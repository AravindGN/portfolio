var atollSchemaRes = [];
var getSitesV = [];
var siteAutoAjax;
var siteGrid;
var transmitterTableGrid;
var cell5gnrGrid;
var spareAntennaGrid;
var cellLTEGrid;
var gridData = [];
var oldGridData = [];
var savePayload;
var routerParams = {};
var isParamPresentInUrl = false;
var dataModified = false;
var allDropdownVal = {};
var columnIndexs = {} ;
var versionsSelected = [];
var mountFaceVal = ['A','B','C','D','E','F','G','H','I'];
const shouldShowVzCbandSwitchPower = (Object.keys(featureToggleMap).includes("M-7177") && featureToggleMap['M-7177']);

var spareAntennaGridColumns = [
                {readOnly:false,type: 'text',width: '160px',title: 'SPARE_ANTENNA_ID',name: 'spareAntennaId'},
                {readOnly:false,type: 'text',width: '160px',title: 'SITE_RECORD_ID',name: 'siteRecordId',wordWrap: true},
                {readOnly:false,type: 'text',width: '160px',name: "mountFace",title: "MOUNT_FACE",wordWrap: true},
                {readOnly:false,type: 'text',width: '160px',name: "mountPosition",title: "MOUNT_POSITION",wordWrap: true},
                {readOnly:false,type: 'text',width: '160px',name: "manufacturer",title: "MANUFACTURER",wordWrap: true},
                {readOnly:false,type: 'text',width: '160px',name: "orderablePartName",title: "ORDERABLE_PART_NAME",wordWrap: true},
                {readOnly:false,type: 'text',width: '160px',name: "centreLine",title: "CENTERLINE",wordWrap: true},
                {readOnly:false,type: 'text',width: '160px',name: "antennaTipHeight",title: "ANTENNA_TIP_HEIGHT",wordWrap: true},
                {readOnly:false,type: 'text',width: '160px',name: "installType",title: "INSTALL_TYPE",wordWrap: true},
                {readOnly:false,type: 'text',width: '160px',name: "notes",title: "NOTES",wordWrap: true},
                {readOnly:false,type: 'text',width: '160px',name: "model",title: "MODEL",wordWrap: true},
                {readOnly:false,type: 'text',width: '160px',name: "azimuth",title: "AZIMUT",wordWrap: true},
                {readOnly:false,type: 'text',width: '160px',name: "spareCoaxConnection",title: "SPARE_COAX_CONNECTION",wordWrap: true}
            ];
var siteTableColumns = [
    { name: 'name', type: 'text', title: 'NAME', width: 140, readOnly: true },
    { name: 'latitude', type: 'text', title: 'LATITUDE', width: 160, readOnly: false },
    { name: 'longitude', type: 'text', title: 'LONGITUDE', width: 160, readOnly: false },
    { name: 'altitude', type: 'text', title: 'ALTITUDE (ft)', width: 160, readOnly: false },
    { name: 'pylonHeight', type: 'text', title: 'SUPPORT HEIGHT (ft)', width: 160, readOnly: false },
    { name: 'vzSiteCode', type: 'text', title: 'SITE CODE', width: 160, readOnly: false },
    { name: 'vzSiteNumber', type: 'text', title: 'SITE NUMBER', width: 160, readOnly: false },
    { name: 'vzSiteVersion', type: 'text', title: 'SITE VERSION', width: 160, readOnly: false },
    { name: 'vzZipCode', type: 'text', title: 'ZIP CODE', width: 160, readOnly: false },
    { name: 'vzLocationName', type: 'text', title: 'LOCATION NAME', width: 140, readOnly: false },
    { name: 'vzStreetAddress', type: 'text', title: 'STREET ADDRESS', width: 160, readOnly: false },
    { name: 'vzState', type: 'dropdown', source : allDropdownVal.VZ_STATE,title: 'STATE', width: 160, readOnly: false },                                                                  
    { name: 'vzCity', type: 'text', title: 'CITY', width: 160, readOnly: false },
    { name: 'vzCounty', type: 'text', title: 'COUNTY', width: 160, readOnly: false },
    { name: 'vzSiteName', type: 'text', title: 'SITE FRIENDLY NAME', width: 160, readOnly: false },
    { name: 'vzNetworkterritory', type: 'text', title: 'NETWORK TERRITORY', width: 160, readOnly: true },
    { name: 'vzNetworkMarket', type: 'text', title: 'NETWORK MARKET', width: 160, readOnly: true },
    { name: 'vzNetworkSubMarket', type: 'text', title: 'NETWORK SUBMARKET', width: 140, readOnly: true },
    { name: 'vzNetworkSchema', type: 'text', title: 'NETWORK SCHEMA', width: 140, readOnly: true },
    { name: 'vzCountry', type: 'dropdown', sourcce : allDropdownVal.VZ_COUNTRY ,title: 'COUNTRY', width: 160, readOnly: false },
    { name: 'vzSiteInfoId', type: 'text', title: 'SITE INFO ID', width: 160, readOnly: true },
    { name: 'vzNetworkExtCapable', type: 'dropdown', source:allDropdownVal.VZ_NETWORK_EXT_CAPABLE,title: 'NETWORK EXTENDER CAPABLE', width: 160, readOnly: false },
    { name: 'vzTempSite', type: 'dropdown', source: allDropdownVal.VZ_TEMP_SITE, title: 'TEMPORARY SITE', width: 160, readOnly: false },
    { name: 'vzLraPartner', type: 'text', title: 'LRA PARTNER', width: 160, readOnly: false },
    { name: 'vzSurveyedAltitude', type: 'text', title: 'SURVEYED ALTITUDE', width: 160, readOnly: false },
    { name: 'vzOverallStructureHT', type: 'text', title: 'OVERALL STRUCTURE HEIGHT', width: 160, readOnly: false },
    { name: 'vzStructureType', type: 'dropdown', source : allDropdownVal.VZ_STRUCTURE_TYPE ,title: 'STRUCTURE TYPE', width: 160, readOnly: false },
    { name: 'vzNetworkLocale', type: 'text', title: 'NETWORK LOCALE MARKET', width: 160, readOnly: true },
    { name: 'vzCountyFips', type: 'text', title: 'FIPS COUNTY CODE', width: 140, readOnly: true },
    { name: 'vzCranHubName', type: 'text', title: 'C-RAN HUB NAME', width: 140, readOnly: false },
    { name: 'vzSiteRecordId', type: 'text', title: 'SITE RECORD ID', width: 160, readOnly: true },
    { name: 'vzSpmProjectId', type: 'text', title: 'VZ SPM PROJECT ID', width: 160, readOnly: true },
    { name: 'vz5gcMarket', type: 'text', title: '5GC BAND MARKET', width: 160, readOnly: false },
    { name: 'siteType', type: 'text', title: 'SITE TYPE', width: 160, readOnly: false },
    { name: 'siteSubType', type: 'text', title: 'SITE SUBTYPE', width: 160, readOnly: false }
    ];

var transmitterGridColumns = [
	
    { name: 'siteName', type: 'text', title: 'SITE', width: 140, readOnly: true },
    { name: 'txId', type: 'text', title: 'TRANSMITTER', width: 160, readOnly: true },
    { name: 'fband', type: 'dropdown', source : allDropdownVal.FBAND,title: 'FREQUENCY BAND', width: 160, readOnly: false },
    { name: 'antennaName', type: 'text', title: 'ANTENNA', width: 160, readOnly: false },
    { name: 'height', type: 'text', title: 'HEIGHT', width: 160, readOnly: false },
    { name: 'azimut', type: 'text', title: 'AZIMUT', width: 160, readOnly: false },
    { name: 'tilt', type: 'text', title: 'MECHANICAL DOWN TILT', width: 160, readOnly: false },
    { name: 'calcRadius', type: 'text', title: 'MAIN CALCULATION RADIUS', width: 160, readOnly: false },
    { name: 'propagModel', type: 'dropdown', source : allDropdownVal.PROPAG_MODEL,title: 'MAIN PROPAGATION MODEL', width: 160, readOnly: false },
    { name: 'txLosses', type: 'text', title: 'TRANSMISSION LOSSES', width: 140, readOnly: false },
    { name: 'rxLosses', type: 'text', title: 'RECEPTION LOSSES', width: 160, readOnly: false },
    { name: 'noiseFigure', type: 'text', title: 'NOISE FIGURE', width: 160, readOnly: false },
    { name: 'comment', type: 'text', title: 'COMMENT', width: 160, readOnly: false },
    { name: 'tmaName', type: 'text', title: 'TMA EQUIPMENT', width: 160, readOnly: true },
    { name: 'feederName', type: 'text', title: 'FEEDER EQUIPMET', width: 160, readOnly: true },
    { name: 'btsName', type: 'text', title: 'TRANSMITTER NAME', width: 160, readOnly: true },
    { name: 'feederLengthDL', type: 'text', title: 'TRANSMISSION FEEDER LENGTH', width: 160, readOnly: false },
    { name: 'feederLengthUL', type: 'text', title: 'RECEPTION FEEDER LENGTH', width: 160, readOnly: false },
    { name: 'missDll', type: 'text', title: 'MISSDLL', width: 140, readOnly: false },
    { name: 'missUll', type: 'text', title: 'MISSULL', width: 160, readOnly: false },
    { name: 'calcRadius2', type: 'text', title: 'EXTENDED CALCULATION RADIUS', width: 160, readOnly: false },
    { name: 'propagModel2', type: 'dropdown', source : allDropdownVal.PROPAG_MODEL2, title: 'EXTENDED PROPAGATION MODEL', width: 160, readOnly: false },
    { name: 'calcResolution', type: 'text', title: 'MAIN RESOLUTION', width: 160, readOnly: false },
    { name: 'calcResolution2', type: 'text', title: 'EXTENDED RESOLUTION2', width: 160, readOnly: false },
    { name: 'redt', type: 'text', title: 'ADDITIONAL ELECTRICAL DOWNTILT', width: 160, readOnly: false },
    { name: 'absX', type: 'text', title: 'LONGITUDE', width: 160, readOnly: false },
    { name: 'absY', type: 'text', title: 'LATITUDE', width: 160, readOnly: false },
    { name: 'bfModel', type: 'dropdown', source : allDropdownVal.BF_MODEL, title: 'BEAMFORMING MODEL', width: 140, readOnly: false },
    { name: 'ntxAntennas', type: 'dropdown', source:allDropdownVal.N_TX_ANTENNAS ,title: 'NUMBER OF TRANSMISSION ANTENNAS', width: 160, readOnly: false },
    { name: 'nrxAntennas', type: 'dropdown', source: allDropdownVal.N_RX_ANTENNAS, title: 'NUMBER OF RECEPTION ANTENNAS', width: 160, readOnly: false },
    { name: 'vzEnodebVendor', type: 'dropdown', source : allDropdownVal.VZ_ENODEB_VENDOR ,title: 'VZ_ENODEB_VENDOR', width: 160, readOnly: false },
    { name: 'vzMissTxLossCom', type: 'text', title: 'MISCELLANEOUS TRANSMISSION LOSSES(dB)', width: 160, readOnly: false },
    { name: 'vzMissRxLossCom', type: 'text', title: 'MISCELLANEOUS RCEPTION LOSSES(dB)', width: 160, readOnly: false },
    { name: 'vzTmaJumperLoss', type: 'text', title: 'TMA JUMPER_LOSS', width: 160, readOnly: false },
    { name: 'vzEpaInputJumLoss', type: 'text', title: 'EPA INPUT JUMPER LOSS(dB)', width: 160, readOnly: false },
    { name: 'vzSystNoiseTemp', type: 'text', title: 'SYSTEM NOISE TEMP(K)', width: 160, readOnly:true },
    { name: 'vzTmaBenefitGain', type: 'text', title: 'TMA BENEFIT GAIN(dB)', width: 160, readOnly: true },
    { name: 'vzEpaModel', type: 'text', title: 'EPA MODEL', width: 160, readOnly: false },
    { name: 'vzEpaManufacturer', type: 'text', title: 'EPA MANUFACTURER', width: 160, readOnly: false },
    { name: 'vzTmaModel', type: 'text', title: 'TMA MODEL', width: 160, readOnly: false },
    { name: 'vzTmaManufacturer', type: 'text', title: 'TMA MANUFACTURER', width: 160, readOnly: false },
    { name: 'vztransmitterCode', type: 'text', title: 'TRANSMITTER CODE', width: 160, readOnly: false },
    { name: 'vzfeederLossRx', type: 'text', title: 'FEEDER LOSS RX(dB)', width: 160, readOnly: true },
    { name: 'vzFeederLossTx', type: 'text', title: 'FEEDER LOSS TX(dB)', width: 140, readOnly: true },
    { name: 'vzRrhManufacturer', type: 'dropdown', source:allDropdownVal.VZ_RRH_MANUFACTURER,title: 'RADIO MANUFACTURER', width: 160, readOnly: false },
    { name: 'vzRrhModel', type: 'dropdown', source:allDropdownVal.VZ_RRH_MODEL,title: 'RADIO MODEL', width: 160, readOnly: false },
    { name: 'vzTipHeight', type: 'text', title: 'TIP HEIGHT(FT)', width: 160, readOnly: false },
    { name: 'vzCenterLine', type: 'text', title: 'CENTERLINE(FT)', width: 160, readOnly: false },
    { name: 'vzRptrNoiseRiseLoss', type: 'text', title: 'NOISE EQUIVALENT TO NOISE RAISE FROM REPEATERS(dB)', width: 160, readOnly: true },
    { name: 'vzTotalTilt', type: 'text', title: 'TOTAL TILT(DEG)', width: 160, readOnly: true },
    { name: 'vzAntennaHBw', type: 'text', title: 'ANTENNA H-BW', width: 160, readOnly: true },
    { name: 'vzAntennaVBw', type: 'text', title: 'ANTENNA V-BW', width: 160, readOnly: true },
    { name: 'vzLteVendorPower', type: 'dropdown', source : allDropdownVal.VZ_5G_VENDOR_POWER ,title: 'LTE VENDOR POWER', width: 160, readOnly: false },
    { name: 'vz5gVendorPower', type: 'dropdown', source :allDropdownVal.VZ_5G_VENDOR_POWER  , title: '5G VENDOR POWER', width: 160, readOnly: false },
    { name: 'vzTotalBandwidth', type: 'text', title: 'TOTAL BAND WIDTH(MHz)', width: 160, readOnly: true },
    { name: 'vzLteMaxPower', type: 'text', title: 'LTE TOTAL MAX POWER', width: 160, readOnly: false },
    { name: 'vz5gMaxPower', type: 'text', title: '5G TOTAL MAX POWER', width: 160, readOnly: false },
    { name: 'vzTotalErpW', type: 'text', title: 'TOTAL ERP', width: 160, readOnly: true },
    { name: 'vzTotalEirpW', type: 'text', title: 'TOTAL EIRP', width: 140, readOnly: true },
    { name: 'vzRegulatoryPower', type: 'text', title: 'PSD REGULATORY POWER', width: 160, readOnly: true },
    { name: 'vzRegulatoryPowerNonPsd', type: 'text', title: 'NON-PSD REGULATORY_POWER', width: 160, readOnly: true },
    { name: 'vzMountPosition', type: 'dropdown', source: allDropdownVal.VZ_MOUNT_POSITION,title: 'MOUNT POSITION', width: 160, readOnly: false },
    { name: 'vzMountFace', type: 'dropdown', source: allDropdownVal.VZ_MOUNT_FACE, title: 'MOUNT FACE', width: 160, readOnly: false },
    { name: 'bfETilt', type: 'text', title: 'BEAFORMING ELECTRICAL TILT', width: 160, readOnly: true },
    { name: 'vzSectorEquipmentFunctionId', type: 'text', title: 'SECTOR EQUIPMENT FUNCTION ID', width: 160, readOnly: true },
    { name: 'vzAllowedMaxPowerCBR', type: 'text', title: 'FAA MAX CONDUCTED POWER', width: 160, readOnly: true },
    { name: 'vzMaxAllowedMaxPowerRFE', type: 'text', title: 'MAX ALLOWED POWER FOR RFE', width: 160, readOnly: true },
    { name: 'vzTxGroup', type: 'text', title: 'TX GROUP', width: 160, readOnly: false },
    { name: 'vzAllowedMaxPowerES', type: 'text', title: 'MAX ALLOWED POWER FOR EARTH STATION', width: 160, readOnly: true },
    { name: 'vzBfOpPortCount', type: 'text', title: 'OPERATIONAL PORT COUNT', width: 160, readOnly: false },
    { name: 'vzElectricalAzimuth', type: 'text', title: 'VZ_ELECTRICAL_AZIMUTH', width: 160, readOnly: false },
    { name: 'vzEnodebId', type: 'hidden',source: allDropdownVal.VZ_ENODEB_ID,title: 'VZ_ENODEB_ID', width: 160, css:"hide"}
    ];

var cellLTEGridColumns = [
    {type: 'text',width: '160px',name: 'cellId',title: 'Name'},
    {type: 'text',width: '160px',name: 'txId',title: 'Transmitter',wordWrap: true},
    {type: 'text',width: '160px',name: "carrier",title: "Carrier",wordWrap: true},
    {type: 'text',width: '160px',name: "maxPower",title: "Max Power(dBm)",wordWrap: true},
    {type: 'text',width: '160px',name: "minRsrp",title: "Min RSRP(dBm)",wordWrap: true},
    {type: 'text',width: '160px',name: "pbchPowerOffset",title: "PBCH EPRE Offset/SSS(dB)",wordWrap: true},
    {type: 'text',width: '160px',name: "pdcchPowerOffset",title: "PDCCH EPRE Ofset/SSS(dB)",wordWrap: true},
    {type: 'dropdown',source:allDropdownVal.PDCCH_SYMBOLS,width: '160px',name: "pdcchSymbols",title: "PDCCH Overhead (OFDM Symbols)",wordWrap: true},
    {type: 'text',width: '160px',name: "pdschPowerOffset",title: "PDSCH & CSI-RS EPRE Offset/SSS(dB)",wordWrap: true},
    {type: 'text',width: '160px',name: "pmchPowerOffset",title: "PMCH EPRE Offset/RS(dB)",wordWrap: true},
    {type: 'text',width: '160px',name: "pucchPrb",title: "PUCCH Overhead(PRBs)",wordWrap: true},
    {type: 'text',width: '160px',name: "rsEpre",title: "RS EPRE per Port(dBm)",wordWrap: true},
    {type: 'text',width: '160px',name: "ssPowerOffset",title: "SS EPRE Offset/RS(dB)",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzCellName",title: "VZ Cell Name",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzCellId",title: "Cell ID",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzSectorId",title: "Sector ID",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzCarrierId",title: "Carrier ID",wordWrap: true},
    {type: 'text',width: '160px',name: "vzTac",title: "TAC",wordWrap: true},
    {type: 'text',width: '160px',name: "vzAluLteMaxpower",title: "(ALU LTE) cellDLTotalPower (dBm)",wordWrap: true},
    {type: 'text',width: '160px',name: "vzAluLteRsEpre",title: "(ALU LTE) referenceSignalPower (dBm)",wordWrap: true},
    {type: 'text',width: '160px',name: "vzAluSsOffset",title: "(ALU LTE) PrimarySyncSignalPowerOffset (dB)",wordWrap: true},
    {type: 'text',width: '160px',name: "vzAluPbchOffset",title: "(ALU LTE) pBCHPowerOffset (dB)",wordWrap: true},
    {type: 'text',width: '160px',name: "vzAluPdcchOffset",title: "(ALU LTE) pDCCHPowerOffsetSymbol1 (dB)",wordWrap: true},
    {type: 'text',width: '160px',name: "vzAluPdschOffset",title: "(ALU LTE) paOffsetPdsch (dB)",wordWrap: true},
    {type: 'text',width: '160px',name: "vzeriLteMaxPower",title: "(ERC) maximumTransmissionPower (0.1 dBm) (Info)",wordWrap: true},
    {type: 'dropdown',source:allDropdownVal.VZ_CARRIER_LABEL,width: '160px',name: "vzCarrierLabel",title: "Carrier Label",wordWrap: true},
    {type: 'text',width: '160px',name: "vzEriCrsGain",title: "(Ericsson LTE) crsGain (0.01 dB)",wordWrap: true},
    {type: 'text',width: '160px',name: "vzMcc",title: "MCC",wordWrap: true},
    {type: 'text',width: '160px',name: "vzMnc",title: "MNC",wordWrap: true},
    {type: 'text',width: '160px',name: "vzEriLteDLAttenuation",title: "(ERC) dlAttenuation (0.1 dBm) (Info)",wordWrap: true},
    {type: 'text',width: '160px',name: "vzEnodebCellAlias",title: "eNodeB Cell Alias",wordWrap: true},
    {type: 'text',width: '160px',name: "vzEriLteConfMaxTxPwr",title: "(Ericsson LTE) configuredMaxTxPower (mW)",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzEcgi",title: "ECGI",wordWrap: true},
    {type: 'text',width: '160px',name: "vzNokLtePmax",title: "(Nokia LTE) pMax (dBm)",wordWrap: true},
    {type: 'text',width: '160px',name: "vzNokLteDlCellPwrred",title: "(Nokia LTE) dlCellPwrRed (dB)",wordWrap: true},
    {type: 'text',width: '160px',name: "vzNokLteDlrsBoost",title: "(Nokia LTE) dlRsBoost (dB)",wordWrap: true},
    {type: 'text',width: '160px',name: "vzSeaMaxTxPower",title: "(Samsung LTE) dlMaxTxPower (0.1 dBm)",wordWrap: true},
    {type: 'text',width: '160px',name: "vzSeaTxAttenuation",title: "(Samsung LTE) TxAtten (0.1 dB)",wordWrap: true},
    {type: 'text',width: '160px',name: "vzSeaPowerBoostFlag",title: "(Samsung LTE) dlPdschPowerBoostFlag",wordWrap: true},
    {type: 'text',width: '160px',name: "vzSeaPowerOption",title: "(Samsung LTE) dlPowerOption",wordWrap: true},
    {type: 'text',width: '160px',name: "vzSeaSsGain",title: "(Samsung LTE) ssPowerGain (dB)",wordWrap: true},
    {type: 'text',width: '160px',name: "vzSeaPbchGain",title: "(Samsung LTE) pbchPowerGain (dB)",wordWrap: true},
    {type: 'text',width: '160px',name: "vzMinAllowedPower",title: "Min Allowed Power Setting",wordWrap: true},
    {type: 'text',width: '160px',name: "vzMaxAllowedPower",title: "Max Allowed Vendor Power Setting",wordWrap: true},
    {type: 'text',width: '160px',name: "vzAllowedPoweComment",title: "Allowed Power Setting Comments",wordWrap: true},
    {type: 'text',width: '160px',name: "vzMaxPowerRfeW",title: "Max Power for RFE (Watts)",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzBandInfo",title: "Band Info",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzDlFrequency",title: "Centre Frequency(DL)(MHz)",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzDlWidth",title: "Total Width(DL)(MHz)",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzArfcn",title: "ARFCN",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzBlock",title: "Block",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzSubBlock",title: "Subblock",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzTotalErpW",title: "ERP(W)",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzTotalEirpW",title: "EIRP(W)",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzbandClass",title: "Band Class Layer",wordWrap: true},
    {type: 'text',width: '160px',name: "vzLraMnc",title: "Secondary MNC",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzCellRecordId",title: "5G Cell Record ID",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzNRbTotal",title: "Total Number of PRBs",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzMaxAllowedPowerSettingFcc",title: "Max Allowed Vendor Power Setting For FCC",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzMaxAllowedPowerSettingRfe",title: "Max Allowed Vendor Power Setting For RFE",wordWrap: true},
	{readOnly:true,type: 'text',width: '160px',name: "vzMaxAllowedPowerSettingSpectrumBorder",title: "Max Allowed Power Setting For Spectrum Border",wordWrap: true},
	{readOnly:true,type: 'text',width: '160px',name: "vzMaxAllowedPowerSetting",title: "Calculated Max Allowed Vendor Power Setting",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzArfcnUl",title: "UL ARFCN",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzLteCellFriendName",title: "Cell Friendly Name",wordWrap: true},
    {type: 'text',width: '160px',name: "vzIsVran",title: "VZ_IS_VRAN",wordWrap: true},
    {type: 'text',width: '160px',name: "vzOperationalState",title: "VZ_OPERATIONAL_STATE",wordWrap: true},
	{type: 'dropdown',source:["Yes","No"],width: '160px',name: "vzDlOnlyChannel",title: "DL only Channel",wordWrap: true},
    {type: 'text',width: '160px',name: "vzRegulatoryPower",title: "PSD Regulatory Power",wordWrap: true},
    {type: 'text',width: '160px',name: "vzregulatoryPowerNonPsd",title: "Non-PSD Regulatory Power",wordWrap: true}
     ];
var Cells5GnrGridColumns = [
    {type: 'text',width: '160px',name: 'cellId',title: 'Name'},
    {type: 'text',width: '160px',name: 'txId',title: 'Transmitter',wordWrap: true},
    {type: 'text',width: '160px',name: "carrier",title: "Carrier",wordWrap: true},
    {type: 'text',width: '160px',name: "pci",title: "Physical Cell ID ",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "pssId",title: "PSS ID",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "sssId",title: "SSS ID",wordWrap: true},
    {type: 'text',width: '160px',name: "maxPower",title: "Max Power(dBm)",wordWrap: true},
    {type: 'text',width: '160px',name: "minSssRsrp",title: "Min SS-RSRP(dBm)",wordWrap: true},
    {type: 'text',width: '160px',name: "sssPower",title: "SSS EPRE(dBm)",wordWrap: true},
    {type: 'text',width: '160px',name: "pssPowerOffset",title: "PSS EPRE Offset/SSS(dB)",wordWrap: true},
    {type: 'text',width: '160px',name: "pbchPowerOffset",title: "PBCH EPRE Offset/SSS(dB)",wordWrap: true},
    {type: 'text',width: '160px',name: "pdcchPowerOffset",title: "PDCCH EPRE Ofset/SSS(dB)",wordWrap: true},
    {type: 'text',width: '160px',name: "pdcchSymbols",title: "PDCCH Overhead (OFDM Symbols)",wordWrap: true},
    {type: 'text',width: '160px',name: "pdschPowerOffset",title: "PDSCH & CSI-RS EPRE Offset/SSS(dB)",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzCellName",title: "VZ Cell Name",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzCellId",title: "Cell ID",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzSectorId",title: "Sector ID",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzCarrierId",title: "Carrier ID",wordWrap: true},
    {type: 'text',width: '160px',name: "vzTac",title: "TAC",wordWrap: true},
    {type: 'dropdown',source:allDropdownVal.VZ_CARRIER_LABEL,width: '160px',name: "vzCarrierLabel",title: "Carrier Label",wordWrap: true},
    {type: 'text',width: '160px',name: "vzMcc",title: "MCC",wordWrap: true},
    {type: 'text',width: '160px',name: "vzMnc",title: "MNC",wordWrap: true},
    {type: 'text',width: '160px',name: "vz5gCellFriendName",title: "Cell Friendly Name",wordWrap: true},
    {type: 'text',width: '160px',name: "vz4gAnchorEnbid",title: "4G Anchor eNB ID",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzBandInfo",title: "Band Info",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzDlFrequency",title: "Centre Frequency(DL)(MHz)",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzDlWidth",title: "Total Width(DL)(MHz)",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzArfcn",title: "ARFCN",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzBlock",title: "Block",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzSubBlock",title: "Subblock",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzTotalErpW",title: "ERP(W)",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzTotalEirpW",title: "EIRP(W)",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzBandClass",title: "Band Class Layer",wordWrap: true},
    {type: 'text',width: '160px',name: "vzLraMnc",title: "Secondary MNC",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzCellRecordId",title: "5G Cell Record ID",wordWrap: true},
    {type: 'text',width: '160px',name: "vzGnodebCellAlias",title: "gNodeB Cell Alias",wordWrap: true},
    {type: 'text',width: '160px',name: "vzNcgi",title: "NCGI",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzNRbTotal",title: "Total Number of PRBs",wordWrap: true},
    {type: 'text',width: '160px',name: "vz5gEriLteConfMaxTxPwr",title: "(Ericsson 5G)configuredMaxTxPower(mW)",wordWrap: true},
    {type: 'text',width: '160px',name: "vz5gNokLtePmax",title: "(Nokia 5G)pMax(dBm)",wordWrap: true},
    {type: 'text',width: '160px',name: "vz5gSeaMaxTxPwr",title: "(Samsung 5G)dlMaxTxPower(0.1 dBm)",wordWrap: true},
    {type: 'text',width: '160px',name: "vzParrRequired",title: "VZ_PARR_REQUIRED",wordWrap: true},
    {type: 'text',width: '160px',name: "vzParrActive",title: "VZ_PARR_ACTIVE",wordWrap: true},
    {type: 'text',width: '160px',name: "vzParrRequiredParameter",title: "VZ_PARR_REQUIRED_PARAMETER",wordWrap: true},
    {type: 'text',width: '160px',name: "vzParrSetting",title: "VZ_PARR_SETTING",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzMaxAllowedPowerSettingFcc",title: "Max Allowed Vendor Power Setting For FCC",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzMaxAllowedPowerSettingCbr",title: "Max Allowed Vendor Power Setting For FAA",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzMaxAllowedPowerSettingRfe",title: "Max Allowed Vendor Power Setting For RFE",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzMaxAllowedPowerSettingSpectrumBorder",title: "Max Allowed Power Setting For Spectrum Border",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzMaxAllowedPowerSetting",title: "Calculated Max Allowed Vendor Power Setting",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzArfcnUl",title: "UL ARFCN",wordWrap: true},
    {readOnly:true,type: 'text',width: '160px',name: "vzMaxAllowedPowerSettingEs",title: "Max Allowed Vendor Power for Earth Station",wordWrap: true},
    {type: 'text',width: '160px',name: "vzSaNsa",title: "VZ_SA_NSA",wordWrap: true},
    {type: 'text',width: '160px',name: "vzPlannedTac",title: "VZ_PLANNED_TAC",wordWrap: true},
    ...(!shouldShowVzCbandSwitchPower ? [{
    type: 'text',
    width: '160px',
    name: "vzCbandSwitchPower",
    title: "VZ_CBAND_SWITCH_POWER",
    wordWrap: true
  }] : []),
    {type: 'text',width: '160px',name: "vzregulatoryPower",title: "PSD Regulatory Power",wordWrap: true},
    {type: 'text',width: '160px',name: "vzRegulatoryPowerNonPsd",title: "Non-PSD Regulatory Power",wordWrap: true}
    ];        
    
$(document).ready(function (e) {

    // try {
    // var env = window.location.href.includes('canvasple') ? '-PLE' : '';
    //     window.initClickstream({
    //         "system_name": "Network Planning Platform",
    //         "app_name": "ATOLL" + env,
    //         "screen_name": "Atoll Site Management",
    //         "showLogs" : "true"
    //     });
    // } catch(e) {
    //     return false;
    // }

    $('#commonSchemaSearch').show();
    commonSchemaSearch('commonSiteManagmentSchemaSearch');
    if (Object.keys(featureToggleMap).includes("F91670") && featureToggleMap['F91670']) {
    	$('#sectorAddPopupIcon').show();
    	$('#addCarrierPopupIcon').show();
    	$('#copySitePopup').show();
    	$('#applyAllButton').show();
    	$('#addCellPopupIcon').show();
    }else{
    	$('#sectorAddPopupIcon').hide();
    	$('#addCarrierPopupIcon').hide();
    	$('#copySitePopup').hide();
    	$('#applyAllButton').hide();
    	$('#addCellPopupIcon').hide();
    }
    
    if (Object.keys(featureToggleMap).includes("F91285") && featureToggleMap['F91285']) {
      	buildCells5gnrGrid();
        buildSpareAntennaGrid();
        buildCellLTEGrid();
        buildTransmitterGrid();
        buildSitesGrid();
        $('#JSTables').show();
        $('#transmitterKendoTable').hide();
        $('#versionKendoTable').hide();
        $('#cellKendoTable').hide();
        $('#transmitterGrid').hide();
        $('#versionGrid').hide();
        $('#cellsGrid').hide();
    }
    else{
    	$('#JSTables').hide();
    	$('#transmitterKendoTable').show();
        $('#versionKendoTable').show();
        $('#cellKendoTable').show();
        $('#transmitterGrid').show();
        $('#versionGrid').show();
        $('#cellsGrid').show();
   
    }
    $('#loading').hide();
})

function copySitePopupInfo(){
	$('#siteNameInPopup').val(selectedCommonSearchSitename);
	$('#siteVersionInPopup').empty();
	$.each(commonSearchSelectedsiteversion, function(i, v){
        $('#siteVersionInPopup').append("<option>" + v + "</option>");
     });
     if(gridData && gridData.sites && gridData.sites.length>0)
     $("#copySitePopupModal").show();
     else 
     aptAlert('warning', 'No records found to copy site!');
}

function closeCopySitePopup(){
	$("#copySitePopupModal").hide();
}

$('#newSiteVersionInPopup').on("keyup", function(){
        validateCopy();
    })
    
$('#newSiteVersionInPopup').on("change", function(){
        validateCopy();
    })

function validateCopy(){
    if($('#newSiteVersionInPopup').val() == undefined || $('#newSiteVersionInPopup').val() == null || $('#newSiteVersionInPopup').val().trim().length == 0){
        $('#copySubmitBtn').attr("disabled", true);
        return;
    }
    else {
	    $('#copySubmitBtn').attr("disabled", false);
     }
}

$('#copySubmitBtn').click(function(e){
	versionName = document.getElementById('newSiteVersionInPopup').value;
	validateVersion(versionName);
	if(versionFlag == 1){
		return errorAlert('Error', 'Version alreay exists!');
		
	} else {
		let siteDataObj = gridData.sites.find(item=>item.vzSiteVersion==$('#siteVersionInPopup').val() && item.vzSiteName == $('#siteNameInPopup').val());
		if(siteDataObj != null && !$.isEmptyObject(siteDataObj)){
			$('#loading').show();
			let payload = {
				"flag": "true",
				"market": commonSchemaSearchPayload.atollSchema,
				"message": null,
				"siteName": commonSchemaSearchPayload.siteName,
			    "siteRecordId": siteDataObj.vzSiteRecordId,
				"siteVersion": versionName,
				"user": VZID
			};
		    $.ajax({
						type : "POST",
						url : createNewSiteVersionUrl,
						// url: 'http://localhost:8100/npp-atoll-services/siteManagement/createNewSite',
						data : JSON.stringify(payload),
						contentType: 'application/json',
						success : function(data) {
							$('#loading').hide();
							if(data != null && !$.isEmptyObject(data)){
							let oldData = data;
							for(var i=0; i<data.sites.length; i++){
								gridData.sites.push(data.sites[i]);
								oldGridData.sites.push(JSON.parse(JSON.stringify(oldData.sites[i])));
							}
							for(var i=0; i<data.xgTransmitters.length; i++){
								gridData.xgTransmitters.push(data.xgTransmitters[i]);
								oldGridData.xgTransmitters.push(JSON.parse(JSON.stringify(oldData.xgTransmitters[i])));
							}
							for(var i=0; i<data.xgCellsLte.length; i++){
								gridData.xgCellsLte.push(data.xgCellsLte[i]);
								oldGridData.xgCellsLte.push(JSON.parse(JSON.stringify(oldData.xgCellsLte[i])));
							}
							for(var i=0; i<data.xgCells5gnr.length; i++){
								gridData.xgCells5gnr.push(data.xgCells5gnr[i]);
								oldGridData.xgCells5gnr.push(JSON.parse(JSON.stringify(oldData.xgCells5gnr[i])));
							}
							for(var i=0; i<data.spareAntennas.length; i++){
								gridData.spareAntennas.push(data.spareAntennas[i]);
								oldGridData.spareAntennas.push(JSON.parse(JSON.stringify(oldData.spareAntennas[i])));
							}
							successAlert('Success','New version created successfully!');
							getSiteVersionCommonSearch(selectedCommonSearchSitename, sechmaListCommonSearch, 'commonSiteManagmentSchemaSearchVersionList', []);
							$('#copySitePopupModal').hide();
							}
							 else {
								errorAlert('Error','Version alreay exists!');
							}
						},
						error : function(response) {
							$('#loading').hide();
							errorAlert('Error',
									'Error occured in Creating New Version');
						}
					});
		}
	}
	});
	
var versionFlag = 0;
var allVersions;
function validateVersion(versionName){
	versionFlag = 0;
	allVersions = $('#commonSiteManagmentSchemaSearchVersionList').val();
	for( var i = 0;i < allVersions.length ; i++){
		if(allVersions[i] == versionName){
			versionFlag =1;
		}
	}
}

$("#siteManagementSaveConfirmation").click(function(){
	$('#loading').show();
    $("#siteManagementSaveConfirmationModal").modal("hide");
	$.ajax({
		type: 'POST',
	    url: saveSiteManagementInfoUrl,
		contentType: 'application/json; charset=UTF-8',
		cache: false,
		data: JSON.stringify(savePayload), 
		success: function (data) {
			$('#loading').hide();
			if(Object.keys(featureToggleMap).includes("F98384") && featureToggleMap['F98384']){
			if(data.validationStatus){
            aptAlert('Success', 'Site Management Info updated successfully!');
            searchButtonIntegration();
            }else{
            aptAlert('error', data.comments);
            }
			}else{
			searchButtonIntegration();
			aptAlert('Success', 'Site Management Info updated successfully!');
			}
		},
		error: function (data) {
			$('#loading').hide();
			aptAlert('error', 'Site Management Info failed to update');
		}
	});
    
}
);

function refreshSiteManagementInfo(){
	searchButtonIntegration();
}

function allTablesDropDownVal() {
	var marketVal = commonSchemaSearchPayload.atollSchema;
	//$('#loading').show();
	$.ajax({
		type : "POST",
		url : fetchChoiceListUrl+'?market='+marketVal,
		// url: 'http://localhost:8100/npp-atoll-services/atollUtility/fetchChoiceList?market='+marketVal,
		contentType : 'application/json',
		data: JSON.stringify({
			"columnName": [
				"VZ_LTE_VENDOR_POWER", "VZ_5G_VENDOR_POWER", "VZ_COUNTRY", "VZ_STATE", "VZ_NETWORK_EXT_CAPABLE", "VZ_TEMP_SITE",
				"VZ_STRUCTURE_TYPE", "VZ_CARRIER_LABEL", "VZ_ENODEB_VENDOR", "VZ_RRH_MANUFACTURER", "VZ_RRH_MODEL", "VZ_MOUNT_POSITION",
				"VZ_MOUNT_FACE"
			],
			"tableName": [
				"xgtransmitters", "xgcellslte", "sites"
			]
		}),
	
		success : function(data) {
			allDropdownVal = data;
			transmitterGridColumns[columnIndexs.fband].source = allDropdownVal.FBAND;
			transmitterGridColumns[columnIndexs.propagModel].source = allDropdownVal.PROPAG_MODEL;
			transmitterGridColumns[columnIndexs.propagModel2].source = allDropdownVal.PROPAG_MODEL2;
			transmitterGridColumns[columnIndexs.bfModel].source = allDropdownVal.BF_MODEL;
			transmitterGridColumns[columnIndexs.nrxAntennas].source = allDropdownVal.N_RX_ANTENNAS;
			transmitterGridColumns[columnIndexs.ntxAntennas].source = allDropdownVal.N_TX_ANTENNAS;
			transmitterGridColumns[columnIndexs.vzEnodebVendor].source = allDropdownVal.VZ_ENODEB_VENDOR;
			transmitterGridColumns[columnIndexs.vzRrhManufacturer].source = allDropdownVal.VZ_RRH_MANUFACTURER;
			transmitterGridColumns[columnIndexs.vzRrhModel].source = allDropdownVal.VZ_RRH_MODEL;
			transmitterGridColumns[columnIndexs.vzLteVendorPower].source = allDropdownVal.VZ_LTE_VENDOR_POWER;		
			transmitterGridColumns[columnIndexs.vz5gVendorPower].source = allDropdownVal.VZ_5G_VENDOR_POWER;
			transmitterGridColumns[columnIndexs.vzMountPosition].source = allDropdownVal.VZ_MOUNT_POSITION;
			transmitterGridColumns[columnIndexs.vzMountFace].source = allDropdownVal.VZ_MOUNT_FACE;
			
			siteTableColumns[columnIndexs.vzTempSite].source = allDropdownVal.VZ_TEMP_SITE;
			siteTableColumns[columnIndexs.vzStructureType].source = allDropdownVal.VZ_STRUCTURE_TYPE;
			siteTableColumns[columnIndexs.vzCountry].source = allDropdownVal.VZ_COUNTRY;
			siteTableColumns[columnIndexs.vzNetworkExtCapable].source = allDropdownVal.VZ_NETWORK_EXT_CAPABLE;
			siteTableColumns[columnIndexs.vzState].source = allDropdownVal.VZ_STATE;
			
			Cells5GnrGridColumns[columnIndexs.vzCarrierLabel].source = allDropdownVal.VZ_CARRIER_LABEL;
			cellLTEGridColumns[columnIndexs.pdcchSymbols].source = allDropdownVal.PDCCH_SYMBOLS;
            cellLTEGridColumns[columnIndexs.vzCarrierLabelLte].source = allDropdownVal.VZ_CARRIER_LABEL;

		
			buildTransmitterGrid(gridData.xgTransmitters);
			buildCells5gnrGrid(gridData.xgCells5gnr);
			buildSpareAntennaGrid(gridData.spareAntennas);
			buildCellLTEGrid(gridData.xgCellsLte);
			buildSitesGrid(gridData);
            resetFilters();
			$('#loading').hide();
		},
		error : function(response) {
			//errorAlert('Error', 'Error occured in fetchTransmitterInfoGridMainData');
			$('#loading').hide();
		}
	});
	//searchButtonIntegration();
}

function resetFilters() {
    siteGrid.resetFilters();
    transmitterTableGrid.resetFilters();
    cellLTEGrid.resetFilters();
    cell5gnrGrid.resetFilters();
    spareAntennaGrid[0].resetFilters();
}

function searchButtonIntegration() {
	$('#loading').show();
	$.ajax({
		type : "POST",
	    url : getSiteManagementInfoUrl,
	    // url : 'http://localhost:8100/npp-atoll-services/siteManagement/getSiteManagementInfo',
		contentType : 'application/json',
		data : JSON.stringify({
			"market" : commonSchemaSearchPayload.atollSchema,
			"siteName" : commonSchemaSearchPayload.siteName,
			"versions" : commonSearchSelectedsiteversion
		}),
		success : function(data) {
			versionsSelected = commonSearchSelectedsiteversion;
			let sites = [];
			for(const element of data.sites) {
             let obj = {}
              $.each(element, function(key, val){
	            for(const col of siteTableColumns){
		           if(col.name===key){
			        obj[key] = val;
		           }
	            }
              })
              sites.push(obj);
            }
            
            let xgTransmitters = [];
			for(const element of data.xgTransmitters) {
             let obj = {}
              $.each(element, function(key, val){
	            for(const col of transmitterGridColumns){
		           if(col.name===key){
			        obj[key] = val;
		           }
	            }
              })
              xgTransmitters.push(obj);
            }
            
            let xgCellsLte = [];
			for(const element of data.xgCellsLte) {
             let obj = {}
              $.each(element, function(key, val){
	            for(const col of cellLTEGridColumns){
		           if(col.name===key){
			        obj[key] = val;
		           }
	            }
              })
              xgCellsLte.push(obj);
            }
            
            let xgCells5gnr = [];
			for(const element of data.xgCells5gnr) {
             let obj = {}
              $.each(element, function(key, val){
	            for(const col of Cells5GnrGridColumns){
		           if(col.name===key){
			        obj[key] = val;
		           }
	            }
              })
              xgCells5gnr.push(obj);
            }
            
            let spareAntennas = [];
			for(const element of data.spareAntennas) {
             let obj = {}
              $.each(element, function(key, val){
	            for(const col of spareAntennaGridColumns){
		           if(col.name===key){
			        obj[key] = val;
		           }
	            }
              })
              spareAntennas.push(obj);
            }
			gridData = {
				market: null,
				sites: sites,
				spareAntennas: spareAntennas,
				xgCells5gnr: xgCells5gnr,
				xgCellsLte: xgCellsLte,
				xgTransmitters: xgTransmitters
			};
			//$('#loading').hide();
			
			allTablesDropDownVal();
			oldGridData = JSON.parse(JSON.stringify(gridData));
			//$('#loading').hide();
			
		},
		error : function(response) {
			//errorAlert('Error', 'Error occured in fetchTransmitterInfoGridMainData');
			$('#loading').hide();
		}
	});

}



function buildSitesGrid(data){
    $("#siteGrid").empty();
	 $("#siteGrid").removeClass("jtabs jexcel_container");
     let tableData = data && data.sites ? data.sites : [] ;
     siteGrid = jspreadsheet(document
        .getElementById('siteGrid'), {
        columns: siteTableColumns,
        data: tableData,
        columnDrag: false,
        worksheetName: 'Sites',
        tableOverflow: true,
        tableWidth: '100%',
        tableHeight: '250px',
        minDimensions: [10,1],
        editable: true,
        columnSorting: true,
        columnResize: true,
        tableOverflowResizable: true,
        filters: true,
        onfilter: function(worksheets, terms, rowNumbers){
            var filterData = [];
            if (rowNumbers.length > 0) {
                let columnMap = {
              name:0,latitude:1,longitude:2,altitude:3,pylonHeight:4,vzSiteCode:5,vzSiteNumber:6,vzSiteVersion:7,vzZipCode:8,vzLocationName:9,vzAddressDesc:10,vzStreetAddress:11,vzState:12,vzCity:13,vzCounty:14,
              vzSiteName:15,vzNetworkterritory:16,vzNetworkMarket:17,vzNetworkSubMarket:18,vzNetworkSchema:19,vzCountry:20,vzPeopleSoftLocationCode:21,vzSiteInfoId:22,vzNetworkExtCapable:23,vzTempSite:24,
              vzSurveyedAltitude:25,vzOverallStructureHT:26,vzStructureType:27,vzNetworkLocale:28,vzCountyFips:29,vzCranHubName:30,vzSiteRecordId:31,vz:32,SpmProjectId:33,locusId:34,mdgLocationCode:35,vz5gcMarket:36,
              siteType:37,siteSubType:38
          };
           for (const [key, value] of Object.entries(columnMap)) {
             data.sites.filter(function(data){
                  if (rowNumbers[value]) {
                      Object.keys(rowNumbers[value]).filter(function (type) {
                          if ((data[key] == type)) {
                              obj = {};
                             obj['siteName'] = data.name;
                             obj['siteRecordId'] = data.vzSiteRecordId;
                              filterData.push(obj);
                          }
                      })
                  }
                 
              })
           }
          }else{
                data.sites.filter(function (data) {
                    obj = {};
                    obj['siteName'] = data.name;
                    obj['siteRecordId'] = data.vzSiteRecordId;
                    filterData.push(obj);
                })  
            }
            onChangeSiteVersionFilter(data,filterData);
        }
    });
     columnIndexs.vzTempSite =  siteGrid.getColumnIdByName('vzTempSite');
     columnIndexs.vzStructureType =  siteGrid.getColumnIdByName('vzStructureType');
     columnIndexs.vzCountry =  siteGrid.getColumnIdByName('vzCountry');
     columnIndexs.vzState =  siteGrid.getColumnIdByName('vzState');
     columnIndexs.vzNetworkExtCapable =  siteGrid.getColumnIdByName('vzNetworkExtCapable');
}

function buildTransmitterGrid(data){
    $("#transmitterTableGrid").empty();
$("#transmitterTableGrid").removeClass("jtabs jexcel_container");

transmitterTableGrid = jspreadsheet(document
    .getElementById('transmitterTableGrid'), {
    data: data,
    columns: transmitterGridColumns,
    columnDrag: false,
    worksheetName: 'Transmitter',
    //minDimensions: [68, cellsLTEArray.length],
    tableOverflow: true,
    tableWidth: '100%',
    tableHeight: '250px',
    minDimensions: [10,1],
    editable: true,
    columnSorting: true,
    columnResize: true,
    tableOverflowResizable: true,
    filters: true,
    onfilter: function(worksheets, terms, rowNumbers){
        var filterData = [];
        let columnMap ={};
        if (rowNumbers.length > 0) {
             columnMap = {
                    siteName:0,txId:1,fband:2,antennaName:3,height:4,azimut:5,tilt:6,calcRadius:7,propagModel:8,txLosses:9,rxLosses:10,noiseFigure:11,comment:12,tmaName:13,feederName:14,btsName:15,feederLengthDL:16,
                    feederLengthUL:17,missDll:18,missUll:19,calcRadius2:20,propagModel2:21,calcResolution:22,calcResolution2:23,redt:24,absX:25,absY:26,bfModel:27,ntxAntennas:28,
                    nrxAntennas:29,vzEnodebVendor:30,vzMissTxLossCom:31,vzMissRxLossCom:32,vzTmaJumperLoss:33,vzEpaInputJumLoss:34,vzSystNoiseTemp:35,vzTmaBenefitGain:36,
                    vzEpaModel:37,vzEpaManufacturer:38,vzTmaModel:39,vzTmaManufacturer:40,vztransmitterCode:41,vzfeederLossRx:42,vzFeederLossTx:43,vzRrhManufacturer:44,vzRrhModel:45,
                    vzTipHeight:46,vzCenterLine:47,vzRptrNoiseRiseLoss:48,vzTotalTilt:49,vzAntennaHBw:50,vzAntennaVBw:51,vzLteVendorPower:52,vz5gVendorPower:53,vzTotalBandwidth:54,
                    vzLteMaxPower:55,vz5gMaxPower:56,vzTotalErpW:57,vzTotalEirpW:58,vzRegulatoryPower:59,vzRegulatoryPowerNonPsd:60,vzMountPosition:61,vzMountFace:62,bfETilt:63,
                    vzSectorEquipmentFunctionId:64,vzAllowedMaxPowerCBR:65,vzMaxAllowedMaxPowerRFE:66,vzTxGroup:67,vzAllowedMaxPowerES:68,vzBfOpPortCount:69,vzElectricalAzimuth:70
                };
          data.filter(function (data) {
              for (const [key, value] of Object.entries(columnMap)) {
              if (rowNumbers[value]) {
                  Object.keys(rowNumbers[value]).filter(function (type) {
                      if ((data[key] == type)) {
                          obj = {};
                         obj['txId'] = data.txId;
                          filterData.push(obj);
                      }
                  })
              }
              }
          })
      } else {
            data.filter(function (data) {
                obj = {};
                obj['txId'] = data.txId;
                filterData.push(obj);
            })
        }

            const filterVal = {};
        rowNumbers.forEach((item,index) => {
        if(item){
        for (const [key,value] of Object.entries(columnMap)){
            if (value === index){
                let val = '';
                for (const [key,value] of Object.entries(item)){
                val  +=  key +',';   
                }
            val = val.slice(0, -1);
                filterVal[key] = val;
            }
        }	
        }
        });
        const flteredData =  data.filter(item => {
        return Object.entries(filterVal).every(([key, value]) => {
        const filterValues = value.split(',');
            return item[key] !== undefined && filterValues.includes(item[key].toString());
        });
        });
        onChangeTXFilter(flteredData);
    }
});

columnIndexs.fband = transmitterTableGrid.getColumnIdByName('fband');
columnIndexs.propagModel =  transmitterTableGrid.getColumnIdByName('propagModel');
columnIndexs.propagModel2 =  transmitterTableGrid.getColumnIdByName('propagModel2');
columnIndexs.bfModel =  transmitterTableGrid.getColumnIdByName('bfModel');
columnIndexs.nrxAntennas =  transmitterTableGrid.getColumnIdByName('nrxAntennas');
columnIndexs.ntxAntennas =  transmitterTableGrid.getColumnIdByName('ntxAntennas');
columnIndexs.vzEnodebVendor =  transmitterTableGrid.getColumnIdByName('vzEnodebVendor');
columnIndexs.vzRrhManufacturer =  transmitterTableGrid.getColumnIdByName('vzRrhManufacturer');
columnIndexs.vzRrhModel =  transmitterTableGrid.getColumnIdByName('vzRrhModel');
columnIndexs.vzLteVendorPower =  transmitterTableGrid.getColumnIdByName('vzLteVendorPower');
columnIndexs.vz5gVendorPower =  transmitterTableGrid.getColumnIdByName('vz5gVendorPower');
columnIndexs.vzMountPosition =  transmitterTableGrid.getColumnIdByName('vzMountPosition');
columnIndexs.vzMountFace =  transmitterTableGrid.getColumnIdByName('vzMountFace');
}	

// code to create 5G cells ,spare antenna and cells LTE grid starts here 
function buildSpareAntennaGrid(data) {
    $("#spareAntennaGrid").empty();
	 $("#spareAntennaGrid").removeClass("jtabs jexcel_container");
	 let totalRow = data && data.length>0 ? data.length: 1;
    spareAntennaGrid = jspreadsheet(document.getElementById('spareAntennaGrid'), {
        worksheets: [{
            data: data,
            columns: spareAntennaGridColumns,
            columnDrag: false,
            worksheetName: 'Spare Antenna',
            minDimensions: [10, 1],
            tableOverflow: true,
            tableWidth: '100%',
            tableHeight: '500px',
            editable: false,
            columnSorting: true,
            columnResize: true,
            tableOverflowResizable: true,
            editable: true,
            filters: true
        }],
        toolbar: true
    });
}

function buildCells5gnrGrid(data) {
    $("#cell5gnrGrid").empty();
	$("#cell5gnrGrid").removeClass("jtabs jexcel_container");
	let totalRows = data && data.length>0 ? data.length : 1;
//    cell5gnrGrid = jspreadsheet(document.getElementById('cell5gnrGrid'), {
//        worksheets: [{
//            data: data,
//            columnDrag: false,
//            worksheetName: '5G Cells',
//            minDimensions: [57, totalRows],
//            tableOverflow: true,
//            tableWidth: '100%',
//            tableHeight: '500px',
//            editable: false,
//            columnSorting: false,
//            editable: true,
//            columnResize: true,
//            tableOverflowResizable: true,
//            filters: true,
//            columns: Cells5GnrGridColumns
//                    }],
//        toolbar: true
//    });
	cell5gnrGrid = jspreadsheet(document
            .getElementById('cell5gnrGrid'), {
            data: data,
            columns: Cells5GnrGridColumns,
            columnDrag: false,
            worksheetName: '5G Cells',
            //minDimensions: [68, cellsLTEArray.length],
            tableOverflow: true,
            tableWidth: '100%',
            tableHeight: '250px',
            minDimensions: [10,1],
            editable: true,
            columnSorting: true,
            columnResize: true,
            tableOverflowResizable: true,
            filters: true,
        });
	
	 columnIndexs.vzCarrierLabel =  cell5gnrGrid.getColumnIdByName('vzCarrierLabel');
}

function buildCellLTEGrid(data) {

    $("#cellLTEGrid").empty();
	 $("#cellLTEGrid").removeClass("jtabs jexcel_container");
//	 let totalRow = data && data.length>0 ? data : 1;
//    cellLTEGrid = jspreadsheet(document.getElementById('cellLTEGrid'), {
//        worksheets: [{
//            data: data,
//            columnDrag: false,
//            worksheetName: 'Cells LTE',
//            minDimensions: [68, totalRow],
//            tableOverflow: true,
//            tableWidth: '100%',
//            tableHeight: '500px',
//            editable: false,
//            columnSorting: false,
//            columnResize: true,
//            editable: true,
//            tableOverflowResizable: true,
//            filters: true,
//            columns: cellLTEGridColumns
//        }],
//        toolbar: true
//    });
    
    cellLTEGrid = jspreadsheet(document
            .getElementById('cellLTEGrid'), {
            data: data,
            columns: cellLTEGridColumns,
            columnDrag: false,
            worksheetName: 'Cells LTE',
            //minDimensions: [68, cellsLTEArray.length],
            tableOverflow: true,
            tableWidth: '100%',
            tableHeight: '250px',
            minDimensions: [10,1],
            editable: true,
            columnSorting: true,
            columnResize: true,
            tableOverflowResizable: true,
            filters: true,
        });
    columnIndexs.pdcchSymbols =  cellLTEGrid.getColumnIdByName('pdcchSymbols');
    columnIndexs.vzCarrierLabelLte =  cellLTEGrid.getColumnIdByName('vzCarrierLabel');

}

function clearAtollSiteManagementInfo() {
    var data = [];
    clearCommonSearchDropdown()
    buildCells5gnrGrid(data);
    buildSpareAntennaGrid(data);
    buildCellLTEGrid(data);
    buildSitesGrid(data);
    buildTransmitterGrid(data);
}

function onChangeSiteVersionFilter(data,filterData){
    var trasmitterData = [];
    data.xgTransmitters.filter(function(data){
        filterData.filter(function(site){
            if(site.siteName == data.siteName){
                trasmitterData.push(data);
            }
        })
    })
    buildTransmitterGrid(trasmitterData);

    var lteCellsData = [];
    data.xgCellsLte.filter(function(data){
        trasmitterData.filter(function(transmitter){
            if(transmitter.txId == data.txId){
                lteCellsData.push(data);
            }
        })
    })
    buildCellLTEGrid(lteCellsData);

    var fiveGCellsData = [];
    data.xgCells5gnr.filter(function(data){
        trasmitterData.filter(function(transmitter){
            if(transmitter.txId == data.txId){
                fiveGCellsData.push(data);
            }
        })
    })
    buildCells5gnrGrid(fiveGCellsData);

    var spareAntennaData = [];
    data.spareAntennas.filter(function(data){
        filterData.filter(function(site){
            if(site.siteRecordId == data.siteRecordId){
                spareAntennaData.push(data);
            }
        })
    })
    buildSpareAntennaGrid(spareAntennaData);
}

function onChangeTXFilter(filterData){
    var lteCellsData = [];
    gridData.xgCellsLte.filter(function(data){
        filterData.filter(function(transmitter){
            if(transmitter.txId == data.txId){
                lteCellsData.push(data);
            }
        })
    })
    buildCellLTEGrid(lteCellsData);

    var fiveGCellsData = [];
    gridData.xgCells5gnr.filter(function(data){
        filterData.filter(function(transmitter){
            if(transmitter.txId == data.txId){
                fiveGCellsData.push(data);
            }
        })
    })
    buildCells5gnrGrid(fiveGCellsData);
}

function applyAll(){
    var siteRecordList = [];
    gridData.sites.filter(function (data) {
        var obj = {};
        obj.siteRecordId = data.vzSiteRecordId;
        siteRecordList.push(obj);
    })
    
    invalidEnodeBId = false;
    enb_tx_id ='';
    var validationStatus=false;
    var saveResponse ='';
	siteManagementModifiedDataList	= formSiteManagementModifiedDataList();
    if (dataModified){
        $.ajax({
            type: 'POST',
            url: saveSiteManagementInfoUrl,
            contentType: 'application/json; charset=UTF-8',
            cache: false,
            data: JSON.stringify(savePayload), 
            success: function (data) {
                $('#loading').hide();
                if(Object.keys(featureToggleMap).includes("F98384") && featureToggleMap['F98384']){
                    validationStatus=data.validationStatus;
                    if(validationStatus){
                        saveResponse = 'Site Management Info updated successfully!';
                        searchButtonIntegration();
                    } else{
                        saveResponse = data.comments;
                    }
                } else{
                    searchButtonIntegration();
                    validationStatus = true;
                    saveResponse = 'Site Management Info updated successfully!';
                }
            },
            error: function (data) {
                $('#loading').hide();
                saveResponse = 'Site Management Info failed to update';
            }
        });
    } else{
        validationStatus = true;
    }
    if((siteManagementModifiedDataList === null || $.isEmptyObject(siteManagementModifiedDataList)) && invalidEnodeBId)
	{
		aptAlert('error', 'cannot run applyAll cuz VZ_ENODEB_ID should not be in the range of 995000-999999 for TX_ID : ' + enb_tx_id);
		$('#loading').hide();
	}
	else{
     $('#loading').show();
     if(validationStatus){
         var payloadData = {
        "params": siteRecordList,
        "schema": commonSchemaSearchPayload.atollSchema,
        "vzId": VZID
    };

    // Add additional fields only if feature flag M6350 is enabled
    if(Object.keys(featureToggleMap).includes("M6350") && featureToggleMap['M6350']){
        payloadData.isFromUI = "Yes";
        payloadData.versions = commonSearchSelectedsiteversion;
        payloadData.siteName = commonSchemaSearchPayload.siteName;
    }
    $.ajax({
		type: 'POST',
        url: applyAllForSiteManagement,
	    // url: "http://localhost:8100/npp-atoll-services/vzapplyAll/applyAllForSiteManagement",
		contentType: 'application/json; charset=UTF-8',
		cache: false,
        data : JSON.stringify(payloadData),
		success: function (data) {
            var vzAppplyAllResult = [];
            keyValues = Object.keys(data);
            Object.keys(data).forEach(function(key) {
                vzAppplyAllResult.push(key+":"+data[key].result);
            })
            $('#loading').hide();
            const applyAllResp =
              data && data.VzApplyAll ? data.VzApplyAll : data;
            const warningMsg =
              applyAllResp && applyAllResp.warningMsg
                ? applyAllResp.warningMsg.trim()
                : "";

            if (warningMsg) {
              console.log("warningMsg", applyAllResp, warningMsg);
              aptAlert("warning", warningMsg);
              return;
            }
            
             if(Object.keys(featureToggleMap).includes("M6350") && featureToggleMap['M6350']){
                if(data && data.OPERATIONAL_PORT_ERROR){
                    saveResponse = data.OPERATIONAL_PORT_ERROR;
                    aptAlert("error", saveResponse)
                }else{
                    aptAlert('Success', saveResponse + '\r\n'+ vzAppplyAllResult.join(","));
                    searchButtonIntegration();
                }
            }else{
                aptAlert('Success', saveResponse + '\r\n'+ vzAppplyAllResult.join(","));
                searchButtonIntegration();
            }           
		},
		error: function (data) {
			$('#loading').hide();
			aptAlert('error', saveResponse +'\r\n'+ 'Apply All logs failed to update');
		}
	},(error) => {
        $('#loading').hide();
        aptAlert('error', saveResponse + '\r\n'+ 'Service Timed Out, Apply All logs failed to update');
    });
    }else{
    $('#loading').hide();
    aptAlert('error', saveResponse + '\r\n' + 'Apply All logs failed to update');
    }
}
}

function addToListInCarrierPopup(){
	
    var val = $('#carriersInAddCarrierPopup').val();
    var dl;
    $.each(carrierDLMapInSite, function(i, v){
        if(v.NAME == val){
            dl = v.DL_FREQUENCY
        }
    });
    $("#addCellFormInCarrierPopup").append('<div class="row cellRow carrierDataRow" style="margin: 2px 17x;padding-top: 6px;border: 1px solid #efefef;">'+
        '<div class="col-sm-5 carrierNameCarrier" style="padding-left: 2px;">'+
            '<label>' + $('#carriersInAddCarrierPopup').val() + '</label>'+
        '</div>'+
        '<div class="col-sm-5 dlCarrier" style="padding-left: 2px;">'+
            '<label>' + dl + '</label>'+
        '</div>'+
        '<div class="col-sm-2 labelInCarrier">'+
            '<select><option>F0</option><option>F1</option><option>F2</option><option>F3</option><option>F4</option><option>F5</option><option>F6</option><option>F7</option><option>F8</option><option>F9</option><option>F10</option><option>F11</option><option>F12</option><option>F13</option><option>F14</option><option>F15</option></select>'+
            '<i style="padding-left: 30px;cursor: pointer;" onclick="deleteOneCarrier(this)" class="fas fa-trash"></i>'+
        '</div>'+
    '</div>');
    
    validatecarrier();
}


function addCarriersInCarrierAdd(){
	carriers =[];
	  $('#addCellFormInCarrierPopup').find('.carrierDataRow').each(function( index ) {
          var obj = {};
          obj.band = $('#bandClassInAddCarrierPopup').val();
          obj.carrier = $(this).find('.carrierNameCarrier').find('label').text();
          obj.label = $(this).find('.labelInCarrier').find('select').val();
          carriers.push(obj);
      });
	console.log(carriers);
	
	let carrierPayload = {};
	
	carrierPayload.band = $('#bandClassInAddCarrierPopup').val(),
	carrierPayload.carriers = carriers;
	carrierPayload.market = commonSchemaSearchPayload.atollSchema,
	carrierPayload.siteInfoId = selectedSiteName;
	carrierPayload.siteName = commonSchemaSearchPayload.siteName,
	carrierPayload.sourceVersion =  $('#sourceVersionsInAddCarrierPopup').val(),
	carrierPayload.versions = $('#versionAppliedToInAddCarrierPopup').val()
	
	$.ajax({
		type: 'POST',
		url : carrierAddUrl,
		contentType: 'application/json; charset=UTF-8',
		cache: false,
		data : JSON.stringify(carrierPayload),
		success: function (data) {
			let oldData = data;
			for(var i = 0 ; i < data.xgTransmitters.length; i++){
				gridData.xgTransmitters.push(data.xgTransmitters[i]);
				oldGridData.xgTransmitters.push(JSON.parse(JSON.stringify(oldData.xgTransmitters[i])));
			}

			for(var i = 0 ; i < data.xgCellsLte.length; i++){
				gridData.xgCellsLte.push(data.xgCellsLte[i]);
				oldGridData.xgCellsLte.push(JSON.parse(JSON.stringify(oldData.xgCellsLte[i])));
			}
			
			for(var i = 0 ; i < data.xgCells5gnr.length; i++){
				gridData.xgCells5gnr.push(data.xgCells5gnr[i]);
				oldGridData.xgCells5gnr.push(JSON.parse(JSON.stringify(oldData.xgCells5gnr[i])));
			}
			
			buildTransmitterGrid(gridData.xgTransmitters);
			buildCellLTEGrid(gridData.xgCellsLte);
			buildCells5gnrGrid(gridData.xgCells5gnr);
			
			$('#loading').hide();
			aptAlert('Success', 'Site Management Info updated successfully!');
		},
		error: function (data) {
			$('#loading').hide();
			aptAlert('error', 'Site Management Info failed to update');
		}
	});
}

function openAddCarrierPopup(e){
	
	$('#addToListInCarrierPopup').attr('disabled', true);
	document.getElementById("addCarrierPopup").style.display = "block";
	$('#sourceVersionsInAddCarrierPopup').html('');
	$('#sourceVersionsInAddCarrierPopup').multiselect('destroy');
	$('#versionAppliedToInAddCarrierPopup').html('');
	$('#versionAppliedToInAddCarrierPopup').multiselect('destroy');
	var $par = $('#dlSpectrumWidthInAddCarrierPopup').parents(".col-sm-6");
	$('#dlSpectrumWidthInAddCarrierPopup').parents(".col-sm-6").empty();
	$par.append('<select class="form-control" style="width: 90%;" id="dlSpectrumWidthInAddCarrierPopup"></select>');

	var $par1 = $('#carriersInAddCarrierPopup').parents(".col-sm-6");
	$('#carriersInAddCarrierPopup').parents(".col-sm-6").empty();
	$par1.append('<select class="form-control" style="width: 90%;" id="carriersInAddCarrierPopup"></select>');
    $('#addCellFormInCarrierPopup').find('.carrierDataRow').remove();
	
	
	if(versionsSelected.length > 1){
		$('#sourceVersionsInAddCarrierPopup').append("<option>" + 'None Selected' + "</option>");
	}

	$.each(versionsSelected, function(i, v) {
		$('#sourceVersionsInAddCarrierPopup').append("<option>" + v + "</option>");
	});
	$('#sourceVersionsInAddCarrierPopup').val('', '');
	$('#sourceVersionsInAddCarrierPopup').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering : true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
		nonSelectedText: 'None selected'

	});

	$.each(versionsSelected, function(i, v) {
		$('#versionAppliedToInAddCarrierPopup').append("<option>" + v + "</option>");
	});
	$('#versionAppliedToInAddCarrierPopup').val('', '');
	$('#versionAppliedToInAddCarrierPopup').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering : true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
		nonSelectedText: 'None selected'
	});
	$('#siteNameInAddCarrierPopup').val(commonSchemaSearchPayload.siteName);

	var json = {}
	json.atollSchema = commonSchemaSearchPayload.atollSchema;
	var $par = $('#bandClassInAddCarrierPopup').parents(".col-sm-6");
	$('#bandClassInAddCarrierPopup').parents(".col-sm-6").empty();
	$par.append('<select class="form-control" style="width: 90%;" id="bandClassInAddCarrierPopup"></select>');
	$.ajax({
		url: '/uuigui/uui/eapp/atoll_pg/getBandClass',
		type: 'POST',
		contentType: 'application/json',
		data: JSON.stringify(json),
		success: function (data) {
			var bandClass = data && data.data? data.data : [];
			$('#bandClassInAddCarrierPopup').append("<option value=''>-</option>");
			$.each(bandClass, function(i, v){
				$('#bandClassInAddCarrierPopup').append("<option>" + v.FBAND + "</option>");
			});

			$('#bandClassInAddCarrierPopup').multiselect({
				includeSelectAllOption: true,
				enableFiltering:true,
				enableCaseInsensitiveFiltering: true,
				buttonClass: 'btn btn-default whitebg btn-sm',
				numberDisplayed: 1
			});
		}
	});
	$('#bandClassInAddCarrierPopup').change(function(e){
		var val = $(this).val().toString();
		var $par = $('#dlSpectrumWidthInAddCarrierPopup').parents(".col-sm-6");
		$('#dlSpectrumWidthInAddCarrierPopup').parents(".col-sm-6").empty();
		$par.append('<select class="form-control" style="width: 90%;" id="dlSpectrumWidthInAddCarrierPopup"></select>');

		var $par1 = $('#carriersInAddCarrierPopup').parents(".col-sm-6");
		$('#carriersInAddCarrierPopup').parents(".col-sm-6").empty();
		$par1.append('<select class="form-control" style="width: 90%;" id="carriersInAddCarrierPopup"></select>');
		$('#carriersInAddCarrierPopup').append("<option value=''>-</option>");
		$('#carriersInAddCarrierPopup').multiselect({
			includeSelectAllOption: true,
			enableFiltering:true,
			enableCaseInsensitiveFiltering: true,
			buttonClass: 'btn btn-default whitebg btn-sm',
			numberDisplayed: 1
		});
		$('#addToListInCarrierPopup').attr('disabled', true);
		if(val == ""){
			$('#dlSpectrumWidthInAddCarrierPopup').append("<option value=''>-</option>");
			$('#dlSpectrumWidthInAddCarrierPopup').multiselect({
				includeSelectAllOption: true,
				enableFiltering:true,
				enableCaseInsensitiveFiltering: true,
				buttonClass: 'btn btn-default whitebg btn-sm',
				numberDisplayed: 1
			});
			return;
		}
		var json = {}
		json.atollSchema = commonSchemaSearchPayload.atollSchema;
		json.band = val;
		$.ajax({
			url: '/uuigui/uui/eapp/atoll_pg/getDlWidth',
			type: 'POST',
			contentType: 'application/json',
			data: JSON.stringify(json),
			success: function (data) {
				var carriers = data && data.data? data.data : [];
				$('#dlSpectrumWidthInAddCarrierPopup').append("<option value=''>-</option>");
				$.each(carriers, function(i, v){
					$('#dlSpectrumWidthInAddCarrierPopup').append("<option>" + v.DL_WIDTH + "</option>");
				})    
				$('#dlSpectrumWidthInAddCarrierPopup').multiselect({
					includeSelectAllOption: true,
					enableFiltering:true,
					enableCaseInsensitiveFiltering: true,
					buttonClass: 'btn btn-default whitebg btn-sm',
					numberDisplayed: 1
				});
			}
		});



		$('#dlSpectrumWidthInAddCarrierPopup').change(function(e){
			var val = $(this).val().toString();
			var $par = $('#carriersInAddCarrierPopup').parents(".col-sm-6");
			$('#carriersInAddCarrierPopup').parents(".col-sm-6").empty();
			$par.append('<select class="form-control" style="width: 90%;" id="carriersInAddCarrierPopup"></select>');
			var $par1 = $('#stationTemplateInAddCarrierPopup').parents(".col-sm-6");
			$('#stationTemplateInAddCarrierPopup').parents(".col-sm-6").empty();
			$par1.append('<select class="form-control" style="width: 90%;" id="stationTemplateInAddCarrierPopup"></select>');
			$('#addToListInCarrierPopup').attr('disabled', true);
			if(val == ""){
				$('#carriersInAddCarrierPopup').append("<option value=''>-</option>");
				$('#carriersInAddCarrierPopup').multiselect({
					includeSelectAllOption: true,
					enableFiltering:true,
					enableCaseInsensitiveFiltering: true,
					buttonClass: 'btn btn-default whitebg btn-sm',
					numberDisplayed: 1
				});

				return;
			}
			var json = {}
			json.atollSchema = commonSchemaSearchPayload.atollSchema;
			json.band = $('#bandClassInAddCarrierPopup').val().toString();
			json.dlWidth = val;

			$.ajax({
				url: '/uuigui/uui/eapp/atoll_pg/getCarrierDetails',
				type: 'POST',
				contentType: 'application/json',
				data: JSON.stringify(json),
				success: function (data) {
					var $par = $('#carriersInAddCarrierPopup').parents(".col-sm-6");
					$('#carriersInAddCarrierPopup').parents(".col-sm-6").empty();
					$par.append('<select class="form-control" style="width: 90%;" id="carriersInAddCarrierPopup"></select>');
					var carriers = data && data.data? data.data : [];
					carrierDLMapInSite = data.data;
					$('#carriersInAddCarrierPopup').append("<option value=''>-</option>");
					$.each(carriers, function(i, v){
						$('#carriersInAddCarrierPopup').append("<option>" + v.NAME + "</option>");
					})    
					$('#carriersInAddCarrierPopup').multiselect({
						includeSelectAllOption: true,
						enableFiltering:true,
						enableCaseInsensitiveFiltering: true,
						buttonClass: 'btn btn-default whitebg btn-sm',
						numberDisplayed: 1
					});




					$('#carriersInAddCarrierPopup').change(function(e){
						if($('#carriersInAddCarrierPopup').val() == ""){
							$('#addToListInCarrierPopup').attr('disabled', true);
						}else{
							$('#addToListInCarrierPopup').attr('disabled', false);
						}
					});
				},
				error: function (err) {}
			});



		});
	});

	$("#txGridInCarrierPopup").kendoGrid({
		autoBind: true,
		// height: 60,
		sortable: true,
		pageable: {
			pageSizes: [10, 25, 50, 100, 150, 200, 500],
			input: true,
			numeric: false,
			messages :{}
		},
		columns: [
			{
				"title": "TX ID",
				"field": "txId",
				filterable: {
					cell: {
						operator: "contains",
						suggestionOperator: "contains"
					}
				},
				width: "300px"
			},
			{
				"title": "FBAND",
				"field": "fband",
				filterable: {
					cell: {
						operator: "contains",
						suggestionOperator: "contains"
					}
				},
				width: "100px"
			},
			{
				"title": "ANTENNA NAME",
				"field": "antennaName",
				filterable: {
					cell: {
						operator: "contains",
						suggestionOperator: "contains"
					}
				},
				width: "300px"
			},
			{
				"title": "Height",
				"field": "height",
				filterable: {
					cell: {
						operator: "contains",
						suggestionOperator: "contains"
					}
				},
				width: "150px"
			},
			{
				"title": "Azimuth",
				"field": "azimut",
				filterable: {
					cell: {
						operator: "contains",
						suggestionOperator: "contains"
					}
				},
				width: "100px"
			},
			{
				"title": "Tilt",
				"field": "tilt",
				filterable: {
					cell: {
						operator: "contains",
						suggestionOperator: "contains"
					}
				},
				width: "100px"
			},
			{
				"title": "Sector",
				"field": "vzSector",
				filterable: {
					cell: {
						operator: "contains",
						suggestionOperator: "contains"
					}
				},
				width: "100px"
			}
			],
			dataSource: {
				data: gridData.xgTransmitters,
				schema: {
					model: {
					}
				},
				pageSize: 5
			},
			filterable: {
				operators: {},
				extra: false
			},
			filter: function (e) {
			},
			columnMenu: {
				columns: false
			},
			reorderable: true,
			resizable: true
	});
}

function validatecarrier(){
	if ($('#addCellFormInCarrierPopup').find('.carrierDataRow').length != 0) {
		$('#addCarrierSubmitBtn').attr("disabled",false);
  }else{
		$('#addCarrierSubmitBtn').attr("disabled",true);		
	}
}

function closeAddCarrierPopup(){
  $('#addCarrierPopup').hide();

  $('#alertMask').hide();
}

function deleteOneCarrier(e){
  $(e).parents('.cellRow').remove();
  validatecarrier(); 
}

function openSectorAddPopUp(){
    $('#sectorCarrierSubmitBtn').attr('disabled', true);
	
	$('#versionInSectorAddPopUp').html('');
	$('#versionInSectorAddPopUp').multiselect('destroy');
	$('#existingFaceInSectorAdd').html('');
	$('#existingFaceInSectorAdd').multiselect('destroy');
	$('#newFaceInSectorAdd').html('');
	$('#newFaceInSectorAdd').multiselect('destroy');
	document.getElementById("Azimut").value = '';
	document.getElementById("newVersionTextField").value = '';
	document.getElementById("newVersionCheckbox").checked = false;
	document.getElementById("newVersionTextField").style.backgroundcolor = "lightgrey";
	document.getElementById("sectorAddPopUp").style.display = "block";
	//	$('#versionInSectorAddPopUp').append("<option value='None Selected'>None Selected</option>");
	$.each(versionsSelected, function(i, v) {
		$('#versionInSectorAddPopUp').append("<option>" + v + "</option>");
	});
	$('#versionInSectorAddPopUp').val('', '');
	$('#versionInSectorAddPopUp').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering : true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
		nonSelectedText: 'None selected'
	});
	
	$('#existingFaceInSectorAdd').append("<option value='None Selected'>None Selected</option>");
	var fetchMountValues = mountFaceVal;
	for (var i = 0; i < fetchMountValues.length; i++) {
		if (fetchMountValues[i] == "") {
			fetchMountValues.splice(i, 1);
			
		}
	}
	$.each(fetchMountValues, function (i, v) {
		$('#existingFaceInSectorAdd').append("<option>" + v + "</option>");
	});
	//$('#existingFaceInSectorAdd').val('', '');
	$('#existingFaceInSectorAdd').multiselect({
		includeSelectAllOption: true,
		enableFiltering:true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1
	});
	

	$('#newFaceInSectorAdd').append("<option value='None Selected'>None Selected</option>");
	$('#newFaceInSectorAdd').multiselect({
		includeSelectAllOption: true,
		enableFiltering:true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1
	});
	

}

$('#versionInSectorAddPopUp').change(function(e){
    if(!$('#versionInSectorAddPopUp').val()){
        $('#sectorCarrierSubmitBtn').attr('disabled', true);
    }else{
        $('#sectorCarrierSubmitBtn').attr('disabled', false);
    }
});

$('#existingFaceInSectorAdd').change(function(e){
	$('#newFaceInSectorAdd').html('');
	$('#newFaceInSectorAdd').multiselect('destroy');
	let existingFaceVal = $('#existingFaceInSectorAdd').val();
	let fetchValues = mountFaceVal;
	for(var i = 0; i < fetchValues.length; i++){
		if(fetchValues[i] == existingFaceVal){
			fetchValues.splice(i,1);
		}
		
	}
	
	$('#newFaceInSectorAdd').append("<option value='None Selected'>None Selected</option>");
	$.each(fetchValues, function(i, v) {
		$('#newFaceInSectorAdd').append("<option>" + v + "</option>");
	});
	$('#newFaceInSectorAdd').multiselect({
		includeSelectAllOption: true,
		enableFiltering:true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1
	});
	fetchValues.push(existingFaceVal);
	fetchValues.sort();
});
function closeSectorAddPopup(){
	//document.getElementById("sectorAddPopUp").style.display = "block";
	$('#sectorAddPopUp').hide();
}


function sectorAddIntegration(){
	$('#loading').show();
	let siteDataObj = gridData.sites.find(item=>item.vzSiteVersion==$('#versionInSectorAddPopUp').val() && item.vzSiteName == commonSchemaSearchPayload.siteName);
	var payload = {
			user: VZID,
			mountFace : $('#existingFaceInSectorAdd').val(),
			azimut : $('#Azimut').val(),
			market : commonSchemaSearchPayload.atollSchema,
			siteName : commonSchemaSearchPayload.siteName,
			flag : "true",
			message : null,
			newMountFace : $('#newFaceInSectorAdd').val(),
			siteVersion : $('#newVersionTextField').val(),
			copySiteEnabled : document.getElementById("newVersionCheckbox").checked,
			siteRecordId : siteDataObj.vzSiteRecordId,
		}
	
	$.ajax({
		type: 'POST',
		//url : "http://localhost:8100/npp-atoll-services/siteManagement/sectorAdd",
		url : sectorAddUrl,
		contentType: 'application/json; charset=UTF-8',
		cache: false,
		data : JSON.stringify(payload),
		success: function (data) {
			let oldData = data;
			if(data.xgTransmitters != null && data.xgTransmitters.length > 0){
				for(var i = 0 ; i < data.xgTransmitters.length; i++){
					gridData.xgTransmitters.push(data.xgTransmitters[i]);
					oldGridData.xgTransmitters.push(JSON.parse(JSON.stringify(oldData.xgTransmitters[i])));
				}	
			}
			if(data.xgCellsLte != null && data.xgCellsLte.length > 0){
				for(var i = 0 ; i < data.xgCellsLte.length; i++){
					gridData.xgCellsLte.push(data.xgCellsLte[i]);
					oldGridData.xgCellsLte.push(JSON.parse(JSON.stringify(oldData.xgCellsLte[i])));
				}
			}
			if(data.xgCells5gnr != null && data.xgCells5gnr.length > 0){
				for(var i = 0 ; i < data.xgCells5gnr.length; i++){
					gridData.xgCells5gnr.push(data.xgCells5gnr[i]);
					oldGridData.xgCells5gnr.push(JSON.parse(JSON.stringify(oldData.xgCells5gnr[i])));
				}
			}
			buildTransmitterGrid(gridData.xgTransmitters);
			buildCellLTEGrid(gridData.xgCellsLte);
			buildCells5gnrGrid(gridData.xgCells5gnr);

			$('#sectorAddPopUp').hide();
			
			$('#loading').hide();
			if(document.getElementById("newVersionCheckbox").checked){
				aptAlert('Success',"New Version created succesfully");
			}else{
                if (
                  data.warningMsg &&
                  Object.keys(featureToggleMap).includes("F3341-186") &&
                  featureToggleMap["F3341-186"]
                ) {
                    aptAlert(
                      "Success",
                      "Sector Info added Succesfully!",
                      "Warning",
                      data.warningMsg
                    );    
                } else {
                    aptAlert('Success', 'Sector Info added Succesfully!');
                }
}
		},
		error: function (data) {
			$('#loading').hide();
			aptAlert('error', 'Sector Info failed to update');
		}
	});
	
}
function azimutLimt(input){
	var azimutVal = parseInt(input.value);

	if(azimutVal) {
        if (azimutVal > 360 || azimutVal < 0) {
            alert("Azimut Value should be between 0 and 360");
            $('#sectorCarrierSubmitBtn').attr('disabled', true);
        } else {
            $('#sectorCarrierSubmitBtn').attr('disabled', false);
        }
    } else {
        $('#sectorCarrierSubmitBtn').disabled = true;
    }
}
function newVersionTextBox() {
	var newVersionChecked = document.getElementById("newVersionCheckbox").checked;
	if(newVersionChecked) {
		document.getElementById("newVersionTextField").disabled = false;
document.getElementById("newVersionTextField").style.backgroundColor = "white";
	} else {
		document.getElementById("newVersionTextField").disabled = true;
	}
}


function openAddCellPopup() {
    $('#addToListInCellPopup').attr('disabled', true);
    $('#addCellSubmitBtn').attr("disabled", true);
    $('#siteNameInAddCellPopup').html('').multiselect('destroy');
    $('#txNameInAddCellPopup').html('').multiselect('destroy');
    if ($("#cellGridInCellPopup").data("kendoGrid") != undefined) {
        $("#cellGridInCellPopup").data("kendoGrid").destroy();
        $('#cellGridInCellPopup').empty();
    }

    $('#txNameInAddCellPopup').multiselect({
        includeSelectAllOption: true,
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        buttonClass: 'btn btn-default whitebg btn-sm',
        numberDisplayed: 1,
        nonSelectedText: 'None selected'
    });

    var $par = $('#bandClassInAddCellPopup').parents(".col-sm-6");
    $('#bandClassInAddCellPopup').parents(".col-sm-6").empty();
    $par.append('<select class="form-control" style="width: 100%;" id="bandClassInAddCellPopup"></select>');
    $('#bandClassInAddCellPopup').append("<option value=''>-</option>");

    var $par = $('#dlSpectrumWidthInAddCellPopup').parents(".col-sm-6");
    $('#dlSpectrumWidthInAddCellPopup').parents(".col-sm-6").empty();
    $par.append('<select class="form-control" style="width: 100%;" id="dlSpectrumWidthInAddCellPopup"></select>');
    $('#dlSpectrumWidthInAddCellPopup').append("<option value=''>-</option>");

    var $par1 = $('#carriersInAddCellPopup').parents(".col-sm-6");
    $('#carriersInAddCellPopup').parents(".col-sm-6").empty();
    $par1.append('<select class="form-control" style="width: 100%;" id="carriersInAddCellPopup"></select>');
    $('#carriersInAddCellPopup').append("<option value=''>-</option>");

    var versions = commonSearchSelectedsiteversion;
    var siteName = [];
    for (const element of versions) {
        gridData.sites.filter(function (data) {
            if (data.vzSiteVersion == element) {
                siteName.push(data.name);
                $('#siteNameInAddCellPopup').append("<option>" + data.name + "</option>");
            }
        })
    }
    $('#siteNameInAddCellPopup').multiselect({
        includeSelectAllOption: true,
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        buttonClass: 'btn btn-default whitebg btn-sm',
        numberDisplayed: 1,
        nonSelectedText: 'None selected'
    });
    $('#siteNameInAddCellPopup').change(function (e) {
        $('#txNameInAddCellPopup').html('').multiselect('destroy');
        var selectedSiteName = $('#siteNameInAddCellPopup').val() ? $('#siteNameInAddCellPopup').val() : [];
        var txData = [];
        for (const element of selectedSiteName) {
            gridData.xgTransmitters.filter(function (data) {
                if (element == data.siteName) {
                    txData.push(data);
                    $('#txNameInAddCellPopup').append("<option>" + data.txId + "</option>");
                }
            })
        }
        $('#txNameInAddCellPopup').multiselect({
            includeSelectAllOption: true,
            enableFiltering: true,
            enableCaseInsensitiveFiltering: true,
            buttonClass: 'btn btn-default whitebg btn-sm',
            numberDisplayed: 1,
            nonSelectedText: 'None selected'
        });
    })
    var json = {}
    json.atollSchema = commonSchemaSearchPayload.atollSchema;
    $("#addCellFormInCellPopup").empty();
    $("#addCellFormInCellPopup").append('<div class="row cellRow" style="margin: 2px 17x;padding-top: 6px;border: 1px solid #efefef;">' +
        '<div class="col-sm-5" style="padding-left: 2px;">' +
        '<label>Carrier Name</label>' +
        '</div>' +
        '<div class="col-sm-5" style="padding-left: 2px;">' +
        '<label>DL Frequency</label>' +
        '</div>' +
        '<div class="col-sm-2" style="padding-left: 2px;">' +
        '<label>Carrier Label</label>' +
        '</div>' +
        '</div>');

    addCellTxNameChange();

    $('#addCellPopup').show();
    $('#alertMask').show();
}

function closeAddCellPopup() {
    $('#addCellPopup').hide();
    $('#alertMask').hide();
}

function addCellTxNameChange() {
    $('#txNameInAddCellPopup').change(function (e) {
        var cellData = [], bandClass = [];
        var txName = $('#txNameInAddCellPopup').val() ? $('#txNameInAddCellPopup').val() : [];
        for (const element of txName) {
            gridData.xgTransmitters.filter(function (data) {
                if (element == data.txId) {
                    bandClass.push(data.fband);
                }
            })
            bandClass = [...new Set(bandClass)];
            gridData.xgCellsLte.filter(function (data) {
                if (element == data.txId) {
                    var obj = {};
                    obj.TXID = data.txId;
                    obj.TECHNOLOGY = "LTE";
                    obj.CELL_ID = data.vzCellId;
                    obj.CARRIER = data.vzCarrierId;
                    cellData.push(obj);
                }
            })
            gridData.xgCells5gnr.filter(function (data) {
                if (element == data.txId) {
                    var obj = {};
                    obj.TXID = data.txId;
                    obj.TECHNOLOGY = "5GNR";
                    obj.CELL_ID = data.vzCellId;
                    obj.CARRIER = data.vzCarrierId;
                    cellData.push(obj);
                }
            })
        }
        var $par = $('#bandClassInAddCellPopup').parents(".col-sm-6");
        $('#bandClassInAddCellPopup').parents(".col-sm-6").empty();
        $par.append('<select class="form-control" style="width: 90%;" id="bandClassInAddCellPopup"></select>');
        $('#bandClassInAddCellPopup').append("<option value=''>-</option>");

        $.each(bandClass, function (i, v) {
            $('#bandClassInAddCellPopup').append("<option>" + v + "</option>");
        })
        $('#bandClassInAddCellPopup').multiselect({
            includeSelectAllOption: true,
            enableFiltering: true,
            enableCaseInsensitiveFiltering: true,
            buttonClass: 'btn btn-default whitebg btn-sm',
            numberDisplayed: 1
        });

        addcellBandClassChange();

        var $par = $('#dlSpectrumWidthInAddCellPopup').parents(".col-sm-6");
        $('#dlSpectrumWidthInAddCellPopup').parents(".col-sm-6").empty();
        $par.append('<select class="form-control" style="width: 100%;" id="dlSpectrumWidthInAddCellPopup"></select>');
        $('#dlSpectrumWidthInAddCellPopup').append("<option value=''>-</option>");

        var $par1 = $('#carriersInAddCellPopup').parents(".col-sm-6");
        $('#carriersInAddCellPopup').parents(".col-sm-6").empty();
        $par1.append('<select class="form-control" style="width: 100%;" id="carriersInAddCellPopup"></select>');
        $('#carriersInAddCellPopup').append("<option value=''>-</option>");

        $("#cellGridInCellPopup").kendoGrid({
            autoBind: true,
            height: "40%",
            sortable: true,
            pageable: {
                pageSizes: [10, 25, 50, 100, 150, 200, 500]
            },
            columns: [
                {
                    "title": "TXID",
                    "field": "TXID",
                    filterable: {
                        cell: {
                            operator: "contains",
                            suggestionOperator: "contains"
                        }
                    }
                },
                {
                    "title": "TECHNOLOGY",
                    "field": "TECHNOLOGY",
                    filterable: {
                        cell: {
                            operator: "contains",
                            suggestionOperator: "contains"
                        }
                    }
                },
                {
                    "title": "CELL ID",
                    "field": "CELL_ID",
                    filterable: {
                        cell: {
                            operator: "contains",
                            suggestionOperator: "contains"
                        }
                    }
                },
                {
                    "title": "CARRIER",
                    "field": "CARRIER",
                    filterable: {
                        cell: {
                            operator: "contains",
                            suggestionOperator: "contains"
                        }
                    }
                }
            ],
            dataSource: {
                data: cellData,
                schema: {
                    model: {
                    }
                },
                pageSize: 5
            },
            reorderable: true,
            resizable: true
        });
    })
}
function addcellBandClassChange() {
    $('#bandClassInAddCellPopup').change(function (e) {
        var $par = $('#carriersInAddCellPopup').parents(".col-sm-6");
        $('#carriersInAddCellPopup').parents(".col-sm-6").empty();
        $par.append('<select class="form-control" style="width: 100%;" id="carriersInAddCellPopup"></select>');
        $('#carriersInAddCellPopup').append("<option value=''>-</option>");

        var $par1 = $('#dlSpectrumWidthInAddCellPopup').parents(".col-sm-6");
        $('#dlSpectrumWidthInAddCellPopup').parents(".col-sm-6").empty();
        $par1.append('<select class="form-control" style="width: 100%;" id="dlSpectrumWidthInAddCellPopup"></select>');

        $('#addToListInCellPopup').attr('disabled', true);
        var val = $(this).val().toString();
        if (val == "") {
            $('#dlSpectrumWidthInAddCellPopup').append("<option value=''>-</option>");
            return;
        }
        var json = {}
        json.atollSchema = commonSchemaSearchPayload.atollSchema;
        json.band = val;
        $.ajax({
            url: '/uuigui/uui/eapp/atoll_pg/getDlWidth',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(json),
            success: function (data) {
                var carriers = data.data;
                $('#dlSpectrumWidthInAddCellPopup').append("<option value=''>-</option>");
                $.each(carriers, function (i, v) {
                    $('#dlSpectrumWidthInAddCellPopup').append("<option>" + v.DL_WIDTH + "</option>");
                })
                $('#dlSpectrumWidthInAddCellPopup').multiselect({
                    includeSelectAllOption: true,
                    enableFiltering: true,
                    enableCaseInsensitiveFiltering: true,
                    buttonClass: 'btn btn-default whitebg btn-sm',
                    numberDisplayed: 1
                });

                $('#dlSpectrumWidthInAddCellPopup').change(function (e) {
                    var val = $(this).val().toString();
                    var $par = $('#carriersInAddCellPopup').parents(".col-sm-6");
                    $('#carriersInAddCellPopup').parents(".col-sm-6").empty();
                    $par.append('<select class="form-control" style="width: 100%;" id="carriersInAddCellPopup"></select>');
                    $('#addToListInCellPopup').attr('disabled', true);
                    if (val == "") {
                        $('#carriersInAddCellPopup').append("<option value=''>-</option>");
                        return;
                    }
                    var json = {}
                    json.atollSchema = commonSchemaSearchPayload.atollSchema;
                    json.band = $('#bandClassInAddCellPopup').val().toString();
                    json.dlWidth = val;
                    $.ajax({
                        url: '/uuigui/uui/eapp/atoll_pg/getCarrierDetails',
                        type: 'POST',
                        contentType: 'application/json',
                        data: JSON.stringify(json),
                        success: function (data) {
                            var carriers = data.data;
                            carrierDLMapInCell = data.data;
                            $('#carriersInAddCellPopup').append("<option value=''>-</option>");
                            $.each(carriers, function (i, v) {
                                $('#carriersInAddCellPopup').append("<option>" + v.NAME + "</option>");
                            })
                            $('#carriersInAddCellPopup').multiselect({
                                includeSelectAllOption: true,
                                enableFiltering: true,
                                enableCaseInsensitiveFiltering: true,
                                buttonClass: 'btn btn-default whitebg btn-sm',
                                numberDisplayed: 1
                            });
                            $('#carriersInAddCellPopup').change(function (e) {
                                if ($('#carriersInAddCellPopup').val() == "") {
                                    $('#addToListInCellPopup').attr('disabled', true);
                                } else {
                                    $('#addToListInCellPopup').attr('disabled', false);
                                }
                            });
                        },
                        error: function (err) { }
                    });
                });
            },
            error: function (err) { }
        });
    });
}

$("#addToListInCellPopup").click(function (e) {
    var val = $('#carriersInAddCellPopup').val();
    var dl;
    $.each(carrierDLMapInCell, function (i, v) {
        if (v.NAME == val) {
            dl = v.DL_FREQUENCY
        }
    });
    $("#addCellFormInCellPopup").append('<div class="row cellRow cellDataRow" style="margin: 2px 17x;padding-top: 6px;border: 1px solid #efefef;">' +
        '<div class="col-sm-5 carrierNameCarrier" style="padding-left: 2px;">' +
        '<label>' + $('#carriersInAddCellPopup').val() + '</label>' +
        '</div>' +
        '<div class="col-sm-5 dlCarrier" style="padding-left: 2px;">' +
        '<label>' + dl + '</label>' +
        '</div>' +
        '<div class="col-sm-5 bandClass" style="padding-left: 2px; display: none">' +
        '<label>' + $('#bandClassInAddCellPopup').val() + '</label>' +
        '</div>' +
        '<div class="col-sm-5 dlWidth" style="padding-left: 2px; display: none">' +
        '<label>' + $('#dlSpectrumWidthInAddCellPopup').val() + '</label>' +
        '</div>' +
        '<div class="col-sm-2 labelInCarrier">' +
        '<select><option>F0</option><option>F1</option><option>F2</option><option>F3</option><option>F4</option><option>F5</option><option>F6</option><option>F7</option><option>F8</option><option>F9</option><option>F10</option><option>F11</option><option>F12</option><option>F13</option><option>F14</option><option>F15</option></select>' +
        '<i style="padding-left: 30px;cursor: pointer;" onclick="deleteOneCell(this)" class="fas fa-trash"></i>' +
        '</div>' +
        '</div>');
    validatecells();
});

function validatecells() {
    if ($('#addCellFormInCellPopup').find('.cellDataRow').length == 0) {
        $('#addCellSubmitBtn').attr("disabled", true);
    } else {
        $('#addCellSubmitBtn').attr("disabled", false);
    }
}

function deleteOneCell(e) {
    $(e).parents('.cellRow').remove();
    validatecells();
}

$('#addCellSubmitBtn').click(function (e) {
    var json = {}
    var sitesList = [];
    var selectedSiteNames = $('#siteNameInAddCellPopup').val();
    var selectedTxNames = $('#txNameInAddCellPopup').val();
    for (const element of selectedSiteNames) {
        var siteObj = {};
        siteObj.transmitters = [];
         var txList = [];
        for (const txname of selectedTxNames) {
           
            var txObj = {};
            gridData.xgTransmitters.filter(function (txData) {
                if (element == txData.siteName && txname == txData.txId) {
                    var cellsObj = [];
                    txObj.txid = txname;
                    $(".cellDataRow").each(function (index) {
                        if ($(this).find('.bandClass').find('label').text() == txData.fband) {
                            var obj = {};
                            obj.carrier = $(this).find('.carrierNameCarrier').find('label').text();
                            obj.label = $(this).find('.labelInCarrier').find('select').val();
                            obj.bandWidth = $(this).find('.dlWidth').find('label').text();
                            obj.band = $(this).find('.bandClass').find('label').text();
                            cellsObj.push(obj);
                        }
                    });
                    if (cellsObj.length > 0) {
                        txObj.carriers = cellsObj;
                        txList.push(txObj);
                    }
                }
            })
            if (txList.length > 0) {
                siteObj.transmitters = txList;
            }
        }
        if (siteObj.transmitters.length > 0) {
            gridData.sites.filter(function (siteData) {
                if (element == siteData.name) {
                    siteObj.siteName = element;
                }
            })
            sitesList.push(siteObj);
        }

    }
    json.market = commonSchemaSearchPayload.atollSchema;
    json.sites = sitesList;
    $('#loading').show();
    $.ajax({
        url: cellAddUrl,
        //url: 'http://localhost:8100/npp-atoll-services/siteManagement/cellAdd',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(json),
        success: function (data) {
            $('#loading').hide();
            if (data.xgCellsLte.length > 0 || data.xgCells5gnr.length > 0) {
                if (data.xgCellsLte.length > 0) {
                    for (var i = 0; i < data.xgCellsLte.length; i++) {
                        oldGridData.xgCellsLte.push(data.xgCellsLte[i]);
                        oldGridData = JSON.parse(JSON.stringify(oldGridData))
                        gridData.xgCellsLte.push(data.xgCellsLte[i]);
                    }
                }
                if (data.xgCells5gnr.length > 0) {
                    for (var i = 0; i < data.xgCells5gnr.length; i++) {
                        oldGridData.xgCells5gnr.push(data.xgCells5gnr[i]);
                        oldGridData = JSON.parse(JSON.stringify(oldGridData))
                        gridData.xgCells5gnr.push(data.xgCells5gnr[i]);
                    }
                }

                buildCells5gnrGrid(gridData.xgCells5gnr);
                buildCellLTEGrid(gridData.xgCellsLte);
                closeAddCellPopup();
                aptAlert('Success', 'Cells Added Successfully!')
            } else {
                aptAlert('error', 'Failed to Add Cells!')
            }
        },
        error: function (err) {
            $('#loading').hide();
            aptAlert('error', 'Failed to Add Cells');
        }
    });
})
