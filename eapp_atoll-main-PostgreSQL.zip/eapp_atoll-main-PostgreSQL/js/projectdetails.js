let currentMainTableData = [];

/**
 * Shows the modal with a given message.
 * The modal now uses the 'show' class for visibility and transition.
 * @param {string} message - The message to display in the modal.
 */
function showModal(message) {
    $('#modalMessage').html(message);
    // Add the 'show' class to trigger the new modal's display and transitions
    $('#myModal').addClass('show');
}

/**
 * Hides the modal.
 * The modal now uses the 'show' class for visibility and transition.
 */
function hideModal() {
    // Remove the 'show' class to hide the modal
    $('#myModal').removeClass('show');
}

/**
 * Shows a confirmation dialog with Approve/Cancel buttons using consistent Approve button design.
 * @param {string} message - The confirmation message to display.
 * @param {function} onConfirm - Callback function to execute if user clicks Approve.
 */
function showConfirmationDialog(message, onConfirm) {
    // Create a confirmation dialog structure with the same styling as approve buttons
    const confirmDialog = `
        <div style="text-align: center;">
            <p style="font-size: 16px; margin-bottom: 25px; font-weight: 600; color: #333;">${message}</p>
            <div style="display: flex; gap: 15px; justify-content: center; align-items: center;">
                <button id="confirmYesBtn" class="approve-btn" style="display: inline-flex; align-items: center; justify-content: center; border-radius: 3px; font-size: 14px; font-weight: 900; font-family: nhg-display-bold, Arial, sans-serif; letter-spacing: .025em; text-align: center; color: white; background-color: #CD040B; border: none; padding: 8px 25px; cursor: pointer; transition: all 0.15s ease-in-out;">Approve</button>
                <button id="confirmNoBtn" class="cancel-btn" style="display: inline-flex; align-items: center; justify-content: center; border-radius: 3px; font-size: 14px; font-weight: 600; font-family: Arial, sans-serif; letter-spacing: .025em; text-align: center; color: #333; background-color: #f0f0f0; border: 1px solid #ddd; padding: 8px 25px; cursor: pointer; transition: all 0.15s ease-in-out;">Cancel</button>
            </div>
        </div>
    `;
    
    showModal(confirmDialog);
    
    // Handle Approve button click
    $('#confirmYesBtn').off('click').on('click', () => {
        hideModal();
        onConfirm();
    });
    
    // Handle hover effects for Approve button
    $('#confirmYesBtn').on('mouseenter', function() {
        $(this).css('background-color', '#A80309');
    }).on('mouseleave', function() {
        $(this).css('background-color', '#CD040B');
    });
    
    // Handle Cancel button click
    $('#confirmNoBtn').off('click').on('click', () => {
        hideModal();
    });
    
    // Handle hover effects for Cancel button
    $('#confirmNoBtn').on('mouseenter', function() {
        $(this).css('background-color', '#e0e0e0');
    }).on('mouseleave', function() {
        $(this).css('background-color', '#f0f0f0');
    });
}

function getNestedValue(obj, path) {
    const parts = path.split('::');
    let current = obj;
    for (let i = 0; i < parts.length; i++) {
        const part = parts[i];
        if (current === undefined || current === null) {
            return undefined;
        }
        current = current[part];
    }
    return current;
}

function normalizeValue(value) {
    if (value === null || value === undefined || (typeof value === 'string' && value.trim().toUpperCase() === '-NA-')) {
        return '';
    }
    return String(value).trim();
}

/**
 * Sorts dynamic carrier/technology keys based on a predefined hierarchical order.
 * Rules:
 * 1. Keys matching predefinedOrder come first, in that order.
 * 2. Missing keys from predefinedOrder are simply skipped.
 * 3. Keys NOT in predefinedOrder are appended at the end (in their original order).
 */
function sortCarrierKeys(keys) {
    if (!Array.isArray(keys)) return [];

    const predefinedOrder = ['700', '850', 'PCS', 'AWS', 'C-Band', 'CBRS', 'CBAND', 'MMW', 'LAA'];

    // Build a lookup: normalized predefined label -> index
    const orderMap = {};
    predefinedOrder.forEach((label, index) => {
        orderMap[label.toLowerCase()] = index;
    });

    const known = [];
    const unknown = [];

    keys.forEach((key, originalIndex) => {
        const lower = String(key).toLowerCase();
        // Try to match by startsWith first, then contains
        let matchIndex = -1;
        for (const label of predefinedOrder) {
            const ll = label.toLowerCase();
            if (lower.startsWith(ll) || lower.includes(ll)) {
                matchIndex = orderMap[ll];
                break;
            }
        }

        if (matchIndex !== -1) {
            known.push({ key, order: matchIndex, originalIndex });
        } else {
            // preserve original index for stable append ordering
            unknown.push({ key, originalIndex });
        }
    });

    // Sort known keys by their predefined order and preserve original relative order within same bucket
    known.sort((a, b) => {
        if (a.order === b.order) return a.originalIndex - b.originalIndex;
        return a.order - b.order;
    });

    // Keep unknown keys in original order
    unknown.sort((a, b) => a.originalIndex - b.originalIndex);

    return [...known.map(item => item.key), ...unknown.map(item => item.key)];
}

/**
 * Transform API response data to rename labels
 * - "Cell/EnodeB ID" -> "e/gNodeB ID"
 * - "Electrical Down-Tilt" -> "Antenna Electrical Down-Tilt"
 */
function transformApiResponseLabels(data) {
    if (!data || !Array.isArray(data.data)) return data;

    // mapping of source label (lowercased & trimmed) -> target label
    const labelMap = {
        'cell/enodeb id': 'e/gNodeB ID',
        'electrical down-tilt': 'Antenna Electrical Down-Tilt'
    };

    data.data.forEach(row => {
        if (!row || typeof row.label !== 'string') return;
        const normalized = row.label.trim().toLowerCase();
        if (labelMap.hasOwnProperty(normalized)) {
            row.label = labelMap[normalized];
        }
    });

    return data;
}

/**
 * Parses query parameters from the URL and converts keys to lowercase
 * for case-insensitive access.
 * @returns {Object} An object containing the URL query parameters.
 */
function getQueryParams() {
    const params = {};
    // ✅ FIX: Corrected syntax for the forEach loop
    window.location.search.substring(1).split('&').forEach(param => {
        const parts = param.split('=');
        if (parts.length === 2) {
            const key = decodeURIComponent(parts[0]).toLowerCase(); // Correctly converts key to lowercase
            params[key] = decodeURIComponent(parts[1]);
        }
    });
    return params;
}

async function fetchMainTableData(fuzeSiteId, projectNumber) {
    const apiUrl = getPromotionUrl + `?fuzeSiteId=${fuzeSiteId}&projectNumber=${projectNumber}`;
    console.log("Calling API for main table summary data:", apiUrl);
    try {
        const response = await fetch(apiUrl, {
            method: 'GET',
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            }
        });
        if (!response.ok) {
            const errorText = await response.text();
            console.error('Failed to load main table data:', response.status, errorText);
            showModal('Failed to load main table data! ' + (errorText || 'Failed to load main table data!'));
            return [];
        }
        const data = await response.json();
        console.log("Raw API response for main table:", data);
        
        // Extract summary from the API response
        if (data && data.summary) {
            const mainTableData = [{
                siteName: data.summary.siteName || "",
                fuzeSiteId: data.summary.fuzeSiteId || "",
                submarket: data.summary.submarket || "",
                proposedSiteRecordId: data.summary.proposedSiteRecordId || "",
                projectName: data.summary.projectName || "",
                projectId: data.summary.projectId || "",
                initiative: data.summary.initiative || "",
                rfdsProjectScope: data.summary.rfdsProjectScope || "",
                isApproved: data.summary.isApproved || false
            }];
            console.log("Extracted main table data from API summary:", mainTableData);
            return mainTableData;
        } else {
            console.warn("API response did not contain expected 'summary' property for main table.");
            return [];
        }
    } catch (error) {
        console.error('Error fetching main table data:', error);
        showModal('No data found');
        return [];
    }
}

async function getUserCommonSchema(fuzeSiteId, projectNumber) {
    const apiUrl = getPromotionUrl + `?fuzeSiteId=${fuzeSiteId}&projectNumber=${projectNumber}`;
    console.log("Calling API for merged table data:", apiUrl);
    try {
        const response = await fetch(apiUrl, {
            method: 'GET',
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            }
        });
        if (!response.ok) {
            const errorText = await response.text();
            console.error('Failed to load atollSchema data:', response.status, errorText);
            showModal('Failed to load atollSchema data! ' + (errorText || 'Failed to load atollSchema data!'));
            return null;
        }
        const data = await response.json();
        console.log("Raw API response for merged table:", data);
        if (data && data.schema && data.data) {
            // Transform labels dynamically
            transformApiResponseLabels(data);
            console.log("Directly using API response as merged table config:", data);
            return data;
        } else {
            console.warn("API response did not contain expected 'schema' or 'data' properties for merged table.");
            return null;
        }
    } catch (error) {
        console.error('no data found:', error);
        showModal(`No data Found`);
        return null;
    }
}

async function fetchMergedTableData(fuzeSiteId, projectNumber) {
    console.log(`Attempting to fetch merged table data for Fuze Site ID: ${fuzeSiteId}, Project Number: ${projectNumber}`);
    const config = await getUserCommonSchema(fuzeSiteId, projectNumber);
    console.log("Fetched config for merged table (after getUserCommonSchema):", config);
    return config || { schema: {}, data: [] };
}

function populateMainDataTable(data) {
    const $tbody = $('#mainDataTable tbody');
    $tbody.empty();

    if (data.length === 0) {
        const $tr = $('<tr>');
        const $td = $('<td>').attr('colspan', '9').addClass('loading-text').text('No data available for the table.');
        $tr.append($td);
        $tbody.append($tr);
        return;
    }

    data.forEach(rowData => {
        const $newRow = $('<tr>');

        const headers = ["siteName", "fuzeSiteId", "submarket", "proposedSiteRecordId", "projectName", "projectId", "initiative", "rfdsProjectScope"];
        headers.forEach(header => {
            // For RFDS Project Scope, wrap the content in a scrollable container so
            // large amounts of text or lists don't expand the whole table row.
            if (header === 'rfdsProjectScope') {
                const $td = $('<td>');
                const $wrapper = $('<div>').addClass('rfds-scope-menu').css({ 'max-width': '320px', 'overflow': 'hidden' });
                // Use html() to allow pre-formatted HTML in the scope if present
                $wrapper.html(rowData[header] || '');
                $td.append($wrapper);
                $newRow.append($td);
            } else {
                const $td = $('<td>').text(rowData[header] || '');
                $newRow.append($td);
            }
        });

        const $actionTd = $('<td>').addClass('action-cell');

        if (rowData.isApproved) {
            const $button = $('<button>').addClass('approve-btn').html('Approved').prop('disabled', true).css({
                'background-color': '#ec9ea1ff',
                'cursor': 'not-allowed',
                'pointer-events': 'none',
                'opacity': '0.8'
            });
            $actionTd.append($button);
        } else {
            const $button = $('<button>').addClass('approve-btn').html('Approve <svg viewBox="0 0 10 16"><path d="M1 1l8 7-8 7"/></svg>');
            $button.on('click', (event) => {
                // Show confirmation dialog before approving
                showConfirmationDialog('Do you want to approve ' + rowData.siteName + '?', () => {
                    approveAction(rowData, event.currentTarget);
                });
            });
            $actionTd.append($button);
        }

        $newRow.append($actionTd);
        $tbody.append($newRow);
    });

    // After building the table, ensure RFDS scope cells are scrollable even when
    // the RFDS content is populated dynamically later. We find the RFDS column by
    // header text and apply the scrollable wrapper styles to each cell in that column.
    (function ensureRfdsScrollable() {
        const rfdsHeaderIndex = $('#mainDataTable thead th').filter(function() {
            return $(this).text().trim() === 'RFDS Project Scope';
        }).index();

        if (rfdsHeaderIndex >= 0) {
            $('#mainDataTable tbody tr').each(function() {
                const $cell = $(this).find('td').eq(rfdsHeaderIndex);
                // If the wrapper exists (we created it), ensure it has the CSS class.
                const $wrapper = $cell.find('.rfds-scope-menu');
                if ($wrapper.length) {
                    $wrapper.css({ 'max-height': '220px', 'overflow-y': 'auto' });
                } else {
                    // If content is injected directly later, wrap it so CSS applies.
                    const cellHtml = $cell.html();
                    $cell.empty();
                    const $newWrapper = $('<div>').addClass('rfds-scope-menu').css({ 'max-height': '220px', 'overflow-y': 'auto' }).html(cellHtml);
                    $cell.append($newWrapper);
                }
            });
        }
    })();
}

function generateTableStructure(config) {
    const headerRows = [[], [], []];
    const bodyColumnOrder = [];

    headerRows[0].push({ title: "Carrier & Technology", colspan: 1, tag: "th", class: "border-right-black" });
    headerRows[1].push({ title: "Atoll Version", colspan: 1, tag: "th", class: "border-right-black" });
    headerRows[2].push({ title: "Sector", colspan: 1, tag: "th", class: "border-right-black" });

    bodyColumnOrder.push({ type: "label", key: "label", minWidth: "120px" });

    if (config && config.schema && typeof config.schema === 'object') {
        // Sort the top-level technology/carrier blocks according to predefined order
        const techNames = sortCarrierKeys(Object.keys(config.schema));
        let currentBodyColumnIndex = 0;

        techNames.forEach((techName, techIndex) => {
            const tech = config.schema[techName];
            let currentTechColspan = 0;
            const techSubsectionsRow2Headers = [];
            const techSectorsOrEmptyRow3Headers = [];

            let techTitleClass = "red-text";

            if (tech && tech.subsections && typeof tech.subsections === 'object') {
                // For subsections, ensure 'single_column' stays first (if present)
                // then sort the remaining subsections using the same carrier/technology order
                const rawSubNames = Object.keys(tech.subsections);
                const subsectionNames = [];
                if (rawSubNames.includes('single_column')) {
                    subsectionNames.push('single_column');
                }
                const remainingSubNames = rawSubNames.filter(n => n !== 'single_column');
                subsectionNames.push(...sortCarrierKeys(remainingSubNames));

                subsectionNames.forEach((subsectionName, subIndex) => {
                    const subsection = tech.subsections[subsectionName];
                    const borderClassForInnerCells = "border-right-black";

                    if (subsection.type === "single_column") {
                        techSubsectionsRow2Headers.push({
                            title: subsectionName,
                            colspan: 1,
                            tag: "th",
                            class: borderClassForInnerCells
                        });
                        techSectorsOrEmptyRow3Headers.push({
                            title: "",
                            colspan: 1,
                            tag: "th",
                            class: borderClassForInnerCells
                        });
                        bodyColumnOrder.push({
                            type: "data",
                            key: techName + "::" + subsectionName,
                            class: borderClassForInnerCells,
                            minWidth: "100px"
                        });
                        currentTechColspan += 1;
                        currentBodyColumnIndex += 1;
                    } else if (subsection.type === "band_with_sectors") {
                        const numSectors = subsection.sectors ? subsection.sectors.length : 0;
                        techSubsectionsRow2Headers.push({
                            title: subsectionName,
                            colspan: numSectors,
                            tag: "th",
                            class: borderClassForInnerCells
                        });
                        // REPLACE WITH THIS BLOCK (adds sectorIndex to bodyColumnOrder):
                        if (subsection.sectors && Array.isArray(subsection.sectors)) {
                            subsection.sectors.forEach((sector, sectorIndex) => {
                                techSectorsOrEmptyRow3Headers.push({
                                    title: sector,
                                    colspan: 1,
                                    tag: "th",
                                    class: borderClassForInnerCells
                                });
                                bodyColumnOrder.push({
                                    type: "data",
                                    key: techName + "::" + subsectionName + "::" + sector,
                                    sectorIndex: sectorIndex, // <-- ADDED THIS LINE
                                    class: borderClassForInnerCells,
                                    minWidth: "100px"
                                });
                                currentTechColspan += 1;
                                currentBodyColumnIndex += 1;
                            });
                        }
                    }
                });
            }

            headerRows[0].push({
                title: techName.replace(/ LTE$/, ''),
                colspan: currentTechColspan,
                tag: "th",
                class: "border-right-black " + techTitleClass
            });

            headerRows[1].push(...techSubsectionsRow2Headers);
            headerRows[2].push(...techSectorsOrEmptyRow3Headers);

            if (techIndex < techNames.length - 1) {
                const lastTechHeader = headerRows[0][headerRows[0].length - 1];
                lastTechHeader.class = (lastTechHeader.class || '') + ' column-spacer';

                if (techSubsectionsRow2Headers.length > 0) {
                    const lastSubsectionHeader = techSubsectionsRow2Headers[techSubsectionsRow2Headers.length - 1];
                    lastSubsectionHeader.class = (lastSubsectionHeader.class || '') + ' column-spacer';
                }

                if (techSectorsOrEmptyRow3Headers.length > 0) {
                    const lastSectorHeader = techSectorsOrEmptyRow3Headers[techSectorsOrEmptyRow3Headers.length - 1];
                    lastSectorHeader.class = (lastSectorHeader.class || '') + ' column-spacer';
                }

                if (currentBodyColumnIndex > 0) {
                    const lastColOfTechBlock = bodyColumnOrder[currentBodyColumnIndex - 1];
                    lastColOfTechBlock.class = (lastColOfTechBlock.class || '') + ' column-spacer';
                }
            }
        });
    }

    if (headerRows[0].length > 0) {
        const lastHeader0 = headerRows[0][headerRows[0].length - 1];
        lastHeader0.class = (lastHeader0.class || '').replace('border-right-black', '').replace('border-right-black-2px', '').replace('column-spacer', '').trim();
    }
    if (headerRows[1].length > 0) {
        const lastHeader1 = headerRows[1][headerRows[1].length - 1];
        lastHeader1.class = (lastHeader1.class || '').replace('border-right-black', '').replace('border-right-black-2px', '').replace('column-spacer', '').trim();
    }
    if (headerRows[2].length > 0) {
        const lastHeader2 = headerRows[2][headerRows[2].length - 1];
        lastHeader2.class = (lastHeader2.class || '').replace('border-right-black', '').replace('border-right-black-2px', '').replace('column-spacer', '').trim();
    }
    if (bodyColumnOrder.length > 0) {
        const lastBodyCol = bodyColumnOrder[bodyColumnOrder.length - 1];
        lastBodyCol.class = (lastBodyCol.class || '').replace('border-right-black', '').replace('border-right-black-2px', '').replace('column-spacer', '').trim();
    }

    return { headerRows, bodyColumnOrder };
}

function populateMergedDataTable(config) {
    const $table = $('#mergedDataTable');
    const $thead = $table.find('thead');
    const $tbody = $table.find('tbody');
    const $tableContainer = $table.closest('.table-container.mb-2');

    $thead.empty();
    $tbody.empty();
    $table.find('colgroup').remove();

    const { headerRows, bodyColumnOrder } = generateTableStructure(config);

    if (!config || !config.schema || Object.keys(config.schema).length === 0 || !config.data || config.data.length === 0) {
        const $tr = $('<tr>');
        const $td = $('<td>').attr('colspan', bodyColumnOrder.length || '9').addClass('loading-text').text('No data available for the table.');
        $tr.append($td);
        $tbody.append($tr);
        $tableContainer.addClass('no-merged-data-highlight');
        return;
    } else {
        $tableContainer.removeClass('no-merged-data-highlight');
    }

    let colgroupHtml = '<colgroup>';
    bodyColumnOrder.forEach(col => {
        colgroupHtml += '<col style="min-width: ' + (col.minWidth || '100px') + ';">';
    });
    colgroupHtml += '</colgroup>';
    $table.prepend(colgroupHtml);

    headerRows.forEach(rowDef => {
        const $tr = $('<tr>');
        rowDef.forEach(colDef => {
            const $cell = $('<' + colDef.tag + '>');
            $cell.text(colDef.title || '');
            if (colDef.colspan && colDef.colspan > 1) {
                $cell.attr('colspan', colDef.colspan);
            }
            if (colDef.rowspan && colDef.rowspan > 1) {
                $cell.attr('rowspan', colDef.rowspan);
            }
            if (colDef.class) {
                $cell.addClass(colDef.class);
            }
            $tr.append($cell);
        });
        $thead.append($tr);
    });

    const dynamicComparisonSubsections = {};
    if (config && config.schema) {
        for (const techName in config.schema) {
            if (config.schema.hasOwnProperty(techName) && config.schema[techName].subsections) {
                // Build a consistent order for subsection names: single_column first, then the rest
                const raw = Object.keys(config.schema[techName].subsections || {});
                const subNames = [];
                if (raw.includes('single_column')) subNames.push('single_column');
                const remaining = raw.filter(n => n !== 'single_column');
                subNames.push(...sortCarrierKeys(remaining));

                const distinctSubsections = [];
                for (const subName of subNames) {
                    if (subName && distinctSubsections.length < 2) {
                        distinctSubsections.push(subName);
                    } else if (distinctSubsections.length === 2) {
                        break;
                    }
                }

                if (distinctSubsections.length === 2) {
                    const baseSub = distinctSubsections[0];
                    const compareSub = distinctSubsections[1];

                    dynamicComparisonSubsections[techName] = {
                        base: baseSub,
                        compare: compareSub
                    };
                }
            }
        }
    }

    config.data.forEach(rowData => {
        if (rowData.label === "Sector") {
            return;
        }

        const $tr = $('<tr>');
        bodyColumnOrder.forEach((colConfig) => {
            const $td = $('<td>');
            let cellContent = '';

            if (colConfig.type === "label") {
                cellContent = rowData[colConfig.key] || '';
            } else if (colConfig.type === "empty") {
                cellContent = '';
            } else if (colConfig.type === "data") {
                const keyParts = colConfig.key.split('::');
                const techName = keyParts[0];
                const subsectionName = keyParts[1];
                const sector = keyParts[2];

                const currentValueRaw = getNestedValue(rowData, colConfig.key);
                const normalizedCurrentValue = normalizeValue(currentValueRaw);

                // Dynamically compare all rows for highlighting
                // Find the base subsection to compare with
                if (dynamicComparisonSubsections[techName]) {
                    const { base, compare } = dynamicComparisonSubsections[techName];

                    if (subsectionName === compare) {
                        let normalizedBaseValue;
                        const baseSubSchema = config.schema[techName]?.subsections?.[base];

                        // REPLACE WITH THIS BLOCK (uses positional index to lookup base sector):
                        if (baseSubSchema && baseSubSchema.type === "single_column") {
                            const baseKey = `${techName}::${base}`;
                            const baseValueRaw = getNestedValue(rowData, baseKey);
                            normalizedBaseValue = normalizeValue(baseValueRaw);
                        } else {
                            // Determine the corresponding base sector name by positional index (or fallback to sector key)
                            let baseSector = sector;
                            if (baseSubSchema && Array.isArray(baseSubSchema.sectors) && colConfig.sectorIndex !== undefined) {
                                baseSector = baseSubSchema.sectors[colConfig.sectorIndex] || sector;
                            }
                            const baseKey = `${techName}::${base}::${baseSector}`;
                            const baseValueRaw = getNestedValue(rowData, baseKey);
                            normalizedBaseValue = normalizeValue(baseValueRaw);
                        }

                        if (normalizedCurrentValue !== normalizedBaseValue) {
                            $td.addClass('highlight-red');
                        }
                    }
                }

                cellContent = currentValueRaw ?? '';
            }

            $td.text(cellContent);

            if (colConfig.class) {
                $td.addClass(colConfig.class);
            }

            $tr.append($td);
        });
        $tbody.append($tr);
    });
}

async function approveAction(rowData, buttonElement) {
    if (!roles.includes("PLANNING_RF_ENG")) {
        showModal('Access Denied: You do not have the required "PLANNING_RF_ENG" role to perform this action.');
        return;
    }

    showModal('Approving for ' + rowData.siteName + '... <span class="spinner"></span>');
    $('#modalSpinner').show();
    $('#myModal .approve-btn').hide(); // Hide the OK button during spinner
    $(buttonElement).prop('disabled', true).text('Approving...');


    const payload = {
        fuzeSiteId: rowData.fuzeSiteId,
        spmProjectId: rowData.projectId,
        userId: VZID // Added userId to the payload
    };

    console.log("Sending approval payload:", payload);

    try {
        const response = await fetch(versionPromotionUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(payload)
        });

        const data = await response.json();

        // Check result field in response (success/failure) regardless of HTTP status
        if (data && data.result === 'success') {
            showModal('<div class="version-promotion">Success! ' + (data.comments || 'Action approved successfully.') + '</div>');
            console.log("Approval successful for:", rowData, "API Response:", data);
            loadPageData();

        } else if (data && data.result === 'failure') {
            const errorMessage = data.error || data.comments || 'Version promotion Failed.';
            showModal('<div class="version-promotion">Error approving for ' + rowData.siteName + ': ' + errorMessage + '</div>');
            console.error("Approval failed (API result failure):", data);
            $(buttonElement).prop('disabled', false).text('Approve');

        } else {
            // Display error or comments for any other response
            const message = data.error || data.comments || data.message || 'Unexpected API response.';
            showModal('<div class="version-promotion">' + message + '</div>');
            console.warn("Unexpected API response format:", data);
            $(buttonElement).prop('disabled', false).text('Approve');
        }
    } catch (error) {
        showModal('<div class="version-promotion">Network error or API is unreachable: ' + error.message + '</div>');
        console.error("Fetch error:", error);
        $(buttonElement).prop('disabled', false).text('Approve');
    } finally {
        $('#modalSpinner').hide();
        $('#myModal .approve-btn').show(); // Show the OK button after spinner
    }
}

async function loadPageData() {
    $('#globalLoadingBar').css({
        'opacity': '1',
        'transform': 'scaleX(0)',
        'animation': 'none'
    }).show();

    await new Promise(resolve => setTimeout(resolve, 10));
    $('#globalLoadingBar').css('animation', 'loading-fill 5s linear forwards');

    $('#mainDataTable').hide();
    $('#mergedDataTable').hide();

    const queryParams = getQueryParams();
    const fuzeSiteIdFromUrl = queryParams.fuzesiteid;
    const projectNumberFromUrl = queryParams.projectid || queryParams.projectnumber;

    const mainTableDataFromApi = await fetchMainTableData(fuzeSiteIdFromUrl, projectNumberFromUrl);
    currentMainTableData = mainTableDataFromApi;

    populateMainDataTable(currentMainTableData);

    let mergedConfigToDisplay = { schema: {}, data: [] };

    if (currentMainTableData.length > 0) {
        mergedConfigToDisplay = await fetchMergedTableData(currentMainTableData[0].fuzeSiteId, currentMainTableData[0].projectId);
    }

    populateMergedDataTable(mergedConfigToDisplay);

    $('#mainDataTable').show();
    $('#mainDataTable thead').show();
    $('#mainDataTable tbody').show();

    $('#mergedDataTable').show();
    $('#mergedDataTable thead').show();
    $('#mergedDataTable tbody').show();

    // After layout is rendered, adjust top/merged table sizing to avoid overlap
    try {
        adjustMainWrapperAndMergedOffset();
    } catch (e) {
        console.warn('adjustMainWrapperAndMergedOffset failed:', e);
    }

    $('#globalLoadingBar').hide();
}

// Variables to track scroll position
// Define a scroll threshold in pixels

$(document).ready(function() {
    // Updated event listeners for the new modal design
    // The close button now calls hideModal()
    $('#modalCloseButton').on('click', function() { // Changed to #modalCloseButton as per HTML
        hideModal();
    });
    // Clicking outside the modal content also calls hideModal()
    $(window).on('click', function(event) {
        if ($(event.target).is('#myModal')) {
            hideModal();
        }
    });

    const requiredRolesForPage = ["PLANNING_RF_ENG", "PLANNING_RF_ENG2", "PLANNING_RF_ENG3"];
    let hasRequiredRole = false;

    console.log('versionPromotion URL:', versionPromotionUrl);
    console.log('getPromotion URL:', getPromotionUrl);

    if (!Array.isArray(roles)) {
        roles = [];
    }

    for (const requiredRole of requiredRolesForPage) {
        if (roles.includes(requiredRole)) {
            hasRequiredRole = true;
            break;
        }
    }

    if (!hasRequiredRole) {
        $('.main-container').hide();
        showModal('Access Denied: You do not have the required role to view this page.');
        $('#modalSpinner').hide();
        // The original request was to remove the OK button. If it's desired to show it for access denied, uncomment below.
        // $('#myModal .approve-btn').show(); // Ensure OK button is shown for access denied
        $('#globalLoadingBar').hide();
        return;
    }

    if (!VZID || VZID.trim() === "") {
        $('.main-container').hide();
        showModal('Error: User ID (VZID) is missing. Please ensure you are logged in correctly.');
        $('#modalSpinner').hide();
        // The original request was to remove the OK button. If it's desired to show it for missing VZID, uncomment below.
        // $('#myModal .approve-btn').show(); // Ensure OK button is shown for missing VZID
        $('#globalLoadingBar').hide();
        return;
    }

    loadPageData();
});

// Adjust the main table wrapper max-height and ensure the merged table is positioned
// below the visible height of the top container to avoid overlap.
function adjustMainWrapperAndMergedOffset() {
    const $topContainer = $('.table-container.first-table-container');
    const $wrapper = $topContainer.find('.table-responsive-wrapper');
    const $mergedContainer = $('.table-container.mb-2');

    if (!$topContainer.length || !$wrapper.length || !$mergedContainer.length) return;

    // Viewport height and top container position
    const viewportH = window.innerHeight || document.documentElement.clientHeight;
    const topRect = $topContainer[0].getBoundingClientRect();
    const topOffset = Math.max(0, topRect.top);

    // Reserve some space for merged table and margins; tweak reservedBelow as needed
    const reservedBelow = 160;
    const availableForTopContainer = Math.max(120, viewportH - topOffset - reservedBelow);

    // Account for the header height (keep header visible while body scrolls)
    const theadHeight = $topContainer.find('thead').outerHeight(true) || 40;
    const wrapperMax = Math.max(100, availableForTopContainer - theadHeight);

    $wrapper.css({ 'max-height': wrapperMax + 'px', 'overflow-y': 'auto' });

    // Ensure RFDS wrappers have reasonable heights inside the top wrapper
    $wrapper.find('.rfds-scope-menu').css({
        'max-height': Math.min(Math.max(120, wrapperMax - 20), 400) + 'px',
        'overflow-y': 'auto'
    });

    // Position the merged table container below the rendered top container height
    const topContainerHeight = Math.ceil($topContainer.outerHeight(true));
    const gap = 2;
    $mergedContainer.css('margin-top', (topContainerHeight + gap) + 'px');
}

// MutationObserver to watch for dynamic changes inside the top container and reflow
function enableTopContainerObserver() {
    const topEl = document.querySelector('.table-container.first-table-container');
    if (!topEl) return;
    const mo = new MutationObserver(() => {
        // Small timeout to allow layout to settle after DOM changes
        setTimeout(adjustMainWrapperAndMergedOffset, 50);
    });
    mo.observe(topEl, { childList: true, subtree: true, attributes: true, characterData: true });
    // Also observe window resize
    window.addEventListener('resize', () => {
        // debounce to prevent excessive calls
        if (window._adjustTimeout) clearTimeout(window._adjustTimeout);
        window._adjustTimeout = setTimeout(adjustMainWrapperAndMergedOffset, 100);
    });
}

// Enable observer after DOM ready
$(function() {
    enableTopContainerObserver();
});

