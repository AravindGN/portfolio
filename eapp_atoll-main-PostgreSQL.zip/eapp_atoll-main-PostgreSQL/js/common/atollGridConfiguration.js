var siteManagementModifiedDataList	= {};
var modifiedGridData = [];
var invalidEnodeBId = false;
var enb_tx_id ='';
var saveConfirmationSpreadsheetColumns = [
	{ name: 'Type', type: 'text', title: 'Type', width: 120, readOnly: true },
	{ name: 'FieldName', type: 'text', title: 'Field Name', width: 160, readOnly: true },
	{ name: 'OldValue', type: 'text', title: 'Old Value', width: 160, readOnly: true },
	{ name: 'NewValue', type: 'text', title: 'New Value', width: 160, readOnly: true },
	{ name: 'Action', type: 'text', title: 'Action', width: 110, readOnly: true }
];
var gridObj = {
			data: modifiedGridData,
			columns: saveConfirmationSpreadsheetColumns,
			tableOverflow: true,
			tableWidth: '100%',
			filters: false,
			tabs: false,
			allowInsertRow: false,
			allowInsertColumn: false,
			allowRenameColumn: false,
			allowDeleteColumn: false,
			allowDeleteRow: false,
			tableOverflowResizable: true,
			autoIncrement:false,
		};
		
$(document).ready(function (e){
	createSaveConfirmationGrid(gridObj);
})

function saveSiteManagementInfo(){
	$('#loading').show();
	let isDataModified = false;
	invalidEnodeBId = false;
    enb_tx_id ='';
	siteManagementModifiedDataList	= formSiteManagementModifiedDataList();
    if((siteManagementModifiedDataList === null || $.isEmptyObject(siteManagementModifiedDataList)) && invalidEnodeBId)
	{
		aptAlert('error', 'VZ_ENODEB_ID should not be in the range of 995000-999999 for TX_ID : ' + enb_tx_id);
		$('#loading').hide();
	}
	else{	
	if(siteManagementModifiedDataList != null && !$.isEmptyObject(siteManagementModifiedDataList)){
		isDataModified = true;
	}
	if(isDataModified){

		callConfirmationSpreadsheet(siteManagementModifiedDataList);
	}
	else{
		aptAlert('warning', 'No records found to update!');
		$('#loading').hide();
	}
}
};

$("#siteManagementSaveConfirmationCancel").click(function(){
	$('#loading').hide();
	$("#siteManagementSaveConfirmationModal").modal("hide");
});

function compareAndBuildModifiedData(inputNewItemObj, inputOriginalItemObj, tableName, tableColumns, modifiedDataList, payloadArray){
   
	for( var i = 0;inputNewItemObj && i < inputNewItemObj.length ; i++){
		let oldvalue = inputOriginalItemObj[i]?inputOriginalItemObj[i]:{};
	    let newValue = inputNewItemObj[i]?inputNewItemObj[i]:{};
	    let isModified = false;
	    $.each(newValue, function(key, val){
		    oldvalue[key] = oldvalue[key]===null || oldvalue[key]===undefined ? '':oldvalue[key];
			newValue[key] = newValue[key]===null || newValue[key]===undefined ? '':newValue[key];
		   if (Object.keys(oldvalue).includes(key) && Object.keys(newValue).includes(key) && oldvalue[key] != newValue[key]){
			let fieldName = tableColumns.find(obj=>obj.name == key);
			if(fieldName){
			let modifiedData = { 'FieldName': fieldName.title, 'OldValue': oldvalue[key], 'NewValue': newValue[key], 'Type': tableName, 'Action': 'Update' };
			modifiedDataList.push(modifiedData);
			isModified = true;
			}
		   }
	    })
	    let saveObj = newValue;
		if(isModified){
			saveObj.flag = "update";
			payloadArray.push(saveObj);
		}
	}
	var enodeb_vendor_exit = false;
	if (Object.keys(featureToggleMap).includes("F76965") && featureToggleMap['F76965']) {
	for(var i in modifiedDataList){
		if(modifiedDataList[i]['FieldName'] == "VZ_ENODEB_VENDOR"){
			enodeb_vendor_exit = true;
		}
	}

	if(tableName === 'Transmitter' && enodeb_vendor_exit){
			for( var i = 0;payloadArray && i < payloadArray.length ; i++){
				if((payloadArray[i]['vzEnodebVendor']!=null || !$.isEmptyObject(payloadArray[i]['vzEnodebVendor'])) && (!(payloadArray[i]['vzEnodebVendor'].includes("NHN")) ) &&(payloadArray[i]['vzEnodebId']>=995000 && payloadArray[i]['vzEnodebId']<=999999)){
				invalidEnodeBId = true;
				enb_tx_id = payloadArray[i]['txId'] ;
				break;
			}
		 	
		}
	}
}
	return modifiedDataList;
}

function formSiteManagementModifiedDataList(){
	let modifiedDataList = {};
	let invalidEnodebIdEmptyList = []
	// code to check sites modified
	let modifiedSitesDataList = [];
	let payloadSites = [];
	modifiedSitesDataList = compareAndBuildModifiedData(gridData.sites, oldGridData.sites, 'Sites', siteTableColumns, modifiedSitesDataList, payloadSites)
	if(modifiedSitesDataList.length>0)
	modifiedDataList.modifiedSitesData = modifiedSitesDataList;	
	// code to check transmitter modified
	let modifiedTransmitterDataList = [];
	let payloadTransmitter = [];
	modifiedTransmitterDataList = compareAndBuildModifiedData(gridData.xgTransmitters, oldGridData.xgTransmitters, 'Transmitter', transmitterGridColumns, modifiedTransmitterDataList, payloadTransmitter)	
	if(invalidEnodeBId){
		return invalidEnodebIdEmptyList;
	}
	if(modifiedTransmitterDataList.length>0)
	modifiedDataList.modifiedTransmitterData = modifiedTransmitterDataList;

	// code to check Cell LTE modified
	let modifiedCellLTEDataList = [];
	let payloadCellLTE = [];
	modifiedCellLTEDataList = compareAndBuildModifiedData(gridData.xgCellsLte, oldGridData.xgCellsLte, 'Cells LTE', cellLTEGridColumns, modifiedCellLTEDataList, payloadCellLTE)
	if(modifiedCellLTEDataList.length>0)
	modifiedDataList.modifiedCellLTEData = modifiedCellLTEDataList;
	// code to check 5G NR modified
	let modified5GnrDataList = [];
	let payload5Gnr = [];
	modified5GnrDataList = compareAndBuildModifiedData(gridData.xgCells5gnr, oldGridData.xgCells5gnr, '5G Cells', Cells5GnrGridColumns, modified5GnrDataList, payload5Gnr)
	if(modified5GnrDataList.length>0)
	modifiedDataList.modified5GnrData = modified5GnrDataList;

	// code to check spare antenna modified
	let modifiedSpareAntennaDataList = [];
	let payloadSpareAntenna = [];
	modifiedSpareAntennaDataList = compareAndBuildModifiedData(gridData.spareAntennas, oldGridData.spareAntennas, 'Spare Antenna', spareAntennaGridColumns, modifiedSpareAntennaDataList, payloadSpareAntenna)
	if(modifiedSpareAntennaDataList.length>0)
	 modifiedDataList.modifiedSpareAntennaData = modifiedSpareAntennaDataList;
	let obj = {
		"sites": payloadSites,
		"xgTransmitters": payloadTransmitter,
		"xgCellsLte": payloadCellLTE,
		"xgCells5gnr": payload5Gnr,
		"spareAntennas": payloadSpareAntenna,
		"market": commonSchemaSearchPayload.atollSchema
	}
	savePayload = obj;	 
	return modifiedDataList;
}

var jSpreadsheetSitesSaveConfirmationObj;
var jSpreadTransmitterSaveConfirmationObj;
var jSpreadsheetCellLTESaveConfirmationObj;
var jSpreadsheetCell5gnrSaveConfirmationObj;
var jSpreadsheetSpareAntennaSaveConfirmationObj;
function createSaveConfirmationGrid(gridObj){
	 jSpreadsheetSitesSaveConfirmationObj = jspreadsheet(document.getElementById('sitesSaveConfirmationSpreadsheet'),gridObj );
	 jSpreadTransmitterSaveConfirmationObj = jspreadsheet(document.getElementById('transmitterSaveConfirmationSpreadsheet'),gridObj);
	 jSpreadsheetCellLTESaveConfirmationObj = jspreadsheet(document.getElementById('cellLTESaveConfirmationSpreadsheet'),gridObj);
	 jSpreadsheetCell5gnrSaveConfirmationObj = jspreadsheet(document.getElementById('cell5gnrSaveConfirmationSpreadsheet'),gridObj); 
	 jSpreadsheetSpareAntennaSaveConfirmationObj = jspreadsheet(document.getElementById('spareAntennaSaveConfirmationSpreadsheet'),gridObj);
}

function callConfirmationSpreadsheet(modifiedDataList){
	$("#siteManagementSaveConfirmationModal").modal("show");
    modifiedGridData = modifiedDataList.hasOwnProperty('modifiedSitesData') ? modifiedDataList.modifiedSitesData : {};								
	if(modifiedGridData != null && !$.isEmptyObject(modifiedGridData)){
		$('#sitesSaveConfirmationSpreadsheet').show();
		jSpreadsheetSitesSaveConfirmationObj.setData(modifiedGridData);
	} else $('#sitesSaveConfirmationSpreadsheet').hide();
	
	modifiedGridData = modifiedDataList.hasOwnProperty('modifiedTransmitterData') ? modifiedDataList.modifiedTransmitterData : {};
	if(modifiedGridData != null && !$.isEmptyObject(modifiedGridData)){
		$('#transmitterSaveConfirmationSpreadsheet').show();
		jSpreadTransmitterSaveConfirmationObj.setData(modifiedGridData);
	} else $('#transmitterSaveConfirmationSpreadsheet').hide();
	
	modifiedGridData = modifiedDataList.hasOwnProperty('modifiedCellLTEData') ? modifiedDataList.modifiedCellLTEData : {};
	if(modifiedGridData != null && !$.isEmptyObject(modifiedGridData)){
		$('#cellLTESaveConfirmationSpreadsheet').show();
		jSpreadsheetCellLTESaveConfirmationObj.setData(modifiedGridData);
	} else $('#cellLTESaveConfirmationSpreadsheet').hide();
	
	
	modifiedGridData = modifiedDataList.hasOwnProperty('modified5GnrData') ? modifiedDataList.modified5GnrData : {};
	if(modifiedGridData != null && !$.isEmptyObject(modifiedGridData)){
		$('#cell5gnrSaveConfirmationSpreadsheet').show();
		jSpreadsheetCell5gnrSaveConfirmationObj.setData(modifiedGridData);
	} else $('#cell5gnrSaveConfirmationSpreadsheet').hide();
	
	modifiedGridData = modifiedDataList.hasOwnProperty('modifiedSpareAntennaData') ? modifiedDataList.modifiedSpareAntennaData : {};
	if(modifiedGridData != null && !$.isEmptyObject(modifiedGridData)){
		$('#spareAntennaSaveConfirmationSpreadsheet').show();
		jSpreadsheetSpareAntennaSaveConfirmationObj.setData(modifiedGridData);
	} else $('#spareAntennaSaveConfirmationSpreadsheet').hide();
	
	$('#loading').hide();
}