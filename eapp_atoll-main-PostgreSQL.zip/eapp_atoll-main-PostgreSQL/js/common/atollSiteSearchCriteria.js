function populateTerritory(isServerCallReq) {
    
	if(isServerCallReq) {
		territoryDataProvider = [];
		$.ajax({
			url: CONTEXT_PATH + '/uui/eapp/rfds_pg/getTerritoryDropdown',
			dataType: 'json',
			type: "GET",
			async: false,
			success: function (data) {
				territoryDataProvider = data;
				if (loadOffScreenData) {
					entireTerritoryList = [];
					$.each(territoryDataProvider, function (index, value) {
						entireTerritoryList.push(value.TERRITORY);
					});
					populateAreas(entireTerritoryList, true);
				}
			},
			error: function (data) {
				showMessageBanner('error', 'Failed to load territory data!');
			}
		});
	} else {
		if (loadOffScreenData) {
			entireTerritoryList = [];
			$.each(territoryDataProvider, function (index, value) {
				entireTerritoryList.push(value.TERRITORY);
			});
			populateAreas(entireTerritoryList, true);
		}
	}
   

    $.each(territoryDataProvider, function (index, value) {
        $('#territoryDropdown').append("<option style='display:inline-block;' id='" + value.TERRITORY + "' value='" + value.TERRITORY + "' class='multis'>" + value.TERRITORY + "</option>");
    });

    $('#territoryDropdown').multiselect({
        includeSelectAllOption: true,
        enableFiltering: true,
        numberDisplayed: 1,
        enableCaseInsensitiveFiltering: true,
        buttonClass: 'btn btn-default whitebg btn-sm',
		nonSelectedText: 'Any',
        onChange: function (option, checked, select){
    		console.log("in change territoryDropdown");
        	let tList = $('#territoryDropdown').val()!=null?$('#territoryDropdown').val():entireTerritoryList;
			if(returnedFuzeSiteId == "") {
				populateAreas(tList, true);
			}
        },
        onDropdownHide: function (option, checked, select) {         
			$("#siteNameSelect").val('');
        }
    });
}
function populateAreas(tList, isServerCallReq) {
	if(isServerCallReq) {
		areasDataProvider = [];
	}
	else {
		if (loadOffScreenData) {
			entireAreaList = [];
			$.each(areasDataProvider, function (index, value) {
				entireAreaList.push(value.area);
			});
			populateRegions(entireAreaList, true);
		}
	}
    if (tList != null) {
        var territoryList = JSON.stringify(tList);

        $.ajax({
            async: false,
            url: CONTEXT_PATH + '/uui/eapp/rfds_pg/getAreaForMarketBoundary',
            type: "POST",
            data: { territoryList: territoryList },
            cache: false,
            success: function (data) {
                areasDataProvider = JSON.parse(data).areas;
                if (loadOffScreenData) {
					entireAreaList = [];
                    $.each(areasDataProvider, function (index, value) {
                        entireAreaList.push(value.area);
                    });
                    populateRegions(entireAreaList, true);
                }
            }
        });
    }
    $('#areaDropdown').html('');
    $('#areaDropdown').multiselect('destroy');
    $.each(areasDataProvider, function (index, value) {
        $('#areaDropdown').append("<option value='" + value.area + "' class='multis'>" + value.areaname + "</option>");
    });

    $('#areaDropdown').multiselect({
        includeSelectAllOption: true,
        enableFiltering: true,
        numberDisplayed: 1,
        enableCaseInsensitiveFiltering: true,
        buttonClass: 'btn btn-default whitebg btn-sm',
		nonSelectedText: 'Any',
        onChange: function (option, checked, select){
    		console.log("in change areaDropdown");
        	let tList = $('#areaDropdown').val()!=null?$('#areaDropdown').val():entireAreaList;
			if(returnedFuzeSiteId == "") {
				populateRegions(tList, true);
			}
        },
        onDropdownHide: function (option, checked, select) {
			$("#siteNameSelect").val('');
        }
    });
    setTimeout(function () {
        $('#areaDropdown').multiselect({
            includeSelectAllOption: true,
            enableFiltering: true,
            enableCaseInsensitiveFiltering: true,
            numberDisplayed: 1
        });
    }, 1);

}

function populateRegions(aList, isServerCallReq) {
	if(isServerCallReq) {
		regionsDataProvider = [];
	} else {
		if (loadOffScreenData) {
			entireRegionList = [];
			$.each(regionsDataProvider, function (index, value) {
				entireRegionList.push(value.region);
			});
			populateMarkets(entireRegionList, true);
		}
	}
    if (aList != null) {
        var areaList = JSON.stringify(aList);

        $.ajax({
            async: false,
            url: CONTEXT_PATH + '/uui/eapp/rfds_pg/getRegionsForMarketBoundary',
            type: "POST",
            data: { areaList: areaList },
            cache: false,
            success: function (data) {
                regionsDataProvider = JSON.parse(data).regions;
                if (loadOffScreenData) {
					entireRegionList = [];
                    $.each(regionsDataProvider, function (index, value) {
                        entireRegionList.push(value.region);
                    });
					populateMarkets(entireRegionList, true);
                }
            }
        });
    }
    $('#regionDropdown').html('');
    $('#regionDropdown').multiselect('destroy');
    $.each(regionsDataProvider, function (index, value) {
        $('#regionDropdown').append("<option value='" + value.region + "' class='multis'>" + value.regionname + "</option>");
    });

    $('#regionDropdown').multiselect({
        includeSelectAllOption: true,
        enableFiltering: true,
        numberDisplayed: 1,
        enableCaseInsensitiveFiltering: true,
        buttonClass: 'btn btn-default whitebg btn-sm',
		nonSelectedText: 'Any',
        onChange: function (option, checked, select){
    		console.log("in change regionDropdown");
        	let tList = $('#regionDropdown').val()!=null?$('#regionDropdown').val():entireRegionList;
			if(returnedFuzeSiteId == "") {
				populateMarkets(tList, true);
			}
        },
        onDropdownHide: function (option, checked, select) {
			$("#siteNameSelect").val('');
        }
    });
    setTimeout(function () {
        $('#regionDropdown').multiselect({
            includeSelectAllOption: true,
            enableFiltering: true,
            enableCaseInsensitiveFiltering: true,
            numberDisplayed: 1
        });
    }, 1);
}

function populateMarkets(rList, isServerCallReq){
	if(isServerCallReq) {
		marketsDataProvider = [];
	} else {
		if(loadOffScreenData) {
			entireMarketList = [];
			 $.each(marketsDataProvider, function (index, value) {
				entireMarketList.push(value.MARKET);
			});
		}
	}
    if (rList != null) {
        var regionList = JSON.stringify(rList);
        $.ajax({
            async: false,
            url: CONTEXT_PATH + '/uui/eapp/rfds_pg/getMarketsForMarketBoundary',
            type: "POST",
            data: { regionList: regionList },
            cache: false,
            success: function (data) {
                marketsDataProvider = JSON.parse(data).markets;
				if(loadOffScreenData) {
					entireMarketList = [];
					 $.each(marketsDataProvider, function (index, value) {
                        entireMarketList.push(value.MARKET);
                    });
				}
            }
        });
    }

    $('#marketDropdown').html('');
    $('#marketDropdown').multiselect('destroy');
    $.each(marketsDataProvider, function (index, value) {
        $('#marketDropdown').append("<option value='" + value.MARKET + "' class='multis'>" + value.MARKET + "-" + value.MARKETNAME + "</option>");
    });
    $('#marketDropdown').multiselect({
        includeSelectAllOption: true,
        enableFiltering: true,
        numberDisplayed: 1,
        enableCaseInsensitiveFiltering: true,
        buttonClass: 'btn btn-default whitebg btn-sm',
		nonSelectedText: 'Any',
		onDropdownHide: function (option, checked, select) {
            let marketValue = $('#marketDropdown').val();
            if (marketValue != null && marketValue.length > 0) {
				$("#siteNameSelect").val('');
		    }

        },
	
    });

    $("#marketDropdown").attr("size", 3);
    setTimeout(function () {
        $('#marketDropdown').multiselect({
            includeSelectAllOption: true,
            enableFiltering: true,
            numberDisplayed: 1,
            enableCaseInsensitiveFiltering: true
        });
    }, 1);
}




function drawTable(id,dataSource,columns,filename){
	
	$(id).kendoGrid({
        dataSource:dataSource,
       	columns: columns,
       
        filterable: {
            operators: {
                //string:kendoGridManager.stringFilterOperator
            }
        },
        groupable:false,
        columnMenu: true,
        reorderable: true,
        pageable: {
            pageSizes:5,  
            input: true,
            numeric: false,
            pageSizes:[10,20, 50, 100, "All"]
            
        },
		selectable: 'row',
		columnMenu: true,
		sortable: true,
        change: function () {
           // $('tbody tr').find('[type=checkbox]').prop('checked', false);
		   // $(' tbody tr.k-state-selected').find('[type=checkbox]').prop('checked', true);
        },
		dataBound: function (e) {
			var grid = e.sender;
            var items = e.sender.items();
            //e.sender.pager.element.hide();
           items.each(function(e) {
                var dataItem = grid.dataItem(this);
                if(dataItem.projectstatus == "COMPLETED" || dataItem.projectstatus == "CANCELLED" || dataItem.lock == "YES"){
                	$(this).find('#editProjectIcon').css({"pointer-events": "none", "color": "darkgrey"});
                }
           });
		},
		noRecords: {
				template: "<div style='font-size:12px;color:red'>No data available</div>"
		},
		toolbar: [
            "excel"
        ],
        excel: {
            fileName: filename,
            allPages: true
        },
      });
	grid = $(id).data("kendoGrid");
}