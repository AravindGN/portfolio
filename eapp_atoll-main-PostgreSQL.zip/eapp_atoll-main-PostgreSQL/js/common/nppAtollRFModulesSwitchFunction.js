var currentRFModuleName;
var fetchSchemaFromlocalStorage;
var fetchSiteNameFromlocalStorage;
var fetchSiteVersionFromlocalStorage;
var typeOfModule;
var fetchLinksData;
var rfdsSchema;
var fuseSiteId = [];
var extractProjectNumber;
var getRfdsSubmitLink;
var extractedProjectNumberArray=[];
var rfdsVersion;
var projectNumber;
var fuzeSiteIdPresent;
$(document).ready(function() { 
    if (Object.keys(featureToggleMap).includes("F90711") && featureToggleMap['F90711']) {
		buildAtollRFModuleSwtich();
	}
});
function buildAtollRFModuleSwtich() {
    var loadeModules = $("<div style='width: 165px; display:inline-block;'><select type='drop-down' id='moduleToSelect' onchange='getModuleType()'></select></div>");
    $('#createModulesDb').append(loadeModules);
    var lunchButton = $('<div style="width: 120px; display:inline-block;"> <button class="btn btn-danger" style="margin-left: 10px;height: 25px;min-height: 25px;line-height: 25px;margin-top: 19px;border-radius: 3px !important;font-size: 14px;width: 100px;padding: 0 20px;" onclick = "launchModule()">Launch</button></div>');
    $('#createModulesDb').append(lunchButton);
    loadAtollRFModules();
}
function getModuleType() {
    typeOfModule = document.getElementById("moduleToSelect").value;
    console.log(typeOfModule);
}
var getLink;
function loadAtollRFModules() {
   
   
    $.ajax({
        type: 'POST',
        async: false,
       // url: "https://nppatolluat-east1.ebiz.verizon.com/npp-atoll-services/atollUtility/fetchRfModulesAndLinks",
       //  url: "http://localhost:8100/npp-atoll-services/atollUtility/fetchRfModulesAndLinks",
       url: fetchRfModulesAndLinksUrl,
        dataType: 'json',
        contentType: 'application/json',
        cache: false,
        headers: {
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json'
        },
        success: function (data) {
            console.log(data);
            fetchLinksData = data;
            $('#moduleToSelect').html('');
            $('#moduleToSelect').multiselect('destroy');

            $.each(fetchLinksData, function (i, v) {
                $('#moduleToSelect').append("<option>" + fetchLinksData[i].rfModule
                    + "</option>");
            });
          
            $('#moduleToSelect').multiselect({
                includeSelectAllOption: true,
                enableFiltering: true,
                enableCaseInsensitiveFiltering: true,
                buttonClass: 'btn btn-default whitebg btn-sm',
                numberDisplayed: 1,
                nonSelectedText: 'None selected'

            });

        }
    });
    var selectUrl = window.location.pathname.split('/');
	var urlName = selectUrl[selectUrl.length-1];
    if (urlName === "gNodeBinfo") { 
        currentRFModuleName = "eNB/gNB Planning tool";
       setDefaultValue();
    } else if (urlName === "zitePCI") {
        currentRFModuleName = "PCI/RSI";
        setDefaultValue();
    } else if (urlName === "e911Jspreadsheet") {
        currentRFModuleName = "E911 SUBMIT";
        setDefaultValue();
    } else if (urlName === "RfdsService") {
        currentRFModuleName = "RFDS";
        setDefaultValue();
    } else if (urlName === "atollSiteHistory") {
        currentRFModuleName = "Atoll Site History";
        setDefaultValue();
    }else if (urlName === "scheduleUpdates") {
        currentRFModuleName = "Scheduled Updates";
        setDefaultValue();
    } if (urlName === "e911Report") {
        currentRFModuleName = "E911 Reports";
        setDefaultValue();
    } else {
        currentRFModuleName = "E911 Dispatchable Location";
        setDefaultValue();
    }
   
}
function setDefaultValue() {
    $('#moduleToSelect').val([]).multiselect('refresh');
    for(var i =0; i < fetchLinksData.length; i++) {
        if(fetchLinksData[i].rfModule == currentRFModuleName){
             fetchLinksData.splice(i, 1);          
           // $("#moduleToSelect").multiselect('select', fetchLinksData[i].rfModule)
       }
    }
     $('#moduleToSelect').html('');
	$('#moduleToSelect').multiselect('destroy');
    $('#moduleToSelect').append("<option>None selected</option>");
    $.each(fetchLinksData, function(i, v) {
		$('#moduleToSelect').append("<option>" + v.rfModule + "</option>");
	});
	$('#moduleToSelect').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
		nonSelectedText: 'None selected'

	});
    
}
var routerParamsUrl = {};
// after clicking on launch button selected value and redirect to that link
function launchModule() {

	var selectUrl = window.location.pathname.split('/');
	var urlName = selectUrl[selectUrl.length-1];
    let url = window.location.href;
    let splitUrl = url.split("?");
			let params = (splitUrl[1]) ? splitUrl[1].split('&') : [];
            params.forEach(element => {
				if (element) {
					var obj = {};
					var a = element.split("=");
					if (a.length > 0) {
						obj[a[0]] = a[1];
						routerParamsUrl = { ...obj, ...routerParamsUrl };
					}
				}
			});
    if(urlName=='RfdsService'){
    	fuseSiteId = [];
if(routerParamsUrl.fuzeSiteId && routerParamsUrl.projectnumber) {
            fuseSiteId = routerParamsUrl.fuzeSiteId;
            projectNumber =  routerParamsUrl.projectnumber;
        } else {
            fuseSiteId = $('#siteNameSelect').val();
            projectNumber =  $('#projectNumberSelect').val();
}
    
        fetchRfdsInputs(fuseSiteId,projectNumber);
    	fetchSchemaFromlocalStorage = localStorage.getItem('atollSchema');
    	if (fuseSiteId) {
            fetchSiteNameFromlocalStorage = fuseSiteId;
        }else{
            fetchSiteNameFromlocalStorage = localStorage.getItem('fuzeSiteId');
        }

        if(fetchSiteNameFromlocalStorage!=null && fetchSiteNameFromlocalStorage!=''){
        	fuzeSiteIdPresent = fetchSiteNameFromlocalStorage;
            getSiteVersionCommonSearch(fetchSiteNameFromlocalStorage);
        }
        fetchSiteVersionFromlocalStorage = [rfdsVersion];
    }
    else{
        fetchSchemaFromlocalStorage = localStorage.getItem('atollSchema');
        fetchSiteNameFromlocalStorage = localStorage.getItem('fuzeSiteId');
        fetchSiteVersionFromlocalStorage = localStorage.getItem('siteVersion');
        fetchSiteNameFromlocalStorage = fetchSiteNameFromlocalStorage? fetchSiteNameFromlocalStorage.replace(/["']/g, "") : '';
    }

    
    if(fetchSiteVersionFromlocalStorage && fetchSiteVersionFromlocalStorage.includes('[')){
        fetchSiteVersionFromlocalStorage = fetchSiteVersionFromlocalStorage.replace(/["']/g, "").replace(/[[\]]/g, '');
    }

    for (var i = 0; i < fetchLinksData.length; i++) {
        if (fetchLinksData[i].rfModule == typeOfModule) {
            getLink = fetchLinksData[i].link;
            if (urlName != 'RfdsService') {
                var isSchemaSelected = $('#' + document.querySelectorAll('#schemaDiv select')[0].id).val();
            }

            if (`${CONTEXT_PATH}` + fetchLinksData[i].link != window.location.pathname) {
                if (urlName == 'RfdsService') {
                    if (fetchSiteNameFromlocalStorage) {
                        window.open(`${CONTEXT_PATH}` + getLink + "?fuzeSiteId=" + fetchSiteNameFromlocalStorage + "&siteVersion=" + fetchSiteVersionFromlocalStorage, '_blank');
                    } else {
                        window.open(`${CONTEXT_PATH}` + getLink);
                    }
                } else if (!isSchemaSelected || isSchemaSelected == 'None Selected') {
                    window.open(`${CONTEXT_PATH}` + getLink);
                } else if (typeOfModule == 'RFDS') {
                    switchToRfdsScreen();
                } else {
                    window.open(`${CONTEXT_PATH}` + getLink + "?fuzeSiteId=" + fetchSiteNameFromlocalStorage + "&siteVersion=" + fetchSiteVersionFromlocalStorage, '_blank');
                }
            }
        }
    }
}

function switchToRfdsScreen() {
    if (fetchSiteVersionFromlocalStorage != null) {
        fetchSiteVersionFromlocalStorage = fetchSiteVersionFromlocalStorage.split(',');
    }
                   // window.open(`${CONTEXT_PATH}` + getLink + "?fuzeSiteId=" + fetchSiteNameFromlocalStorage + "&siteVersion=" + fetchSiteVersionFromlocalStorage, '_blank');
                  if ((fetchSiteVersionFromlocalStorage==null)||((fetchSiteNameFromlocalStorage) && (fetchSiteVersionFromlocalStorage.length !== 1))) {
                        //  window.open(`${CONTEXT_PATH}` + getLink + "?fuzeSiteId=" + fetchSiteNameFromlocalStorage + "&siteVersion=" + fetchSiteVersionFromlocalStorage, '_blank');
                        window.open(`${CONTEXT_PATH}` + getLink + "?fuzeSiteId=" + fetchSiteNameFromlocalStorage, '_blank');
                    } else if ((fetchSiteNameFromlocalStorage) && (fetchSiteVersionFromlocalStorage.length === 1 && fetchSiteVersionFromlocalStorage[0])) {
                        fetchProjectNumber(fetchSiteNameFromlocalStorage);

                        for (const prop in extractProjectNumber) {
                            const value = extractProjectNumber[prop];
                            if (value.startsWith(fetchSiteVersionFromlocalStorage[0])) {
                                const matches = value.match(/\([^)]+\)/g);
                                if (matches && matches.length >= 2) {
                                    const extractedProjectNumberValue = matches[1].slice(1, -1);
                                    if (extractedProjectNumberValue) {
                                        extractedProjectNumberArray.push(extractedProjectNumberValue);
                                    }
                                }
                            }
                        }
                        const uniqueProjectNumbers = [...new Set(extractedProjectNumberArray)];
                        if (uniqueProjectNumbers.length > 0) {
                            const parts = getLink.split('/');
                            if (parts.length > 0) {
                                parts[parts.length - 1] = 'RfdsService';
                                getRfdsSubmitLink = parts.join('/');
                            }
                            window.open(`${CONTEXT_PATH}` + getRfdsSubmitLink + "?projectnumber=" + uniqueProjectNumbers[0] + "&fuzeSiteId=" + fetchSiteNameFromlocalStorage, '_blank');
                        } else {
                            window.open(`${CONTEXT_PATH}` + getLink + "?fuzeSiteId=" + fetchSiteNameFromlocalStorage, '_blank');
                        }
                    } else if ((fetchSiteNameFromlocalStorage) && (fetchSiteVersionFromlocalStorage.length === 1 && !fetchSiteVersionFromlocalStorage[0])) {
                        window.open(`${CONTEXT_PATH}` + getLink + "?fuzeSiteId=" + fetchSiteNameFromlocalStorage, '_blank');
                    }
                    else {
                        window.open(`${CONTEXT_PATH}` + getLink);
                    }
                }
            
function fetchProjectNumber(fetchSiteNameFromlocalStorage){
    var versionPayloadSV = [fetchSiteNameFromlocalStorage];
    $.ajax({
        type: 'POST',
        async: false,
       // url: "https://nppatolluat-east1.ebiz.verizon.com/plan-rfds/site-version-controller/fetchSiteVersion",
        url: fetchSiteVersionFromRfdsUrl,
        dataType: 'json',
        data: JSON.stringify(versionPayloadSV),
        type: "POST",
        contentType: 'application/json',
        cache: false,
        headers: {
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json'
        },
        success: function (data) {
            
            extractProjectNumber=data[0].siteRecords;

        }
    });

}
function fetchRfdsInputs(fusesiteId, projectNumber) {
    if (fusesiteId[0] != null && fusesiteId[0] != '') {
        $.ajax({
            type: 'POST',
            async: false,
            // url: "https://nppatolluat-east1.ebiz.verizon.com/npp-atoll-services/atollUtility/getSchemaIdentify",
            url: getSchemaFromFuseSiteId,
            dataType: 'json',
            data: JSON.stringify([fusesiteId]),
            contentType: 'application/json',
            cache: false,
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            success: function (data) {
                rfdsSchema = data.data[0].schema;
                fetchSchemaFromlocalStorage = rfdsSchema;
                fetchSchemaFromlocalStorage = fetchSchemaFromlocalStorage.replace(/['"]+/g, '')
                localStorage.setItem('atollSchema', fetchSchemaFromlocalStorage);
            }
        });
    } else if (projectNumber != null && projectNumber != '') {
        var projectNumberPayload = [projectNumber];
        $.ajax({
            type: 'POST',
            async: false,
            // url: "https://nppatolluat-east1.ebiz.verizon.com/npp-atoll-services/atollUtility/fetchSchemaAndFuzeSiteIdByProjectNumber",
            url: fetchSchemaAndFuzeSiteIdByProjectNumberURL + projectNumber,
            dataType: 'json',
            data: JSON.stringify(projectNumberPayload),
            contentType: 'application/json',
            cache: false,
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            success: function (data) {
                rfdsSchema = data.data[0].schema;
                fuseSiteId = data.data[0].fuzeSiteIdList[0];
                fetchSiteNameFromlocalStorage = data.data[0].fuzeSiteIdList[0];
                fetchSchemaFromlocalStorage = rfdsSchema;
                fetchSchemaFromlocalStorage = fetchSchemaFromlocalStorage.replace(/['"]+/g, '')
                localStorage.setItem('fuzeSiteId', fetchSiteNameFromlocalStorage);
                localStorage.setItem('atollSchema', fetchSchemaFromlocalStorage);

            },
            error: function (data) {
                localStorage.setItem('fuzeSiteId', '');
            }
        });
    }
}
