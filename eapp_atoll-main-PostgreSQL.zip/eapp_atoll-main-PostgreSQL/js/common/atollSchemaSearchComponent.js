var sechmaListCommonSearch = 'None Selected';
var commonSearchSelectedsiteversion = [];
var selectedCommonSearchSitename;
var commonSchemaSearchPayload = {};
var commonSearchResetId;
var globalParentId;
var fuzeSiteIdPresent;
var siteAutoAjax;
var rfdsVersion;
var projectNumber;
var routerParams = {};
var atollSchemaRes;
var selectedSiteName;
function commonSchemaSearch(parentId) {

var commonAtollSchemaSearch = $('<div style="margin-bottom: 0px" id="commonAtollSchemaSearch"></div>');
 $('#commonSchemaSearch').append(commonAtollSchemaSearch);

 fetchCommonSchemaList(parentId);

 var siteNameId = fetchSiteName(parentId);
	var siteVersionId = fetchSiteVersion(parentId);
	var resetAndSearchButton = $(`<div style="float: left; margin-left: 5px;margin-top: 24px;"> <button class="btn btn-default" id="resetBtn" onclick="clearAtollSchemaSearchData(${parentId})" style="height: 25px;min-height: 25px;line-height: 25px;margin-top: 0px;border-radius: 3px !important;font-size: 14px;width: 90px;padding: 0 20px;">Reset</button> <button class="btn btn-danger" id="searchBtn" onclick="onCommonSearchClick('${parentId}')" style="margin-left: 10px;height: 25px;min-height: 25px;line-height: 25px;margin-top: 0px;border-radius: 3px !important;font-size: 14px;width: 90px;padding: 0 20px;">Search</button></div>`);
	if(featureToggleMap["F94118"] && window?.location?.href?.includes("atollSiteHistory")){
		resetAndSearchButton = $(`<div style="float: left; margin-left: 5px;margin-top: 24px;"> <button class="btn btn-default" id="resetBtn" onclick="clearAtollSchemaSearchData(${parentId})" style="height: 25px;min-height: 25px;line-height: 25px;margin-top: 0px;border-radius: 3px !important;font-size: 14px;width: 90px;padding: 0 20px;">Reset</button> <button class="btn btn-danger" id="searchBtn" onclick="onCommonSearchClick('${parentId}')" style="margin-left: 10px;height: 25px;min-height: 25px;line-height: 25px;margin-top: 0px;border-radius: 3px !important;font-size: 14px;width: 90px;padding: 0 20px;">Search</button><button onclick="exportHistoryGridDataToExcel()" class="btn btn-danger" style="margin-left: 10px;height: 25px;min-height: 35px;line-height: 25px;margin-top: 0px;border-radius: 3px !important;font-size: 14px;width: 150px;padding: 0 20px;">Export To Excel</button></div>`);
	}
	if (parentId != 'commonScheduleComp') {
		$('#' + parentId).append(resetAndSearchButton);
	}
 //reloadData();
 $.widget("custom.catautocomplete", $.ui.autocomplete, {
	_create: function() {
		this._super();
		this.widget().menu("option", "items", "> :not(.ui-autocomplete-category)");
	},
	_renderMenu: function(ul, items) {
		var self = this;
		var current = "";
		$.each(items, function(index, item) {
			if (item.category != current) {
				ul.append("<li class='ui-autocomplete-category'>" + item.category + "</li>");
				current = item.category;
			}
			self._renderItemData(ul, item);
		});
	},
});

buildCatautoForSiteName($('#' + siteNameId), parentId, siteVersionId);

}

// fetch Schema List for parent div (Id)
function fetchCommonSchemaList(commonSchemaListID) {
	var dropdownId = commonSchemaListID+'Schemalist';
	console.log('dropdownId===>', dropdownId);
	var schemaListDiv = $(`<div style="width:20%; float: left;" id="schemaDiv"><label for=${dropdownId}><b>Atoll Schema</b><span style="color:red;">*</span></label> <select name=${dropdownId} id=${dropdownId} onChange="selectSchema(${dropdownId})"></select></div>`);
	$('#' + commonSchemaListID).append(schemaListDiv);
	getUserCommonSchema(dropdownId, '');
}

// fetch Site version  for parent div (Id)
function fetchSiteVersion(siteVersionId) {
	var siteVersionListId = siteVersionId + 'VersionList';
	var commonSearchSiteVersion = $(`<div class="form-group" style="width: 20%; float: left; margin-left: 15px;"> <label for=${siteVersionListId}><b>Site Version (Site Record) (Project ID)</b></label><select class="form-control js-data-example-ajax" placeholder="Search by Site Version" id=${siteVersionListId} name=${siteVersionListId} multiple="multiple" onChange="selectSiteVesion(${siteVersionListId})"></select></div>`);
	$('#' + siteVersionId).append(commonSearchSiteVersion);
	return siteVersionListId;
}

// fetch SiteName for parent div (Id)
function fetchSiteName(siteNameId) {
	var siteNameListId = siteNameId + 'SiteName';
	var commonSearchSiteName = $(`<div style="width:21%; float: left; margin-left: 15px;" class="siteNameDropdownStyling"><label for=${siteNameListId}><b>Site Name/Fuze Site Id</b><span style="color:red;">*</span></label></label><br /> <input id=${siteNameListId} title="Search by Site Name" type="text" style="height: 28px;width:100%;padding-left: 10px;border-radius: 0;" placeholder="Search by Site Name"></div>`);
	$('#' + siteNameId).append(commonSearchSiteName);
	return siteNameListId;
}

// reset functionality for common search reference by parent div (Id)
function clearAtollSchemaSearchData(resetDivId) {
	var selectUrl = window.location.pathname.split('/');
	var urlName = selectUrl[selectUrl.length-1];
if (resetDivId.id) {
		commonSearchResetId = resetDivId.id;
	}
	if (urlName == 'gNodeBinfo') {
		clearAtollUpdate();
	} else if(urlName === 'zitePCI') {
        clearPciRsiInfo();
	}else if(urlName == 'versionSearchPage'){
		clearAtollSiteManagementInfo();
	} else if(urlName == 'e911Jspreadsheet') {
		e911ResetClick();
	} else if(urlName == 'e911Report') {
		e911ReportResetClick();
	}else if(urlName == 'scheduleUpdates'){
		commonSearchResetId = resetDivId;
		clearCommonSearchDropdown();
	}
	else if(urlName === "atollSiteHistory"){
		clearAtollSiteHistoryDropdowns();
	}
}

// based on the popup user wants to reset or cancel 
function clearCommonSearchDropdown() {
	atollSchemaSearchDropdown = 'None selected';
	sechmaListCommonSearch = '';
	selectedCommonSearchSitename = '';
	commonSearchSelectedsiteversion = [];
	commonSchemaSearchPayload = {
		atollSchema: "",
		siteName: "",
		siteVersion: [""],
	}
	if(commonSearchResetId == 'commonScheduleComp'){
		let schemaList = commonSearchResetId +'Schemalist';
		let cronJob = 'commonSchedulerNameList';
		let siteVersionList = commonSearchResetId + 'VersionList';
		let siteNameSelected = commonSearchResetId + 'SiteName';
		buildCatautoForSiteName($('#' + siteNameSelected), commonSearchResetId, siteVersionList);
		$('#' + schemaList).html("");
		$('#' + schemaList).multiselect("rebuild");
		$('#' + schemaList).multiselect({
			includeSelectAllOption: true,
			enableFiltering: true,
			enableCaseInsensitiveFiltering: true,
			buttonClass: 'btn btn-default whitebg btn-sm',
			numberDisplayed: 1,
			nonSelectedText: 'None selected'
		});
		$('#' + cronJob).html("");
		$('#' + cronJob).multiselect("rebuild");
		$('#' + cronJob).multiselect({
			includeSelectAllOption: true,
			enableFiltering: true,
			enableCaseInsensitiveFiltering: true,
			buttonClass: 'btn btn-default whitebg btn-sm',
			numberDisplayed: 1,
			nonSelectedText: 'None selected'
		});
		$('#' + siteVersionList).html("");
		$('#' + siteVersionList).multiselect("rebuild");
		$('#' + siteVersionList).multiselect({
			includeSelectAllOption: true,
			enableFiltering: true,
			enableCaseInsensitiveFiltering: true,
			buttonClass: 'btn btn-default whitebg btn-sm',
			numberDisplayed: 1,
			nonSelectedText: 'None selected'
		});
		
		$("#" + siteNameSelected).val('');
		//call get schema list function
		getUserCommonSchema(schemaList, '');
		getSchedulerNameCommon('#'+cronJob, '#' + siteNameSelected);
		scheduleUpdatesEmptyTable();
		sechmaListCommonSearch = '';
		selectedCommonSearchSitename = '';
		commonSearchSelectedsiteversion = [];
	}else{
		// reset as per the parent div ID 
		let schemaList = commonSearchResetId +'Schemalist';
		let siteVersionList = commonSearchResetId + 'VersionList';
		let siteNameSelected = commonSearchResetId + 'SiteName';

		buildCatautoForSiteName($('#' + siteNameSelected), commonSearchResetId, siteVersionList);
		$('#' + schemaList).html("");
		$('#' + schemaList).multiselect("rebuild");
		$('#' + schemaList).multiselect({
			includeSelectAllOption: true,
			enableFiltering: true,
			enableCaseInsensitiveFiltering: true,
			buttonClass: 'btn btn-default whitebg btn-sm',
			numberDisplayed: 1,
			nonSelectedText: 'None selected'
		});
		$('#' + siteVersionList).html("");
		$('#' + siteVersionList).multiselect("rebuild");
		$('#' + siteVersionList).multiselect({
			includeSelectAllOption: true,
			enableFiltering: true,
			enableCaseInsensitiveFiltering: true,
			buttonClass: 'btn btn-default whitebg btn-sm',
			numberDisplayed: 1,
			nonSelectedText: 'None selected'
		});

		$("#" + siteNameSelected).val('');
		//call get schema list function
		getUserCommonSchema(schemaList, '');
		sechmaListCommonSearch = '';
		selectedCommonSearchSitename = '';
		commonSearchSelectedsiteversion = [];
		
	}
	localStorage.setItem('siteVersion', '');
	localStorage.setItem('atollSchema', '');
	localStorage.setItem('fuzeSiteId', '');
}

// on page load fetching the schema list as per the parent div (Id)
function getUserCommonSchema(dropdownId, selectedAtollSchema) {

	$.ajax({
		async: false,
		url: getAtollSchemaData,
		// url: 'http://localhost:8100/npp-atoll-services/enbgnbAssignment/getAtollSchema',
		dataType: 'json',
		type: "POST",
		contentType: 'application/json; charset=UTF-8',
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function(data) {
            atollSchemaRes = data;
		},
		error: function(data) {
			aptAlert('Warning', 'Failed to load atollSchema data!');
		}
	});
	$('#' + dropdownId).html('');
	$('#' + dropdownId).multiselect('destroy');
	$('#' + dropdownId).append("<option>None Selected</option>");
if (selectedAtollSchema) {
		$.each(atollSchemaRes, function(i, v) {
			if(selectedAtollSchema.toUpperCase() == v) {
				$('#' + dropdownId).append("<option selected>" + v + "</option>");
			}
			else {
				$('#' + dropdownId).append("<option>" + v + "</option>");
			}
		});
		if(isParamPresentInUrl) {
			selectSchema(globalParentId);
			runSiteAutocompleteFromUrl(selectedCommonSearchSitename, selectedAtollSchema);
			if(selectedCommonSearchSitename) {
				// $('#'+globalParentId+'SiteName').val(selectedCommonSearchSitename);
				getSiteVersionCommonSearch(selectedCommonSearchSitename, selectedAtollSchema, globalParentId+'VersionList', commonSearchSelectedsiteversion);
			}
		}
		
	}
	else {
	$.each(atollSchemaRes, function(i, v) {
		$('#' + dropdownId).append("<option>" + v + "</option>");
	});
	$('#' + dropdownId).val('', '');
}
	$('#' + dropdownId).multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
		nonSelectedText: 'None selected'

	});
}

// selecting schema value and update other dropdown
function selectSchema(schemaValue) {
	if (schemaValue.id) {
    var schemaDropdownId = schemaValue.id;
	} else {
		var schemaDropdownId = schemaValue +'Schemalist';
	}
    sechmaListCommonSearch = '';
	$("#"+ globalParentId + 'SiteName').val('');
	sechmaListCommonSearch = $('#' + schemaDropdownId).val();
	localStorage.setItem('atollSchema', sechmaListCommonSearch);
    sechmaList = sechmaListCommonSearch;
	if (sechmaListCommonSearch == 'None Selected') {
		sechmaListCommonSearch = '';
	}
	if (sechmaListCommonSearch != 'None Selected') {
		var temp = $('#' + globalParentId + 'VersionList').val();
		if (temp != null) {
			$('#' + globalParentId + 'VersionList').html("");
			$('#' + globalParentId + 'VersionList').multiselect("rebuild");
			$('#' + globalParentId + 'VersionList').multiselect({
				includeSelectAllOption: true,
				enableFiltering: true,
				enableCaseInsensitiveFiltering: true,
				buttonClass: 'btn btn-default whitebg btn-sm',
				numberDisplayed: 1,
				nonSelectedText: 'None selected'
			});
		}
		$("#"+ globalParentId + 'SiteName').val('');

	}
	var selectUrl = window.location.pathname.split('/');
	var urlName = selectUrl[selectUrl.length-1];
	if(urlName === "gNodeBinfo" && sechmaListCommonSearch != ''){
		getAtollMarketDb(sechmaListCommonSearch);
		$("#atollMarketDb").multiselect("enable");
	} else {
		$('#atollMarketDb').html('');
	$('#atollMarketDb').multiselect('destroy');
	$('#atollMarketDb').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,

	});
	$("#atollMarketDb").multiselect("disable");
	}
return sechmaListCommonSearch;
}

// auto complete dropdown select the siteName
function buildCatautoForSiteName(element, parentId, siteVersionId) {
	$('#' + siteVersionId).html("");
	$('#' + siteVersionId).multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
		nonSelectedText: 'None selected'
	});
	$(element).catautocomplete({
		minLength: 2,
		delay: 600,
		source: function(request, response) {
			$(element).addClass("ui-autocomplete-loading");
			var term = request.term;
			var suggestions = [];
			runSiteAutocompleteSearch(term, siteVersionId).then(function(results) {
				if (!results || !results.data || results.data.length == 0) {
					suggestions.push({ label: "Not Found.", value: "Not found.", category: "Site Results" });
					siteNameGlobal = term;
					// fuzeSiteIdGlobal = term;
				} else {
					var obj = _.map(results.data, function convertResult(result) {
						return {
							// label: result.NAME,
							label: "(" + result.VZ_SITE_INFO_ID + ") " + result.VZ_SITE_NAME,
							value: result.VZ_SITE_NAME,
							siteName: result.VZ_SITE_NAME,
							fuzeSiteId: result.VZ_SITE_INFO_ID,
							category: "Site Results",
						};
					});
					suggestions = obj
					//	getSiteVersion();
				}
				response(_.flatten(_.filter(suggestions, Boolean)));
				$(element).removeClass("ui-autocomplete-loading");
			});
		},
		select: function(event, ui) {
			$(element).removeClass("ui-autocomplete-loading");
			// fuzeSiteIdGlobal = ui.item.fuzeSiteId;
			////console.log(event);
			selectedCommonSearchSitename = ui.item.label;
			isParamPresentInUrl = false;
			localStorage.setItem('fuzeSiteId', JSON.stringify(selectedCommonSearchSitename));
			var temp = $('#' + siteVersionId).val();
			if (temp != null && selectedCommonSearchSitename != '') {
				$('#' + siteVersionId).html("");
				$('#' + siteVersionId).multiselect("rebuild");
				$('#' + siteVersionId).multiselect({
					includeSelectAllOption: true,
					enableFiltering: true,
					enableCaseInsensitiveFiltering: true,
					buttonClass: 'btn btn-default whitebg btn-sm',
					numberDisplayed: 1,
					nonSelectedText: 'None selected'
				});
			}
			// selectedCommonSearchSitename = 'BELL_MOUNTAIN';
			sechmaListCommonSearch = $('#'+ parentId + 'Schemalist').val();
			fuzeSiteIdPresent = selectedCommonSearchSitename.substring( selectedCommonSearchSitename.indexOf( '(' ) + 1, selectedCommonSearchSitename.indexOf( ')' ) );
			selectedSiteName = fuzeSiteIdPresent;
			if (fuzeSiteIdPresent == "null") {
				fuzeSiteIdPresent = '';
				selectedCommonSearchSitename = selectedCommonSearchSitename.substring(selectedCommonSearchSitename.indexOf(' ') + 1);
				getSiteVersionCommonSearch(selectedCommonSearchSitename, sechmaListCommonSearch, siteVersionId, []);
			}
			var selectUrl = window.location.pathname.split('/');
            var urlName = selectUrl[selectUrl.length-1];
            if(urlName === "versionSearchPage"){
				fuzeSiteIdPresent = '';
                selectedCommonSearchSitename = selectedCommonSearchSitename.substring(selectedCommonSearchSitename.indexOf(' ') + 1);
            }
			if (fuzeSiteIdPresent) {
				selectedCommonSearchSitename = fuzeSiteIdPresent;
				localStorage.setItem('fuzeSiteId', JSON.stringify(selectedCommonSearchSitename));
				getSiteVersionCommonSearch(selectedCommonSearchSitename, sechmaListCommonSearch, siteVersionId, []);

			} else if (!selectedCommonSearchSitename || selectedCommonSearchSitename == undefined) {
				alert('please select correct site name');
				// getSiteVersionCommonSearch(selectedCommonSearchSitename, sechmaListCommonSearch);
			} else {
				getSiteVersionCommonSearch(selectedCommonSearchSitename, sechmaListCommonSearch, siteVersionId, []);
			}

		}
	});
}

function runSiteAutocompleteSearch(term, siteVersionId, response) {
	if (siteAutoAjax) {
		siteAutoAjax.abort();
		siteAutoAjax = null;
	}
	commonSearchSelectedsiteversion = [];
	$('#' + siteVersionId).html("");
	$('#' + siteVersionId).multiselect("rebuild");
	$('#' + siteVersionId).multiselect('deselectAll', false);
	$('#' + siteVersionId).multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
		nonSelectedText: 'None selected'
	});
	term = term.toUpperCase();
	siteAutoAjax = $.get(CONTEXT_PATH + "/uui/eapp/atoll_pg/siteAutocomplete", { query: term, atollSchema: sechmaListCommonSearch }).success().error(
		function handleError(error) {
			// console.error("Something went wrong with the site search", error);
			return [];
		}
	);
	return siteAutoAjax;
}

// save search data in local storage key value pair
function saveLocalSearchData() {
	localStorage.setItem('atollSchema', sechmaListCommonSearch);
	localStorage.setItem('fuzeSiteId', JSON.stringify(selectedCommonSearchSitename));
	localStorage.setItem('siteVersion', JSON.stringify(commonSearchSelectedsiteversion));
}
function onCommonSearchClick(parentId) {
	var selectUrl = window.location.pathname.split('/');
	var urlName = selectUrl[selectUrl.length-1];
var selectedSiteVersion = [];
	console.log('urlName', urlName);
	sechmaListCommonSearch = $('#'+ parentId + 'Schemalist').val();
	// selectedCommonSearchSitename =  $('#'+ parentId + 'SiteName').val();
	commonSearchSelectedsiteversion = $('#'+ parentId + 'VersionList').val() ? $('#'+ parentId + 'VersionList').val(): [];
    commonSearchSelectedsiteversion.forEach(element => {
		selectedSiteVersion.push(element.split(' ')[0]);
	});
    atollSchemaCommonSearch(parentId, sechmaListCommonSearch, selectedCommonSearchSitename, selectedSiteVersion, urlName)
}
// Common atoll schema search as per the Id
function atollSchemaCommonSearch(parentId, atollSchema, siteName, siteVersion, screenName) {
	
	globalParentId = parentId;
	sechmaListCommonSearch = atollSchema;
	selectedCommonSearchSitename = siteName;
	commonSearchSelectedsiteversion = siteVersion;

	if (isParamPresentInUrl) {
		runSiteAutocompleteFromUrl(selectedCommonSearchSitename, atollSchema);
	}
	
    if (screenName == 'gNodeBinfo') {
		if(atollSchema && siteName && siteVersion)  {
        $("#gnodebtab").removeClass('active');
        $("#atollUpdateTab").addClass('active');
         PopulateGbEbTabs(3);
		}
		
		getUserCommonSchema(globalParentId+'Schemalist', atollSchema);
        commonSchemaSearchPayload = {
            atollSchema: sechmaListCommonSearch,
            siteName: selectedCommonSearchSitename,
            siteVersion: commonSearchSelectedsiteversion,
        }
        if (commonSchemaSearchPayload.atollSchema && commonSchemaSearchPayload.siteName) {
            $("#loading").addClass('loading-icon');
			// save search data in local storage
			saveLocalSearchData();
            getVirtualAssignmentSummeryDetails();
        } else {
            alert('Please Select All the Mandatory Dropdowns');
        }
    } else if (screenName === "zitePCI") {
getUserCommonSchema(globalParentId+'Schemalist', atollSchema);
        commonSchemaSearchPayload = {
            atollSchema: sechmaListCommonSearch,
            siteName: selectedCommonSearchSitename,
            siteVersion: commonSearchSelectedsiteversion,
        }
        getPCIRSIInfoSummery();
    }else if (screenName === "e911Jspreadsheet") {
        getUserCommonSchema(globalParentId+'Schemalist', atollSchema);
        commonSchemaSearchPayload = {
            atollSchema: sechmaListCommonSearch,
            siteName: selectedCommonSearchSitename,
            siteVersion: commonSearchSelectedsiteversion,
        }
        searchSiteNameAndVersion();
    } else if(screenName === "versionSearchPage"){
		commonSchemaSearchPayload =  {
			atollSchema: sechmaListCommonSearch,
			siteName: selectedCommonSearchSitename,
			siteVersion: commonSearchSelectedsiteversion,
		}
		if (commonSchemaSearchPayload.atollSchema && commonSchemaSearchPayload.siteName && commonSchemaSearchPayload.siteVersion) {
			searchButtonIntegration();
		}else{
			alert('Please Select All the Mandatory Dropdowns');
		}
	} else if(screenName === "siteSearch"){
		commonSchemaSearchPayload =  {
				atollSchema: sechmaListCommonSearch,
				siteName: selectedCommonSearchSitename,
			}
			if (commonSchemaSearchPayload.atollSchema && commonSchemaSearchPayload.siteName) {
				getSiteGridDetail(commonSchemaSearchPayload);
			}
} else if (screenName === "e911Report") {
			getUserCommonSchema(globalParentId+'Schemalist', atollSchema);
			sechmaListCommonSearch = atollSchema;
			commonSchemaSearchPayload = {
				atollSchema: sechmaListCommonSearch,
				siteName: selectedCommonSearchSitename,
				siteVersion: commonSearchSelectedsiteversion,
			}
			if (commonSchemaSearchPayload.atollSchema && commonSchemaSearchPayload.siteName) {
				reloadData();
			} else {
				alert('Please Select All the Mandatory Dropdowns');
			}
}else if (screenName === "scheduleUpdates") {
	getUserCommonSchema(globalParentId+'Schemalist', atollSchema);
	commonSchemaSearchPayload = {
			atollSchema:sechmaListCommonSearch,
			siteName: selectedCommonSearchSitename,
			siteVersion: commonSearchSelectedsiteversion,
			cronjob: $('#commonSchedulerNameList').val(),
	}
	getScheduleUpdatesData();

}
	else if(featureToggleMap && featureToggleMap["F94118"] && screenName==="atollSiteHistory"){
		fetchAtollSiteHistoryData();
	}
}

const checkSiteRecordIdPresent = (data) => {
	return data && data[0] && data[0].siteRecords && Object.values(data[0].siteRecords).length;
}

// After selecting schema and sitename we are fetching site version
function getSiteVersionCommonSearch(changevaluesitename, sechmaList, siteVersionId, selectedSiteVersionList) {
	var selectUrl = window.location.pathname.split('/');
    var urlName = selectUrl[selectUrl.length-1];
	if ((fuzeSiteIdPresent || routerParams.fuzeSiteId) && urlName != "versionSearchPage") {
		if (routerParams.fuzeSiteId && isParamPresentInUrl) {
			changevaluesitename = routerParams.fuzeSiteId;
		}
		var versionPayload = [changevaluesitename];
		$.ajax({
			async: false,
			url: fetchSiteVersionFromRfdsUrl,
			// url: 'https://nppranuat-east1.ebiz.verizon.com/plan-rfds/siteversion/fetchSiteVersion',
			dataType: 'json',
			data: JSON.stringify(versionPayload),
			type: "POST",
			contentType: 'application/json; charset=UTF-8',
			headers: {
				'Accept': 'application/json, text/plain, */*',
				'Content-Type': 'application/json'
			},
			success: function (data) {
				if(featureToggleMap && featureToggleMap["F94118"] && data && data[0]?.result?.toLowerCase()!="success" && selectUrl && selectUrl.includes("atollSiteHistory")){
					showError("Error fetching version data: "+data[0]?.result);
					setTimeout(() => hideProgress(), 5000);
				}
				else if(featureToggleMap && featureToggleMap["F94118"] && data && !checkSiteRecordIdPresent(data) && selectUrl && selectUrl.includes("atollSiteHistory")){
					showError("No Site Records found");
					setTimeout(() => hideProgress(), 5000);
				}
				getSitesV = [];
				var siteVersionArr = [];
				var siteVersionObj = {};
				console.log('roles Data ===>', data);
				for (const prop in data[0].siteRecords) {
					siteVersionObj = { 'siteVersion': data[0].siteRecords[prop] };
					siteVersionArr.push(siteVersionObj);
				}
				getSitesV = siteVersionArr;
				localStorage.setItem("fetchedSiteVersionsLength",getSitesV.length);	

			},
			error: function (data) {
				aptAlert('Warning', 'Failed to load site version data!');
			}
		});
	} else {
		var versionPayload = {
			atollSchema: sechmaList,
			siteName: changevaluesitename,
		}
		$.ajax({
			async: false,
			url: getSiteVersionsURL,
			//url: 'http://localhost:8100/npp-atoll-services/enbgnbAssignment/getSiteVersions',
			dataType: 'json',
			data: JSON.stringify(versionPayload),
			type: "POST",
			contentType: 'application/json; charset=UTF-8',
			headers: {
				'Accept': 'application/json, text/plain, */*',
				'Content-Type': 'application/json'
			},
			success: function (data) {
				getSitesV = data;
				console.log('getSitesV', getSitesV);
			},
			error: function (data) {
				aptAlert('Warning', 'Failed to load site version data!');
			}
		});
	}

	if(urlName!='RfdsService'){
		$('#' + siteVersionId).html('');
		$('#' + siteVersionId).multiselect('destroy');
if(selectedSiteVersionList != null) {
		if (selectedSiteVersionList.length > 0) {
			for (var i = 0; i < getSitesV.length; i++) {
				var selectOnlySiteVersion;
				if (getSitesV[i].siteVersion.includes('(')) {
					selectOnlySiteVersion = getSitesV[i].siteVersion.substring(0, getSitesV[i].siteVersion.indexOf(' '));
				} else {
					selectOnlySiteVersion = getSitesV[i].siteVersion;
				}
				if (selectedSiteVersionList.includes(selectOnlySiteVersion)) {
					$('#' + siteVersionId).append("<option selected>" + getSitesV[i].siteVersion
							+ "</option>");
				}
				else {
					$('#' + siteVersionId).append("<option>" + getSitesV[i].siteVersion
							+ "</option>");
				}
			}
		}
		else {
			if (getSitesV.length > 0) {
				for (var i = 0; i < getSitesV.length; i++) {
					$('#' + siteVersionId).append("<option>" + getSitesV[i].siteVersion
							+ "</option>");
}
				}
			}
		}


		$('#' + siteVersionId).multiselect({
			includeSelectAllOption: true,
			enableFiltering: true,
			enableCaseInsensitiveFiltering: true,
			buttonClass: 'btn btn-default whitebg btn-sm',
			numberDisplayed: 1,


		});
	} else{
		getSitesV.forEach(element => {
			if(element.siteVersion.includes(' ')){
				var val= '(' + $('#projectNumberSelect').val() + ')';
				if((val) == element.siteVersion.split(' ')[2]){
					rfdsVersion = element.siteVersion.split(' ')[0];
				}
			}
		});
	}
}

// onChange Method For selected multi select siteVesion 
function selectSiteVesion(siteVersionListId) {
	var selectedSiteVersion = [];
	if (siteVersionListId.id) {
		commonSearchSelectedsiteversion = $('#'+ siteVersionListId.id).val();
	} else {
		commonSearchSelectedsiteversion = $('#'+ siteVersionListId + 'VersionList').val();
	}
	if(commonSearchSelectedsiteversion != null) {
	commonSearchSelectedsiteversion.forEach(element => {
		selectedSiteVersion.push(element.split(' ')[0]);
	});
	}
	commonSearchSelectedsiteversion = selectedSiteVersion;
	localStorage.setItem('siteVersion', JSON.stringify(commonSearchSelectedsiteversion));
};

// sitename autocomplete function
function siteNameAutoComplete() {
	$.widget("custom.catautocomplete", $.ui.autocomplete, {
		_create: function() {
			this._super();
			this.widget().menu("option", "items", "> :not(.ui-autocomplete-category)");
		},
		_renderMenu: function(ul, items) {
			var self = this;
			var current = "";
			$.each(items, function(index, item) {
				if (item.category != current) {
					ul.append("<li class='ui-autocomplete-category'>" + item.category + "</li>");
					current = item.category;
				}
				self._renderItemData(ul, item);
			});
		},
	});
}

function aptAlert(status, message, status1, message1) {
  $("#alertsuccess").hide();
  $("#alerterror").hide();
  $("#alertinfo").hide();
  $("#alertwarning").hide();

  $("#alertTitle").html(status + "!");
  $("#alert" + status.toLowerCase()).html(message);
  $("#alert" + status.toLowerCase()).show();
  if (message1) {
    $("#alert" + status1.toLowerCase()).html(message1);
    $("#alert" + status1.toLowerCase()).show();
  }
  $("#myModal").css(
    "margin-top",
    Math.max(0, ($(window).height() - ($("#myModal").height() + 100)) / 2)
  );
  $("#myModal").css(
    "margin-left",
    Math.max(0, ($(window).width() - $("#myModal").width()) / 2)
  );
  $("#myModal").modal("show");
}

// siteName auto populated when user fuzeSiteid entered from url
function runSiteAutocompleteFromUrl(term, atollSchema) {
	if((term && term != undefined && term.length > 1) && (atollSchema && atollSchema != undefined)) {
		$.ajax({
			url: CONTEXT_PATH + "/uui/eapp/atoll_pg/siteAutocomplete"+ '?query=' + term + '&atollSchema=' + atollSchema,
			// url: getUserRoleURL + userId,
			dataType: 'json',
			type: "GET",
			async: false,
			success: function(data) {
				console.log(' Data ===>', data);
				$('#'+globalParentId+'SiteName').val(data.data[0].VZ_SITE_NAME);
			},
			error: function(data) {
				console.log('Failed to load site data!');
			}
		});
	}
}
var schedulerUpdateResCommon = [];
var schedulerNameId = '';
var scheduleSiteNameId = '';
// get cron jobs list
function getSchedulerNameCommon(elementId, siteNameId) {
	schedulerNameId = elementId;
	scheduleSiteNameId = siteNameId;
	$.ajax({
		async: false,
		url: fetchSchedulerNameUrl,
		//url: 'http://localhost:8100/npp-atoll-services//scheduledUpdate/fetchSchedulerName',
		dataType: 'json',
		type: "POST",
		contentType: 'application/json; charset=UTF-8',
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function (data) {
			schedulerUpdateResCommon = data;

		},
		error: function (data) {
			// aptAlert('Warning', 'Failed to load atollSchema data!');
		}
	});
	$(elementId).html('');
	$(elementId).multiselect('destroy');
	$.each(schedulerUpdateResCommon, function (i, v) {
		$(elementId).append("<option>" + v + "</option>");
	});
	$(elementId).val('', '');
	$(elementId).multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,

	});
}

// if project number when we are passing from url then setting the siteversion
function updateSiteVersionDropdown(projectNumber, siteVersionId) {
	$('#' + siteVersionId + 'VersionList').html('');
	$('#' + siteVersionId + 'VersionList').multiselect('destroy');
		getSitesV.forEach(element => {
		if(element.siteVersion.includes(' ')) {
			var val= '(' + projectNumber + ')';
			if((val) == element.siteVersion.split(' ')[2]) {
				rfdsVersion = element.siteVersion.split(' ')[0];
				$('#' + siteVersionId + 'VersionList').append("<option selected>" + element.siteVersion
					+ "</option>");
			} else {
				$('#' + siteVersionId + 'VersionList').append("<option>" + element.siteVersion
						+ "</option>");
			}
		}
	});

	$('#' + siteVersionId + 'VersionList').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
	});
}