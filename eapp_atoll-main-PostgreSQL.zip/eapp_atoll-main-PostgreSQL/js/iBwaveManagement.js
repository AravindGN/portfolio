var grid = null
var siteDataGridColumns = [{"field": 'ACTION', "title": 'Actions', template:'<i title="Project Inforamtion" onclick="getProjectInfo(event)" class="fas fa-eye" style="cursor: pointer; z-index:100;margin-left:11px;"></i>',width:"50px"},{ title: 'Site Name', field: 'siteName', width:"175px" }, { title: 'Site ID', field: 'fuzeSiteId' }, { title: 'eNB/gNB', field: 'eNodebId' }, { title: 'PSLC#', field: 'pslc'},
	{ title: 'CLLI', field: 'clli'},{ title: 'Site Type', field: 'siteType' },{title: 'Solution Name', field: 'solutionname'}, { title: 'Status', field: 'status'},
	{ title: 'Address', field: 'address'}, { title: 'City', field: 'city'}, { title: 'State', field: 'state'},{ title: 'County', field: 'county'}];
var siteDatagrid;
var siteType=null;
var market=null;
var siteDataSource = new kendo.data.DataSource({
  data: [],
});
var loadOffScreenData = true;
var clearStatus = false;
var projectDataSource = new kendo.data.DataSource({
	data: [],
});
var leaf;
var t = XYZ.map();
var google_api_key = "AIzaSyBCDhGdiIbpa3jV-e7xuhwPfvJUUDZJNN8";
var attribution = "<span id='attributionSpan'>Cursor out of map bounds</span>";
var satellite_url = 'http://netgeo.vh.eng.vzwcorp.com/arcgis/rest/services/basemap_webmer/World_Imagery/MapServer/tile/{z}/{y}/{x}';
var grayscale_url = 'http://netgeo.vh.eng.vzwcorp.com/arcgis/rest/services/basemap_webmer/World_Topo_Map/MapServer/tile/{z}/{y}/{x}'
var streetmap_url = 'http://netgeo.vh.eng.vzwcorp.com/arcgis/rest/services/basemap_webmer/World_Street_Map/MapServer/tile/{z}/{y}/{x}';
var multiplier = 1.0;
var disableZoom = 20;
var splitClusters =null;
var tileOptions = { maxZoom: 19, minZoom: 2, opacity: .2, attribution: attribution, stamp: Date.now };
var clusterOptions = { maxRad: 1900, disableZoom: disableZoom, splitClusters: splitClusters };
var current_url = streetmap_url;
var defaultPageSize = 10;
var featureGroup = null;
var entireTerritoryList = [];
var entireAreaList = [];
var entireRegionList= [];
var entireMarketList = [];
var territoryDataProvider = [];
var areasDataProvider = [];
var regionsDataProvider = [];
var marketsDataProvider = [];
var siteStrucLocInfoObj = null;
var siteDetailsInfoObj = null;
var selectedSiteGridRowIndex = -1;
var selectedProjectGridRowIndex = -1;
var TERRITORY_DUMP = [];
var AREA_DUMP = [];
var REGION_DUMP = [];
var MARKET_DUMP = [];


function getSummaryColumns() {
	return [
		{	"field": 'ACTION', "title": 'Actions', template: function() {
				return '<i title="Edit" id="editProjectIcon" onclick="onProjectEditOrView(event, \'edit\')" class="fas fa-edit cloneIcon" style="cursor: pointer; z-index:100;float:left;margin-left:2px;"></i>';
			}, width: 50
		}, {
			"title": "Project Number",
			"field": "projectnumber",
			width: 50,			
  			headerAttributes: { style: "white-space: normal; overflow : visible"}
		}, {
			"title": "Project Name",
			"field": "projectname",
			width: 80,			
			headerAttributes: { style: "white-space: normal; overflow : visible"}
		},
		{
			"title": "NPP RFDS Project Id",
			"field": "rfdsProjectId",
			width: 80,			
			headerAttributes: { style: "white-space: normal; overflow : visible"}
		},
		{
			"title": "SPM RFDS Project Id",
			"field": "spmRfdsProjectId",
			width: 80,			
			headerAttributes: { style: "white-space: normal; overflow : visible"}
		},
		{
			"title": "Project Alt Name",
			"field": "projectdescription",
			width: 80,			
			headerAttributes: { style: "white-space: normal; overflow : visible"}
		}, {
			"title": "Project Template",
			"field": "projecttemplate",
			width: 80,			
			headerAttributes: { style: "white-space: normal; overflow : visible"}
		},
		{
			"title": "Project Status",
			"field": "projectstatus",
			width: 70,			
			headerAttributes: { style: "white-space: normal; overflow : visible"}
		},
		{
			"title": "Lock",
			"field": "lock",
			width: 80,			
			headerAttributes: { style: "white-space: normal; overflow : visible"}
		},
		{			
			"title": "FP Solution",
			"field": "fpSolution",
			width: 70,			
			headerAttributes: { style: "white-space: normal; overflow : visible"}
		}
		, {
			"title": "Created By",
			"field": "createdBy",
			width: 70,			
			headerAttributes: { style: "white-space: normal; overflow : visible"}
		}
		, {
			"title": "Created Date",
			"field": "createdDate",
			width: 70,			
			headerAttributes: { style: "white-space: normal; overflow : visible"}
		}
		, {
			"title": "Updated Date",
			"field": "updatedDate",
			width: 70,			
			headerAttributes: { style: "white-space: normal; overflow : visible"}
		}
		, {
			"title": "Submitted Date",
			"field": "submittedDate",
			width: 70,			
			headerAttributes: { style: "white-space: normal; overflow : visible"}
		}
	];
}
function onProjectEditOrView(e, type){
	debugger
	let tr = $(e.target).closest("tr");
	let currentRowData ;
	let mode;
	switch(type) {
		case 'edit':
			currentRowData = $("#projectGrid").data("kendoGrid").dataItem(tr);
			mode = (currentRowData != null && currentRowData.rpfProjectnumber!= null) ? "2": "1";
		break;

		case 'view':
			currentRowData = $("#projectGrid").data("kendoGrid").dataItem(tr);
			mode = (currentRowData != null && currentRowData.rpfProjectnumber!= null) ? "4-2" : "4-3";
		break;
	}
	if(currentRowData && mode) {
		selectedProjectGridRowIndex = tr.index();
		storeState(currentRowData.fuzeSiteId);
		var siteName = (siteStrucLocInfoObj!==null && siteStrucLocInfoObj !== undefined && siteStrucLocInfoObj.length>0 && siteStrucLocInfoObj[0].siteName)? siteStrucLocInfoObj[0].siteName : currentRowData.sitename;
		var url = CONTEXT_PATH + '/uui/eapp/atoll_pg/iBwaveProjectSummary?projectName='+ currentRowData.projectname +'&projectnumber='+ currentRowData.projectnumber
		+'&sitename='+siteName+'&siteid='+currentRowData.sitenumber +'&fuzesiteid='+currentRowData.fuzeSiteId
		+'&parentSolutionId='+currentRowData.parentsolutionid+'&latitude='+currentRowData.sitelatitude+'&longitude='+currentRowData.sitelongitude;
		window.location.href = url;
	}
}

function getProjectInfo(e){
	let tr = $(e.target).closest("tr");
	var selectedItem = $("#marketGrid").data("kendoGrid").dataItem(tr);
	if(selectedItem.fuzeSiteId && selectedItem.fuzeSiteId != "") {
		let payload = {
						projectNumber : $("#projectNumberSelect").val(),
						fuzeSiteId: selectedItem.fuzeSiteId
						};
		getProjectGridDetail(payload, -1);
		getSiteDetails(selectedItem.fuzeSiteId);
		
	} else {
		showMessageBanner('error', 'Site Name not available');
	}
}
function initMap() {
	L.CursorHandler = L.Handler.extend({

		addHooks: function () {
			this._popup = new L.Popup();
			this._map.on('mouseover', this._open, this);
			this._map.on('mousemove', this._update, this);
			this._map.on('mouseout', this._close, this);
		},

		removeHooks: function () {
			this._map.off('mouseover', this._open, this);
			this._map.off('mousemove', this._update, this);
			this._map.off('mouseout', this._close, this);
		},

		_open: function (e) {
			this._update(e);
		},

		_close: function (e) {
			$('#attributionSpan').text("Zoom Level: " + this._map.getZoom() + " Coordinates: " + parseFloat(e.latlng.lat).toFixed(5) + ", " + parseFloat(e.latlng.lng).toFixed(5));
		},

		_update: function (e) {
			$('#attributionSpan').text("Zoom Level: " + this._map.getZoom() + " Coordinates: " + parseFloat(e.latlng.lat).toFixed(5) + ", " + parseFloat(e.latlng.lng).toFixed(5));
		}
	});

	L.Map.addInitHook('addHandler', 'cursor', L.CursorHandler);
	leaf = t.initialize("map", {
		"zoomPos": 'topright',
		"clusterPie": false,
		"cursor": true,
		"tileOptions": tileOptions,
		"clusterOptions": clusterOptions,
		"stamp": "?_={stamp}", 'url': current_url, 'resourcePath': CONTEXT_PATH + '/uui/espresso/static',
		"legendPos": "bottomleft"
	})._map;
	t.setEdgeAttr(XYZ.ATTR.EDGE_AGGR_TEXT | XYZ.ATTR.EDGE_TEXT | XYZ.ATTR.EDGE_AGGR_POPUP);
	t.setMode(XYZ.MODE.STATIC);

	leaf.cursor.enable();

	L.control.scale({ position: "bottomleft" }).addTo(leaf);

	googleRoadMutant = L.gridLayer.googleMutant({ maxZoom: 24, type: 'roadmap' });
	googleTerrainMutant = L.gridLayer.googleMutant({ maxZoom: 24, type: 'terrain' });
	googleRoadMutant.addTo(leaf);
	leaf.on('moveend', function () {
		let text = $('#attributionSpan').text();
		text = text.slice(0, 12) + leaf.getZoom() + " " + text.slice(14, text.length);
		$('#attributionSpan').text(text);
		enableMapZoom();
	});
	
	function hideDropdown() {
		$(".multiselect-native-select").children().removeClass("open");
	}

	featureGroup = L.featureGroup().addTo(leaf);
}

function enableMapZoom(){
	leaf.dragging.enable();
	leaf.doubleClickZoom.enable();
	leaf.scrollWheelZoom.enable();
	leaf.boxZoom.enable();
	leaf.keyboard.enable();
}

/*Document Ready*/
$(document).ready(function () {

	try {
		var env = window.location.href.includes('canvasple') ? '-PLE' : '';
		window.initClickstream({
			"system_name": "Network Planning Platform",
			"app_name": "ATOLL" + env,
			"screen_name": "iBwave Import",
			"showLogs" : "true"
		});
	} catch(e) {
		return false;
	}

	  kendo.pdf.defineFont({
    "DejaVuSans"             : "http://cdn.kendostatic.com/2014.3.1314/styles/fonts/DejaVu/DejaVuSans.ttf",
    "DejaVuSans-Bold"        : "http://cdn.kendostatic.com/2014.3.1314/styles/fonts/DejaVu/DejaVuSans-Bold.ttf"
  });
  
  $('#messageBanner').hide();
  	loadDumpVariables();
  	drawTable("#marketGrid",siteDataSource,siteDataGridColumns,"SiteSearch Data.xlsx");
	if(returnedFuzeSiteId == "") {
		populateTerritory(true);
		$('#territoryDropdown').val('EAST').multiselect('refresh');
		populateAreas(['EAST'], true);
	}
   
	$("#siteNameSelect").val('');
	$('#aorFilterContainer').show();
	$("#aorfields").show();	
	if(returnedFuzeSiteId == ""){
	    	$('#siteNameDropdownContainer').show();
	    	
	}
		

	$("input[name='specificEnodeb']").change(function () {
		  $('#aorFilterContainer').show();
	    if ($("#specificEnodeb").prop('checked') == true) {
	      $('#aorfields').show();
	    	enableAORFields();
	    	if(returnedFuzeSiteId == ""){
		        	$('#siteNameDropdownContainer').show();
				uiCache.loadAorData(function () {
					$('#siteNameDropdownContainer').show();
				});
	    	}
	    } else {
	        enableAORFields();
	        $('#aorfields').show();
	  		populateAreas($('#territoryDropdown').val(), true);
	    }
	});
	
	 $("#siteSearchbtn").click(function() {
		  $('.strip').hide();
		if (checkForMandatoryFields()){
			let payloadData = formPayLoadForSiteSearchGrid();
			getSiteGridDetail (payloadData);
		} 
    });
    $('#clearSearchBtn').click(function (e) {
		debugger
        
		$("#siteNameSelect").val('');
		$("#eNodebIdSelect").val("");
		$("#projectNumberSelect").val("");
		$('#marketGrid')
          .getKendoGrid()
          .setDataSource(
            new kendo.data.DataSource({
              pageSize: 10,
              data: [],
            }));
		$('#recentSitesData').addClass("in");
		$('#gridMinimize1').removeClass("collapsed");
		$('#siteDetailsData	').removeClass("in");
		$('#siteDetailsHeader').addClass("collapsed");
		selectedSiteGridRowIndex = -1;
		clearProjectDetils();
		
		$('#aorfields').show();
		enableAORFields();
		if(returnedFuzeSiteId == ""){
			uiCache.loadAorData(function () {
				$('#siteNameDropdownContainer').show();
			});
		}
	});
	
   
	
	$("#onAir-tab").click(function () {
		$('#siteDetailsDiv').hide();
		$("#onAirServicesDiv").show();
	})
	$("#site-tab").click(function () {
		$('#siteDetailsDiv').show();
		$("#onAirServicesDiv").hide();
	});
	drawTable("#projectGrid",projectDataSource,getSummaryColumns(),"Projectdetails.xlsx");
	initMap();
	if(returnedFuzeSiteId == "") {
		setTimeout(function () {
			$('#siteDetailsData').removeClass("in");
		}, 2000);
	}
	$("#loading").hide();
	
	if(returnedFuzeSiteId != "") {
		restoreState(returnedFuzeSiteId);
		returnedFuzeSiteId = "";
	}
	else{		
		$("input[name='specificEnodeb']").change();
	}


	$('#eNodebIdSelect').on('keypress',function(event){
		if(event.which==13)$('#siteSearchbtn').click();
	})
	$('#siteNameSelect').on('keypress',function(event){
		if(event.which==13)$('#siteSearchbtn').click();
	});
	$('#projectNumberSelect').on('keypress',function(event){
		if(event.which==13)$('#siteSearchbtn').click();
	});
	$('#projectNumberSelect').on('change',function(){
		if($('#projectNumberSelect').val()===''){
			$('#eNodebIdSelect').prop('disabled', false);
			$('#siteNameSelect').prop('disabled', false);
			$('#territoryDropdown').multiselect('enable');
			$('#areaDropdown').multiselect('enable');
			$('#regionDropdown').multiselect('enable');
			$('#marketDropdown').multiselect('enable');
		}
		else{
			$('#eNodebIdSelect').prop('disabled', true);
			$('#siteNameSelect').prop('disabled', true);
			$('#territoryDropdown').multiselect('disable');
			$('#areaDropdown').multiselect('disable');
			$('#regionDropdown').multiselect('disable');
			$('#marketDropdown').multiselect('disable');
		}
	});

});
$(document).click(function(e){
      
    });

function checkForMandatoryFields() {
	
	 let mandatoryValue = $('#territoryDropdown').val();
	 
	 let siteNameValue  = $("#siteNameSelect").val();
	 let projectNumber  = $("#projectNumberSelect").val();
	 
	 if((typeof siteNameValue == 'undefined' || siteNameValue == null || siteNameValue== '') && (typeof projectNumber == 'undefined' || projectNumber == null || projectNumber == '')){
		alert('Please enter Site Name/FUZE Site ID or Project Name/Number ');
		return false;
	 }
	 if(typeof siteNameValue == 'undefined' || siteNameValue == null){
		 siteNameValue = '';
	 }
	 
	 let enodebId  = $("#eNodebIdSelect").val();
	 if(typeof siteNameValue == 'undefined' || siteNameValue == null){
			 enodebId = '';
	 }
	 
	 if(typeof siteNameValue == 'undefined' || siteNameValue == null){
			 projectNumber = '';
	 }
	 if(mandatoryValue == null && siteNameValue == '' && projectNumber=='' && enodebId=='') {
		showMessageBanner('warn', 'Please select Territory ');
		return false;
	 } 
	return true;
}
var siteSearchAjaxObj;
function getSiteGridDetail(payloadData) {
	$('#loading').show();
	$("#searchCancelIconContent").show();
	siteSearchAjaxObj	= $.ajax({
        type: 'POST',
        url:fetchSiteDetailsUrl,
		dataType: 'json',
		contentType: 'application/json; charset=UTF-8',
		cache: false,
		data: JSON.stringify(payloadData),
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
        success: function (data) {
            var returnedData = data;
			$("#searchCancelIconContent").hide();
			if(returnedData.length<1){
				$('#loading').hide()
				
				showMessageBanner('info','No data found');
				
				grid.setDataSource(
					new kendo.data.DataSource({
					  pageSize: 10,
					  data: [],
					}));
				$('#recentSitesData').addClass("in");
				$('#gridMinimize1').removeClass("collapsed");
				$('#siteDetailsData	').removeClass("in");
				$('#siteDetailsHeader').addClass("collapsed");
				selectedSiteGridRowIndex = -1;
				clearProjectDetils();
				return;			
			}
            market=returnedData[0].market;
            $('#loading').hide();
			console.log('success', 'Site Search Record fetched successfully');
			$('#marketGrid')
          .getKendoGrid()
          .setDataSource(
            new kendo.data.DataSource({
              pageSize: data.length,
              data: data,
            })
          );
		 clearProjectDetils(); 
		  populateFields(data);
		  siteDetailsInfoObj = data;
		  if(data != null && data.length == 1) {
			getProjectGridDetail({ projectNumber: $("#projectNumberSelect").val(),fuzeSiteId: data[0].fuzeSiteId }, -1);
			getSiteDetails(data[0].fuzeSiteId);
		  } else {
			$('#recentSitesData').addClass("in");
			$('#gridMinimize1').removeClass("collapsed");
			$('#siteDetailsData	').removeClass("in");
			$('#siteDetailsHeader').addClass("collapsed");
		  }

        },
        error: function (request, status, err) {
			$("#searchCancelIconContent").hide();
			$('#loading').hide();
			var statusText	= request.statusText;
			if(statusText === 'abort'){
				//aptAlert('info', 'Cancelled Site Search');
				showMessageBanner("error","Warning! Cancelled Site Search");
				console.log('Fault', 'Something went wrong while fetching Site Records '+err);
			}
			else{
				showMessageBanner('error', 'Something went wrong while fetching Site Records');
				console.log('Fault', 'Something went wrong while fetching Site Records '+err);
			}
        }
});

}
function showMessageBanner(level, message){
	$('#messageBanner').show();
	$('#messageBanner').text(message);
	if(level.toLowerCase()=="info"){
		$('#messageBanner').css("background-color","yellow");
	}
	else if(level.toLowerCase()=="warn"){
		$('#messageBanner').css("background-color","grey");
	}
	else if(level.toLowerCase()=="error"){
		$('#messageBanner').css("background-color","pink");
	}
	setTimeout(function() {
		$('#messageBanner').hide();
	}, 3000);
}
function selectRow(e) {
  grid.clearSelection();
  //clearProjectDetils();
  var menuDiv = '<ul>' +
    '<li><span class="projectInfoIcon" id="projectInfo"></span><span id="projectInfo_a" class="icon-style">Project Information</span></li>' +
    '<li style="width: 1%;"><button id="closeBtn" type="button" class="close alphaBG" >&times;</button></li>' +
    '</ul>';
  $("#stripDiv").html(menuDiv);
  $('#closeBtn').bind('click', function () {
     $("#stripDiv").hide();
    e.stopPropagation();
  });
 $('#projectInfo, #projectInfo_a').bind('click', function () {
    var selectedItem = grid.dataItem(grid.select());
	if(selectedItem.fuzeSiteId && selectedItem.fuzeSiteId != "") {
		let payload = {
						projectNumber: $("#projectNumberSelect").val(),
						fuzeSiteId: selectedItem.fuzeSiteId
						};
		getProjectGridDetail(payload, -1);
		getSiteDetails(selectedItem.fuzeSiteId);
		
	} else {
		showMessageBanner('error', 'Site Name not available');
	}
    // var url = CONTEXT_PATH + '/uui/eapp/rfds_pg/RfdsSearch?tmp=' + Date.parse(new Date()) + '&fuzeSiteId=' + selectedItem.fuzeSiteId;
     // window.location.href = url;
  });
  var popupPosition = e.screenX < 100 ? 100 : e.screenX;
  if (popupPosition > 100) {
    if (popupPosition > 1100) {
      $("#stripDiv").css('right', 1300 - popupPosition);
    } else {
      $("#stripDiv").css('left', popupPosition);
    }

  } else {
    $("#stripDiv").css('left', popupPosition);
  }

  var offset = $(e.target).closest("tr").offset();
   $("#stripDiv").show().css('top', parseInt(offset.top) + 38);
  var tr = $(e.target).closest("tr");
  selectedSiteGridRowIndex = tr.index();
  if (tr.hasClass("k-state-selected") == false) {
    tr.addClass("k-state-selected");
  } else {
    tr.removeClass("k-state-selected");

    var rows = grid.select();
    if (rows == null || rows == undefined || rows.length == 0)
       $("#stripDiv").hide();
  }
}
function projectSelectRow(e) {
	let grid = $("#projectGrid").data("kendoGrid");
  grid.clearSelection();
  let menuDiv = '<ul>' +
	'<li><span class="editInfoIcon" id="editInfo"></span><span id="editInfo_a" class="icon-style">Edit</span></li>' +
	'<li><span class="fa fa-map-marker fa-2x viewInfoIcon" id="viewInfo"></span><span id="viewInfo_a" class="icon-style">View</span></li>' +
    '<li style="width: 10%;"><button id="projectCloseBtn" type="button" class="close alphaBG" >&times;</button></li>' +
    '</ul>';
  $("#projectStripDiv").html(menuDiv);
  $('#projectCloseBtn').bind('click', function () {
    $('#projectStripDiv').hide();
    e.stopPropagation();
  });
 $('#editInfo, #editInfo_a, #viewInfo, #viewInfo_a, #addInfo, #addInfo_a').bind('click', function (event) {
	 
	let grid = $("#projectGrid").data("kendoGrid");
    let selectedItem = grid.dataItem(grid.select());
	let mode;
	
 	if(event.target.id.includes("edit")) {
		mode = (selectedItem != null && selectedItem.rpfProjectnumber!= null) ? "2": "1";
	} else {
		mode = (selectedItem != null && selectedItem.rpfProjectnumber!= null) ? "3-2" : "3-1";
	}
		
	storeState(selectedItem.fuzeSiteId);
	var url = CONTEXT_PATH + '/uui/eapp/rfds_pg/RfdsService?projectName='+ selectedItem.projectname +'&projectAltName='+selectedItem.projectdescription+'&rfdsProjectId='+selectedItem.rfdsProjectId+'&rfdsSpmStatus='+currentRowData.projStatus+'&submittedDate='+currentRowData.submittedDate+'&projectnumber='+ selectedItem.projectnumber + '&status=' + selectedItem.projectstatus + '&fuzeSiteId=' + selectedItem.fuzeSiteId+'&parentsolutionid='+ selectedItem.parentsolutionid +'&market='+ market +'&mode=' + mode + '&region=' + selectedItem.region + '&tmp=' + Date.parse(new Date());
	window.location.href = url;
  });
  let popupPosition = e.screenX < 100 ? 100 : e.screenX;
  if (popupPosition > 100) {
    if (popupPosition > 1100) {
      $("#projectStripDiv").css('right', 1300 - popupPosition);
    } else {
      $("#projectStripDiv").css('left', popupPosition);
    }

  } else {
    $("#projectStripDiv").css('left', popupPosition);
  }

  let offset = $(e.target).closest("tr").offset();
  $('#projectStripDiv').show().css('top', parseInt(offset.top) + 38);
  let tr = $(e.target).closest("tr");
  selectedProjectGridRowIndex = tr.index();
  if (tr.hasClass("k-state-selected") == false) {
    tr.addClass("k-state-selected");
  } else {
    tr.removeClass("k-state-selected");

    let rows = grid.select();
    if (rows == null || rows == undefined || rows.length == 0)
      $('#projectStripDiv').hide();
  }
}


function formPayLoadForSiteSearchGrid() {
	let payload = {};
	
	let territory = $('#territoryDropdown').val() != null ? $('#territoryDropdown').val() : TERRITORY_DUMP;
	payload.territory = territory;
	
	let area = ($('#areaDropdown').val() != null) ? $('#areaDropdown').val() : [...document.getElementById('areaDropdown')].map(o => o.value).length>0 ? [...document.getElementById('areaDropdown')].map(o => o.value) : AREA_DUMP;
	payload.area = area;
	
	let region = ($('#regionDropdown').val() != null) ? $('#regionDropdown').val() : [...document.getElementById('regionDropdown')].map(o => o.value).length>0 ? [...document.getElementById('regionDropdown')].map(o => o.value) : REGION_DUMP;
	payload.region = region;
	
	let market = $('#marketDropdown').val() != null ? $('#marketDropdown').val() : [...document.getElementById('marketDropdown')].map(o => o.value).length>0 ? [...document.getElementById('marketDropdown')].map(o => o.value) : MARKET_DUMP;
	payload.market = market;
	
	let siteName = $('#siteNameSelect').val();
	payload.siteName = siteName;
	
	let enodebId = $('#eNodebIdSelect').val();
	payload.enodebId = enodebId;

	let projectNumber = $('#projectNumberSelect').val();
	payload.projectNumber = projectNumber;
	
	return payload;
}

function downloadProjectData() {
	var grid = $("#projectGrid").data("kendoGrid");
	grid.saveAsExcel();
}

var projectStatusNumbers = {
        "ACTIVE"  : 1,
        "PENDING"  : 2,
        "CANCELED" : 3,
        "COMPLETED" : 4
      };

function getProjectGridDetail(payloadData, selectedIndex) {

	$('#loading').show();
	$.ajax({
		type: 'GET',
		cache: false,
		contentType: 'application/json; charset=UTF-8',
		dataType: 'json',
		data: payloadData,
		url: fetchProjectDetailsUrl,
		success: function (data) {
			var returnedData = data;
			$('#loading').hide();
			$('.strip').hide();
			console.log('success', 'Project details fetched successfully');
			$('#projectGrid')
				.getKendoGrid()
				.setDataSource(
					new kendo.data.DataSource({
						pageSize: data.length,
						data: data,
						sort: { field: "projectstatus", dir: "asc", compare: compareFunc}
					})
				);
			if(selectedIndex != -1) {
				$("#projectGrid").data("kendoGrid").select("tr:eq(" +selectedIndex +")");
			}
			$('#recentSitesData').removeClass("in");
			$('#gridMinimize1').addClass("collapsed");
			$('#siteDetailsData	').addClass("in");
			$('#siteDetailsHeader').removeClass("collapsed");
		},
		error: function (err) {
			$('#loading').hide();
			$('.strip').hide();
			showMessageBanner('error', 'Something went wrong while fetching Project Details');
			console.log('Fault', 'Something went wrong while fetching Project Details');
		}
	});
}
function compareFunc(a,b) {
	return projectStatusNumbers[a.projectstatus] - projectStatusNumbers[b.projectstatus];
}
function getSiteDetails(fuzeSiteId) {
	if(fuzeSiteId == null || fuzeSiteId =="" || fuzeSiteId=='0') {
		return;
	}
	var projectnumber = $("#projectNumberSelect").val();
	$('#loading').show();
	$.ajax({
		type: 'GET',
		cache: false,
		contentType: 'application/json; charset=UTF-8',
		dataType: 'json',
		headers: {
			'Accept': 'application/json, text/plain, */*',  
			'Content-Type': 'application/json'
		},
		data: {fuzeSiteId: fuzeSiteId, rfdsProjectNumber: projectnumber},
		beforeSend: function (xhr) {
			xhr.setRequestHeader('user_id', VZID);
		},
		url: fetchSiteDetailsByFuzeSiteIdOrProjectNumberUrl,
		success: function (data) {
			var returnedData = data;
			$('#loading').hide();
			try {
				siteStrucLocInfoObj = returnedData
				populateFields(returnedData);
				market=returnedData[0].market;
			} catch (error) { console.log(error); }
			//showAlert('success', 'Required metadata loaded');
		},
		error: function (err) {
			$('#loading').hide();
			showMessageBanner('error', 'Something went wrong while fetching Site data');
		}
	});
}

function populateFields(returnedData) {
	if(returnedData != null && returnedData.length > 0 ) {
		let carryObj = returnedData[0];
		$('#siteId').html(carryObj.fuzeSiteId);
		$('#siteName').html(carryObj.siteName);
		$('#searchRing').html("");
		$('#eNodebId').html((carryObj.eNodebId != null && carryObj.eNodebId!= undefined) ? carryObj.eNodebId : "");
		$('#switchName').html((carryObj.switchName != null && carryObj.switchName!= undefined) ? carryObj.switchName : "");
		$('#towerOwner').html("");
		$('#siteType').html(carryObj.siteType);
		siteType=carryObj.siteType;
		$('#siteStatus').html(carryObj.status);
		$('#cellNumber').html((carryObj.marketId != null && carryObj.marketId!= undefined) ? carryObj.marketId : "");
		
		$('#streetAddress').html(carryObj.address);
		$('#city').html(carryObj.city);
		$('#state').html(carryObj.state);
		$('#zipCode').html(carryObj.zipcode);
		$('#county').html(carryObj.county);
		$('#latitude').html(carryObj.latitude);
		$('#longitude').html(carryObj.longitude);
		
		focusSiteOnMap(carryObj);
	}
}
function aptAlert(status, message) {
	$("#alertsuccess").hide();
	$("#alerterror").hide();
	$("#alertinfo").hide();
	$("#alertwarning").hide();

	$("#alertTitle").html(status + '!');
	$("#alert" + status.toLowerCase()).html(message);
	$("#alert" + status.toLowerCase()).show();
	$("#myModal").css(
		"margin-top",
		Math.max(0, ($(window).height() - ($("#myModal").height() + 100)) / 2));
	$("#myModal").css(
		"margin-left",
		Math.max(0, ($(window).width() - $("#myModal").width()) / 2));
	$("#myModal").modal("show");
}

function focusSiteOnMap(rowData) {
	let popupContent = "<span>Site ID: <b> " + rowData.fuzeSiteId +" </b> <span>" ;
	var equipIcon = L.divIcon({ className: 'fa fa-map-marker fa-2x' });
	var siteMarker = new L.marker([rowData.latitude, rowData.longitude],
						{
							icon: equipIcon, equipType: 'Site ID'
						}).bindPopup(popupContent).addTo(featureGroup);
	leaf.flyTo([rowData.latitude, rowData.longitude], 15);
	//leaf.fitBounds(featureGroup.getBounds());
}
function focusProjectOnMap(rowData) {
	//console(rowData);
}

function clearProjectDetils() {
	$('#siteId').html("");
	$('#searchRing').html("");
	$('#siteName').html("");
	$('#eNodebId').html("");
	$('#switchName').html("");
	$('#towerOwner').html("");
	$('#siteType').html("");
	$('#siteStatus').html("");
	$('#cellNumber').html("");
	
	$('#streetAddress').html("");
	$('#city').html("");
	$('#state').html("");
	$('#zipCode').html("");
	$('#county').html("");
	$('#latitude').html("");
	$('#longitude').html("");
	
	selectedProjectGridRowIndex = -1;
	$("#projectGrid").data("kendoGrid").setDataSource(
            new kendo.data.DataSource({
              //pageSize: 10,
              data: [],
            }));
	if(featureGroup)
		featureGroup.clearLayers();
}
function storeState(fuzeSiteId) {
	if (window.sessionStorage) {
		sessionStorage.removeItem(fuzeSiteId);
		sessionStorage.setItem(fuzeSiteId, JSON.stringify(formStateData()));
		try{
			sessionStorage.setItem(fuzeSiteId+"grid", JSON.stringify(getDatagridInfo()));
		} catch(exp) {
			console.log("Cannot retain datagrid records", exp);
		}
	}
}
function restoreState(fuzeSiteId) {
	if (window.sessionStorage && sessionStorage.getItem(fuzeSiteId)) {
		var prevState = JSON.parse(sessionStorage.getItem(fuzeSiteId));
		
		if(	prevState != null && prevState != undefined) {
			let obj = prevState.isAorSettingEnabled;
			if(!obj || obj=="false") $("#specificEnodeb").prop('checked', false);
			else $("#specificEnodeb").prop('checked', obj);
			
			//if(obj!= null && (obj == "false" || obj == false)) {
				//$("#specificEnodeb").change();

				obj = prevState.territorySel;
				territoryDataProvider = getProvider(obj.dataProvider);
				populateTerritory(false);
				//fillMultiSelectDropdownProvider("#territoryDropdown", obj.dataProvider);
				obj.selectedValue != "" ? $("#territoryDropdown").val(obj.selectedValue).multiselect("refresh") :"";
				
				obj = prevState.areaSel;
				areasDataProvider = getProvider(obj.dataProvider);
				if(areasDataProvider != null && areasDataProvider.length >0)
					populateAreas($("#territoryDropdown").val(), false);
				//fillMultiSelectDropdownProvider("#areaDropdown", obj.dataProvider);
				obj.selectedValue != "" ? $("#areaDropdown").val(obj.selectedValue).multiselect("refresh") :"";
				
				obj = prevState.regionSel;
				regionsDataProvider =  getProvider(obj.dataProvider);
				if(regionsDataProvider != null && regionsDataProvider.length >0)
					populateRegions($("#areaDropdown").val(), false);
				//fillMultiSelectDropdownProvider("#regionDropdown", obj.dataProvider);
				obj.selectedValue != "" ? $("#regionDropdown").val(obj.selectedValue).multiselect("refresh") :"";
				
				obj = prevState.marketSel;
				marketsDataProvider = getProvider(obj.dataProvider);
				if(marketsDataProvider != null && marketsDataProvider.length >0)
					populateMarkets($("#regionDropdown").val(), false);
				
				obj.selectedValue != "" ? $("#marketDropdown").val(obj.selectedValue).multiselect("refresh") :"";
			
			
			obj = prevState.siteNameSelect;
			
			$('#siteNameSelect').removeAttr("disabled");
			siteStrucLocInfoObj = prevState.siteStrucLocInfoObj;
			siteDetailsInfoObj = prevState.siteDetailsInfoObj;
			obj = (siteStrucLocInfoObj && siteStrucLocInfoObj.length>0) ? siteStrucLocInfoObj:siteDetailsInfoObj;	
			if(obj != undefined && obj != null) {
				populateFields(obj);
			}
			console.log(prevState);
			$("#siteNameSelect").val(prevState.siteName);
			$("#eNodebIdSelect").val(prevState.enodebId);
			$("#projectNumberSelect").val(prevState.projectNumber);
		}
	}
	if (window.sessionStorage && sessionStorage.getItem(fuzeSiteId+"grid")) {
		var prevGridState = JSON.parse(sessionStorage.getItem(fuzeSiteId+"grid"));
		let obj = prevGridState.siteDataGrid
		if(obj != undefined && obj != null && obj.options) {
			$("#marketGrid").data("kendoGrid").setOptions(JSON.parse(obj.options));
			if(obj.selectedIndex != -1) {
				$("#marketGrid").data("kendoGrid").select("tr:eq(" +(obj.selectedIndex) +")");
			}				
		}
		obj = prevGridState.projectDataGrid
		if(obj != undefined && obj != null && obj.options) {
			/*$("#projectGrid").data("kendoGrid").setOptions(JSON.parse(obj.options));
			if(obj.selectedIndex != -1) {
				$("#projectGrid").data("kendoGrid").select("tr:eq(" +(obj.selectedIndex) +")");
			}
			$('#recentSitesData').removeClass("in");
			$('#gridMinimize1').addClass("collapsed");
			$('#siteDetailsData	').addClass("in");
			$('#siteDetailsHeader').removeClass("collapsed");*/
			let returnedProjectNumber = $("#projectNumberSelect").val();
			let payload = {
						fuzeSiteId: returnedFuzeSiteId,
						projectNumber : returnedProjectNumber
						};
			getSiteDetails(fuzeSiteId);
			getProjectGridDetail(payload, obj.selectedIndex);
			
		}
	}
	sessionStorage.removeItem(fuzeSiteId);
	sessionStorage.removeItem(fuzeSiteId+"grid");
	//$("#siteSearchbtn").click();
}
function getProvider (dataProvider) {
	return (dataProvider != undefined && dataProvider != null && dataProvider != "" && dataProvider.length > 0) ? dataProvider : [];
}
function formStateData() {
	var stateObj = {};
	
	stateObj.isAorSettingEnabled = $("#specificEnodeb").prop('checked');
		stateObj.territorySel = {dataProvider:territoryDataProvider, selectedValue: ($('#territoryDropdown').val() != null ? $('#territoryDropdown').val() : "")};
		stateObj.areaSel = {dataProvider:areasDataProvider, selectedValue: ($('#areaDropdown').val() != null ? $('#areaDropdown').val() : "" )};
		stateObj.regionSel = {dataProvider:regionsDataProvider, selectedValue: ($('#regionDropdown').val() != null ? $('#regionDropdown').val() : "" )};
		stateObj.marketSel =  {dataProvider:marketsDataProvider, selectedValue: ($('#marketDropdown').val() != null ? $('#marketDropdown').val() : "" )};
	stateObj.siteNameSelect =  {dataProvider:[], selectedValue: ($('#siteNameSelect').val() != null ? $('#siteNameSelect').val() : "" )};
	stateObj.siteName = $('#siteNameSelect').val();
	stateObj.enodebId = $("#eNodebIdSelect").val();
	stateObj.projectNumber = $("#projectNumberSelect").val();
	
	if(siteStrucLocInfoObj != null && siteStrucLocInfoObj != undefined)
		stateObj.siteStrucLocInfoObj = siteStrucLocInfoObj;
	if(siteDetailsInfoObj != null && siteDetailsInfoObj != undefined)
		stateObj.siteDetailsInfoObj = siteDetailsInfoObj;
	return stateObj;
}
function getDatagridInfo() {
	let gridStateObj = {};
	
	try{
		gridStateObj.siteDataGrid = { selectedIndex:selectedSiteGridRowIndex, options: kendo.stringify($("#marketGrid").data("kendoGrid").getOptions())};	
	} catch(exp) {
		
		console.log("Cannot retain Site list records", exp);
	}
	
	try{
		gridStateObj.projectDataGrid = { selectedIndex:selectedProjectGridRowIndex, options: kendo.stringify($("#projectGrid").data("kendoGrid").getOptions())};
	} catch(exp) {
		console.log("Cannot retain Project list records", exp);
	}
	
	return gridStateObj;
}
function fillMultiSelectDropdownProvider(dropdownObj, providerObj){
	if(providerObj != null) {
		switch(dropdownObj) {
			case "#marketDropdown" :
				$.each(providerObj, function (index, value) {
				$(dropdownObj).append("<option style='display:inline-block;' id='" + value.MARKET + "' value='" + value.MARKET + "' class='multis'>" + value.MARKET + "-" +value.MARKETNAME + "</option>");
			});
			break;
			case "#territoryDropdown":
				$.each(providerObj, function (index, value) {
				$(dropdownObj).append("<option style='display:inline-block;' id='" + value.TERRITORY + "' value='" + value.TERRITORY + "' class='multis'>" + value.TERRITORY + "</option>");
			});
			break;
			case "#areaDropdown":
				$.each(providerObj, function (index, value) {
				$(dropdownObj).append("<option style='display:inline-block;' id='" + value.area + "' value='" + value.area + "' class='multis'>" + value.areaname + "</option>");
			});
			break;
			case "#regionDropdown":
				$.each(providerObj, function (index, value) {
				$(dropdownObj).append("<option style='display:inline-block;' id='" + value.region + "' value='" + value.region + "' class='multis'>" + value.regionname + "</option>");
			});
			break;
		}
	}
}

function enableAORFields() {
    $('#territoryDropdown').multiselect('enable');
    $('#areaDropdown').multiselect('enable');
    $('#regionDropdown').multiselect('enable');
    $('#marketDropdown').multiselect('enable');
    $('#countyDropdown').multiselect('enable');
    $('#rfEngDropdown').multiselect('enable');
    $("#enodebSearchInput").prop('disabled', false);
}

function disableAORFields() {
    $('#territoryDropdown').multiselect('disable');
    $('#areaDropdown').multiselect('disable');
    $('#regionDropdown').multiselect('disable');
    $('#marketDropdown').multiselect('disable');
    $('#countyDropdown').multiselect('disable');
    $("#enodebSearchInput").prop('disabled', true);
    $('#rfEngDropdown').multiselect('disable');
}

//Payload generation to fetch sitename
function formPayLoadForGetSiteName() {
	let payload = {};
	let temp = JSON.stringify(($('#territoryDropdown').val() != null) ? $('#territoryDropdown').val() : entireTerritoryList);
	payload.territory = temp;
	
	temp = JSON.stringify(($('#areaDropdown').val() != null) ? $('#areaDropdown').val() : entireAreaList);
	payload.area = temp;
	
	temp = JSON.stringify(($('#regionDropdown').val() != null) ? $('#regionDropdown').val() : entireRegionList);
	payload.region = temp;
	
	temp = JSON.stringify(($('#marketDropdown').val() != null) ? $('#marketDropdown').val() : entireMarketList);
	payload.market = temp;
	
	temp = JSON.stringify($('#siteNameSelect').val());
	payload.siteName = temp;
	
	temp = JSON.stringify($('#eNodebIdSelect')).val();
	payload.enodebId = temp;
	return payload;
}

var loadDumpVariables = function(){
	TERRITORY_DUMP = ['EAST', 'WEST'];
	$.ajax({
		async : false,
		url: CONTEXT_PATH + '/uui/eapp/rfds_pg/getAreaForMarketBoundary',
		type: "POST",
		data: { territoryList: TERRITORY_DUMP },
		success: function (data) {
			AREA_DUMP = JSON.parse(data).areas.map(x => x.area);
		}
	});
	$.ajax({
		async : false,
		url: CONTEXT_PATH + '/uui/eapp/rfds_pg/getRegionsForMarketBoundary',
		type: "POST",
		data: { areaList: JSON.stringify(AREA_DUMP) },
		success: function (data) {
			REGION_DUMP = JSON.parse(data).regions.map(x => x.region);
		}
	})
	$.ajax({
		async : false,
		url : CONTEXT_PATH + '/uui/eapp/rfds_pg/getMarketsForMarketBoundary',
		type : 'POST',
		data : {regionList : JSON.stringify(REGION_DUMP)},
		success : function(data){
			MARKET_DUMP = JSON.parse(data).markets.map(x => x.MARKET);
		}
	})
}

$("#searchCancelIconContent").click(function(){
	siteSearchAjaxObj.abort();
	$("#searchCancelIconContent").hide();
});





