const historyRequestStatusColumns = [
    {
        "title": "Request Id",
        "field": "REQUEST_ID",
        "width": "80px"
    },
    {
        "title": "Request Status",
        "field": "REQUEST_STATUS",
        "width": "120px"
    },
    {
        "title": "Site Name",
        "field": "siteName",
        "width": "120px",
        "template": (requestItem) => {
            try{
                return JSON.parse(requestItem.REQUEST_PAYLOAD).siteName
            }
            catch(err){
                return "";
            }
        }
    },
    {
        "title": "Requested Time",
        "field": "REQUEST_DATE_TIME",
        "width": "160px"
    },
    {
        "title": "Completed Time",
        "field": "COMPLETED_DATE_TIME",
        "width": "160px"
    },
    {
        "title": "Requested By",
        "field": "REQUESTED_BY",
        "width": "120px"
    },
    {
        "title": "Download",
        "field": "download",
        "width": "80px",
        "template": (requestItem) => {
            try{
                return downloadHistoryRequestDataTemplate(requestItem);
            }
            catch(err){
                return "";
            }
        }
    },
]

var sitesHistoryGridColumns = [
    {
        "title": "NAME",
        "field": "NAME",
        "width": "240px"
    },
    {
        "title": "LONGITUDE",
        "field": "LONGITUDE",
        "width": "240px"
    },
    {
        "title": "LATITUDE",
        "field": "LATITUDE",
        "width": "240px"
    },
    {
        "title": "ALTITUDE",
        "field": "ALTITUDE",
        "width": "240px"
    },
    {
        "title": "COMMENT_",
        "field": "COMMENT_",
        "width": "240px"
    },
    {
        "title": "PYLON_HEIGHT",
        "field": "PYLON_HEIGHT",
        "width": "240px"
    },
    {
        "title": "SUPPORT_INFO",
        "field": "SUPPORT_INFO",
        "width": "240px"
    },
    {
        "title": "CHANNEL_ELEMENTS_UL",
        "field": "CHANNEL_ELEMENTS_UL",
        "width": "240px"
    },
    {
        "title": "CHANNEL_ELEMENTS_DL",
        "field": "CHANNEL_ELEMENTS_DL",
        "width": "240px"
    },
    {
        "title": "MAX_IUB_RATE_UL",
        "field": "MAX_IUB_RATE_UL",
        "width": "240px"
    },
    {
        "title": "MAX_IUB_RATE_DL",
        "field": "MAX_IUB_RATE_DL",
        "width": "240px"
    },
    {
        "title": "CDMA_EQUIPMENT",
        "field": "CDMA_EQUIPMENT",
        "width": "240px"
    },
    {
        "title": "EVDO_CES",
        "field": "EVDO_CES",
        "width": "240px"
    },
    {
        "title": "BH_CAPACITY_DL",
        "field": "BH_CAPACITY_DL",
        "width": "240px"
    },
    {
        "title": "BH_CAPACITY_UL",
        "field": "BH_CAPACITY_UL",
        "width": "240px"
    },
    {
        "title": "ALIAS_",
        "field": "ALIAS_",
        "width": "240px"
    },
    {
        "title": "VZ_SITE_CODE",
        "field": "VZ_SITE_CODE",
        "width": "240px"
    },
    {
        "title": "VZ_SITE_NUMBER",
        "field": "VZ_SITE_NUMBER",
        "width": "240px"
    },
    {
        "title": "VZ_SITE_VERSION",
        "field": "VZ_SITE_VERSION",
        "width": "240px"
    },
    {
        "title": "VZ_ZIP_CODE",
        "field": "VZ_ZIP_CODE",
        "width": "240px"
    },
    {
        "title": "VZ_LOCATION_NAME",
        "field": "VZ_LOCATION_NAME",
        "width": "240px"
    },
    {
        "title": "VZ_ADDRESS_DESC",
        "field": "VZ_ADDRESS_DESC",
        "width": "240px"
    },
    {
        "title": "VZ_STREET_ADDRESS",
        "field": "VZ_STREET_ADDRESS",
        "width": "240px"
    },
    {
        "title": "VZ_STATE",
        "field": "VZ_STATE",
        "width": "240px"
    },
    {
        "title": "VZ_CITY",
        "field": "VZ_CITY",
        "width": "240px"
    },
    {
        "title": "VZ_COUNTY",
        "field": "VZ_COUNTY",
        "width": "240px"
    },
    {
        "title": "VZ_SITE_NAME",
        "field": "VZ_SITE_NAME",
        "width": "240px"
    },
    {
        "title": "VZ_SITE_ON_AIR_DATE",
        "field": "VZ_SITE_ON_AIR_DATE",
        "width": "240px"
    },
    {
        "title": "VZ_NETWORK_TERRITORY",
        "field": "VZ_NETWORK_TERRITORY",
        "width": "240px"
    },
    {
        "title": "VZ_NETWORK_MARKET",
        "field": "VZ_NETWORK_MARKET",
        "width": "240px"
    },
    {
        "title": "VZ_NETWORK_SUBMARKET",
        "field": "VZ_NETWORK_SUBMARKET",
        "width": "240px"
    },
    {
        "title": "VZ_NETWORK_SCHEMA",
        "field": "VZ_NETWORK_SCHEMA",
        "width": "240px"
    },
    {
        "title": "VZ_COUNTRY",
        "field": "VZ_COUNTRY",
        "width": "240px"
    },
    {
        "title": "VZ_SITE_OFF_AIR_DATE",
        "field": "VZ_SITE_OFF_AIR_DATE",
        "width": "240px"
    },
    {
        "title": "VZ_PEOPLESOFT_LOCATION_CODE",
        "field": "VZ_PEOPLESOFT_LOCATION_CODE",
        "width": "240px"
    },
    {
        "title": "VZ_SITE_INFO_ID",
        "field": "VZ_SITE_INFO_ID",
        "width": "240px"
    },
    {
        "title": "VZ_TOWER_OWNER",
        "field": "VZ_TOWER_OWNER",
        "width": "240px"
    },
    {
        "title": "VZ_SEARCH_RING_ID",
        "field": "VZ_SEARCH_RING_ID",
        "width": "240px"
    },
    {
        "title": "VZ_NETWORK_EXT_CAPABLE",
        "field": "VZ_NETWORK_EXT_CAPABLE",
        "width": "240px"
    },
    {
        "title": "VZ_TEMP_SITE",
        "field": "VZ_TEMP_SITE",
        "width": "240px"
    },
    {
        "title": "VZ_LRA_PARTNER",
        "field": "VZ_LRA_PARTNER",
        "width": "240px"
    },
    {
        "title": "VZ_SURVEYED_ALTITUDE",
        "field": "VZ_SURVEYED_ALTITUDE",
        "width": "240px"
    },
    {
        "title": "VZ_OVERALL_STRUCTURE_HT",
        "field": "VZ_OVERALL_STRUCTURE_HT",
        "width": "240px"
    },
    {
        "title": "VZ_STRUCTURE_TYPE",
        "field": "VZ_STRUCTURE_TYPE",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_31",
        "field": "MARKET_SITECUSTOMFIELD_31",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_32",
        "field": "MARKET_SITECUSTOMFIELD_32",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_33",
        "field": "MARKET_SITECUSTOMFIELD_33",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_34",
        "field": "MARKET_SITECUSTOMFIELD_34",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_35",
        "field": "MARKET_SITECUSTOMFIELD_35",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_36",
        "field": "MARKET_SITECUSTOMFIELD_36",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_37",
        "field": "MARKET_SITECUSTOMFIELD_37",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_38",
        "field": "MARKET_SITECUSTOMFIELD_38",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_39",
        "field": "MARKET_SITECUSTOMFIELD_39",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_40",
        "field": "MARKET_SITECUSTOMFIELD_40",
        "width": "240px"
    },
    {
        "title": "VZ_NETWORK_LOCALE",
        "field": "VZ_NETWORK_LOCALE",
        "width": "240px"
    },
    {
        "title": "VZ_COUNTY_FIPS",
        "field": "VZ_COUNTY_FIPS",
        "width": "240px"
    },
    {
        "title": "VZ_CRAN_HUB_NAME",
        "field": "VZ_CRAN_HUB_NAME",
        "width": "240px"
    },
    {
        "title": "VZ_SITE_RECORD_ID",
        "field": "VZ_SITE_RECORD_ID",
        "width": "240px"
    },
    {
        "title": "VZ_SPM_PROJECT_ID",
        "field": "VZ_SPM_PROJECT_ID",
        "width": "240px"
    },
    {
        "title": "VZ_POR_YEAR",
        "field": "VZ_POR_YEAR",
        "width": "240px"
    },
    {
        "title": "VZ_ACTIVATION_COMMENTS",
        "field": "VZ_ACTIVATION_COMMENTS",
        "width": "240px"
    },
    {
        "title": "VZ_5G_MARKET",
        "field": "VZ_5G_MARKET",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_01",
        "field": "MARKET_SITECUSTOMFIELD_01",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_02",
        "field": "MARKET_SITECUSTOMFIELD_02",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_03",
        "field": "MARKET_SITECUSTOMFIELD_03",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_04",
        "field": "MARKET_SITECUSTOMFIELD_04",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_05",
        "field": "MARKET_SITECUSTOMFIELD_05",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_06",
        "field": "MARKET_SITECUSTOMFIELD_06",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_07",
        "field": "MARKET_SITECUSTOMFIELD_07",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_08",
        "field": "MARKET_SITECUSTOMFIELD_08",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_09",
        "field": "MARKET_SITECUSTOMFIELD_09",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_10",
        "field": "MARKET_SITECUSTOMFIELD_10",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_11",
        "field": "MARKET_SITECUSTOMFIELD_11",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_12",
        "field": "MARKET_SITECUSTOMFIELD_12",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_13",
        "field": "MARKET_SITECUSTOMFIELD_13",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_14",
        "field": "MARKET_SITECUSTOMFIELD_14",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_15",
        "field": "MARKET_SITECUSTOMFIELD_15",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_16",
        "field": "MARKET_SITECUSTOMFIELD_16",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_17",
        "field": "MARKET_SITECUSTOMFIELD_17",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_18",
        "field": "MARKET_SITECUSTOMFIELD_18",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_19",
        "field": "MARKET_SITECUSTOMFIELD_19",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_20",
        "field": "MARKET_SITECUSTOMFIELD_20",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_21",
        "field": "MARKET_SITECUSTOMFIELD_21",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_22",
        "field": "MARKET_SITECUSTOMFIELD_22",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_23",
        "field": "MARKET_SITECUSTOMFIELD_23",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_24",
        "field": "MARKET_SITECUSTOMFIELD_24",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_25",
        "field": "MARKET_SITECUSTOMFIELD_25",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_26",
        "field": "MARKET_SITECUSTOMFIELD_26",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_27",
        "field": "MARKET_SITECUSTOMFIELD_27",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_28",
        "field": "MARKET_SITECUSTOMFIELD_28",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_29",
        "field": "MARKET_SITECUSTOMFIELD_29",
        "width": "240px"
    },
    {
        "title": "MARKET_SITECUSTOMFIELD_30",
        "field": "MARKET_SITECUSTOMFIELD_30",
        "width": "240px"
    },
    {
        "title": "DB_RECORD_ID",
        "field": "DB_RECORD_ID",
        "width": "240px"
    },
    {
        "title": "HISTORY_ID",
        "field": "HISTORY_ID",
        "width": "240px"
    },
    {
        "title": "MODIFIED_BY",
        "field": "MODIFIED_BY",
        "width": "240px"
    },
    {
        "title": "MODIFIED_DATE",
        "field": "MODIFIED_DATE",
        "width": "240px"
    },
    {
        "title": "HISTORY_STATUS",
        "field": "HISTORY_STATUS",
        "width": "240px"
    },
    {
        "title": "VZ_SPM_PROJECT_IN_SERVICE",
        "field": "VZ_SPM_PROJECT_IN_SERVICE",
        "width": "240px"
    },
    {
        "title": "VZ_SPM_PROJECT_LINK",
        "field": "VZ_SPM_PROJECT_LINK",
        "width": "240px"
    },
    {
        "title": "VZ_SPM_PROJECT_NAME",
        "field": "VZ_SPM_PROJECT_NAME",
        "width": "240px"
    },
    {
        "title": "VZ_SPM_PROJECT_PLAN_YEAR",
        "field": "VZ_SPM_PROJECT_PLAN_YEAR",
        "width": "240px"
    },
    {
        "title": "VZ_SPM_PROJECT_RF_ENGINEER",
        "field": "VZ_SPM_PROJECT_RF_ENGINEER",
        "width": "240px"
    },
    {
        "title": "VZ_SPM_PROJECT_STATUS",
        "field": "VZ_SPM_PROJECT_STATUS",
        "width": "240px"
    },
    {
        "title": "VZ_SPM_PROJECT_TYPE",
        "field": "VZ_SPM_PROJECT_TYPE",
        "width": "240px"
    },
    {
        "title": "VZ_SPM_SITE_RF_ENGINEER",
        "field": "VZ_SPM_SITE_RF_ENGINEER",
        "width": "240px"
    },
    {
        "title": "VZ_5GC_MARKET",
        "field": "VZ_5GC_MARKET",
        "width": "240px"
    },
    {
        "title": "RFDS_LOCK",
        "field": "RFDS_LOCK",
        "width": "240px"
    },
    {
        "title": "CQ_LOCK",
        "field": "CQ_LOCK",
        "width": "240px"
    },
    {
        "title": "VZ_MONTHLY_RENT",
        "field": "VZ_MONTHLY_RENT",
        "width": "240px"
    },
    {
        "title": "VZ_LAST_EFFECTIVE_DATE",
        "field": "VZ_LAST_EFFECTIVE_DATE",
        "width": "240px"
    },
    {
        "title": "VZ_PROJECTED_ON_AIR_DATE",
        "field": "VZ_PROJECTED_ON_AIR_DATE",
        "width": "240px"
    },
    {
        "title": "VZ_GP_STRUCT_TYPE",
        "field": "VZ_GP_STRUCT_TYPE",
        "width": "240px"
    },
    {
        "title": "VZ_SITE_TYPE",
        "field": "VZ_SITE_TYPE",
        "width": "240px"
    },
    {
        "title": "VZ_SITE_SUB_TYPE",
        "field": "VZ_SITE_SUB_TYPE",
        "width": "240px"
    },
    {
        "title": "VZ_APP_NAME",
        "field": "VZ_APP_NAME",
        "width": "240px"
    },
    {
        "title": "VZ_CHANGE_NOTIFICATION_ACTIVE",
        "field": "VZ_CHANGE_NOTIFICATION_ACTIVE",
        "width": "240px"
    },
    {
        "title": "VZ_SOURCE_SITE_RECORD_ID",
        "field": "VZ_SOURCE_SITE_RECORD_ID",
        "width": "240px"
    },
    {
        "title": "VZ_NPP_AREA",
        "field": "VZ_NPP_AREA",
        "width": "240px"
    },
    {
        "title": "VZ_NPP_MARKET",
        "field": "VZ_NPP_MARKET",
        "width": "240px"
    },
    {
        "title": "VZ_NPP_LTE_MARKET_NAME",
        "field": "VZ_NPP_LTE_MARKET_NAME",
        "width": "240px"
    },
    {
        "title": "VZ_HQ_AREA",
        "field": "VZ_HQ_AREA",
        "width": "240px"
    },
    {
        "title": "VZ_LONG_TERM_TEMP",
        "field": "VZ_LONG_TERM_TEMP",
        "width": "240px"
    }
]

var transmittersHistoryGridColumns = [
    {
        "title": "SITE_NAME",
        "field": "SITE_NAME",
        "width": "240px"
    },
    {
        "title": "TX_ID",
        "field": "TX_ID",
        "width": "240px"
    },
    {
        "title": "ACTIVE",
        "field": "ACTIVE",
        "width": "240px"
    },
    {
        "title": "DX",
        "field": "DX",
        "width": "240px"
    },
    {
        "title": "DY",
        "field": "DY",
        "width": "240px"
    },
    {
        "title": "FBAND",
        "field": "FBAND",
        "width": "240px"
    },
    {
        "title": "ANTENNA_NAME",
        "field": "ANTENNA_NAME",
        "width": "240px"
    },
    {
        "title": "HEIGHT",
        "field": "HEIGHT",
        "width": "240px"
    },
    {
        "title": "AZIMUT",
        "field": "AZIMUT",
        "width": "240px"
    },
    {
        "title": "TILT",
        "field": "TILT",
        "width": "240px"
    },
    {
        "title": "CALC_RADIUS",
        "field": "CALC_RADIUS",
        "width": "240px"
    },
    {
        "title": "PROPAG_MODEL",
        "field": "PROPAG_MODEL",
        "width": "240px"
    },
    {
        "title": "TXLOSSES",
        "field": "TXLOSSES",
        "width": "240px"
    },
    {
        "title": "RXLOSSES",
        "field": "RXLOSSES",
        "width": "240px"
    },
    {
        "title": "NOISE_FIGURE",
        "field": "NOISE_FIGURE",
        "width": "240px"
    },
    {
        "title": "COMMENT_",
        "field": "COMMENT_",
        "width": "240px"
    },
    {
        "title": "TMA_NAME",
        "field": "TMA_NAME",
        "width": "240px"
    },
    {
        "title": "FEEDER_NAME",
        "field": "FEEDER_NAME",
        "width": "240px"
    },
    {
        "title": "BTS_NAME",
        "field": "BTS_NAME",
        "width": "240px"
    },
    {
        "title": "FEEDERLENGTH_DL",
        "field": "FEEDERLENGTH_DL",
        "width": "240px"
    },
    {
        "title": "FEEDERLENGTH_UL",
        "field": "FEEDERLENGTH_UL",
        "width": "240px"
    },
    {
        "title": "MISCDLL",
        "field": "MISCDLL",
        "width": "240px"
    },
    {
        "title": "MISCULL",
        "field": "MISCULL",
        "width": "240px"
    },
    {
        "title": "CALC_RADIUS2",
        "field": "CALC_RADIUS2",
        "width": "240px"
    },
    {
        "title": "PROPAG_MODEL2",
        "field": "PROPAG_MODEL2",
        "width": "240px"
    },
    {
        "title": "CALC_RESOLUTION",
        "field": "CALC_RESOLUTION",
        "width": "240px"
    },
    {
        "title": "CALC_RESOLUTION2",
        "field": "CALC_RESOLUTION2",
        "width": "240px"
    },
    {
        "title": "REDT",
        "field": "REDT",
        "width": "240px"
    },
    {
        "title": "MAX_RANGE",
        "field": "MAX_RANGE",
        "width": "240px"
    },
    {
        "title": "SHAREDPATTERN",
        "field": "SHAREDPATTERN",
        "width": "240px"
    },
    {
        "title": "USE_ABS_XY",
        "field": "USE_ABS_XY",
        "width": "240px"
    },
    {
        "title": "ABS_X",
        "field": "ABS_X",
        "width": "240px"
    },
    {
        "title": "ABS_Y",
        "field": "ABS_Y",
        "width": "240px"
    },
    {
        "title": "TX_TYPE",
        "field": "TX_TYPE",
        "width": "240px"
    },
    {
        "title": "BF_MODEL",
        "field": "BF_MODEL",
        "width": "240px"
    },
    {
        "title": "N_TX_ANTENNAS",
        "field": "N_TX_ANTENNAS",
        "width": "240px"
    },
    {
        "title": "N_RX_ANTENNAS",
        "field": "N_RX_ANTENNAS",
        "width": "240px"
    },
    {
        "title": "N_TX_PA",
        "field": "N_TX_PA",
        "width": "240px"
    },
    {
        "title": "VZ_SECTOR",
        "field": "VZ_SECTOR",
        "width": "240px"
    },
    {
        "title": "VZ_ENODEB_VENDOR",
        "field": "VZ_ENODEB_VENDOR",
        "width": "240px"
    },
    {
        "title": "VZ_ENODEB_MODEL",
        "field": "VZ_ENODEB_MODEL",
        "width": "240px"
    },
    {
        "title": "VZ_MISC_TXLOSS_COM",
        "field": "VZ_MISC_TXLOSS_COM",
        "width": "240px"
    },
    {
        "title": "VZ_MISC_RXLOSS_COM",
        "field": "VZ_MISC_RXLOSS_COM",
        "width": "240px"
    },
    {
        "title": "VZ_TMA_JUMPER_LOSS",
        "field": "VZ_TMA_JUMPER_LOSS",
        "width": "240px"
    },
    {
        "title": "VZ_EPA_INPUT_JUMLOSS",
        "field": "VZ_EPA_INPUT_JUMLOSS",
        "width": "240px"
    },
    {
        "title": "VZ_SYST_NOISE_TEMP",
        "field": "VZ_SYST_NOISE_TEMP",
        "width": "240px"
    },
    {
        "title": "VZ_TMA_BENEFIT_GAIN",
        "field": "VZ_TMA_BENEFIT_GAIN",
        "width": "240px"
    },
    {
        "title": "VZ_EPA_MODEL",
        "field": "VZ_EPA_MODEL",
        "width": "240px"
    },
    {
        "title": "VZ_EPA_MANUFACTURER",
        "field": "VZ_EPA_MANUFACTURER",
        "width": "240px"
    },
    {
        "title": "VZ_TMA_MODEL",
        "field": "VZ_TMA_MODEL",
        "width": "240px"
    },
    {
        "title": "VZ_TMA_MANUFACTURER",
        "field": "VZ_TMA_MANUFACTURER",
        "width": "240px"
    },
    {
        "title": "VZ_TRANSMITTER_CODE",
        "field": "VZ_TRANSMITTER_CODE",
        "width": "240px"
    },
    {
        "title": "VZ_FEEDER_LOSS_RX",
        "field": "VZ_FEEDER_LOSS_RX",
        "width": "240px"
    },
    {
        "title": "VZ_FEEDER_LOSS_TX",
        "field": "VZ_FEEDER_LOSS_TX",
        "width": "240px"
    },
    {
        "title": "VZ_RRH_MANUFACTURER",
        "field": "VZ_RRH_MANUFACTURER",
        "width": "240px"
    },
    {
        "title": "VZ_RRH_MODEL",
        "field": "VZ_RRH_MODEL",
        "width": "240px"
    },
    {
        "title": "VZ_AUTO_MODEL_ASSIGNMENT",
        "field": "VZ_AUTO_MODEL_ASSIGNMENT",
        "width": "240px"
    },
    {
        "title": "VZ_LTE_CELL_TYPE",
        "field": "VZ_LTE_CELL_TYPE",
        "width": "240px"
    },
    {
        "title": "VZ_CLUTTER_CLASS",
        "field": "VZ_CLUTTER_CLASS",
        "width": "240px"
    },
    {
        "title": "VZ_PROP_CLASS",
        "field": "VZ_PROP_CLASS",
        "width": "240px"
    },
    {
        "title": "VZ_CLUTTER_HEIGHT",
        "field": "VZ_CLUTTER_HEIGHT",
        "width": "240px"
    },
    {
        "title": "VZ_BUILDING_TYPE",
        "field": "VZ_BUILDING_TYPE",
        "width": "240px"
    },
    {
        "title": "VZ_BUILDING_HEIGHT",
        "field": "VZ_BUILDING_HEIGHT",
        "width": "240px"
    },
    {
        "title": "VZ_ANTENNA_ENVIRON",
        "field": "VZ_ANTENNA_ENVIRON",
        "width": "240px"
    },
    {
        "title": "VZ_HEIGHT_DIFFERENCE",
        "field": "VZ_HEIGHT_DIFFERENCE",
        "width": "240px"
    },
    {
        "title": "VZ_ENVIRON_MORPH",
        "field": "VZ_ENVIRON_MORPH",
        "width": "240px"
    },
    {
        "title": "VZ_REMOTE_ELEC_TILT",
        "field": "VZ_REMOTE_ELEC_TILT",
        "width": "240px"
    },
    {
        "title": "VZ_E911_LONGITUDE",
        "field": "VZ_E911_LONGITUDE",
        "width": "240px"
    },
    {
        "title": "VZ_E911_LATITUDE",
        "field": "VZ_E911_LATITUDE",
        "width": "240px"
    },
    {
        "title": "VZ_E911_ADDRESS",
        "field": "VZ_E911_ADDRESS",
        "width": "240px"
    },
    {
        "title": "VZ_E911_CITY",
        "field": "VZ_E911_CITY",
        "width": "240px"
    },
    {
        "title": "VZ_E911_STATE",
        "field": "VZ_E911_STATE",
        "width": "240px"
    },
    {
        "title": "VZ_E911_COUNTY",
        "field": "VZ_E911_COUNTY",
        "width": "240px"
    },
    {
        "title": "VZ_E911_DISPATCH_LOC",
        "field": "VZ_E911_DISPATCH_LOC",
        "width": "240px"
    },
    {
        "title": "VZ_E911_ZIPCODE",
        "field": "VZ_E911_ZIPCODE",
        "width": "240px"
    },
    {
        "title": "VZ_TIP_HEIGHT",
        "field": "VZ_TIP_HEIGHT",
        "width": "240px"
    },
    {
        "title": "VZ_CENTERLINE",
        "field": "VZ_CENTERLINE",
        "width": "240px"
    },
    {
        "title": "VZ_RPTR_NOISE_RISE_LOSS",
        "field": "VZ_RPTR_NOISE_RISE_LOSS",
        "width": "240px"
    },
    {
        "title": "VZ_RET_ANTENNA_UPDATE",
        "field": "VZ_RET_ANTENNA_UPDATE",
        "width": "240px"
    },
    {
        "title": "VZ_RET_ANTENNA_MODEL",
        "field": "VZ_RET_ANTENNA_MODEL",
        "width": "240px"
    },
    {
        "title": "VZ_RET_ANTENNA_COMMENT",
        "field": "VZ_RET_ANTENNA_COMMENT",
        "width": "240px"
    },
    {
        "title": "VZ_COMB_CELL_CODE",
        "field": "VZ_COMB_CELL_CODE",
        "width": "240px"
    },
    {
        "title": "VZ_TOTAL_TILT",
        "field": "VZ_TOTAL_TILT",
        "width": "240px"
    },
    {
        "title": "VZ_ANTENNA_H_BW",
        "field": "VZ_ANTENNA_H_BW",
        "width": "240px"
    },
    {
        "title": "VZ_ANTENNA_V_BW",
        "field": "VZ_ANTENNA_V_BW",
        "width": "240px"
    },
    {
        "title": "VZ_COMP_MIN_MECH_TILT",
        "field": "VZ_COMP_MIN_MECH_TILT",
        "width": "240px"
    },
    {
        "title": "VZ_COMP_MAX_MECH_TILT",
        "field": "VZ_COMP_MAX_MECH_TILT",
        "width": "240px"
    },
    {
        "title": "VZ_COMP_MIN_ELEC_TILT",
        "field": "VZ_COMP_MIN_ELEC_TILT",
        "width": "240px"
    },
    {
        "title": "VZ_COMP_MAX_ELEC_TILT",
        "field": "VZ_COMP_MAX_ELEC_TILT",
        "width": "240px"
    },
    {
        "title": "VZ_COMP_TILT_COMMENT",
        "field": "VZ_COMP_TILT_COMMENT",
        "width": "240px"
    },
    {
        "title": "VZ_STATION_TEMPLATE",
        "field": "VZ_STATION_TEMPLATE",
        "width": "240px"
    },
    {
        "title": "VZ_SECTOR_CLASSIFICATION",
        "field": "VZ_SECTOR_CLASSIFICATION",
        "width": "240px"
    },
    {
        "title": "VZ_SECTOR_RTT80",
        "field": "VZ_SECTOR_RTT80",
        "width": "240px"
    },
    {
        "title": "VZ_AMA_COMMENT",
        "field": "VZ_AMA_COMMENT",
        "width": "240px"
    },
    {
        "title": "VZ_TX_RECORD_ID",
        "field": "VZ_TX_RECORD_ID",
        "width": "240px"
    },
    {
        "title": "VZ_MIDBAND_NUM_CELLS",
        "field": "VZ_MIDBAND_NUM_CELLS",
        "width": "240px"
    },
    {
        "title": "VZ_MIDBAND_BANDWIDTH",
        "field": "VZ_MIDBAND_BANDWIDTH",
        "width": "240px"
    },
    {
        "title": "VZ_MIDBAND_PCIS",
        "field": "VZ_MIDBAND_PCIS",
        "width": "240px"
    },
    {
        "title": "VZ_5G_NW_PROJECT",
        "field": "VZ_5G_NW_PROJECT",
        "width": "240px"
    },
    {
        "title": "VZ_5G_SECTOR",
        "field": "VZ_5G_SECTOR",
        "width": "240px"
    },
    {
        "title": "VZ_MARKET_ID",
        "field": "VZ_MARKET_ID",
        "width": "240px"
    },
    {
        "title": "VZ_BASE_MARKET_ID",
        "field": "VZ_BASE_MARKET_ID",
        "width": "240px"
    },
    {
        "title": "VZ_ENODEB_ID",
        "field": "VZ_ENODEB_ID",
        "width": "240px"
    },
    {
        "title": "VZ_ENODEB_NAME",
        "field": "VZ_ENODEB_NAME",
        "width": "240px"
    },
    {
        "title": "VZ_ENODEB_FRIENDNAME",
        "field": "VZ_ENODEB_FRIENDNAME",
        "width": "240px"
    },
    {
        "title": "VZ_GNODEB_ID",
        "field": "VZ_GNODEB_ID",
        "width": "240px"
    },
    {
        "title": "VZ_GNODEB_NAME",
        "field": "VZ_GNODEB_NAME",
        "width": "240px"
    },
    {
        "title": "VZ_GNODEB_FRIENDNAME",
        "field": "VZ_GNODEB_FRIENDNAME",
        "width": "240px"
    },
    {
        "title": "VZ_5G_GNB_DU_NUMBER",
        "field": "VZ_5G_GNB_DU_NUMBER",
        "width": "240px"
    },
    {
        "title": "VZ_5G_GNB_DU_ID",
        "field": "VZ_5G_GNB_DU_ID",
        "width": "240px"
    },
    {
        "title": "VZ_5G_GNB_DU_NAME",
        "field": "VZ_5G_GNB_DU_NAME",
        "width": "240px"
    },
    {
        "title": "VZ_5G_GNB_DU_FRIENDNAME",
        "field": "VZ_5G_GNB_DU_FRIENDNAME",
        "width": "240px"
    },
    {
        "title": "VZ_GNODEB_MIXED_LABEL",
        "field": "VZ_GNODEB_MIXED_LABEL",
        "width": "240px"
    },
    {
        "title": "VZ_LTE_VENDOR_POWER",
        "field": "VZ_LTE_VENDOR_POWER",
        "width": "240px"
    },
    {
        "title": "VZ_5G_VENDOR_POWER",
        "field": "VZ_5G_VENDOR_POWER",
        "width": "240px"
    },
    {
        "title": "VZ_TOTAL_BAND_WIDTH",
        "field": "VZ_TOTAL_BAND_WIDTH",
        "width": "240px"
    },
    {
        "title": "VZ_LTE_MAX_POWER",
        "field": "VZ_LTE_MAX_POWER",
        "width": "240px"
    },
    {
        "title": "VZ_5G_MAX_POWER",
        "field": "VZ_5G_MAX_POWER",
        "width": "240px"
    },
    {
        "title": "VZ_TOTAL_ERP_W",
        "field": "VZ_TOTAL_ERP_W",
        "width": "240px"
    },
    {
        "title": "VZ_TOTAL_EIRP_W",
        "field": "VZ_TOTAL_EIRP_W",
        "width": "240px"
    },
    {
        "title": "VZ_REGULATORY_POWER",
        "field": "VZ_REGULATORY_POWER",
        "width": "240px"
    },
    {
        "title": "VZ_REGULATORY_POWER_NONPSD",
        "field": "VZ_REGULATORY_POWER_NONPSD",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_01",
        "field": "MARKET_TXCUSTOMFIELD_01",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_02",
        "field": "MARKET_TXCUSTOMFIELD_02",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_03",
        "field": "MARKET_TXCUSTOMFIELD_03",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_04",
        "field": "MARKET_TXCUSTOMFIELD_04",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_05",
        "field": "MARKET_TXCUSTOMFIELD_05",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_06",
        "field": "MARKET_TXCUSTOMFIELD_06",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_07",
        "field": "MARKET_TXCUSTOMFIELD_07",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_08",
        "field": "MARKET_TXCUSTOMFIELD_08",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_09",
        "field": "MARKET_TXCUSTOMFIELD_09",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_10",
        "field": "MARKET_TXCUSTOMFIELD_10",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_11",
        "field": "MARKET_TXCUSTOMFIELD_11",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_12",
        "field": "MARKET_TXCUSTOMFIELD_12",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_13",
        "field": "MARKET_TXCUSTOMFIELD_13",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_14",
        "field": "MARKET_TXCUSTOMFIELD_14",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_15",
        "field": "MARKET_TXCUSTOMFIELD_15",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_16",
        "field": "MARKET_TXCUSTOMFIELD_16",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_17",
        "field": "MARKET_TXCUSTOMFIELD_17",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_18",
        "field": "MARKET_TXCUSTOMFIELD_18",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_19",
        "field": "MARKET_TXCUSTOMFIELD_19",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_20",
        "field": "MARKET_TXCUSTOMFIELD_20",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_21",
        "field": "MARKET_TXCUSTOMFIELD_21",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_22",
        "field": "MARKET_TXCUSTOMFIELD_22",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_23",
        "field": "MARKET_TXCUSTOMFIELD_23",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_24",
        "field": "MARKET_TXCUSTOMFIELD_24",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_25",
        "field": "MARKET_TXCUSTOMFIELD_25",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_26",
        "field": "MARKET_TXCUSTOMFIELD_26",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_27",
        "field": "MARKET_TXCUSTOMFIELD_27",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_28",
        "field": "MARKET_TXCUSTOMFIELD_28",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_29",
        "field": "MARKET_TXCUSTOMFIELD_29",
        "width": "240px"
    },
    {
        "title": "MARKET_TXCUSTOMFIELD_30",
        "field": "MARKET_TXCUSTOMFIELD_30",
        "width": "240px"
    },
    {
        "title": "VZ_ANTENNA_POSITION",
        "field": "VZ_ANTENNA_POSITION",
        "width": "240px"
    },
    {
        "title": "VZ_ANTENNA_SECTOR",
        "field": "VZ_ANTENNA_SECTOR",
        "width": "240px"
    },
    {
        "title": "VZ_LTE_TOTAL_BAND_WIDTH",
        "field": "VZ_LTE_TOTAL_BAND_WIDTH",
        "width": "240px"
    },
    {
        "title": "VZ_PERCENT_POWER",
        "field": "VZ_PERCENT_POWER",
        "width": "240px"
    },
    {
        "title": "DB_RECORD_ID",
        "field": "DB_RECORD_ID",
        "width": "240px"
    },
    {
        "title": "HISTORY_ID",
        "field": "HISTORY_ID",
        "width": "240px"
    },
    {
        "title": "MODIFIED_BY",
        "field": "MODIFIED_BY",
        "width": "240px"
    },
    {
        "title": "MODIFIED_DATE",
        "field": "MODIFIED_DATE",
        "width": "240px"
    },
    {
        "title": "HISTORY_STATUS",
        "field": "HISTORY_STATUS",
        "width": "240px"
    },
    {
        "title": "VZ_DSS_ACTIVATION",
        "field": "VZ_DSS_ACTIVATION",
        "width": "240px"
    },
    {
        "title": "VZ_DSS_ACTIVATION_DATE",
        "field": "VZ_DSS_ACTIVATION_DATE",
        "width": "240px"
    },
    {
        "title": "VZ_BMC_CELL_RADIUS",
        "field": "VZ_BMC_CELL_RADIUS",
        "width": "240px"
    },
    {
        "title": "BF_E_TILT",
        "field": "BF_E_TILT",
        "width": "240px"
    },
    {
        "title": "VZ_SECTOR_EQUIPMENT_FUNCTION_ID",
        "field": "VZ_SECTOR_EQUIPMENT_FUNCTION_ID",
        "width": "240px"
    },
    {
        "title": "VZ_ALLOWED_MAX_POWER_CBR",
        "field": "VZ_ALLOWED_MAX_POWER_CBR",
        "width": "240px"
    },
    {
        "title": "VZ_ALLOWED_MAX_POWER_RFE",
        "field": "VZ_ALLOWED_MAX_POWER_RFE",
        "width": "240px"
    },
    {
        "title": "VZ_TX_GROUP",
        "field": "VZ_TX_GROUP",
        "width": "240px"
    },
    {
        "title": "VZ_COP_PROCESSED_DATE",
        "field": "VZ_COP_PROCESSED_DATE",
        "width": "240px"
    },
    {
        "title": "VZ_RADIO_LOCATION",
        "field": "VZ_RADIO_LOCATION",
        "width": "240px"
    },
    {
        "title": "VZ_DL_ONLY_CHANNEL",
        "field": "VZ_DL_ONLY_CHANNEL",
        "width": "240px"
    },
    {
        "title": "VZ_BEST_SERVER_CELL_RADIUS",
        "field": "VZ_BEST_SERVER_CELL_RADIUS",
        "width": "240px"
    },
    {
        "title": "VZ_CELL_RADIUS",
        "field": "VZ_CELL_RADIUS",
        "width": "240px"
    },
    {
        "title": "VZ_TX_REVISION",
        "field": "VZ_TX_REVISION",
        "width": "240px"
    },
    {
        "title": "VZ_TX_UNIQUE_KEY",
        "field": "VZ_TX_UNIQUE_KEY",
        "width": "240px"
    },
    {
        "title": "VZ_DSS_STATUS",
        "field": "VZ_DSS_STATUS",
        "width": "240px"
    },
    {
        "title": "VZ_MOUNT_FACE",
        "field": "VZ_MOUNT_FACE",
        "width": "240px"
    },
    {
        "title": "VZ_MOUNT_POSITION",
        "field": "VZ_MOUNT_POSITION",
        "width": "240px"
    },
    {
        "title": "VZ_ALLOWED_MAX_POWER_ES",
        "field": "VZ_ALLOWED_MAX_POWER_ES",
        "width": "240px"
    },
    {
        "title": "VZ_APP_NAME",
        "field": "VZ_APP_NAME",
        "width": "240px"
    },
    {
        "title": "VZ_NE_MODE",
        "field": "VZ_NE_MODE",
        "width": "240px"
    },
    {
        "title": "VZ_NE_NAME",
        "field": "VZ_NE_NAME",
        "width": "240px"
    }
]

var cellsHistoryGridColumns = [
    {
        "title": "HISTORY_ID",
        "field": "HISTORY_ID",
        "width": "240px"
    },
    {
        "title": "MODIFIED_DATE",
        "field": "MODIFIED_DATE",
        "width": "240px"
    },
    {
        "title": "MODIFIED_BY",
        "field": "MODIFIED_BY",
        "width": "240px"
    },
    {
        "title": "HISTORY_STATUS",
        "field": "HISTORY_STATUS",
        "width": "240px"
    },
    {
        "title": "CELL_ID",
        "field": "CELL_ID",
        "width": "240px"
    },
    {
        "title": "TX_ID",
        "field": "TX_ID",
        "width": "240px"
    },
    {
        "title": "ACTIVE",
        "field": "ACTIVE",
        "width": "240px"
    },
    {
        "title": "COMMENT_",
        "field": "COMMENT_",
        "width": "240px"
    },
    {
        "title": "UNIQUE_ID",
        "field": "UNIQUE_ID",
        "width": "240px"
    },
    {
        "title": "CELL_TYPE",
        "field": "CELL_TYPE",
        "width": "240px"
    },
    {
        "title": "TX_CELL_ORDER",
        "field": "TX_CELL_ORDER",
        "width": "240px"
    },
    {
        "title": "CARRIER",
        "field": "CARRIER",
        "width": "240px"
    },
    {
        "title": "PCI",
        "field": "PCI",
        "width": "240px"
    },
    {
        "title": "PSS_ID",
        "field": "PSS_ID",
        "width": "240px"
    },
    {
        "title": "SSS_ID",
        "field": "SSS_ID",
        "width": "240px"
    },
    {
        "title": "CHANNEL_STATUS",
        "field": "CHANNEL_STATUS",
        "width": "240px"
    },
    {
        "title": "PSS_ID_STATUS",
        "field": "PSS_ID_STATUS",
        "width": "240px"
    },
    {
        "title": "SSS_ID_STATUS",
        "field": "SSS_ID_STATUS",
        "width": "240px"
    },
    {
        "title": "PCI_DOMAIN_NAME",
        "field": "PCI_DOMAIN_NAME",
        "width": "240px"
    },
    {
        "title": "REUSE_DISTANCE",
        "field": "REUSE_DISTANCE",
        "width": "240px"
    },
    {
        "title": "CELL_EDGE_BOOST",
        "field": "CELL_EDGE_BOOST",
        "width": "240px"
    },
    {
        "title": "CELL_EDGE_MARGIN",
        "field": "CELL_EDGE_MARGIN",
        "width": "240px"
    },
    {
        "title": "CELL_INDIV_OFFSET",
        "field": "CELL_INDIV_OFFSET",
        "width": "240px"
    },
    {
        "title": "CELL_SELECTION_TH",
        "field": "CELL_SELECTION_TH",
        "width": "240px"
    },
    {
        "title": "CELLSIZE_RSI_MAPPING",
        "field": "CELLSIZE_RSI_MAPPING",
        "width": "240px"
    },
    {
        "title": "CYCLIC_PREFIX",
        "field": "CYCLIC_PREFIX",
        "width": "240px"
    },
    {
        "title": "DL_BEAM_USAGE",
        "field": "DL_BEAM_USAGE",
        "width": "240px"
    },
    {
        "title": "DL_CELL_EDGE_TRAFFIC",
        "field": "DL_CELL_EDGE_TRAFFIC",
        "width": "240px"
    },
    {
        "title": "DL_DIVERSITY_SUPPORT",
        "field": "DL_DIVERSITY_SUPPORT",
        "width": "240px"
    },
    {
        "title": "DL_EXTERNAL_NOISE_RISE",
        "field": "DL_EXTERNAL_NOISE_RISE",
        "width": "240px"
    },
    {
        "title": "DL_LOAD",
        "field": "DL_LOAD",
        "width": "240px"
    },
    {
        "title": "DL_MAX_LOAD",
        "field": "DL_MAX_LOAD",
        "width": "240px"
    },
    {
        "title": "DL_MU_SM_GAIN",
        "field": "DL_MU_SM_GAIN",
        "width": "240px"
    },
    {
        "title": "DL_NUM_USERS",
        "field": "DL_NUM_USERS",
        "width": "240px"
    },
    {
        "title": "EQUIPMENT",
        "field": "EQUIPMENT",
        "width": "240px"
    },
    {
        "title": "FRAME_CONFIG",
        "field": "FRAME_CONFIG",
        "width": "240px"
    },
    {
        "title": "HO_MARGIN",
        "field": "HO_MARGIN",
        "width": "240px"
    },
    {
        "title": "ICIC_MODE",
        "field": "ICIC_MODE",
        "width": "240px"
    },
    {
        "title": "ICIC_PRB_GROUP0",
        "field": "ICIC_PRB_GROUP0",
        "width": "240px"
    },
    {
        "title": "ICIC_PRB_GROUP1",
        "field": "ICIC_PRB_GROUP1",
        "width": "240px"
    },
    {
        "title": "ICIC_PRB_GROUP2",
        "field": "ICIC_PRB_GROUP2",
        "width": "240px"
    },
    {
        "title": "ICIC_SUPPORT",
        "field": "ICIC_SUPPORT",
        "width": "240px"
    },
    {
        "title": "LAYER",
        "field": "LAYER",
        "width": "240px"
    },
    {
        "title": "MAX_NEIGHB_NUMBER",
        "field": "MAX_NEIGHB_NUMBER",
        "width": "240px"
    },
    {
        "title": "MAX_EXT_NEIGHB_NUMBER",
        "field": "MAX_EXT_NEIGHB_NUMBER",
        "width": "240px"
    },
    {
        "title": "MAX_NUMBER_OF_USERS",
        "field": "MAX_NUMBER_OF_USERS",
        "width": "240px"
    },
    {
        "title": "MAX_POWER",
        "field": "MAX_POWER",
        "width": "240px"
    },
    {
        "title": "MIN_RSRP",
        "field": "MIN_RSRP",
        "width": "240px"
    },
    {
        "title": "MBSFN_SC_SPACING",
        "field": "MBSFN_SC_SPACING",
        "width": "240px"
    },
    {
        "title": "N_CRS_PORTS",
        "field": "N_CRS_PORTS",
        "width": "240px"
    },
    {
        "title": "PBCH_POWER_OFFSET",
        "field": "PBCH_POWER_OFFSET",
        "width": "240px"
    },
    {
        "title": "PDCCH_POWER_OFFSET",
        "field": "PDCCH_POWER_OFFSET",
        "width": "240px"
    },
    {
        "title": "PDCCH_SYMBOLS",
        "field": "PDCCH_SYMBOLS",
        "width": "240px"
    },
    {
        "title": "PDSCH_POWER_OFFSET",
        "field": "PDSCH_POWER_OFFSET",
        "width": "240px"
    },
    {
        "title": "PMCH_POWER_OFFSET",
        "field": "PMCH_POWER_OFFSET",
        "width": "240px"
    },
    {
        "title": "PRACH_PREAMBLE_FORMAT",
        "field": "PRACH_PREAMBLE_FORMAT",
        "width": "240px"
    },
    {
        "title": "PRACH_RB",
        "field": "PRACH_RB",
        "width": "240px"
    },
    {
        "title": "PRACH_RSI_LIST",
        "field": "PRACH_RSI_LIST",
        "width": "240px"
    },
    {
        "title": "PRACH_RSI_REQUIRED",
        "field": "PRACH_RSI_REQUIRED",
        "width": "240px"
    },
    {
        "title": "PRACH_RSI_STATUS",
        "field": "PRACH_RSI_STATUS",
        "width": "240px"
    },
    {
        "title": "PRACH_RSI_DOMAIN_NAME",
        "field": "PRACH_RSI_DOMAIN_NAME",
        "width": "240px"
    },
    {
        "title": "PRACH_SUBFRAMES",
        "field": "PRACH_SUBFRAMES",
        "width": "240px"
    },
    {
        "title": "PUCCH_PRB",
        "field": "PUCCH_PRB",
        "width": "240px"
    },
    {
        "title": "RS_EPRE",
        "field": "RS_EPRE",
        "width": "240px"
    },
    {
        "title": "SCHEDULER",
        "field": "SCHEDULER",
        "width": "240px"
    },
    {
        "title": "SS_POWER_OFFSET",
        "field": "SS_POWER_OFFSET",
        "width": "240px"
    },
    {
        "title": "TDD_SSF_CONFIG",
        "field": "TDD_SSF_CONFIG",
        "width": "240px"
    },
    {
        "title": "UL_BEAM_USAGE",
        "field": "UL_BEAM_USAGE",
        "width": "240px"
    },
    {
        "title": "UL_CELL_EDGE_NR",
        "field": "UL_CELL_EDGE_NR",
        "width": "240px"
    },
    {
        "title": "UL_DIVERSITY_SUPPORT",
        "field": "UL_DIVERSITY_SUPPORT",
        "width": "240px"
    },
    {
        "title": "UL_EXTERNAL_NOISE_RISE",
        "field": "UL_EXTERNAL_NOISE_RISE",
        "width": "240px"
    },
    {
        "title": "UL_FPC_CINR_MAX",
        "field": "UL_FPC_CINR_MAX",
        "width": "240px"
    },
    {
        "title": "UL_FPC_FACTOR",
        "field": "UL_FPC_FACTOR",
        "width": "240px"
    },
    {
        "title": "UL_FPC_NR_MAX",
        "field": "UL_FPC_NR_MAX",
        "width": "240px"
    },
    {
        "title": "UL_LOAD",
        "field": "UL_LOAD",
        "width": "240px"
    },
    {
        "title": "UL_MAX_LOAD",
        "field": "UL_MAX_LOAD",
        "width": "240px"
    },
    {
        "title": "UL_MU_SM_GAIN",
        "field": "UL_MU_SM_GAIN",
        "width": "240px"
    },
    {
        "title": "UL_NOISE_RISE",
        "field": "UL_NOISE_RISE",
        "width": "240px"
    },
    {
        "title": "UL_NUM_USERS",
        "field": "UL_NUM_USERS",
        "width": "240px"
    },
    {
        "title": "AMS_THRESHOLD",
        "field": "AMS_THRESHOLD",
        "width": "240px"
    },
    {
        "title": "VZ_CELL_NAME",
        "field": "VZ_CELL_NAME",
        "width": "240px"
    },
    {
        "title": "VZ_CELL_ID",
        "field": "VZ_CELL_ID",
        "width": "240px"
    },
    {
        "title": "VZ_SECTOR_ID",
        "field": "VZ_SECTOR_ID",
        "width": "240px"
    },
    {
        "title": "VZ_CARRIER_ID",
        "field": "VZ_CARRIER_ID",
        "width": "240px"
    },
    {
        "title": "VZ_TAC",
        "field": "VZ_TAC",
        "width": "240px"
    },
    {
        "title": "VZ_ALU_LTE_MAXPOWER",
        "field": "VZ_ALU_LTE_MAXPOWER",
        "width": "240px"
    },
    {
        "title": "VZ_ALU_LTE_RS_EPRE",
        "field": "VZ_ALU_LTE_RS_EPRE",
        "width": "240px"
    },
    {
        "title": "VZ_ALU_SS_OFFSET",
        "field": "VZ_ALU_SS_OFFSET",
        "width": "240px"
    },
    {
        "title": "VZ_ALU_PBCH_OFFSET",
        "field": "VZ_ALU_PBCH_OFFSET",
        "width": "240px"
    },
    {
        "title": "VZ_ALU_PDCCH_OFFSET",
        "field": "VZ_ALU_PDCCH_OFFSET",
        "width": "240px"
    },
    {
        "title": "VZ_ALU_PDSCH_OFFSET",
        "field": "VZ_ALU_PDSCH_OFFSET",
        "width": "240px"
    },
    {
        "title": "VZ_ERI_LTE_MAXPOWER",
        "field": "VZ_ERI_LTE_MAXPOWER",
        "width": "240px"
    },
    {
        "title": "MBSFN_CELL_TYPE",
        "field": "MBSFN_CELL_TYPE",
        "width": "240px"
    },
    {
        "title": "MBSFN_AREA_MCE",
        "field": "MBSFN_AREA_MCE",
        "width": "240px"
    },
    {
        "title": "MBSFN_AREA_ID",
        "field": "MBSFN_AREA_ID",
        "width": "240px"
    },
    {
        "title": "VZ_CARRIER_LABEL",
        "field": "VZ_CARRIER_LABEL",
        "width": "240px"
    },
    {
        "title": "VZ_ERI_CRSGAIN",
        "field": "VZ_ERI_CRSGAIN",
        "width": "240px"
    },
    {
        "title": "VZ_MCC",
        "field": "VZ_MCC",
        "width": "240px"
    },
    {
        "title": "VZ_MNC",
        "field": "VZ_MNC",
        "width": "240px"
    },
    {
        "title": "VZ_ERI_LTE_DLATTENUATION",
        "field": "VZ_ERI_LTE_DLATTENUATION",
        "width": "240px"
    },
    {
        "title": "VZ_VPI_BINPCT80",
        "field": "VZ_VPI_BINPCT80",
        "width": "240px"
    },
    {
        "title": "VZ_VPI_RTTRATIO",
        "field": "VZ_VPI_RTTRATIO",
        "width": "240px"
    },
    {
        "title": "VZ_VPI_RTTGAP",
        "field": "VZ_VPI_RTTGAP",
        "width": "240px"
    },
    {
        "title": "VZ_VPI_SPECTRUMEFFICIENCY",
        "field": "VZ_VPI_SPECTRUMEFFICIENCY",
        "width": "240px"
    },
    {
        "title": "VZ_VPI_TRGCAT",
        "field": "VZ_VPI_TRGCAT",
        "width": "240px"
    },
    {
        "title": "VZ_VPI_HEADROOM",
        "field": "VZ_VPI_HEADROOM",
        "width": "240px"
    },
    {
        "title": "VZ_ENODEB_CELL_ALIAS",
        "field": "VZ_ENODEB_CELL_ALIAS",
        "width": "240px"
    },
    {
        "title": "VZ_ERI_LTE_CONFMAXTXPWR",
        "field": "VZ_ERI_LTE_CONFMAXTXPWR",
        "width": "240px"
    },
    {
        "title": "VZ_ECGI",
        "field": "VZ_ECGI",
        "width": "240px"
    },
    {
        "title": "VZ_VPI_PRJDTOEXHAUST",
        "field": "VZ_VPI_PRJDTOEXHAUST",
        "width": "240px"
    },
    {
        "title": "VZ_NOK_LTE_PMAX",
        "field": "VZ_NOK_LTE_PMAX",
        "width": "240px"
    },
    {
        "title": "VZ_NOK_LTE_DLCELLPWRRED",
        "field": "VZ_NOK_LTE_DLCELLPWRRED",
        "width": "240px"
    },
    {
        "title": "VZ_NOK_LTE_DLRSBOOST",
        "field": "VZ_NOK_LTE_DLRSBOOST",
        "width": "240px"
    },
    {
        "title": "VZ_SEA_MAX_TX_POWER",
        "field": "VZ_SEA_MAX_TX_POWER",
        "width": "240px"
    },
    {
        "title": "VZ_SEA_TX_ATTENUATION",
        "field": "VZ_SEA_TX_ATTENUATION",
        "width": "240px"
    },
    {
        "title": "VZ_SEA_POWER_BOOST_FLAG",
        "field": "VZ_SEA_POWER_BOOST_FLAG",
        "width": "240px"
    },
    {
        "title": "VZ_SEA_POWER_OPTION",
        "field": "VZ_SEA_POWER_OPTION",
        "width": "240px"
    },
    {
        "title": "VZ_SEA_SS_GAIN",
        "field": "VZ_SEA_SS_GAIN",
        "width": "240px"
    },
    {
        "title": "VZ_SEA_PBCH_GAIN",
        "field": "VZ_SEA_PBCH_GAIN",
        "width": "240px"
    },
    {
        "title": "VZ_MIN_ALLOWED_POWER",
        "field": "VZ_MIN_ALLOWED_POWER",
        "width": "240px"
    },
    {
        "title": "VZ_MAX_ALLOWED_POWER",
        "field": "VZ_MAX_ALLOWED_POWER",
        "width": "240px"
    },
    {
        "title": "VZ_MAX_ALLOWED_POWER_SETTING_SPECTRUM_BORDER",
        "field": "VZ_MAX_ALLOWED_POWER_SETTING_SPECTRUM_BORDER",
        "width": "240px"
    },
    {
        "title": "VZ_ALLOWED_POWER_COMMENT",
        "field": "VZ_ALLOWED_POWER_COMMENT",
        "width": "240px"
    },
    {
        "title": "VZ_IOT_TAC",
        "field": "VZ_IOT_TAC",
        "width": "240px"
    },
    {
        "title": "VZ_MAX_POWER_RFE_W",
        "field": "VZ_MAX_POWER_RFE_W",
        "width": "240px"
    },
    {
        "title": "VZ_4G_ANCHOR_ENBID",
        "field": "VZ_4G_ANCHOR_ENBID",
        "width": "240px"
    },
    {
        "title": "VZ_BAND_INFO",
        "field": "VZ_BAND_INFO",
        "width": "240px"
    },
    {
        "title": "VZ_DL_FREQUENCY",
        "field": "VZ_DL_FREQUENCY",
        "width": "240px"
    },
    {
        "title": "VZ_DL_WIDTH",
        "field": "VZ_DL_WIDTH",
        "width": "240px"
    },
    {
        "title": "VZ_ARFCN",
        "field": "VZ_ARFCN",
        "width": "240px"
    },
    {
        "title": "VZ_BLOCK",
        "field": "VZ_BLOCK",
        "width": "240px"
    },
    {
        "title": "VZ_SUBBLOCK",
        "field": "VZ_SUBBLOCK",
        "width": "240px"
    },
    {
        "title": "VZ_TOTAL_ERP_W",
        "field": "VZ_TOTAL_ERP_W",
        "width": "240px"
    },
    {
        "title": "VZ_TOTAL_EIRP_W",
        "field": "VZ_TOTAL_EIRP_W",
        "width": "240px"
    },
    {
        "title": "VZ_BAND_CLASS",
        "field": "VZ_BAND_CLASS",
        "width": "240px"
    },
    {
        "title": "MARKET_CELLCUSTOMFIELD_15",
        "field": "MARKET_CELLCUSTOMFIELD_15",
        "width": "240px"
    },
    {
        "title": "VZ_LRA_MNC",
        "field": "VZ_LRA_MNC",
        "width": "240px"
    },
    {
        "title": "VZ_CELL_RECORD_ID",
        "field": "VZ_CELL_RECORD_ID",
        "width": "240px"
    },
    {
        "title": "VZ_N_RB_TOTAL",
        "field": "VZ_N_RB_TOTAL",
        "width": "240px"
    },
    {
        "title": "MARKET_CELLCUSTOMFIELD_01",
        "field": "MARKET_CELLCUSTOMFIELD_01",
        "width": "240px"
    },
    {
        "title": "MARKET_CELLCUSTOMFIELD_02",
        "field": "MARKET_CELLCUSTOMFIELD_02",
        "width": "240px"
    },
    {
        "title": "MARKET_CELLCUSTOMFIELD_03",
        "field": "MARKET_CELLCUSTOMFIELD_03",
        "width": "240px"
    },
    {
        "title": "MARKET_CELLCUSTOMFIELD_04",
        "field": "MARKET_CELLCUSTOMFIELD_04",
        "width": "240px"
    },
    {
        "title": "MARKET_CELLCUSTOMFIELD_05",
        "field": "MARKET_CELLCUSTOMFIELD_05",
        "width": "240px"
    },
    {
        "title": "MARKET_CELLCUSTOMFIELD_06",
        "field": "MARKET_CELLCUSTOMFIELD_06",
        "width": "240px"
    },
    {
        "title": "MARKET_CELLCUSTOMFIELD_07",
        "field": "MARKET_CELLCUSTOMFIELD_07",
        "width": "240px"
    },
    {
        "title": "MARKET_CELLCUSTOMFIELD_08",
        "field": "MARKET_CELLCUSTOMFIELD_08",
        "width": "240px"
    },
    {
        "title": "MARKET_CELLCUSTOMFIELD_09",
        "field": "MARKET_CELLCUSTOMFIELD_09",
        "width": "240px"
    },
    {
        "title": "MARKET_CELLCUSTOMFIELD_10",
        "field": "MARKET_CELLCUSTOMFIELD_10",
        "width": "240px"
    },
    {
        "title": "MARKET_CELLCUSTOMFIELD_11",
        "field": "MARKET_CELLCUSTOMFIELD_11",
        "width": "240px"
    },
    {
        "title": "MARKET_CELLCUSTOMFIELD_12",
        "field": "MARKET_CELLCUSTOMFIELD_12",
        "width": "240px"
    },
    {
        "title": "MARKET_CELLCUSTOMFIELD_13",
        "field": "MARKET_CELLCUSTOMFIELD_13",
        "width": "240px"
    },
    {
        "title": "MARKET_CELLCUSTOMFIELD_14",
        "field": "MARKET_CELLCUSTOMFIELD_14",
        "width": "240px"
    },
    {
        "title": "DB_RECORD_ID",
        "field": "DB_RECORD_ID",
        "width": "240px"
    },
    {
        "title": "VZ_ARFCN_UL",
        "field": "VZ_ARFCN_UL",
        "width": "240px"
    },
    {
        "title": "VZ_LTE_CELL_FRIENDNAME",
        "field": "VZ_LTE_CELL_FRIENDNAME",
        "width": "240px"
    },
    {
        "title": "VZ_4G5G_TYPE",
        "field": "VZ_4G5G_TYPE",
        "width": "240px"
    },
    {
        "title": "VZ_OPERATIONAL_STATE",
        "field": "VZ_OPERATIONAL_STATE",
        "width": "240px"
    },
    {
        "title": "VZ_E911_REQUIRED",
        "field": "VZ_E911_REQUIRED",
        "width": "240px"
    },
    {
        "title": "VZ_TVW_FOUND",
        "field": "VZ_TVW_FOUND",
        "width": "240px"
    },
    {
        "title": "VZ_APP_NAME",
        "field": "VZ_APP_NAME",
        "width": "240px"
    },
    {
        "title": "VZ_DL_ONLY_CHANNEL",
        "field": "VZ_DL_ONLY_CHANNEL",
        "width": "240px"
    },
    {
        "title": "VZ_REGULATORY_POWER",
        "field": "VZ_REGULATORY_POWER",
        "width": "240px"
    },
    {
        "title": "VZ_REGULATORY_POWER_NONPSD",
        "field": "VZ_REGULATORY_POWER_NONPSD",
        "width": "240px"
    }
]

var repeatersHistoryGridColumns = [
    {
        "title": "HISTORY_ID",
        "field": "HISTORY_ID",
        "width": "240px"
    },
    {
        "title": "MODIFIED_DATE",
        "field": "MODIFIED_DATE",
        "width": "240px"
    },
    {
        "title": "MODIFIED_BY",
        "field": "MODIFIED_BY",
        "width": "240px"
    },
    {
        "title": "HISTORY_STATUS",
        "field": "HISTORY_STATUS",
        "width": "240px"
    },
    {
        "title": "TX_ID",
        "field": "TX_ID",
        "width": "240px"
    },
    {
        "title": "DONOR_CELLID",
        "field": "DONOR_CELLID",
        "width": "240px"
    },
    {
        "title": "REC_ANTENNA",
        "field": "REC_ANTENNA",
        "width": "240px"
    },
    {
        "title": "HEIGHT",
        "field": "HEIGHT",
        "width": "240px"
    },
    {
        "title": "DOWNTILT",
        "field": "DOWNTILT",
        "width": "240px"
    },
    {
        "title": "AZIMUT",
        "field": "AZIMUT",
        "width": "240px"
    },
    {
        "title": "TOTAL_GAIN",
        "field": "TOTAL_GAIN",
        "width": "240px"
    },
    {
        "title": "AMPLIFIER_GAIN",
        "field": "AMPLIFIER_GAIN",
        "width": "240px"
    },
    {
        "title": "FEEDER_NAME",
        "field": "FEEDER_NAME",
        "width": "240px"
    },
    {
        "title": "FEEDERLENGTH",
        "field": "FEEDERLENGTH",
        "width": "240px"
    },
    {
        "title": "DONOR_LINK_TYPE",
        "field": "DONOR_LINK_TYPE",
        "width": "240px"
    },
    {
        "title": "DONOR_LINK_LOSS",
        "field": "DONOR_LINK_LOSS",
        "width": "240px"
    },
    {
        "title": "EQUIPMENT_NAME",
        "field": "EQUIPMENT_NAME",
        "width": "240px"
    },
    {
        "title": "REC_FEEDERLENGTH_UL",
        "field": "REC_FEEDERLENGTH_UL",
        "width": "240px"
    },
    {
        "title": "DONOR_PROPAG_MODEL",
        "field": "DONOR_PROPAG_MODEL",
        "width": "240px"
    },
    {
        "title": "VZ_REP_MANUFACTURER",
        "field": "VZ_REP_MANUFACTURER",
        "width": "240px"
    },
    {
        "title": "VZ_REP_MODEL",
        "field": "VZ_REP_MODEL",
        "width": "240px"
    },
    {
        "title": "FREEZETOTALGAIN",
        "field": "FREEZETOTALGAIN",
        "width": "240px"
    },
    {
        "title": "DELAY",
        "field": "DELAY",
        "width": "240px"
    },
    {
        "title": "VZ_NODE",
        "field": "VZ_NODE",
        "width": "240px"
    },
    {
        "title": "VZ_AUTO_MODEL_ASSIGNMENT",
        "field": "VZ_AUTO_MODEL_ASSIGNMENT",
        "width": "240px"
    },
    {
        "title": "VZ_CLUTTER_CLASS",
        "field": "VZ_CLUTTER_CLASS",
        "width": "240px"
    },
    {
        "title": "VZ_PROP_CLASS",
        "field": "VZ_PROP_CLASS",
        "width": "240px"
    },
    {
        "title": "VZ_CLUTTER_HEIGHT",
        "field": "VZ_CLUTTER_HEIGHT",
        "width": "240px"
    },
    {
        "title": "VZ_BUILDING_TYPE",
        "field": "VZ_BUILDING_TYPE",
        "width": "240px"
    },
    {
        "title": "VZ_BUILDING_HEIGHT",
        "field": "VZ_BUILDING_HEIGHT",
        "width": "240px"
    },
    {
        "title": "VZ_ANTENNA_ENVIRON",
        "field": "VZ_ANTENNA_ENVIRON",
        "width": "240px"
    },
    {
        "title": "VZ_HEIGHT_DIFFERENCE",
        "field": "VZ_HEIGHT_DIFFERENCE",
        "width": "240px"
    },
    {
        "title": "VZ_ENVIRON_MORPH",
        "field": "VZ_ENVIRON_MORPH",
        "width": "240px"
    },
    {
        "title": "VZ_CENTERLINE",
        "field": "VZ_CENTERLINE",
        "width": "240px"
    },
    {
        "title": "VZ_TIP_HEIGHT",
        "field": "VZ_TIP_HEIGHT",
        "width": "240px"
    },
    {
        "title": "VZ_REGULATORY_POWER",
        "field": "VZ_REGULATORY_POWER",
        "width": "240px"
    },
    {
        "title": "VZ_REGULATORY_POWER_NONPSD",
        "field": "VZ_REGULATORY_POWER_NONPSD",
        "width": "240px"
    },
    {
        "title": "VZ_TOTAL_EIRP_W",
        "field": "VZ_TOTAL_EIRP_W",
        "width": "240px"
    },
    {
        "title": "VZ_TOTAL_ERP_W",
        "field": "VZ_TOTAL_ERP_W",
        "width": "240px"
    },
    {
        "title": "DB_RECORD_ID",
        "field": "DB_RECORD_ID",
        "width": "240px"
    },
    {
        "title": "VZ_TOTAL_GAIN",
        "field": "VZ_TOTAL_GAIN",
        "width": "240px"
    },
    {
        "title": "VZ_TX_RECORD_ID",
        "field": "VZ_TX_RECORD_ID",
        "width": "240px"
    },
    {
        "title": "VZ_APP_NAME",
        "field": "VZ_APP_NAME",
        "width": "240px"
    }
]