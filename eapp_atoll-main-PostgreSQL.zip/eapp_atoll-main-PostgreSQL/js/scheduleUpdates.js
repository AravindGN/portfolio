var scheduleUpdatesDataSource = new kendo.data.DataSource({
	data: [],
});
var cronJobDataSource = new kendo.data.DataSource({
    data: [],
});
var scheduleUpdatesGridColumns = [
	{ 	title : "Select All",
		selectable: true, width: "15px" 
	},
	{
		"title": "Site Friendly Name",
		"field": "siteName",
		"template": function (dataItem) {
			if (dataItem.siteName == null || dataItem.siteName == 'null')
				return '';
			else
				return dataItem.siteName;
		},
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",

		editable: () => false
	},
	{
		"title": "Site Record Id",
		"field": "siteRecordId",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "90px",
		template: function (dataItem) {
			if (dataItem.siteRecordId == null || dataItem.siteRecordId == 'null')
				return '';
			else
				return dataItem.siteRecordId;
		},
		editable: () => false
	},
	{
		"title": "Version",
		"field": "version",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "80px",
		template: function (dataItem) {

			if (dataItem.version == null || dataItem.version == 'null')
				return '';
			else
				return dataItem.version;
		},
		editable: () => false
	},
	{
		"title": "Fuze Site Id",
		"field": "siteInfoId",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "60px",
		template: function (dataItem) {
			if (dataItem.siteInfoId == null || dataItem.siteInfoId == 'null') {
				return '';
			} else {
				return dataItem.siteInfoId;
			}

		},
		editable: () => false
	},
];
var cornJobGridColumns = [
    {
        "title": "Acknowledgment No",
        "field": "acknowledgementNum",
        "template": function (dataItem) {
            if (dataItem.acknowledgementNum == null || dataItem.acknowledgementNum == 'null')
                return '';
            else
                return dataItem.acknowledgementNum;
        },
        "filterable": {
            "cell": {
                "operator": "contains",
                "suggestionOperator": "contains"
            }
        },
        "width": "70px",

        editable: () => false
    },
    {
        "title": "Function Name",
        "field": "functionName",
        "filterable": {
            "cell": {
                "operator": "contains",
                "suggestionOperator": "contains"
            }
        },
        "width": "90px",
        template: function (dataItem) {
            if (dataItem.functionName == null || dataItem.functionName == 'null')
                return '';
            else
                return dataItem.functionName;
        },
        editable: () => false
    },
    {
        "title": "Parameters",
        "field": "parameters",
        "filterable": {
            "cell": {
                "operator": "contains",
                "suggestionOperator": "contains"
            }
        },
        "width": "80px",
        template: function (dataItem) {

            if ((dataItem.parameters == null || dataItem.parameters == 'null,null') || dataItem.parameters == 'null')
                return '';
            else
                return dataItem.parameters;
        },
        editable: () => false
    },
    {
        "title": "Market",
        "field": "market",
        "filterable": {
            "cell": {
                "operator": "contains",
                "suggestionOperator": "contains"
            }
        },
        "width": "60px",
        template: function (dataItem) {
            if (dataItem.market == null || dataItem.market == 'null') {
                return '';
            } else {
                return dataItem.market;
            }

        },
        editable: () => false
    },
    {
        "title": "Status",
        "field": "status",
        "filterable": {
            "cell": {
                "operator": "contains",
                "suggestionOperator": "contains"
            }
        },
        "width": "60px",
        template: function (dataItem) {
            if (dataItem.status == null || dataItem.status == 'null') {
                return '';
            } else {
                return dataItem.status;
            }

        },
        editable: () => false
    },
    {
        "title": "Triggered By",
        "field": "triggeredBy",
        "filterable": {
            "cell": {
                "operator": "contains",
                "suggestionOperator": "contains"
            }
        },
        "width": "60px",
        template: function (dataItem) {
            if (dataItem.triggeredBy == null || dataItem.triggeredBy == 'null') {
                return '';
            } else {
                return dataItem.triggeredBy;
            }

        },
        editable: () => false
    },
    {
        "title": "Start Time",
        "field": "startTime",
        "filterable": {
            "cell": {
                "operator": "contains",
                "suggestionOperator": "contains"
            }
        },
        "width": "60px",
        template: function (dataItem) {
            if (dataItem.startTime == null || dataItem.startTime == 'null') {
                return '';
            } else {
                return dataItem.startTime;
            }

        },
        editable: () => false
    },
    {
        "title": "End Time",
        "field": "endTime",
        "filterable": {
            "cell": {
                "operator": "contains",
                "suggestionOperator": "contains"
            }
        },
        "width": "60px",
        template: function (dataItem) {
            if (dataItem.endTime == null || dataItem.endTime == 'null') {
                return '';
            } else {
                return dataItem.endTime;
            }

        },
        editable: () => false
    },
    {
        "title": "Comments",
        "field": "comments",
        "filterable": {
            "cell": {
                "operator": "contains",
                "suggestionOperator": "contains"
            }
        },
        "width": "60px",
        template: function (dataItem) {
            if (dataItem.comments == null || dataItem.comments == 'null') {
                return '';
            } else {
                return dataItem.comments;
            }

        },
        editable: () => false
    },
];
var schedulerUpdateRes = [];
var siteAutoAjax;
var selectedSitename;
var siteVersion=[];
var atollSchemaRes = [];
var selectedFuzeSiteId; 
var isParamPresentInUrl;

/*Document Ready*/
$(document).ready(function () {
	
	if (Object.keys(featureToggleMap).includes("F92683") && featureToggleMap['F92683']) {
		$('#isNotCommonSchemaSearch').hide();
		commonSchemaSearch('commonScheduleComp');
		getSchedulerNameCommon('#commonSchedulerNameList', '#' + "commonScheduleCompSiteName");
		loadAtollRFModules();
	} else {
		$('#isNotCommonSchemaSearch').show();
		$('#commonScheduleSearch').hide();
	}
	document.getElementById("submitBtn").disabled = true;
	try {
		var env = window.location.href.includes('canvasple') ? '-PLE' : '';
		window.initClickstream({
			"system_name": "Network Planning Platform",
			"app_name": "ATOLL" + env,
			"screen_name": "Scheduled Updates",

			"showLogs": "true"
		});
	} catch (e) {
		return false;
	}

	$('#validInvalidDropdown').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
	});

	scheduleUpdatesEmptyTable();

	//reloadData();
	$.widget("custom.catautocomplete", $.ui.autocomplete, {
		_create: function () {
			this._super();
			this.widget().menu("option", "items", "> :not(.ui-autocomplete-category)");
		},
		_renderMenu: function (ul, items) {
			var self = this;
			var current = "";
			$.each(items, function (index, item) {
				if (item.category != current) {
					ul.append("<li class='ui-autocomplete-category'>" + item.category + "</li>");
					current = item.category;
				}
				self._renderItemData(ul, item);
			});
		},
	});
	buildCatauto($('#siteName'));
	getUserSchema();
	$("#atollSearchCriteria").show();
	$("#assignFiveGVirtualGrid").show();
	getSchedulerName();
    $("#reloadCronJobs").hide();
    $("#alertDivId").hide();
    if (Object.keys(featureToggleMap).includes("F79372") && featureToggleMap['F79372']){
		$("#nppapply_logs_btn").show();
	} else {
		$("#nppapply_logs_btn").hide();
	}
    if (Object.keys(featureToggleMap).includes("F92683") && featureToggleMap['F92683']) {
    	if (window.location.href.includes("?")) {
    		(localStorage.getItem('atollSchema')) ? routerParams.atollSchema = localStorage.getItem('atollSchema') : '';
    		console.log("atollSchemaLocal", routerParams.atollSchema);
    		console.log(window.location.href);
    		let url = window.location.href;
    		let splitUrl = url.split("?");
    		let params = (splitUrl[1]) ? splitUrl[1].split('&') : [];
    		console.log(params);
    		params.forEach(element => {
    			if (element) {
    				var obj = {};
    				var a = element.split("=");
    				if (a.length > 0) {
    					obj[a[0]] = a[1];
    					routerParams = { ...obj, ...routerParams };
    				}
    			}
    		});
    		if (routerParams) {
    			isParamPresentInUrl = true;
    		}
    		console.log(routerParams);
    		routerParams["siteVersion"] = (routerParams.siteVersion) ? routerParams.siteVersion.split(",") : [];
    		if (routerParams.projectNumber) {
    			getDataUsingProjectNumber(routerParams.projectNumber);
    		} else if (routerParams.siteRecordId) {
    			getDataUsingSiteRecordId(routerParams.siteRecordId);
    		} else {
    			setTimeout(() => {
    				atollSchemaCommonSearch('commonScheduleComp', routerParams.atollSchema, routerParams.fuzeSiteId, routerParams.siteVersion, 'scheduleUpdates');
    			}, 200);
    		}
    	}
    }
});

function getDataUsingSiteRecordId(siteRecordId) {
    $.ajax({
        //url: 'http://localhost:8100/npp-atoll-services/atollUtility/fetchSchemaAndFuzeSiteIdBySiteRecordId?siteRecordId=' + siteRecordId,
        url: fetchSchemaAndFuzeSiteIdBySiteRecordIdURL + siteRecordId,
        dataType: 'json',
        type: "POST",
        async: false,
        success: function(projectData) {
            console.log('roles Data ===>', projectData);
            routerParams.fuzeSiteId = projectData.VZ_SITE_INFO_ID;
            routerParams.atollSchema = projectData.ATOLL_SCHEMA;
            atollSchemaCommonSearch('commonScheduleComp', routerParams.atollSchema, routerParams.fuzeSiteId, routerParams.siteVersion, 'scheduleUpdates');
        },
        error: function(data) {
            aptAlert('Warning', 'Failed to load data!');
        }
    });
}
function getDataUsingProjectNumber(projectNumber) {
	$.ajax({
		//url: 'http://localhost:8100/npp-atoll-services/atollUtility/fetchSchemaAndFuzeSiteIdByProjectNumber?projectNumber=' + projectNumber,
		url: fetchSchemaAndFuzeSiteIdByProjectNumberURL + projectNumber,
		dataType: 'json',
		type: "POST",
		async: false,
		success: function(projectData) {
			console.log('roles Data ===>', projectData);
			routerParams.fuzeSiteId = projectData.data[0].fuzeSiteIdList[0];
			routerParams.atollSchema = projectData.data[0].schema;
			atollSchemaCommonSearch('commonScheduleComp', routerParams.atollSchema, routerParams.fuzeSiteId, routerParams.siteVersion, 'scheduleUpdates');
		},
		error: function(data) {
			aptAlert('Warning', 'Failed to load data!');
		}
	});
}


/* scheduleUpdates Kendo emepty Table */
function scheduleUpdatesEmptyTable() {

	$("#scheduleUpdatesGrid").kendoGrid({
		dataSource: scheduleUpdatesDataSource,
		columns: scheduleUpdatesGridColumns,
		sortable: true,
		filterable: {
			extra: false,
			operators: {
				string: {
					startswith: "Starts with",
					eq: "Is equal to",
					neq: "Is not equal to"
				}
			}
		},
		pageable: {
			pageSizes: 5,
			input: true,
			numeric: false,
			pageSizes: [25, 50, 75, 100, 150, 200, "All"]

		},
		change: onChange,
		dataBound: function (e) {

		},
		noRecords: {
			template: "<div style='font-size:12px;color:red'>No data available</div>"
		},

	});
	grid1 = $("#scheduleUpdatesGrid").data("kendoGrid");
}

function getNppApplyLogs() {
	var params = {
		vzid: userID,
		processName: 'SCHEDULER_UPDATES'
	}
	openNppApplyLogs(params);
}

function CronJobStatusEmptyTable() {

	$("#cronJobStatusGrid").kendoGrid({
		dataSource: cronJobDataSource,
		columns: cornJobGridColumns,   //scheduleUpdatesGridColumns
		sortable: true,
		filterable: {
			extra: false,
			operators: {
				string: {
					startswith: "Starts with",
					eq: "Is equal to",
					neq: "Is not equal to"
				}
			}
		},
		pageable: {
			pageSizes: 5,
			input: true,
			numeric: false,
			pageSizes: [25, 50, 75, 100, 150, 200, "All"]

		},
		change: function () {

		},
		dataBound: function (e) {

		},
		noRecords: {
			template: "<div style='font-size:12px;color:red'>No data available</div>"
		},

	});
	grid1 = $("#cronJobStatusGrid").data("kendoGrid");
}
function getUserSchema() {


	$.ajax({
		async: false,
		url: getAtollSchemaData,
		//url: 'http://localhost:8100/npp-atoll-services/enbgnbAssignment/getAtollSchema',
		dataType: 'json',
		type: "POST",
		contentType: 'application/json; charset=UTF-8',
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function (data) {
			atollSchemaRes = data;

		},
		error: function (data) {
			aptAlert('Warning', 'Failed to load atollSchema data!');
		}
	});
	$('#atollSchemaDropdown').html('');
	$('#atollSchemaDropdown').multiselect('destroy');
	$.each(atollSchemaRes, function (i, v) {
		$('#atollSchemaDropdown').append("<option>" + v + "</option>");
	});
	$('#atollSchemaDropdown').val('');
	$('#atollSchemaDropdown').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,

	});
}

var sechmaList = '';
var schedulerUpdateList = '';
$('#atollSchemaDropdown').change(function () {
    selectedSitename = '';
	selectedFuzeSiteId = '';
	$("#siteName").val('');
	sechmaList = $('#atollSchemaDropdown').val();
});

// get cron jobs list
function getSchedulerName() {

	$.ajax({
		async: false,
		url: fetchSchedulerNameUrl,
		// url: 'http://localhost:8100/npp-atoll-services//scheduledUpdate/fetchSchedulerName',
		dataType: 'json',
		type: "POST",
		contentType: 'application/json; charset=UTF-8',
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function (data) {
			schedulerUpdateRes = data;

		},
		error: function (data) {
			// aptAlert('Warning', 'Failed to load atollSchema data!');
		}
	});
	$('#schedulerNameList').html('');
	$('#schedulerNameList').multiselect('destroy');
	$.each(schedulerUpdateRes, function (i, v) {
		$('#schedulerNameList').append("<option>" + v + "</option>");
	});
	$('#schedulerNameList').val('', '');
	$('#schedulerNameList').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,

	});
}


// cron job list

$('#schedulerNameList').change(function () {
	$("#siteName").val('');
	schedulerUpdateList = $('#schedulerNameList').val();
});

var clearSiteFuzeSId;
// Get Schedule Updates search Data
function getScheduleUpdatesData() {
	if (Object.keys(featureToggleMap).includes("F92683") && featureToggleMap['F92683']) {
		console.log(commonSchemaSearchPayload);
		sechmaList = commonSchemaSearchPayload.atollSchema;
		selectedFuzeSiteId =  commonSchemaSearchPayload.siteName;
		selectedSitename=  commonSchemaSearchPayload.siteName;
		clearSiteFuzeSId=  commonSchemaSearchPayload.siteName;
		schedulerUpdateList = commonSchemaSearchPayload.cronjob;
		siteVersion = commonSchemaSearchPayload.siteVersion;
	}else{
		clearSiteFuzeSId = document.getElementById('siteName').value;
	}
	if(clearSiteFuzeSId == '') {
		selectedSitename = '';
		selectedFuzeSiteId = '';
	 } 
	document.getElementById("submitBtn").disabled = true;
	if ((sechmaList == '' || sechmaList == undefined || schedulerUpdateList == '' || schedulerUpdateList ==null || clearSiteFuzeSId==null || clearSiteFuzeSId =='' || clearSiteFuzeSId == undefined) && (Object.keys(featureToggleMap).includes("F92683") && featureToggleMap['F92683'])) {
		aptAlert('Warning', 'Please Select All the Mandatory fields');
		$('#loading').fadeOut();
	} else if (sechmaList == '' || sechmaList == undefined || schedulerUpdateList == '' || schedulerUpdateList ==null) {
			aptAlert('Warning', 'Please Select All the Mandatory fields');
			$('#loading').fadeOut();
	}else if(clearSiteFuzeSId !== selectedSitename) {
		selectedFuzeSiteId = '';
		selectedSitename = '';
		aptAlert('Warning', 'Incorrect Site Selected. Please choose from dropdown');
		$('#loading').fadeOut();
	}else {
		$("#loading").show();
		var scheduleUpdatePayload = {
			"cronJob": schedulerUpdateList,
			"fuzeSiteId": selectedFuzeSiteId,
			"market": sechmaList,
			"siteVersion": siteVersion
		};
		$.ajax({
			type: 'POST',
			async: false,
			// url: "http://localhost:8100/npp-atoll-services/scheduledUpdate/fetchSitesByFuze",
			url: fetchSitesByFuzeUrl,
			dataType: 'json',
			contentType: 'application/json; charset=UTF-8',
			cache: false,
			data: JSON.stringify(scheduleUpdatePayload),
			headers: {
				'Accept': 'application/json, text/plain, */*',
				'Content-Type': 'application/json'
			},
			success: function (data) {
				var scheduleUpdatesData = data;
				setTimeout(function () {

					$('#scheduleUpdatesGrid')
						.getKendoGrid()
						.setDataSource(
							new kendo.data.DataSource({
								pageSize: 25,
								data: scheduleUpdatesData,
							})
						);
				}, 1000);

				$('#loading').fadeOut();
			},
			error: function (data) {
				$('#loading').fadeOut();
			}
		});
		 
	}
}


function buildCatauto(element) {
	$(element).catautocomplete({
		minLength: 2,
		delay: 600,
		source: function (request, response) {
			$(element).addClass("ui-autocomplete-loading");
			var term = request.term;
			var suggestions = [];
			runSiteAutocomplete(term).then(function (results) {
				if (!results || !results.data || results.data.length == 0) {
					suggestions.push({ label: "Not Found.", value: "Not found.", category: "Site Results" });
					siteNameGlobal = term;
				} else {
					var obj = _.map(results.data, function convertResult(result) {
						return {
							// label: result.NAME,
							label: "(" + result.VZ_SITE_INFO_ID + ") " + result.VZ_SITE_NAME,
							value: result.VZ_SITE_NAME,
							siteName: result.VZ_SITE_NAME,
							fuzeSiteId: result.VZ_SITE_INFO_ID,
							category: "Site Results",
						};
					});
					suggestions = obj
				}
				response(_.flatten(_.filter(suggestions, Boolean)));
				$(element).removeClass("ui-autocomplete-loading");
			});
		},
		select: function (event, ui) {
			$(element).removeClass("ui-autocomplete-loading");
			selectedSitename = ui.item.siteName;
			selectedFuzeSiteId = ui.item.fuzeSiteId;
		}
	});
}

function runSiteAutocomplete(term, response) {
	if (siteAutoAjax) {
		siteAutoAjax.abort();
		siteAutoAjax = null;
	}
	term = term.toUpperCase();
	siteAutoAjax = $.get(CONTEXT_PATH + "/uui/eapp/atoll_pg/siteAutocomplete", { query: term, atollSchema: $('#atollSchemaDropdown').val() }).success().error(
		function handleError(error) {
			console.error("Something went wrong with the site search", error);
			return [];
		}
	);
	return siteAutoAjax;
}
function PopulatescheduleUpdateTabs(tabIndex) {
    if (tabIndex == '1') {
        $("#searchPanel").show();
        $("#scheduleUpdatesGrid").show();
        $("#cronJobStatusGrid").hide();
		$("#reloadCronJobs").hide();
		$("#submitBtn").show();
    } else {
        $("#searchPanel").hide();
        $("#scheduleUpdatesGrid").hide();
        $("#cronJobStatusGrid").show();
        CronJobStatusEmptyTable();
		loadCronScheduleLogs();
		$("#reloadCronJobs").show();
		$("#submitBtn").hide();
    }
}
function getCornJobsData() {
	loadCronScheduleLogs();
}
function loadCronScheduleLogs() {
	$("#loading").show();
	$.ajax({
		async: false,
		url: fetchAllCronLogsURL,
		// url: 'http://localhost:8100/npp-atoll-services/scheduledUpdate/fetchAllCronLogs',
		dataType: 'json',
		type: "POST",
		contentType: 'application/json; charset=UTF-8',
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function (data) {
			var fetchAllCronLogs = data;
		setTimeout(function () {
						$('#cronJobStatusGrid')
					.getKendoGrid()
					.setDataSource(
						new kendo.data.DataSource({
							pageSize: 25,
							data: fetchAllCronLogs,
						})
					);
					}, 100);
					$('#loading').fadeOut();

		},
		error: function (data) {
			aptAlert('Warning', 'Failed to load CronScheduleLogs data!');
			$('#loading').fadeOut();
		}
	});
}
function clearScheduleUpdateTable() {
	schedulerUpdateList = '';
	sechmaList = ''
	// reset schema list
	$('#atollSchemaDropdown').html("");
	$('#atollSchemaDropdown').multiselect("rebuild");
	$('#atollSchemaDropdown').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
	});

	// reset cron job list schedulerNameList
	$('#schedulerNameList').html("");
	$('#schedulerNameList').multiselect("rebuild");
	$('#schedulerNameList').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
	});
	$("#siteName").val('');
	selectedSitename = '';
	selectedFuzeSiteId = '';
	getUserSchema();
	getSchedulerName();
	scheduleUpdatesEmptyTable();
	document.getElementById("submitBtn").disabled = true;
}

function aptAlert(status, message) {
	$("#alertsuccess").hide();
	$("#alerterror").hide();
	//$("#alertinfo").hide();
	$("#alertwarning").hide();

	$("#alertTitle1").html(status + '!');
	$("#alert" + status.toLowerCase()).html(message);
	$("#alert" + status.toLowerCase()).show();
	$("#myModal").css(
		"margin-top",
		Math.max(0, ($(window).height() - ($("#myModal").height() + 100)) / 2));
	$("#myModal").css(
		"margin-left",
		Math.max(0, ($(window).width() - $("#myModal").width()) / 2));
	$("#myModal").modal("show");
}
var dataItem;
var rows;
function onChange(e) {
    rows = e.sender.select();
    items = [];
    if (rows.length != 0) {
        rows.each(function (e) {
            var grid = $("#scheduleUpdatesGrid").data("kendoGrid");
            dataItem = grid.dataItem(this);
            items.push(dataItem);
        });
        document.getElementById("submitBtn").disabled = false;
        console.log('items', items);
    } else {
        var uncheckedItems;
        for (var i = 0; i < items.length; i++) {
            uncheckedItems = items[i].indexOf($(this).val());
        }
        items.splice(uncheckedItems, 1);
        document.getElementById("submitBtn").disabled = true;
    }
}
var ackNum;

function invokeMechanism(){
	var submitScheduleUpdatePayload = [];
	
   for(i=0;i<items.length;i++){
	var temp = {
        siteInfoId: '',
        siteName: '',
        siteRecordId: '',
        version: ''
    }
        temp.siteInfoId = items[i].siteInfoId;
        temp.siteName = items[i].siteName;
        temp.siteRecordId = items[i].siteRecordId;
        temp.version = items[i].version;
        submitScheduleUpdatePayload.push(temp);
    }
    
    var temp2 = {
        jobName: schedulerUpdateList,
        params: submitScheduleUpdatePayload,
        schema: sechmaList,
        vzId:userID,
    }
		console.log(temp2);
    if (sechmaList == '' || sechmaList == undefined || schedulerUpdateList == '' || schedulerUpdateList ==null || schedulerUpdateList == undefined) {
    	aptAlert('Warning', 'Please Select the Mandatory fields Atoll Schema and Cron Job');
    	$('#loading').fadeOut();
    }else{
    	$.ajax({
    		url: generateAcknowledgementNumUrl,
    		// url: 'http://localhost:8100/npp-atoll-services/scheduledUpdate/generateAckNum',
    		dataType: 'json',
    		type: "POST",
    		contentType: 'application/json; charset=UTF-8',
    		data: JSON.stringify(temp2),
    		headers: {
    			'Accept': 'application/json, text/plain, */*',
    			'Content-Type': 'application/json'
    		},
    		success: function (data) {
    			ackNum = data;
    			console.log(ackNum);
    			aptAlert('Success', "Acknowledgement Number  - " +ackNum);
    		},
    		error: function (data) {
    			aptAlert('Warning', 'Failed to Generate Acknowledgement Number!');
    		}
    	});
    }

	 
}
