

$(document).ready(function () {
    $('#siteNameInput').hide();
    $('input[name="searchType"]').change(function () {
        const selected = $(this).val();  
        $('#siteRecordDatabody').empty()
      $('#siteNameField').val('');
      $('#siteRecordIdField').val('');        
        if (selected === 'siteRecordId') {
            $('#siteRecordIdInput').show();
            $('#siteNameInput').hide();
            $("#siteRecordsTable").empty();
        } else {
            $('#siteNameInput').show();           
            $('#siteRecordIdInput').hide();
            $("#siteRecordsTable").empty();
        }
    });

    let debounceTimer;

    $('#siteNameField').on('input', function () {
      clearTimeout(debounceTimer);
  
      const query = $(this).val().trim();
  
      if (query.length === 0) {
        $('#siteNameSuggestions').empty().hide();
        return;
      }
      
      debounceTimer = setTimeout(() => {
        fetchSiteNameSuggestions(query);
      }, 300);
    });
});
let lastSearchType = '';
let lastSiteRecordIds = [];
let lastSiteName = '';

$('#searchBtn').click(function () {
   
    const searchType = $('input[name="searchType"]:checked').val();
    if (searchType === 'siteRecordId') {
      const rawValue = $('#siteRecordIdField').val().trim();
      if(rawValue === ''){
        alert('Please enter site record ID');
        $('#siteNameField').val('');
      $('#siteRecordIdField').val('');
        return;
      }
        const ids = $('#siteRecordIdField').val().split(',').map(id => id.trim());
        if (ids.some(id => isNaN(parseInt(id)))) {
            alert('Only integer values allowed.')
            $('#siteNameField').val('');
      $('#siteRecordIdField').val('');
            return;
        }
        lastSearchType = 'siteRecordId';
        lastSiteRecordIds = ids;
        fetchSiteRecords(ids, '', renderGrid);
    } else {
      if($('#siteNameField').val().trim() === ''){
        alert('Please enter site Name');
        $('#siteNameField').val('');
      $('#siteRecordIdField').val('');
        return;      }
        const siteName = $('#siteNameField').val().trim();       
        if (!/^[a-zA-Z0-9 _-]+$/.test(siteName)) {
            alert('Only alphanumeric characters allowed.')
            $('#siteNameField').val('');
      $('#siteRecordIdField').val('');
            return;
        }
        lastSearchType = 'siteName';
        lastSiteName = siteName;
        fetchSiteRecords([], siteName, renderGrid);
    }

   

});
function renderGrid(data) {
  $('#gridWrapper').html('<div id="siteRecordsTable"></div>');

  $("#siteRecordsTable").kendoGrid({
    dataSource: {
      data: data,
      pageSize: 5
    },
    pageable: {
      refresh: true,
      pageSizes: [5, 10, 20, 50],
      buttonCount: 5
    },
    columns: [
      {
        field: "siteRecordId",
        title: "Site Record ID"
      },
      {
        field: "fuzeSiteId",
        title: "Fuze Site ID",
        template: function(dataItem) {
          return dataItem.fuzeSiteId ? dataItem.fuzeSiteId : "-";
        }
      },
      {
        field: "version",
        title: "Version"
      },
      {
        title: "Action",
        template: function(dataItem) {
          return `<button class="updateBtn"
                          data-id="${dataItem.siteRecordId}"
                          data-fuze="${dataItem.fuzeSiteId || ''}"
                          data-schema="${dataItem.schema || ''}"
                          data-version="${dataItem.version}">
                    Update
                  </button>`;
        },
        width: 120
      }
    ],
    dataBound: function() {
      $('.updateBtn').on('click', function () {
        currentUpdateId = $(this).data('id');
        currentOldFuzeSiteId = $(this).data('fuze') || '';
        currentSchema = $(this).data('schema');
        versionId =$(this).data('version') || '';
        $('#fuzeSiteIdInput').val(currentOldFuzeSiteId);
        $('#fuzeError').hide();
        $('#modalHeading').text(`Update Fuze Site ID for Site Record ID: ${currentUpdateId}`);
        $('#updateModal').show();
      });
    },
    noRecords: {
      template: "No records available."
    }
  });
}
function fetchSiteRecords(siteRecordIds = [], siteName = '', responseCallback) {
  const apiUrl = getSiteRecordsUrl;
  let queryParams = [];

  if (siteRecordIds.length) {
    siteRecordIds.forEach(id => {
      queryParams.push(`siteRecordId=${encodeURIComponent(id)}`);
    });
  }

  if (siteName) {
    queryParams.push(`siteName=${encodeURIComponent(siteName.toUpperCase())}`);
  }

  const finalUrl = `${apiUrl}?${queryParams.join('&')}`;
  console.log(finalUrl);

  $.ajax({
    url: finalUrl,
    method: 'GET',
    headers: {
      'Accept': 'application/json'
    },
    cache: true,
    success: function (response) {
      if (Array.isArray(response)) {
        renderGrid(response)
        if (typeof responseCallback === 'function') {
          responseCallback(response); 
        }
      } else {
        alert(response.message);
      }
    },
    error: function (xhr, status, error) {
      try {
        const errorMessage = JSON.parse(xhr.responseText)?.error?.split('|').pop().trim();
        alert(errorMessage || 'Unexpected error format.');
      } catch (e) {
        alert('Failed to fetch records: ' + (xhr.statusText || 'Unknown Error'));
      }
    }
  });
}

let currentUpdateId = null;
let currentOldFuzeSiteId = null;

function saveFuzeSiteId() {
  const newId = $('#fuzeSiteIdInput').val().trim();
  const isValid = /^[A-Z0-9-]+$/.test(newId);

  if (!isValid) {
    $('#fuzeError').show();
    return;
  }

  
  if (newId === currentOldFuzeSiteId) {
    alert('No changes detected.');
    return;
  }

  const payload = {
    siteRecordId: currentUpdateId,
    fuzeSiteId: newId,
    schema: currentSchema,
    version : versionId
  };

  $.ajax({
    url:updateFuzeSiteId,
    method: 'POST',
    contentType: 'application/json',
    data: JSON.stringify(payload),
    success: function (response) {
      alert(response.message || 'Updated successfully');
      $('#updateModal').hide();
      if(lastSearchType === 'siteRecordId'){
        fetchSiteRecords(lastSiteRecordIds, '')
      }else{
        fetchSiteRecords([],lastSiteName)
      }
    },
    error: function (xhr) {
      alert('Update failed: ' + (xhr.responseText || xhr.statusText));
    }
  });
}

function closeModal() {
  $('#updateModal').hide();
}
$(document).on('click', function(e){
  if(!$(e.target).closest('#siteNameField').length && !$(e.target).closest('#siteNameSuggestions').length){
    $('#siteNameSuggestions').hide()
  }
})
function fetchSiteNameSuggestions(siteName='') {
  const apiUrl = getAtollGlobalSiteName;
  let queryParams = [];


  if (siteName) {
    queryParams.push(`siteName=${encodeURIComponent(siteName)}`);
  }

  const finalUrl = `${apiUrl}?${queryParams.join('&')}`;
  console.log(finalUrl);

  $.ajax({
    url: finalUrl,
    method: 'GET',
    headers: {
      'Accept': 'application/json'
    },
    cache: true,
 
    success: function (data) {
      renderSuggestions(data);
    },
    error: function () {
      $('#siteNameSuggestions').html('<div style="padding:5px;">No results found</div>').show();
    }
  });
}

function renderSuggestions(data) {
  const $suggestions = $('#siteNameSuggestions');
  $suggestions.empty();

  if (!data || data.length === 0) {
    $suggestions.html('<div style="padding:5px;">No suggestions</div>').show();
    return;
  }

  data.forEach(function (item) {
    const $item = $('<div></div>')
      .addClass('suggestion-item')
      .text(item)
      .css({ padding: '5px', cursor: 'pointer' })
      .hover(function () {
        $(this).css('background-color', '#f0f0f0');
      }, function () {
        $(this).css('background-color', '#fff');
      })
      .click(function () {
        $('#siteNameField').val(item);
        $suggestions.empty().hide();
      });

    $suggestions.append($item);
  });

  $suggestions.show();
}