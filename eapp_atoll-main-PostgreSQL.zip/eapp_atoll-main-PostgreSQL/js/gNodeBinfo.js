var loadOffScreenData = true;
var fiveGVirtualDataSource;
var assignmentDataSource = new kendo.data.DataSource({
	data: [],
});
var validationDataSource = new kendo.data.DataSource({
	data: [],
});
var enodeAssignmentDataSource = new kendo.data.DataSource({
	data: [],
});
var enodeValidationDataSource = new kendo.data.DataSource({
	data: [],
});
var dataarrayNeMode = [];
var gnbID;
var assignmentData;
var physicalGnbSectorViewData;
var marketNum;
var selectedValidityFlag = [];
var selectedValidityFlagEnodeB = [];
var uniqGnbAssignmentTextId = '';
var uniqGnbValidationTextId = '';
var uniqEnbAssignmentTextId = '';
var uniqEnbValidationTextId = '';
var selectedMarketList = [];
var getIndexVal;
var phyLteFlag = false;
var atoll5GData;
var siteNameOrSiteId;
var siteAutoAjax;
var MidIndex;
var entireTerritoryList = [];
var entireAreaList = [];
var entireRegionList = [];
var current_page = 1;
var onlyExceptionFlag = false
var entireMarketList = [];
var territoryDataProvider = [];
var areasDataProvider = [];
var regionsDataProvider = [];
var marketsDataProvider = [];
var TERRITORY_DUMP = [];
var AREA_DUMP = [];
var REGION_DUMP = [];
var MARKET_DUMP = [];
var gnbAssignTerritoryList;
var gnbAssignAreaList;
var gnbAssignRegionList;
var marketsMapping = {};
var mList;
var getSelectedValue;
var activeAtollTabIndex = 1;
var spreadsheetAssignmet = 'virtualAssignmentGridInfo';
var spreadsheetConfiguration = 'configurationViewGrid';
var atollPushData = [];
var atollSchemaRes = [];
var spreadsheetTransmitterObj;
var updatePopupSpreadsheetObjBef;
var spreadsheetConfigurationObj;
var updatePopupSpreadsheetObjAft;
var editFlag = false;
var aorArea = [];
var aorRegion = [];
var aorMarket = [];
var aorTerritory = [];
var onChangeFlag = false;
var Editcount = 0;
var marketFlag = false;
var regionFlag = false
var getRowsData;
var rowNumber;
var row;
var rowrecieved;
var rowupdated;
var dataarray = [];
var dataarraylteSector = [];
var dataarrayGnbId = [];
var dataarrayGnbFriendlyname = [];
var dataarrayGnbDufriendlyname = [];
var dataarrayGnbDuNumber = [];
var dataarrayEnbId = [];
var dataarrayEnbFriendlyname = [];
var tempdataArrayFirstcopy = [];
var dataarrayGnbMixmodellable = [];
var indexOfTabs = 1;
var ParentIndex = 1;
var atollPushDataTemp = [];
var cellKeyMap = new Map();
var getMarketName
cellKeyMap.set("6", "neMode");
cellKeyMap.set("8", "fiveGSector");
cellKeyMap.set("9", "ltesector");
cellKeyMap.set("10", "gNBId");
cellKeyMap.set("11", "gNBFriendlyName");
cellKeyMap.set("12", "gNBMixedModeLabel");
cellKeyMap.set("14", "gNBDUNumber");
cellKeyMap.set("15", "gNBDUFriendlyname");
cellKeyMap.set("18", "eNBID");
cellKeyMap.set("19", "eNBFriendlyName");
var fRValues = "No Value";
var fr1Fr2DropdownList = ["No Value", "FR1", "FR2"];
var activeAtollTabIndex = 1;
var getIndex = 1;
var marketsSelected = '';
var vendorVal = '';
var validityFlag = '';
var validationData;
var vVendorVal = '';
var returnedData;
var enodeInnerHtml;
var vzEnodebVendorHtml;
var dataFr2;
var fetchGnbDUNumbers = [];
var virtualGnbData = [];
var gbEbIndex;
var gNodeBSelected = true;
var eNodeBSelected = false;
var gNodeBAssignment = true;
var gNodeBValidation = false;
var eNodeBAssignment = false;
var eNodeBValidation = false;
var getEndVal = $("#NBTextNum").val();
var enbAText = $("#eANodebIdSelect").val('');
var enbVText;
enbVText = $("#eNBTextNum").val();
var enodeBValidationResData;
var getSectorCarrierGridData;
var gnodeb = '';
var validAssignmentFlag = [];
var getMarketId;
var fetchEnbM1Data;
var fetchEnbM2Data;
var fetchEnbM3Data;
var mrkNumOne;
var mrkNumTwo;
var mrkNumThree;
var resultVal;
var resultKeys = [];
var result2Keys = [];
var enbDrillViewData;
var assignmentEnodeData;
var getBoxClickId;
var sectorCarrirEndPayload = {};
var golbelMId;
var updatedMarketList = [];
var assignmentEnodeData;
var virtualDuIds;
var sechmaList = 'None Selected';
var getSitesV = [];
var selectedSitename;
var selectedsiteversion = [];
var atollTramitterData = [];
var assignmentVirtualPayload;
var cellValueExceeded = false;
var Editcount = 0;
var getRowsData;
var rowNumber;
var areaFlag = false;
let physicalMarket = ""
let fetchPhyGnbs = [];
var assignedCellPercentCapChng;
var atollPushDataCopy = [];
var siteVersions=[];
var tabIndexEnbAtollUpdate;
var drilldata;
var enbSelData1;
var enbSecData1;
var enbSecTabData1;
var kendoGridFirstTimeLoad = false;
var gnbvirtualDuIds;
var marketInAorAvailable;
var isRowDataEdited = false;

var cranHubNameHide = false;
var isParamPresentInUrl = false;
var builtInFlag = Object.keys(featureToggleMap).includes("F89366") && featureToggleMap['F89366'];

var val = JSON.parse(localStorage.getItem("geoLabelData"));
var physicalgNBEVendorList = [];
var selectedPhysicalgNBEVendor;
var selectedPhysicalgNBEMiddleDigit;
var selectedDuExpansionVendor;
var selectedFirstDuDigit;
var useCaseValue = "";
var physicalExpAction = "add";
var duExpansionAction = "add";
var selectedFRMappingVal;
var selectedFRMappingValDu;
var physicalgNBEMiddleList = [];
var duExpansionVendorList = [];
var actionUrl = "";
var reqBodyParam = "";
var middleFR2 = [];
var middleFR1 = [];

var assignmentGridColumns = [
	{
		"title": "gNB",
		"field": "vzGnodebId",
		"template": "<a  class='anchorNavLinkStyle' >#=vzGnodebId#</a>",
		click(e) {

		},
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",

		editable: () => false
	},
	{
		"title": "gNBVendor",
		"field": "vzEnodebVendor",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "90px",
		template: function(dataItem) {
			if (dataItem.vzEnodebVendor == null || dataItem.vzEnodebVendor == 'null')
				return '';
			else
				return dataItem.vzEnodebVendor;
		},
		editable: () => false
	},
	{
		"title": geolabelDetail(),
		"field": "market",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "80px",
		template: function(dataItem) {

			if (dataItem.market == null || dataItem.market == 'null')
				return '';
			else
				return dataItem.market;
		},
		editable: () => false
	},
	{
		"title": "vCU",
		"field": "vCU",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "60px",
		template: function(dataItem) {
			if (dataItem.vCU == null || dataItem.vCU == 'null') {
				return '';
			} else {
				return dataItem.vCU;
			}

		},
		editable: () => false
	},
	{
		title: "Assigned DU Count(gNB)",
		field: "assignedDUCountgNB",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		width: "80px",
		template: function(dataItem) {
			if (dataItem.assignedDUCountgNB == null || dataItem.assignedDUCountgNB == 'null')
				return '';
			else
				return dataItem.assignedDUCountgNB;
		},
		editable: () => false
	},
	{
		title: "Assigned DU Count(VCU)",
		field: "assignedDUCountVCU",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		width: "80px",
		template: function(dataItem) {

			if (dataItem.assignedDUCountVCU == null || dataItem.assignedDUCountVCU == 'null')
				return '';
			else
				return dataItem.assignedDUCountVCU;

		},
		editable: () => false
	},
	{
		"title": "Assigned Cell Count (GNB)",
		"field": "assignedCellCountgNB",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "80px",
		template: function(dataItem) {
			if (dataItem.assignedCellCountgNB == null || dataItem.assignedCellCountgNB == 'null')
				return '';
			else
				return dataItem.assignedCellCountgNB;
		},
		editable: () => false
	},
	{
		"title": "Assigned Cell Count (VCU)",
		"field": "assignedCellCountVCU",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "80px",
		template: function(dataItem) {
			if (dataItem.assignedCellCountVCU == null || dataItem.assignedCellCountVCU == 'null')
				return '';
			else
				return dataItem.assignedCellCountVCU;

		},
		editable: () => false
	},
	{
		"title": "Assigned Cell % (GNB)",
		"field": "assignedCellPercentgNB",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "80px",
		template: function(dataItem) {
			if (dataItem.assignedCellPercentgNB == null || dataItem.assignedCellPercentgNB == 'null')
				return '';
			else
				return dataItem.assignedCellPercentgNB;
		},
		editable: () => false,
		hidden: assignedCellPercentCapChng
	},
	{
		"title": "Assigned Cell % (VCU)",
		"field": "assignedCellPercentVCU",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "80px",
		template: function(dataItem) {
			if (dataItem.assignedCellPercentVCU == null || dataItem.assignedCellPercentVCU == 'null')
				return '';
			else
				return dataItem.assignedCellPercentVCU;

		},
		editable: () => false,
		hidden: assignedCellPercentCapChng
	},
	{
		"title": "Available Cell Count (gNB)",
		"field": "availableCellCountgNB",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "80px",
		template: function(dataItem) {
			if (dataItem.availableCellCountgNB == null || dataItem.availableCellCountgNB == 'null')
				return '';
			else
				return dataItem.availableCellCountgNB;
		},
		editable: () => false
	},
	{
		"title": "Available Cell Count (VCU)",
		"field": "availableCellCountVCU",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "80px",
		template: function(dataItem) {
			if (dataItem.availableCellCountVCU == null || dataItem.availableCellCountVCU == 'null')
				return '';
			else
				return dataItem.availableCellCountVCU;

		},
		editable: () => false
	},
	{
		"title": "FR1",
		"field": "fR1",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "60px",
		template: function(dataItem) {
			if (dataItem.fR1 == null || dataItem.fR1 == 'null')
				return '';
			else
				return dataItem.fR1;
		},
		editable: () => false
	},
	{
		"title": "FR2",
		"field": "fR2",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "60px",
		template: function(dataItem) {
			if (dataItem.fR2 == null || dataItem.fR2 == 'null')
				return '';
			else
				return dataItem.fR2;
		},
		editable: () => false
	},
	{
		"title": "Hub Name",
		"field": "cranHubName",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "60px",
		template: function(dataItem) {
			if (dataItem.cranHubName == null || dataItem.cranHubName == 'null')
				return '';
			else
				return dataItem.cranHubName;
		},
		editable: () => false,
		hidden: cranHubNameHide
	}
];
function geolabelDetail(){

    var check;
    if(val){
        if (val['GEO4']) {
            check=val['GEO4'];
        }
    }else{
        check="MARKET";
    }
    return check;
}
function geoMarketIDdetail(){
    var check;
    if(val){
        if (val['GEO4']) {
            check=val['GEO4'] + 'ID';
        }
    }else{
        check="MARKET ID";
    }
    return check;
}
var enodbAssignmentGridColumns = [
	{
		"title": geolabelDetail(),
		"field": "market",

		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",

		editable: () => false
	},
	{
		"title": "Fuze Site ID",
		"field": "enbsectorcarrier.siteFUZEID",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "90px",
		template: function(dataItem) {

			if (dataItem.enbsectorcarrier.siteFUZEID == '<Multiple>')
				return '&ltMultiple&gt';
			else if (dataItem.enbsectorcarrier.siteFUZEID == null || dataItem.enbsectorcarrier.siteFUZEID == 'null') {
				return '';
			}
			return dataItem.enbsectorcarrier.siteFUZEID;
		},
		editable: () => false
	},
	{
		"title": "Site Name",
		"field": "enbsectorcarrier.siteName",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "80px",
		template: function(dataItem) {
			if (dataItem.enbsectorcarrier.siteName == '<Multiple>')
				return '&lt;Multiple&gt;';
			else if (dataItem.enbsectorcarrier.siteName == null || dataItem.enbsectorcarrier.siteName == 'null') {
				return '';
			}
			return dataItem.enbsectorcarrier.siteName;
		},
		editable: () => false
	},
	{
		"title": "Site Version",
		"field": "enbsectorcarrier.siteVersion",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "60px",
		template: function(dataItem) {
			if (dataItem.enbsectorcarrier.siteVersion == null || dataItem.enbsectorcarrier.siteVersion == 'null') {
				return '';
			} else {
				return dataItem.enbsectorcarrier.siteVersion;
			}

		},
		editable: () => false
	},
	{
		title: "Vendor",
		field: "vendor",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		width: "80px",
		template: function(dataItem) {
			if (dataItem.vendor == null || dataItem.vendor == 'null')
				return '';
			else
				return dataItem.vendor;
		},
		editable: () => false
	},
	{
		title: "eNB",
		field: "eNB",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		width: "80px",
		template: function(dataItem) {

			if (dataItem.eNB == null || dataItem.eNB == 'null')
				return '';
			else
				return dataItem.eNB;

		},
		editable: () => false
	},
	{
		"title": "Sector",
		"field": "sector",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "80px",
		template: function(dataItem) {
			if (dataItem.sector == null || dataItem.sector == 'null')
				return '';
			else
				return dataItem.sector;
		},
		editable: () => false
	},
	{
		"title": "Carrier",
		"field": "carrier",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "80px",
		template: function(dataItem) {
			if (dataItem.carrier == null || dataItem.carrier == 'null')
				return '';
			else
				return dataItem.carrier;

		},
		editable: () => false
	},
	{
		"title": "Frequency Band",
		"field": "frequencyBand",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "80px",
		template: function(dataItem) {
			if (dataItem.frequencyBand == null || dataItem.frequencyBand == 'null')
				return '';
			else
				return dataItem.frequencyBand;
		},
		editable: () => false
	},
	{
		"title": "Center Channel",
		"field": "centreChannel",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "80px",
		template: function(dataItem) {
			if (dataItem.centreChannel == null || dataItem.centreChannel == 'null')
				return '';
			else
				return dataItem.centreChannel;

		},
		editable: () => false
	},
	{
		"title": "BW",
		"field": "bw",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "60px",
		template: function(dataItem) {
			if (dataItem.bw == null || dataItem.bw == 'null')
				return '';
			else
				return dataItem.bw;
		},
		editable: () => false
	},
	{
		"title": "Status",
		"field": "enbsectorcarrier.status",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "60px",
		template: function(dataItem) {
			if (dataItem.enbsectorcarrier.status == null || dataItem.enbsectorcarrier.status == 'null')
				return '';
			else
				return dataItem.enbsectorcarrier.status;
		},
		editable: () => false
	},
	{
		"title": "Hub Name",
		"field": "cranHubName",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "60px",
		template: function(dataItem) {
			if (dataItem.cranHubName == null || dataItem.cranHubName == 'null')
				return '';
			else
				return dataItem.cranHubName;
		},
		editable: () => false,
		hidden: cranHubNameHide
	}
];
var validationGridColumns = [
	{
		"title": "Validity Flag",
		"field": "validFlag",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",
		template: function(dataItem) {
			if (dataItem.validFlag == null || dataItem.validFlag == 'null')
				return '';
			else
				return dataItem.validFlag;
		},
		editable: () => false,

	},
	{
		"title": "Site Version",
		"field": "siteVersion",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",
		template: function(dataItem) {
			if (dataItem.siteVersion == null || dataItem.siteVersion == 'null')
				return '';
			else
				return dataItem.siteVersion;
		},
		editable: () => false,

	},
	{
		"title": "Vendor",
		"field": "vzEnodebVendor",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",
		template: function(dataItem) {
			if (dataItem.vzEnodebVendor == null || dataItem.vzEnodebVendor == 'null')
				return '';
			else
				return dataItem.vzEnodebVendor;
		},
		editable: () => false,

	},
	{
		"title": "Schema",
		"field": "schema",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",
		template: function(dataItem) {

			if (dataItem.schema == null || dataItem.schema == 'null')
				return '';
			else
				return dataItem.schema;
		},
		editable: () => false
	},
	{
		"title": "vCU",
		"field": "vcu",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "60px",
		template: function(dataItem) {
			if (dataItem.vcu == null || dataItem.vcu == 'null')
				return '';
			else
				return dataItem.vcu;
		},
		editable: () => false
	},
	{
		"title": "gNB Id",
		"field": "vzGnodebId",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "60px",
		template: function(dataItem) {
			if (dataItem.vzGnodebId == null || dataItem.vzGnodebId == 'null')
				return '';
			else
				return dataItem.vzGnodebId;
		},
		editable: () => false
	},
	{
		"title": "gNB DU Number",
		"field": "vzGnbDuNumber",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",
		template: function(dataItem) {
			if (dataItem.vzGnbDuNumber == null || dataItem.vzGnbDuNumber == 'null')
				return '';
			else
				return dataItem.vzGnbDuNumber;
		},
		editable: () => false
	},
	{
		"title": "gNB DU ID",
		"field": "vzGnbDuId",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "80px",
		template: function(dataItem) {
			if (dataItem.vzGnbDuId == null || dataItem.vzGnbDuId == 'null')
				return '';
			else
				return dataItem.vzGnbDuId;
		},
		editable: () => false
	},
	{
		"title": "Sector",
		"field": "sector",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "80px",
		template: function(dataItem) {
			if (dataItem.sector == null || dataItem.sector == 'null')
				return '';
			else
				return dataItem.sector;
		},
		editable: () => false
	},
	{
		"title": "Frequency Band",
		"field": "fBand",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "90px",
		template: function(dataItem) {
			if (dataItem.fBand == null || dataItem.fBand == 'null')
				return '';
			else
				return dataItem.fBand;
		},
		editable: () => false
	},
	{
		"title": "BW",
		"field": "bandwidth",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "60px",
		template: function(dataItem) {
			if (dataItem.bandwidth == null || dataItem.bandwidth == 'null')
				return '';
			else
				return dataItem.bandwidth;
		},
		editable: () => false
	},
	{
		"title": "Valid mmW BW",
		"field": "validmmWBW",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",
		template: function(dataItem) {
			if (dataItem.validmmWBW == null || dataItem.validmmWBW == 'null')
				return '';
			else
				return dataItem.validmmWBW;
		},
		editable: () => false
	},
	{
		"title": "gNB Built in USM/NSP/ENM",
		"field": "builtInSwitch",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "100px",
		template: function(dataItem) {
			if (dataItem.builtInSwitch == null || dataItem.builtInSwitch == 'null')
				return '';
			else
				return dataItem.builtInSwitch;
		},
		editable: () => false
	},
	{
		"title": "Valid gNB Market Number",
		"field": "validGNBMarketNumber",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",
		template: function(dataItem) {
			if (dataItem.validGNBMarketNumber == null || dataItem.validGNBMarketNumber == 'null')
				return '';
			else
				return dataItem.validGNBMarketNumber;
		},
		editable: () => false
	},
	{
		"title": "Valid gNB Middle Number",
		"field": "validGNBMiddleNumber",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",
		template: function(dataItem) {
			if (dataItem.validGNBMiddleNumber == null || dataItem.validGNBMiddleNumber == 'null')
				return '';
			else
				return dataItem.validGNBMiddleNumber;
		},
		editable: () => false
	},
	{
		"title": "Valid gNB Length",
		"field": "validGNBLength",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",
		template: function(dataItem) {
			if (dataItem.validGNBLength == null || dataItem.validGNBLength == 'null')
				return '';
			else
				return dataItem.validGNBLength;
		},
		editable: () => false
	},
	{
		"title": "Valid DU ID Length",
		"field": "validDUIdLength",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",
		template: function(dataItem) {
			if (dataItem.validDUIdLength == null || dataItem.validDUIdLength == 'null')
				return '';
			else
				return dataItem.validDUIdLength;
		},
		editable: () => false
	},
	{
		"title": "Valid 1st DU Number",
		"field": "validFirstDUNumber",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",
		template: function(dataItem) {
			if (dataItem.validFirstDUNumber == null || dataItem.validFirstDUNumber == 'null')
				return '';
			else
				return dataItem.validFirstDUNumber;
		},
		editable: () => false
	},
	{
		"title": "Valid Numeric gNBDUID and Sector",
		"field": "validNumericgNBDUIDandSector",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",
		"hidden": false,
		template: function(dataItem) {
			if (dataItem.validNumericgNBDUIDandSector == null || dataItem.validNumericgNBDUIDandSector == 'null')
				return '';
			else
				return dataItem.validNumericgNBDUIDandSector;
		},
		editable: () => false,

	},
	{
		"title": "Count of Duplicate gNBDU ID Sec",
		"field": "countDupGNBs",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "75px",
		template: function(dataItem) {
			if (dataItem.countDupGNBs == null || dataItem.countDupGNBs == 'null')
				return '';
			else
				return dataItem.countDupGNBs;
		},
		editable: () => false
	},
	{
		"title": "GNBDU ID Built in Switch",
		"field": "gNBDUBuiltInSwitch",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",
		template: function(dataItem) {
			if (dataItem.gNBDUBuiltInSwitch == null || dataItem.gNBDUBuiltInSwitch == 'null')
				return '';
			else
				return dataItem.gNBDUBuiltInSwitch;
		},
		editable: () => false
	},
	{
		"title": "County",
		"field": "county",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",
		template: function(dataItem) {
			if (dataItem.county == null || dataItem.county == 'null')
				return '';
			else
				return dataItem.county;
		},
		editable: () => false
	},
	{
		"title": "Site Info ID",
		"field": "siteInfoId",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "60px",
		template: function(dataItem) {
			if (dataItem.siteInfoId == null || dataItem.siteInfoId == 'null')
				return '';
			else
				return dataItem.siteInfoId;
		},
		editable: () => false
	},
	{
		"title": "Site Name",
		"field": "siteName",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "100px",
		template: function(dataItem) {
			if (dataItem.siteName == null || dataItem.siteName == 'null')
				return '';
			else
				return dataItem.siteName;
		},
		editable: () => false
	}
];
var enodeValidationGridColumns = [
	{
		"title": "Validity Flag",
		"field": "validFlag",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",
		template: function(dataItem) {
			if (dataItem.validFlag == null || dataItem.validFlag == 'null')
				return '';
			else
				return dataItem.validFlag;
		},
		editable: () => false,

	},
	{
		"title": "Site Version",
		"field": "siteVersion",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",
		template: function(dataItem) {
			if (dataItem.siteVersion == null || dataItem.siteVersion == 'null')
				return '';
			else
				return dataItem.siteVersion;
		},
		editable: () => false,

	},
	{
		"title": "Vendor",
		"field": "vendor",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",
		template: function(dataItem) {
			if (dataItem.vendor == null || dataItem.vendor == 'null')
				return '';
			else
				return dataItem.vendor;
		},
		editable: () => false,

	},
	{
		"title": "Schema",
		"field": "schema",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",
		template: function(dataItem) {

			if (dataItem.schema == null || dataItem.schema == 'null')
				return '';
			else
				return dataItem.schema;
		},
		editable: () => false
	},
	{
		"title": "eNB Id",
		"field": "eNodeBID",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "60px",
		template: function(dataItem) {
			if (dataItem.eNodeBID == null || dataItem.eNodeBID == 'null')
				return '';
			else
				return dataItem.eNodeBID;
		},
		editable: () => false
	},
	{
		"title": "Sector",
		"field": "sector",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "60px",
		template: function(dataItem) {
			if (dataItem.sector == null || dataItem.sector == 'null')
				return '';
			else
				return dataItem.sector;
		},
		editable: () => false
	},
	{
		"title": "Frequency Band",
		"field": "fBand",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "80px",
		template: function(dataItem) {
			if (dataItem.fBand == null || dataItem.fBand == 'null')
				return '';
			else
				return dataItem.fBand;
		},
		editable: () => false
	},
	{
		"title": "BW",
		"field": "bw",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "80px",
		template: function(dataItem) {
			if (dataItem.bw == null || dataItem.bw == 'null')
				return '';
			else
				return dataItem.bw;
		},
		editable: () => false
	},
	{
		"title":builtInFlag	? "eNB Built in USM/NSP/ENM": "Built In Switch",
		"field": "builtInSwitch",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "80px",
		template: function(dataItem) {
			if (dataItem.builtInSwitch == null || dataItem.builtInSwitch == 'null')
				return '';
			else
				return dataItem.builtInSwitch;
		},
		editable: () => false
	},
	{
		"title": "Valid eNB Length",
		"field": "validENBLength",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "90px",
		template: function(dataItem) {
			if (dataItem.validENBLength == null || dataItem.validENBLength == 'null')
				return '';
			else
				return dataItem.validENBLength;
		},
		editable: () => false
	},
	{
		"title": "Valid Numeric eNB",
		"field": "validENBNumber",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "60px",
		template: function(dataItem) {
			if (dataItem.validENBNumber == null || dataItem.validENBNumber == 'null')
				return '';
			else
				return dataItem.validENBNumber;
		},
		editable: () => false
	},
	{
		"title": "Valid Sector Length",
		"field": "validEnbSectorLength",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",
		template: function(dataItem) {
			if (dataItem.validEnbSectorLength == null || dataItem.validEnbSectorLength == 'null')
				return '';
			else
				return dataItem.validEnbSectorLength;
		},
		editable: () => false
	},
	{
		"title": "Valid Numeric Sector",
		"field": "validEnbSectorNumber",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",
		template: function(dataItem) {
			if (dataItem.validEnbSectorNumber == null || dataItem.validEnbSectorNumber == 'null')
				return '';
			else
				return dataItem.validEnbSectorNumber;
		},
		editable: () => false
	},
	{
		"title": "County",
		"field": "county",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",
		template: function(dataItem) {
			if (dataItem.county == null || dataItem.county == 'null')
				return '';
			else
				return dataItem.county;
		},
		editable: () => false
	},
	{
		"title": "Site Info ID",
		"field": "siteInfoId",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",
		template: function(dataItem) {
			if (dataItem.siteInfoId == null || dataItem.siteInfoId == 'null')
				return '';
			else
				return dataItem.siteInfoId;
		},
		editable: () => false
	},
	{
		"title": "Site Name",
		"field": "siteName",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",
		template: function(dataItem) {
			if (dataItem.siteName == null || dataItem.siteName == 'null')
				return '';
			else
				return dataItem.siteName;
		},
		editable: () => false
	},

];
var marketsData ;
var configurationColumns = [
	{ name: 'marketName', type: 'text', title: geolabelDetail(), width: 130, readOnly: true },
	{ name: 'vendor', type: 'text', title: 'Vendor', width: 130, readOnly: true },
	{ name: 'cellCapacity', type: 'number', title: 'Capacity (Cells)', width: 130, readOnly: false },
	{ name: 'vcuThreshold', type: 'number', title: 'VCU Threshold %', width: 130, readOnly: false },
	{ name: 'marketNumber', type: 'hidden', title: '', width: 100, readOnly: false },
	{ name: 'id', type: 'hidden', title: '', width: 100, readOnly: false },

];

	var dynamicAssignmentcolumns = [
{ name: 'transmitter', type: 'text', title: 'Transmitter', width: 130, readOnly: true },
{ name: 'site', type: 'text', title: 'Site', width: 90, readOnly: true },
{ name: 'siteVersion', type: 'text', title: 'Site Version', width: 130, readOnly: true },
{ name: 'frequencyBand', type: 'text', title: 'Frequency Band', width: 100, readOnly: true },
{ name: 'gNBeNBVendor', type: 'text', title: 'gNB/eNB Vendor', width: 100, readOnly: true },
{ name: 'rat', type: 'text', title: 'RAT', width: 80, readOnly: true },
{ name: 'neMode', type:'dropdown', title: 'NE Mode', width: 110, source: ["","5GDU", "4G5G"] },
{ name: 'neName', type:'text', title: 'NE Name', width: 90, readOnly: true },
{ name: 'fiveGSector', type: 'number', title: '5G Sector', width: 110, readOnly: false },
{ name: 'ltesector', type: 'number', title: 'LTE Sector', width: 110, readOnly: false, mask: '00' },
{ name: 'gNBId', type: 'number', title: 'gNB ID', width: 90, readOnly: false },
{ name: 'gNBFriendlyName', type: 'text', title: 'gNB Friendly Name', width: 120, readOnly: false },
{ name: 'gNBMixedModeLabel', type: 'dropdown', title: 'gNB Mixed Model Label', width: 150, source: ["Skip", "4G5G", "5GNB"] },
{ name: 'gNBName', type: 'text', title: 'gNB Name', width: 110, readOnly: true },
{ name: 'gNBDUNumber', type: 'number', title: 'gNB DU Number', width: 90, readOnly: false },
{ name: 'gNBDUFriendlyname', type: 'text', title: 'gNB DU Friendly Name', width: 140, readOnly: false },
{ name: 'gNBDUId', type: 'text', title: 'gNB DU ID', width: 70, readOnly: true },
{ name: 'gNBDUName', type: 'text', title: 'gNB DU Name', width: 90, readOnly: true },
{ name: 'eNBID', type: 'number', title: 'eNB ID', width: 100, readOnly: false },
{ name: 'eNBFriendlyName', type: 'text', title: 'eNB Friendly Name', width: 120, readOnly: false },
{ name: 'eNBName', type: 'text', title: 'eNB Name', width: 110, readOnly: true },
{ name: 'modifiedTS', type: 'hidden', title: '', width: 100, readOnly: false },
{ name: 'dbRecordId', type: 'hidden', title: '', width: 100, readOnly: false },
{ name: 'isModified', type: 'hidden', title: '', width: 100, readOnly: false },
{ name: 'transDbRecordId', type: 'hidden', title: '', width: 100, readOnly: false },
{ name: 'cranHubName', type: 'hidden', title: '', width: 100, readOnly: false }

];
if(Object.keys(featureToggleMap).includes("F10375") && featureToggleMap['F10375']) {
	dynamicAssignmentcolumns = dynamicAssignmentcolumns.map(obj => {
		if(obj.name === 'gNBMixedModeLabel'){
			return {...obj, source: [...obj.source, "CGNB"]}
		}
		return obj;
    });
}
var routerParams = {};

function fetchFRMappingAutomatically() {
	var rawDigit = $('#firstDuDigitLb').val();
	var digitStr = Array.isArray(rawDigit) ? rawDigit[0] : rawDigit;
	if (digitStr === 'None Selected' || !digitStr) {
		digitStr = '';
	}

	var rawVendor = $('#duExpansionVendor').val();
	var vendorStr = Array.isArray(rawVendor) ? rawVendor[0] : rawVendor;
	if (vendorStr === 'None Selected' || !vendorStr) {
		vendorStr = '';
	}

	// Keep add flow unchanged: no auto-fetch and FR remains user-editable dropdown.
	if (duExpansionAction !== 'delete') {
		$('#fr1Fr2Du').show();
		$('#fr1Fr2DuDisplayText').hide();
		$('#fr1Fr2Du').attr('disabled', false);
		return;
	}

	// In delete flow, FR mapping is enabled only after vendor + first DU digit are selected.
	if (!vendorStr || !digitStr) {
		$('#fr1Fr2Du').val('');
		$('#fr1Fr2DuDisplayText').text('');
		$('#fr1Fr2Du').show();
		$('#fr1Fr2DuDisplayText').hide();
		$('#fr1Fr2Du').attr('disabled', true);
		return;
	}

	$('#loading').show();
	$.ajax({
		url: getFRByVendorAndFirstDuDigitURL + '?vendor=' + encodeURIComponent(vendorStr) + '&firstDuDigit=' + encodeURIComponent(digitStr),
		type: 'GET',
		dataType: 'json',
		contentType: 'application/json; charset=UTF-8',
		success: function(response) {
			$('#loading').hide();

			var resObj = response;
			if (typeof response === 'string') {
				try { resObj = JSON.parse(response); } catch (e) {}
			}
			if (Array.isArray(resObj)) {
				resObj = resObj[0];
			}

			var fetchedMapping = resObj ? (resObj.FR_MAPPING || resObj.fr_mapping || resObj.FR_Mapping) : null;
			if (fetchedMapping) {
				fetchedMapping = fetchedMapping.toString().trim().toUpperCase();
				// In delete mode: show value as text, hide dropdown
				$('#fr1Fr2DuDisplayText').text(fetchedMapping);
				$('#fr1Fr2Du').hide();
				$('#fr1Fr2DuDisplayText').show();
			} else {
				$('#fr1Fr2Du').val('');
				$('#fr1Fr2DuDisplayText').text('');
				$('#fr1Fr2Du').show();
				$('#fr1Fr2DuDisplayText').hide();
			}
		},
		error: function() {
			$('#loading').hide();
			$('#fr1Fr2Du').val('');
			$('#fr1Fr2DuDisplayText').text('');
			$('#fr1Fr2Du').show();
			$('#fr1Fr2DuDisplayText').hide();
		}
	});
}

function bindFirstDuDigitAutoFetchHandler() {
	$('#firstDuDigitLb').off('change.duExpansionAutoFetch').on('change.duExpansionAutoFetch', function() {
		fetchFRMappingAutomatically();
	});
}


$(document).ready(function() {

	$("#deleteMDConfirmationCancel").click(function(){
        $("#deletMdConfirmationModal").modal("hide");
    });

	$("#deleteDuDigitConfirmationCancel").click(function(){
		$("#deletDuDigitConfirmationModal").modal("hide");
	});

	$('#fr1Fr2').change(function() {
		if($('#fr1Fr2').val() != "") {
			selectedFRMappingVal = $('#fr1Fr2').val();
		} else {
			selectedFRMappingVal = "";
		}
	});

	$('#fr1Fr2Du').change(function() {
		if($('#fr1Fr2Du').val() != "") {
			selectedFRMappingValDu = $('#fr1Fr2Du').val();
		} else {
			selectedFRMappingValDu = "";
		}
	});

	$("#submitbtn").click(function() {
		if(physicalExpAction == "" || physicalExpAction == undefined) {
			aptAlert("Warning","Select Action to proceed !");
			return;
		}

		if ($("#useCaseTextBox").val()) {
			useCaseValue = $("#useCaseTextBox").val();
		}

		if(physicalExpAction == "delete") {
			if(selectedPhysicalgNBEVendor == "" || selectedPhysicalgNBEVendor == undefined ||selectedPhysicalgNBEMiddleDigit == "" || selectedPhysicalgNBEMiddleDigit == undefined) {
				aptAlert("Warning", "Select all mandatory fields !");
				return;
			}
			actionUrl = deleteMiddleDigitsURL;
			reqBodyParam = JSON.stringify({vendor: selectedPhysicalgNBEVendor, action: "", middleDigit: selectedPhysicalgNBEMiddleDigit, useCase:useCaseValue});
			$("#deletMdConfirmationModal").modal("show");

		} else {
			if(selectedPhysicalgNBEVendor == "" || selectedPhysicalgNBEVendor == undefined ||selectedPhysicalgNBEMiddleDigit == "" || selectedPhysicalgNBEMiddleDigit == undefined || selectedFRMappingVal == "" || selectedFRMappingVal == undefined) {
				aptAlert("Warning", "Select all mandatory fields !");
				return;
			}
			actionUrl = addMiddleDigitsURL;
			reqBodyParam = JSON.stringify({vendor: selectedPhysicalgNBEVendor, targetCarrier: selectedFRMappingVal, useCase:useCaseValue,middleDigit:selectedPhysicalgNBEMiddleDigit});
			$('#loading').show();
			$.ajax({
				url: actionUrl,
				data: reqBodyParam,
				type: "POST",
				contentType: 'application/json; charset=UTF-8',
				async: false,
				cache: false,
				success: function(data) {
					$('#loading').hide();
					console.log(data);
					if(data.status == "success") {
						aptAlert('success', data.message);
					}
				},
				error: function(data) {
					$('#loading').hide();
					if(data.status == "error") {
						aptAlert('error', data.message);
					} else {
						aptAlert('error', 'Failed to add Middle Digit!');
					}
				}
			});
		}
		console.log(reqBodyParam);
		console.log(actionUrl);
	});

	$('#physicalgNBEVendor').change(function() {
		selectedPhysicalgNBEVendor = '';
		selectedPhysicalgNBEMiddleDigit = '';
		selectedPhysicalgNBEVendor = $('#physicalgNBEVendor').val();
		if (selectedPhysicalgNBEVendor == 'None Selected') {
			selectedPhysicalgNBEVendor = '';
		}
		if (selectedPhysicalgNBEVendor != 'None Selected') {
			getMiddleDigitByVendor(selectedPhysicalgNBEVendor);
		}

		$("#useCaseTextBox").val("");
		useCaseValue = "";
		$('#fr1Fr2').val("");
		selectedFRMappingVal = "";
	});

	$('#middleDigitLb').change(function() {
		selectedPhysicalgNBEMiddleDigit = '';
		selectedPhysicalgNBEMiddleDigit = $('#middleDigitLb').val();
		if (selectedPhysicalgNBEMiddleDigit == 'None Selected') {
			selectedPhysicalgNBEMiddleDigit = '';
		}
	});

	/* DU Expansion vendor -> populate First DU Digit select */
	$('#duExpansionVendor').change(function() {
		selectedDuExpansionVendor = '';
		selectedFirstDuDigit = '';
		selectedDuExpansionVendor = $('#duExpansionVendor').val();
		if (!selectedDuExpansionVendor || (Array.isArray(selectedDuExpansionVendor) && selectedDuExpansionVendor.length === 0) || selectedDuExpansionVendor == 'None Selected') {
			selectedDuExpansionVendor = '';
			resetFirstDuDigitDropdown();
		}
		if (selectedDuExpansionVendor) {
			getFirstDuDigitByVendor(selectedDuExpansionVendor);
		}

		$("#useCaseTextBoxDu").val("");
		useCaseValue = "";
		$('#fr1Fr2Du').val("");
		selectedFRMappingValDu = "";
		fetchFRMappingAutomatically();
	});


	/* DU Expansion submit handler */
    /* DU Expansion submit handler */
/* DU Expansion submit handler */
	$('#duSubmitbtn').click(function() {
		if(duExpansionAction == "" || duExpansionAction == undefined) {
			aptAlert("Warning","Select Action to proceed !");
			return;
		}

		var useCaseValue = $("#useCaseTextBoxDu").val() || "";

		var rawVendor = $('#duExpansionVendor').val();
		var vendorSubmitStr = Array.isArray(rawVendor) ? rawVendor[0] : rawVendor;

		var rawDigit = $('#firstDuDigitLb').val();
		var digitSubmitStr = Array.isArray(rawDigit) ? rawDigit[0] : rawDigit;

		// In delete mode, FR mapping is displayed as text; in add mode, it's a dropdown
		var mappingSubmitStr = '';
		if (duExpansionAction === 'delete') {
			// Get value from display text (since dropdown is hidden in delete mode)
			mappingSubmitStr = $('#fr1Fr2DuDisplayText').text().trim();
		} else {
			// Get value from dropdown (since it's visible in add mode)
			mappingSubmitStr = $('#fr1Fr2Du').val();
		}

		// FAILSAFE: If the multiselect plugin blocked the change event, fetch the mapping right now!
		if (duExpansionAction === 'delete' && vendorSubmitStr && digitSubmitStr && (!mappingSubmitStr || mappingSubmitStr === '')) {
			$('#loading').show();
			$.ajax({
				url: getFRByVendorAndFirstDuDigitURL + '?vendor=' + encodeURIComponent(vendorSubmitStr) + '&firstDuDigit=' + encodeURIComponent(digitSubmitStr),
				type: "GET",
				dataType: 'json',
				async: false, // Critical: Forces the browser to wait for the API before continuing
				success: function(response) {
					var resObj = response;
					if (typeof response === 'string') {
						try { resObj = JSON.parse(response); } catch(e) {}
					}
					if (Array.isArray(resObj)) resObj = resObj[0];

					var fetchedMapping = resObj ? (resObj.FR_MAPPING || resObj.fr_mapping || resObj.FR_Mapping) : null;

					if (fetchedMapping) {
						mappingSubmitStr = fetchedMapping.toString().trim().toUpperCase();
						$('#fr1Fr2DuDisplayText').text(mappingSubmitStr);
					}
					$('#loading').hide();
				},
				error: function() {
					$('#loading').hide();
				}
			});
		}

		// Proceed with the actual submission logic
		if(duExpansionAction == "delete") {
			if(!vendorSubmitStr || !digitSubmitStr || !mappingSubmitStr) {
				aptAlert("Warning", "Select all mandatory fields (Vendor, First DU Digit, FR Mapping) !");
				return;
			}
			reqBodyParam = JSON.stringify({
				vendor: vendorSubmitStr,
				targetCarrier: mappingSubmitStr,
				useCase: useCaseValue,
				firstDuDigit: parseInt(digitSubmitStr)
			});
			$("#deletDuDigitConfirmationModal").modal("show");

		} else {
			if(!vendorSubmitStr || !digitSubmitStr || !mappingSubmitStr) {
				aptAlert("Warning", "Select all mandatory fields (Vendor, First DU Digit, FR Mapping) !");
				return;
			}
			reqBodyParam = JSON.stringify({
				vendor: vendorSubmitStr,
				targetCarrier: mappingSubmitStr,
				useCase: useCaseValue,
				firstDuDigit: parseInt(digitSubmitStr)
			});

			$('#loading').show();
			$.ajax({
				url: addFirstDuDigitsURL,
				data: reqBodyParam,
				type: "POST",
				contentType: 'application/json; charset=UTF-8',
				async: false,
				cache: false,
				success: function(data) {
					$('#loading').hide();
					if(data.status == "success") {
						aptAlert('success', data.message);
					} else if(data.status == "error") {
						aptAlert('error', data.message);
					}
				},
				error: function(data) {
					$('#loading').hide();
					if(data.responseJSON && data.responseJSON.message) {
						aptAlert('error', data.responseJSON.message);
					} else {
						aptAlert('error', 'Failed to submit DU Expansion!');
					}
				}
			});
		}
	});

	try {
		var env = window.location.href.includes('canvasple') ? '-PLE' : '';
		window.initClickstream({
			"system_name": "Network Planning Platform",
			"app_name": "ATOLL" + env,
			"screen_name": "gNB/eNB Planning Tool",

			"showLogs": "true"
		});
	} catch (e) {
		return false;
	}

	if (Object.keys(featureToggleMap).includes("F90711") && featureToggleMap['F90711']) {
		$('#isNotCommonSchemaSearch').hide();
		$('#commonSchemaSearch').show();
		commonSchemaSearch('commonGnbSchemaSearch');
	} else {
		$('#isNotCommonSchemaSearch').show();
		$('#commonSchemaSearch').hide();
	}
	tabIndexEnbAtollUpdate==2
	// featureToggleMap.F76857 = false;
	kendoGridFirstTimeLoad = true;
	tabIndexGnbAtollUpdate = 1;
	siteVersions = $('#siteVersionDropdownId').val();
	document.getElementById("updateBtn").disabled = true;
	if((Object.keys(featureToggleMap).includes("F87042") && featureToggleMap['F87042']) && val){
		jQuery("label[for='atollMarketDb']").find('b').text(val['GEO4']);
		jQuery("#geoLabelMarket").text(jQuery("#geoLabelMarket").text().replace('Market',val['GEO4']));
		jQuery('#vzMarket').parent('div').find('label').text(jQuery("#vzMarket").parent('div').find('label').text().replace('Market',val['GEO4']));
		jQuery('#phMarket').parent('div').find('label').text(jQuery("#phMarket").parent('div').find('label').text().replace('Market',val['GEO4']));
		jQuery('#fiveGvzMarket').parent('div').find('label').text(jQuery("#fiveGvzMarket").parent('div').find('label').text().replace('Market',val['GEO4']));
		jQuery('#fiveGphMarket').parent('div').find('label').text(jQuery("#fiveGphMarket").parent('div').find('label').text().replace('Market',val['GEO4']));
		jQuery("#marketLTEGeoValue").text(jQuery("#marketLTEGeoValue").text().replace('Market',val['GEO4']));
	}

	$.each(typeDropdownList, function(i, v) {
		$('#typeDropdown').append("<option>" + v + "</option>");
	});
	$('#typeDropdown').val('', '');
	$('#typeDropdown').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
		nonSelectedText: 'None selected'

	});

	$('#eNodebDropdownSection').hide();
	$('#eNodebValidityFlagSection').hide();
	$('#gNodebDropdownSection').show();

	if (gNodeBAssignment) {
		$('#assignmentGrid').show();
	}

	clearAssignmentDropdowns('#areaDropdown');
	clearAssignmentDropdowns('#regionDropdown');
	clearAssignmentDropdowns('#marketDropdown');
	clearAssignmentDropdowns('#avendorDropdown');
	$('#validInvalidDropdown').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
	});
	$('#siteVersionDropdownId').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1
	});
	$('#atollUpdateRightSiteVersion').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1
	});
		fetchAOR(userID);
		$('#ConfigurationTab').show();
		assignmentGridColumns[8].hidden = false;
		assignmentGridColumns[9].hidden = false;
		//assignmentEmptyTable();
		assignmentEmptyTable("#assignmentGrid", assignmentDataSource, assignmentGridColumns);

	$("#atollUpdate").hide();
	$("#showAllValidationDb").hide();
	$("#eNodeBinfo").hide();
	$("#marketLTETabs").hide();
	$("#physicalTabView").hide();

	$("#eNodeBDrillView").hide();
	$("#sectorResults").hide();
	$("#marketTabs").hide();
	$("#configurationViewGrid").hide();
	$("#refreshSaveBtn").hide();
	$("#configurationGridToolBar").hide();
	$('#reserveMarketRange').hide();
	//roles.push("BETA_USER");
	console.log('featureToggleMap', featureToggleMap);
	$("#showAtoll").show();
		$("#siteVersionId").show();

	//reloadData();
	$.widget("custom.catautocomplete", $.ui.autocomplete, {
		_create: function() {
			this._super();
			this.widget().menu("option", "items", "> :not(.ui-autocomplete-category)");
		},
		_renderMenu: function(ul, items) {
			var self = this;
			var current = "";
			$.each(items, function(index, item) {
				if (item.category != current) {
					ul.append("<li class='ui-autocomplete-category'>" + item.category + "</li>");
					current = item.category;
				}
				self._renderItemData(ul, item);
			});
		},
	});

	buildCatauto($('#siteName'));

	$('#siteVersionDb').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		numberDisplayed: 1,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',

	});
	$('#atollMarketDb').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		numberDisplayed: 1,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',

	});
	$("#atollMarketDb").multiselect("disable");

	$("#atollSearchCriteria").show();
	creatingJSpreadsheeteAsiignment(dynamicAssignmentcolumns, spreadsheetAssignmet);
	creatingJSpreadsheeteConfiguration(configurationColumns, spreadsheetConfiguration);
	$("#MarketDbSh").show();

	getUserSchema();
	$("#showHideFr1Fr2Db").show();

		$("#atollUpdateTab").show();
// $("#atollUpdateTab").show();

	$("#fr1Fr2Db").multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		numberDisplayed: 1,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		nonSelectedText: 'None selected'
	});

	$('#typeDropdown').val('', '');
	$("#typeDropdown").multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		numberDisplayed: 1,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		nonSelectedText: 'None selected'
	});

	$("#fr1Fr2Db").multiselect("disable");
	if(!marketInAorAvailable){
		$("#siteVersionDropdownId").multiselect("disable");
		}
	$('#marketTabs').hide();
	$('#enodeAssignmentGrid').hide();
	$('#eNodeBDrillView').hide();
	$("#configurationViewGrid").hide();
	$("#refreshSaveBtn").hide();
	$('#typeDb').hide();
	$('#assignmentGridToolbar').show();
	$("#validationGridToolbar").hide();
	$("#enodeValidationToolbar").hide();
	getUserRolesData();
	if (Object.keys(featureToggleMap).includes("F9488") && featureToggleMap['F9488']) {
		getPhysicaleExpVendorList();
		getDuExpVendorList();
	}
	if (Object.keys(featureToggleMap).includes("F90711") && featureToggleMap['F90711']) {
		if (window.location.href.includes("?")) {
			(localStorage.getItem('atollSchema')) ? routerParams.atollSchema = localStorage.getItem('atollSchema') : '';
			console.log("atollSchemaLocal", routerParams.atollSchema);
			console.log(window.location.href);
			let url = window.location.href;
			let splitUrl = url.split("?");
			let params = (splitUrl[1]) ? splitUrl[1].split('&') : [];
			console.log(params);
			params.forEach(element => {
				if (element) {
					var obj = {};
					var a = element.split("=");
					if (a.length > 0) {
						obj[a[0]] = a[1];
						routerParams = { ...obj, ...routerParams };
					}
				}
			});
			if (routerParams) {
				isParamPresentInUrl = true;
			}
			routerParams["siteVersion"] = (routerParams.siteVersion) ? routerParams.siteVersion.split(",") : [];
			console.log(routerParams);
			if (routerParams.projectNumber) {
                getDataUsingProjectNumber(routerParams.projectNumber);
				updateSiteVersionDropdown(routerParams.projectNumber, 'commonGnbSchemaSearch');
				routerParams.siteVersion = $('#' + 'commonGnbSchemaSearch' + 'VersionList').val();
				if (routerParams.siteVersion != null) {
					routerParams.siteVersion = [routerParams.siteVersion[0].split(" ")[0]];
					atollSchemaCommonSearch('commonGnbSchemaSearch', routerParams.atollSchema, routerParams.fuzeSiteId, routerParams.siteVersion, 'gNodeBinfo');
				}
            } else if (routerParams.siteRecordId) {
                getDataUsingSiteRecordId(routerParams.siteRecordId);
            } else {
                setTimeout(() => {
                    atollSchemaCommonSearch('commonGnbSchemaSearch', routerParams.atollSchema, routerParams.fuzeSiteId, routerParams.siteVersion, 'gNodeBinfo');
                }, 200);
            }
		}
	}
});

function getphysicalExpActionVal(action) {
	preResetPEPopup();
	if(action != '') {
		physicalExpAction = action;
	}

	if(physicalExpAction == "delete") {
		$('#fr1Fr2').attr('disabled', true);
		$('#fr1Fr2DbVisible').hide();
	} else {
		$('#fr1Fr2').attr('disabled', false);
		$('#fr1Fr2DbVisible').show();
	}
}

function getDuExpansionActionVal(action) {
	if(action != '') {
		duExpansionAction = action;
	}
	// Reset DU fields when action changes
	selectedDuExpansionVendor = '';
	selectedFirstDuDigit = '';
	selectedFRMappingValDu = '';
    	$('#duExpansionVendor').multiselect('destroy');
    	$('#duExpansionVendor').html('');

    	$.each(duExpansionVendorList, function(i, v) {
    		$('#duExpansionVendor').append($('<option></option>').val(v).text(v));
    	});

	$('#duExpansionVendor').val('', '');
	$('#duExpansionVendor').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
		nonSelectedText: 'None selected'
	});
	resetFirstDuDigitDropdown();
	$("#useCaseTextBoxDu").val("");
	useCaseValue = "";
	$('#fr1Fr2Du').val("");
	$('#fr1Fr2DuDisplayText').text('');
    selectedFRMappingValDu = "";

	fetchFRMappingAutomatically();
	$('#fr1Fr2DbVisibleDu').show();
}

function getPhysicaleExpVendorList() {
	console.log('ff');
	console.log(getPhysicalVendorListUrl);
	$.ajax({
		async: false,
		url: getPhysicalVendorListUrl,
		dataType: 'json',
		type: "GET",
		contentType: 'application/json; charset=UTF-8',
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function(data) {
			physicalgNBEVendorList = data;
		},
		error: function(data) {
			aptAlert('Warning', 'Failed to load physicalgNBEVendorList data!');
			physicalgNBEVendorList =  [
			"SpiderCloud",
			"Corning",
			"Alcatel-Lucent",
			"Ericsson",
			"Samsung",
			"Nokia",
			"Test",
			"test"
			];
		}
	});

	$('#physicalgNBEVendor').html('');
	$('#physicalgNBEVendor').multiselect('destroy');

	$.each(physicalgNBEVendorList, function(i, v) {
		$('#physicalgNBEVendor').append("<option>" + v + "</option>");
	});
	$('#physicalgNBEVendor').val('', '');
	$('#physicalgNBEVendor').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
		nonSelectedText: 'None selected'
	});
	$('#middleDigitLb').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
		nonSelectedText: 'None selected'
	});

	$('#duExpansionVendor').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
		nonSelectedText: 'None selected'
	});

	resetFirstDuDigitDropdown();
}

function getDuExpVendorList() {
	$.ajax({
		async: false,
		url: getDuVendorListUrl,
		dataType: 'json',
		type: "GET",
		contentType: 'application/json; charset=UTF-8',
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function(data) {
			duExpansionVendorList = data;
		},
		error: function() {
			aptAlert('Warning', 'Failed to load DU vendor list data!');
			duExpansionVendorList = [
				"SpiderCloud",
				"Corning",
				"Alcatel-Lucent",
				"Ericsson",
				"Samsung",
				"Nokia"
			];
		}
	});
	// 1. Destroy the plugin BEFORE emptying the HTML so it cleans up the old invisible UI
        $('#duExpansionVendor').multiselect('destroy');
        $('#duExpansionVendor').html('');

        // 2. Safely append the options using .text() to prevent <None> from breaking the UI
        $.each(duExpansionVendorList, function(i, v) {
           $('#duExpansionVendor').append($('<option></option>').val(v).text(v));
        });

//	$('#duExpansionVendor').html('');
//	$('#duExpansionVendor').multiselect('destroy');
//
//	$.each(duExpansionVendorList, function(i, v) {
//		$('#duExpansionVendor').append("<option>" + v + "</option>");
//	});
	$('#duExpansionVendor').val('', '');
	$('#duExpansionVendor').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
		nonSelectedText: 'None selected'
	});
}

function getMiddleDigitByVendor(selectedVendor) {
    $.ajax({
        url: getMiddleDigitByVendorURL,
        data: JSON.stringify({vendor: selectedVendor, action: physicalExpAction}),
        type: "POST",
		contentType: 'application/json; charset=UTF-8',
        async: false,
		cache: false,
        success: function(response) {
			console.log(response);
			if(response.mdList.length > 0) {
				physicalgNBEMiddleList = response.mdList;
			} else {
				aptAlert('error', 'No Middle Digits are available for assignment, Please try different vendor!');
			}
        },
        error: function(response) {
            aptAlert('Warning', 'Failed to load Middle Digit!');
        }
    });

	$('#middleDigitLb').html('');
	$('#middleDigitLb').multiselect('destroy');

	$.each(physicalgNBEMiddleList, function(i, v) {
		$('#middleDigitLb').append("<option>" + v + "</option>");
	});
	$('#middleDigitLb').val('', '');
	$('#middleDigitLb').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
		nonSelectedText: 'None selected'
	});
}

function resetFirstDuDigitDropdown() {
	$('#firstDuDigitLb').html('');
	$('#firstDuDigitLb').multiselect('destroy');
	$('#firstDuDigitLb').val('', '');
    $('#firstDuDigitLb').multiselect({
   includeSelectAllOption: true,
   enableFiltering: true,
   enableCaseInsensitiveFiltering: true,
   buttonClass: 'btn btn-default whitebg btn-sm',
   numberDisplayed: 1,
   nonSelectedText: 'None selected',
   onChange: function(option, checked) {
      // This forces the API to fire the millisecond the user clicks a number!
      fetchFRMappingAutomatically();
   }
});
  bindFirstDuDigitAutoFetchHandler();
}

function getFirstDuDigitByVendor(selectedVendor) {
	var firstDuList = [];
	if (!selectedVendor || (Array.isArray(selectedVendor) && selectedVendor.length === 0)) {
		resetFirstDuDigitDropdown();
		return;
	}

	$.ajax({
		url: getFirstDuDigitByVendorURL,
		data: JSON.stringify({vendor: selectedVendor, action: duExpansionAction}),
		type: "POST",
		contentType: 'application/json; charset=UTF-8',
		async: false,
		cache: false,
		success: function(response) {
			console.log(response);
			if(response && response.fdList && response.fdList.length > 0) {
				firstDuList = response.fdList;
			} else if (response && response.length > 0) {
				// fallback if API returns array directly
				firstDuList = response;
			} else {
				aptAlert('error', 'No First DU Digits are available for assignment, Please try different vendor!');
			}
		},
		error: function(response) {
			aptAlert('Warning', 'Failed to load First DU Digit!');
		}
	});

	resetFirstDuDigitDropdown();

	$.each(firstDuList, function(i, v) {
		$('#firstDuDigitLb').append("<option>" + v + "</option>");
	});
	$('#firstDuDigitLb').multiselect('rebuild');
	bindFirstDuDigitAutoFetchHandler();
}

function deleteMDConfirm(){
    $("#deletMdConfirmationModal").modal("hide");
	$('#loading').show();
	console.log(reqBodyParam);
    $.ajax({
        url: deleteMiddleDigitsURL,
        data: reqBodyParam,
        type: "POST",
		contentType: 'application/json; charset=UTF-8',
        async: false,
		cache: false,
        success: function(data) {
			$('#loading').hide();
			console.log(data);
			if(data.status == "success") {
				aptAlert('success', data.message);
			}
        },
        error: function(data) {
			$('#loading').hide();
			if(data.status == "error") {
				aptAlert('error', data.message);
			} else {
				aptAlert('error', 'Failed to delete Middle Digit!');
			}
        }
    });
}

/* DU First Digit delete confirmation handler */
function deleteDuDigitConfirm() {
	$("#deletDuDigitConfirmationModal").modal("hide");
	$('#loading').show();
	console.log(reqBodyParam);
	$.ajax({
		url: deleteFirstDuDigitsURL,
		data: reqBodyParam,
		type: "POST",
		contentType: 'application/json; charset=UTF-8',
		async: false,
		cache: false,
		success: function(data) {
			$('#loading').hide();
			console.log(data);
			if(data.status == "success") {
				aptAlert('success', data.message);
			} else if(data.status == "error") {
				aptAlert('error', data.message);
			}
		},
		error: function(data) {
			$('#loading').hide();
			if(data.responseJSON && data.responseJSON.message) {
				aptAlert('error', data.responseJSON.message);
			} else {
				aptAlert('error', 'Failed to delete First DU Digit!');
			}
		}
	});
}

function getDataUsingSiteRecordId(siteRecordId) {
    $.ajax({
        //url: 'http://localhost:8100/npp-atoll-services/atollUtility/fetchSchemaAndFuzeSiteIdBySiteRecordId?siteRecordId=' + siteRecordId,
        url: fetchSchemaAndFuzeSiteIdBySiteRecordIdURL + siteRecordId,
        dataType: 'json',
        type: "POST",
        async: false,
        success: function(projectData) {
            console.log('roles Data ===>', projectData);
            routerParams.fuzeSiteId = projectData.VZ_SITE_INFO_ID;
            routerParams.atollSchema = projectData.ATOLL_SCHEMA;
            atollSchemaCommonSearch('commonGnbSchemaSearch', routerParams.atollSchema, routerParams.fuzeSiteId, routerParams.siteVersion, 'gNodeBinfo');
        },
        error: function(data) {
            aptAlert('Warning', 'Failed to load data!');
        }
    });
}
function getDataUsingProjectNumber(projectNumber) {
    $.ajax({
        //url: 'http://localhost:8100/npp-atoll-services/atollUtility/fetchSchemaAndFuzeSiteIdByProjectNumber?projectNumber=' + projectNumber,
        url: fetchSchemaAndFuzeSiteIdByProjectNumberURL + projectNumber,
        dataType: 'json',
        type: "POST",
        async: false,
        success: function(projectData) {
            console.log('roles Data ===>', projectData);
            routerParams.fuzeSiteId = projectData.data[0].fuzeSiteIdList[0];
            routerParams.atollSchema = projectData.data[0].schema;
            atollSchemaCommonSearch('commonGnbSchemaSearch', routerParams.atollSchema, routerParams.fuzeSiteId, routerParams.siteVersion, 'gNodeBinfo');
        },
        error: function(data) {
            aptAlert('Warning', 'Failed to load data!');
        }
    });
}

function getUserRolesData() {
	var userId = vzid;
	$.ajax({
		// url: 'https://uteidentitydit1.ebiz.verizon.com/user/uiroles/' + userId,
		url: getUserRoleURL + userId,
		dataType: 'json',
		type: "GET",
		async: false,
		success: function(data) {
			console.log('roles Data ===>', data);
			var roles = data;
				$('#ConfigurationTab').hide();
				$('#physicalgNBExpansionTab').hide();
				for (var i = 0; i < roles.length; i++) {
					if (roles[i].roleName === "PLANNING_RF_ENG3") {
						$('#ConfigurationTab').show();
					}
					if (Object.keys(featureToggleMap).includes("F9488") && featureToggleMap['F9488']) {
						if (roles[i].roleName === "NPP_STANDARDS") {
							$('#physicalgNBExpansionTab').show();
						}
					}
				}
		},
		error: function(data) {
			aptAlert('Warning', 'Failed to load UserRoles data!');
		}
	});
}




$("#siteSearchbtn").click(function() {
	marketsSelected = $('#marketDropdown').val();
	if ((gnbAssignTerritoryList == undefined) || (gnbAssignRegionList == undefined) || (gnbAssignRegionList == "") || (!gnbAssignRegionList) || (marketsSelected == '') || (!marketsSelected) || (gnbAssignAreaList == undefined) || ($('#siteVersionDropdownId').val() == '') || ($('#siteVersionDropdownId').val() == undefined)) {
		alert("Please Select All the Mandatory Dropdowns");
		$('#loading').hide();
	} else {
		if (indexOfTabs == 1 && ParentIndex == 1) {
			assignmentGnodebData();
		} else if (indexOfTabs == 2 && ParentIndex == 1) {
			validationGnodeData();
			$('#assignmentGrid').hide();
		} else if (indexOfTabs == 1 && ParentIndex == 2) {
			$('#assignmentGrid').hide();
			$('#validationViewGrid').hide();
			// getSectorCarrierAssignment();
			$('#assignmentGrid').hide();

				$('#marketTabs').show();
				$('#enbsectorexportToExcel').hide();
				$('#exportToExcelEnbAssignmentTab').show();
				getSectorCarrierAssignment();

		} else if (indexOfTabs == 2 && ParentIndex == 2) {
			validationEnodeData();
		} else if (ParentIndex == 4) {
			if ((typeValue == '') || (typeValue == undefined)) {
				alert("Please Select All the Mandatory Dropdowns");
				$('#loading').hide();
			} else {
				if(typeValue=="Assignment Capacity Change"){
					$('#reserveMarketRange').hide();
					$('#configurationGridToolBar').show();
					$('#configurationViewGrid').show();
					if (capacityFlagCheck || vcuFlagCheck) {
						$('#configurationTabChanges').show();
					} else {
						configurationDataFetch();
					}
				}else if(typeValue=="Reserve Market Range"){
					$('#configurationGridToolBar').hide();
					$('#configurationViewGrid').hide();
					$('#reserveMarketRange').show();
					getEnbReservedRanges();
					// reserveMarketRangeTable(responseR);
				}
			}
		}
		console.log(indexOfTabs);
	}
})

// $("#clearSearchBtn").click(function(){




// })


var configurationData = [];
var rowData;

function creatingJSpreadsheeteAsiignment(dynamicAssignmentcolumns, spreadsheetAssignmet, atollPushData) {

	if (spreadsheetAssignmet == 'virtualAssignmentGridInfo') {

		spreadsheetTransmitterObj = jspreadsheet(document.getElementById(spreadsheetAssignmet), {
			data: atollPushData,
			columns: dynamicAssignmentcolumns,

			tableOverflow: true,
			tableWidth: '100%',
			minSpareRows: 0,
			minDimensions: [0, 6],
			filters: true,
			allowInsertRow: false,
			allowInsertColumn: false,
			allowRenameColumn: false,
			allowDeleteColumn: false,
			allowDeleteRow: false,
			autoIncrement: false,
			onchange: function(instance, cell, c, r, value) {
				transmittergridinfoChange(instance, cell, c, r, value);
			},

			onload: function(instance) {

				if (atollPushDataCopy.length == 0) {
					row = document.getElementsByClassName('jexcel jexcel_overflow')[0].rows;
					rowData = document.getElementsByClassName('jexcel jexcel_overflow')[0];
					rowrecieved = document.getElementsByClassName('jexcel jexcel_overflow')[0].rows;
				} else {
					row = document.getElementsByTagName('tbody')[4].rows;
					rowData = document.getElementsByTagName('tbody')[4];
					rowrecieved = document.getElementsByTagName('tbody')[4].rows;
				}
				// row = document.getElementsByClassName('jexcel jexcel_overflow')[0].rows;
				// rowrecieved = document.getElementsByClassName('jexcel jexcel_overflow')[0].rows;
				console.log(rowrecieved);
				for (var i = 0; i < row.length; i++) {
					console.log(row[i].cells[6].innerHTML);

					// if (i > 0) {

					if (row[i].cells[6].innerHTML == "5G NR") {

						rowData.rows[i].cells[9].className = "highlightchange";
						rowData.rows[i].cells[10].className = "readonly";
						rowData.rows[i].cells[11].className = "highlightchange";
						rowData.rows[i].cells[12].className = "highlightchange";
						rowData.rows[i].cells[13].className = "highlightchange";
						rowData.rows[i].cells[15].className = "highlightchange";
						rowData.rows[i].cells[16].className = "highlightchange";
						rowData.rows[i].cells[19].className = "readonly";
						rowData.rows[i].cells[20].className = "readonly";
					}	else if (row[i].cells[6].innerHTML == "LTE" && row[i].cells[7].innerHTML == "") {


						rowData.rows[i].cells[9].className = "readonly";
						rowData.rows[i].cells[10].className = "highlightchange";
						rowData.rows[i].cells[12].className = "readonly";
						rowData.rows[i].cells[11].className = "readonly";
						rowData.rows[i].cells[13].className = "readonly";
						rowData.rows[i].cells[15].className = "readonly";
						rowData.rows[i].cells[16].className = "readonly";
						rowData.rows[i].cells[19].className = "highlightchange";
						rowData.rows[i].cells[20].className = "highlightchange";
					}else if (row[i].cells[6].innerHTML == "LTE" && row[i].cells[7].innerHTML == "5GDU") {


						rowData.rows[i].cells[9].className = "readonly";
						rowData.rows[i].cells[10].className = "highlightchange";
						rowData.rows[i].cells[12].className = "readonly";
						rowData.rows[i].cells[11].className = "readonly";
						rowData.rows[i].cells[13].className = "readonly";
						rowData.rows[i].cells[15].className = "readonly";
						rowData.rows[i].cells[16].className = "readonly";
						rowData.rows[i].cells[19].className = "highlightchange";
						rowData.rows[i].cells[20].className = "highlightchange";
					}	else if (row[i].cells[6].innerHTML == "LTE" && row[i].cells[7].innerHTML == "4G5G") {


						rowData.rows[i].cells[9].className = "readonly";
						rowData.rows[i].cells[10].className = "highlightchange";
						rowData.rows[i].cells[12].className = "highlightchange";
						rowData.rows[i].cells[11].className = "highlightchange";
						rowData.rows[i].cells[13].className = "readonly";
						rowData.rows[i].cells[15].className = "highlightchange";
						rowData.rows[i].cells[16].className = "highlightchange";
						rowData.rows[i].cells[19].className = "highlightchange";
						rowData.rows[i].cells[20].className = "highlightchange";
					}	 else if (row[i].cells[6].innerHTML == "5G NR;LTE") {

						rowData.rows[i].cells[9].className = "highlightchange";
						rowData.rows[i].cells[10].className = "highlightchange";
						rowData.rows[i].cells[11].className = "highlightchange";
						rowData.rows[i].cells[12].className = "highlightchange";
						rowData.rows[i].cells[13].className = "highlightchange";
						rowData.rows[i].cells[15].className = "highlightchange";
						rowData.rows[i].cells[16].className = "highlightchange";
						rowData.rows[i].cells[19].className = "highlightchange";
						rowData.rows[i].cells[20].className = "highlightchange";
					} else if (row[i].cells[6].innerHTML == "NO RAT") {
						rowData.rows[i].cells[7].className = "readonly";
						rowData.rows[i].cells[9].className = "readonly";
						rowData.rows[i].cells[10].className = "readonly";
						rowData.rows[i].cells[11].className = "readonly";
						rowData.rows[i].cells[12].className = "readonly";
						rowData.rows[i].cells[13].className = "readonly";
						rowData.rows[i].cells[15].className = "readonly";
						rowData.rows[i].cells[16].className = "readonly";
						rowData.rows[i].cells[19].className = "readonly";
						rowData.rows[i].cells[20].className = "readonly";
					} else {
						rowData.rows[i].cells[7].className = "readonly";
						rowData.rows[i].cells[9].className = "readonly";
						rowData.rows[i].cells[10].className = "readonly";
						rowData.rows[i].cells[11].className = "readonly";
						rowData.rows[i].cells[12].className = "readonly";
						rowData.rows[i].cells[13].className = "readonly";
						rowData.rows[i].cells[15].className = "readonly";
						rowData.rows[i].cells[16].className = "readonly";
						rowData.rows[i].cells[19].className = "readonly";
						rowData.rows[i].cells[20].className = "readonly";
					}

					// }


					for (var j = 0; j < row[i].cells.length; j++) {
						if (j == 7) {

							row[i].cells[j].id = i + '_r_' + j;

							dataarrayNeMode.push(rowrecieved[i].cells[7].innerHTML);



						}
						else if (j == 9) {

							row[i].cells[j].id = i + '_r_' + j;

							dataarray.push(rowrecieved[i].cells[9].innerHTML);
							// row[i].cells[j].addEventListener('keyup', function (event) {

							// 	// document.getElementById(event.currentTarget.id).innerHTML = document.getElementById(event.currentTarget.id).innerHTML.slice(0,4);
							// 	var test = document.getElementById(event.currentTarget.id);
							// 	var test2 = test.getElementsByTagName('input');
							// 	test2[0].value = test2[0].value.slice(0, 4);
							// 	console.log(document.getElementById(event.currentTarget.id).innerHTML);

							// })

							row[i].cells[j].addEventListener('keypress', function(event) {
								var code = (event.which) ? event.which : event.keyCode;
								var test = document.getElementById(event.currentTarget.id);
								var test2 = test.getElementsByTagName('input');

								if (code > 31 && (code < 48 || code > 57) || test2[0].value.length > 3) {
									event.preventDefault();
								}

							})


						} else if (j == 10) {
							dataarraylteSector.push(rowrecieved[i].cells[10].innerHTML);
						}
						else if (j == 11) {
							dataarrayGnbId.push(rowrecieved[i].cells[11].innerHTML);
							row[i].cells[j].id = i + '_r11_' + j;
							row[i].cells[j].addEventListener('keypress', function(event) {
								var code = (event.which) ? event.which : event.keyCode;
								var test = document.getElementById(event.currentTarget.id);
								var test2 = test.getElementsByTagName('input');

								if (code > 31 && (code < 48 || code > 57) || test2[0].value.length > 6) {
									event.preventDefault();
								}

							})

						}
						else if (j == 12) {

							row[i].cells[j].id = i + '_r12_' + j;

							dataarrayGnbFriendlyname.push(rowrecieved[i].cells[12].innerHTML);
							row[i].cells[j].addEventListener('keypress', function(event) {

								var test = document.getElementById(event.currentTarget.id);
								var test2 = test.getElementsByTagName('input');

								row[i].cells[j].addEventListener('paste', function(event) {
									event.preventDefault();
								});

							})

						} else if (j == 13) {
							dataarrayGnbMixmodellable.push(rowrecieved[i].cells[13].innerHTML);
						} else if (j == 15) {
							row[i].cells[j].id = i + '_r15_' + j;
							dataarrayGnbDuNumber.push(rowrecieved[i].cells[15].innerHTML);
							row[i].cells[j].addEventListener('keypress', function(event) {
								var code = (event.which) ? event.which : event.keyCode;
								var test = document.getElementById(event.currentTarget.id);
								var test2 = test.getElementsByTagName('input');

								if (code > 31 && (code < 48 || code > 57) || test2[0].value.length > 3) {
									event.preventDefault();
								}

							})

						} else if (j == 16) {

							row[i].cells[j].id = i + '_r16_' + j;

							dataarrayGnbDufriendlyname.push(rowrecieved[i].cells[16].innerHTML);
							row[i].cells[j].addEventListener('keypress', function(event) {

								var test = document.getElementById(event.currentTarget.id);
								var test2 = test.getElementsByTagName('input');

								if (test2[0].value.length > 69) {
									event.preventDefault();
								}

							})

						} else if (j == 19) {

							row[i].cells[j].id = i + '_r19_' + j;

							dataarrayEnbId.push(rowrecieved[i].cells[19].innerHTML);
							row[i].cells[j].addEventListener('keypress', function(event) {
								var code = (event.which) ? event.which : event.keyCode;
								var test = document.getElementById(event.currentTarget.id);
								var test2 = test.getElementsByTagName('input');

								if (code > 31 && (code < 48 || code > 57) || test2[0].value.length > 5) {
									event.preventDefault();
								}

							})

						} else if (j == 20) {

							row[i].cells[j].id = i + '_r20_' + j;
							rowrecieved[i].cells[20] ? dataarrayEnbFriendlyname.push(rowrecieved[i].cells[20].innerHTML) : '';
							row[i].cells[j].addEventListener('keypress', function(event) {

								var test = document.getElementById(event.currentTarget.id);
								var test2 = test.getElementsByTagName('input');

								if (test2[0].value.length > 69) {
									event.preventDefault();
								}

							})
						}


					}
				}
				tempdataArrayFirstcopy = dataarray;

			},



		});
	}

	if (spreadsheetAssignmet == 'updatePopupBefore') {

		updatePopupSpreadsheetObjBef = jspreadsheet(document.getElementById(spreadsheetAssignmet), {
			data: atollPushData,
			columns: dynamicAssignmentcolumns,
			tableOverflow: true,
			tableWidth: '120%',
			minSpareRows: 0,
			minDimensions: [0, 3],
			filters: true,
			allowInsertRow: false,
			allowInsertColumn: false,
			allowRenameColumn: false,
			allowDeleteColumn: false,
			allowDeleteRow: false,
			autoIncrement: false,

			onchange: function(instance, cell, c, r, value) {

			},
		});
	}

	if (spreadsheetAssignmet == 'updatePopupAfter') {

		updatePopupSpreadsheetObjAft = jspreadsheet(document.getElementById(spreadsheetAssignmet), {
			data: atollPushData,
			columns: dynamicAssignmentcolumns,
			tableOverflow: true,
			tableWidth: '120%',
			minSpareRows: 0,
			minDimensions: [0, 3],
			filters: true,
			allowInsertRow: false,
			allowInsertColumn: false,
			allowRenameColumn: false,
			allowDeleteColumn: false,
			allowDeleteRow: false,
			autoIncrement: false,

			onchange: function(instance, cell, c, r, value) {

			},
		});
	}
}
var updatedPayloadData = [];
var isGnbIdValid = true;
var isGnbDuFirstDigitValid = true;

function transmittergridinfoChange(instance, cell, c, r, value) {
	isRowDataEdited = false;
	rowupdated = document.getElementsByClassName('jexcel jexcel_overflow')[1].rows;
	var ismodified = false;
	var ismodifiedltesector = false;
	var ismodifiedGnbId = false;
	var ismodifiedGnbfrienglyname = false;
	var ismodifiedGnbmixmodellable = false;
	var ismodifiedGnbDUnumber = false;
	var ismodifiedGnbDUfriendlyName = false;
	var ismodifiedEnBID = false;
	var ismodifiedEnbFriendlyname = false;
	var isPayloadToModify = true;


	document.getElementById("updateBtn").disabled = false;
	if (c == 6) {
if (Object.keys(featureToggleMap).includes("F90617") && featureToggleMap['F90617']) {
            var filterData = document.getElementsByClassName('jexcel jexcel_overflow')[1].rows;
                for(var i=1; i< filterData.length; i++) {
                    console.log('filterData[i]', filterData[i].cells[1].innerHTML)
                if (atollPushData[r].transmitter == filterData[i].cells[1].innerHTML) {
                    if (filterData[i].cells[11].style.backgroundColor == 'red') {
                        filterData[i].cells[11].style.backgroundColor = '';
                    }
                    if (filterData[i].cells[12].style.backgroundColor == 'red') {
                        filterData[i].cells[12].style.backgroundColor = '';
                    }
                    if (filterData[i].cells[15].style.backgroundColor == 'red') {
                        filterData[i].cells[15].style.backgroundColor = '';
                    }
                    if (filterData[i].cells[16].style.backgroundColor == 'red') {
                        filterData[i].cells[16].style.backgroundColor = '';
                    }
                }
            }
        }
		for (var i = 0; i < row.length; i++) {
			if (row[i].cells[6].innerHTML == "LTE" && row[i].cells[7].innerHTML == "") {
				rowData.rows[i].cells[12].className = "readonly";
				rowData.rows[i].cells[11].className = "readonly";
				rowData.rows[i].cells[15].className = "readonly";
				rowData.rows[i].cells[16].className = "readonly";
			} else if(row[i].cells[6].innerHTML == "LTE" && row[i].cells[7].innerHTML == "5GDU") {
				//alert("shouldn't be empty");
				rowData.rows[i].cells[12].className = "readonly";
				rowData.rows[i].cells[11].className = "readonly";
				rowData.rows[i].cells[15].className = "readonly";
				rowData.rows[i].cells[16].className = "readonly";
			} else if(row[i].cells[6].innerHTML == "LTE" && row[i].cells[7].innerHTML == "4G5G") {
				rowData.rows[i].cells[12].className = "highlightchange";
				rowData.rows[i].cells[11].className = "highlightchange";
				rowData.rows[i].cells[15].className = "highlightchange";
				rowData.rows[i].cells[16].className = "highlightchange";
			}
		}
		for (var i = 0; i < dataarrayNeMode.length; i++) {
			if (i > 7) {
				if (dataarrayNeMode[parseInt(r) + 7] == value) {
					ismodifiedGnbId = true;
					isPayloadToModify = false;
				}
			}
		}
	} else if (c == 8) {
		for (var i = 0; i < dataarray.length; i++) {
			if (i > 7) {
				let size = 4;
				value = pad(value, size);
				if (value === '0000') {
					value = '';
					cell.innerHTML=value;
				} else {
					spreadsheetTransmitterObj.options.data[r][8] = value;
					cell.innerHTML=value;
				}
				var checkValue=dataarray[parseInt(r) + 7];
				var updatedValue = pad(checkValue, size);
				if (updatedValue == value) {
					ismodified = true;
					isPayloadToModify = false;
				}else if (checkValue == value) {
					ismodified = true;
					isPayloadToModify = false;
				}
			}
		}
	} else if (c == 9) {
		if (/^[0-9]+$/.test(value)) {
			value = value;
		} else {
			value = '';
			cell.innerHTML = '00';
			spreadsheetTransmitterObj.options.data[r][9] = '00';
		}

		if (value <= 9) {
			let size = 2;
			value = pad(value, size);
			if (value == '00') {
				cell.innerHTML = '';
			} else {
				cell.innerHTML = value;
			}
			spreadsheetTransmitterObj.options.data[r][9] = value;
		}
		for (var i = 0; i < dataarraylteSector.length; i++) {
			if (i > 7) {
				var tempLteSector = dataarraylteSector[parseInt(r) + 7];
				if (value <= 9) {
					tempLteSector = dataarraylteSector[parseInt(r) + 7];
					if (tempLteSector.length == 1) {
						let size = 2;
						tempLteSector = pad(tempLteSector, size);
					}
				}
				if (tempLteSector == value) {
					ismodifiedltesector = true;
					isPayloadToModify = false;
				}
			}
		}
	} else if (c == 10) {

			if (value.toString().length == 7) {
				for (var i = 0; i < dataarrayGnbId.length; i++) {
					if (i > 7) {
						if (dataarrayGnbId[parseInt(r) + 7] == value) {
							ismodifiedGnbId = true;
							isPayloadToModify = false;
						}
					}
				}
				if (isPayloadToModify) {
					validateGnbIdFirstAndMiddleNum(instance, cell, c, r, value);
				} else {
					updatedTransmitterGnbIDRecord = updatedTransmitterGnbIDRecord.filter(item => item !== spreadsheetTransmitterObj.options.data[r][0]);
				}
			} else {
				let size = 7;
				if (value) {
					value = pad(value, size);
					cell.innerHTML = value;
					spreadsheetTransmitterObj.options.data[r][10] = value;
				}

				for (var i = 0; i < dataarrayGnbId.length; i++) {
					if (i > 7) {
						if (dataarrayGnbId[parseInt(r) + 7] == value) {
							ismodifiedGnbId = true;
							isPayloadToModify = false;
						}
					}
				}
				if (isPayloadToModify) {
					validateGnbIdFirstAndMiddleNum(instance, cell, c, r, value);
				} else {
					updatedTransmitterGnbIDRecord = updatedTransmitterGnbIDRecord.filter(item => item !== spreadsheetTransmitterObj.options.data[r][0]);
				}
			}

	} else if (c == 11) {

		for (var i = 0; i < dataarrayGnbFriendlyname.length; i++) {
			if (i > 7) {
				if (dataarrayGnbFriendlyname[parseInt(r) + 7] == value) {
					ismodifiedGnbfrienglyname = true;
					isPayloadToModify = false;
				}
			}
		}
	} else if (c == 12) {

		for (var i = 0; i < dataarrayGnbMixmodellable.length; i++) {
			if (i > 7) {
				if (dataarrayGnbMixmodellable[parseInt(r) + 7] == value) {
					ismodifiedGnbfrienglyname = true;
					isPayloadToModify = false;
				}
			}
			addEventListener("paste", (event) => {
				if(value == '' || value == undefined){
cell.style.backgroundColor = 'white';
				}

			});
		}
	} else if (c == 14) {

			if (value.toString().length == 4) {
				for (var i = 0; i < dataarrayGnbDuNumber.length; i++) {
					if (i > 7) {
						if (dataarrayGnbDuNumber[parseInt(r) + 7] == value) {
							ismodifiedGnbDUnumber = true;
							isPayloadToModify = false;

						}
					}
				}
				if (isPayloadToModify) {
					conditionsForGnbDuNumber(instance, cell, c, r, value)
				} else {
					updatedTransmitterGnbDuRecord = updatedTransmitterGnbDuRecord.filter(item => item !== spreadsheetTransmitterObj.options.data[r][0]);
				}
			} else {
				if (value) {
					let size = 4;
					value = pad(value, size);
					cell.innerHTML = value;
					spreadsheetTransmitterObj.options.data[r][14] = value;
				}
				for (var i = 0; i < dataarrayGnbDuNumber.length; i++) {
					if (i > 7) {
						if (dataarrayGnbDuNumber[parseInt(r) + 7] == value) {
							ismodifiedGnbDUnumber = true;
							isPayloadToModify = false;

						}
					}
				}
				if (isPayloadToModify) {
					conditionsForGnbDuNumber(instance, cell, c, r, value)
				} else {
					updatedTransmitterGnbDuRecord = updatedTransmitterGnbDuRecord.filter(item => item !== spreadsheetTransmitterObj.options.data[r][0]);
				}
			}
	} else if (c == 15) {

		for (var i = 0; i < dataarrayGnbDufriendlyname.length; i++) {
			if (i > 7) {
				if (dataarrayGnbDufriendlyname[parseInt(r) + 7] == value) {
					ismodifiedGnbDUfriendlyName = true;
					isPayloadToModify = false;
				}
			}
		}
	} else if (c == 18) {
		for (var i = 0; i < dataarrayEnbId.length; i++) {
			if (i > 7) {
				if (dataarrayEnbId[parseInt(r) + 7] == value) {
					ismodifiedEnBID = true;
					isPayloadToModify = false;
				}
			}
		}
	} else if (c == 19) {
		for (var i = 0; i < dataarrayEnbFriendlyname.length; i++) {
			if (i > 7) {
				if (dataarrayEnbFriendlyname[parseInt(r) + 7] == value) {
					ismodifiedEnbFriendlyname = true;
					isPayloadToModify = false;
				}
			}
		}
	}

	updatedPayloadData.push(spreadsheetTransmitterObj.options.data[r]);

	for(var i=0; i<updatedPayloadData.length; i++) {
		if (updatedPayloadData[i][0] === spreadsheetTransmitterObj.options.data[r][0]) {
			updatedPayloadData[i] = spreadsheetTransmitterObj.options.data[r];
		}
	}

	if (ismodified == true || ismodifiedltesector == true || ismodifiedGnbId == true || ismodifiedGnbfrienglyname == true || ismodifiedGnbmixmodellable == true || ismodifiedGnbDUnumber == true
		|| ismodifiedGnbDUfriendlyName == true || ismodifiedEnBID == true || ismodifiedEnbFriendlyname == true) {
		if (cell.style.backgroundColor == "lightgreen") {
			Editcount--;
		}
		cell.style.backgroundColor = 'white';
	} else {
		if (cell.style.backgroundColor == "") {
			Editcount++
		}
		cell.style.backgroundColor = 'lightgreen';
	}
	rowNumber = r;
	getRowsData = document.getElementById('virtualAssignmentGridInfo').jexcel.getRowData(r);

	//cell.style.backgroundColor = 'lightgreen';
	let valuerecieved = '';
	let valuerecievedcol_7 = '';
	let valuerecievedcol_9 = '';
	let valuerecievedcol_10 = '';
	let valuerecievedcol_13 = '';
	let valuerecievedcol_17 = '';
	valuerecievedcol_17 = value;
	valuerecievedcol_10 = value;
	valuerecievedcol_9 = value;
	valuerecievedcol_7 = value;
	valuerecievedcol_13 = value;
	valuerecieved = value;


	if (valuerecieved.toString().length < 4 && c == 8 && valuerecieved !== '') {
		let size = 4;
		getRowsData[8] = pad(value, size);
		cell.innerHTML = pad(value, size);
	} else if (cell.innerHTML.length > 4 && c == 8) {

		cell.innerHTML = cell.innerHTML.slice(0, 4);
		validate5Sector(instance, cell, c, r, value);
	}

	else if (valuerecievedcol_7.toString().length < 2 && c == 9 && valuerecievedcol_7 !== '') {
		let size = 2;
		getRowsData[9] = pad(value, size);
		cell.innerHTML = pad(value, size);
	} else if (cell.innerHTML.length > 2 && c == 9) {

		cell.innerHTML = cell.innerHTML.slice(0, 2);
	}
	else if (valuerecievedcol_9.toString().length < 7 && c == 10 && valuerecievedcol_9 !== '') {
		let size = 7;
		getRowsData[10] = pad(value, size);
		cell.innerHTML = pad(value, size);
	} else if (cell.innerHTML.length > 7 && c == 10) {

		cell.innerHTML = cell.innerHTML.slice(0, 7);
		validateGnbId(instance, cell, c, r, value);
	}
	else if (valuerecievedcol_13.toString().length < 4 && c == 14 && valuerecievedcol_13 !== '') {
		let size = 4;
		getRowsData[14] = pad(value, size);
		cell.innerHTML = pad(value, size);
		conditionsForGnbDuNumber(instance, cell, c, r, cell.innerHTML);
	} else if (cell.innerHTML.length > 4 && c == 14) {

		cell.innerHTML = cell.innerHTML.slice(0, 4);
		validateGnbDuNumber(instance, cell, c, r, value);
	}
	else if (valuerecievedcol_17.toString().length < 6 && c == 18 && valuerecievedcol_17 !== '') {
		let size = 6;
		getRowsData[18] = pad(value, size);
		cell.innerHTML = pad(value, size);
	} else if (cell.innerHTML.length > 6 && c == 18) {

		cell.innerHTML = cell.innerHTML.slice(0, 6);
		validateEnbIdNumber(instance, cell, c, r, value);
	}



	//subTask - 11979
	let txId = getRowsData[0];
	let cellKey = "";
	if (cellKeyMap.has(c.toString()))
		cellKey = cellKeyMap.get(c.toString());
	let cellValue = getRowsData[c];

	updateAtollDataObject(txId, cellKey, cellValue, atollPushDataTemp, isPayloadToModify, r);

	console.log(atollPushDataTemp);
}

function validateGnbDuFirstNumber(r, value) {
	for (var i = 0; i < dataarrayGnbDuNumber.length; i++) {
		if (i > 7) {
			if (dataarrayGnbDuNumber[parseInt(r) + 7] == value) {
				ismodifiedGnbDUnumber = true;
				isPayloadToModify = false;

			}
			updatedTransmitterGnbDuRecord = updatedTransmitterGnbDuRecord.filter(item => item !== spreadsheetTransmitterObj.options.data[r][0]);
		}
	}
}

function getMiddleDigitFR (vendor,fr,instance, cell, c, r, value,ValueMiddleNumber){
	console.log(getVendFRMiddleDigit,'vendor URL');
	let details =[]
	$.ajax({
		url: getVendFRMiddleDigit+ '?vendor='+vendor+'&fr='+fr,
        dataType: 'json',
		type: "GET",
		contentType: 'application/json; charset=UTF-8',
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function (data) {
			 details = data.mdList;

				if (data.mdList.includes(parseInt(ValueMiddleNumber))) {
					commonCodeForValidateGnbId(r, value);
				} else {
					isGnbIdValid = false;
					validateGnbId(instance, cell, c, r, value);
				}


		},
		error: function (err) {}
	});

}

function validateGnbIdFirstAndMiddleNum(instance, cell, c, r, value) {

	console.log(middleFR1,middleFR2,"FR data");
	var ValuefirstDigit = value.toString()[0];
	var ValueMiddleNumber = value.toString()[3];
	ValuefirstDigit = Number(ValuefirstDigit);
	if (spreadsheetTransmitterObj.options.data[r][5] == 'LTE') {
		commonCodeForValidateGnbId(r, value);
	}
	else if (ValuefirstDigit == 0 || ValuefirstDigit == 1 || ValuefirstDigit == 2) {
		if (Object.keys(featureToggleMap).includes("F9488") && featureToggleMap['F9488']) {
			if (spreadsheetTransmitterObj.options.data[r][3] == 'Bn261' || spreadsheetTransmitterObj.options.data[r][3] == 'Bn260') {
				getMiddleDigitFR(spreadsheetTransmitterObj.options.data[r][4],'FR2',instance, cell, c, r, value,ValueMiddleNumber);
			}
			else if ((spreadsheetTransmitterObj.options.data[r][3] != 'Bn261' || spreadsheetTransmitterObj.options.data[r][3] != 'Bn260')) {
				getMiddleDigitFR(spreadsheetTransmitterObj.options.data[r][4],'FR1',instance, cell, c, r, value,ValueMiddleNumber);

			} else {
				isGnbIdValid = false;
				validateGnbId(instance, cell, c, r, value);
			}
		} else {
			if ((spreadsheetTransmitterObj.options.data[r][4] == 'Samsung' || spreadsheetTransmitterObj.options.data[r][4] == 'Nokia')
				&& (spreadsheetTransmitterObj.options.data[r][3] == 'Bn261' || spreadsheetTransmitterObj.options.data[r][3] == 'Bn260')) {
				if (ValueMiddleNumber == 0) {
					commonCodeForValidateGnbId(r, value);
				} else {
					isGnbIdValid = false;
					validateGnbId(instance, cell, c, r, value);
				}
			} else if ((spreadsheetTransmitterObj.options.data[r][3] == 'Bn261' || spreadsheetTransmitterObj.options.data[r][3] == 'Bn260')) {
				if (ValueMiddleNumber == 0 || ValueMiddleNumber == 1 || ValueMiddleNumber == 2) {
					commonCodeForValidateGnbId(r, value);
				} else {
					isGnbIdValid = false;
					validateGnbId(instance, cell, c, r, value);
				}
			} else if ((spreadsheetTransmitterObj.options.data[r][4] == 'Ericsson' &&
				(spreadsheetTransmitterObj.options.data[r][3] == 'Bn77' ||
					spreadsheetTransmitterObj.options.data[r][3] == 'Bn5' ||
					spreadsheetTransmitterObj.options.data[r][3] == 'Bn5-B5' ||
					spreadsheetTransmitterObj.options.data[r][3] == 'Bn2' ||
					spreadsheetTransmitterObj.options.data[r][3] == 'Bn2-B2' ||
					spreadsheetTransmitterObj.options.data[r][3] == 'Bn66' ||
					spreadsheetTransmitterObj.options.data[r][3] == 'Bn66-B66'
				)
			)) {
				if (ValueMiddleNumber == 7 || ValueMiddleNumber == 9) {
					commonCodeForValidateGnbId(r, value);
				} else {
					isGnbIdValid = false;
					validateGnbId(instance, cell, c, r, value);
				}
			} else if ((spreadsheetTransmitterObj.options.data[r][3] != 'Bn261' || spreadsheetTransmitterObj.options.data[r][3] != 'Bn260')) {
				if (ValueMiddleNumber == 9) {
					commonCodeForValidateGnbId(r, value);
				} else {
					isGnbIdValid = false;
					validateGnbId(instance, cell, c, r, value);
				}
			}
			else {
				isGnbIdValid = false;
				validateGnbId(instance, cell, c, r, value);
			}
		}
	}
	else {
		isGnbIdValid = false;
		validateGnbId(instance, cell, c, r, value);
	}
}

function commonCodeForValidateGnbId(r, value) {
	isGnbIdValid = true;
	for (var i = 0; i < dataarrayGnbId.length; i++) {
		if (i > 7) {
			if (dataarrayGnbId[parseInt(r) + 7] == value) {
				ismodifiedGnbId = true;
				isPayloadToModify = false;
			}
		}
		updatedTransmitterGnbIDRecord = updatedTransmitterGnbIDRecord.filter(item => item !== spreadsheetTransmitterObj.options.data[r][0]);
	}
}

function conditionsForGnbDuNumber(instance, cell, c, r, value) {
	var valuefirstDigit = value.toString()[0];

	if (Object.keys(featureToggleMap).includes("M10642") && featureToggleMap['M10642']
		&& typeof value !== 'undefined' && value !== null && value.toString().length === 4 && $.isNumeric(value)) {
		var vendor = spreadsheetTransmitterObj.options.data[r][4];
		var band = spreadsheetTransmitterObj.options.data[r][3];
		var fr = (band === 'Bn260' || band === 'Bn261') ? 'FR2' : 'FR1';

		if (vendor && getVendFRFirstDuDigit) {
			$.ajax({
				url: getVendFRFirstDuDigit + '?vendor=' + encodeURIComponent(vendor) + '&fr=' + encodeURIComponent(fr),
				dataType: 'json',
				type: "GET",
				contentType: 'application/json; charset=UTF-8',
				headers: {
					'Accept': 'application/json, text/plain, */*',
					'Content-Type': 'application/json'
				},
				success: function(data) {
					var firstDigit = parseInt(valuefirstDigit, 10);
					var fdList = data && data.fdList ? data.fdList : [];

					if (Array.isArray(fdList) && fdList.indexOf(firstDigit) !== -1) {
						isGnbDuFirstDigitValid = true;
						validateGnbDuFirstNumber(r, value);
					} else {
						isGnbDuFirstDigitValid = false;
						validateGnbDuNumber(instance, cell, c, r, value);
					}
				},
				error: function() {
					// Fall back to existing static checks if API is unavailable.
					if (spreadsheetTransmitterObj.options.data[r][4] == 'Samsung' && spreadsheetTransmitterObj.options.data[r][3] == 'Bn77') {
						if (Number(valuefirstDigit) == 3) {
							validateGnbDuFirstNumber(r, value);
						} else {
							isGnbDuFirstDigitValid = false;
							validateGnbDuNumber(instance, cell, c, r, value);
						}
					} else if (spreadsheetTransmitterObj.options.data[r][4] == 'Samsung' && spreadsheetTransmitterObj.options.data[r][3] !== ('Bn261' || 'Bn260' || 'Bn77')) {
						if (Number(valuefirstDigit) == 2) {
							validateGnbDuFirstNumber(r, value);
						} else {
							isGnbDuFirstDigitValid = false;
							validateGnbDuNumber(instance, cell, c, r, value);
						}
					} else if (spreadsheetTransmitterObj.options.data[r][3] == 'Bn261' || spreadsheetTransmitterObj.options.data[r][3] == 'Bn260'
						|| spreadsheetTransmitterObj.options.data[r][4] == 'Nokia' || spreadsheetTransmitterObj.options.data[r][4] == 'Ericsson') {
						if (Number(valuefirstDigit) == 0 || Number(valuefirstDigit) == 1) {
							validateGnbDuFirstNumber(r, value);
						} else {
							isGnbDuFirstDigitValid = false;
							validateGnbDuNumber(instance, cell, c, r, value);
						}
					}
				}
			});
			return;
		}
	}
else {
         	if (spreadsheetTransmitterObj.options.data[r][4] == 'Samsung' && spreadsheetTransmitterObj.options.data[r][3] == 'Bn77') {
         		if (Number(valuefirstDigit) == 3) {
         			validateGnbDuFirstNumber(r, value);
         		} else {
         			isGnbDuFirstDigitValid = false;
         			validateGnbDuNumber(instance, cell, c, r, value);
         		}
         	} else if (spreadsheetTransmitterObj.options.data[r][4] == 'Samsung' && spreadsheetTransmitterObj.options.data[r][3] !== ('Bn261' || 'Bn260' || 'Bn77')) {
         		if (Number(valuefirstDigit) == 2) {
         			validateGnbDuFirstNumber(r, value);
         		} else {
         			isGnbDuFirstDigitValid = false;
         			validateGnbDuNumber(instance, cell, c, r, value);
         		}
         	} else if (spreadsheetTransmitterObj.options.data[r][3] == 'Bn261' || spreadsheetTransmitterObj.options.data[r][3] == 'Bn260'
         		|| spreadsheetTransmitterObj.options.data[r][4] == 'Nokia' || spreadsheetTransmitterObj.options.data[r][4] == 'Ericsson') {
         		if (Number(valuefirstDigit) == 0 || Number(valuefirstDigit) == 1) {
         			validateGnbDuFirstNumber(r, value);
         		} else {
         			isGnbDuFirstDigitValid = false;
         			validateGnbDuNumber(instance, cell, c, r, value);
         		}
         	}
}

}

function checkAllTheEditedValue(r, rowData) {

			rowData.gNBId = rowData.gNBId ? rowData.gNBId : '';
			rowData.fiveGSector = rowData.fiveGSector ? rowData.fiveGSector : '';
			rowData.ltesector = rowData.ltesector ? rowData.ltesector : '';
			rowData.gNBDUNumber = rowData.gNBDUNumber ? rowData.gNBDUNumber : '';
			rowData.gNBFriendlyNam = rowData.gNBFriendlyNam ? rowData.gNBFriendlyNam : '';
			rowData.gNBMixedModeLabel = rowData.gNBMixedModeLabel ? rowData.gNBMixedModeLabel : '';
			rowData.gNBDUFriendlyname = rowData.gNBDUFriendlyname ? rowData.gNBDUFriendlyname : '';
			rowData.eNBFriendlyName = rowData.eNBFriendlyName ? rowData.eNBFriendlyName : '';
			rowData.eNBID = rowData.eNBID ? rowData.eNBID : '';
			rowData.neMode = rowData.neMode ? rowData.neMode : '';

		if ((rowData.gNBId == dataarrayGnbId[parseInt(r) + 7])
			&& (rowData.fiveGSector == dataarray[parseInt(r) + 7])
			&& (rowData.ltesector == dataarraylteSector[parseInt(r) + 7])
			&& (rowData.gNBDUNumber == dataarrayGnbDuNumber[parseInt(r) + 7])
			&& (rowData.gNBFriendlyName == dataarrayGnbFriendlyname[parseInt(r) + 7])
			&& (rowData.gNBMixedModeLabel == dataarrayGnbMixmodellable[parseInt(r) + 7])
			&& (rowData.gNBDUFriendlyname == dataarrayGnbDufriendlyname[parseInt(r) + 7])
			&& (rowData.eNBFriendlyName == dataarrayEnbFriendlyname[parseInt(r) + 7])
            && (rowData.eNBID == dataarrayEnbId[parseInt(r) + 7])
            && (rowData.neMode == dataarrayNeMode[parseInt(r) + 7])) {
			isRowDataEdited = false;
		} else {
			isRowDataEdited = true;
		}
}

function updateAtollDataObject(txId, cellKey, cellValue, atollDataOriginal, isPayloadToModify, r) {
	$.each(atollDataOriginal, function(key, value) {

		if (atollDataOriginal[key] != null && atollDataOriginal[key].hasOwnProperty("transmitter")) {
			if (atollDataOriginal[key].transmitter == txId) {
				if (isPayloadToModify)
					atollDataOriginal[key].isModified = 1;
				else
					atollDataOriginal[key].isModified = 0;
				if (atollDataOriginal[key].hasOwnProperty(cellKey)) {
					switch (cellKey) {
						case 'neMode':
							atollDataOriginal[key].neMode = cellValue;
							break;
						case 'fiveGSector':
							atollDataOriginal[key].fiveGSector = cellValue;
							break;
						case 'ltesector':
							atollDataOriginal[key].ltesector = cellValue;
							break;
						case 'gNBId':
							atollDataOriginal[key].gNBId = cellValue;
							break;
						case 'gNBFriendlyName':
							atollDataOriginal[key].gNBFriendlyName = cellValue;
							break;
						case 'gNBMixedModeLabel':
							atollDataOriginal[key].gNBMixedModeLabel = cellValue;
							break;
						case 'gNBDUNumber':
							atollDataOriginal[key].gNBDUNumber = cellValue;
							break;
						case 'gNBDUFriendlyname':
							atollDataOriginal[key].gNBDUFriendlyname = cellValue;
						//	atollDataOriginal[key].gNBDUFriendlyname.toUpperCase();
							break;
						case 'eNBID':
							atollDataOriginal[key].eNBID = cellValue;
							break;
						case 'eNBFriendlyName':
							atollDataOriginal[key].eNBFriendlyName = cellValue;
							break;
						default:
							break;
					}
				}
					checkAllTheEditedValue(r, atollDataOriginal[key]);
					if (isRowDataEdited) {
						atollDataOriginal[key].isModified = 1;
					} else {
						atollDataOriginal[key].isModified = 0;
					}
			}
		}

		atollDataOriginal[key].atollSchema = sechmaList;
	});

	atollPushDataTemp = atollDataOriginal;

}

function pad(num, size) {
	num = num.toString();
	while (num.length < size) num = "0" + num;
	return num;
}
function populateAssignmentTerritory(isServerCallReq) {
	if (isServerCallReq) {
		territoryDataProvider = [];
		$.ajax({
			url: CONTEXT_PATH + '/uui/eapp/rfds_pg/getTerritoryDropdown',
			dataType: 'json',
			type: "GET",
			async: false,
			success: function(data) {
				territoryDataProvider = data;
				if (loadOffScreenData) {
					entireTerritoryList = [];
					$.each(territoryDataProvider, function(index, value) {
						entireTerritoryList.push(value.TERRITORY);
					});

				}
			},
			error: function(data) {
				aptAlert('Warning', 'Failed to load territory data!');
			}
		});
	} else {
		if (loadOffScreenData) {
			entireTerritoryList = [];
			$.each(territoryDataProvider, function(index, value) {
				entireTerritoryList.push(value.TERRITORY);
			});

		}
	}
	// $.each(territoryDataProvider, function (index, value) {
	// //	$('#territoryDropdown').append("<option    id='" + value.TERRITORY + "' value='" + value.TERRITORY + "' class='multis'>" + value.TERRITORY + "</option>");
	// });
	$.each(territoryDataProvider, function(index, value) {
		if (aorTerritory.includes(value.TERRITORY)) {
			$('#territoryDropdown').append("<option   selected id='" + value.TERRITORY + "' value='" + value.TERRITORY + "' class='multis'>" + value.TERRITORY + "</option>");
		}
		else {
			$('#territoryDropdown').append("<option  id='" + value.TERRITORY + "' value='" + value.TERRITORY + "' class='multis'>" + value.TERRITORY + "</option>");

		}
	});
		if (onChangeFlag) {
			$('#territoryDropdown').val('');

		}

	$('#territoryDropdown').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		numberDisplayed: 1,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		onDropdownHide: function(option, checked, select) {

			$("#siteNameSelect").val('');
		}
	});
}
function siteVersionDropdownValidation(){
	$.each(siteDropdownList, function(i, v) {
		if(v=="0000"||v=="0001"||v=="0FAA"){
		$('#siteVersionDropdownId').append("<option selected>" + v + "</option>");
		}else{
			$('#siteVersionDropdownId').append("<option>" + v + "</option>");
		}
	});
}
$('#territoryDropdown').change(function() {
	onChangeFlag = true;
	gnbAssignTerritoryList = $("#territoryDropdown").val();
	$("#siteVersionDropdownId").html('')
	$('#siteVersionDropdownId').multiselect('destroy');
	siteVersionDropdownValidation()
	$('#siteVersionDropdownId').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1
	});
	$("#siteVersionDropdownId").multiselect('disable')
	siteVersions = $('#siteVersionDropdownId').val();
	if (gnbAssignTerritoryList) {

		populateAssignmentAreas(gnbAssignTerritoryList, true);
		clearAssignmentDropdowns("#fr1Fr2Db");
		$("#fr1Fr2Db").multiselect('disable');
		clearAssignmentDropdowns('#regionDropdown');
		clearAssignmentDropdowns('#marketDropdown');
		clearAssignmentDropdowns('#avendorDropdown');
	} else {
		gnbAssignTerritoryList = '';
		gnbAssignRegionList = '';
		marketsSelected = '';
		gnbAssignAreaList == '';
		clearAssignmentDropdowns('#areaDropdown');
		clearAssignmentDropdowns('#regionDropdown');
		clearAssignmentDropdowns('#marketDropdown');
		clearAssignmentDropdowns('#avendorDropdown');
		clearAssignmentDropdowns("#fr1Fr2Db");
		$("#fr1Fr2Db").multiselect('disable');
		document.getElementById("PhysicalCheckbox").checked = false;
	}
});

function populateAssignmentAreas(tList, isServerCallReq) {
	if (tList) {
		if (isServerCallReq) {
			areasDataProvider = [];
		}
		else {
			if (loadOffScreenData) {
				entireAreaList = [];
				$.each(areasDataProvider, function(index, value) {
					entireAreaList.push(value.area);
				});
			}
		}
		if (tList != null) {
			var territoryList = JSON.stringify(tList);
			$.ajax({
				async: false,
				url: CONTEXT_PATH + '/uui/eapp/rfds_pg/getAreaForMarketBoundary',
				type: "POST",
				data: { territoryList: territoryList },
				cache: false,
				success: function(data) {
					areasDataProvider = JSON.parse(data).areas;
					if (loadOffScreenData) {
						entireAreaList = [];
						$.each(areasDataProvider, function(index, value) {
							entireAreaList.push(value.area);
						});
					}
				}
			});
		}
	} else {
		$('#areaDropdown').multiselect('clearSelection');
		$('#aRegionDropdown').multiselect('clearSelection');
		$('#aMarketDropdown').multiselect('clearSelection');
		document.getElementById("PhysicalCheckbox").checked = false;
	}
	$('#areaDropdown').html('');
	$('#areaDropdown').multiselect('destroy');
	if (areaFlag) {
		$.each(areasDataProvider, function(index, value) {
			$('#areaDropdown').append("<option value='" + value.area + "' class='multis'>" + value.areaname + "</option>");
		});
	} else {
		$.each(areasDataProvider, function(index, value) {
			if (aorArea.includes(value.area)) {
				$('#areaDropdown').append("<option selected value='" + value.area + "' class='multis'>" + value.areaname + "</option>");
			}
			else {
				$('#areaDropdown').append("<option value='" + value.area + "' class='multis'>" + value.areaname + "</option>");
			}
		});
	}

	if (onChangeFlag) {
		$('#areaDropdown').val('');
	}

	$('#areaDropdown').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		numberDisplayed: 1,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		onDropdownHide: function(option, checked, select) {


			$("#siteNameSelect").val('');
		}
	});
	setTimeout(function() {
		$('#areaDropdown').multiselect({
			includeSelectAllOption: true,
			enableFiltering: true,
			enableCaseInsensitiveFiltering: true,
			numberDisplayed: 1
		});
	}, 1);

}

$('#areaDropdown').change(function() {
	onChangeFlag = true;
	gnbAssignAreaList = $('#areaDropdown').val();

	$("#siteVersionDropdownId").html('')
	$('#siteVersionDropdownId').multiselect('destroy');
	siteVersionDropdownValidation()
	$('#siteVersionDropdownId').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1
	});
	$("#siteVersionDropdownId").multiselect('disable')
	siteVersions = $('#siteVersionDropdownId').val();

	if (gnbAssignAreaList) {
		populateAssignmentRegions(gnbAssignAreaList, true);
		clearAssignmentDropdowns("#fr1Fr2Db");
		$("#fr1Fr2Db").multiselect('disable');
		clearAssignmentDropdowns('#marketDropdown');
		clearAssignmentDropdowns('#avendorDropdown');
	} else {
		gnbAssignRegionList = '';
		marketsSelected = [];
		clearAssignmentDropdowns('#regionDropdown');
		clearAssignmentDropdowns('#marketDropdown');
		clearAssignmentDropdowns('#avendorDropdown');
		clearAssignmentDropdowns("#fr1Fr2Db");
		$("#fr1Fr2Db").multiselect('disable');
		document.getElementById("PhysicalCheckbox").checked = false;

	}
});

function populateAssignmentRegions(gnbAssignAreaList, isServerCallReq) {
	if (gnbAssignAreaList) {
		if (isServerCallReq) {
			regionsDataProvider = [];
		} else {
			if (loadOffScreenData) {
				entireRegionList = [];
				$.each(regionsDataProvider, function(index, value) {
					entireRegionList.push(value.region);
				});

			}
		}
		if (gnbAssignAreaList != null) {
			var areaList = JSON.stringify(gnbAssignAreaList);

			$.ajax({
				async: false,
				url: CONTEXT_PATH + '/uui/eapp/rfds_pg/getRegionsForMarketBoundary',
				type: "POST",
				data: { areaList: areaList },
				cache: false,
				success: function(data) {
					regionsDataProvider = JSON.parse(data).regions;
					if (loadOffScreenData) {
						entireRegionList = [];
						$.each(regionsDataProvider, function(index, value) {
							entireRegionList.push(value.region);
						});


					}
					$('#regionDropdown').html('');
					$('#regionDropdown').multiselect('destroy');
					$.each(regionsDataProvider, function(index, value) {


						if (aorRegion === value.region) {
							$('#regionDropdown').append("<option selected value='" + value.region + "' class='multis'>" + value.regionname + "</option>");
						} else {
							$('#regionDropdown').append("<option  value='" + value.region + "' class='multis'>" + value.regionname + "</option>");
						}
					});
					if (regionFlag)
						$('#regionDropdown').val('');
						if (onChangeFlag) {
							$('#regionDropdown').val('');
						}
					$('#regionDropdown').multiselect({
						//includeSelectAllOption: false,
						multiple: false,
						selectedList: 1,
						enableFiltering: true,
						//numberDisplayed: 1,
						enableCaseInsensitiveFiltering: true,
						buttonClass: 'btn btn-default whitebg btn-sm',
						onDropdownHide: function(option, checked, select) {
							$("#siteNameSelect").val('');
						}
					});
					setTimeout(function() {
						$('#regionDropdown').multiselect({
							includeSelectAllOption: true,
							enableFiltering: true,
							enableCaseInsensitiveFiltering: true,
							numberDisplayed: 1
						});
					}, 1);
				}
			});
		}


	}

}

$('#regionDropdown').change(function() {
	onChangeFlag = true;
	$('#marketDropdown').val('');
	marketsSelected = [];
	gnbAssignRegionList = $('#regionDropdown').val();

	if (gnbAssignRegionList) {
		populateAssignmentMarkets(gnbAssignRegionList, true);
		marketsSelected = [];
		clearAssignmentDropdowns("#fr1Fr2Db");
		$("#fr1Fr2Db").multiselect('disable');
	} else {

		clearAssignmentDropdowns('#marketDropdown');
		clearAssignmentDropdowns('#avendorDropdown');
		clearAssignmentDropdowns("#fr1Fr2Db");
		document.getElementById("PhysicalCheckbox").checked = false;
		$("#fr1Fr2Db").multiselect('disable');

	}
});

function populateAssignmentMarkets(gnbAssignRegionList, isServerCallReq) {
	if (isServerCallReq) {
		marketsDataProvider = [];
	} else {
		if (loadOffScreenData) {
			entireMarketList = [];
			$.each(marketsDataProvider, function(index, value) {
				entireMarketList.push(value.MARKET);
			});
		}
	}
	if (gnbAssignRegionList != null) {
		var regionList = JSON.stringify(gnbAssignRegionList);
		$.ajax({
			async: false,
			url: CONTEXT_PATH + '/uui/eapp/rfds_pg/getMarketsForMarketBoundary',
			type: "POST",
			data: { regionList: regionList },
			cache: false,
			success: function(data) {
				marketsDataProvider = JSON.parse(data).markets;
				if (loadOffScreenData) {
					entireMarketList = [];
					$.each(marketsDataProvider, function(index, value) {
						entireMarketList.push(value.MARKET);
					});
				}
				clearAssignmentDropdowns('#avendorDropdown');
				document.getElementById("PhysicalCheckbox").checked = false;
				$('#marketDropdown').html('');
				$('#marketDropdown').multiselect('destroy');

				$.each(marketsDataProvider, function(index, value) {
					marketsMapping[value.MARKET] = value.MARKETNAME;
					if (aorMarket == value.MARKETNAME) {
						$('#marketDropdown').append("<option selected value='" + value.MARKET + "' class='multis' >" + value.MARKET + "-" + value.MARKETNAME + "</option>");
					} else {
						$('#marketDropdown').append("<option value='" + value.MARKET + "' class='multis'>" + value.MARKET + "-" + value.MARKETNAME + "</option>");
					}
				});
				if (marketFlag)
					$('#marketDropdown').val('', '');
					if (onChangeFlag) {
						$('#marketDropdown').val('', '');
					}
				$('#marketDropdown').multiselect({
					includeSelectAllOption: true,
					enableFiltering: true,
					numberDisplayed: 1,
					enableCaseInsensitiveFiltering: true,
					buttonClass: 'btn btn-default whitebg btn-sm',

					onDropdownHide: function(option, checked, select) {
						let marketValue = $('#marketDropdown').val();
						if (marketValue != null && marketValue.length > 0) {
							$("#siteNameSelect").val('');
						}

					},

				});

				setTimeout(function() {
					$('#marketDropdown').multiselect({
						includeSelectAllOption: true,
						enableFiltering: true,
						numberDisplayed: 1,
						enableCaseInsensitiveFiltering: true,
					});
				}, 1);
			}
		});
	}

}

$('#marketDropdown').change(function() {
	document.getElementById("PhysicalCheckbox").checked = false;
	var selected = $(this).find("option:selected");
	getMarketName = selected[0].innerHTML.split('-');
	marketsSelected = '';
	marketsSelected = $('#marketDropdown').val();
	$("#siteVersionDropdownId").multiselect("enable");

	// selected.each(function () {
	// 	marketsSelected.push($(this).val());
	// });
	selectedMarketList = [];
	selectedMarketList.push(marketsSelected);
	if (gNodeBSelected) {
		populatevvendorDropdownforAssignment(selectedMarketList);
	}
	clearAssignmentDropdowns("#fr1Fr2Db");
	$("#fr1Fr2Db").multiselect('disable');



});

function populatevvendorDropdownforAssignment(marketsSelectedforvender) {
	$.ajax({
		type: 'POST',
		async: false,
		//url: "http://localhost:8100/npp-atoll-services/atollUtility/fetchVendors",
		url: fetchVendorsUrl,
		dataType: 'json',
		contentType: 'application/json; charset=UTF-8',
		cache: false,
		data: JSON.stringify(marketsSelectedforvender),
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function(data) {
			vendors = data;

			if (loadOffScreenData) {
				entireMarketList = [];
				$.each(vendors, function(index, value) {
					entireMarketList.push(value);
				});
			}
			$('#avendorDropdown').html('');
			$('#avendorDropdown').multiselect('destroy');
			$('#avendorDropdown').append("<option value='' id='selectAllVendor'>Select All</option>");
			$.each(vendors, function(index, value) {
				$('#avendorDropdown').append("<option  class='multis'>" + value + "</option>");
			});
			$('#avendorDropdown').val('', '');
			$('#avendorDropdown').multiselect({
				includeSelectAllOption: true,
				enableFiltering: true,
				numberDisplayed: 1,
				enableCaseInsensitiveFiltering: true,
				buttonClass: 'btn btn-default whitebg btn-sm',
				onChange: function(option, checked, select) {
					var selectItem = $('#selectAllVendor').val();

					if (selectItem == 'selectAll') {
						$('#avendorDropdown').attr('disabled', false);
					}

				},
				onDropdownHide: function(option, checked, select) {
					let marketValue = $('#avendorDropdown').val();
					if (marketValue != null && marketValue.length > 0) {
						$("#siteNameSelect").val('');
					}

				},

			});

			setTimeout(function() {
				$('#avendorDropdown').multiselect({
					includeSelectAllOption: true,
					enableFiltering: true,
					numberDisplayed: 1,
					enableCaseInsensitiveFiltering: true,
				});
			}, 1);
		},
		error: function(data) {
			$('#loading').hide();
			aptAlert('error', 'failed');
		}
	});
}

$('#fr1Fr2Db').change(function() {
	fRValues = $('#fr1Fr2Db').val();
	current_page = 1;
});
var getSelectedValue;
var currentPage = 1;
function setDuPaginationActivePage(pageNumber, totalPages) {
	const pageList = document.getElementById("showHidePageIDList");
	if (!pageList) {
		return;
	}

	// Clear any previously active page item in the DU pagination strip.
	pageList.querySelectorAll("li.page-item.active").forEach(function(item) {
		item.classList.remove("active");
	});

	const dynamicPageItem = document.getElementById("showHidePageIDItem" + pageNumber);
	if (dynamicPageItem) {
		dynamicPageItem.classList.add("active");
		return;
	}

	if (pageNumber === 1) {
		const firstPageItem = document.getElementById("showHidePageID");
		if (firstPageItem) {
			firstPageItem.classList.add("active");
		}
		return;
	}

	if (pageNumber <= totalPages) {
		const legacyPageItem = document.getElementById("showHidePage" + (pageNumber - 1));
		if (legacyPageItem) {
			legacyPageItem.classList.add("active");
		}
	}
}
function goToPageList(pageNumber,totalPages){
	currentPage = pageNumber;
	setDuPaginationActivePage(pageNumber, totalPages);
	if(currentPage == 1){
		showFirst()
	}else{
	for(let i =1 ; i<= totalPages;i++){
		const rows = document.querySelectorAll(`#dusRows${i}`);
		if(rows && rows.length > 0) {
			rows[0].style.display = (i === pageNumber) ? 'block' :'none';
		}
	}
	}
}
function showPreviousList(totalPages){
	if(currentPage >1){
		goToPageList(currentPage-1,totalPages);
	}

}
function showNextList(totalPages){
	if(totalPages <= 1){
		goToPageList(1,totalPages);
		return;
	}

	const nextPage = currentPage >= totalPages ? 1 : currentPage + 1;
	goToPageList(nextPage,totalPages)

}
function loadGnbIdsDrillView() {
if ((Object.keys(featureToggleMap).includes("F90277") && featureToggleMap['F90277'])) {
		document.querySelectorAll("#dusMarketRows1").forEach(el => el.className = "geohierarchydiv");
		document.querySelectorAll("#errisonHead").forEach(el => el.className = "geohierarchydiv");
		document.querySelectorAll("#physicalTabView").forEach(el => el.className = "geohierarchydiv");

} else {
			document.querySelectorAll("#dusMarketRows1").forEach(el => el.removeClass = "geohierarchydiv");
			document.querySelectorAll("#errisonHead").forEach(el => el.removeClass = "geohierarchydiv");
			document.querySelectorAll("#physicalTabView").forEach(el => el.removeClass = "geohierarchydiv");

		}
	if (tabIndexGnbAtollUpdate == 1 ) {
	$("#showVirtualDuIdss").hide();
	$("#virtualGnbView").hide();
	$("#phyGnbView").show();
	$("#configurationGridToolBar").hide();
	let e = document.getElementById("avendorDropdown");
	if (e.options) {
		 getSelectedValue = e.options[e.selectedIndex].value;
	}
	var gnodeb = '';
	if ($("#eNodebIdSelect").val()) {
		gnodeb = $("#eNodebIdSelect").val();
	}
		document.getElementById("dusRows1").outerHTML = "<div class='containerseating' id='dusRows1'></div>";
		document.getElementById("dusRows2").outerHTML = "<div class='containerseating' id='dusRows2'></div>";
		document.getElementById("dusRows3").outerHTML = "<div class='containerseating' id='dusRows3'></div>";
		document.getElementById("dusRows4").outerHTML = "<div class='containerseating' id='dusRows4'></div>";
		document.getElementById("dusRows5").outerHTML = "<div class='containerseating' id='dusRows5'></div>";
		document.getElementById("dusRows6").outerHTML = "<div class='containerseating' id='dusRows6'></div>";
		document.getElementById("dusRows7").outerHTML = "<div class='containerseating' id='dusRows7'></div>";
		document.getElementById("dusRows8").outerHTML = "<div class='containerseating' id='dusRows8'></div>";
		document.getElementById("dusRows9").outerHTML = "<div class='containerseating' id='dusRows9'></div>";
		document.getElementById("dusRows10").outerHTML = "<div class='containerseating' id='dusRows10'></div>";
	} else {
		getSelectedValue = "Ericsson";
		document.getElementById("fiveGPhysicaldusRows1").outerHTML = "<div class='containerseatingFivegPhysicalVirtual' id='fiveGPhysicaldusRows1'></div>";
		document.getElementById("fiveGPhysicaldusRows2").outerHTML = "<div class='containerseatingFivegPhysicalVirtual' id='fiveGPhysicaldusRows2'></div>";
		document.getElementById("fiveGPhysicaldusRows3").outerHTML = "<div class='containerseatingFivegPhysicalVirtual' id='fiveGPhysicaldusRows3'></div>";
		document.getElementById("fiveGPhysicaldusRows4").outerHTML = "<div class='containerseatingFivegPhysicalVirtual' id='fiveGPhysicaldusRows4'></div>";
		document.getElementById("fiveGPhysicaldusRows5").outerHTML = "<div class='containerseatingFivegPhysicalVirtual' id='fiveGPhysicaldusRows5'></div>";
		document.getElementById("fiveGPhysicaldusRows6").outerHTML = "<div class='containerseatingFivegPhysicalVirtual' id='fiveGPhysicaldusRows6'></div>";
		document.getElementById("fiveGPhysicaldusRows7").outerHTML = "<div class='containerseatingFivegPhysicalVirtual' id='fiveGPhysicaldusRows7'></div>";
		document.getElementById("fiveGPhysicaldusRows8").outerHTML = "<div class='containerseatingFivegPhysicalVirtual' id='fiveGPhysicaldusRows8'></div>";
		document.getElementById("fiveGPhysicaldusRows9").outerHTML = "<div class='containerseatingFivegPhysicalVirtual' id='fiveGPhysicaldusRows9'></div>";
		document.getElementById("fiveGPhysicaldusRows10").outerHTML = "<div class='containerseatingFivegPhysicalVirtual' id='fiveGPhysicaldusRows10'></div>";

	}
if ((Object.keys(featureToggleMap).includes("F90277") && featureToggleMap['F90277'])) {
		document.querySelectorAll("#dusRows1").forEach(el => el.className = "geohierarchydiv");
		document.querySelectorAll("#dusRows2").forEach(el => el.className = "geohierarchydiv");
		document.querySelectorAll("#dusRows3").forEach(el => el.className = "geohierarchydiv");
		document.querySelectorAll("#dusRows4").forEach(el => el.className = "geohierarchydiv");
		document.querySelectorAll("#dusRows5").forEach(el => el.className = "geohierarchydiv");
		document.querySelectorAll("#dusRows6").forEach(el => el.className = "geohierarchydiv");
		document.querySelectorAll("#dusRows7").forEach(el => el.className = "geohierarchydiv");
		document.querySelectorAll("#dusRows8").forEach(el => el.className = "geohierarchydiv");
		document.querySelectorAll("#dusRows9").forEach(el => el.className = "geohierarchydiv");
		document.querySelectorAll("#dusRows10").forEach(el => el.className = "geohierarchydiv");

} else {
	document.querySelectorAll("#dusRows1").forEach(el => el.removeClass = "geohierarchydiv");
	document.querySelectorAll("#dusRows2").forEach(el => el.removeClass = "geohierarchydiv");
	document.querySelectorAll("#dusRows3").forEach(el => el.removeClass = "geohierarchydiv");
	document.querySelectorAll("#dusRows4").forEach(el => el.removeClass = "geohierarchydiv");
	document.querySelectorAll("#dusRows5").forEach(el => el.removeClass = "geohierarchydiv");
	document.querySelectorAll("#dusRows6").forEach(el => el.className = "geohierarchydiv");
	document.querySelectorAll("#dusRows7").forEach(el => el.className = "geohierarchydiv");
	document.querySelectorAll("#dusRows8").forEach(el => el.className = "geohierarchydiv");
	document.querySelectorAll("#dusRows9").forEach(el => el.className = "geohierarchydiv");
	document.querySelectorAll("#dusRows10").forEach(el => el.className = "geohierarchydiv");
		}

	if ((getSelectedValue !== " " || getSelectedValue !== null)) {

		document.getElementById("PhysicalCheckbox").checked = true;
		$('.pageCriteria').hide();
		$('#exportToExcel').hide();
		//$('#fiveGexportToExcel').hide();
		$("#assignmentGridToolbar").hide();

		if (tabIndexGnbAtollUpdate == 1 ) {
		var physicalPayload = {
			"marketName": marketsSelected,
			"vendor": getSelectedValue,
			"vzGnodebId": gnodeb,
			"fR2": fRValues,
			"siteVersions": siteVersions
		};
		physicalMarket = marketsSelected;
		} else {
			var physicalPayload = {

				atollSchema: sechmaList,
				fR2: "",
				marketName: marketIdOrName,
				siteName: "",
				validationFlag: [
				  ""
				],
				vendor: "Ericsson",
				vzGnodebId: "",
				"siteVersions": $("#atollUpdateRightSiteVersion").val()

			};
			physicalMarket = marketIdOrName;
		}


		$.ajax({
			type: 'POST',
			async: false,
			//url: "http://localhost:8100/npp-atoll-services/enbgnbAssignment/fetchPhysicalGNBDetails",
			url: fetchPhysicalGNBDetailsUrl,
			dataType: 'json',
			contentType: 'application/json; charset=UTF-8',
			cache: false,
			data: JSON.stringify(physicalPayload),
			headers: {
				'Accept': 'application/json, text/plain, */*',
				'Content-Type': 'application/json'
			},
			success: function(data) {
					$("#exportToExcelPhGnbView").show();
				fetchPhyGnbs = data;
				var fetchGnbIds = data;
				if (fetchGnbIds.length == 0) {
					$("#phyGnbView").hide();
					alert("Not found GnbDUNumbers");
				} else {
					onlyExceptionFlag = false;
					var fetchGnbIdslength = fetchGnbIds.length;

					var fetchGnbIdRows = Math.ceil(fetchGnbIdslength / 25);


					if (fRValues === "FR1") {
						$("#showHidePageID").show();
						$("#showHidePage2").hide();
						$("#showHidePage3").hide();
						$("#showHidePage4").hide();

						//$("#showHidePage1").show();
						var flag = false;
						for (var i = 0; i < 40; i++) {
							var sId = "seatingrow" + i;
							$("#dusRows1").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							for (var j = 1; j <= 25; j++) {
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName + '">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}

						}
						$("#showHidePage1").show();
						for (var i = 40; i < 80; i++) {
							var sId = "seatingrow" + i;
							$("#dusRows2").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							for (var j = 1; j <= 25; j++) {
								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						for (var i = 80; i < 120; i++) {
							var sId = "seatingrow" + i;
							$("#dusRows3").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							for (var j = 1; j <= 25; j++) {
								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						for (var i = 120; i < 160; i++) {
							var sId = "seatingrow" + i;
							$("#dusRows4").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							for (var j = 1; j <= 25; j++) {
								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						for (var i = 160; i < 200; i++) {
							var sId = "seatingrow" + i;
							$("#dusRows5").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							for (var j = 1; j <= 25; j++) {
								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						for (var i = 200; i < 240; i++) {
							var sId = "seatingrow" + i;
							$("#dusRows6").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							for (var j = 1; j <= 25; j++) {
								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						for (var i = 240; i < 280; i++) {
							var sId = "seatingrow" + i;
							$("#dusRows7").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							for (var j = 1; j <= 25; j++) {
								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						for (var i = 280; i < 320; i++) {
							var sId = "seatingrow" + i;
							$("#dusRows8").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							for (var j = 1; j <= 25; j++) {
								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						for (var i = 320; i < 340; i++) {
							var sId = "seatingrow" + i;
							$("#dusRows9").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							for (var j = 1; j <= 25; j++) {
								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						for (var i = 360; i < 400; i++) {
							var sId = "seatingrow" + i;
							$("#dusRows10").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							for (var j = 1; j <= 25; j++) {
								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}


						// if (fetchGnbIdRows <= 40) {
						// 	$("#showHidePage").hide();
						// 	var flag = false;
						// 	for (var i = 0; i < fetchGnbIdRows; i++) {
						// 		var sId = "seatingrow" + i;
						// 		$("#dusRows1").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
						// 		for (var j = 1; j <= 25; j++) {
						// 			if (j + i * 25 > fetchGnbIdslength) {
						// 				flag = true;
						// 				break;
						// 			}
						// 			if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
						// 				$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')"  data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
						// 			} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
						// 				$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')"  data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
						// 			} else {
						// 				$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
						// 			}

						// 		}
						// 		if (flag) {
						// 			break;
						// 		}
						// 	}
					} else if (fRValues === "FR2") {
						$('#showHidePageID').show();
						$("#showHidePage3").hide();
						$("#showHidePage4").hide();
						//$("#showHidePage1").show();
						var flag = false;
						for (var i = 0; i < 40; i++) {
							var sId = "seatingrow" + i;
							$("#dusRows1").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							for (var j = 1; j <= 25; j++) {
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId +'\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName + '">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId +'\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName + '">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}

						}
						$("#showHidePage1").show();
						for (var i = 40; i < 80; i++) {
							var sId = "seatingrow" + i;
							$("#dusRows2").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							for (var j = 1; j <= 25; j++) {
								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						$("#showHidePage2").show();
						for (var i = 80; i < 120; i++) {
							var sId = "seatingrow" + i;
							$("#dusRows3").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							for (var j = 1; j <= 25; j++) {

								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')"  data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						$("#showHidePage3").show();
						for (var i = 120; i < 160; i++) {
							var sId = "seatingrow" + i;
							$("#dusRows4").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							for (var j = 1; j <= 25; j++) {

								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')"  data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						$("#showHidePage4").show();
						for (var i = 160; i < 200; i++) {
							var sId = "seatingrow" + i;
							$("#dusRows5").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							for (var j = 1; j <= 25; j++) {

								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')"  data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						$("#showHidePage5").show();
						for (var i = 200; i < 240; i++) {
							var sId = "seatingrow" + i;
							$("#dusRows6").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							for (var j = 1; j <= 25; j++) {

								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')"  data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						$("#showHidePage6").show();
						for (var i = 240; i < 280; i++) {
							var sId = "seatingrow" + i;
							$("#dusRows7").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							for (var j = 1; j <= 25; j++) {

								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')"  data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						$("#showHidePage7").show();
						for (var i = 280; i < 320; i++) {
							var sId = "seatingrow" + i;
							$("#dusRows8").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							for (var j = 1; j <= 25; j++) {

								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')"  data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						$("#showHidePage8").show();
						for (var i = 320; i < 360; i++) {
							var sId = "seatingrow" + i;
							$("#dusRows9").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							for (var j = 1; j <= 25; j++) {

								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')"  data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						$("#showHidePage9").show();
						for (var i = 360; i < 400; i++) {
							var sId = "seatingrow" + i;
							$("#dusRows10").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							for (var j = 1; j <= 25; j++) {

								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')"  data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}

					} else {
						$("#showHidePageID").show();
						$("#showHidePage2").hide();
						$("#showHidePage3").hide();
						$("#showHidePage4").hide();
						tabIndexGnbAtollUpdate == 1 ? $("#showHidePageID").show() : $("#showFiveGPhysicalHidePage").show();
						//$("#showHidePage1").show();
						var flag = false;
						for (var i = 0; i < 40; i++) {
							var sId = tabIndexGnbAtollUpdate == 1 ? "seatingrow" + i: "fiveGPhysicalseatingrow"+ i;
							// $("#dusRows1").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							if (tabIndexGnbAtollUpdate == 1 ) {
							$("#dusRows1").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							} else {
								$("#fiveGPhysicaldusRows1").append('<div class="fiveGPhysicalseatingrow" id="' + sId + '" style="text-align:center"></div>');

							}
							for (var j = 1; j <= 25; j++) {
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}

						}
						tabIndexGnbAtollUpdate == 1 ? $("#showHidePage1").show() : $("#showFiveGPhysicalHidePage1").show();
						for (var i = 40; i < 80; i++) {
							var sId = tabIndexGnbAtollUpdate == 1 ? "seatingrow" + i: "fiveGPhysicalseatingrow"+ i;
							// $("#dusRows1").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							if (tabIndexGnbAtollUpdate == 1 ) {
							$("#dusRows2").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							} else {
								$("#fiveGPhysicaldusRows2").append('<div class="fiveGPhysicalseatingrow" id="' + sId + '" style="text-align:center"></div>');

							}
							for (var j = 1; j <= 25; j++) {
								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName + '">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						tabIndexGnbAtollUpdate == 1 ? $("#showHidePage2").show() : $("#showFiveGPhysicalHidePage2").show();
						for (var i = 80; i < 120; i++) {
							var sId = tabIndexGnbAtollUpdate == 1 ? "seatingrow" + i: "fiveGPhysicalseatingrow"+ i;
							// $("#dusRows1").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							if (tabIndexGnbAtollUpdate == 1 ) {
							$("#dusRows3").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							} else {
								$("#fiveGPhysicaldusRows3").append('<div class="fiveGPhysicalseatingrow" id="' + sId + '" style="text-align:center"></div>');

							}
							for (var j = 1; j <= 25; j++) {
								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')"  data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						tabIndexGnbAtollUpdate == 1 ? $("#showHidePage3").show() : $("#showFiveGPhysicalHidePage3").show();
						for (var i = 120; i < 160; i++) {
							var sId = tabIndexGnbAtollUpdate == 1 ? "seatingrow" + i: "fiveGPhysicalseatingrow"+ i;
							// $("#dusRows1").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							if (tabIndexGnbAtollUpdate == 1 ) {
							$("#dusRows4").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							} else {
								$("#fiveGPhysicaldusRows4").append('<div class="fiveGPhysicalseatingrow" id="' + sId + '" style="text-align:center"></div>');

							}
							for (var j = 1; j <= 25; j++) {
								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')"  data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						tabIndexGnbAtollUpdate == 1 ? $("#showHidePage4").show() : $("#showFiveGPhysicalHidePage4").show();
						for (var i = 160; i < 200; i++) {
							var sId = tabIndexGnbAtollUpdate == 1 ? "seatingrow" + i: "fiveGPhysicalseatingrow"+ i;
							// $("#dusRows1").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							if (tabIndexGnbAtollUpdate == 1 ) {
							$("#dusRows5").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							} else {
								$("#fiveGPhysicaldusRows5").append('<div class="fiveGPhysicalseatingrow" id="' + sId + '" style="text-align:center"></div>');

							}
							for (var j = 1; j <= 25; j++) {
								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip"  onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName + '">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')"  data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						tabIndexGnbAtollUpdate == 1 ? $("#showHidePage5").show() : $("#showFiveGPhysicalHidePage5").show();
						for (var i = 200; i < 240; i++) {
							var sId = tabIndexGnbAtollUpdate == 1 ? "seatingrow" + i: "fiveGPhysicalseatingrow"+ i;
							// $("#dusRows1").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							if (tabIndexGnbAtollUpdate == 1 ) {
							$("#dusRows6").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							} else {
								$("#fiveGPhysicaldusRows6").append('<div class="fiveGPhysicalseatingrow" id="' + sId + '" style="text-align:center"></div>');

							}
							for (var j = 1; j <= 25; j++) {
								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip"  onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName + '">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')"  data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						tabIndexGnbAtollUpdate == 1 ? $("#showHidePage6").show() : $("#showFiveGPhysicalHidePage6").show();
						for (var i = 240; i < 280; i++) {
							var sId = tabIndexGnbAtollUpdate == 1 ? "seatingrow" + i: "fiveGPhysicalseatingrow"+ i;
							// $("#dusRows1").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							if (tabIndexGnbAtollUpdate == 1 ) {
							$("#dusRows7").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							} else {
								$("#fiveGPhysicaldusRows7").append('<div class="fiveGPhysicalseatingrow" id="' + sId + '" style="text-align:center"></div>');

							}
							for (var j = 1; j <= 25; j++) {
								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip"  onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName + '">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')"  data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						tabIndexGnbAtollUpdate == 1 ? $("#showHidePage7").show() : $("#showFiveGPhysicalHidePage7").show();
						for (var i = 280; i < 320; i++) {
							var sId = tabIndexGnbAtollUpdate == 1 ? "seatingrow" + i: "fiveGPhysicalseatingrow"+ i;
							// $("#dusRows1").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							if (tabIndexGnbAtollUpdate == 1 ) {
							$("#dusRows8").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							} else {
								$("#fiveGPhysicaldusRows8").append('<div class="fiveGPhysicalseatingrow" id="' + sId + '" style="text-align:center"></div>');

							}
							for (var j = 1; j <= 25; j++) {
								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip"  onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName + '">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')"  data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						tabIndexGnbAtollUpdate == 1 ? $("#showHidePage8").show() : $("#showFiveGPhysicalHidePage8").show();
						for (var i = 320; i < 360; i++) {
							var sId = tabIndexGnbAtollUpdate == 1 ? "seatingrow" + i: "fiveGPhysicalseatingrow"+ i;
							// $("#dusRows1").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							if (tabIndexGnbAtollUpdate == 1 ) {
							$("#dusRows9").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							} else {
								$("#fiveGPhysicaldusRows9").append('<div class="fiveGPhysicalseatingrow" id="' + sId + '" style="text-align:center"></div>');

							}
							for (var j = 1; j <= 25; j++) {
								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip"  onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName + '">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')"  data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}
						tabIndexGnbAtollUpdate == 1 ? $("#showHidePage9").show() : $("#showFiveGPhysicalHidePage9").show();
						for (var i = 360; i < 400; i++) {
							var sId = tabIndexGnbAtollUpdate == 1 ? "seatingrow" + i: "fiveGPhysicalseatingrow"+ i;
							// $("#dusRows1").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							if (tabIndexGnbAtollUpdate == 1 ) {
							$("#dusRows10").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
							} else {
								$("#fiveGPhysicaldusRows10").append('<div class="fiveGPhysicalseatingrow" id="' + sId + '" style="text-align:center"></div>');

							}
							for (var j = 1; j <= 25; j++) {
								if (j + i * 25 > fetchGnbIdslength) {
									flag = true;
									break;
								}
								if (fetchGnbIds[j - 1 + i * 25].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="showtooltip"  onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')" data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName + '">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else if (fetchGnbIds[j - 1 + i * 25].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="showtooltip" onClick="selectPhysicalDuId(\'' + fetchGnbIds[j - 1 + i * 25].gNBId + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\',\'' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\',\'' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\')"  data-title="SiteName:' + fetchGnbIds[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbIds[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbIds[j - 1 + i * 25].vzSiteInfoId + '\nHub Name: ' + fetchGnbIds[j - 1 + i * 25].cranHubName +'">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');

								} else {
									$("#" + sId).append('<div class="avliable">' + fetchGnbIds[j - 1 + i * 25].gNBId + ' </div>');
								}

							}
							if (flag) {
								break;
							}
						}




					}



				}

				if (fetchGnbIds.length > 1000) {

						const pageFiveGPhysicalContainer = document.getElementById("showFiveGPhysicalHidePage");
						const pageFiveGPhysicalList =  document.getElementById("showFiveGPhysicalHidePageList");

						const totalFiveGPhysicalPages = Math.ceil( fetchGnbIds.length/1000);
						// if (Object.keys(featureToggleMap).includes("F9488") && featureToggleMap['F9488']) {
							pageFiveGPhysicalList.innerHTML = " ";
							const prevfg = document.createElement("li");
							prevfg.className = "page-item";
							prevfg.innerHTML = `<span onclick = "showFiveGPhysicalPrevious()"> &laquo;</span>`;
							pageFiveGPhysicalList.appendChild(prevfg);
							const itemfg = document.createElement("li");
							itemfg.className = "page-item";
							itemfg.id=" showFiveGPhysicalHidePage";
							itemfg.innerHTML = `<span onclick = "showFiveGPhysicalFirst()"> 1</span>`;
							pageFiveGPhysicalList.appendChild(itemfg);
							for(i = 1; i<=totalFiveGPhysicalPages-1 ;i++){
								const lifg = document.createElement("li");
								lifg.className ="page-item";
								lifg.id = "showFiveGPhysicalHidePage"+i;
								lifg.innerHTML = `<span onclick ="goToPage(${i+1},${totalFiveGPhysicalPages})">${i+1}</span>`;
								pageFiveGPhysicalList.appendChild(lifg);
							}
							const nextfg = document.createElement("li");
							nextfg.className ="page-item"
							nextfg.innerHTML =`<span onclick="showFiveGPhysicalNext(})">&raquo</span>`;
							pageFiveGPhysicalList.appendChild(nextfg);



					const pageContainer = document.getElementById("showHidePageID");
					const pageList =  document.getElementById("showHidePageIDList");

					const totalPages = Math.ceil( fetchGnbIds.length/1000);
					if (Object.keys(featureToggleMap).includes("F9488") && featureToggleMap['F9488']) {
						pageList.innerHTML = " ";
						const prev = document.createElement("li");
						prev.className = "page-item";
						prev.innerHTML = `<span onclick = "showPreviousList(${totalPages})"> &laquo;</span>`;
						pageList.appendChild(prev);
						const item = document.createElement("li");
						item.className = "page-item";
						item.id=" showHidePageID";
						item.innerHTML = `<span onclick = "goToPageList(1,${totalPages})"> 1</span>`;
						pageList.appendChild(item);
						for(i = 1; i<=totalPages-1 ;i++){
							const li = document.createElement("li");
							li.className ="page-item";
							li.id = "showHidePage"+i;
							li.innerHTML = `<span onclick ="goToPageList(${i+1},${totalPages})">${i+1}</span>`;
							pageList.appendChild(li);
						}
						const next = document.createElement("li");
						next.className ="page-item"
						next.innerHTML =`<span onclick="showNextList(${totalPages})">&raquo</span>`;
						pageList.appendChild(next);
					}else{
						pageContainer.style.display ="block";
						pageList.innerHTML = `
						<li class="page-item">

							<span aria-hidden="true" onclick=' showPrevious();'>&laquo;</span>
							<span class="sr-only">Previous</span>

						</li>
						<li class="page-item" id="showHidePageID"><span onclick='showFirst();'>1</span></li>
						<li class="page-item" id="showHidePage1"><span onclick='showSecond();'>2</span></li>
						<li class="page-item" id="showHidePage2"><span onclick='showThird();'>3</span></li>
						<li class="page-item" id="showHidePage3"><span onclick='showFourth();'>4</span></li>
						<li class="page-item" id="showHidePage4"><span onclick='showFifth();'>5</span></li>
						<li class="page-item">

							<span aria-hidden="true" onclick='showNext();'>&raquo;</span>
							<span class="sr-only">Next</span>

						</li>`;
					// $('#showHidePageID').show();
					}
																						}
													else{
					const pageFiveGPhysicalContainer = document.getElementById("showFiveGPhysicalHidePage");
					const pageFiveGPhysicalList =  document.getElementById("showFiveGPhysicalHidePageList");

					pageFiveGPhysicalContainer.style.display ="block";
					pageFiveGPhysicalList.innerHTML = `
						<li class="page-item">

									<span aria-hidden="true" onclick=' showFiveGPhysicalPrevious();'>&laquo;</span>
									<span class="sr-only">Previous</span>

								</li>
								<li class="page-item" id="showFiveGPhysicalHidePage"><span
										onclick='showFiveGPhysicalFirst();'>1</span></li>
								<li class="page-item" id="showFiveGPhysicalHidePage1"><span
										onclick='showFiveGPhysicalSecond();'>2</span></li>
								<li class="page-item" id="showFiveGPhysicalHidePage2"><span
										onclick='showFiveGPhysicalThird();'>3</span></li>
								<li class="page-item" id="showFiveGPhysicalHidePage3"><span
										onclick='showFiveGPhysicalFourth();'>4</span></li>
								<li class="page-item" id="showFiveGPhysicalHidePage4"><span
										onclick='showFiveGPhysicalFifth();'>5</span></li>
						<li class="page-item">

									<span aria-hidden="true" onclick='showFiveGPhysicalNext();'>&raquo;</span>
									<span class="sr-only">Next</span>

								</li> `;
					// $('#showHidePageID').show();
					}


			},
			error: function(data) {
				$('#loading').fadeOut();
				if(($("#atollUpdateRightSiteVersion").val())==null){
					$('#physicalTabView').hide()
					alert('Kindly select at least one Site Version');

				}else{
				aptAlert('error', 'failed');
				}
			}
		})

		$("#showFiveGphysicalduids").hide();

		if(tabIndexGnbAtollUpdate == 1) {
		$("#dusRows2").hide();
		$("#dusRows3").hide();
		$("#dusRows4").hide();
		$("#dusRows5").hide();
		$("#dusRows6").hide();
		$("#dusRows7").hide();
		$("#dusRows8").hide();
		$("#dusRows9").hide();
		$("#dusRows10").hide();
		} else {
			$("#fiveGPhysicaldusRows2").hide();
			$("#fiveGPhysicaldusRows3").hide();
			$("#fiveGPhysicaldusRows4").hide();
			$("#fiveGPhysicaldusRows5").hide();
			$("#fiveGPhysicaldusRows6").hide();
			$("#fiveGPhysicaldusRows7").hide();
			$("#fiveGPhysicaldusRows8").hide();
			$("#fiveGPhysicaldusRows9").hide();
			$("#fiveGPhysicaldusRows10").hide();
		}



	}
	else {
		$("#AssignmentDrillView").hide();
		$('.pageCriteria').show();
		assignmentEmptyTable("#assignmentGrid", assignmentDataSource, assignmentGridColumns);
		//assignmentEmptyTable();
		document.getElementById("PhysicalCheckbox").checked = false;
	}
}
var excelData = [];
function assignmentGnodebData() {
	$("#loading").show();
	$("#assignmentGrid").show();
	$("#showphysicalduids").hide();
	// physicalGnbSectorViewData='';
	gnbvirtualDuIds='';
	fetchGnbIdRows='';
	vendorVal = $("#avendorDropdown").val();
	if (vendorVal == 'Select') {
		vendorVal = '';
	} else {
		vendorVal = $("#avendorDropdown").val();
	}
	if (vendorVal == null) {
		vendorVal = '';
	}
	if (indexOfTabs == 1 && ParentIndex == 1)
		uniqGnbAssignmentTextId = document.getElementById('eNodebIdSelect').value;
	uniqGnbValidationTextId = '';
	if ((gnbAssignTerritoryList == undefined) || (gnbAssignRegionList == undefined) || (gnbAssignRegionList == "") || (!gnbAssignRegionList) || (marketsSelected == '') || (!marketsSelected) || (gnbAssignAreaList == undefined) || ($('#siteVersionDropdownId').val() == '') || ($('#siteVersionDropdownId').val() == undefined)) {
		alert("Please Select All the Mandatory Dropdowns");
		$('#loading').hide();
	} else {
					if ((marketsSelected && marketsSelected.length != 0) && document.getElementById("PhysicalCheckbox").checked ) {
				$('#assignmentGrid').hide();
				$('#gNBViewDetails').hide();
				$("#AssignmentDrillView").show();

				if ((Object.keys(featureToggleMap).includes("F93111") && featureToggleMap['F93111']) || vendorVal == 'Ericsson' ){
					//if ((F93111) || vendorVal == 'Ericsson' ){
					loadGnbIdsDrillView();
					}
				$('#loading').hide();

			}
		else {

			$('#assignmentGridToolbar').show();
			$('#assignmentGrid').show();
			$('#gNBViewDetails').show();
			$("#AssignmentDrillView").hide();
			$("#showVirtualDuIdss").hide();
			$("#phyGnbView").hide();
			$('#virtualGnbView').hide();
			var gnodePayload = {
				"marketName": marketsSelected,
				"vzGnodebId": uniqGnbAssignmentTextId,
				"vendor": vendorVal,
				"siteVersions": siteVersions
			};
			$.ajax({
				type: 'POST',
				async: false,
				//url: "http://localhost:8100/npp-atoll-services/enbgnbAssignment/fetchGnbData",
				url: enbgnbAssignmentUrl,
				dataType: 'json',
				contentType: 'application/json; charset=UTF-8',
				cache: false,
				data: JSON.stringify(gnodePayload),
				headers: {
					'Accept': 'application/json, text/plain, */*',
					'Content-Type': 'application/json'
				},
				success: function(data) {
					assignmentData = data;
					excelData = data;

					setTimeout(function() {
						assignmentEmptyTable("#assignmentGrid", assignmentData, assignmentGridColumns)
						/* $('#assignmentGrid')
							.getKendoGrid()
							.setDataSource(
								new kendo.data.DataSource({
									pageSize: 25,
									data: assignmentData,
								})
							); */
					}, 1000);

					$('#loading').fadeOut();
				},
				error: function(data) {
					$('#loading').fadeOut();
					aptAlert('error', 'failed');
				}
			});
		}
	}
}

$("#avendorDropdown").change(function() {
	let e = document.getElementById("avendorDropdown");
	getSelectedValue = e.options[e.selectedIndex].value;

	if(Object.keys(featureToggleMap).includes("F93111") && featureToggleMap['F93111']){
		document.getElementById("PhysicalCheckbox").disabled = false;
	}

	if ((getSelectedValue === "Ericsson" || getSelectedValue === "ERC" || getSelectedValue === "ERICSSON")) {

		if(!(Object.keys(featureToggleMap).includes("F93111") && featureToggleMap['F93111'])){
			document.getElementById("PhysicalCheckbox").checked = true;
		}

		//document.getElementById("PhysicalCheckbox").checked = true;
		fRValues = "";
		$("#fr1Fr2Db").multiselect("destroy");
		$.each(fr1Fr2DropdownList, function(index, value) {
			$("#fr1Fr2Db").append($("<option></option>").val(value).html(value));
			// $('#fr1Fr2Db').append("<option value='" + value + "'>" + value + "</option>");
		});

		$("#fr1Fr2Db").multiselect({
			includeSelectAllOption: true,
			enableFiltering: true,
			numberDisplayed: 1,
			enableCaseInsensitiveFiltering: true,
			buttonClass: 'btn btn-default whitebg btn-sm',
			nonSelectedText: 'None selected'
		});
		$("#fr1Fr2Db").multiselect("enable");
		$("#eNodebIdSelect").prop('disabled', true);
		document.getElementById('eNodebIdSelect').value = '';
	} else {
		document.getElementById("PhysicalCheckbox").checked = false;
		clearAssignmentDropdowns("#fr1Fr2Db");
		$("#fr1Fr2Db").multiselect('disable');
		$("#eNodebIdSelect").prop('disabled', false);
	}

});

function clearAssignmentDropdowns(dropDownId) {
	$(dropDownId).html('');
	$(dropDownId).multiselect('destroy');
	$(dropDownId).multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		numberDisplayed: 1,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
	});
	document.getElementById("PhysicalCheckbox").checked = false;
}
function clearValidationDropdowns(validationDb) {
	$(validationDb).html('');
	$(validationDb).multiselect('destroy');
	$(validationDb).multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		numberDisplayed: 1,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
	});
}
function resetValidation() {
	excelDatagnbValidation='';
		onChangeFlag = false;
		fetchAOR(userID);
}

function dynamicallyPopulateAssignmentData(tabIndex) {
	if (tabIndex == "1") {
		indexOfTabs = 1;
			//			$("#assignmentGridToolbar").show();
			//			$("#validationGridToolbar").hide();
			//			$("#enodeValidationToolbar").hide();
			//			$("#fiveGVirtualGridToolbar").hide();
			$("#exportToExcelEnbAssignmentTab").hide();
			$("#exportToExcelLte").hide();
		if (gNodeBSelected) {
			gNodeBAssignment = true;
			eNodeBAssignment = false;
			eNodeBValidation = false;
			gNodeBValidation = false;
		} else {
			gNodeBAssignment = false;
			eNodeBAssignment = true;
			eNodeBValidation = false;
			gNodeBValidation = false;
		}
		$("#showHideFr1Fr2Db").show();
		$('#enbAssignmentSectorViewGrid').hide();
		$('#showphysicalduids').hide();
		$("#configurationViewGrid").hide();
		$("#refreshSaveBtn").hide();
		$("#enodeValidationToolbar").hide();


		getIndex = tabIndex;
		activeAtollTabIndex = tabIndex;
		$("#validationViewGrid").hide();
		$("#showValid").hide();
		$('#showHideFr1Fr2Db').hide();
		$('#assignmentGrid').show();
		$('#validationViewGrid').hide();

		// if (!virtualDuIds || (virtualDuIds.length == 0)) {
		// 	$('#AssignmentDrillView').hide();
		// 	$('#showVirtualDuIdss').hide();
		// } else {
		// 	$('#AssignmentDrillView').show();
		// 	$('#showVirtualDuIdss').show();
		// }
		if(gnbvirtualDuIds){
			$('#AssignmentDrillView').show();
			$('#showVirtualDuIdss').show();
		}

		if (gNodeBSelected && gNodeBAssignment) {
			$('#assignmentGrid').show();
			$('#assignmentGridToolbar').show();
			$("#validationGridToolbar").hide();
			$("#enodeValidationToolbar").hide();
			$('#validationViewGrid').hide();
			$('#enodeAssignmentGrid').hide();
			$('#enodeValidationViewGrid').hide();
			$("#PhysicalCheckbox").show();
			$('#physicalCheckboxid').show();
			$('#showHideFr1Fr2Db').show();

		}
		if (fetchPhyGnbs.length == 0) {
			// $("#AssignmentDrillView").hide();
			$('#assignmentGridToolbar').show();
			$('#assignmentGrid').show();
			$('#gNBViewDetails').show();
			$("#sectorResults").hide();
			// if(fetchGnbDUNumbers){
			// 	$("#AssignmentDrillView").show();
			// }
		} else if ((fetchPhyGnbs.length > 0) && (vendorVal == 'Ericsson')) {
			$("#AssignmentDrillView").show();
			$('#assignmentGrid').hide();
			$('#assignmentGridToolbar').hide();
			$('#gNBViewDetails').hide();
			$('#showVirtualDuIdss').hide();
			if(fetchGnbIdRows){
				$("#showphysicalduids").show();
				$('#physicalSectorExportToExcel').show();
			}
		} else if (vendorVal == 'Ericsson') {
			$('#assignmentGrid').hide();
			$('#assignmentGridToolbar').hide();
			$('#showVirtualDuIdss').hide();
		}
		if (eNodeBSelected && eNodeBAssignment) {
			$('#assignmentGrid').hide();
			$('#AssignmentDrillView').hide();
			$('#showVirtualDuIdss').hide();
			$('#validationGridToolbar').hide();
			$('#validationGridToolbar').hide();
			$("#assignmentGridToolbar").hide();
			$('#validationViewGrid').hide();
			$('#enodeAssignmentGrid').show();
			$('#enbAssignmentGridToolbar').show();
			$("#showphysicalduids").hide();

			if (resultVal) {

						$("#exportToExcelEnbAssignmentTab").show();
					$('#marketTabs').show();
					if(drilldata){
							$('#sectorResults').show();
						$('#enbAssignmentSectorViewGrid').show();
						$('#eNodeBDrillView').show();
					}

				$('#enodeAssignmentGrid').hide();
			}
			if (uniqEnbAssignmentTextId) {
				$('#eNodeBDrillView').show();
				$('#marketTabs').hide();
				$('#enodeAssignmentGrid').show();
				$('#enbAssignmentGridToolbar').show();
			}
			$('#enodeValidationViewGrid').hide();
			$("#enodeValidationToolbar").hide();
		}
		$("#enbValidationInfo").hide();
		$("#gnbValidationInfo").hide();

	}
	else if (tabIndex == "2") {
		indexOfTabs = 2;
		$("#exportToExcelEnbAssignmentTab").hide();
		$("#exportToExcelLte").hide();
		//		}

		if (eNodeBSelected) {
			eNodeBValidation = true;
			gNodeBValidation = false;
			gNodeBAssignment = false;
			eNodeBAssignment = false;
		} else {
			eNodeBValidation = false;
			gNodeBValidation = true;
			gNodeBAssignment = false;
			eNodeBAssignment = false;
		}
		if (!returnedData) {
			validationEmptyTable();
		}
		getIndex = tabIndex;
		$("#showValid").show();
		$("#PhysicalCheckbox").hide();
		$('#physicalCheckboxid').hide();
		$('#validationViewGrid').show();
		$("#showHideFr1Fr2Db").hide();
		$('#enbAssignmentSectorViewGrid').hide();
		$("#configurationViewGrid").hide();
		$("#refreshSaveBtn").hide();
		if (gNodeBSelected && gNodeBValidation) {
			$('#assignmentGrid').hide();
			$('#AssignmentDrillView').hide();
			$('#showVirtualDuIdss').hide();
			$('#validationViewGrid').show();
			$("#enbValidationInfo").hide();
			$('#showphysicalduids').hide();

				$("#gnbValidationInfo").show();

				$('#validationGridToolbar').show();
			$("#assignmentGridToolbar").hide();
			$("#enodeValidationToolbar").hide();
			$('#enodeAssignmentGrid').hide();
			$('#enodeValidationViewGrid').hide();
		}
		if (eNodeBSelected && eNodeBValidation) {
			$('#assignmentGrid').hide();
			$('#AssignmentDrillView').hide();
			$('#showVirtualDuIdss').hide();
			$('#validationViewGrid').hide();
			$('#enodeAssignmentGrid').hide();
			$('#sectorResults').hide();
			$('#enodeValidationViewGrid').show();

			$("#enbValidationInfo").show();

			$("#gnbValidationInfo").hide();
			$('#enodeValidationToolbar').show();
			$("#assignmentGridToolbar").hide();
			$("#validationGridToolbar").hide();
			$('#marketTabs').hide();
			$('#eNodeBDrillView').hide();
			$("#sectorResults").hide();
			if (!enodeBValidationResData) {
				enodeValidationEmptyTable();
			}
		}
		$('#validInvalidDropdown').multiselect('deselectAll', false);
		$("#validInvalidDropdown").multiselect('refresh');
		if (selectedValidityFlagEnodeB && eNodeBValidation) {
			for (var i in selectedValidityFlagEnodeB) {
				$('#validInvalidDropdown').multiselect('select', selectedValidityFlagEnodeB[i]);
			}
		}
		if (selectedValidityFlag && gNodeBValidation) {
			for (var i in selectedValidityFlag) {
				$('#validInvalidDropdown').multiselect('select', selectedValidityFlag[i]);
			}
		}
	}
}
$('#validInvalidDropdown').change(function() {
	if (indexOfTabs == 2 && ParentIndex == 1) {
		selectedValidityFlag = $('#validInvalidDropdown').val();
	} else if (indexOfTabs == 2 && ParentIndex == 2) {
		selectedValidityFlagEnodeB = $('#validInvalidDropdown').val();
	}
})

$('#siteVersionDropdownId').change(function () {

	siteVersions = $('#siteVersionDropdownId').val();

})
function assignmentEmptyTable(id, dataSource, columns) {
	if (kendoGridFirstTimeLoad) {
		kendoGridFirstTimeLoad = false;
		dataSource = '';
	} else {
		$(id).empty();
	}
	$(id).kendoGrid({
		dataSource: dataSource,
		columns: columns,
		sortable: true,
		filterable: {
			extra: false,
			operators: {
				string: {
					startswith: "Starts with",
					eq: "Is equal to",
					neq: "Is not equal to"
				}
			}
		},
		pageable: {
			pageSize: 25,
			input: true,
			numeric: false,
			pageSizes: [25, 50, 75, 100, 150, 200, "All"]

		},
		change: function() {

		},
		dataBound: function(e) {

		},
		noRecords: {
			template: "<div style='font-size:12px;color:red'>No data available</div>"
		},

	});
	grid1 = $(id).data("kendoGrid");
}

function validationEmptyTable() {
	$("#loading").hide();
	validationDataSource='';
	$("#validationViewGrid").kendoGrid({
		dataSource: validationDataSource,
		columns: validationGridColumns,
		sortable: true,
		resizable: true,
		filterable: {
			extra: false,
			operators: {
				string: {
					startswith: "Starts with",
					eq: "Is equal to",
					neq: "Is not equal to"
				}
			}
		},
		pageable: {
			pageSizes: 5,
			input: true,
			numeric: false,
			pageSizes: [25, 50, 75, 100, 150, 200, "All"]

		},
		change: function() {

		},
		dataBound: function(e) {
			var rows = e.sender.tbody.children();
			console.log('rows', rows);
				for (var j = 0; j < rows.length; j++) {
					var row = $(rows[j]);
					var dataItem = e.sender.dataItem(row);
					var validmmWBWFlag = dataItem.get("validmmWBW");
					var gNBDUBuiltInSwitchFlag = dataItem.get("gNBDUBuiltInSwitch");
					var builtInSwitchFlag = dataItem.get("builtInSwitch");
					var validGNBMarketNumberFlag = dataItem.get("validGNBMarketNumber");
					var validGNBMiddleNumberFlag = dataItem.get("validGNBMiddleNumber");
					var validGNBLengthFlag = dataItem.get("validGNBLength");
					var validDUIdLengthFlag = dataItem.get("validDUIdLength");
					var validFirstDUNumberFlag = dataItem.get("validFirstDUNumber");
					var validNumericgNBDUIDandSectorFlag = dataItem.get("validNumericgNBDUIDandSector");


					if (validmmWBWFlag == "No") {
						row[0].cells[11].style.border = "1px solid red";
					}
					if (validGNBMarketNumberFlag == "No") {
						row[0].cells[13].style.border = "1px solid red";
					}
					if (validGNBMiddleNumberFlag == "No") {
						row[0].cells[14].style.border = "1px solid red";
					}
					if (validGNBLengthFlag == "No") {
						row[0].cells[15].style.border = "1px solid red";
					}
					if (validDUIdLengthFlag == "No") {
						row[0].cells[16].style.border = "1px solid red";
					}
					if (validFirstDUNumberFlag == "No") {
						row[0].cells[17].style.border = "1px solid red";
					}
					if (validNumericgNBDUIDandSectorFlag == "No") {
						row[0].cells[18].style.border = "1px solid red";
					}
					if (dataItem.get("vzEnodebVendor") == "Samsung" && dataItem.get("siteVersion") == "0000") {
						if (builtInSwitchFlag != "USM") {
							row[0].cells[12].style.border = "1px solid red";
						}
						if (gNBDUBuiltInSwitchFlag != "USM") {
							row[0].cells[20].style.border = "1px solid red";
						}
					}
					if (dataItem.get("vzEnodebVendor") == "Nokia" && dataItem.get("siteVersion") == "0000") {
						if (builtInSwitchFlag != "NSP") {
							row[0].cells[12].style.border = "1px solid red";
						}
						if (gNBDUBuiltInSwitchFlag != "NSP") {
							row[0].cells[20].style.border = "1px solid red";
						}
					}
					if (dataItem.get("vzEnodebVendor") == "Ericsson" && dataItem.get("siteVersion") == "0000") {
						if (builtInSwitchFlag != "ENM") {
							row[0].cells[12].style.border = "1px solid red";
						}
						if (gNBDUBuiltInSwitchFlag != "ENM") {
							row[0].cells[20].style.border = "1px solid red";
						}
					}
				}
		},
		noRecords: {
			template: "<div style='font-size:12px;color:red'>No data available</div>"
		},

	});
	grid2 = $("#validationViewGrid").data("kendoGrid");
}

function enodeAssignmentEmptyTable(id, data, columns) {

	$(id).kendoGrid({
		dataSource: data,
		columns: columns,
		sortable: true,
		filterable: {
			extra: false,
			operators: {
				string: {
					startswith: "Starts with",
					eq: "Is equal to",
					neq: "Is not equal to"
				}
			}
		},
		pageable: {
			pageSizes: 5,
			input: true,
			numeric: false,
			pageSizes: [25, 50, 75, 100, 150, 200, "All"]

		},
		change: function() {
		},
		dataBound: function(e) {

		},
		noRecords: {
			template: "<div style='font-size:12px;color:red'>No data available</div>"
		},

	});
	grid1 = $(id).data("kendoGrid");
}

function enodeValidationEmptyTable() {
	$("#enbsectorResultsexportToExcel").hide();
	$("#enodeValidationViewGrid").kendoGrid({
		dataSource: enodeValidationDataSource,
		columns: enodeValidationGridColumns,
		sortable: true,
		resizable: true,
		filterable: {
			extra: false,
			operators: {
				string: {
					startswith: "Starts with",
					eq: "Is equal to",
					neq: "Is not equal to"
				}
			}
		},
		pageable: {
			pageSizes: 5,
			input: true,
			numeric: false,
			pageSizes: [25, 50, 75, 100, 150, 200, "All"]

		},
		dataBound: function(e) {
			var rows = e.sender.tbody.children();
			console.log('rows', rows);
			for (var j = 0; j < rows.length; j++) {
				var row = $(rows[j]);
				var dataItem = e.sender.dataItem(row);
				var builtInSwitchFlag = dataItem.get("builtInSwitch");
				var valideNBSectorCarrierBuiltinUSMNSPENMFlag = dataItem.get("builtInSwitch");
				var	validENBLengthFlag = dataItem.get("validENBLength");
				var	validENBNumberFlag = dataItem.get("validENBNumber");
				var	validEnbSectorLengthFlag = dataItem.get("validEnbSectorLength");
				var	validEnbSectorNumberFlag = dataItem.get("validEnbSectorNumber");
				if((Object.keys(featureToggleMap).includes("F89366") && featureToggleMap['F89366'])) {
					if (dataItem.get("vendor") == "Samsung" && dataItem.get("siteVersion") == "0000" &&  valideNBSectorCarrierBuiltinUSMNSPENMFlag != "USM") {
						{
							row[0].cells[8].style.border = "1px solid red";
						}
					}
					if (dataItem.get("vendor") == "Nokia" && dataItem.get("siteVersion") == "0000" &&  valideNBSectorCarrierBuiltinUSMNSPENMFlag != "NSP") {
						{
							row[0].cells[8].style.border = "1px solid red";
						}
					}
					if (dataItem.get("vendor") == "Ericsson" && dataItem.get("siteVersion") == "0000" && valideNBSectorCarrierBuiltinUSMNSPENMFlag != "ENM") {
						{
							row[0].cells[8].style.border = "1px solid red";
						}
					}
			    }
				else{
					if( builtInSwitchFlag == "No")
						{
						row[0].cells[8].style.border = "1px solid red";
						}
				}
				if (validENBLengthFlag == "No") {
					row[0].cells[9].style.border = "1px solid red";
				}
				if (validENBNumberFlag == "No") {
					row[0].cells[10].style.border = "1px solid red";
				}
				if (validEnbSectorLengthFlag == "No") {
					row[0].cells[11].style.border = "1px solid red";
				}
				if (validEnbSectorNumberFlag == "No") {
					row[0].cells[12].style.border = "1px solid red";
				}
			}
		},
		noRecords: {
			template: "<div style='font-size:12px;color:red'>No data available</div>"
		},

	});
	grid2 = $("#enodeValidationViewGrid").data("kendoGrid");
}
function validationGnodeData() {
	$(".btn-group").removeClass('open');
	$("#validationViewGrid").show();
	var gnodeb = '';
	var validityFlag = [];
	uniqGnbValidationTextId = document.getElementById('eNodebIdSelect').value;
	uniqGnbAssignmentTextId = '';
	if ((gnbAssignTerritoryList == undefined) || (gnbAssignRegionList == undefined) || (gnbAssignRegionList == "") || (!gnbAssignRegionList) || (marketsSelected == '') || (!marketsSelected) || (gnbAssignAreaList == undefined) || ($('#siteVersionDropdownId').val() == '') || ($('#siteVersionDropdownId').val() == undefined)) {
		alert("Please Select All the Mandatory Dropdowns");
		$('#loading').hide();
	}

	// if ((gnbValidTerritoryList == undefined) || (gnbValidRegionList == undefined) || (validationMarket== undefined) || (validationMarket== "") || (gnbValidAreaList == undefined)) {
	// 	alert("Please Select All the Mandatory Dropdowns");
	// 	$('#loading').hide();
	// }

	vVendorVal = $("#avendorDropdown").val();

	if (vVendorVal == 'Select') {
		vVendorVal = '';
	} else {
		vVendorVal = $("#avendorDropdown").val();
	}

	if ($("#validInvalidDropdown").val() != null) {
		validityFlag = $("#validInvalidDropdown").val();
	}
	if ($("#vENodebIdSelect").val()) {
		gnodeb = $("#vENodebIdSelect").val();
	}
	if ($("#validInvalidDropdown").val()) {
		validityFlag = $("#validInvalidDropdown").val();
	}

	var gnodePayload = {
		"marketName": marketsSelected, // validationMarket.join(','),
		"vzGnodebId": uniqGnbValidationTextId,
		"validationFlag": validityFlag,
		"vendor": vVendorVal,
		"siteVersions":siteVersions
	};
	$('#loading').show();
	$.ajax({
		type: 'POST',
		async: false,
		//url: "http://localhost:8100/npp-atoll-services/enbgnbAssignment/validateGNBs",
		url: enbgnbValidationUrl,
		dataType: 'json',
		contentType: 'application/json; charset=UTF-8',
		cache: false,
		data: JSON.stringify(gnodePayload),
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function(data) {

			returnedData = data;
			excelDatagnbValidation = data;
			if (returnedData.length < 1) {

				validationEmptyTable();
				$('#loading').fadeOut();
				return;
			}
			validationData = data;
			if(validationData.length>0){
				setTimeout(function() {
					$('#validationViewGrid')
						.getKendoGrid()
						.setDataSource(
							new kendo.data.DataSource({
								pageSize: 25,
								data: validationData,
							})
						);

				}, 1000);
			}else{
				validationEmptyTable();
				$('#loading').fadeOut();
			}

			$('#loading').fadeOut();
			$('#assignmentGrid').hide();
		},
		error: function(data) {
			$('#loading').fadeOut();
			aptAlert('error', 'failed');
		}
	});
}
function assignmentResetValues() {
	assignmentDataSource = '';
	fetchGnbDUNumbers='';
	fetchPhyGnbs='';
	gnbvirtualDuIds='';
	excelData='';

		assignmentEmptyTable("#assignmentGrid", assignmentDataSource, assignmentGridColumns);
		$("#AssignmentDrillView").hide();
		$("#showphysicalduids").hide();
		$("#showVirtualDuIdss").hide();

		onChangeFlag = false;
		fetchAOR(userID);
        fetchGnbDUNumbers ="";
		virtualDuIds ="";
		$("#fr1Fr2Db").multiselect('disable');
		$("#eNodebIdSelect").val('');
		document.getElementById("PhysicalCheckbox").checked = false;
		// $("#assignmentGrid").show();
		$("#AssignmentDrillView").hide();
		$("#showphysicalduids").hide();
		$("#showVirtualDuIdss").hide();
		$("#eNodebIdSelect").prop('disabled', false);
		assignmentDataSource = '';
		assignmentEmptyTable("#assignmentGrid", assignmentDataSource, assignmentGridColumns);
		//assignmentEmptyTable();
		$('#assignmentGrid').show();
		$('#validationViewGrid').hide();
		$('#enodeAssignmentGrid').hide();
		$('#enodeValidationViewGrid').hide();
		$('#assignmentGridToolbar').show();
		$("#AssignmentDrillView").hide();


}

function clearAllDropdown() {
	gnbAssignTerritoryList = '';
	gnbAssignRegionList = '';
	marketsSelected = '';
	gnbAssignAreaList == '';
	getSelectedValue = '';
	vendorVal = '';

	// clearAssignmentDropdowns('#territoryDropdown');

	// clearAssignmentDropdowns('#territoryDropdown');
	$('#territoryDropdown').multiselect('deselectAll', false);
	$("#territoryDropdown").multiselect('refresh');
	clearAssignmentDropdowns('#areaDropdown');
	clearAssignmentDropdowns('#regionDropdown');
	clearAssignmentDropdowns('#marketDropdown');
	clearAssignmentDropdowns('#avendorDropdown');
	clearAssignmentDropdowns("#fr1Fr2Db");
}
var virtualFiveGData;
$(document).on('click', '.anchorNavLinkStyle', function(e) {
if ((Object.keys(featureToggleMap).includes("F90277") && featureToggleMap['F90277'])) {
	document.querySelectorAll("#AssignmentDrillView").forEach(el => el.className = "geohierarchydiv1");
	document.querySelectorAll("#errisonHead").forEach(el => el.className = "geohierarchydiv");
	document.querySelectorAll("#fiveHeader").forEach(el => el.className = "geohierarchydiv");
	 document.querySelectorAll("#dusMarketRows1").forEach(el => el.className = "geohierarchydiv");
    document.querySelectorAll("#showVirtualDuIdss").forEach(el => el.className = "geohierarchydiv");
	 document.querySelectorAll("#fiveGVirtualDuIdss").forEach(el => el.className = "geohierarchydiv");
	 document.querySelectorAll("#fiveGVirtualView").forEach(el => el.className = "geohierarchydiv");
	 document.querySelectorAll("#fiveGdusRows1").forEach(el => el.className = "geohierarchydiv");
	 document.querySelectorAll("#fiveGdusRows2").forEach(el => el.className = "geohierarchydiv");
	} else {
		document.querySelectorAll("#errisonHead").forEach(el => el.removeClass = "geohierarchydiv");
		document.querySelectorAll("#AssignmentDrillView").forEach(el => el.removeClass = "geohierarchydiv1");
			 document.querySelectorAll("#dusMarketRows1").forEach(el => el.removeClass = "geohierarchydiv");
	}

	if (tabIndexGnbAtollUpdate == 1) {
	for (var duPage = 1; document.getElementById("dusRows" + duPage); duPage++) {
		document.getElementById("dusRows" + duPage).outerHTML = "<div class='containerseating' id='dusRows" + duPage + "'></div>";
	}
		// $('#showVirtualDuIdss').show();
	} else {
		for (var fiveGPage = 1; document.getElementById("fiveGdusRows" + fiveGPage); fiveGPage++) {
			document.getElementById("fiveGdusRows" + fiveGPage).outerHTML = "<div class='containerseatingFivegVirtual' id='fiveGdusRows" + fiveGPage + "'></div>";
		}
	}
	var $clickedRow = $(this).closest("tr[data-uid]");
	var $gridElement = $clickedRow.closest(".k-grid");
	var grid = $gridElement.length ? $gridElement.data("kendoGrid") : null;
	if (!grid) {
		grid = tabIndexGnbAtollUpdate == 1 ? $("#assignmentGrid").data("kendoGrid") : $("#assignFiveGVirtualGrid").data("kendoGrid");
	}
	if (!grid || !$clickedRow.length) {
		console.error("gNB link click ignored: grid or row not found", { tabIndexGnbAtollUpdate: tabIndexGnbAtollUpdate });
		return;
	}
	var dataItem = grid.dataItem($clickedRow);
	if (!dataItem) {
		console.error("gNB link click ignored: row has no bound data item", { tabIndexGnbAtollUpdate: tabIndexGnbAtollUpdate });
		return;
	}
	// virtualGnbData = dataItem;
	tabIndexGnbAtollUpdate==1?virtualGnbData= dataItem:virtualFiveGData = dataItem;
	$("#virtualGnbView").show();
	$("#phyGnbView").hide();
	document.getElementById(tabIndexGnbAtollUpdate == 1? "vzGnodebId": "fiveGvzGnodebId").innerHTML = dataItem.vzGnodebId;
	document.getElementById(tabIndexGnbAtollUpdate == 1?"vzEnodebVendor": "fiveGvzEnodebVendor").innerHTML = dataItem.vzEnodebVendor;
	document.getElementById(tabIndexGnbAtollUpdate == 1?"vzMarket":"fiveGvzMarket").innerHTML = dataItem.market;
	document.getElementById(tabIndexGnbAtollUpdate == 1?"vzvCU": "fiveGvzvCU").innerHTML = dataItem.vCU;
	document.getElementById(tabIndexGnbAtollUpdate == 1?"vzAdu": "fiveGvzAdu").innerHTML = dataItem.assignedDUCountgNB;
	document.getElementById(tabIndexGnbAtollUpdate == 1?"vzAcu":"fiveGvzAcu").innerHTML = dataItem.assignedDUCountVCU;
	document.getElementById(tabIndexGnbAtollUpdate == 1?"Acu": "fiveGAcu").innerHTML = dataItem.assignedCellCountgNB;
	document.getElementById(tabIndexGnbAtollUpdate == 1?"vzAcc":"fiveGvzAcc").innerHTML = dataItem.assignedCellCountVCU;
	document.getElementById(tabIndexGnbAtollUpdate == 1?"vzAccg":"fiveGvzAccg").innerHTML = dataItem.availableCellCountgNB;
	document.getElementById(tabIndexGnbAtollUpdate == 1?"vzAccV":"fiveGvzAccV").innerHTML = dataItem.availableCellCountVCU;
	document.getElementById(tabIndexGnbAtollUpdate == 1?"vzFr1":"fiveGvzFr1").innerHTML = dataItem.fR1;
	document.getElementById(tabIndexGnbAtollUpdate == 1?"vzFr2":"fiveGvzFr2").innerHTML = dataItem.fR2;
	enodeInnerHtml = dataItem.vzGnodebId;
	vzEnodebVendorHtml = dataItem.vzEnodebVendor;
	dataFr2 = dataItem.fR2;

	if (tabIndexGnbAtollUpdate == 1) {
	var gnodePayload = {
		"marketName": marketsSelected,
		"vzGnodebId": dataItem.vzGnodebId,
		"vendor": dataItem.vzEnodebVendor,
		"fR2": dataItem.fR2,
		"siteVersions": siteVersions,
	};
		virtualDrillDown(dataItem.vzGnodebId);
	} else {
		var atollVendor = dataItem.vzEnodebVendor || vzEnodebVendorHtml || "";
		var atollFr2 = dataItem.fR2 || dataFr2 || "";
		var gnodePayload = {
			atollSchema: sechmaList,
			marketName: marketIdOrName,
			vzGnodebId: dataItem.vzGnodebId,
			vendor: atollVendor,
			fR2: atollFr2,
			"siteVersions": $("#atollUpdateRightSiteVersion").val(),

		};
		virtualDrillDown(dataItem.vzGnodebId);
	}

	$.ajax({
		type: 'POST',
		async: false,
		//url: "http://localhost:8100/npp-atoll-services/enbgnbAssignment/fetchGnbDUNumberDetails",
		url: fetchGnbDUNumberUrl,
		dataType: 'json',
		contentType: 'application/json; charset=UTF-8',
		cache: false,
		data: JSON.stringify(gnodePayload),
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function(data) {
		console.log('fetchGnbDUNumberDetails response', data);
		// FIX: Hide 5G Virtual DU pagination wrappers if no data is returned
                if (!data || data.length === 0) {
                         $("#showHidePageID").hide();
                         $("#showHidePage").hide();
                         $("#fiveGDuPageList").hide();
                         $("#showFiveGVirtualDuPage").hide();
                         $('[id="showHideVirtualPage"]').hide();
							if (tabIndexGnbAtollUpdate == 3) {
								// Keep DU panel visible in Atoll Update 5G Virtual even when API returns empty array.
								$("#fiveGVirtualView").show();
								$("#fiveGexportToExcel").hide();
							}
                    // <-- CRITICAL: Stop execution here so empty data isn't rendered!
                }
			if(tabIndexGnbAtollUpdate == 3) {
				duViewGnodeAssignmentAtollUpdate(data);
				gnbAtollFlag=true;
			} else if(tabIndexGnbAtollUpdate  == 1) {
				duViewGnodeAssignmentAtollUpdate(data);
				gnbDuSectViewFlag = false;
			}

		}, error: function(jqXHR, textStatus, errorThrown) {
           			$('#loading').hide();

           			// THIS CATCHES THE BLANK 200 RESPONSE PARSER ERROR!
                       // If the status is 200 but textStatus is 'parsererror', it means the API sent nothing.
                       if (jqXHR.status === 200 || textStatus === 'parsererror') {
                           console.log("Caught blank response (No Data). Wiping pagination.");
                       }

                       // 1. Hide standard paginations
           			$("#showHidePageID").hide();
           			$("#showHidePage").hide();

                       // 2. CRITICAL: Use .empty() before .hide() to destroy any injected HTML
                       // from previous successful calls that might be lingering in the DOM
           			$("#fiveGDuPageList").empty().hide();

           			// 3. Hide the 5G Virtual pagination component parent nav wrapper
           			$("#showFiveGVirtualDuPage").hide();

           			// 4. Force-hide ALL instances of the hardcoded << 1 2 >> pagers
           			$('[id="showHideVirtualPage"]').hide();
						if (tabIndexGnbAtollUpdate == 3) {
							// Parser errors from blank/invalid payload should still show DU panel in 5G Virtual tab.
							duViewGnodeAssignmentAtollUpdate([]);
						}

           			return null;
           		}
	});
});

function showFirst() {
	current_page = 1;
	$("#dusRows1").show();
	$("#dusRows2").hide();
	$("#dusRows3").hide();
	$("#dusRows4").hide();
	$("#dusRows5").hide();
	$("#dusRows6").hide();
	$("#dusRows7").hide();
	$("#dusRows8").hide();
	$("#dusRows9").hide();
	$("#dusRows10").hide();


}
function showSecond() {
	current_page = 2;
	$("#dusRows1").hide();
	$("#dusRows2").show();
	$("#dusRows3").hide();
	$("#dusRows4").hide();
	$("#dusRows5").hide();
	$("#dusRows6").hide();
	$("#dusRows7").hide();
	$("#dusRows8").hide();
	$("#dusRows9").hide();
	$("#dusRows10").hide();

}
function showThird() {
	current_page = 3;
	$("#dusRows1").hide();
	$("#dusRows2").hide();
	$("#dusRows3").show();
	$("#dusRows4").hide();
	$("#dusRows5").hide();
	$("#dusRows6").hide();
	$("#dusRows7").hide();
	$("#dusRows8").hide();
	$("#dusRows9").hide();
	$("#dusRows10").hide();

}
function showFourth() {
	current_page = 4;
	$("#dusRows1").hide();
	$("#dusRows2").hide();
	$("#dusRows3").hide();
	$("#dusRows4").show();
	$("#dusRows5").hide();
	$("#dusRows6").hide();
	$("#dusRows7").hide();
	$("#dusRows8").hide();
	$("#dusRows9").hide();
	$("#dusRows10").hide();

}
function showFifth() {
	current_page = 5;
	$("#dusRows1").hide();
	$("#dusRows2").hide();
	$("#dusRows3").hide();
	$("#dusRows4").hide();
	$("#dusRows5").show();
	$("#dusRows6").hide();
	$("#dusRows7").hide();
	$("#dusRows8").hide();
	$("#dusRows9").hide();
	$("#dusRows10").hide();

}

function showNext() {
	if (current_page == 1 && !$("#showHidePage1").is(':hidden'))
		showSecond();
	else if (current_page == 2 && !onlyExceptionFlag && window.getComputedStyle(document.querySelector("#showHidePage2")).display !== "none")
		showThird();
	else if (current_page == 3 && window.getComputedStyle(document.querySelector("#showHidePage3")).display != 'none')
		showFourth();
	else if (current_page == 4 && window.getComputedStyle(document.querySelector("#showHidePage4")).display != 'none')
		showFifth();
	else if (current_page == 5)
		showFifth();
	else
		showSecond();

}

function showPrevious() {
	if (current_page == 1)
		showFirst();
	else if (current_page == 2)
		showFirst();
	else if (current_page == 3)
		showSecond();
	else if (current_page == 4)
		showThird();
	else if (current_page == 5)
		showFourth();

}

// ── 5G Virtual DU View Pagination ──────────────────────────────────────────
var fiveGDuCurrentPage = 1;
function setFiveGDuPaginationActivePage(pageNumber) {
    const pageList = document.getElementById("fiveGDuPageList");
    if (!pageList) {
        return;
    }

    // Clear previously active page items
    pageList.querySelectorAll("li.page-item.active").forEach(function(item) {
        item.classList.remove("active");
    });

    // Add active class to the current page item
    const dynamicPageItem = document.getElementById("showHideFiveGPageItem" + pageNumber);
    if (dynamicPageItem) {
        dynamicPageItem.classList.add("active");
    }
}
/**
 * Navigate to a specific page in the 5G Virtual DU View.
 * Shows fiveGdusRows{pageNumber} and hides all others.
 */
function goToFiveGDuPage(pageNumber, totalPages) {
    fiveGDuCurrentPage = pageNumber;

    // Add this line to trigger the red ball active state:
    setFiveGDuPaginationActivePage(pageNumber);

    for (var i = 1; i <= totalPages; i++) {
        var el = document.getElementById("fiveGdusRows" + i);
        if (el) {
           el.style.display = (i === pageNumber) ? 'block' : 'none';
        }
    }
}

function showFiveGVirtualDuPrev(totalPages) {
	if (fiveGDuCurrentPage > 1) {
		goToFiveGDuPage(fiveGDuCurrentPage - 1, totalPages);
	}
}

function showFiveGVirtualDuNext(totalPages) {
	if (fiveGDuCurrentPage < totalPages) {
		goToFiveGDuPage(fiveGDuCurrentPage + 1, totalPages);
	}
}

// ── Sector View Pagination ──────────────────────────────────────────────────
var virtualSectorCurrentPage = 1;

/**
 * Navigate to a specific page in the Sector View.
 * Handles both  (virtualDusRows) and 5G Virtual View (fiveGvirtualDusRows).
 */
function goToVirtualSectorPage(pageNumber, totalPages) {
	virtualSectorCurrentPage = pageNumber;
	for (var i = 1; i <= totalPages; i++) {
		var duEl   = document.getElementById("virtualDusRows" + i);
		var fiveEl = document.getElementById("fiveGvirtualDusRows" + i);
		var display = (i === pageNumber) ? 'block' : 'none';
		if (duEl)   duEl.style.display   = display;
		if (fiveEl) fiveEl.style.display = display;
	}
}

function showVirtualSectorPrev(totalPages) {
	if (virtualSectorCurrentPage > 1) {
		goToVirtualSectorPage(virtualSectorCurrentPage - 1, totalPages);
	}
}

function showVirtualSectorNext(totalPages) {
	if (virtualSectorCurrentPage < totalPages) {
		goToVirtualSectorPage(virtualSectorCurrentPage + 1, totalPages);
	}
}

function emptyEnodeBDropdowns(dropDownId) {
	$(dropDownId).html('');
	$(dropDownId).multiselect('destroy');
	$(dropDownId).multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		numberDisplayed: 1,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
	});
}
var tabIndexGnbAtollUpdate;
var gnbAtollFlag=false;
var gnbDuSectViewFlag  = true;
var gnbphysicalGnbSectorViewData;
function PopulateGbEbTabs(gbEbIndex) {
	//onChangeFlag = true ;
	tabIndexEnbAtollUpdate=gbEbIndex;
	tabIndexGnbAtollUpdate = gbEbIndex;
	if (gbEbIndex == '1') {
		capacityFlagCheck = false;
		vcuFlagCheck = false;
		$("#parentGbEbTabs").show();
		$('#enodeValidationToolbar').hide();
		ParentIndex = 1;
		indexOfTabs = 1;
		gNodeBSelected = true;
		eNodeBSelected = false;

		$("#gNodeBinfo").show();
			$("#physicalgNBExpansionTabInfo").hide();

		$("#eNodeBinfo").hide();
		$("#atollUpdate").hide();
		$("#eNodeBDrillView").show();
		$("#eNodebDropdownSection").hide();
		$("#typeDb").hide();
		$("#showHideFr1Fr2Db").show();
		$("#siteVersionId").show();
		$("#gnbTextBox").show();
		$("#exportToExcelEnbAssignmentTab").hide();
		$("#exportToExcelLte").hide();
		$('#enbAssignmentSectorViewGrid').hide();
		$('#eNodebValidityFlagSection').hide();
		$("#configurationViewGrid").hide();
		$("#refreshSaveBtn").hide();
		$("#configurationGridToolBar").hide();
		$("#reserveMarketRange").hide();
		if (gNodeBSelected) {
			gNodeBAssignment = true;
			eNodeBAssignment = false;
			gNodeBValidation = false;
			eNodeBValidation = false;
			$("#parentGbEbTabs li").removeClass('active');
			$("#parentGbEbTabs li:first").addClass('active');
			$("#showValid").hide();
			$('#marketTabs').hide();
			$('#eNodeBDrillView').hide();
			$("#sectorResults").hide();
		}
		if (gNodeBSelected && eNodeBValidation) {
			gNodeBValidation = true;
			eNodeBValidation = false;
		}
		if (gNodeBAssignment) {
			$('#assignmentGrid').show();
			$('#validationViewGrid').hide();
			$('#enodeAssignmentGrid').hide();
			$('#enodeValidationViewGrid').hide();
			$('#assignmentGridToolbar').show();
			$("#showHideFr1Fr2Db").show();
			$('#PhysicalCheckbox').show();
			$('#physicalCheckboxid').show();
			$('#showValid').hide();
			$('#eNodebIdDropdownContainer').show();
		}
		if (eNodeBAssignment) {
			$('#assignmentGrid').hide();
			$('#validationViewGrid').hide();
			$('#enodeAssignmentGrid').show();
			$('#enbAssignmentGridToolbar').show();
			$('#validationGridToolbar').hide();
			$("#assignmentGridToolbar").hide();
			$("#enodeValidationToolbar").hide();
			$('#enodeValidationViewGrid').hide();
		}
		if (gNodeBValidation) {
			$('#assignmentGrid').hide();
			$('#validationViewGrid').show();
			$('#enodeAssignmentGrid').hide();
			$('#enodeValidationViewGrid').hide();
			$('#validationGridToolbar').show();
			$("#assignmentGridToolbar").hide();
			$("#enodeValidationToolbar").hide();
			$('#showValid').show();
			$('#eNodebIdDropdownContainer').show();
		}
		if (eNodeBValidation) {
			$('#assignmentGrid').hide();
			$('#validationViewGrid').hide();
			$('#enodeAssignmentGrid').hide();
			$('#enodeValidationViewGrid').show();
			$('#enodeValidationToolbar').show();
			$("#assignmentGridToolbar").hide();
			$("#validationGridToolbar").hide();
			$('#showValid').show();
		}
		if (!gnbvirtualDuIds || (gnbvirtualDuIds.length == 0)) {
			$('#AssignmentDrillView').hide();
			$('#showVirtualDuIdss').hide();
		} else {
			$('#AssignmentDrillView').show();
			$('#showVirtualDuIdss').show();
			$("#fiveGVirtualDuIdss").show();
			$("#fiveGSectorexportToExcel").show();
		}
		$('#validInvalidDropdown').multiselect('deselectAll', false);
		$("#validInvalidDropdown").multiselect('refresh');
		if (selectedValidityFlag) {
			for (var i in selectedValidityFlag) {
				$('#validInvalidDropdown').multiselect('select', selectedValidityFlag[i]);
			}
		}
		if (fetchPhyGnbs.length == 0) {
			//$("#AssignmentDrillView").hide();
			$('#assignmentGridToolbar').show();
			$('#assignmentGrid').show();
			$('#gNBViewDetails').show();
		} else if ((fetchPhyGnbs.length > 0) && (vendorVal == 'Ericsson')) {
			$("#AssignmentDrillView").show();
			$('#assignmentGrid').hide();
			$('#assignmentGridToolbar').hide();
			$('#gNBViewDetails').hide();
			$('#showVirtualDuIdss').hide();
			if(fetchGnbIdRows){
				$("#showphysicalduids").show();
				$('#physicalSectorExportToExcel').show();
			}

		} else if (vendorVal == 'Ericsson') {
			$('#assignmentGrid').hide();
			$('#assignmentGridToolbar').hide();
			$('#showVirtualDuIdss').hide();
		}
		$("#enbValidationInfo").hide();
		$("#gnbValidationInfo").hide();
		if (fetchGnbIdRows.length == 0) {
			$("#showphysicalduids").hide();
		}
		if(fetchGnbDUNumbers&&gnbDuSectViewFlag){
			$("#AssignmentDrillView").hide();
			$('#showVirtualDuIdss').hide();

		}
		// if (fetchGnbDUNumbers) {
		// 	$("#AssignmentDrillView").hide();
		// 	$("#showVirtualDuIdss").hide();
		// }
		if(gnbvirtualDuIds){
			$('#AssignmentDrillView').show();
			if(gnbphysicalGnbSectorViewData){
				$('#showVirtualDuIdss').show();
			}

		}

	} else if (gbEbIndex == '2') {
		capacityFlagCheck = false;
		vcuFlagCheck = false;
		$("#parentGbEbTabs").show();
		indexOfTabs = 1;
		ParentIndex = 2;
		gNodeBSelected = false;
		eNodeBSelected = true;
		ConfigurationTab = false;
		$("#parentGbEbTabs li").removeClass('active');
		$("#parentGbEbTabs li:first").addClass('active');
		$('#eNodebIdDropdownContainer').hide();
		$("#configurationViewGrid").hide();
		$("#refreshSaveBtn").hide();
		$("#typeDb").hide();
		$('#physicalCheckboxid').hide();
		$('#showHideFr1Fr2Db').hide();
		$("#configurationGridToolBar").hide();
		$("#reserveMarketRange").hide();
		/* $('#gNodebDropdownSection').hide();
		$('#eNodebDropdownSection').hide(); */
		$('#eNodebDropdownSection').show();
		$('#gnbTextBox').hide();
		//eNodebIdDropdownContainer

		$("#exportToExcelEnbAssignmentTab").show();
		$("#exportToExcelLte").hide();
		$('#enbAssignmentSectorViewGrid').hide();
		$("#gNodeBinfo").show();
		// $("#eNodeBinfo").show();
		$("#atollUpdate").hide();
		$("#siteVersionId").show();
		/* 	if (!enbDrillViewData) {
				$("#eNodeBDrillView").hide();

			} else {
				$("#eNodeBDrillView").show();
			}
			if (!resultVal) {
				$("#marketTabs").hide();
			} else {
				$("#marketTabs").show();
			} */

		if (getIndexVal == 2) {
			$("#enodeAssignmentGrid").hide();
			$("#enodeValidationViewGrid").show();
			$("#eNodeBDrillView").hide();
			$("#marketTabs").hide();
			$("#enbsectorResultsexportToExcel").hide();

		}
		if (!getSectorCarrierGridData) {
			enodeAssignmentEmptyTable('#enodeAssignmentGrid', enodeAssignmentDataSource, enodbAssignmentGridColumns);
			$("#eNodeBDrillView").hide();
		} else if (gnodeb == null || gnodeb == '' && getEndVal == null || getEndVal == '') {
				$("#marketTabs").show();
			$("#eNodeBDrillView").hide();
		} else if (getIndexVal == 1) {
			// $("#enodeAssignmentGrid").show();
			$("#eNodeBDrillView").show();
			$("#marketTabs").hide();
		}
		if (eNodeBSelected) {
			gNodeBAssignment = false;
			eNodeBAssignment = true;
			gNodeBValidation = false;
			eNodeBValidation = false;
		}
		if (eNodeBSelected && gNodeBValidation) {
			gNodeBValidation = false;
			eNodeBValidation = true;
		}
		if (gNodeBAssignment) {
			$('#physicalCheckboxid').show();
			$('#showHideFr1Fr2Db').show();
			$('#assignmentGrid').show();
			$('#validationViewGrid').hide();
			$('#enodeAssignmentGrid').hide();
			$('#enodeValidationViewGrid').hide();
			$('#showValid').hide();
		}
		if (eNodeBAssignment) {
			$('#assignmentGrid').hide();
			$('#validationViewGrid').hide();
			$('#enodeAssignmentGrid').show();
			$('#enbAssignmentGridToolbar').show();
			$('#enodeValidationViewGrid').hide();
			$('#validationGridToolbar').hide();
			$("#assignmentGridToolbar").hide();
			$("#enodeValidationToolbar").hide();
			$('#showValid').hide();

			if (resultVal) {

						$("#exportToExcelEnbAssignmentTab").show();
					$('#marketTabs').show();
					if(drilldata){
							$('#sectorResults').show();
						$('#enbAssignmentSectorViewGrid').show();
						$('#eNodeBDrillView').show();
					}

				$('#enodeAssignmentGrid').hide();
			} else {
				$("#exportToExcelEnbAssignmentTab").hide();
				$('#marketTabs').hide();
			}
			if (uniqEnbAssignmentTextId) {
				$("#enodeAssignmentGrid").show();
					$('#enbAssignmentGridToolbar').show();
				$('#eNodeBDrillView').show();
				$('#marketTabs').hide();
				enodeAssignmentEmptyTable('#enbAssignmentSectorViewGrid', assignmentEnodeData.SectorCarrier, enodbAssignmentGridColumns);

			}
		}
		if (gNodeBValidation) {
			$('#assignmentGrid').hide();
			$('#validationViewGrid').show();
			$('#enodeAssignmentGrid').hide();
			$('#enodeValidationViewGrid').hide();
			$('#showValid').show();
		}
		if (eNodeBValidation) {
			$('#assignmentGrid').hide();
			$('#validationViewGrid').hide();
			$('#enodeAssignmentGrid').hide();
			$('#enodeValidationViewGrid').show();
			$('#showValid').show();
		}
		$('#AssignmentDrillView').hide();
		$('#showVirtualDuIdss').hide();
		$('#showphysicalduids').hide();
		$('#validInvalidDropdown').multiselect('deselectAll', false);
		$("#validInvalidDropdown").multiselect('refresh');
		if (selectedValidityFlagEnodeB) {
			for (var i in selectedValidityFlagEnodeB) {
				$('#validInvalidDropdown').multiselect('select', selectedValidityFlagEnodeB[i]);
			}
		}
		$("#enbValidationInfo").hide();
		$("#gnbValidationInfo").hide();
		$("#physicalgNBExpansionTabInfo").hide();

	} else if (gbEbIndex == '3') {
		indexOfTabs = 3;
		ParentIndex = 3;
		capacityFlagCheck = false;
		vcuFlagCheck = false;
		$("#physicalgNBExpansionTabInfo").hide();

		$("#configurationGridToolBar").hide();
		$("#gNodeBinfo").hide();
		$("#eNodeBinfo").hide();
		$("#atollUpdate").show();
		$('#AssignmentDrillView').hide();
		$('#showVirtualDuIdss').hide();
		$('#showphysicalduids').hide();
		$("#typeDb").hide();
		$("#configurationViewGrid").hide();
		$("#reserveMarketRange").hide();
		$('#refreshSaveBtn').hide();
		$('#enbAssignmentSectorViewGrid').hide();
		$('#configurationViewGrid').hide();
		$('#validInvalidDropdown').multiselect('deselectAll', false);
		$("#validInvalidDropdown").multiselect('refresh');
		$('#assignmentGridToolbar').hide();
		$('#enodeValidationToolbar').hide();
		$("#enbValidationInfo").hide();
		$("#gnbValidationInfo").hide();
			if(getIndex == 2) {
			$("#fiveGVirtualGridToolbar").hide();
		} else if(getIndex == 3) {
			$("#fiveGVirtualGridToolbar").hide();
		} else{
			$("#fiveGVirtualGridToolbar").show();
		}

			$('#exportToExcelLte').show();
		$("#fiveGVirtualDuIdss").hide();
		$("#fiveGVirtualView").hide();


		// console.log(five5GIndex);
		// if(virtualFiveGData&&(five5GIndex==1)){
		// 	$("#fiveGVirtualView").show();
		// 	$("#fiveGVirtualDuIdss").show();
		// }
		if(virtualFiveGData&&gnbAtollFlag){
			if(fiveGVirtualFlag){
				$("#fiveGVirtualView").show();
				$("#fiveGVirtualDuIdss").show();
					$("#fiveGSectorexportToExcel").show();
			}

			}




		fiveGVirtualTab = document.querySelector('#atollSearchCriteria ul li.active a').innerHTML;
		if (!atollPushData || (fiveGVirtualTab == '5G Virtual')) {
			populate5GTables(1);
			$("#assignFiveGVirtualGrid").show();
		}

		if (!atoll5GData && tabIndexGnbAtollUpdate == 3) {
			kendoGridFirstTimeLoad = true;
			assignmentEmptyTable("#assignFiveGVirtualGrid", fiveGVirtualDataSource, assignmentGridColumns);
			$("#assignFiveGVirtualGrid").show();
			//assignmentFiveGVirtualTable();
		}
		$('#marketTabs').hide();
		$('#eNodeBDrillView').hide();
		$('#assignmentGrid').hide();
		$('#validationViewGrid').hide();
		$('#enodeAssignmentGrid').hide();
		$('#enodeValidationViewGrid').hide();
		$("#sectorResults").hide();
		$("#atollMarketDb").multiselect({
			includeSelectAllOption: true,
			enableFiltering: true,
			numberDisplayed: 1,
			enableCaseInsensitiveFiltering: true,
			buttonClass: 'btn btn-default whitebg btn-sm',
			nonSelectedText: 'None selected'
		});
		$('#validationGridToolbar').hide();
		if (sechmaList == '') {
			getUserSchema();
		}

			$("#atollUpdateRightSiteVersionDropdown").show();
			if(!atoll5GData){
			$("#atollUpdateRightSiteVersion").multiselect("disable");
			}
	}
	else if (gbEbIndex == '4')  {


		ParentIndex = 4;
		gNodeBSelected = false;
		eNodeBSelected = false;
		ConfigurationTab = true;
		$("#gNodeBinfo").show();
		$("#configurationViewGrid").show();
		$('#refreshSaveBtn').show();
		$("#atollUpdate").hide();
		$("#parentGbEbTabs").hide();
		$('#marketTabs').hide();
		$('#eNodeBDrillView').hide();
		$('#assignmentGrid').hide();
		$("#sectorResults").hide();
		$('#validationViewGrid').hide();
		$('#enodeAssignmentGrid').hide();
		$('#enodeValidationViewGrid').hide();
		$('#configurationViewGrid').show();
		$("#typeDb").show();
		$("#showHideFr1Fr2Db").hide();
		$('#PhysicalCheckbox').hide();
		$('#physicalCheckboxid').hide();
		$('#showValid').hide();
		$('#eNodebIdDropdownContainer').hide();
		$('#gnbTextBox').hide();
		$('#AssignmentDrillView').hide();
		$('#gNBViewDetails').hide();
		$('#showVirtualDuIdss').hide();
		$('#eNodebDropdownSection').hide();
		$('#assignmentGridToolbar').hide();
		$('#enodeValidationToolbar').hide();
		$('#validationGridToolbar').hide();
		$("#sectorResults").hide();
		$('#enbAssignmentSectorViewGrid').hide();
		$('#showphysicalduids').hide();
		$("#siteVersionId").hide();
		$("#enbValidationInfo").hide();
		$("#gnbValidationInfo").hide();
		$("#physicalgNBExpansionTabInfo").hide();

		if(typeValue=="Assignment Capacity Change" || typeValue==''){
			$('#configurationGridToolBar').show();
			$("#configurationViewGrid").show();
			$('#reserveMarketRange').hide();
		}else if(typeValue=="Reserve Market Range"){
			$('#configurationGridToolBar').hide();
			$("#configurationViewGrid").hide();
			$('#reserveMarketRange').show();
		}


	}
	else if (gbEbIndex == '6')  {
		ParentIndex = 6;
		$("#physicalgNBExpansionTabInfo").show();
		$("#gNodeBinfo").hide();
		$('#reserveMarketRange').hide();
		$("#configurationViewGrid").hide();
		$('#refreshSaveBtn').hide();
		$("#atollUpdate").hide();
		$("#parentGbEbTabs").hide();
		$('#marketTabs').hide();
		$('#eNodeBDrillView').hide();
		$('#assignmentGrid').hide();
		$("#sectorResults").hide();
		$('#validationViewGrid').hide();
		$('#enodeAssignmentGrid').hide();
		$('#enodeValidationViewGrid').hide();
		$("#typeDb").hide();
		$("#showHideFr1Fr2Db").hide();
		$('#PhysicalCheckbox').hide();
		$('#physicalCheckboxid').hide();
		$('#showValid').hide();
		$('#eNodebIdDropdownContainer').hide();
		$('#gnbTextBox').hide();
		$('#AssignmentDrillView').hide();
		$('#gNBViewDetails').hide();
		$('#showVirtualDuIdss').hide();
		$('#eNodebDropdownSection').hide();
		$('#assignmentGridToolbar').hide();
		$('#enodeValidationToolbar').hide();
		$('#validationGridToolbar').hide();
		$("#sectorResults").hide();
		$('#enbAssignmentSectorViewGrid').hide();
		$('#showphysicalduids').hide();
		$("#siteVersionId").hide();
		$("#enbValidationInfo").hide();
		$("#gnbValidationInfo").hide();
		$("#configurationGridToolBar").hide();
		$('#enbAssignmentGrid').hide();           // <-- Present and correct!
        $('#enbAssignmentGridToolbar').hide();    // <-- Present and correct!
	}

	else{

		ParentIndex = 5;
		gNodeBSelected = false;
		eNodeBSelected = false;
		ConfigurationTab = false;

		$("#gNodeBinfo").hide();
		$("#configurationGridToolBar").hide();
		$("#configurationViewGrid").hide();
		$('#refreshSaveBtn').hide();
		$("#atollUpdate").hide();
		$("#parentGbEbTabs").hide();
		$('#marketTabs').hide();
		$('#eNodeBDrillView').hide();
		$('#assignmentGrid').hide();
		$("#sectorResults").hide();
		$('#validationViewGrid').hide();
		$('#enodeAssignmentGrid').hide();
		$('#enodeValidationViewGrid').hide();
		$('#configurationViewGrid').hide();
		$("#typeDb").hide();
		$("#showHideFr1Fr2Db").hide();
		$('#PhysicalCheckbox').hide();
		$('#physicalCheckboxid').hide();
		$('#showValid').hide();
		$('#eNodebIdDropdownContainer').hide();
		$('#gnbTextBox').hide();
		$('#AssignmentDrillView').hide();
		$('#gNBViewDetails').hide();
		$('#showVirtualDuIdss').hide();
		$('#eNodebDropdownSection').hide();
		$('#assignmentGridToolbar').hide();
		$('#enodeValidationToolbar').hide();
		$('#validationGridToolbar').hide();
		$("#sectorResults").hide();
		$('#enbAssignmentSectorViewGrid').hide();
		$('#showphysicalduids').hide();
		$("#physicalgNBExpansionTabInfo").hide();

	}
}


function showNonSelectdDb(dbIds) {
	$(dbIds).html('');
	$(dbIds).multiselect('destroy');
	$(dbIds).multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		numberDisplayed: 1,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
	});
}
function clearEnodeValidationDropdowns(dbId) {
	$(dbId).html('');
	$(dbId).multiselect('destroy');
	$(dbId).multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		numberDisplayed: 1,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
	});
}
function resetEnodeAssignment() {
	$("#sectorResults").hide();
		$("#enbAssignmentSectorViewGrid").hide();
		$("#eNodeBDrillView").hide();
		enodeAssignmentDataSource='';
		enodeAssignmentEmptyTable('#enodeAssignmentGrid', enodeAssignmentDataSource, enodbAssignmentGridColumns);
		onChangeFlag = false;
		fetchAOR(userID);
}

function resetEnodeValidation() {
	excelDataenbValidation='';
		onChangeFlag = false;
		fetchAOR(userID);
}

function validationEnodeData() {
	$("#enodeValidationViewGrid").show();
	$("#enbsectorResultsexportToExcel").hide();
	// enbText = $("#vENodebIdSelect").val();
	var validityFlag = [];

	if ((gnbAssignTerritoryList == undefined) || (gnbAssignRegionList == undefined) || (gnbAssignRegionList == "") || (!gnbAssignRegionList) || (marketsSelected == '') || (!marketsSelected) || (gnbAssignAreaList == undefined) || ($('#siteVersionDropdownId').val() == '') || ($('#siteVersionDropdownId').val() == undefined)) {
		alert("Please Select All the Mandatory Dropdowns");
		$('#loading').hide();
	} else {
		if ($("#validInvalidDropdown").val() != null) {
			validityFlag = $("#validInvalidDropdown").val();
		}
		uniqEnbValidationTextId = document.getElementById('vENodebIdSelect').value;
		// uniqEnbAssignmentTextId = "";
		enbText = $("#eNBTextNum").val();
		if ($("#validInvalidDropdown").val()) {
			validityFlag = $("#validInvalidDropdown").val();
		}
		var finalmarketName = marketsSelected;

		enbText = $("#vENodebIdSelect").val();
		if (!enbText) {
			enbText = '';
		}

		var enodePayload = {
			"marketName": finalmarketName,
			"vzEnodebId": uniqEnbValidationTextId,
			"validationFlag": validityFlag,
			"siteVersions":siteVersions
		};
		$('#loading').show();
		$.ajax({
			type: 'POST',
			async: false,
			//url: "http://localhost:8100/npp-atoll-services/enbgnbAssignment/validateENBs",
			url: enbgnbvalidateENBsUrl,
			dataType: 'json',
			contentType: 'application/json; charset=UTF-8',
			cache: false,
			data: JSON.stringify(enodePayload),
			headers: {
				'Accept': 'application/json, text/plain, */*',
				'Content-Type': 'application/json'
			},
			success: function(data) {

				enodeBValidationResData = data;
				excelDataenbValidation = data;
				if (enodeBValidationResData.length < 1) {
					//$('#loading').fadeOut(2000);
					enodeValidationEmptyTable();
					$('#loading').fadeOut();
					return;
				}
				enodeBValidationResData = data;
				setTimeout(function() {
					$('#enodeValidationViewGrid')
						.getKendoGrid()
						.setDataSource(
							new kendo.data.DataSource({
								pageSize: 25,
								data: enodeBValidationResData,
							})
						);

				}, 1000);
				$('#loading').fadeOut();
				document.getElementById('assignmentGrid').style.display = 'none';
				document.getElementById('validationViewGrid').style.display = 'none';
				document.getElementById('marketTabs').style.display = 'none';

			},
			error: function(data) {
				$('#loading').fadeOut();
				aptAlert('error', 'failed');
			}
		});
	}
}



function MarketID(indexOfM) {
	if (indexOfM == '1') {
		golbelMId = '';
		sectorCarrirEndPayload = '';
		golbelMId = mrkNumOne;
		sectorCarrirEndPayload = {
			"marketName": golbelMId,
			"validationFlag": validAssignmentFlag,
			"vzEnodebId": golbelMId + getBoxClickId
		};
		document.getElementById("dusMarketRows1Old").outerHTML = "<div class='containerMarketseating' id='dusMarketRows1Old'></div>";

		if (fetchEnbM1Data.length == 0) {
			alert("Not found GnbDUNumbers");
			$('#loading').fadeOut();
		} else {
			var fetchGnbDUMarkets1 = fetchEnbM1Data.length;
			var fetchGnbDUSRows = Math.ceil(fetchGnbDUMarkets1 / 25);
			if (fetchGnbDUSRows <= 40) {
				$("#showHideMarkets").hide();
				var flag = false;
				for (var i = 0; i < fetchGnbDUSRows; i++) {
					var sId = "seatingMarketrow" + i;
					$("#dusMarketRows1Old").append('<div class="seatingMarketrow" id="' + sId + '" style="text-align:center"></div>');
					for (var j = 1; j <= 25; j++) {
						if (j + i * 25 > fetchGnbDUMarkets1) {
							flag = true;
							break;
						}
						if (fetchEnbM1Data[j - 1 + i * 25].status == "On Air") {
							$("#" + sId).append('<div class="onAir" id="onAirtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM1Data[j - 1 + i * 25].enodebId + '\', \''+ null +'\',\'' + fetchEnbM1Data[j - 1 + i * 25].siteVersion + '\')" data-title="SiteName:' + fetchEnbM1Data[j - 1 + i * 25].siteName + '\nSiteVersion: ' + fetchEnbM1Data[j - 1 + i * 25].siteVersion + '\nSiteInfoId: ' + fetchEnbM1Data[j - 1 + i * 25].siteInfoId + '">' + fetchEnbM1Data[j - 1 + i * 25].enodebId + ' </div>');
						} else if (fetchEnbM1Data[j - 1 + i * 25].status == "Assigned") {
							$("#" + sId).append('<div class="assigned" id="assignedtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM1Data[j - 1 + i * 25].enodebId + '\', \''+ null +'\',\'' + fetchEnbM1Data[j - 1 + i * 25].siteVersion + '\')" data-title="SiteName:' + fetchEnbM1Data[j - 1 + i * 25].siteName + '\nSiteVersion: ' + fetchEnbM1Data[j - 1 + i * 25].siteVersion + '\nSiteInfoId: ' + fetchEnbM1Data[j - 1 + i * 25].siteInfoId + '">' + fetchEnbM1Data[j - 1 + i * 25].enodebId + ' </div>');
						} else {
							$("#" + sId).append('<div class="avliable">' + fetchEnbM1Data[j - 1 + i * 25].enodebId + ' </div>');
						}

					}

					if (flag) {
						break;
					}
				}
			} else {
				$("#showHideMarkets").show();
				var flag = false;
				for (var i = 0; i < 40; i++) {
					var sId = "seatingMarketrow" + i;
					$("#dusMarketRows1Old").append('<div class="seatingMarketrow" id="' + sId + '" style="text-align:center"></div>');
					for (var j = 1; j <= 25; j++) {
						if (fetchEnbM1Data[j - 1 + i * 25].status == "On Air") {
							$("#" + sId).append('<div class="onAir" id="onAirtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM1Data[j - 1 + i * 25].enodebId + '\', \''+ null +'\',\'' + fetchEnbM1Data[j - 1 + i * 25].siteVersion + '\')" data-title="SiteName:' + fetchEnbM1Data[j - 1 + i * 25].siteName + '\nSiteVersion: ' + fetchEnbM1Data[j - 1 + i * 25].siteVersion + '\nSiteInfoId: ' + fetchEnbM1Data[j - 1 + i * 25].siteInfoId + '">' + fetchEnbM1Data[j - 1 + i * 25].enodebId + ' </div>');
						} else if (fetchEnbM1Data[j - 1 + i * 25].status == "Assigned") {
							$("#" + sId).append('<div class="assigned" id="assignedtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM1Data[j - 1 + i * 25].enodebId + '\', \''+ null +'\',\'' + fetchEnbM1Data[j - 1 + i * 25].siteVersion + '\')" data-title="SiteName:' + fetchEnbM1Data[j - 1 + i * 25].siteName + '\nSiteVersion: ' + fetchEnbM1Data[j - 1 + i * 25].siteVersion + '\nSiteInfoId: ' + fetchEnbM1Data[j - 1 + i * 25].siteInfoId + '">' + fetchEnbM1Data[j - 1 + i * 25].enodebId + ' </div>');
						} else {
							$("#" + sId).append('<div class="avliable">' + fetchEnbM1Data[j - 1 + i * 25].enodebId + ' </div>');
						}

					}

				}
				for (var i = 40; i < fetchGnbDUSRows; i++) {
					var sId = "seatingMarketrow" + i;
					$("#dusMarketRows2").append('<div class="seatingMarketrow" id="' + sId + '" style="text-align:center"></div>');
					for (var j = 1; j <= 25; j++) {
						if (j + i * 25 > fetchGnbDUMarkets1) {
							flag = true;
							break;
						}
						if (fetchEnbM2Data[j - 1 + i * 25].status == "On Air") {
							$("#" + sId).append('<div class="onAir" id="onAirtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM2Data[j - 1 + i * 25].enodebId + '\', \''+ null +'\',\'' + fetchEnbM2Data[j - 1 + i * 25].siteVersion + '\')" data-title="SiteName:' + fetchEnbM2Data[j - 1 + i * 25].siteName + '\nSiteVersion: ' + fetchEnbM2Data[j - 1 + i * 25].siteVersion + '\nFuzeSiteId: ' + fetchEnbM2Data[j - 1 + i * 25].siteInfoId + '">' + fetchEnbM2Data[j - 1 + i * 25].enodebId + ' </div>');
						} else if (fetchEnbM2Data[j - 1 + i * 25].status == "Assigned") {
							$("#" + sId).append('<div class="assigned" id="assignedtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM2Data[j - 1 + i * 25].enodebId + '\', \''+ null +'\',\'' + fetchEnbM2Data[j - 1 + i * 25].siteVersion + '\')" data-title="SiteName:' + fetchEnbM2Data[j - 1 + i * 25].siteName + '\nSiteVersion: ' + fetchEnbM2Data[j - 1 + i * 25].siteVersion + '\nFuzeSiteId: ' + fetchEnbM2Data[j - 1 + i * 25].siteInfoId + '">' + fetchEnbM2Data[j - 1 + i * 25].enodebId + ' </div>');
						} else {
							$("#" + sId).append('<div class="avliable" >' + fetchEnbM2Data[j - 1 + i * 25].enodebId + ' </div>');
						}

					}
					if (flag) {
						break;
					}
				}
			}



		}
	} else if (indexOfM == '2') {
		golbelMId = '';
		sectorCarrirEndPayload = '';
		golbelMId = mrkNumTwo;
		sectorCarrirEndPayload = {
			"marketName": golbelMId,
			"validationFlag": validAssignmentFlag,
			"vzEnodebId": golbelMId + getBoxClickId
		};
		document.getElementById("dusMarketRows1Old").outerHTML = "<div class='containerMarketseating' id='dusMarketRows1Old'></div>";

		if (fetchEnbM2Data.length == 0) {
			alert("Not found GnbDUNumbers");
			$('#loading').fadeOut();
		} else {
			var fetchGnbDUMarkets2 = fetchEnbM2Data.length;
			var fetchGnbDUSRows = Math.ceil(fetchGnbDUMarkets2 / 25);
			if (fetchGnbDUSRows <= 40) {
				$("#showHideMarkets").hide();
				var flag = false;
				for (var i = 0; i < fetchGnbDUSRows; i++) {
					var sId = "seatingMarketrow2" + i;
					$("#dusMarketRows1Old").append('<div class="seatingMarketrow2" id="' + sId + '" style="text-align:center"></div>');
					for (var j = 1; j <= 25; j++) {
						if (j + i * 25 > fetchGnbDUMarkets2) {
							flag = true;
							break;
						}
						if (fetchEnbM2Data[j - 1 + i * 25].status == "On Air") {
							$("#" + sId).append('<div class="onAir" id="onAirtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM2Data[j - 1 + i * 25].enodebId + '\', \''+ null +'\',\'' + fetchEnbM2Data[j - 1 + i * 25].siteVersion + '\')" data-title="SiteName:' + fetchEnbM2Data[j - 1 + i * 25].siteName + '\nSiteVersion: ' + fetchEnbM2Data[j - 1 + i * 25].siteVersion + '\nFuzeSiteId: ' + fetchEnbM2Data[j - 1 + i * 25].siteInfoId + '">' + fetchEnbM2Data[j - 1 + i * 25].enodebId + ' </div>');
						} else if (fetchEnbM2Data[j - 1 + i * 25].status == "Assigned") {
							$("#" + sId).append('<div class="assigned" id="assignedtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM2Data[j - 1 + i * 25].enodebId + '\', \''+ null +'\',\'' + fetchEnbM2Data[j - 1 + i * 25].siteVersion + '\')" data-title="SiteName:' + fetchEnbM2Data[j - 1 + i * 25].siteName + '\nSiteVersion: ' + fetchEnbM2Data[j - 1 + i * 25].siteVersion + '\nFuzeSiteId: ' + fetchEnbM2Data[j - 1 + i * 25].siteInfoId + '">' + fetchEnbM2Data[j - 1 + i * 25].enodebId + ' </div>');
						} else {
							$("#" + sId).append('<div class="avliable" >' + fetchEnbM2Data[j - 1 + i * 25].enodebId + ' </div>');
						}

					}

					if (flag) {
						break;
					}
				}
			} else {
				$("#showHideMarkets").show();
				var flag = false;
				for (var i = 0; i < 40; i++) {
					var sId = "seatingMarketrow2" + i;
					$("#dusMarketRows1Old").append('<div class="seatingMarketrow2" id="' + sId + '" style="text-align:center"></div>');
					for (var j = 1; j <= 25; j++) {
						if (fetchEnbM2Data[j - 1 + i * 25].status == "On Air") {
							$("#" + sId).append('<div class="onAir" id="onAirtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM2Data[j - 1 + i * 25].enodebId + '\', \''+ null +'\',\'' + fetchEnbM2Data[j - 1 + i * 25].siteVersion + '\')" data-title="SiteName:' + fetchEnbM2Data[j - 1 + i * 25].siteName + '\nSiteVersion: ' + fetchEnbM2Data[j - 1 + i * 25].siteVersion + '\nFuzeSiteId: ' + fetchEnbM2Data[j - 1 + i * 25].siteInfoId + '">' + fetchEnbM2Data[j - 1 + i * 25].enodebId + ' </div>');
						} else if (fetchEnbM2Data[j - 1 + i * 25].status == "Assigned") {
							$("#" + sId).append('<div class="assigned" id="assignedtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM2Data[j - 1 + i * 25].enodebId + '\', \''+ null +'\',\'' + fetchEnbM2Data[j - 1 + i * 25].siteVersion + '\')" data-title="SiteName:' + fetchEnbM2Data[j - 1 + i * 25].siteName + '\nSiteVersion: ' + fetchEnbM2Data[j - 1 + i * 25].siteVersion + '\nFuzeSiteId: ' + fetchEnbM2Data[j - 1 + i * 25].siteInfoId + '">' + fetchEnbM2Data[j - 1 + i * 25].enodebId + ' </div>');
						} else {
							$("#" + sId).append('<div class="avliable" >' + fetchEnbM2Data[j - 1 + i * 25].enodebId + ' </div>');
						}

					}

				}
				for (var i = 40; i < fetchGnbDUSRows; i++) {
					var sId = "seatingMarketrow2" + i;
					$("#dusMarketRows2").append('<div class="seatingMarketrow2" id="' + sId + '" style="text-align:center"></div>');
					for (var j = 1; j <= 25; j++) {
						if (j + i * 25 > fetchGnbDUMarkets2) {
							flag = true;
							break;
						}
						if (fetchEnbM2Data[j - 1 + i * 25].status == "On Air") {
							$("#" + sId).append('<div class="onAir" id="onAirtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM2Data[j - 1 + i * 25].enodebId + '\', \''+ null +'\',\'' + fetchEnbM2Data[j - 1 + i * 25].siteVersion + '\')" data-title="SiteName:' + fetchEnbM2Data[j - 1 + i * 25].siteName + '\nSiteVersion: ' + fetchEnbM2Data[j - 1 + i * 25].siteVersion + '\nFuzeSiteId: ' + fetchEnbM2Data[j - 1 + i * 25].siteInfoId + '">' + fetchEnbM2Data[j - 1 + i * 25].enodebId + ' </div>');
						} else if (fetchEnbM2Data[j - 1 + i * 25].status == "Assigned") {
							$("#" + sId).append('<div class="assigned" id="assignedtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM2Data[j - 1 + i * 25].enodebId + '\', \''+ null +'\',\'' + fetchEnbM2Data[j - 1 + i * 25].siteVersion + '\')" data-title="SiteName:' + fetchEnbM2Data[j - 1 + i * 25].siteName + '\nSiteVersion: ' + fetchEnbM2Data[j - 1 + i * 25].siteVersion + '\nFuzeSiteId: ' + fetchEnbM2Data[j - 1 + i * 25].siteInfoId + '">' + fetchEnbM2Data[j - 1 + i * 25].enodebId + ' </div>');
						} else {
							$("#" + sId).append('<div class="avliable" >' + fetchEnbM2Data[j - 1 + i * 25].enodebId + ' </div>');
						}

					}
					if (flag) {
						break;
					}
				}
			}



		}
	} else if (indexOfM == '3') {
		golbelMId = '';
		sectorCarrirEndPayload = '';
		golbelMId = mrkNumThree;
		sectorCarrirEndPayload = {
			"marketName": golbelMId,
			"validationFlag": validAssignmentFlag,
			"vzEnodebId": golbelMId + getBoxClickId
		};
		document.getElementById("dusMarketRows1Old").outerHTML = "<div class='containerMarketseating' id='dusMarketRows1Old'></div>";

		if (fetchEnbM3Data.length == 0) {
			alert("Not found GnbDUNumbers");
			$('#loading').fadeOut();
		} else {
			var fetchGnbDUMarkets3 = fetchEnbM3Data.length;
			var fetchGnbDUSRows = Math.ceil(fetchGnbDUMarkets3 / 25);
			if (fetchGnbDUSRows <= 40) {
				$("#showHideMarkets").hide();
				var flag = false;
				for (var i = 0; i < fetchGnbDUSRows; i++) {
					var sId = "seatingMarketrow3" + i;
					$("#dusMarketRows1Old").append('<div class="seatingMarketrow3" id="' + sId + '" style="text-align:center"></div>');
					for (var j = 1; j <= 25; j++) {
						if (j + i * 25 > fetchGnbDUMarkets3) {
							flag = true;
							break;
						}
						if (fetchEnbM3Data[j - 1 + i * 25].status == "On Air") {
							$("#" + sId).append('<div class="onAir" id="onAirtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM3Data[j - 1 + i * 25].enodebId + '\', \''+ null +'\',\'' + fetchEnbM3Data[j - 1 + i * 25].siteVersion + '\')" data-title="SiteName:' + fetchEnbM3Data[j - 1 + i * 25].siteName + '\nSiteVersion: ' + fetchEnbM3Data[j - 1 + i * 25].siteVersion + '\nFuzeSiteId: ' + fetchEnbM3Data[j - 1 + i * 25].siteInfoId + '">' + fetchEnbM3Data[j - 1 + i * 25].enodebId + ' </div>');
						} else if (fetchEnbM3Data[j - 1 + i * 25].status == "Assigned") {
							$("#" + sId).append('<div class="assigned" id="assignedtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM3Data[j - 1 + i * 25].enodebId + '\', \''+ null +'\',\'' + fetchEnbM3Data[j - 1 + i * 25].siteVersion + '\')" data-title="SiteName:' + fetchEnbM3Data[j - 1 + i * 25].siteName + '\nSiteVersion: ' + fetchEnbM3Data[j - 1 + i * 25].siteVersion + '\nFuzeSiteId: ' + fetchEnbM3Data[j - 1 + i * 25].siteInfoId + '">' + fetchEnbM3Data[j - 1 + i * 25].enodebId + ' </div>');
						} else {
							$("#" + sId).append('<div class="avliable" >' + fetchEnbM3Data[j - 1 + i * 25].enodebId + ' </div>');
						}

					}

					if (flag) {
						break;
					}
				}
			} else {
				$("#showHideMarkets").show();
				var flag = false;
				for (var i = 0; i < 40; i++) {
					var sId = "seatingMarketrow3" + i;
					$("#dusMarketRows1Old").append('<div class="seatingMarketrow3" id="' + sId + '" style="text-align:center"></div>');
					for (var j = 1; j <= 25; j++) {
						if (fetchEnbM3Data[j - 1 + i * 25].status == "On Air") {
							$("#" + sId).append('<div class="onAir" id="onAirtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM3Data[j - 1 + i * 25].enodebId + '\', \''+ null +'\',\'' + fetchEnbM3Data[j - 1 + i * 25].siteVersion + '\')" data-title="SiteName:' + fetchEnbM3Data[j - 1 + i * 25].siteName + '\nSiteVersion: ' + fetchEnbM3Data[j - 1 + i * 25].siteVersion + '\nFuzeSiteId: ' + fetchEnbM3Data[j - 1 + i * 25].siteInfoId + '">' + fetchEnbM3Data[j - 1 + i * 25].enodebId + ' </div>');
						} else if (fetchEnbM3Data[j - 1 + i * 25].status == "Assigned") {
							$("#" + sId).append('<div class="assigned" id="assignedtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM3Data[j - 1 + i * 25].enodebId + '\', \''+ null +'\',\'' + fetchEnbM3Data[j - 1 + i * 25].siteVersion + '\')" data-title="SiteName:' + fetchEnbM3Data[j - 1 + i * 25].siteName + '\nSiteVersion: ' + fetchEnbM3Data[j - 1 + i * 25].siteVersion + '\nFuzeSiteId: ' + fetchEnbM3Data[j - 1 + i * 25].siteInfoId + '">' + fetchEnbM3Data[j - 1 + i * 25].enodebId + ' </div>');
						} else {
							$("#" + sId).append('<div class="avliable" >' + fetchEnbM3Data[j - 1 + i * 25].enodebId + ' </div>');
						}

					}

				}
				for (var i = 40; i < fetchGnbDUSRows; i++) {
					var sId = "seatingMarketrow3" + i;
					$("#dusMarketRows2").append('<div class="seatingMarketrow3" id="' + sId + '" style="text-align:center"></div>');
					for (var j = 1; j <= 25; j++) {
						if (j + i * 25 > fetchGnbDUMarkets3) {
							flag = true;
							break;
						}
						if (fetchEnbM3Data[j - 1 + i * 25].status == "On Air") {
							$("#" + sId).append('<div class="onAir" id="onAirtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM3Data[j - 1 + i * 25].enodebId + '\', \''+ null +'\',\'' + fetchEnbM3Data[j - 1 + i * 25].siteVersion + '\')" data-title="SiteName:' + fetchEnbM3Data[j - 1 + i * 25].siteName + '\nSiteVersion: ' + fetchEnbM3Data[j - 1 + i * 25].siteVersion + '\nFuzeSiteId: ' + fetchEnbM3Data[j - 1 + i * 25].siteInfoId + '">' + fetchEnbM3Data[j - 1 + i * 25].enodebId + ' </div>');
						} else if (fetchEnbM3Data[j - 1 + i * 25].status == "Assigned") {
							$("#" + sId).append('<div class="assigned" id="assignedtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM3Data[j - 1 + i * 25].enodebId + '\', \''+ null +'\',\'' + fetchEnbM3Data[j - 1 + i * 25].siteVersion + '\')" data-title="SiteName:' + fetchEnbM3Data[j - 1 + i * 25].siteName + '\nSiteVersion: ' + fetchEnbM3Data[j - 1 + i * 25].siteVersion + '\nFuzeSiteId: ' + fetchEnbM3Data[j - 1 + i * 25].siteInfoId + '">' + fetchEnbM3Data[j - 1 + i * 25].enodebId + ' </div>');
						} else {
							$("#" + sId).append('<div class="avliable" >' + fetchEnbM3Data[j - 1 + i * 25].enodebId + ' </div>');
						}

					}
					if (flag) {
						break;
					}
				}
			}



		}
	}
}


function getSectorCarrierAssignment() {
	// phyLteFlag = false;
	resultVal = [];
	resultKeys=[];
	enbSecData1='';
	enbSecTabData1='';
	enbSelData1='';
	drilldata='';
	$("#loading").show();
	$("#showMarketTabs li").removeClass('active');
	$("#showMarketTabs li:first").addClass('active');
	document.getElementById("marketIdtab").innerHTML = '';
	document.getElementById("marketId300tab").innerHTML = '';
	document.getElementById("marketId600tab").innerHTML = '';
	document.getElementById("dusMarketRows1").outerHTML = "<div class='containerMarketseating' id='dusMarketRows1'></div>";
	if ((gnbAssignTerritoryList == undefined) || (gnbAssignRegionList == undefined) || (gnbAssignRegionList == "") || (!gnbAssignRegionList) || (marketsSelected == '') || (!marketsSelected) || (gnbAssignAreaList == undefined) || ($('#siteVersionDropdownId').val() == '') || ($('#siteVersionDropdownId').val() == undefined)) {
		alert("Please Select All the Mandatory Dropdowns");
		$('#loading').hide();
	} else {
		$("#sectorResults").hide();
		uniqEnbAssignmentTextId = document.getElementById('vENodebIdSelect').value;
		uniqEnbValidationTextId = '';
		if (uniqEnbAssignmentTextId == '' || uniqEnbAssignmentTextId == null) {
			$("#enodeAssignmentGrid").hide();
			$("#eNodeBDrillView").hide();
			$("#enbAssignmentSectorViewGrid").hide();
			$("#sectorResults").hide();
			var enBAssignmentPayload = {
				"marketName": marketsSelected,
				"validationFlag": validAssignmentFlag,
				"vzEnodebId": uniqEnbAssignmentTextId,
				"siteVersions":siteVersions
			};
			document.getElementById("dusMarketRows1").outerHTML = "<div class='containerMarketseating' id='dusMarketRows1'></div>";
			$.ajax({
				type: 'POST',
				async: false,
				//url: "http://localhost:8100/npp-atoll-services/enbgnbAssignment/getENBAssignments",
				url: getENBAssignmentsUrl,
				dataType: 'json',
				contentType: 'application/json; charset=UTF-8',
				cache: false,
				data: JSON.stringify(enBAssignmentPayload),
				headers: {
					'Accept': 'application/json, text/plain, */*',
					'Content-Type': 'application/json'
				},
				success: function(data) {

					$('#loading').fadeOut();

					if (data) {
						$("#marketTabs").show();
						$("#enbsectorexportToExcel").hide();
					}

					result = Object.keys(data);
					var inOrderKeys = result.sort();
					resultVal.push(data[inOrderKeys[0]]);
					resultVal.push(data[inOrderKeys[1]]);
					resultVal.push(data[inOrderKeys[2]]);
					//resultVal = Object.values(data);
					enbAssignmentAtollUpdateLteCommonView();


				}, error: function(response) {
					$('#loading').hide();
					$('#enodeAssignmentGrid').show();
						$('#enbAssignmentGridToolbar').show();
					return null;
				}
			});
			$("#dusMarketRows2").hide();
		} else {
			assignmentEnodeData = '';
			$("#eNodeBDrillView").hide();
			$("#marketTabs").hide();
			$("#enbAssignmentSectorViewGrid").hide();
			var sectorCarrirEndPayload = {
				"marketName": marketsSelected,
				"validationFlag": validAssignmentFlag,
				"vzEnodebId": uniqEnbAssignmentTextId,
				"siteVersions":siteVersions
			};
			$.ajax({
				type: 'POST',
				async: false,
				//url: "http://localhost:8100/npp-atoll-services/enbgnbAssignment/getSectorCarrierAssignments",
				url: getSectorCarrierAssignmentsURL,
				dataType: 'json',
				contentType: 'application/json; charset=UTF-8',
				cache: false,
				data: JSON.stringify(sectorCarrirEndPayload),
				headers: {
					'Accept': 'application/json, text/plain, */*',
					'Content-Type': 'application/json'
				},
				success: function(data) {
						$('#enbsectorexportToExcel').show();
					assignmentEnodeData = data;
					enbDrillViewData = assignmentEnodeData.SectorCarrierDetails;
					getSectorCarrierGridData = assignmentEnodeData.SectorCarrier;

					if (getSectorCarrierGridData == undefined) {

						setTimeout(function() {
							$("#enodeAssignmentGrid").show();
								$('#enbAssignmentGridToolbar').show();
							$("#enodeAssignmentGrid").data("kendoGrid").dataSource.data([]);
						}, 1000);
						$('#loading').fadeOut();
					} else {
						$("#enodeAssignmentGrid").show();
							$('#enbAssignmentGridToolbar').show();
						setTimeout(function() {
							enodeAssignmentEmptyTable('#enodeAssignmentGrid', assignmentEnodeData.SectorCarrier, enodbAssignmentGridColumns);
						}, 1000);
						$('#loading').fadeOut();
					}
					document.getElementById("dusEnbRows1").outerHTML = "<div class='containerEnbseating' id='dusEnbRows1'></div>";
					if (!enbDrillViewData) {
						alert("Not found enbDUNumbers");
						$("#enbsectorResultsexportToExcel").hide();
						$('#loading').fadeOut();
					} else {
							// $("#sectorResults").show();
							$("#enbsectorResultsexportToExcel").show();
						enbSecData1=enbDrillViewData;
						enbSelData1=uniqEnbAssignmentTextId;

						var drillSampleDatalength = enbDrillViewData.length;
						var fetchGnbDUSRows = Math.ceil(drillSampleDatalength / 10);

						if (fetchGnbDUSRows <= 26) {
							$("#showHidePage").hide();
							var flag = false;
							for (var i = 0; i < fetchGnbDUSRows; i++) {
								var sId = "seatinenbgrow" + i;
								$("#dusEnbRows1").append('<div class="seatinenbgrow" id="' + sId + '" style="text-align:center"></div>');
								for (var j = 1; j <= 10; j++) {
									if (j + i * 10 > drillSampleDatalength) {
										flag = true;
										break;
									}
									if (enbDrillViewData[j - 1 + i * 10].status == "On Air") {
											$("#" + sId).append('<div class="onAir" id="onAirtooltip"  data-title="SiteName: ' + enbDrillViewData[j - 1 + i * 10].siteName + '\nSiteVersion: ' + enbDrillViewData[j - 1 + i * 10].siteVersion + '\nFuzeSiteId: ' + enbDrillViewData[j - 1 + i * 10].siteFUZEID + '\nHubName: ' + enbDrillViewData[j - 1 + i * 10].cranHubName + '">' + enbDrillViewData[j - 1 + i * 10].sectorCarrier + ' </div>');
										} else if (enbDrillViewData[j - 1 + i * 10].status == "Assigned") {
											$("#" + sId).append('<div class="assigned" id="assignedtooltip"  data-title="SiteName: ' + enbDrillViewData[j - 1 + i * 10].siteName + '\nSiteVersion: ' + enbDrillViewData[j - 1 + i * 10].siteVersion + '\nFuzeSiteId: ' + enbDrillViewData[j - 1 + i * 10].siteFUZEID + '\nHubName: ' + enbDrillViewData[j - 1 + i * 10].cranHubName + '">' + enbDrillViewData[j - 1 + i * 10].sectorCarrier + ' </div>');
										} else {
											$("#" + sId).append('<div class="avliable" onclick="avliableEnbDuId()">' + enbDrillViewData[j - 1 + i * 10].sectorCarrier + ' </div>');
										}
									}


								if (flag) {
									break;
								}
							}
						}

					}
					$("#eNodeBDrillView").show();
					$('#loading').fadeOut();
				},

				error: function(data) {
					$('#loading').fadeOut();
					aptAlert('error', 'failed');
				}
			});

		}

		$('#assignmentGrid').hide();
		$('#validationViewGrid').hide();


		//}
	}
if ((Object.keys(featureToggleMap).includes("F90277") && featureToggleMap['F90277'])) {
		document.querySelectorAll("#eNodeBDrillView").forEach(el => el.className = "geohierarchydiv");
		 document.querySelectorAll("#dusMarketRows1").forEach(el => el.className = "geohierarchydiv");
		document.querySelectorAll("#marketTabs").forEach(el => el.className = "geohierarchydiv");

		} else {
		 document.querySelectorAll("#dusMarketRows1").forEach(el => el.removeClass = "geohierarchydiv");
		document.querySelectorAll("#eNodeBDrillView").forEach(el => el.removeClass = "geohierarchydiv");
		document.querySelectorAll("#marketTabs").forEach(el => el.removeClass = "geohierarchydiv");
		}
}
var golbelMId;
let enbSecData = [];
var enbSecTabData = [];
let enbSelData;
var sectorCarrierLteTabData=[];
var fetchLteBoxId;
function showSectorCarrierView(enbId, selectedMarketId, siteVersion) {
	// golbelMId = mrkNumOne;
	// drilldata='';
	getBoxClickId = enbId;
	fetchLteBoxId = enbId;
	if (tabIndexEnbAtollUpdate == 2) {
		$("#loading").show();
		$('#enodeAssignmentGrid').hide();
		$('#enbsectorexportToExcel').show();

	}
	else {
		// $("#loading").show();
		// $('#carrierLteGird').hide();
			$('#lteSectorResults').show();

	}
	if(tabIndexEnbAtollUpdate==2){
			updatedMarketList = [mrkNumOne, mrkNumTwo, mrkNumThree]

			if (updatedMarketList.length > 0) {
				enbAMList = updatedMarketList[selectedMarketId];
				golbelMId = updatedMarketList[selectedMarketId];
			}
		sectorCarrirEndPayload = {
			"marketName": marketsSelected,
			"validationFlag": validAssignmentFlag,
			"vzEnodebId": golbelMId + getBoxClickId,
			"siteVersions": [siteVersion],
		};
		enbSelData1 = golbelMId + getBoxClickId;
	}
	else{
			updatedMarketList = [mrkNumOne, mrkNumTwo, mrkNumThree]

			if (updatedMarketList.length > 0) {
				enbAMList = updatedMarketList[selectedMarketId];
				golbelMId = updatedMarketList[selectedMarketId];
			}

		// else {
		// 	enbAMList = marketsSelected;
		// }
		sectorCarrirEndPayload = {
			atollSchema: sechmaList,
			marketName: mrkNumOne,
			validationFlag: [],
			vzEnodebId:golbelMId + getBoxClickId,
			siteVersions: [siteVersion]
		};
		enbSelData = golbelMId + getBoxClickId;
	}

	$.ajax({
		type: 'POST',
		async: false,
		//	url: "http://localhost:8100/npp-atoll-services/enbgnbAssignment/getSectorCarrierAssignments",
		url: getSectorCarrierAssignmentsURL,
		dataType: 'json',
		contentType: 'application/json; charset=UTF-8',
		cache: false,
		data: JSON.stringify(sectorCarrirEndPayload),
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function(data) {
				$("#enbsectorexportToExcel").show();
			// enbSecData = data.SectorCarrierDetails;
			// enbSecTabData = data.SectorCarrier;
			assignmentEnodeData = data;
			var enbDrillViewData = assignmentEnodeData.SectorCarrierDetails;
			getSectorCarrierGridData = assignmentEnodeData.SectorCarrier;


			if(tabIndexEnbAtollUpdate==2){
				drilldata=enbDrillViewData;
				enbSecData1=enbDrillViewData;
				enbSecTabData1=getSectorCarrierGridData;
				// enbSelData1=enbSelData;

				$("#enbAssignmentSectorViewGrid").show();
				enodeAssignmentEmptyTable('#enbAssignmentSectorViewGrid', assignmentEnodeData.SectorCarrier, enodbAssignmentGridColumns);
				document.getElementById("dusEnbRows1").outerHTML = "<div class='containerEnbseating' id='dusEnbRows1'></div>";
			}
			else{
				atollData=data;
				enbSecData = data.SectorCarrierDetails;
				enbSecTabData = data.SectorCarrier;

				// carrierLteEmptyTable();
				$("#carrierLteGrid").show();
				enodeAssignmentEmptyTable('#carrierLteGrid', assignmentEnodeData.SectorCarrier, enodbAssignmentGridColumns);
				// $("#eNodeBLteDrillView").show();

				document.getElementById("dusLteRows1").outerHTML = "<div class='lteEnbseating' id='dusLteRows1'></div>";
			}




			/* setTimeout(function () {
				//$("eNodeBDrillView").show();
				$('#enodeAssignmentGrid')
					.getKendoGrid()
					.setDataSource(
						new kendo.data.DataSource({
							pageSize: 25,
							data: assignmentEnodeData.SectorCarrier,
						})
					);
			}, 1000); */


			if (!enbDrillViewData) {
				alert("No Data for enodeB");
				$("#enodeAssignmentGrid").hide();
				$("#eNodeBDrillView").hide();
				$('#loading').fadeOut();
			} else {
				// $("#enodeAssignmentGrid").show();
				if(tabIndexEnbAtollUpdate==2){
					window.scrollTo(0, document.getElementById("enbAssignmentSectorViewGrid").scrollHeight);
					$('html, body').animate({
						scrollTop: $("#enbAssignmentSectorViewGrid").offset().top
					}, "slow");
				}
				else {
					window.scrollTo(0, document.getElementById("carrierLteGrid").scrollHeight);
					$('html, body').animate({
						scrollTop: $("#carrierLteGrid").offset().top
					}, "slow");
				}


				var drillSampleDatalength = enbDrillViewData.length;
				var fetchGnbDUSRows = Math.ceil(drillSampleDatalength / 10);

				if (fetchGnbDUSRows <= 26) {
					$("#showHidePage").hide();
					var flag = false;
					for (var i = 0; i < fetchGnbDUSRows; i++) {
						var sId = tabIndexEnbAtollUpdate == 2 ?"seatinenbgrow" + i : "lteSeatinenBrow" + i;
						if (tabIndexEnbAtollUpdate == 2 ) {
							$("#dusEnbRows1").append('<div class="seatinenbgrow" id="' + sId + '" style="text-align:center"></div>');
						} else {
							$("#dusLteRows1").append('<div class="lteSeatinenBrow" id="' + sId + '" style="text-align:center"></div>');

						}
						for (var j = 1; j <= 10; j++) {
							if (j + i * 10 > drillSampleDatalength) {
								flag = true;
								break;
							}
							if (enbDrillViewData[j - 1 + i * 10].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="onAirtooltip"  data-title="SiteName: ' + enbDrillViewData[j - 1 + i * 10].siteName + '\nSiteVersion: ' + enbDrillViewData[j - 1 + i * 10].siteVersion + '\nFuzeSiteId: ' + enbDrillViewData[j - 1 + i * 10].siteFUZEID + '\nHubName: ' + enbDrillViewData[j - 1 + i * 10].cranHubName + '">' + enbDrillViewData[j - 1 + i * 10].sectorCarrier + ' </div>');
								} else if (enbDrillViewData[j - 1 + i * 10].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="assignedtooltip"  data-title="SiteName: ' + enbDrillViewData[j - 1 + i * 10].siteName + '\nSiteVersion: ' + enbDrillViewData[j - 1 + i * 10].siteVersion + '\nFuzeSiteId: ' + enbDrillViewData[j - 1 + i * 10].siteFUZEID + '\nHubName: ' + enbDrillViewData[j - 1 + i * 10].cranHubName + '">' + enbDrillViewData[j - 1 + i * 10].sectorCarrier + ' </div>');
								} else {
									$("#" + sId).append('<div class="avliable" onclick="avliableEnbDuId()">' + enbDrillViewData[j - 1 + i * 10].sectorCarrier + ' </div>');
								}
						}

						if (flag) {
							break;
						}
					}
				}
				if(tabIndexEnbAtollUpdate==2){
					// $("#enodeAssignmentGrid").hide();
					$("#eNodeBDrillView").show();
				}
				else{
					// $("#enodeAssignmentGrid").hide();
					$("#eNodeBLteDrillView").show();

				}

					tabIndexEnbAtollUpdate==2?$('#sectorResults').show():
					$('#ltesectorResults').show();
				$('#loading').fadeOut();
			}

		},

		error: function(data) {
			alert("No Data SectorCarrier View");
			$("#enodeAssignmentGrid").hide();
			$("#eNodeBDrillView").hide();
			$('#loading').fadeOut();
		}
	});

}


function virtualDrillDown(getDuId) {
	if (tabIndexGnbAtollUpdate == 1) {
	document.getElementById("virtualDusRows1").outerHTML = "<div class='containerVirtualseating' id='virtualDusRows1'></div>";
	document.getElementById("virtualDusRows2").outerHTML = "<div class='containerVirtualseating' id='virtualDusRows2'></div>";
		$("#showVirtualDuIdss").show();
		$("#fiveGVirtualDuIdss").hide();
	} else {
		$("#showVirtualDuIdss").hide();
		$("#fiveGVirtualDuIdss").show();
			$("#fiveGSectorexportToExcel").show();
		document.getElementById("fiveGvirtualDusRows1").outerHTML = "<div class='containerVirtualFiveseating' id='fiveGvirtualDusRows1'></div>";
		document.getElementById("fiveGvirtualDusRows2").outerHTML = "<div class='containerVirtualFiveseating' id='fiveGvirtualDusRows2'></div>";
	}

	if (tabIndexGnbAtollUpdate == 1) {
	var virtualPayload = {
		"marketName": marketsSelected,
		"vzGnodebId": getDuId,
		"vendor": vzEnodebVendorHtml,
		"fR2": dataFr2,
		"siteVersions":siteVersions,
	};
	} else {
		var atollVirtualVendor = vzEnodebVendorHtml || "";
		var atollVirtualFr2 = dataFr2 || "";
		var virtualPayload = {
			atollSchema: sechmaList,
			fR2: atollVirtualFr2,
			marketName: marketIdOrName,
			siteName: "",
			validationFlag: [
				""
			],
			vendor: atollVirtualVendor,
			vzGnodebId: getDuId,
			"siteVersions":$("#atollUpdateRightSiteVersion").val()
		};
	}

	$.ajax({
		type: 'POST',
		async: false,
		//url: "http://localhost:8100/npp-atoll-services/enbgnbAssignment/getVirtualandPhysicalGNBSecAssignments",
		url: getVirtualandPhysicalGNBSecAssignmentsUrl,
		dataType: 'json',
		contentType: 'application/json; charset=UTF-8',
		cache: false,
		data: JSON.stringify(virtualPayload),
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function(data) {
				$('#sectorexportToExcel').show();
				$('#physicalSectorExportToExcel').show();

			virtualDuIds = data.SectorList;
			if(tabIndexGnbAtollUpdate==1){
				gnbvirtualDuIds=virtualDuIds;
			}

			console.log('virtualDuIds', virtualDuIds);
			if (virtualDuIds.length == 0) {
                alert("Not found GnbDUNumbers");
                $("#showHideVirtualPage").hide();
            }else {

				var virtualDuIdsLength = virtualDuIds.length;
				var virtualDuIdsRows = Math.ceil(virtualDuIdsLength / 25);
				if (virtualDuIdsRows <= 40) {
					$("#showHideVirtualPage").hide();
					var flag = false;
					for (var i = 0; i < virtualDuIdsRows; i++) {
						var sId = (tabIndexGnbAtollUpdate == 1) ? "virtualSeatingRow" + i: "fiveGVirtualSeatingRow"  + i;
						if (tabIndexGnbAtollUpdate == 1) {
						$("#virtualDusRows1").append('<div class="virtualSeatingRow" id="' + sId + '" style="text-align:center"></div>');
						} else {
							$("#fiveGvirtualDusRows1").append('<div class="fiveGVirtualSeatingRow" id="' + sId + '" style="text-align:center"></div>');
						}

						for (var j = 1; j <= 25; j++) {
							if (j + i * 25 > virtualDuIdsLength) {
								flag = true;
								break;
							}
							if (virtualDuIds[j - 1 + i * 25].status == "On Air") {

								$("#" + sId).append('<div class="onAir" id="onAirtooltip"  data-title="SiteName: ' + virtualDuIds[j - 1 + i * 25].siteName + '\nSiteVersion: ' + virtualDuIds[j - 1 + i * 25].siteVersion + '\nFuzeSiteId: ' + virtualDuIds[j - 1 + i * 25].siteFuzeId + '\nHubName: ' + virtualDuIds[j - 1 + i * 25].cranHubName + '">' + virtualDuIds[j - 1 + i * 25].sector + ' </div>');

							} else if (virtualDuIds[j - 1 + i * 25].status == "Assigned") {

								$("#" + sId).append('<div class="assigned"  id="assignedtooltip"  data-title="SiteName: ' + virtualDuIds[j - 1 + i * 25].siteName + '\nSiteVersion: ' + virtualDuIds[j - 1 + i * 25].siteVersion + '\nFuzeSiteId: ' + virtualDuIds[j - 1 + i * 25].siteFuzeId + '\nHubName: ' + virtualDuIds[j - 1 + i * 25].cranHubName + '">' + virtualDuIds[j - 1 + i * 25].sector + ' </div>');

							} else {
								$("#" + sId).append('<div class="avliable" >' + virtualDuIds[j - 1 + i * 25].sector + ' </div>');
							}

						}

						if (flag) {
							break;
						}
					}
				} else {
				// --- Sector View Dynamic Pagination: 1,000 records per page (40 rows × 25 cols) ---
				var SECT_ROWS_PER_PAGE = 40;
				var totalSectorPages = Math.ceil(virtualDuIdsRows / SECT_ROWS_PER_PAGE);

				var flag = false;
				for (var page = 1; page <= totalSectorPages; page++) {
					var startRow = (page - 1) * SECT_ROWS_PER_PAGE;
					var endRow   = Math.min(page * SECT_ROWS_PER_PAGE, virtualDuIdsRows);
					for (var i = startRow; i < endRow; i++) {
						var sId = (tabIndexGnbAtollUpdate == 1) ? "virtualSeatingRow" + i : "fiveGVirtualSeatingRow" + i;
						if (tabIndexGnbAtollUpdate == 1) {
							$("#virtualDusRows" + page).append('<div class="virtualSeatingRow" id="' + sId + '" style="text-align:center"></div>');
						} else {
							$("#fiveGvirtualDusRows" + page).append('<div class="fiveGVirtualSeatingRow" id="' + sId + '" style="text-align:center"></div>');
						}
						for (var j = 1; j <= 25; j++) {
							if (j + i * 25 > virtualDuIdsLength) {
								flag = true;
								break;
							}
							var srec = virtualDuIds[j - 1 + i * 25];
							if (srec.status == "On Air") {
								$("#" + sId).append('<div class="onAir" id="onAirtooltip" data-title="SiteName: ' + srec.siteName + '\nSiteVersion: ' + srec.siteVersion + '\nFuzeSiteId: ' + srec.siteFuzeId + '\nHubName: ' + srec.cranHubName + '">' + srec.sector + ' </div>');
							} else if (srec.status == "Assigned") {
								$("#" + sId).append('<div class="assigned" id="assignedtooltip" data-title="SiteName: ' + srec.siteName + '\nSiteVersion: ' + srec.siteVersion + '\nFuzeSiteId: ' + srec.siteFuzeId + '\nHubName: ' + srec.cranHubName + '">' + srec.sector + ' </div>');
							} else {
								$("#" + sId).append('<div class="avliable">' + srec.sector + ' </div>');
							}
						}
						if (flag) break;
					}
					if (flag) break;
				}

				// Hide all pages except page 1 initially
				for (var p = 2; p <= totalSectorPages; p++) {
					var duP   = document.getElementById("virtualDusRows" + p);
					var fiveP = document.getElementById("fiveGvirtualDusRows" + p);
					if (duP)   duP.style.display   = 'none';
					if (fiveP) fiveP.style.display = 'none';
				}
				virtualSectorCurrentPage = 1;

				// Build pagination nav for all showHideVirtualPage navs on page
				var sectorNavHtml = '<li class="page-item"><span onclick="showVirtualSectorPrev(' + totalSectorPages + ');" aria-hidden="true">&laquo;</span><span class="sr-only">Previous</span></li>';
				sectorNavHtml += '<li class="page-item active"><span onclick="goToVirtualSectorPage(1,' + totalSectorPages + ');">1</span></li>';
				for (var p = 2; p <= totalSectorPages; p++) {
					sectorNavHtml += '<li class="page-item"><span onclick="goToVirtualSectorPage(' + p + ',' + totalSectorPages + ');">' + p + '</span></li>';
				}
				sectorNavHtml += '<li class="page-item"><span onclick="showVirtualSectorNext(' + totalSectorPages + ');" aria-hidden="true">&raquo;</span><span class="sr-only">Next</span></li>';
				$("#showHideVirtualPage").each(function() {
					$(this).find("ul").html(sectorNavHtml);
					$(this).show();
				});
			}



			}


		}, error: function(response) {
			$('#loading').hide();
			return null;
		}
	});
}

function getUserSchema() {


	$.ajax({
		async: false,
		url: getAtollSchemaData,
		//url: 'http://localhost:8100/npp-atoll-services/enbgnbAssignment/getAtollSchema',
		dataType: 'json',
		type: "POST",
		contentType: 'application/json; charset=UTF-8',
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function(data) {
			atollSchemaRes = data;




			/* $.each(atollSchemaRes, function (index, value) {
				entireTerritoryList.push(value);
			}); */
		},
		error: function(data) {
			aptAlert('Warning', 'Failed to load atollSchema data!');
		}
	});
	$('#atollSchemaDropdown').html('');
	$('#atollSchemaDropdown').multiselect('destroy');

	$.each(atollSchemaRes, function(i, v) {
		$('#atollSchemaDropdown').append("<option>" + v + "</option>");
	});
	$('#atollSchemaDropdown').val('', '');
	$('#atollSchemaDropdown').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
		nonSelectedText: 'None selected'

	});



}


$('#atollSchemaDropdown').change(function() {
	sechmaList = '';
	$("#siteName").val('');
	sechmaList = $('#atollSchemaDropdown').val();
	if (sechmaList == 'None Selected') {
		sechmaList = '';
	}
	if (sechmaList != 'None Selected') {
		var temp = $('#siteVersionDb').val();
		if (temp != null) {
			$('#siteVersionDb').html("");
			$('#siteVersionDb').multiselect("rebuild");
			$('#siteVersionDb').multiselect({
				includeSelectAllOption: true,
				enableFiltering: true,
				enableCaseInsensitiveFiltering: true,
				buttonClass: 'btn btn-default whitebg btn-sm',
				numberDisplayed: 1,
				nonSelectedText: 'None selected'
			});
		}
		$("#siteName").val('');

	}
	$("#atollMarketDb").multiselect("enable");
	if (phyLteFlag) {
		phyLteFlag = false
	}
	fiveGVirtualDataSource = '';
	assignmentEmptyTable("#assignFiveGVirtualGrid", fiveGVirtualDataSource, assignmentGridColumns);
	$("#marketLTETabs").hide();
	$("#physicalTabView").hide();
	getAtollMarketDb(sechmaList);

	$('#atollUpdateRightSiteVersion').html('');
	$('#atollUpdateRightSiteVersion').multiselect('destroy');
$.each(siteDropdownList, function(i, v) {
		if(v=="0000"||v=="0001"||v=="0FAA"){
		$('#atollUpdateRightSiteVersion').append("<option selected>" + v + "</option>");
		}else{
			$('#atollUpdateRightSiteVersion').append("<option>" + v + "</option>");
		}
	});
$('#atollUpdateRightSiteVersion').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1
	});
$("#atollUpdateRightSiteVersion").multiselect("disable");

});

function getSiteVersion(changevaluesitename, sechmaList) {
	var versionPayload = {
		atollSchema: sechmaList,
		siteName: changevaluesitename
		//siteVersion: ""


	}


	$.ajax({
		async: false,
		url: getSiteVersionsURL,
		//url: 'http://localhost:8100/npp-atoll-services/enbgnbAssignment/getSiteVersions',
		dataType: 'json',
		data: JSON.stringify(versionPayload),
		type: "POST",
		contentType: 'application/json; charset=UTF-8',
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function(data) {
			getSitesV = data;
			console.log('getSitesV', getSitesV);
			$.each(getSitesV, function(index, value) {
				entireTerritoryList.push(value);
			});
		},
		error: function(data) {
			aptAlert('Warning', 'Failed to load atollSchema data!');
		}
	});
	$('#siteVersionDb').html('');
	$('#siteVersionDb').multiselect('destroy');
	for (var i = 0; i < getSitesV.length; i++) {
		$('#siteVersionDb').append("<option>" + getSitesV[i].siteVersion
			+ "</option>");
	}
	/* $.each(getSitesV, function (i, v) {
		$('#siteVersionDb').append("<option>" + v.siteVersion
		+ "</option>");
	}); */
	$('#siteVersionDb').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,


	});
}

$('#siteVersionDb').change(function() {
	selectedsiteversion = $('#siteVersionDb').val();

});


function buildCatauto(element) {
	$('#siteVersionDb').html("");
	$('#siteVersionDb').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
		nonSelectedText: 'None selected'
	});
	$(element).catautocomplete({
		minLength: 2,
		delay: 600,
		source: function(request, response) {
			$(element).addClass("ui-autocomplete-loading");
			var term = request.term;
			var suggestions = [];
			runSiteAutocomplete(term).then(function(results) {
				if (!results || !results.data || results.data.length == 0) {
					suggestions.push({ label: "Not Found.", value: "Not found.", category: "Site Results" });
					siteNameGlobal = term;
					// fuzeSiteIdGlobal = term;
				} else {
					var obj = _.map(results.data, function convertResult(result) {
						return {
							// label: result.NAME,
							label: "(" + result.VZ_SITE_INFO_ID + ") " + result.VZ_SITE_NAME,
							value: result.VZ_SITE_NAME,
							siteName: result.VZ_SITE_NAME,
							fuzeSiteId: result.VZ_SITE_INFO_ID,
							category: "Site Results",
						};
					});
					suggestions = obj
					//	getSiteVersion();
				}
				response(_.flatten(_.filter(suggestions, Boolean)));
				$(element).removeClass("ui-autocomplete-loading");
			});
		},
		select: function(event, ui) {
			$(element).removeClass("ui-autocomplete-loading");
			// fuzeSiteIdGlobal = ui.item.fuzeSiteId;
			////console.log(event);
			selectedSitename = ui.item.siteName;
			var temp = $('#siteVersionDb').val();
			if (temp != null && selectedSitename != '') {
				$('#siteVersionDb').html("");
				$('#siteVersionDb').multiselect("rebuild");
				$('#siteVersionDb').multiselect({
					includeSelectAllOption: true,
					enableFiltering: true,
					enableCaseInsensitiveFiltering: true,
					buttonClass: 'btn btn-default whitebg btn-sm',
					numberDisplayed: 1,
					nonSelectedText: 'None selected'
				});
			}
			getSiteVersion(ui.item.siteName, sechmaList);

		}
	});
}

function runSiteAutocomplete(term, response) {
	if (siteAutoAjax) {
		siteAutoAjax.abort();
		siteAutoAjax = null;
	}
	selectedsiteversion = [];
	$('#siteVersionDb').html("");
	$('#siteVersionDb').multiselect("rebuild");
	$('#siteVersionDb').multiselect('deselectAll', false);
	$('#siteVersionDb').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
		nonSelectedText: 'None selected'
	});
	term = term.toUpperCase();
	siteAutoAjax = $.get(CONTEXT_PATH + "/uui/eapp/atoll_pg/siteAutocomplete", { query: term, atollSchema: $('#atollSchemaDropdown').val() }).success().error(
		function handleError(error) {
			// console.error("Something went wrong with the site search", error);
			return [];
		}
	);
	return siteAutoAjax;
}

function getVirtualAssignmentSummeryDetails() {
	resetStoredValues();
	updatedPayloadData = [];
	if (Editcount !== 0 && !(editFlag)) {
		$("#loading").hide();
		$("#atollUpdateTableCheck").show();
	}
	else {
		Editcount = 0;
		atollTramitterData = [];
		spreadsheetTransmitterObj.resetFilters();
		phyLteFlag = true;

		$("#atollUpdateTabs li").removeClass('active');
		$("#atollUpdateTabs li:first").addClass('active');

		if (sechmaList || commonSchemaSearchPayload.atollSchema) {
			if (sechmaList != 'None Selected') {
				populate5GTables(1);
			}
		}
		$("#atollSearchCriteria").show();
		$("#loading").show();
             $("#fiveGVirtualView").hide();
			$("#fiveGVirtualDuIdss").hide();
			direction= "middle";
		movingMiddlefromright();
		movingMiddle();
if (Object.keys(featureToggleMap).includes("F90711") && featureToggleMap['F90711']) {
			console.log(commonSchemaSearchPayload);
			sechmaList = commonSchemaSearchPayload.atollSchema;
			siteNameOrSiteId =  commonSchemaSearchPayload.siteName;
			selectedsiteversion = commonSchemaSearchPayload.siteVersion
			selectedSitename = commonSchemaSearchPayload.siteName;
		} else {
		sechmaList = $('#atollSchemaDropdown').val();
		siteNameOrSiteId = document.getElementById('siteName').value;
}

		// getAtollMarketDb(sechmaList);

		if (sechmaList == 'None Selected' || (sechmaList == '' && siteNameOrSiteId == '') || siteNameOrSiteId == '' || (marketIdOrName == '' && marketIdOrName == undefined) || ($('#atollUpdateRightSiteVersion').val() == '') || ($('#atollUpdateRightSiteVersion').val() == undefined)) {
			$("#loading").hide();
			alert('Please Select All the Mandatory Dropdowns');
			sechmaList = '';
			spreadsheetTransmitterObj.destroy();
			creatingJSpreadsheeteAsiignment(dynamicAssignmentcolumns, spreadsheetAssignmet);
		}
		else if (siteNameOrSiteId != selectedSitename) {
			phyLteFlag = false;
			alert("Incorrect Site Selected. Please choose from dropdown");
			spreadsheetTransmitterObj.destroy();
			$("#loading").hide();
			creatingJSpreadsheeteAsiignment(dynamicAssignmentcolumns, spreadsheetAssignmet);
			assignmentFiveGVirtualTable();
			$("#physicalTabView").hide();
			$("#marketLTETabs").hide();
		}
		else {
			assignmentVirtualPayload = {

				atollSchema: sechmaList,
				siteName: selectedSitename,
				siteVersion: selectedsiteversion,
			}
			$("#atollMarketDb").multiselect("enable");
			$("#atollUpdateRightSiteVersion").multiselect("enable");
			setTimeout(() => {
				$("#loading").addClass('loading-icon');
			$.ajax({
				async: false,
				url: getGNBENBAtollInfoURL,
				//url: 'http://localhost:8100/npp-atoll-services/enbgnbAssignment/getGNBENBAtollInfo',
				dataType: 'json',
				data: JSON.stringify(assignmentVirtualPayload),
				type: "POST",
				contentType: 'application/json; charset=UTF-8',
				headers: {
					'Accept': 'application/json, text/plain, */*',
					'Content-Type': 'application/json'
				},
				success: function(data) {
					$("#loading").removeClass('loading-icon');
					spreadsheetTransmitterObj.destroy();
					//atollPushData = dummyObj;
					atollPushData = data;
					//copying data to temp object for subTask - 11979
					atollPushDataTemp = JSON.parse(JSON.stringify(data));

					// atollPushDataCopy = Array.from(atollPushDataTemp);

					atollPushDataCopy = atollPushDataTemp.slice();


					creatingJSpreadsheeteAsiignment(dynamicAssignmentcolumns, spreadsheetAssignmet, atollPushData);
					$("#loading").hide();

					for (var i = 0; i < atollPushData.length; i++) {
						if (atollPushData[i].transmitter) {
							atollTramitterData.push(atollPushData[i].transmitter);
						}
					}
					if (atollTramitterData.length === 0) {
						alert("No Records For Site Version");
					}
									},
				error: function(data) {
					spreadsheetTransmitterObj.destroy();
					$("#loading").hide();
					$("#atollMarketDb").multiselect("disable");
					creatingJSpreadsheeteAsiignment(dynamicAssignmentcolumns, spreadsheetAssignmet, atollPushData);
					aptAlert('Warning', 'Failed to load atollInfo data!');
					$("#loading").removeClass('loading-icon');

				}
			});
			})
			rightSidePanelResultSet();

		}



	}
}
var excelData5G;
function rightSidePanelResultSet() {

	marketIdOrName = $('#atollMarketDb').val();
	var assignmentFiveGVirtualPayload = {
		atollSchema: sechmaList,
		marketName: marketIdOrName,
		validationFlag: [
			""
		],
		vendor: "",
		vzGnodebId: "",
		siteVersions:$("#atollUpdateRightSiteVersion").val()

	}
	if(marketIdOrName == null) {
		alert("Please Select search criteria and Click on Search");
		fiveGVirtualDataSource ='';
			assignmentEmptyTable("#assignFiveGVirtualGrid", fiveGVirtualDataSource, assignmentGridColumns);
			$("#assignFiveGVirtualGrid").show();
	} else {
	$.ajax({
		async: false,
		url: enbgnbAssignmentUrl,
		//url: 'http://localhost:8100/npp-atoll-services/enbgnbAssignment/fetchGnbData',
		dataType: 'json',
		data: JSON.stringify(assignmentFiveGVirtualPayload),
		type: "POST",
		contentType: 'application/json; charset=UTF-8',
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function(data) {
			atoll5GData = data;
			excelData5G = data;
			/* $('#assignFiveGVirtualGrid')
				.getKendoGrid()
				.setDataSource(
					new kendo.data.DataSource({
						pageSize: 25,
						data: atoll5GData,
					})
				); */
				assignmentEmptyTable("#assignFiveGVirtualGrid", atoll5GData, assignmentGridColumns);

			$("#loading").hide();
		},
		error: function(data) {
			//assignmentFiveGVirtualTable();
			fiveGVirtualDataSource ='';
			assignmentEmptyTable("#assignFiveGVirtualGrid", fiveGVirtualDataSource, assignmentGridColumns);
			$("#assignFiveGVirtualGrid").show();
			$("#loading").hide();
			if(!($("#atollUpdateRightSiteVersion").val())){
				alert('Kindly select at least one Site Version');
			}else{
				aptAlert('Warning', 'Failed to load atollInfo data!');
			}
		}
	});
}
}

$("#confirmBtn").on("click", function() {
	if (Editcount !== 0)
		$('#atollUpdateTableCheck').show();
	else
		getVirtualAssignmentSummeryDetails();



});

function closeUpdateRevisionDialog() {
	$('#UpdateRevisionDialog').hide();
}

var alreadyMandatoryFieldsMsgShown = false;
var allAtollEditedDataCorrect = true;
var atollUpdateValidationFlag = false;
var allAtollEditedDataAjaxCall = true;
function commonCodeForValidation() {
	$("#loading").hide()
	if(!atollUpdateValidationFlag) {
		alert("Please Select All the Mandatory Fields");
		atollUpdateValidationFlag = true;
	}


	allAtollEditedDataAjaxCall = false;
	movingMiddle();
	$('#UpdatePopupDialog').hide();
}
function updateVirtualAssignmentSummery() {


	allAtollEditedDataAjaxCall = true;
	atollUpdateValidationFlag = false;
	if (Object.keys(featureToggleMap).includes("F90617") && featureToggleMap['F90617']) {
		$("#loading").hide();
		var editRows = document.getElementsByTagName('tbody')[4].rows;
		showExceededAlert();
		for(var k = 0; k < editRows.length; k++) {
			if(editRows[k].cells[6].innerHTML == "LTE" && editRows[k].cells[7].innerHTML == "5GDU") {
				if ((editRows[k].cells[10].innerHTML == "" || editRows[k].cells[19].innerHTML == "" || editRows[k].cells[20].innerHTML == "")) {
					commonCodeForValidation();
					if (editRows[k].cells[10].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[10].style.backgroundColor = "red";
					}

					if (editRows[k].cells[19].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[19].style.backgroundColor = "red";
					}

					if (editRows[k].cells[20].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[20].style.backgroundColor = "red";
					}

				}
			} else if (editRows[k].cells[6].innerHTML == "LTE" && editRows[k].cells[7].innerHTML == "4G5G") {

				if ((editRows[k].cells[11].innerHTML == "" || editRows[k].cells[12].innerHTML == "" || editRows[k].cells[15].innerHTML == "" || editRows[k].cells[16].innerHTML == "" || editRows[k].cells[10].innerHTML == "" || editRows[k].cells[19].innerHTML == "" || editRows[k].cells[20].innerHTML == "")) {
					commonCodeForValidation();
					if (editRows[k].cells[11].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[11].style.backgroundColor = "red";
					} if (editRows[k].cells[12].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[12].style.backgroundColor = "red";
					}
					if (editRows[k].cells[15].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[15].style.backgroundColor = "red";
					}
					if (editRows[k].cells[16].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[16].style.backgroundColor = "red";
					}
					if (editRows[k].cells[10].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[10].style.backgroundColor = "red";
					}

					if (editRows[k].cells[19].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[19].style.backgroundColor = "red";
					}

					if (editRows[k].cells[20].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[20].style.backgroundColor = "red";
					}

				}
			} else if (editRows[k].cells[6].innerHTML == 'LTE' && editRows[k].cells[7].innerHTML == "") {

					if ((editRows[k].cells[10].innerHTML == "" || editRows[k].cells[19].innerHTML == "" || editRows[k].cells[20].innerHTML == "")) {
						commonCodeForValidation();
						if (editRows[k].cells[10].innerHTML == "") {
							document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[10].style.backgroundColor = "red";
						}

						if (editRows[k].cells[19].innerHTML == "") {
							document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[19].style.backgroundColor = "red";
						}

						if (editRows[k].cells[20].innerHTML == "") {
							document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[20].style.backgroundColor = "red";
						}

					}
			} else if (editRows[k].cells[6].innerHTML == '5G NR') {

				if ((editRows[k].cells[9].innerHTML == "" || editRows[k].cells[11].innerHTML == "" || editRows[k].cells[12].innerHTML == "" || editRows[k].cells[15].innerHTML == "" || editRows[k].cells[16].innerHTML == "" || editRows[k].cells[13].innerHTML == "")) { // && i == (parseInt(rowNumber) + 1)
					commonCodeForValidation();
					if (editRows[k].cells[9].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[9].style.backgroundColor = "red";
					}
					if (editRows[k].cells[11].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[11].style.backgroundColor = "red";
					}
					if (editRows[k].cells[13].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[13].style.backgroundColor = "red";
					}
					if (editRows[k].cells[12].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[12].style.backgroundColor = "red";
					}
					if (editRows[k].cells[15].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[15].style.backgroundColor = "red";
					}
					if (editRows[k].cells[16].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[16].style.backgroundColor = "red";
					}

				}
			} else if(editRows[k].cells[6].innerHTML == '5G NR;LTE') {

				if ((editRows[k].cells[9].innerHTML == "" || editRows[k].cells[11].innerHTML == "" || editRows[k].cells[12].innerHTML == "" || editRows[k].cells[13].innerHTML == "" || editRows[k].cells[15].innerHTML == "" || editRows[k].cells[16].innerHTML == "" || editRows[k].cells[10].innerHTML == "" || editRows[k].cells[19].innerHTML == "" || editRows[k].cells[20].innerHTML == "")) {
					commonCodeForValidation();
					if (editRows[k].cells[9].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[9].style.backgroundColor = "red";

					}

					if (editRows[k].cells[10].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[10].style.backgroundColor = "red";
					}
					if (editRows[k].cells[11].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[11].style.backgroundColor = "red";
					}
					if (editRows[k].cells[13].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[13].style.backgroundColor = "red";
					}
					if (editRows[k].cells[15].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[15].style.backgroundColor = "red";
					}
					if (editRows[k].cells[16].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[16].style.backgroundColor = "red";
					}
					if (editRows[k].cells[12].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[12].style.backgroundColor = "red";
					}

					if (editRows[k].cells[19].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[19].style.backgroundColor = "red";
					}

					if (editRows[k].cells[20].innerHTML == "") {
						document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[k+1].cells[20].style.backgroundColor = "red";
					}

				}
			}

				instance = document.getElementsByClassName('jexcel jexcel_overflow')[1];
				c = k;
				if (editRows[k].cells[6].innerHTML == "LTE" && editRows[k].cells[7].innerHTML == "4G5G") {
					validateGnbIdFirstAndMiddleNum(instance, editRows[k].cells[11], c, k, editRows[k].cells[11].innerHTML);
					conditionsForGnbDuNumber(instance, editRows[k].cells[15], c, k, editRows[k].cells[15].innerHTML);
				} else if(editRows[k].cells[6].innerHTML == '5G NR;LTE') {
					validateGnbIdFirstAndMiddleNum(instance, editRows[k].cells[11], c, k, editRows[k].cells[11].innerHTML);
					conditionsForGnbDuNumber(instance, editRows[k].cells[15], c, k, editRows[k].cells[15].innerHTML);
				} else if (editRows[k].cells[6].innerHTML == '5G NR') {
					validateGnbIdFirstAndMiddleNum(instance, editRows[k].cells[11], c, k, editRows[k].cells[11].innerHTML);
					conditionsForGnbDuNumber(instance, editRows[k].cells[15], c, k, editRows[k].cells[15].innerHTML);
				}

		}

	} else {
		allAtollEditedDataCorrect = true;
	if (!updatedTransmitterGnbDuRecord.length && !updatedTransmitterGnbIDRecord.length) {
		alreadyMandatoryFieldsMsgShown = false;
		$("#loading").show();
		movingMiddle();
		direction = "middle";

		getRowsData = document.getElementById('virtualAssignmentGridInfo').jexcel.getRowData(rowNumber);

		showExceededAlert();
		updatedPayloadData.forEach((element) => {
			getRowsData = element;
			getRowsData[0] = getRowsData[0].replace(/  +/g, ' ');

			if (getRowsData[5] == '5G NR') {
				if ((getRowsData[8] == '' || getRowsData[8] == undefined) || (getRowsData[10] == '' || getRowsData[10] == undefined) || (getRowsData[11] == '' || getRowsData[11] == undefined) || (getRowsData[12] == '' || getRowsData[12] == undefined) || (getRowsData[14] == '' || getRowsData[14] == undefined) || (getRowsData[15] == '' || getRowsData[15] == undefined)) {
					$("#loading").hide();
					if (!alreadyMandatoryFieldsMsgShown) {
						alert("Please Select All the Mandatory Fields");
						alreadyMandatoryFieldsMsgShown = true;
					}
					allAtollEditedDataCorrect = false;

					movingMiddle();
					$('#UpdatePopupDialog').hide();
					for (var i = 0; i < rowupdated.length; i++) {
						if (rowupdated[i].cells[1].innerText == getRowsData[0]) {

							if ((rowupdated[i].cells[9].innerHTML == "" || rowupdated[i].cells[11].innerHTML == "" || rowupdated[i].cells[12].innerHTML == "" || rowupdated[i].cells[15].innerHTML == "" || rowupdated[i].cells[16].innerHTML == "" || rowupdated[i].cells[13].innerHTML == "")) { // && i == (parseInt(rowNumber) + 1)
								if (rowupdated[i].cells[9].innerHTML == "") {
									document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[9].style.backgroundColor = "red";
								}
								if (rowupdated[i].cells[11].innerHTML == "") {
									document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[11].style.backgroundColor = "red";
								}
								if (rowupdated[i].cells[13].innerHTML == "") {
									document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[13].style.backgroundColor = "red";
								}
								if (rowupdated[i].cells[12].innerHTML == "") {
									document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[12].style.backgroundColor = "red";
								}
								if (rowupdated[i].cells[15].innerHTML == "") {
									document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[15].style.backgroundColor = "red";
								}
								if (rowupdated[i].cells[16].innerHTML == "") {
									document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[16].style.backgroundColor = "red";
								}

							}

						}
					}
				}

			} else if (getRowsData[5] == '5G NR;LTE') {
				if ((getRowsData[8] == '' || getRowsData[8] == undefined) || (getRowsData[9] == '' || getRowsData[9] == undefined) || (getRowsData[10] == '' || getRowsData[10] == undefined) || (getRowsData[11] == '' || getRowsData[11] == undefined) || (getRowsData[12] == '' || getRowsData[12] == undefined) || (getRowsData[19] == '' || getRowsData[19] == undefined) || (getRowsData[14] == '' || getRowsData[14] == undefined) || (getRowsData[15] == '' || getRowsData[15] == undefined) || (getRowsData[18] == '' || getRowsData[18] == undefined)) {
					$("#loading").hide();
					if (!alreadyMandatoryFieldsMsgShown) {
						alert("Please Select All the Mandatory Fields");
						alreadyMandatoryFieldsMsgShown = true;
					}
					allAtollEditedDataCorrect = false;

					movingMiddle();
					$('#UpdatePopupDialog').hide();
					for (var i = 0; i < rowupdated.length; i++) {
						if (rowupdated[i].cells[1].innerText == getRowsData[0]) {
							if ((rowupdated[i].cells[9].innerHTML == "" || rowupdated[i].cells[11].innerHTML == "" || rowupdated[i].cells[12].innerHTML == "" || rowupdated[i].cells[13].innerHTML == "" || rowupdated[i].cells[15].innerHTML == "" || rowupdated[i].cells[16].innerHTML == "" || rowupdated[i].cells[10].innerHTML == "" || rowupdated[i].cells[19].innerHTML == "" || rowupdated[i].cells[20].innerHTML == "")) {
								if (rowupdated[i].cells[9].innerHTML == "") {
									document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[9].style.backgroundColor = "red";

								}

								if (rowupdated[i].cells[10].innerHTML == "") {
									document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[10].style.backgroundColor = "red";
								}
								if (rowupdated[i].cells[11].innerHTML == "") {
									document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[11].style.backgroundColor = "red";
								}
								if (rowupdated[i].cells[13].innerHTML == "") {
									document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[13].style.backgroundColor = "red";
								}
								if (rowupdated[i].cells[15].innerHTML == "") {
									document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[15].style.backgroundColor = "red";
								}
								if (rowupdated[i].cells[16].innerHTML == "") {
									document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[16].style.backgroundColor = "red";
								}
								if (rowupdated[i].cells[12].innerHTML == "") {
									document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[12].style.backgroundColor = "red";
								}

								if (rowupdated[i].cells[19].innerHTML == "") {
									document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[19].style.backgroundColor = "red";
								}

								if (rowupdated[i].cells[20].innerHTML == "") {
									document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[20].style.backgroundColor = "red";
								}

							}
						}
					}

				}

			} 	if (getRowsData[5] == 'LTE' && getRowsData[6] == '4G5G') {
					if ((getRowsData[9] == '' || getRowsData[9] == undefined) || (getRowsData[18] == '' || getRowsData[18] == undefined) || (getRowsData[19] == '' || getRowsData[19] == undefined) || (getRowsData[10] == '' || getRowsData[10] == undefined) || (getRowsData[11] == '' || getRowsData[11] == undefined) || (getRowsData[14] == '' || getRowsData[14] == undefined) || (getRowsData[15] == '' || getRowsData[15] == undefined)) {
						$("#loading").hide();
						if (!alreadyMandatoryFieldsMsgShown) {
						alert("Please Select All the Mandatory Fields");
							alreadyMandatoryFieldsMsgShown = true;
						}
						allAtollEditedDataCorrect = false;

						movingMiddle();
						$('#UpdatePopupDialog').hide();
						for (var i = 0; i < rowupdated.length; i++) {
							if (rowupdated[i].cells[1].innerText == getRowsData[0]) {
								if ((rowupdated[i].cells[11].innerHTML == "" || rowupdated[i].cells[12].innerHTML == "" || rowupdated[i].cells[15].innerHTML == "" || rowupdated[i].cells[16].innerHTML == "" || rowupdated[i].cells[10].innerHTML == "" || rowupdated[i].cells[19].innerHTML == "" || rowupdated[i].cells[20].innerHTML == "")) {
									if (rowupdated[i].cells[11].innerHTML == "") {
										document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[11].style.backgroundColor = "red";
									} if (rowupdated[i].cells[12].innerHTML == "") {
										document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[12].style.backgroundColor = "red";
									}
									if (rowupdated[i].cells[15].innerHTML == "") {
										document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[15].style.backgroundColor = "red";
									}
									if (rowupdated[i].cells[16].innerHTML == "") {
										document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[16].style.backgroundColor = "red";
									}
									if (rowupdated[i].cells[10].innerHTML == "") {
										document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[10].style.backgroundColor = "red";
									}

									if (rowupdated[i].cells[19].innerHTML == "") {
										document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[19].style.backgroundColor = "red";
									}

									if (rowupdated[i].cells[20].innerHTML == "") {
										document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[20].style.backgroundColor = "red";
									}

								}
							}
						}

					}


				} else if (getRowsData[5] == 'LTE' && getRowsData[6] == '5GDU') {
					if ((getRowsData[9] == '' || getRowsData[9] == undefined) || (getRowsData[18] == '' || getRowsData[18] == undefined) || (getRowsData[19] == '' || getRowsData[19] == undefined)) {
						$("#loading").hide();
						if (!alreadyMandatoryFieldsMsgShown) {
						alert("Please Select All the Mandatory Fields");
							alreadyMandatoryFieldsMsgShown = true;
						}
						allAtollEditedDataCorrect = false;
						movingMiddle();
						$('#UpdatePopupDialog').hide();
						for (var i = 0; i < rowupdated.length; i++) {
							if (rowupdated[i].cells[1].innerText == getRowsData[0]) {
								if ((rowupdated[i].cells[10].innerHTML == "" || rowupdated[i].cells[19].innerHTML == "" || rowupdated[i].cells[20].innerHTML == "")) {
									if (rowupdated[i].cells[10].innerHTML == "") {
										document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[10].style.backgroundColor = "red";
									}

									if (rowupdated[i].cells[19].innerHTML == "") {
										document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[19].style.backgroundColor = "red";
									}

									if (rowupdated[i].cells[20].innerHTML == "") {
										document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[20].style.backgroundColor = "red";
									}

								}
							}
						}
					}


				} else if (getRowsData[5] == 'LTE' && getRowsData[6] == "") {
					if ((getRowsData[9] == '' || getRowsData[9] == undefined) || (getRowsData[18] == '' || getRowsData[18] == undefined) || (getRowsData[19] == '' || getRowsData[19] == undefined)) {
						$("#loading").hide();
						if (!alreadyMandatoryFieldsMsgShown) {
						alert("Please Select All the Mandatory Fields");
							alreadyMandatoryFieldsMsgShown = true;
						}
						allAtollEditedDataCorrect = false;
						movingMiddle();
						$('#UpdatePopupDialog').hide();
						for (var i = 0; i < rowupdated.length; i++) {
							if (rowupdated[i].cells[1].innerText == getRowsData[0]) {
								if ((rowupdated[i].cells[10].innerHTML == "" || rowupdated[i].cells[19].innerHTML == "" || rowupdated[i].cells[20].innerHTML == "")) {

									if (rowupdated[i].cells[10].innerHTML == "") {
										document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[10].style.backgroundColor = "red";
									}

									if (rowupdated[i].cells[19].innerHTML == "") {
										document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[19].style.backgroundColor = "red";
									}

									if (rowupdated[i].cells[20].innerHTML == "") {
										document.getElementsByClassName('jexcel jexcel_overflow')[1].rows[i].cells[20].style.backgroundColor = "red";
									}

								}
							}
						}

					}
				}
		});
		if (allAtollEditedDataCorrect) {
			showPopupDialogBeforAfter();
		} else {
			$("#loading").hide();
				}

	} else {
		$("#loading").hide();
		document.getElementById("updateBtn").disabled = true;
		alert("Please correct Highlighted Cells");
	}
}
	if(allAtollEditedDataAjaxCall) {
		if (!updatedTransmitterGnbDuRecord.length && !updatedTransmitterGnbIDRecord.length) {
			showPopupDialogBeforAfter();
		} else {
			$("#loading").hide();
			document.getElementById("updateBtn").disabled = true;
			alert("Please correct Highlighted Cells");
		}

	} else {
		$("#loading").hide();
	}
}


var editedDataOnly = [];
function showExceededAlert() {
	for (var i = 0; i < spreadsheetTransmitterObj.options.data.length; i++) {
		if (spreadsheetTransmitterObj.options.data[i][8].toString().length > 4) {
			alert("5G Sector limit exceeded More Than 4");
			$("#loading").hide();
			cellValueExceeded = true;
			throw new Error('5G Sector limit exceeded More Than 4');
			// return;
		}
		if (spreadsheetTransmitterObj.options.data[i][10].toString().length > 7) {
			alert("Gnb Id limit exceeded More Than 7");
			$("#loading").hide();
			cellValueExceeded = true;
			throw new Error('Gnb Id limit exceeded More Than 7');
		}
		if (spreadsheetTransmitterObj.options.data[i][14].toString().length > 4) {
			alert("Gnb Du Number limit exceeded More Than 4");
			$("#loading").hide();
			cellValueExceeded = true;
			throw new Error('Gnb Du Number limit exceeded More Than 4');
		}
		if (spreadsheetTransmitterObj.options.data[i][18].toString().length > 6) {
			alert("Enb Du Number limit exceeded More Than 6");
			$("#loading").hide();
			cellValueExceeded = true;
			throw new Error('Enb Du Number limit exceeded More Than 6');
		}
	}
}
function showPopupDialogBeforAfter() {
	var editRowsForJspreasheet = {};
	var getEditRowsJs = [];
	for (var i = 0; i < updatedPayloadData.length; i++) {
		editRowsForJspreasheet =
		{
			"transmitter": updatedPayloadData[i][0],
			"site": updatedPayloadData[i][1],
			"siteVersion": updatedPayloadData[i][2],
			"frequencyBand": updatedPayloadData[i][3],
			"gNBeNBVendor": updatedPayloadData[i][4],
			"rat": updatedPayloadData[i][5],
			"neMode": updatedPayloadData[i][6],
			"neName": updatedPayloadData[i][7],
			"fiveGSector": updatedPayloadData[i][8],
			"lteSector": updatedPayloadData[i][9],
			"gNBId": updatedPayloadData[i][10],
			"gNBFriendlyName": updatedPayloadData[i][11],
			"gNBMixedModeLabel": updatedPayloadData[i][12],
			"gNBName": updatedPayloadData[i][13],
			"gNBDUNumber": updatedPayloadData[i][14],
			"gNBDUFriendlyname": updatedPayloadData[i][15],
			"gNBDUId": updatedPayloadData[i][16],
			"gNBDUName": updatedPayloadData[i][17],
			"eNBID": updatedPayloadData[i][18],
			"eNBFriendlyName": updatedPayloadData[i][19],
			"eNBName": updatedPayloadData[i][20],
			"modifiedTS": updatedPayloadData[i][21],
			"dbRecordId": updatedPayloadData[i][22],
			"atollSchema": sechmaList,
			"isModified": updatedPayloadData[i][23],
		}
		getEditRowsJs.push(editRowsForJspreasheet);
	}

	for (var i = 0; i < atollPushDataTemp.length; i++) {
		atollPushDataTemp[i]["vzid"] = VZID;
		if (atollPushDataTemp[i].isModified == 1) {
			editedDataOnly.push(atollPushDataTemp[i])
		}
	}

	for (var i = 0; i < atollPushDataTemp.length; i++) {
		if (atollPushDataTemp[i].isModified == 1) {
			if (atollPushDataTemp[i].gNBDUFriendlyname) {
				atollPushDataTemp[i].gNBDUFriendlyname = atollPushDataTemp[i].gNBDUFriendlyname.toUpperCase();
			}
		}
	}

if (editedDataOnly.length > 0) {
	$.ajax({
		type: 'POST',
		url: pushGnbEnbDataToAtollURL,
		//url: 'http://localhost:8100/npp-atoll-services/enbgnbAssignment/pushGnbEnbDataToAtoll',
		contentType: 'application/json',
		cache: false,
		data: JSON.stringify(editedDataOnly),
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},

		success: function(data) {
			$("#loading").hide();
			console.log(data);
			updatedPayloadData = [];
			editedDataOnly = [];
			if (data && data['After Update'].Data != null && data['After Update'].Data != undefined && data['After Update'].Data.length != 0) {
				$('#UpdatePopupDialog').show();
				if (updatePopupSpreadsheetObjBef != undefined || updatePopupSpreadsheetObjAft != undefined) {
					updatePopupSpreadsheetObjBef.destroy();
					updatePopupSpreadsheetObjAft.destroy();
				}
				creatingJSpreadsheeteAsiignment(dynamicAssignmentcolumns, 'updatePopupBefore', data['Before Update']);
				creatingJSpreadsheeteAsiignment(dynamicAssignmentcolumns, 'updatePopupAfter', data['After Update'].Data);

				if (data['After Update'].VzApplyAllResponse != null && data['After Update'].VzApplyAllResponse != undefined) {
					var vzApplyNameconf = JSON.stringify(data['After Update'].VzApplyAllResponse.NameConfresponse);
					var vzApplyTotalLoss = JSON.stringify(data['After Update'].VzApplyAllResponse.TotalLossesresponse);
					var vzApplyVendorPow = JSON.stringify(data['After Update'].VzApplyAllResponse.VendorPwrresponse);
					$('#nameConf').html(vzApplyNameconf);
					$('#totalLoss').html(vzApplyTotalLoss);
					$('#vendorPwr').html(vzApplyVendorPow);
				}

			}

			else if (data && data['After Update'].ERROR) {
				$('#updateErrorPopup').show();
				var vzApplyError = JSON.stringify(data['After Update'].ERROR.ERROR);
				$('#errorMsg').html(vzApplyError);
			}

			else {
				aptAlert('error', 'EMPTY RESPONSE')
			}
			resetStoredValues();


		},
		error: function(data) {
			$("#loading").hide();
			movingMiddle();
			updatedPayloadData = [];
			editedDataOnly = [];
			aptAlert('error', 'Failed to update');
		}
	});
	console.log('getEditRows', getEditRowsJs);
} else {
	alert('Data Not edited');
	$("#loading").hide();
	document.getElementById("updateBtn").disabled = true;
}
}


function clearAtollUpdate() {
	fetchGnbDUNumbers='';
	fetchGnbIdRows='';
	virtualDuIds='';
	virtualFiveGData='';
	excelData5G='';
	atoll5GData = [];
	sechmaList = "None Selected";
	marketIdOrName = null;
	direction= "middle";
		movingMiddlefromright();
		movingMiddle();
	$('#atollMarketDb').val('');
	$('#atollUpdateRightSiteVersion').html('');
	document.getElementById("updateBtn").disabled = true;
	$.each(siteDropdownList, function(i, v) {
		if(v=="0000"||v=="0001"||v=="0FAA"){
		$('#atollUpdateRightSiteVersion').append("<option selected>" + v + "</option>");
		}else{
			$('#atollUpdateRightSiteVersion').append("<option>" + v + "</option>");
		}
	});
	siteVersions = $('#atollUpdateRightSiteVersion').val();

	if (Editcount !== 0) {
		$("#loading").hide();
		$("#atollUpdateResetCheck").show();
	}
	else {
		Editcount = 0;
		clearCommonSearchDropdown();
		$("#atollUpdateTabs li").removeClass('active');
		$("#atollUpdateTabs li:first").addClass('active');
		//populate5GTables(1);
		phyLteFlag = false;
		$("#virtualAssignmentGridInfo").html("");
		$('#atollSchemaDropdown').html("");
		$('#atollSchemaDropdown').multiselect("rebuild");
		$('#atollSchemaDropdown').multiselect({
			includeSelectAllOption: true,
			enableFiltering: true,
			enableCaseInsensitiveFiltering: true,
			buttonClass: 'btn btn-default whitebg btn-sm',
			numberDisplayed: 1,
			nonSelectedText: 'None selected'
		});
		$('#siteVersionDb').html("");
		$('#siteVersionDb').multiselect("rebuild");
		$('#siteVersionDb').multiselect({
			includeSelectAllOption: true,
			enableFiltering: true,
			enableCaseInsensitiveFiltering: true,
			buttonClass: 'btn btn-default whitebg btn-sm',
			numberDisplayed: 1,
			nonSelectedText: 'None selected'
		});
		$('#atollUpdateRightSiteVersion').multiselect({
			includeSelectAllOption: true,
			enableFiltering: true,
			enableCaseInsensitiveFiltering: true,
			buttonClass: 'btn btn-default whitebg btn-sm',
			numberDisplayed: 1
		});
		$("#atollUpdateRightSiteVersion").multiselect("disable");
		getUserSchema();
		$("#siteName").val('');
		$("#assignFiveGVirtualGrid").show();
		fiveGVirtualDataSource = '';
		assignmentEmptyTable("#assignFiveGVirtualGrid", fiveGVirtualDataSource, assignmentGridColumns);
		$("#fiveGVirtualDuIdss").hide();
		$("#fiveGVirtualView").hide();
		clearAssignmentDropdowns('#atollMarketDb');
		$("#atollMarketDb").multiselect("disable");
		spreadsheetTransmitterObj.destroy();
		creatingJSpreadsheeteAsiignment(dynamicAssignmentcolumns, spreadsheetAssignmet);
	}
}

function confirmAtollPush() {
	$('#atollUpdateRefreshCheck').hide();
	editFlag = true;
	getVirtualAssignmentSummeryDetails();
	editFlag = false;
	closeUpdateRevisionDialog();
}

function cancelAtollPush() {
	$('#atollUpdateRefreshCheck').hide();
	closeUpdateRevisionDialog();
}

function closeUpdatePopupDialog() {
	$("#loading").show();
	//$("#toggleCharts-left").show();
	confirmAtollPush();
	$('#UpdatePopupDialog').hide();
	$('#loading').hide();
}

function closeErrorUpdatePopup() {
	$("#loading").show();
	$('#updateErrorPopup').hide();
	$('#loading').hide();
}

function aptAlert(status, message) {
	$("#alertsuccess").hide();
	$("#alerterror").hide();
	//$("#alertinfo").hide();
	$("#alertwarning").hide();

	$("#alertTitle1").html(status + '!');
	$("#alert" + status.toLowerCase()).html(message);
	$("#alert" + status.toLowerCase()).show();
	$("#myModal").css(
		"margin-top",
		Math.max(0, ($(window).height() - ($("#myModal").height() + 100)) / 2));
	$("#myModal").css(
		"margin-left",
		Math.max(0, ($(window).width() - $("#myModal").width()) / 2));
	$("#myModal").modal("show");
}

function cancelPopup() {
	$('#loading').hide();
	$('#atollUpdateTableCheck').hide();
	$('#configurationTabChanges').hide();
}

function proceedSearch() {
	Editcount = 0;
	resetStoredValues();
	direction= "middle";
	getVirtualAssignmentSummeryDetails();
	$('#atollUpdateTableCheck').hide();
}
function cancelPopupForReset() {
	$('#loading').hide();
	$('#atollUpdateResetCheck').hide();
	document.getElementById("updateBtn").disabled = false;
}

function proceedReset() {
	Editcount = 0;
	clearAtollUpdate();
	$('#atollUpdateResetCheck').hide();

}

function fetchAOR(VZID) {
	if (Object.keys(featureToggleMap).includes("F9488") && featureToggleMap['F9488']) {
		getPhysicaleExpVendorList();
		getDuExpVendorList();
	}
	aorArea = [];
	aorTerritory = [];
	aorRegion = "";
	aorMarket = "";

	$.ajax({
		type: 'POST',
		contentType: 'application/json',
		cache: false,
		url: getAORPreferencesURL + VZID,
		// url: 'http://localhost:8100/npp-atoll-services/enbgnbAssignment/getAORPreferences?vzId=' + VZID,
		dataType: 'json',
		//data: JSON.stringify(VZID),
		//data: VZID,
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function(data) {
		marketInAorAvailable=data.market
		getMarketName=data.market
		gnbAssignTerritoryList = data.territory;
			gnbAssignAreaList = data.area;
			gnbAssignRegionList = data.region;
			console.log("DATA---", data);
			var AORdata = data;
			aorArea = data.area;
			aorTerritory = data.territory;
			aorRegion = data.region;
			aorMarket = data.market;
			//  var marVal=$('aMarketDropdown').val();
			//  console.log("MARKET VALUE--",marVal);
			$('#areaDropdown').html('');
			$('#areaDropdown').multiselect('destroy');
			$('#territoryDropdown').html('');
			$('#territoryDropdown').multiselect('destroy');
			populateAssignmentTerritory(true);
			if (data.territory != null)
				populateAssignmentAreas(data.territory, true);
			if (data.area != null) {
				if (data.region == null)
					regionFlag = true;
				populateAssignmentRegions(data.area, true);
			}
			if (data.region != null) {
				if (data.market == null)
					marketFlag = true
				populateAssignmentMarkets(data.region, true);
			}
			marketsSelected = $('#marketDropdown').val();
			selectedMarketList = [];
			selectedMarketList.push(marketsSelected);
			if (selectedMarketList[0] != null && gNodeBSelected) {
					populatevvendorDropdownforAssignment(selectedMarketList);
			}
			if(marketInAorAvailable){
				$('#siteVersionDropdownId').html('');
				$('#siteVersionDropdownId').multiselect('destroy');
				$.each(siteDropdownList, function(i, v) {
					if(v=="0000"||v=="0001"||v=="0FAA"){
						$('#siteVersionDropdownId').append("<option selected>" + v + "</option>");
					}else{
						$('#siteVersionDropdownId').append("<option>" + v + "</option>");
					}
				});
			$('#siteVersionDropdownId').multiselect({
				includeSelectAllOption: true,
				enableFiltering: true,
				enableCaseInsensitiveFiltering: true,
				buttonClass: 'btn btn-default whitebg btn-sm',
				numberDisplayed: 1
			});

			}
	// 		// var marVal=$('aMarketDropdown').val();
	// 		// console.log("MARKET VALUE--",marVal);
	// 		//if(data.market!= null)
	// 		//populatevvendorDropdownforAssignment(data.market);
	// 		gnbAssignTerritoryList = data.territory;
	// 		gnbAssignAreaList = data.area;
	// 		gnbAssignRegionList = data.region;
	// 		//marketsSelected.push("113");
	// 		//if(tabIndex == "2"){
	// 		// $('#vAreaDropdown').html('');
	// 		// $('#vAreaDropdown').multiselect('destroy');
	// 		// $('#vterritoryDropdown').html('');
	// 		// $('#vterritoryDropdown').multiselect('destroy');
	// 		// populateValidationTerritory(true);
	// 		// if (data.territory != null)
	// 		//  populateValidationAreas(data.territory, true);
	// 		// if (data.area != null && data.region != null)
	// 		//  populateValidationRegions(data.area, true);
	// 		// if (data.region != null & data.market != null)
	// 		//  populateValidationMarkets(data.region, true);
	// 		// gnbValidTerritoryList = data.territory;
	// 		// gnbValidAreaList = data.area;
	// 		// gnbValidRegionList = data.region;
	// 		// //if(gbEbIndex==2){
	// 		// //if(tabIndex == "1"){
	// 		// $('#eAAreaDropdown').html('');
	// 		// $('#eAAreaDropdown').multiselect('destroy');
	// 		// $('#eAterritoryDropdown').html('');
	// 		// $('#eAterritoryDropdown').multiselect('destroy');
	// 		// populateAssignmentTerritory(true);
	// 		// if (data.territory != null)
	// 		//  populateAssignmentAreas(data.territory, true);
	// 		// if (data.area != null && data.region != null)
	// 		//  populateAssignmentRegions(data.area, true);
	// 		// if (data.region != null & data.market != null)
	// 		//  populateAssignmentMarkets(data.region, true);
	// 		// //if(tabIndex == "2"){
	// 		// $('#eVAreaDropdown').html('');
	// 		// $('#eVAreaDropdown').multiselect('destroy');
	// 		// $('#eVTerritoryDropdown').html('');
	// 		// $('#eVTerritoryDropdown').multiselect('destroy');
	// 		// populateAssignmentTerritory(true);
	// 		// if (data.territory != null)
	// 		//  populateAssignmentAreas(data.territory, true);
	// 		// if (data.area != null && data.region != null)
	// 		//  populateAssignmentRegions(data.area, true);
	// 		// if (data.region != null & data.market != null)
	// 		//  populateAssignmentMarkets(data.region, true);
		},
		error: function(data) {
			aptAlert('error', 'Failed to show AOR preference!');
		}
	});
}
var typeDropdownList = ['Assignment Capacity Change','Reserve Market Range'];

var siteDropdownList = ['0000','0001','0FAA','0002','5GCB','5GLS'];

function preResetPEPopup() {
//	$('#physicalgNBEVendor').html('');
//	$('#physicalgNBEVendor').multiselect('destroy');
//
//	$.each(physicalgNBEVendorList, function(i, v) {
//		$('#physicalgNBEVendor').append("<option>" + v + "</option>");
//	});
    $('#physicalgNBEVendor').multiselect('destroy');
    $('#physicalgNBEVendor').html('');

    $.each(physicalgNBEVendorList, function(i, v) {
       $('#physicalgNBEVendor').append($('<option></option>').val(v).text(v));
    });
	$('#physicalgNBEVendor').val('', '');
	$('#physicalgNBEVendor').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
		nonSelectedText: 'None selected'
	});

	$('#middleDigitLb').html('');
	$('#middleDigitLb').multiselect('destroy');
	$('#middleDigitLb').val('', '');

	$('#middleDigitLb').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
		nonSelectedText: 'None selected'
	});

	$("#useCaseTextBox").val("");
	useCaseValue = "";
	$('#fr1Fr2').val("");
	selectedFRMappingVal = "";
	// --- FIX 2: DU Expansion Vendor ---
    	$('#duExpansionVendor').multiselect('destroy');
    	$('#duExpansionVendor').html('');

    	$.each(duExpansionVendorList, function(i, v) {
    		$('#duExpansionVendor').append($('<option></option>').val(v).text(v));
    	});

//	$('#duExpansionVendor').html('');
//	$('#duExpansionVendor').multiselect('destroy');
//	$.each(duExpansionVendorList, function(i, v) {
//		$('#duExpansionVendor').append("<option>" + v + "</option>");
//	});
	$('#duExpansionVendor').val('', '');
	$('#duExpansionVendor').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
		nonSelectedText: 'None selected'
	});

	$('#firstDuDigitLb').html('');
	$('#firstDuDigitLb').multiselect('destroy');
	$('#firstDuDigitLb').val('', '');
	resetFirstDuDigitDropdown();

	$("#useCaseTextBoxDu").val("");
	$('#fr1Fr2Du').val("");
	$('#fr1Fr2DuDisplayText').text('');
	selectedFRMappingValDu = "";
}

function resetValues() {

	gnbvirtualDuIds=''
	resultVal = '';
	returnedData = '';
	uniqGnbValidationTextId = "";
	uniqGnbAssignmentTextId = "";
	uniqEnbAssignmentTextId = "";
	uniqEnbValidationTextId = "";
	assignmentDataSource ='';
	getSectorCarrierGridData='';
	assignmentEmptyTable("#assignmentGrid", assignmentDataSource, assignmentGridColumns);
	validationEmptyTable();
	enodeAssignmentEmptyTable();
	enodeValidationEmptyTable();
	$('#marketTabs').hide();
	$("#virtualGnbView").hide();
	$('#showVirtualDuIdss').hide()
	$("#phyGnbView").hide();
	$('#typeDropdown').html('');
	$('#typeDropdown').multiselect('destroy');
	$('#siteVersionDropdownId').html('');
	$('#siteVersionDropdownId').multiselect('destroy');



	$.each(typeDropdownList, function(i, v) {
		$('#typeDropdown').append("<option>" + v + "</option>");
	});
	$('#typeDropdown').val('', '');
	$('#typeDropdown').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,
		nonSelectedText: 'None selected'

	});
	$("#vENodebIdSelect").val('');
	$("#eNodebIdSelect").val('');
	$.each(siteDropdownList, function(i, v) {
		if(v=="0000"||v=="0001"||v=="0FAA"){
		$('#siteVersionDropdownId').append("<option selected>" + v + "</option>");
		}else{
			$('#siteVersionDropdownId').append("<option>" + v + "</option>");
		}
	});
	$('#siteVersionDropdownId').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1
	});
	$("#siteVersionDropdownId").multiselect("disable");
	siteVersions = $('#siteVersionDropdownId').val();



	// $('#typeDropdown').multiselect({
	// 	includeSelectAllOption: true,
	// 	enableFiltering: true,
	// 	numberDisplayed: 1,
	// 	enableCaseInsensitiveFiltering: true,
	// 	buttonClass: 'btn btn-default whitebg btn-sm',
	// 	nonSelectedText: 'None selected'
	// });

	if (indexOfTabs == 1 && ParentIndex == 1) {
			$('#assignmentGridToolbar').show();
		$('#assignmentGrid').show();
		$('#validationViewGrid').hide();
		$('#enodeAssignmentGrid').hide();
		$('#enodeValidationViewGrid').hide();
	} else if (indexOfTabs == 2 && ParentIndex == 1) {
		$('#assignmentGrid').hide();
		$('#validationViewGrid').show();
		$('#enodeAssignmentGrid').hide();
		$('#enodeValidationViewGrid').hide();
	} else if (indexOfTabs == 1 && ParentIndex == 2) {
		$('#assignmentGrid').hide();
		$('#validationViewGrid').hide();
		$('#enodeAssignmentGrid').show();
		$('#enbAssignmentGridToolbar').show();
		$('#sectorResults').show();
		$('#enodeValidationViewGrid').hide();
	} else if (indexOfTabs == 2 && ParentIndex == 2) {
		$('#assignmentGrid').hide();
		$('#validationViewGrid').hide();
		$('#enodeAssignmentGrid').hide();
		$('#enodeValidationViewGrid').show();
	} if (ParentIndex == 4) {

		$('#assignmentGrid').hide();
		$('#validationViewGrid').hide();
		$('#enodeAssignmentGrid').hide();
		$('#enodeValidationViewGrid').hide();
		$('#configurationViewGrid').show();
		$('#reserveMarketRange').hide();
		spreadsheetConfigurationObj.destroy();
		typeValue = '';
		creatingJSpreadsheeteConfiguration(configurationColumns, spreadsheetConfiguration, null);
	}
	clearAllDropdown();
	 if(indexOfTabs == 1 && ParentIndex == 1){
	 assignmentResetValues();
	 }
	 if(indexOfTabs == 2 && ParentIndex == 1){
	 resetValidation();
	 }
	 if(indexOfTabs == 1 && ParentIndex == 2){
	 resetEnodeAssignment();
	 }
	 if(indexOfTabs == 2 && ParentIndex == 2){
	 resetEnodeValidation();
	 }
	/* assignmentResetValues();
	resetValidation();
	resetEnodeAssignment();
	resetEnodeValidation(); */




}

function enableAORFields() {
	$('#territoryDropdown').multiselect('enable');
	$('#aterritoryDropdown').multiselect('enable');
	$('#vTerritoryDropdown').multiselect('enable');
	$('#eAterritoryDropdown').multiselect('enable');
	$('#eVTerritoryDropdown').multiselect('enable');

	$('#aAreaDropdown').multiselect('enable');
	$('#vAreaDropdown').multiselect('enable');
	$('#eAAreaDropdown').multiselect('enable');
	$('#eVAreaDropdown').multiselect('enable');

	$('#aRegionDropdown').multiselect('enable');
	$('#vRegionDropdown').multiselect('enable');
	$('#eARegionDropdown').multiselect('enable');
	$('#eVRegionDropdown').multiselect('enable');

	$('#aMarketDropdown').multiselect('enable');
	$('#vMarketDropdown').multiselect('enable');
	$('#eAMarketDropdown').multiselect('enable');
	$('#eVMarketDropdown').multiselect('enable');



	//$('#rfEngDropdown').multiselect('enable');
	//$("#enodebSearchInput").prop('disabled', false);
}

function validate5Sector(instance, cell, c, r, value) {
	var closestRowNumber = r
	console.log(r);
	closestRowNumber++;
	if (typeof value != 'undefined') {
		if ($.isNumeric(value)) {
			var value = Number(value);
			if (value > 4) {

				if (instance.id == "virtualAssignmentGridInfo") {
					$("#atollDataSyncbtn").attr('disabled', 'disabled');
					$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(10)').focus();
					//$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(7)').css("border-color", 'red');
					$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(10)').append('<div class="k-widget k-tooltip k-tooltip-validation k-invalid-msg" style="margin-top: 0.5em;margin-left:-4em;margin-right:0.5em; display: block;" data-for="antennaModel" role="alert"><span class="k-icon k-i-warning"> </span>5G Sector limit exceeded More Than 4<div class="k-callout k-callout-n"></div></div>');
					return false;
				}


			} else if (value < 0) {
				$("#atollDataSyncbtn").attr('disabled', 'disabled');
				$("#atollCurrentDataSyncbtn").attr('disabled', 'disabled');
				$("#atollProposedDataSyncbtn").attr('disabled', 'disabled');
				$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(10)').focus();
				$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(10)').css("border-color", 'red');
				$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(10)').append('<div class="k-widget k-tooltip k-tooltip-validation k-invalid-msg" style="margin-top: 0.5em;margin-left:-4em;margin-right:0.5em; display: block;" data-for="antennaModel" role="alert"><span class="k-icon k-i-warning"> </span>5G Sector should not be a negative number<div class="k-callout k-callout-n"></div></div>');
				return false;
			}
			else {
				//document.getElementById("updateBtn").disabled = false;
				$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(10)').css("border-color", '');
				$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(10)').append('');
			}
		}
	}
}

var updatedTransmitterGnbDuRecord = [];
var updatedTransmitterGnbIDRecord = [];


function validateGnbId(instance, cell, c, r, value) {
	var closestRowNumber = r
	closestRowNumber++;
	if (typeof value != 'undefined') {
		if ($.isNumeric(value)) {
			var value = Number(value);
			if (!isGnbIdValid) {
				const index = updatedTransmitterGnbIDRecord.indexOf(spreadsheetTransmitterObj.options.data[r][0]);
				if (index > -1) {
					updatedTransmitterGnbIDRecord.splice(index, 1);
				}
				updatedTransmitterGnbIDRecord.push(spreadsheetTransmitterObj.options.data[r][0]);
				$("#atollDataSyncbtn").attr('disabled', 'disabled');
				document.getElementById("updateBtn").disabled = true;

				var tableRows = document.querySelector('#virtualAssignmentGridInfo tbody').rows;
				for (var i = 0; i < tableRows.length; i++) {
					var rowNumber = document.querySelector('#virtualAssignmentGridInfo tbody').rows[i].cells[0].innerHTML;
					if (rowNumber == closestRowNumber) {
						var indexNew = i+1;
						$('#virtualAssignmentGridInfo tbody tr:nth-child(' + indexNew + ') td:nth-child(12)').focus();
						$('#virtualAssignmentGridInfo tbody tr:nth-child(' + indexNew + ') td:nth-child(12)').append('<div class="k-widget k-tooltip k-tooltip-validation k-invalid-msg" style="margin-top: 0.5em;margin-left:-4em;margin-right:0.5em; display: block;" data-for="antennaModel" role="alert"><span class="k-icon k-i-warning"> </span>Gnb Id is not valid<div class="k-callout k-callout-n"></div></div>');

					}
				}
				return false;

			} else if (value > 7) {

				if (instance.id == "virtualAssignmentGridInfo") {
					$("#atollDataSyncbtn").attr('disabled', 'disabled');
					$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(12)').focus();
					//$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(7)').css("border-color", 'red');
					$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(12)').append('<div class="k-widget k-tooltip k-tooltip-validation k-invalid-msg" style="margin-top: 0.5em;margin-left:-4em;margin-right:0.5em; display: block;" data-for="antennaModel" role="alert"><span class="k-icon k-i-warning"> </span>Gnb Id limit exceeded More Than 7<div class="k-callout k-callout-n"></div></div>');
					return false;
				}


			} else if (value < 0) {
				$("#atollDataSyncbtn").attr('disabled', 'disabled');
				$("#atollCurrentDataSyncbtn").attr('disabled', 'disabled');
				$("#atollProposedDataSyncbtn").attr('disabled', 'disabled');
				$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(12)').focus();
				//$('#virtualAssignmentGridInfo tbody tr:nth-child('+closestRowNumber+') td:nth-child(10)').css("border-color", 'red');
				$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(12)').append('<div class="k-widget k-tooltip k-tooltip-validation k-invalid-msg" style="margin-top: 0.5em;margin-left:-4em;margin-right:0.5em; display: block;" data-for="antennaModel" role="alert"><span class="k-icon k-i-warning"> </span>Gnb Id should not be a negative number<div class="k-callout k-callout-n"></div></div>');
				return false;
			}
			else {
				updatedTransmitterGnbIDRecord = updatedTransmitterGnbIDRecord.filter(x => x !== spreadsheetTransmitterObj.options.data[r][0]);
				//document.getElementById("updateBtn").disabled = false;
				$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(12)').css("border-color", '');
				$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(12)').append('');
			}
		}
	}
}
function validateGnbDuNumber(instance, cell, c, r, value) {
	var closestRowNumber = r
	closestRowNumber++;
	if (typeof value != 'undefined') {
		if ($.isNumeric(value)) {
			var value = Number(value);
			if (!isGnbDuFirstDigitValid) {
				const index = updatedTransmitterGnbDuRecord.indexOf(spreadsheetTransmitterObj.options.data[r][0]);
					if (index > -1) {
						updatedTransmitterGnbDuRecord.splice(index, 1);
					}
				updatedTransmitterGnbDuRecord.push(spreadsheetTransmitterObj.options.data[r][0]);
				$("#atollDataSyncbtn").attr('disabled', 'disabled');
				document.getElementById("updateBtn").disabled = true;
				var tableRows = document.querySelector('#virtualAssignmentGridInfo tbody').rows;
				for (var i = 0; i < tableRows.length; i++) {
					var rowNumber = document.querySelector('#virtualAssignmentGridInfo tbody').rows[i].cells[0].innerHTML;
					if (rowNumber == closestRowNumber) {
						var indexNew = i+1;
						$('#virtualAssignmentGridInfo tbody tr:nth-child(' + indexNew + ') td:nth-child(16)').focus();
						$('#virtualAssignmentGridInfo tbody tr:nth-child(' + indexNew + ') td:nth-child(16)').append('<div class="k-widget k-tooltip k-tooltip-validation k-invalid-msg" style="margin-top: 0.5em;margin-left:-4em;margin-right:0.5em; display: block;" data-for="antennaModel" role="alert"><span class="k-icon k-i-warning"> </span>Gnb Du First Number is not valid<div class="k-callout k-callout-n"></div></div>');

					}
				}
				return false;

			} else if (value > 4) {
				if (instance.id == "virtualAssignmentGridInfo") {
					$("#atollDataSyncbtn").attr('disabled', 'disabled');
					$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(16)').focus();
					//$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(7)').css("border-color", 'red');
					$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(16)').append('<div class="k-widget k-tooltip k-tooltip-validation k-invalid-msg" style="margin-top: 0.5em;margin-left:-8em;margin-right:0.5em; display: block;" data-for="antennaModel" role="alert"><span class="k-icon k-i-warning"> </span>Gnb Du Number limit exceeded More Than 4<div class="k-callout k-callout-n"></div></div>');
					return false;
				}


			} else if (value < 0) {
				$("#atollDataSyncbtn").attr('disabled', 'disabled');
				$("#atollCurrentDataSyncbtn").attr('disabled', 'disabled');
				$("#atollProposedDataSyncbtn").attr('disabled', 'disabled');
				$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(16)').focus();
				//$('#virtualAssignmentGridInfo tbody tr:nth-child('+closestRowNumber+') td:nth-child(10)').css("border-color", 'red');
				$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(16)').append('<div class="k-widget k-tooltip k-tooltip-validation k-invalid-msg" style="margin-top: 0.5em;margin-left:-8em;margin-right:0.5em; display: block;" data-for="antennaModel" role="alert"><span class="k-icon k-i-warning"> </span>Gnb Du Number should not be a negative number<div class="k-callout k-callout-n"></div></div>');
				return false;
			}
			else {
				updatedTransmitterGnbDuRecord = updatedTransmitterGnbDuRecord.filter(x => x !== spreadsheetTransmitterObj.options.data[r][0]);
				//document.getElementById("updateBtn").disabled = false;
				$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(16)').css("border-color", '');
				$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(16)').append('');
			}
		}
	}
}

function validateEnbIdNumber(instance, cell, c, r, value) {
	var closestRowNumber = r
	closestRowNumber++;
	if (typeof value != 'undefined') {
		if ($.isNumeric(value)) {
			var value = Number(value);
			if (value > 6) {

				if (instance.id == "virtualAssignmentGridInfo") {
					$("#atollDataSyncbtn").attr('disabled', 'disabled');
					$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(20)').focus();
					//$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(7)').css("border-color", 'red');
					$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(20)').append('<div class="k-widget k-tooltip k-tooltip-validation k-invalid-msg" style="margin-top: 0.5em;margin-left:-6em;margin-right:0.5em; display: block;" data-for="antennaModel" role="alert"><span class="k-icon k-i-warning"> </span>Enb Id limit exceeded More Than 6<div class="k-callout k-callout-n"></div></div>');
					return false;
				}


			} else if (value < 0) {
				$("#atollDataSyncbtn").attr('disabled', 'disabled');
				$("#atollCurrentDataSyncbtn").attr('disabled', 'disabled');
				$("#atollProposedDataSyncbtn").attr('disabled', 'disabled');
				$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(20)').focus();
				//$('#virtualAssignmentGridInfo tbody tr:nth-child('+closestRowNumber+') td:nth-child(10)').css("border-color", 'red');
				$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(20)').append('<div class="k-widget k-tooltip k-tooltip-validation k-invalid-msg" style="margin-top: 0.5em;margin-left:-6em;margin-right:0.5em; display: block;" data-for="antennaModel" role="alert"><span class="k-icon k-i-warning"> </span>Enb Id should not be a negative number<div class="k-callout k-callout-n"></div></div>');
				return false;
			}
			else {
				//document.getElementById("updateBtn").disabled = false;
				$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(20)').css("border-color", '');
				$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(20)').append('');
			}
		}
	}
}
function exportToExcelEnbAssignment(jsonObject, jsonObjectKeys, fileName) {

	console.log("In the export to excel function");
	var str = 'eNB ID,Site Name, Site Version,Fuze Site ID, Hub Site,Status\r\n';

	let newJsonArray = [];
	let marketsLength = 0;
	let recordsLowerValue = 0;
	let recordsUpperValue = 50;
	let currentArray;

	while (recordsUpperValue < 1050) {
		for (var i = recordsLowerValue; i < recordsUpperValue; i++) {
			currentArray = jsonObject[0];
			let newJsonObject1 = {

				"eNBID": '="' + jsonObjectKeys[0] + currentArray[i].enodebId + '"',
				"siteName": currentArray[i].siteName != null ? '="' + currentArray[i].siteName + '"' : "",
				"siteVersion": currentArray[i].siteVersion != null ? '="' + currentArray[i].siteVersion + '"' : "",
				"siteFuzeID": currentArray[i].siteInfoId != null ? '="' + currentArray[i].siteInfoId + '"' : "",
				"hubSite": "",
				"status": currentArray[i].status != null ? '="' + currentArray[i].status + '"' : ""

			}
			currentArray = jsonObject[1];
			let newJsonObject2 = {
				"eNBID": '="' + jsonObjectKeys[1] + currentArray[i].enodebId + '"',
				"siteName": currentArray[i].siteName != null ? '="' + currentArray[i].siteName + '"' : "",
				"siteVersion": currentArray[i].siteVersion != null ? '="' + currentArray[i].siteVersion + '"' : "",
				"siteFuzeID": currentArray[i].siteInfoId != null ? '="' + currentArray[i].siteInfoId + '"' : "",
				"hubSite": "",
				"status": currentArray[i].status != null ? '="' + currentArray[i].status + '"' : ""

			}
			currentArray = jsonObject[2];
			let newJsonObject3 = {
				"eNBID": '="' + jsonObjectKeys[2] + currentArray[i].enodebId + '"',
				"siteName": currentArray[i].siteName != null ? '="' + currentArray[i].siteName + '"' : "",
				"siteVersion": currentArray[i].siteVersion != null ? '="' + currentArray[i].siteVersion + '"' : "",
				"siteFuzeID": currentArray[i].siteInfoId != null ? '="' + currentArray[i].siteInfoId + '"' : "",
				"hubSite": "",
				"status": currentArray[i].status != null ? '="' + currentArray[i].status + '"' : ""

			}
			newJsonArray.push(newJsonObject1);
			newJsonArray.push(newJsonObject2);
			newJsonArray.push(newJsonObject3);

		}

		let temp = recordsUpperValue;
		recordsUpperValue = recordsUpperValue + 50;
		recordsLowerValue = temp;
		let blankObject = {

			"eNBID": "",
			"siteName": "",
			"siteVersion": "",
			"siteFuzeID": "",
			"hubSite": "",
			"status": ""

		};
		newJsonArray.push(blankObject);

	}

	var jsonObject = JSON.stringify(newJsonArray);
	var array = typeof jsonObject != 'object' ? JSON.parse(jsonObject) : jsonObject;


	for (var i = 0; i < array.length; i++) {
		var line = '';
		for (var index in array[i]) {
			if (line != '') line += ','

			line += array[i][index];
		}

		str += line + '\r\n';
	}
	var link = document.createElement("a");
	link.id = "lnkDwnldLnk";
	document.body.appendChild(link);
	var csv = str;
	blob = new Blob([str], { type: 'text/csv' });
	var csvUrl = window.webkitURL.createObjectURL(blob);
	$("#lnkDwnldLnk")
		.attr({
			'download': fileName,
			'href': csvUrl
		});

	$('#lnkDwnldLnk')[0].click();
	document.body.removeChild(link);

}
var newJsonObject = []
function exportToExcelEnbGnb(jsonObject, fileName, flag) {

	newJsonObject = []
	var str;
	if (flag === "assignment") {

		str = 'gNB,gNBVendor,Market,vCU,Assigned DU Count(gNB),Assigned DU Count(VCU),Assigned Cell Count (GNB),Assigned Cell Count(VCU), Available Cell Count(GNB),Available Cell Count(VCU),FR1,FR2,Hub Name,\r\n';

	} else if (flag == "enbValidation") {

		if (builtInFlag) {
			str = 'Validity Flag, Site Version, Vendor, Schema, eNB Id, Sector, Frequency Band, BW, eNB Built in USM/NSP/ENM, Valid eNB Length, Valid Numeric eNB, Valid Sector Length, Valid Numeric Sector, County, Site Info ID, Site Name\r\n';
		}
		else{
			str = 'Validity Flag, Site Version, Vendor, Schema, eNB Id, Sector, Frequency Band, BW, Built In Switch, Valid eNB Length, Valid Numeric eNB, Valid Sector Length, Valid Numeric Sector, County, Site Info ID, Site Name\r\n';
		}

	} else if (flag == "atoll") {
		str = 'gNB, gNBVendor, Market, vCU, Assigned DU Count(gNB), Assigned DU Counr(VCU), Assigned Cell Count(GNB), Assigned Cell Count(VCU), Available Cell Count(gNB), Available Cell Count(VCU), FR1, FR2,Hub Name,\n';

	}
	if(val && str){
		str=str.replace('Market',val['GEO4']);
	}
	let newJsonArray = []

	for (const obj of jsonObject) {
		if (flag === "assignment") {

				newJsonObject = {
					vzGnodebId: obj.vzGnodebId,
					vzEnodebVendor: obj.vzEnodebVendor,
					market: obj.market,
					vCU: obj.vCU,
					assignedDUCountgNB: obj.assignedDUCountgNB,
					assignedDUCountVCU: obj.assignedDUCountVCU,
					assignedCellCountgNB: obj.assignedCellCountgNB,
					assignedCellCountVCU: obj.assignedCellCountVCU,
					availableCellCountgNB: obj.availableCellCountgNB,
					availableCellCountVCU: obj.availableCellCountVCU,
					fR1: obj.fR1,
					fR2: obj.fR2,
					hubName: obj.cranHubName
				}

		} else if (flag === "enbValidation") {
		 newJsonObject = {
				validityFlag: obj.validFlag,
				siteVersion: obj.siteVersion,
				vendor: obj.vendor,
				schema: obj.schema,
				enbId: obj.eNodeBID,
				sector: obj.sector,
				frequencyBand: obj.fBand,
				bw: obj.bw,
				builtInSwitch: obj.builtInSwitch,
				valideNBLength: obj.validENBLength,
				validNumericeNB: obj.validENBNumber,
				validSectorLength: obj.validEnbSectorLength,
				validNumericSector: obj.validEnbSectorNumber,
				county: obj.county,
				siteInfoID: obj.siteInfoId,
				siteName: obj.siteName,
                //hubName: obj.cranHubName
			}
		}

		Object.keys(newJsonObject).forEach(function(key) {
			if (newJsonObject[key] === null) {
				newJsonObject[key] = '';
			}
			newJsonObject[key] = '="' + newJsonObject[key] + '"';
		})
		newJsonArray.push(newJsonObject)
	}
	var jsonObject = JSON.stringify(newJsonArray);
	var array = typeof jsonObject != 'object' ? JSON.parse(jsonObject) : jsonObject;


	for (var i = 0; i < array.length; i++) {
		var line = '';
		for (var index in array[i]) {
			if (line != '') line += ','

			line += array[i][index];
		}

		str += line + '\r\n';
	}
	var link = document.createElement("a");
	link.id = "lnkDwnldLnk";
	document.body.appendChild(link);
	var csv = str;
	blob = new Blob([str], { type: 'text/csv' });
	var csvUrl = window.webkitURL.createObjectURL(blob);
	$("#lnkDwnldLnk")
		.attr({
			'download': fileName,
			'href': csvUrl
		});

	$('#lnkDwnldLnk')[0].click();
	document.body.removeChild(link);

}
function exportToExcelGnbValidation(jsonObject, fileName) {

	console.log("In the export to excel function");
	var str = "";
			str = 'Validity Flag, Site Version, Vendor, Schema, vCU, gNB id, gNB DU Number, gNB DU ID, Sector, Frequency Band, BW, Valid mmW BW, gNB Built in USM/NSP/ENM, Valid gNB Market Number, Valid gNB Middle Number, gNB Length, Valid DU ID Length, Valid 1st DU Number, Valid Numeric gNBDUID and Sector, Count of Duplicate gNBDU ID Sec, GNBDU ID Built in Switch, County, Site Info ID, Site Name\r\n';

	let newJsonArray = [];
	let newJsonObject = {};
	for (const obj of jsonObject) {

				newJsonObject = {
					validFlag: obj.validFlag,
					siteVersion: obj.siteVersion,
					vzEnodebVendor: obj.vzEnodebVendor,
					schema: obj.schema,
					vcu: obj.vcu,
					vzGnodebId: obj.vzGnodebId,
					vzGnbDuNumber: obj.vzGnbDuNumber,
					vzGnbDuId: obj.vzGnbDuId,
					sector: obj.sector,
					fBand: obj.fBand,
					bandwidth: obj.bandwidth,
					validmmWBW: obj.validmmWBW,
					gNB_builtInUSM_NSP_ENM: obj.builtInSwitch,
					validGNBMarketNumber: obj.validGNBMarketNumber,
					validGNBMiddleNumber: obj.validGNBMiddleNumber,
					validGNBLength: obj.validGNBLength,
					validDUIdLength: obj.validDUIdLength,
					validFirstDUNumber: obj.validFirstDUNumber,
					validNumericgNBDUIDandSector: obj.validNumericgNBDUIDandSector,
					countDupGNBs: obj.countDupGNBs,
					gnBbuiltInSwitch: obj.gNBDUBuiltInSwitch,
					county: obj.county,
					siteInfoId: obj.siteInfoId,
					siteName: obj.siteName
				};

		Object.keys(newJsonObject).forEach(function(key) {
			if (newJsonObject[key] === null) {
				newJsonObject[key] = '';
			} else {
				newJsonObject[key] = '="' + newJsonObject[key] + '"';
			}
		})
		newJsonArray.push(newJsonObject)
	}
	var jsonObject = JSON.stringify(newJsonArray);
	var array = typeof jsonObject != 'object' ? JSON.parse(jsonObject) : jsonObject;


	for (var i = 0; i < array.length; i++) {
		var line = '';
		for (var index in array[i]) {
			if (line != '') line += ','

			line += array[i][index];
		}

		str += line + '\r\n';
	}
	var link = document.createElement("a");
	link.id = "lnkDwnldLnk";
	document.body.appendChild(link);
	var csv = str;
	blob = new Blob([str], { type: 'text/csv' });
	var csvUrl = window.webkitURL.createObjectURL(blob);
	$("#lnkDwnldLnk")
		.attr({
			'download': fileName,
			'href': csvUrl
		});

	$('#lnkDwnldLnk')[0].click();
	document.body.removeChild(link);

}


function exportToExcel(jsonObject, fileName, gnodeBId) {
	let newJsonArray = []
	for (const obj of jsonObject) {
		let newJsonObject = {
			"gNbId": gnodeBId != null ? '="' + gnodeBId + '"' : "",
			"duId": obj.vz5GgNBDUNumber != null ? '="' + obj.vz5GgNBDUNumber + '"' : "",
			"siteName": obj.vzSiteName != null ? obj.vzSiteName : "",
			"siteVersion": obj.siteVersionLast != null ? '="' + obj.siteVersionLast + '"' : "",
			"siteFuzeId": obj.vzSiteInfoId != null ? obj.vzSiteInfoId : "",
			"status": obj.status != null ? obj.status : "",
			"hubName": obj.cranHubName != null ? obj.cranHubName : ""

		}
		newJsonArray.push(newJsonObject)
	}
	var jsonObject = JSON.stringify(newJsonArray);
	var array = typeof jsonObject != 'object' ? JSON.parse(jsonObject) : jsonObject;
	var str = '';
	str = 'gNB ID,DU ID,Site Name,Site Version,Fuze Site ID,Status,Hub Name,\r\n';

	for (var i = 0; i < array.length; i++) {
		var line = '';
		for (var index in array[i]) {
			if (line != '') line += ','

			line += array[i][index];
		}

		str += line + '\r\n';
	}
	var link = document.createElement("a");
	link.id = "lnkDwnldLnk";
	document.body.appendChild(link);
	var csv = str;
	blob = new Blob([str], { type: 'text/csv' });
	var csvUrl = window.webkitURL.createObjectURL(blob);
	$("#lnkDwnldLnk")
		.attr({
			'download': fileName,
			'href': csvUrl
		});

	$('#lnkDwnldLnk')[0].click();
	document.body.removeChild(link);

}

function sectorexportToExcel(jsonObject, fileName, gnodeBId) {


	let newJsonArray = []
	for (const obj of jsonObject) {
		let newJsonObject = {
			"gnbId": gnodeBId != null ? '="' + gnodeBId + '"' : "",
			"sector": obj.sector != null ? '="' + obj.sector + '"' : "",
			"siteName": obj.siteName != null ? obj.siteName : "",
			"siteVersion": obj.siteVersion != null ? '="' + obj.siteVersion + '"' : "",
			"siteFuzeId": obj.siteFuzeId != null ? obj.siteFuzeId : "",
			"status": obj.status != null ? obj.status : "",
			"hubName": obj.cranHubName != null ? obj.cranHubName : ""

		}
		newJsonArray.push(newJsonObject)
	}
	var jsonObject = JSON.stringify(newJsonArray);
	var array = typeof jsonObject != 'object' ? JSON.parse(jsonObject) : jsonObject;
	var str = '';
	str = 'gNB ID,Sector,Site Name,Site Version,Fuze Site ID,Status,Hub Name,\r\n';


	for (var i = 0; i < array.length; i++) {
		var line = '';
		for (var index in array[i]) {
			if (line != '') line += ','

			line += array[i][index];
		}

		str += line + '\r\n';
	}
	var link = document.createElement("a");
	link.id = "lnkDwnldLnk";
	document.body.appendChild(link);
	var csv = str;
	blob = new Blob([str], { type: 'text/csv' });
	var csvUrl = window.webkitURL.createObjectURL(blob);
	$("#lnkDwnldLnk")
		.attr({
			'download': fileName,
			'href': csvUrl
		});

	$('#lnkDwnldLnk')[0].click();
	document.body.removeChild(link);

}

function exportToExcelPhGnbView(jsonObject, fileName, physicalMarket) {
	let newJsonArray = [];
	if(tabIndexGnbAtollUpdate == 1) {
        physicalMarket  = marketsSelected;
    } else if(tabIndexGnbAtollUpdate == 3) {
        physicalMarket  = marketIdOrName;
    }
	if (parseInt(physicalMarket) < 10) {
		physicalMarket = '00' + physicalMarket;
	} else if (parseInt(physicalMarket) < 100) {
		physicalMarket = '0' + physicalMarket;
	}
	for (const obj of jsonObject) {
	 let newJsonObject = {
			"gNBId": physicalMarket + obj.gNBId != null ? '="' + physicalMarket + obj.gNBId + '"' : "",
			"siteName": obj.vzSiteName != null ? obj.vzSiteName : "",
			"siteVersion": obj.siteVersionLast != null ? '="' + obj.siteVersionLast + '"' : "",
			"siteFuzeId": obj.vzSiteInfoId != null ? obj.vzSiteInfoId : "",
			"status": obj.status != null ? obj.status : "",
            "hubName": obj.cranHubName !== null ? obj.cranHubName : ""
		}
		newJsonArray.push(newJsonObject)
	}
	var jsonObject = JSON.stringify(newJsonArray);
	var array = typeof jsonObject != 'object' ? JSON.parse(jsonObject) : jsonObject;
	var str = '';
	str = 'gNB ID,Site Name,Site Version,Fuze Site ID,Status,Hub Name,\r\n';

	for (var i = 0; i < array.length; i++) {
		var line = '';
		for (var index in array[i]) {
			if (line != '') line += ','

			line += array[i][index];
		}

		str += line + '\r\n';
	}
	var link = document.createElement("a");
	link.id = "lnkDwnldLnk";
	document.body.appendChild(link);
	var csv = str;
	blob = new Blob([str], { type: 'text/csv' });
	var csvUrl = window.webkitURL.createObjectURL(blob);
	$("#lnkDwnldLnk")
		.attr({
			'download': fileName,
			'href': csvUrl
		});

	$('#lnkDwnldLnk')[0].click();
	document.body.removeChild(link);

}

function enbsectorexportToExcel(jsonObject, fileName, enbSelData) {
	let newJsonArray = []
	for (const obj of jsonObject) {
		let newJsonObject = {
			"enbId": enbSelData != null ? enbSelData : "",
			"sectorCarrier": obj.sectorCarrier != null ? '="' + obj.sectorCarrier + '"' : "",
			"siteName": obj.siteName != null ? obj.siteName : "",
			"siteVersion": obj.siteVersion != null ? '="' + obj.siteVersion + '"' : "",
			"siteFuzeId": obj.siteFUZEID != null ? obj.siteFUZEID : "",
			"status": obj.status != null ? obj.status : "",
			"hubName": obj.cranHubName != null ? obj.cranHubName : ""

		}
		newJsonArray.push(newJsonObject)
	}
	var jsonObject = JSON.stringify(newJsonArray);
	var array = typeof jsonObject != 'object' ? JSON.parse(jsonObject) : jsonObject;
	var str = '';
	str = 'eNB ID,Sector_Carrier,Site Name,Site Version,Fuze Site ID,Status,Hub Name,\r\n';


	for (var i = 0; i < array.length; i++) {
		var line = '';
		for (var index in array[i]) {
			if (line != '') line += ','

			line += array[i][index];
		}

		str += line + '\r\n';
	}
	var link = document.createElement("a");
	link.id = "lnkDwnldLnk";
	document.body.appendChild(link);
	var csv = str;
	blob = new Blob([str], { type: 'text/csv' });
	var csvUrl = window.webkitURL.createObjectURL(blob);
	$("#lnkDwnldLnk")
		.attr({
			'download': fileName,
			'href': csvUrl
		});

	$('#lnkDwnldLnk')[0].click();
	document.body.removeChild(link);

}
function resetStoredValues() {
    dataarrayNeMode = ['Ne Mode', '', '', '', '', '', ''];
    dataarray = ['5G Sector', '', '', '', '', '', ''];
    dataarraylteSector = ['LTE Sector', '', '', '', '', '', ''];
    dataarrayGnbId = ['gNB ID', '', '', '', '', '', ''];
    dataarrayGnbFriendlyname = [];
    dataarrayGnbFriendlyname = ['eNB Friendly Name', '', '', '', '', '', ''];
    dataarrayGnbMixmodellable = ['gNB Mixed Model Label', '', '', '', '', '', ''];
    dataarrayGnbDuNumber = ['gNB DU Number', '', '', '', '', '', ''];
    dataarrayGnbDufriendlyname = ['gNB DU Friendly Name', '', '', '', '', '', ''];
    dataarrayEnbFriendlyname = ['eNB Friendly Name', '', '', '', '', '', ''];
    dataarrayEnbId = ['eNB ID', '', '', '', '', '', ''];
}
function enbsectorResultsexportToExcel(jsonObject, fileName, enbSelData) {


	let newJsonArray = []
	for (const obj of jsonObject) {
		let newJsonObject = {
			"market": obj.market != null ? obj.market : "",
			"siteFuzeId": obj.enbsectorcarrier.siteFUZEID != null ? obj.enbsectorcarrier.siteFUZEID : "",
			"siteName": obj.enbsectorcarrier.siteName != null ? obj.enbsectorcarrier.siteName : "",
			"siteVersion": obj.enbsectorcarrier.siteVersion != null ? '="' + obj.enbsectorcarrier.siteVersion + '"' : "",
			"vendor": obj.vendor != null ? obj.vendor : "",
			"enb": obj.eNB != null ? obj.eNB : "",
			"sector": obj.sector != null ? obj.sector : "",
			"carrier": obj.carrier != null ? obj.carrier : "",
			"frequencyBand": obj.frequencyBand != null ? obj.frequencyBand : "",
			"centreChannel": obj.centreChannel != null ? obj.centreChannel : "",
			"bw": obj.bw != null ? obj.bw : "",
			"status": obj.enbsectorcarrier.status != null ? obj.enbsectorcarrier.status : "",
			"hubName": obj.cranHubName != null ? obj.cranHubName : ""

		}
		  newJsonArray.push(newJsonObject);
	}
	var jsonObject = JSON.stringify(newJsonArray);
	var array = typeof jsonObject != 'object' ? JSON.parse(jsonObject) : jsonObject;
	var str = '';
	str = 'Market,Fuze Site ID,Site Name,Site Version,Vendor,EnB,Sector,Carrier,Frequency Band,Centre Channel,BW,Status,Hub Name,\r\n';

	if(val){
		str=str.replace('Market',val['GEO4']);
	}
	for (var i = 0; i < array.length; i++) {
		var line = '';
		for (var index in array[i]) {
			if (line != '') line += ','

			line += array[i][index];
		}

		str += line + '\r\n';
	}
	var link = document.createElement("a");
	link.id = "lnkDwnldLnk";
	document.body.appendChild(link);
	var csv = str;
	blob = new Blob([str], { type: 'text/csv' });
	var csvUrl = window.webkitURL.createObjectURL(blob);
	$("#lnkDwnldLnk")
		.attr({
			'download': fileName,
			'href': csvUrl
		});

	$('#lnkDwnldLnk')[0].click();
	document.body.removeChild(link);

}
let exportToExcelButtonId = document.getElementById('exportToExcel');
exportToExcelButtonId.onclick = () => exportToExcel(fetchGnbDUNumbers, "gnbDuView.csv", virtualGnbData.vzGnodebId)
let sectexportToExcelButtonId = document.getElementById('sectorexportToExcel');
sectexportToExcelButtonId.onclick = () => sectorexportToExcel(virtualDuIds, "gnbSectorView.csv", virtualGnbData.vzGnodebId)
let enbsectexportToExcelButtonId = document.getElementById('enbsectorexportToExcel');
enbsectexportToExcelButtonId.onclick = () => enbsectorexportToExcel(enbSecData1, "enbSectorView.csv", enbSelData1);
let exportToExcelPhGnbViewButtonId = document.getElementById('exportToExcelPhGnbView');
exportToExcelPhGnbViewButtonId.onclick = () => exportToExcelPhGnbView(fetchPhyGnbs, "Physical gNB View.csv", physicalMarket)

document.getElementById("exportToExcelEnbAssignmentTab").onclick = () => exportToExcelEnbAssignment(resultVal, resultKeys, "enbAssignmentView.csv");
document.getElementById("physicalSectorExportToExcel").onclick = () => exportToExcelPhysicalSector(gnbphysicalGnbSectorViewData, "Physical gNB Sector View.csv", gnbID);
let fiveGphySecExportToExcelButtonId = document.getElementById('fiveGphysicalSectorExportToExcel');
if (fiveGphySecExportToExcelButtonId) {
    fiveGphySecExportToExcelButtonId.onclick = () => exportToExcelPhysicalSector(physicalSampledata, "5gPhysicalSectorView.csv", gnbID);
}
// --- GLOBAL PAGINATION RED BALL FIX ---
$(document).on('click', '.page-item span', function() {
    var $ul = $(this).closest('ul');
    var $li = $(this).closest('li');

    // Do nothing if the button is disabled
    if ($li.hasClass('disabled')) return;

    // Wait 50 milliseconds for your existing functions (like showSecond or goToPage) to update the variables
    setTimeout(function() {
        var activePage = 1;
        var ulId = $ul.attr('id');

        // Figure out which view's page variable we need to check
        if (ulId === 'showHidePageIDList') {
            activePage = typeof currentPage !== 'undefined' ? currentPage : current_page;
        } else if (ulId === 'fiveGDuPageList') {
            activePage = typeof fiveGDuCurrentPage !== 'undefined' ? fiveGDuCurrentPage : current_page;
        } else if (ulId === 'showFiveGPhysicalHidePageList') {
            activePage = typeof current_page !== 'undefined' ? current_page : 1;
        } else if ($ul.closest('#showHideVirtualPage').length > 0) {
            activePage = typeof virtualSectorCurrentPage !== 'undefined' ? virtualSectorCurrentPage : 1;
        } else {
            activePage = typeof current_page !== 'undefined' ? current_page : 1; // Fallback
        }

        // Wipe the red ball from everything in this list, and apply it to the new page!
        // (+1 because the "Previous" arrow counts as the 1st child)
        $ul.find('li').removeClass('active');
        $ul.find('li:nth-child(' + (activePage + 1) + ')').addClass('active');

    }, 50);
});
// --- FORCE PAGINATION TO REMOVE RED BUBBLE AND SHIFT LEFT ---
$(document).ready(function() {
    var shiftPaginationLeftCSS = `
        /* 1. Reset all inner list items across containers to match spacing rules */
        #showHidePageIDList li, #showHideVirtualPage ul li, #fiveGDuPageList li, #showFiveGVirtualDuPage li, #showFiveGPhysicalHidePageList li {
            display: inline-block !important;
            margin: 0 !important;
            padding: 0 !important;
            background: transparent !important;
            border: none !important;
        }

        /* 2. Force identical horizontal padding on ALL inner elements (numbers AND arrows) */
        #showHidePageIDList li span, #showHidePageIDList li a,
        #showHideVirtualPage ul li span, #showHideVirtualPage ul li a,
        #fiveGDuPageList li span, #fiveGDuPageList li a,
        #showFiveGVirtualDuPage li span, #showFiveGVirtualDuPage li a,
        #showFiveGPhysicalHidePageList li span, #showFiveGPhysicalHidePageList li a {
            background: transparent !important;
            background-color: transparent !important;
            border: none !important;
            box-shadow: none !important;
            padding: 0 8px !important; /* Perfect mirrored horizontal gaps */
            margin: 0 !important;      /* Overrides the rogue 15px right-margin */
            font-weight: normal !important;
            cursor: pointer !important;
            display: inline-block !important;
            line-height: normal !important;
            vertical-align: middle !important;
        }

        /* 3. Style active page states safely without applying alignment shifts */
        #showHidePageIDList li.active span, #showHideVirtualPage ul li.active span, #fiveGDuPageList li.active span, #showFiveGVirtualDuPage li.active span, #showFiveGPhysicalHidePageList li.active span {
            font-weight: bold !important;
            cursor: default !important;
        }

        /* 4. Harmonize styles across disabled nav components */
        #showHidePageIDList li.disabled span, #showHideVirtualPage ul li.disabled span, #fiveGDuPageList li.disabled span, #showFiveGVirtualDuPage li.disabled span, #showFiveGPhysicalHidePageList li.disabled span {
            color: #cccccc !important;
            cursor: not-allowed !important;
            opacity: 0.6 !important;
        }

        /* 5. Maintain structural stability for left-alignment across grids */
        #showHidePageIDList, #showHideVirtualPage ul, #fiveGDuPageList, #showFiveGVirtualDuPage, #showFiveGPhysicalHidePageList {
            display: flex !important;
            align-items: center !important;
            justify-content: flex-start !important;
            height: auto !important;
            padding: 10px 0 10px 5px !important;
            list-style: none !important;
        }
    `;
    $('<style>').text(shiftPaginationLeftCSS).appendTo('head');
});