var capacityData = [];
var capacityFlagCheck = false;
var vcuFlagCheck = false;
var configurationMarketName;
var configurationFlag = false;
var typeValue='';
var configurationDataNew = [];
var vcuData = [];
var capacityCellCurrentValues = [];
var vcuCellCurrentValues = [];
var capacityOldValues = [];
var vcuOldValues = [];
var updatedRecords=[];
var reservationXcelData='';
var nextTempId=-1;

function creatingJSpreadsheeteConfiguration(configurationColumns, spreadsheetConfiguration, configurationData) {
    if (spreadsheetConfiguration == 'configurationViewGrid') {
        spreadsheetConfigurationObj = jspreadsheet(document.getElementById(spreadsheetConfiguration), {
            data: configurationData,
            columns: configurationColumns,
            tableOverflow: true,
            tableWidth: '100%',
            minSpareRows: 0,
            minDimensions: [0, 6],
            filters: true,
            allowInsertRow: false,
            allowInsertColumn: false,
            allowRenameColumn: false,
            allowDeleteColumn: false,
            allowDeleteRow: false,
            autoIncrement: false,

            onchange: function (instance, cell, c, r, value) {
                capacityFlagCheck = false;
                vcuFlagCheck = false;
                configurationTableCellChange(instance, cell, c, r, value);
            },

            onload: function (instance) {
                row = document.getElementsByClassName('jexcel jexcel_overflow')[0].rows;
                rowrecieved = document.getElementsByClassName('jexcel jexcel_overflow')[0].rows;
                console.log(rowrecieved);
                for (var i = 0; i < row.length; i++) {
                    for (var j = 0; j < row[i].cells.length; j++) {
                        if (j == 3) {
                            if (j == 3) {
                                capacityData.push(rowrecieved[i].cells[3].innerHTML);
                            }
                            row[i].cells[j].id = i + '_r9_' + j;
                            row[i].cells[j].addEventListener('keypress', function (event) {
                                var code = (event.which) ? event.which : event.keyCode;
                                var test = document.getElementById(event.currentTarget.id);
                                var test2 = test.getElementsByTagName('input');

                                if (code > 31 && (code < 48 || code > 57) || test2[0].value.length > 4) {
                                    event.preventDefault();
                                }

                            })
                        }

                        if (j == 4) {
                            if (j == 4) {
                                vcuData.push(rowrecieved[i].cells[4].innerHTML);
                            }
                            row[i].cells[j].id = i + '_r9_' + j;
                            row[i].cells[j].addEventListener('keypress', function (event) {
                                var code = (event.which) ? event.which : event.keyCode;
                                var test = document.getElementById(event.currentTarget.id);
                                var test2 = test.getElementsByTagName('input');

                                if (code > 31 && (code < 48 || code > 57) || test2[0].value.length > 2) {
                                        event.preventDefault();
                                }

                            })
                        }

                        if (!rowrecieved[i].cells[6].innerHTML) {
                            rowrecieved[i].cells[6].innerHTML
                            document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[3].className = "readonly";
                            document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[4].className = "readonly";
                        }

                    }
                }
            }


        });
    }
}

function configurationTableCellChange(instance, cell, c, r, value) {
    capacityCellCurrentValues = [];
    vcuCellCurrentValues = [];
    capacityOldValues = [];
    vcuOldValues =[];

    $.each(spreadsheetConfigurationObj.options.data, function (index, value) {
        capacityCellCurrentValues.push(value[2]);
    });

    $.each(spreadsheetConfigurationObj.options.data, function (index, value) {
        vcuCellCurrentValues.push(value[3]);
    });

    capacityOldValues = capacityData.slice(8);

    vcuOldValues = vcuData.slice(8);


    if (c == 2) {
        if (/^[0-9]+$/.test(value)) {
            value = value;
        } else {
            value = '';
        }
        if (value == '0' || value == '00') {
            value = '';
            cell.innerHTML = '';
        }
        cell.innerHTML = cell.innerHTML.slice(0, 7);
        validationCapacityCellLimit(instance, cell, c, r, value);

        $.each(capacityOldValues, function (index, oldValue) {
            $.each(capacityCellCurrentValues, function (indexCurrent, value) {
                if (index == indexCurrent) {
                    if (oldValue != value) {
                        capacityFlagCheck = true;
                    }
                }
            });
        });

    }
    if (c == 3) {
        if (value == "0" || value == "00") {
            spreadsheetConfigurationObj.options.data[r][c] = '';
            cell.innerHTML = '';
        }
        validationVcuCellLimit(instance, cell, c, r, value);

        $.each(vcuOldValues, function (index, oldValue) {
            $.each(vcuCellCurrentValues, function (indexCurrent, value) {
                if (index == indexCurrent) {
                    if (oldValue != value) {
                        vcuFlagCheck = true;
                    }
                }
            });
        });
    }
}


function validationCapacityCellLimit(instance, cell, c, r, value) {
    var closestRowNumber = r
    closestRowNumber++;
    if (typeof value != 'undefined') {
        if ($.isNumeric(value)) {
            var value = Number(value);
            if (value.toString().length > 5) {

                if (instance.id == "configurationViewGrid") {
                    $("#atollDataSyncbtn").attr('disabled', 'disabled');
                    $('#configurationViewGrid tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(4)').focus();
                    //$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(7)').css("border-color", 'red');
                    $('#configurationViewGrid tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(4)').append('<div class="k-widget k-tooltip k-tooltip-validation k-invalid-msg" style="margin-top: 0.5em;margin-left:-4em;margin-right:0.5em; display: block;" data-for="antennaModel" role="alert"><span class="k-icon k-i-warning"> </span>Capacity- (Cells) limit exceeded More Then 5<div class="k-callout k-callout-n"></div></div>');
                    return false;
                }
            }
        }
    }
}

function validationVcuCellLimit(instance, cell, c, r, value) {
    var closestRowNumber = r
    closestRowNumber++;
    if (typeof value != 'undefined') {
        if ($.isNumeric(value)) {
            var value = Number(value);
            if (value.toString().length >= 3 && value !== 100) {

                if (instance.id == "configurationViewGrid") {
                    $("#atollDataSyncbtn").attr('disabled', 'disabled');
                    $('#configurationViewGrid tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(5)').focus();
                    //$('#virtualAssignmentGridInfo tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(7)').css("border-color", 'red');
                    $('#configurationViewGrid tbody tr:nth-child(' + closestRowNumber + ') td:nth-child(5)').append('<div class="k-widget k-tooltip k-tooltip-validation k-invalid-msg" style="margin-top: 0.5em;margin-left:-4em;margin-right:0.5em; display: block;" data-for="antennaModel" role="alert"><span class="k-icon k-i-warning"> </span>VCU Threshold% limit should be 1 to 100  <div class="k-callout k-callout-n"></div></div>');
                    return false;
                }


            }
        }
    }
}

function refreshData() {
    if (typeValue == "Assignment Capacity Change") {

        if (capacityFlagCheck || vcuFlagCheck) {
            $('#configurationTabChanges').show();
        } else {
            configurationDataFetch();
        }
    }
    else if (typeValue == "Reserve Market Range") {
        if(updatedRecords.length>0){
            $('#configurationTabChanges').show();
        }else{
            getEnbReservedRanges();
        }
    }
   
}
function proceedSearchConfiguration() {
    $('#configurationTabChanges').hide();
    if (typeValue == "Assignment Capacity Change") {
        configurationDataFetch();
    }
    else if (typeValue == "Reserve Market Range") {
        getEnbReservedRanges();
    }
    
}

$('#typeDropdown').change(function () {
    typeValue = $("#typeDropdown").val();

});

var configurationExcelData;
var regionName;
// configuration capacity data fetch service
function configurationDataFetch() {
    typeValue = $('#typeDropdown').val();

    if ((gnbAssignTerritoryList == undefined) || (gnbAssignRegionList == undefined) || (gnbAssignRegionList == "")
        || (marketsSelected == '') || (gnbAssignAreaList == undefined) || (typeValue == '') || (typeValue == undefined)) {
        alert("Please Select All the Mandatory Dropdowns");
        $('#loading').hide();
    } else {
        configurationMarketName = marketsSelected + '-' + marketsMapping[marketsSelected];
        $.each(regionsDataProvider, function (index, value) {
            if (value.region === gnbAssignRegionList) {
                regionName = value.regionname;
            }
        });
        $('#loading').show();
        var gnbCapacityFetchURL;
        gnbCapacityFetchURL = fetchGnbCapacityPlanURL;
        $.ajax({
            type: 'GET',
            contentType: 'application/json; charset=UTF-8',
            cache: false,
              //url: 'http://localhost:8100/npp-atoll-services/enbgnbAssignment/fetchGnbCapacity?regionName=' + regionName,
            url: gnbCapacityFetchURL+regionName,
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            success: function (data) {
                configurationData = data;
                if (configurationData.length > 0) {
                    configurationExcelData = data;
                    $('#loading').hide();
                    spreadsheetConfigurationObj.destroy();
                    creatingJSpreadsheeteConfiguration(configurationColumns, spreadsheetConfiguration, configurationData);
                } else {
                    spreadsheetConfigurationObj.destroy();
                    creatingJSpreadsheeteConfiguration(configurationColumns, spreadsheetConfiguration, null);
                    $('#loading').hide();
                    aptAlert('error', 'No record found');
                }
            },
            error: function (data) {
                $('#loading').hide();
                aptAlert('error', 'failed');
            }
        });
    }
}


// configuration update data
var updatedConfigurationData = [];

function configurationUpdateData() {

    if ((gnbAssignTerritoryList == undefined) || (gnbAssignRegionList == undefined) || (gnbAssignRegionList == "")
        || (marketsSelected == '') || (gnbAssignAreaList == undefined) || (typeValue == '') || (typeValue == undefined)) {
        alert("Please Select All the Mandatory Dropdowns");
        $('#loading').hide();
    } else {
         capacityFlagCheck = false;
         vcuFlagCheck = false;

            $.each(capacityCellCurrentValues, function (indexCurrent, value) {
                if (value.toString().length > 5) {
                    alert('Capacity (Cells) limit exceeded More Then 5');
                    throw new Error('capacity (Cells) limit exceeded More Then 5');
                }
            }); 
            $.each(vcuCellCurrentValues, function (indexCurrent, value) {
                if (value.toString().length >= 3 && value !== 100) {
                    alert('VCU Threshold % limit should be in between 1 to 100');
                    throw new Error('VCU Threshold% limit exceeded More Then 100%');
                }
            }); 2

        var configurationUpdatedData = spreadsheetConfigurationObj.options.data;

        for (var i = 0; i < configurationUpdatedData.length; i++) {
            if (configurationUpdatedData[i][5]) {
                var temp = {
                    marketName: configurationUpdatedData[i][0],
                    vendor: configurationUpdatedData[i][1],
                    cellCapacity: configurationUpdatedData[i][2],
                    vcuThreshold: configurationUpdatedData[i][3],
                    marketNumber: configurationUpdatedData[i][4],
                    id: configurationUpdatedData[i][5]
                }
                updatedConfigurationData.push(temp);
            }

        }

        $('#loading').show();
        var gnbCapacityUpdateURL;
        gnbCapacityUpdateURL = updateGnbCapacityPlanURL;
        $.ajax({
            type: 'POST',
            async: false,
            contentType: 'application/json; charset=UTF-8',
            cache: false,
            data: JSON.stringify(updatedConfigurationData),
              //url: 'http://localhost:8100/npp-atoll-services/enbgnbAssignment/updateGnbCapacity',
            url: gnbCapacityUpdateURL,
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            success: function (data) {
                aptAlert('Success', "Data Updated Successfully");
                configurationDataFetch();
            },
            error: function (data) {
                updatedConfigurationData = [];
                $('#loading').hide();
                aptAlert('error', 'failed');
            }
        });
    }
}

function exportToExcelForConfiguration(jsonObject, fileName) {
        var str = 'Market, Vendor, Capacity (Cells), VCU Threshold %,\r\n';
        if (val) {
            str = str.replace('Market', val['GEO4']);
        }
        let newJsonArray = []
        for (const obj of jsonObject) {
            var newJsonObject = {
                marketName: obj.marketName,
                vendor: obj.vendor,
                cellCapacity: obj.cellCapacity,
                vcuThreshold: obj.vcuThreshold,
            };
            Object.keys(newJsonObject).forEach(function (key) {
                if (newJsonObject[key] === null) {
                    newJsonObject[key] = '';
                } else {
                    newJsonObject[key] = '="' + newJsonObject[key] + '"';
                }
            })
            newJsonArray.push(newJsonObject)
        }
        var jsonObject = JSON.stringify(newJsonArray);
        var array = typeof jsonObject != 'object' ? JSON.parse(jsonObject) : jsonObject;
        for (var i = 0; i < array.length; i++) {
            var line = '';
            for (var index in array[i]) {
                if (line != '') line += ','
                line += array[i][index];
            }
            str += line + '\r\n';
        }
        var link = document.createElement("a");
        link.id = "lnkDwnldLnk";
        document.body.appendChild(link);
        var csv = str;
        blob = new Blob([str], { type: 'text/csv' });
        var csvUrl = window.webkitURL.createObjectURL(blob);
        $("#lnkDwnldLnk")
            .attr({
                'download': fileName,
                'href': csvUrl
            });
        $('#lnkDwnldLnk')[0].click();
        document.body.removeChild(link);

}

function proceedSearchConfiguration() {
    if(configurationFlag){ 
    $('#configurationTabChanges').hide();
    configurationFlag = false;
    capacityFlagCheck=false;
    vcuFlagCheck= false;
    resultVal = '';
    returnedData = '';
    clearAllDropdown();
    assignmentResetValues();
    resetValidation();
    resetEnodeAssignment();
    resetEnodeValidation();
    uniqGnbValidationTextId="";
    uniqGnbAssignmentTextId ="";
    uniqEnbAssignmentTextId ="";
    uniqEnbValidationTextId ="";
    $('#marketTabs').hide();
    $("#virtualGnbView").hide();
    $('#showVirtualDuIdss').hide()
    $("#phyGnbView").hide();
    $('#typeDropdown').html('');
    $('#typeDropdown').multiselect('destroy');
    $.each(typeDropdownList, function (i, v) {
    $('#typeDropdown').append("<option>" + v + "</option>");
    });
    $('#typeDropdown').val('', '');
    $('#typeDropdown').multiselect({
    includeSelectAllOption: true,
    enableFiltering: true,
    enableCaseInsensitiveFiltering: true,
    buttonClass: 'btn btn-default whitebg btn-sm',
    numberDisplayed: 1,
    nonSelectedText: 'None selected'
    });
    // $('#typeDropdown').multiselect({
    // includeSelectAllOption: true,
    // enableFiltering: true,
    // numberDisplayed: 1,
    // enableCaseInsensitiveFiltering: true,
    // buttonClass: 'btn btn-default whitebg btn-sm',
    // nonSelectedText: 'None selected'
    // });
    if (indexOfTabs == 1 && ParentIndex == 1) {
    $('#assignmentGrid').show();
    $('#validationViewGrid').hide();
    $('#enodeAssignmentGrid').hide();
    $('#enodeValidationViewGrid').hide();
    } else if (indexOfTabs == 2 && ParentIndex == 1) {
    $('#assignmentGrid').hide();
    $('#validationViewGrid').show();
    $('#enodeAssignmentGrid').hide();
    $('#enodeValidationViewGrid').hide();
    } else if (indexOfTabs == 1 && ParentIndex == 2) {
    $('#assignmentGrid').hide();
    $('#validationViewGrid').hide();
    $('#enodeAssignmentGrid').show();
    $('#enodeValidationViewGrid').hide();
    } else if (indexOfTabs == 2 && ParentIndex == 2) {
    $('#assignmentGrid').hide();
    $('#validationViewGrid').hide();
    $('#enodeAssignmentGrid').hide();
    $('#enodeValidationViewGrid').show();
    } 
    if (ParentIndex == 4) {
    $('#assignmentGrid').hide();
    $('#validationViewGrid').hide();
    $('#enodeAssignmentGrid').hide();
    //$('#enodeAssignmentGrid').show();
    $('#enodeValidationViewGrid').hide();
    $('#configurationViewGrid').show();
    $('#reserveMarketRange').hide();
    spreadsheetConfigurationObj.destroy();
    typeValue = '';
    creatingJSpreadsheeteConfiguration(configurationColumns, spreadsheetConfiguration, null);
    } 
} else{
        configurationFlag = false;
        capacityFlagCheck=false;
        vcuFlagCheck= false;
        $('#configurationTabChanges').hide();
        if (typeValue == "Assignment Capacity Change") {
            configurationDataFetch();
        }
        else if (typeValue == "Reserve Market Range") {
            getEnbReservedRanges();
        }
    }
}

function preResetPopup() {
    if (capacityFlagCheck || vcuFlagCheck || updatedRecords.length>0) {
        configurationFlag = true;
        $('#configurationTabChanges').show();
    }
    else {
       
		onChangeFlag = false;
		fetchAOR(userID);
	
     resetValues();
    }
       
}


function getEnbReservedRanges(){
    typeValue = $('#typeDropdown').val();
    if ((gnbAssignTerritoryList == undefined) || (gnbAssignRegionList == undefined) || (gnbAssignRegionList == "")
    || (marketsSelected == '') || (gnbAssignAreaList == undefined) || (typeValue == '') || (typeValue == undefined)) {
    alert("Please Select All the Mandatory Dropdowns");
    $('#loading').hide();
} else{
    updatedRecords = [];
    $.each(regionsDataProvider, function (index, value) {
        if (value.region === gnbAssignRegionList) {
            regionName = value.regionname;
        }
    });
    var fetchUrl;
    $('#loading').show();
    fetchUrl = fetchEnbReservedRangesPlanUrl + regionName;
    $.ajax({
        type: 'GET',
        contentType: 'application/json; charset=UTF-8',
        cache: false,
        url: fetchUrl,
        headers: {
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json'
        },
        success: function (data) {
            $('#loading').hide();
            reservationXcelData=data;
           console.log(data);
           if(data.length>0){
            reserveMarketRangeTable(data);
           }
           else {
               var emptyRow = {
                   id: nextTempId,
                   market: '',
                   eNBMinNum: '',
                   eNBMaxNum: ''
               }
               nextTempId--;
               reserveMarketRangeTable(emptyRow);
               alert("No data available!");
           }
           
        },
        error: function (data) {
            $('#loading').hide();
            aptAlert('error', 'failed');
        }
    });
}
}


function reserveMarketRangeTable(response) {
    
	var grid = $("#reserveMarketRangeGrid").kendoGrid({
		dataSource: {
            data:response,
            schema: {
                model: {
                id: "id",
                fields: {
                    market: { type: "number", validation: { required: true, min: 1, max:999}},
                    eNBMinNum: { type: "number", validation: { required: true, min: 1, max:999} },
                    eNBMaxNum : { type: "number", validation: { required: true, min: 1, max:999}}
                }
                }
            }
        },
		columns: [
            {
                command: [{name: "edit",text:"", className:"k-grid-edit-icon"},
                {name: "create",text:"", className:"add k-grid-add-icon"},
                {name: "destroy",text:"", className:"k-grid-delete-icon"}],
                title: 'Actions', 
                width: '150px'
            },
            {field:"market",title:"Market", format:"{0:0}", template: "#= (market == null) ? ' ' : kendo.toString(market, '000') #"},
            {field:"eNBMinNum",title:"Min eNB Reserve #",format:"{0:0}", template: "#= (eNBMinNum == null) ? ' ' : kendo.toString(eNBMinNum, '000') #"},
            {field:"eNBMaxNum",title:"Max eNB Reserve #",format:"{0:0}", template: "#= (eNBMaxNum == null) ? ' ' : kendo.toString(eNBMaxNum, '000') #"},
            
        ],
		sortable: true,
		filterable: {
			extra: false,
			operators: {
				string: {
					startswith: "Starts with",
					eq: "Is equal to",
					neq: "Is not equal to"
				}
			}
		},
        editable:{mode:"inline", confirmation: false,createAt: "bottom"},
		pageable: {
			pageSize: 25,
			input: true,
			numeric: false,
			pageSizes: [25, 50, 75, 100, 150, 200, "All"]

		},
        save: function (e) {

            var updatedRecord = {
                id: e.model.id,
                market: e.model.market,
                eNBMinNum: e.model.eNBMinNum,
                eNBMaxNum: e.model.eNBMaxNum
            };

            if (updatedRecord.eNBMinNum > updatedRecord.eNBMaxNum) {
                alert('Please enter valid eNB Ranges')
                e.preventDefault();
            } else {
                if (updatedRecords.length > 0) {
                    var isAdded;
                    for (var i = 0; i < updatedRecords.length; i++) {
                        if (updatedRecords[i].id == updatedRecord.id) {
                            updatedRecords[i] = updatedRecord;
                            isAdded = true;
                            return false;
                        }
                    }
                    if (!isAdded) {
                        updatedRecords.push(updatedRecord);
                    }
                }
                else {
                    updatedRecords.push(updatedRecord);
                }
                this.dataSource.options.data.push(updatedRecord);
                this.dataSource.sync();

                console.log(this.dataSource.options.data);
            }

        },
        edit: function (e){
            var model = e.model;
            model.dirty= true;
        },
        remove: function(e){
                var dataItem=e.model;
                var removeRecord = {
                    id: dataItem.id,
                    market: null,
                    eNBMinNum: dataItem.eNBMinNum,
                    eNBMaxNum: dataItem.eNBMaxNum
                };
                var id= dataItem.id;
                if(updatedRecords.length>0){
                    var isAdded;
                    for(var i=0;i<updatedRecords.length;i++){
                        if(updatedRecords[i].id==removeRecord.id){
                            updatedRecords[i]=removeRecord;
                            isAdded=true;
                            return false;
                        }
                    }
                    if(!isAdded){
                        updatedRecords.push(removeRecord);
                    }
                }
                else{
                    updatedRecords.push(removeRecord);
                }
                e.preventDefault();
                this.dataSource.remove(dataItem);
                this.dataSource.options.data.forEach(element => {
                    if(element.id!="" && element.id==id){
                        element.market=null;
                    }
                });
                this.dataSource.sync();
                console.log(this.dataSource.options.data);
            
        },
		change: function() {
            console.log(dataSource);

		},
		dataBound: function(e) {

        },
		noRecords: {
			template: "<div style='font-size:12px;color:red'>No data available</div>"
		},

	}).data("kendoGrid");
	
}

$(document).on('click', ".add", function () {
    var grid = $("#reserveMarketRangeGrid").data("kendoGrid");
    
    var createRecord = {
        id: nextTempId,
        market: '',
        eNBMinNum: '',
        eNBMaxNum: ''
    };
    nextTempId--;
    grid.dataSource.add(createRecord);
    grid.editRow(grid.tbody.children().last());
 
  });

 
  $(document).on('click', "#configurationUpdateData", function () {
   if(typeValue=="Assignment Capacity Change"){
        configurationUpdateData();
   
   }
   else if(typeValue=="Reserve Market Range"){
    if(updatedRecords.length>0){
        updateEnbRreservedRange();
    }else{
        alert("No changes exists to update!");
    }
   }
    
  });
function updateEnbRreservedRange() {
    var grid = $("#reserveMarketRangeGrid").data("kendoGrid");
    // grid.dataSource.options.data;
    for (var index = 0; index < updatedRecords.length; index++) {
        var element = updatedRecords[index];
        if (element.id < 0 && element.market == null) {
            updatedRecords.splice(index, 1);
            --index;
        }
        else if (element.id < 0 && element.market != null) {
            element.id = '';
        }
    }

    for (var index = 0; index < updatedRecords.length; index++) {
        var element = updatedRecords[index];
        if (element.id < 0) {
            updatedRecords.splice(index, 1);
            --index;
        }
    }
   

    var payloadForUpdateEnb = updatedRecords;
    $('#loading').show();
    var updateUrl;
    updateUrl = updateEnbReservedRangesPlanUrl;
    $.ajax({
        type: 'POST',
        async: false,
        contentType: 'application/json; charset=UTF-8',
        cache: false,
        data: JSON.stringify(payloadForUpdateEnb),
        url: updateUrl,
        headers: {
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json'
        },
        success: function (data) {
            $('#loading').hide();
            aptAlert('Success', "Data Updated Successfully");
            updatedRecords = [];
            getEnbReservedRanges();
        },
        error: function (data) {
            payloadForUpdateEnb = [];
            updatedRecords = [];
            $('#loading').hide();
            aptAlert('error', 'failed');
        }
    });
}



function exportToExcelForReservation() {
    var jsonObject='';
    var str; 
    var fetchUrl;
        str = 'Market, Min eNB Reserve #,Max eNB Reserve #,\r\n';
        $.each(regionsDataProvider, function (index, value) {
            if (value.region === gnbAssignRegionList) {
                regionName = value.regionname;
            }
        });
        $('#loading').show();
        fetchUrl = fetchEnbReservedRangesPlanUrl + regionName;
        $.ajax({
            type: 'GET',
            contentType: 'application/json; charset=UTF-8',
            cache: false,
            url: fetchUrl,
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json'
            },
            success: function (data) {
                $('#loading').hide();
                 jsonObject = data;
                 if(val){
                    str=str.replace('Market',val['GEO4']);
                }
                let newJsonArray = []
                for (const obj of jsonObject) {
                   
                     if (typeValue == "Reserve Market Range") {
                        var newJsonObject = {
                            market : obj.market,
                            eNBMinNum : obj.eNBMinNum,
                            eNBMaxNum : obj.eNBMaxNum
                        };
                    }
                    
                    Object.keys(newJsonObject).forEach(function(key) {
                        if(newJsonObject[key] === null) {
                            newJsonObject[key] = '';
                        }else{
                            newJsonObject[key] = '="' + newJsonObject[key] + '"';
                        }
                    })
                    newJsonArray.push(newJsonObject)
                }
                var jsonObject = JSON.stringify(newJsonArray);
                var array = typeof jsonObject != 'object' ? JSON.parse(jsonObject) : jsonObject;
                for (var i = 0; i < array.length; i++) {
                    var line = '';
                    for (var index in array[i]) {
                        if (line != '') line += ','
                        line += array[i][index];
                    }
                    str += line + '\r\n';
                }
                var link = document.createElement("a");
                link.id = "lnkDwnldLnk";
                document.body.appendChild(link);
                var csv = str;
                blob = new Blob([str], { type: 'text/csv' });
                var csvUrl = window.webkitURL.createObjectURL(blob);
                $("#lnkDwnldLnk")
                    .attr({
                        'download': 'marketRangeReservations.csv',
                        'href': csvUrl
                    });
                $('#lnkDwnldLnk')[0].click();
                document.body.removeChild(link);
            },
            error: function (data) {
                $('#loading').hide();
                aptAlert('error', 'failed');
            }
        });
    
   
   

}