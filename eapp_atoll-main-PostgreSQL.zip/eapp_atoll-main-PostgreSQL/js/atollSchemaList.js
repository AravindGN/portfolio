


var loadDumpVariables = function(){
	TERRITORY_DUMP = ['EAST', 'WEST'];
	$.ajax({
		async : false,
		url: CONTEXT_PATH + '/uui/eapp/rfds_pg/getAreaForMarketBoundary',
		type: "POST",
		data: { territoryList: TERRITORY_DUMP },
		success: function (data) {
			AREA_DUMP = JSON.parse(data).areas.map(x => x.area);
		}
	});
	$.ajax({
		async : false,
		url: CONTEXT_PATH + '/uui/eapp/rfds_pg/getRegionsForMarketBoundary',
		type: "POST",
		data: { areaList: JSON.stringify(AREA_DUMP) },
		success: function (data) {
			REGION_DUMP = JSON.parse(data).regions.map(x => x.region);
		}
	})
	$.ajax({
		async : false,
		url : CONTEXT_PATH + '/uui/eapp/rfds_pg/getMarketsForMarketBoundary',
		type : 'POST',
		data : {regionList : JSON.stringify(REGION_DUMP)},
		success : function(data){
			
			MARKET_DUMP = JSON.parse(data).markets.map(x => x.MARKET);
			marketsDataProvider = JSON.parse(data).markets;
			console.log('marketsDataProvider1', marketsDataProvider);
			if(marketsDataProvider.length == 0) {
				document.getElementById("marketDropdown").disabled = true;
			} else {
				document.getElementById("marketDropdown").disabled = false;
				for(var i = 0; i < marketsDataProvider.length; i++) {
					$('#marketDropdown').append("<option value='" + marketsDataProvider[i].MARKET + "' class='multis'>" + marketsDataProvider[i].MARKET +    "  -  "   + marketsDataProvider[i].MARKETNAME + "</option>");
				}
			}
					
				
		}
	})
}
