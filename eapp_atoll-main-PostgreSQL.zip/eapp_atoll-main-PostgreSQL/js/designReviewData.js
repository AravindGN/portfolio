var sampleResponse = {
	"marketIdentifier": "NewEnglandEast",
	"fuzeSpmId": 16448474,
	"fuzeSiteId": 441707,
	"fuzeSiteName": "0127_1 CHICAGO_SC_19 (STA-0000)",
	"parentSolutionId": 1052303,
	"spmProjectName": "16448474",
	"siteVersion": "RING",
	"equipmentBundleId": "D01a",
	"vendor": "Samsung",
	"locationInfo": {
		"locationName": "Equipment Bundle Demo",
		"coordinates": [42.25342602519468, -71.01545333862306]
	},

	"revisions": [
		{
			"revisionID": 01,
			"name": "Revision 1",
			"createdBy": "Ahmed, Elhussein",
			"createdOn": "03/23/2021 14:13",
			"status": "active",
			"transmitters": [
				{
					"name": "VZ-3-700-SAM-DB-RFV01U-D2A",
					"layer": 18,
					"antennaName": "NHH-65B-R2B_2130",
					"tx_id": "UNDEF-01 B4_20MHz_2050 Equipment Bundle Demo(RING)",
					"height": 130,
					"tilt": 0,
					"electricalTilt": 0,
					"cellSize": 2000,
					"txType": 0,
					"bfModel": null,
					"btsName": "RRH_3.00_0.00",
					"tmaName": null,
					"feederName": null,
					"feederLengthDL": 0,
					"feederLengthUL": 0,
					"miscdll": 0,
					"miscull": 0,
					"noiseFigure": 3,
					"txLosses": 0,
					"rxLosses": 0,
					"nTxAntennas": 4,
					"nRxAntennas": 4,
					"redt": 0,
					"sharedMast": null,
					"sharedPattern": null,
					"maxRange": null,
					"nTxPA": null,
					"cellEdgeMargin": 0,
					"cellIndivOffset": 0,
					"cellSectionTH": 0,
					"cellType": 1,
					"cyclicPrefix": 0,
					"dlCellEdgeTraffic": 0,
					"dlDiversitySupport": 1,
					"dlExternalNoiseRise": 0,
					"dlLoad": 50,
					"dlMaxLoad": 100,
					"equipment": "VZ LTE Equipment",
					"frameConfig": 1,
					"hoMargin": 0,
					"maxNeighbNumber": null,
					"maxExtNeighbNumber": null,
					"maxNumberofUsers": null,
					"maxPower": null,
					"minRsrp": -124,
					"nRsPorts": 4,
					"ssPowerOffset": -3,
					"ssbNumerology": 1,
					"ssbPeriodicity": 0,
					"ssbOfdmSymbols": 0,
					"tddSsfConfig": 1,
					"trafficNumerology": 1,
					"dlUlRatio": 50,
					"vzEnodebVendor": "Samsung",
					"vzEnodebModel": null,
					"vzSector": 1,
					"vzTransmitterCode": null,
					"vzEnodebId": null,
					"vzEnodebFriendName": null,
					"vzLteCellType": "Macro",
					"vzNokLtePmax": 46,
					"vzNokLteDlcellpwrred": 0,
					"vzNokLteDlrsBoost": 0,
					"vzSeaMaxTXPower": 460,
					"vzSeaTXAttenuation": 0,
					"vzSeaPowerBoostFlag": 0,
					"vzSeaPowerOption": 0,
					"vzSeaSsGain": 0,
					"vzSeaPbchGain": 0,
					"vzRrhManufacturer": "ERC",
					"vzRrhModel": "4449",
					"vzMiscTxlossCom": null,
					"vzMiscRxlossCom": null,
					"vzLteVendorPower": "Off",
					"vz5GVendorPower": "Off",
					"vzLteMaxPower": 46,
					"vz5GMaxPower": null,
					"vzEriLteMaxpower": 490,
					"fipsCode": 0,
					"initiativeType": "AWS",
					"qtyPerSector": 1,
					"radioTotalPerSector": 2,
					"azimut": 0,
					"power": null,
					"solutionId": 7293166,
					"technology": "4G",
					"uuiId": "031700ad-b43c-40f3-9e84-573924d1eefc",
					"solutionId": 7293166
				},
				{
					"name": "VZ-3-700-SAM-DB-RFV01U-D2A",
					"layer": 18,
					"antennaName": "NHH-65B-R2B_0752",
					"tx_id": "UNDEF-02 B4_20MHz_2050 Equipment Bundle Demo(RING)",
					"height": 130,
					"tilt": 0,
					"electricalTilt": 0,
					"cellSize": 2000,
					"comment": null,
					"txType": 0,
					"bfModel": null,
					"btsName": "RRH_3.00_0.00",
					"tmaName": null,
					"feederName": null,
					"feederLengthDL": 0,
					"feederLengthUL": 0,
					"miscdll": 0,
					"miscull": 0,
					"noiseFigure": 3,
					"txLosses": 0,
					"rxLosses": 0,
					"nTxAntennas": 4,
					"nRxAntennas": 4,
					"redt": 0,
					"sharedMast": null,
					"sharedPattern": null,
					"maxRange": null,
					"nTxPA": null,
					"cellEdgeMargin": 0,
					"cellIndivOffset": 0,
					"cellSectionTH": 0,
					"cellType": 1,
					"cyclicPrefix": 0,
					"dlCellEdgeTraffic": 0,
					"dlDiversitySupport": 1,
					"dlExternalNoiseRise": 0,
					"dlLoad": 50,
					"dlMaxLoad": 100,
					"equipment": "VZ LTE Equipment",
					"frameConfig": 1,
					"hoMargin": 0,
					"maxNeighbNumber": null,
					"maxExtNeighbNumber": null,
					"maxNumberofUsers": null,
					"maxPower": null,
					"minRsrp": -124,
					"nRsPorts": 4,
					"ssPowerOffset": -3,
					"ssbNumerology": 1,
					"ssbPeriodicity": 0,
					"ssbOfdmSymbols": 0,
					"tddSsfConfig": 1,
					"ulCellEdgeNR": 0,
					"ulDiversitySupport": 3,
					"ulExternalNoiseRise": 0,
					"ulFpcCinrMax": 20,
					"ulFpcFactor": 1,
					"ulFpcNrMax": 6,
					"ulLoad": 50,
					"ulMaxLoad": 100,
					"ulNoiseRise": 3,
					"trafficNumerology": 1,
					"dlUlRatio": 50,
					"vzEnodebVendor": "Samsung",
					"vzEnodebModel": null,
					"vzSector": 2,
					"vzTransmitterCode": null,
					"vzEnodebId": null,
					"vzEnodebFriendName": null,
					"vzLteCellType": "Macro",
					"vzNokLtePmax": 46,
					"vzNokLteDlcellpwrred": 0,
					"vzNokLteDlrsBoost": 0,
					"vzSeaMaxTXPower": 460,
					"vzSeaTXAttenuation": 0,
					"vzSeaPowerBoostFlag": 0,
					"vzSeaPowerOption": 0,
					"vzSeaSsGain": 0,
					"vzSeaPbchGain": 0,
					"vzRrhManufacturer": "ERC",
					"vzRrhModel": "4449",
					"vzMiscTxlossCom": null,
					"vzMiscRxlossCom": null,
					"vzLteVendorPower": "Off",
					"vz5GVendorPower": "Off",
					"vzLteMaxPower": 46,
					"vz5GMaxPower": null,
					"vzEriLteMaxpower": 490,
					"fipsCode": 0,
					"initiativeType": "PCS",
					"qtyPerSector": 1,
					"radioTotalPerSector": 2,
					"azimut": 120,
					"power": null,
					"solutionId": 7293166,
					"technology": "4G",
					"uuiId": "22d668cb-162e-47a1-94d4-86b419612a7e",
					"solutionId": 7293166
				},
				{
					"name": "VZ-3-700-SAM-DB-RFV01U-D2A",
					"layer": 18,
					"antennaName": "NHH-65B-R2B_2130",
					"tx_id": "UNDEF-03 B4_20MHz_2050 Equipment Bundle Demo(RING)",
					"height": 130,
					"tilt": 0,
					"electricalTilt": 0,
					"cellSize": 2000,
					"txType": 0,
					"bfModel": null,
					"btsName": "RRH_3.00_0.00",
					"tmaName": null,
					"feederName": null,
					"feederLengthDL": 0,
					"feederLengthUL": 0,
					"miscdll": 0,
					"miscull": 0,
					"noiseFigure": 3,
					"txLosses": 0,
					"rxLosses": 0,
					"nTxAntennas": 4,
					"nRxAntennas": 4,
					"redt": 0,
					"sharedMast": null,
					"sharedPattern": null,
					"maxRange": null,
					"nTxPA": null,
					"cellEdgeMargin": 0,
					"cellIndivOffset": 0,
					"cellSectionTH": 0,
					"cellType": 1,
					"cyclicPrefix": 0,
					"dlCellEdgeTraffic": 0,
					"dlDiversitySupport": 1,
					"dlExternalNoiseRise": 0,
					"dlLoad": 50,
					"dlMaxLoad": 100,
					"equipment": "VZ LTE Equipment",
					"frameConfig": 1,
					"hoMargin": 0,
					"maxNeighbNumber": null,
					"maxExtNeighbNumber": null,
					"maxNumberofUsers": null,
					"maxPower": null,
					"minRsrp": -124,
					"nRsPorts": 4,
					"ssPowerOffset": -3,
					"ssbNumerology": 1,
					"ssbPeriodicity": 0,
					"ssbOfdmSymbols": 0,
					"tddSsfConfig": 1,
					"trafficNumerology": 1,
					"dlUlRatio": 50,
					"vzEnodebVendor": "Samsung",
					"vzEnodebModel": null,
					"vzSector": 1,
					"vzTransmitterCode": null,
					"vzEnodebId": null,
					"vzEnodebFriendName": null,
					"vzLteCellType": "Macro",
					"vzNokLtePmax": 46,
					"vzNokLteDlcellpwrred": 0,
					"vzNokLteDlrsBoost": 0,
					"vzSeaMaxTXPower": 460,
					"vzSeaTXAttenuation": 0,
					"vzSeaPowerBoostFlag": 0,
					"vzSeaPowerOption": 0,
					"vzSeaSsGain": 0,
					"vzSeaPbchGain": 0,
					"vzRrhManufacturer": "ERC",
					"vzRrhModel": "8843",
					"vzMiscTxlossCom": null,
					"vzMiscRxlossCom": null,
					"vzLteVendorPower": "Off",
					"vz5GVendorPower": "Off",
					"vzLteMaxPower": 46,
					"vz5GMaxPower": null,
					"vzEriLteMaxpower": 490,
					"fipsCode": 0,
					"initiativeType": "PCS",
					"qtyPerSector": 1,
					"radioTotalPerSector": 2,
					"azimut": 240,
					"power": null,
					"solutionId": 7293163,
					"technology": "4G",
					"uuiId": "92892a92-a1d5-43dc-8cea-1b0f0765e56e"
				},
				{
					"name": "VZ-3-700-SAM-DB-RFV01U-D2A",
					"layer": 18,
					"antennaName": "NHH-65B-R2B_2130",
					"tx_id": "UNDEF-01 B2_15MHz_1025 Equipment Bundle Demo(RING)",
					"height": 130,
					"tilt": 0,
					"electricalTilt": 0,
					"cellSize": 2000,
					"comment": null,
					"txType": 0,
					"bfModel": null,
					"btsName": "RRH_3.00_0.00",
					"tmaName": null,
					"feederName": null,
					"feederLengthDL": 0,
					"feederLengthUL": 0,
					"miscdll": 0,
					"miscull": 0,
					"noiseFigure": 3,
					"txLosses": 0,
					"rxLosses": 0,
					"nTxAntennas": 4,
					"nRxAntennas": 4,
					"redt": 0,
					"sharedMast": null,
					"sharedPattern": null,
					"maxRange": null,
					"nTxPA": null,
					"cellEdgeMargin": 0,
					"cellIndivOffset": 0,
					"cellSectionTH": 0,
					"cellType": 1,
					"cyclicPrefix": 0,
					"dlCellEdgeTraffic": 0,
					"dlDiversitySupport": 1,
					"dlExternalNoiseRise": 0,
					"dlLoad": 50,
					"dlMaxLoad": 100,
					"equipment": "VZ LTE Equipment",
					"frameConfig": 1,
					"hoMargin": 0,
					"maxNeighbNumber": null,
					"maxExtNeighbNumber": null,
					"maxNumberofUsers": null,
					"maxPower": null,
					"minRsrp": -124,
					"nRsPorts": 4,
					"ssPowerOffset": -3,
					"ssbNumerology": 1,
					"ssbPeriodicity": 0,
					"ssbOfdmSymbols": 0,
					"tddSsfConfig": 1,
					"ulCellEdgeNR": 0,
					"ulDiversitySupport": 3,
					"ulExternalNoiseRise": 0,
					"ulFpcCinrMax": 20,
					"ulFpcFactor": 1,
					"ulFpcNrMax": 6,
					"ulLoad": 50,
					"ulMaxLoad": 100,
					"ulNoiseRise": 3,
					"trafficNumerology": 1,
					"dlUlRatio": 50,
					"vzEnodebVendor": "Samsung",
					"vzEnodebModel": null,
					"vzSector": 2,
					"vzTransmitterCode": null,
					"vzEnodebId": null,
					"vzEnodebFriendName": null,
					"vzLteCellType": "Macro",
					"vzNokLtePmax": 46,
					"vzNokLteDlcellpwrred": 0,
					"vzNokLteDlrsBoost": 0,
					"vzSeaMaxTXPower": 460,
					"vzSeaTXAttenuation": 0,
					"vzSeaPowerBoostFlag": 0,
					"vzSeaPowerOption": 0,
					"vzSeaSsGain": 0,
					"vzSeaPbchGain": 0,
					"vzRrhManufacturer": "ERC",
					"vzRrhModel": "8843",
					"vzMiscTxlossCom": null,
					"vzMiscRxlossCom": null,
					"vzLteVendorPower": "Off",
					"vz5GVendorPower": "Off",
					"vzLteMaxPower": 46,
					"vz5GMaxPower": null,
					"vzEriLteMaxpower": 490,
					"fipsCode": 0,
					"initiativeType": "PCS",
					"qtyPerSector": 1,
					"radioTotalPerSector": 2,
					"azimut": 0,
					"power": null,
					"solutionId": 7293163,
					"technology": "4G",
					"uuiId": "cf5acc83-ccfe-4b15-9e1e-b4dbfbac4e92"
				},
				{
					"name": "VZ-3-700-SAM-DB-RFV01U-D2A",
					"layer": 18,
					"antennaName": "NHH-65B-R2B_2130",
					"tx_id": "UNDEF-02 B2_15MHz_1025 Equipment Bundle Demo(RING)",
					"height": 130,
					"tilt": 0,
					"electricalTilt": 0,
					"cellSize": 2000,
					"comment": null,
					"txType": 0,
					"bfModel": null,
					"btsName": "RRH_3.00_0.00",
					"tmaName": null,
					"feederName": null,
					"feederLengthDL": 0,
					"feederLengthUL": 0,
					"miscdll": 0,
					"miscull": 0,
					"noiseFigure": 3,
					"txLosses": 0,
					"rxLosses": 0,
					"nTxAntennas": 4,
					"nRxAntennas": 4,
					"redt": 0,
					"sharedMast": null,
					"sharedPattern": null,
					"maxRange": null,
					"nTxPA": null,
					"cellEdgeMargin": 0,
					"cellIndivOffset": 0,
					"cellSectionTH": 0,
					"cellType": 1,
					"cyclicPrefix": 0,
					"dlCellEdgeTraffic": 0,
					"dlDiversitySupport": 1,
					"dlExternalNoiseRise": 0,
					"dlLoad": 50,
					"dlMaxLoad": 100,
					"equipment": "VZ LTE Equipment",
					"frameConfig": 1,
					"hoMargin": 0,
					"maxNeighbNumber": null,
					"maxExtNeighbNumber": null,
					"maxNumberofUsers": null,
					"maxPower": null,
					"minRsrp": -124,
					"nRsPorts": 4,
					"ssPowerOffset": -3,
					"ssbNumerology": 1,
					"ssbPeriodicity": 0,
					"ssbOfdmSymbols": 0,
					"tddSsfConfig": 1,
					"ulCellEdgeNR": 0,
					"ulDiversitySupport": 3,
					"ulExternalNoiseRise": 0,
					"ulFpcCinrMax": 20,
					"ulFpcFactor": 1,
					"ulFpcNrMax": 6,
					"ulLoad": 50,
					"ulMaxLoad": 100,
					"ulNoiseRise": 3,
					"trafficNumerology": 1,
					"dlUlRatio": 50,
					"vzEnodebVendor": "Samsung",
					"vzEnodebModel": null,
					"vzSector": 2,
					"vzTransmitterCode": null,
					"vzEnodebId": null,
					"vzEnodebFriendName": null,
					"vzLteCellType": "Macro",
					"vzNokLtePmax": 46,
					"vzNokLteDlcellpwrred": 0,
					"vzNokLteDlrsBoost": 0,
					"vzSeaMaxTXPower": 460,
					"vzSeaTXAttenuation": 0,
					"vzSeaPowerBoostFlag": 0,
					"vzSeaPowerOption": 0,
					"vzSeaSsGain": 0,
					"vzSeaPbchGain": 0,
					"vzRrhManufacturer": "ERC",
					"vzRrhModel": "8843",
					"vzMiscTxlossCom": null,
					"vzMiscRxlossCom": null,
					"vzLteVendorPower": "Off",
					"vz5GVendorPower": "Off",
					"vzLteMaxPower": 46,
					"vz5GMaxPower": null,
					"vzEriLteMaxpower": 490,
					"fipsCode": 0,
					"initiativeType": "PCS",
					"qtyPerSector": 1,
					"radioTotalPerSector": 2,
					"azimut": 120,
					"power": null,
					"solutionId": 7293163,
					"technology": "4G",
					"uuiId": "cf5acc83-ccfe-4b15-9e1e-b4dbfbac4e92"
				},
				{
					"name": "VZ-3-700-SAM-DB-RFV01U-D2A",
					"layer": 18,
					"antennaName": "NHH-65B-R2B_2130",
					"tx_id": "UNDEF-03 B2_15MHz_1025 Equipment Bundle Demo(RING)",
					"height": 130,
					"tilt": 0,
					"electricalTilt": 0,
					"cellSize": 2000,
					"comment": null,
					"txType": 0,
					"bfModel": null,
					"btsName": "RRH_3.00_0.00",
					"tmaName": null,
					"feederName": null,
					"feederLengthDL": 0,
					"feederLengthUL": 0,
					"miscdll": 0,
					"miscull": 0,
					"noiseFigure": 3,
					"txLosses": 0,
					"rxLosses": 0,
					"nTxAntennas": 4,
					"nRxAntennas": 4,
					"redt": 0,
					"sharedMast": null,
					"sharedPattern": null,
					"maxRange": null,
					"nTxPA": null,
					"cellEdgeMargin": 0,
					"cellIndivOffset": 0,
					"cellSectionTH": 0,
					"cellType": 1,
					"cyclicPrefix": 0,
					"dlCellEdgeTraffic": 0,
					"dlDiversitySupport": 1,
					"dlExternalNoiseRise": 0,
					"dlLoad": 50,
					"dlMaxLoad": 100,
					"equipment": "VZ LTE Equipment",
					"frameConfig": 1,
					"hoMargin": 0,
					"maxNeighbNumber": null,
					"maxExtNeighbNumber": null,
					"maxNumberofUsers": null,
					"maxPower": null,
					"minRsrp": -124,
					"nRsPorts": 4,
					"ssPowerOffset": -3,
					"ssbNumerology": 1,
					"ssbPeriodicity": 0,
					"ssbOfdmSymbols": 0,
					"tddSsfConfig": 1,
					"ulCellEdgeNR": 0,
					"ulDiversitySupport": 3,
					"ulExternalNoiseRise": 0,
					"ulFpcCinrMax": 20,
					"ulFpcFactor": 1,
					"ulFpcNrMax": 6,
					"ulLoad": 50,
					"ulMaxLoad": 100,
					"ulNoiseRise": 3,
					"trafficNumerology": 1,
					"dlUlRatio": 50,
					"vzEnodebVendor": "Samsung",
					"vzEnodebModel": null,
					"vzSector": 2,
					"vzTransmitterCode": null,
					"vzEnodebId": null,
					"vzEnodebFriendName": null,
					"vzLteCellType": "Macro",
					"vzNokLtePmax": 46,
					"vzNokLteDlcellpwrred": 0,
					"vzNokLteDlrsBoost": 0,
					"vzSeaMaxTXPower": 460,
					"vzSeaTXAttenuation": 0,
					"vzSeaPowerBoostFlag": 0,
					"vzSeaPowerOption": 0,
					"vzSeaSsGain": 0,
					"vzSeaPbchGain": 0,
					"vzRrhManufacturer": "ERC",
					"vzRrhModel": "8843",
					"vzMiscTxlossCom": null,
					"vzMiscRxlossCom": null,
					"vzLteVendorPower": "Off",
					"vz5GVendorPower": "Off",
					"vzLteMaxPower": 46,
					"vz5GMaxPower": null,
					"vzEriLteMaxpower": 490,
					"fipsCode": 0,
					"initiativeType": "PCS",
					"qtyPerSector": 1,
					"radioTotalPerSector": 2,
					"azimut": 240,
					"power": null,
					"solutionId": 7293163,
					"technology": "4G",
					"uuiId": "cf5acc83-ccfe-4b15-9e1e-b4dbfbac4e92"
				}
			],
			"carriers": [{
				"tx_id": "UNDEF-01 B4_20MHz_2050 Equipment Bundle Demo(RING)",
				"cell_id": "UNDEF-01 B4_20MHz_2050",
				"band": "B4",
				"centerChannel": "2050",
				"label": "F2",
				"bandWidth": "20MHz",
				"XC_VZ_BAND_CLASS":"B4"
			},
			{
				"tx_id": "UNDEF-02 B4_20MHz_2050 Equipment Bundle Demo(RING)",
				"cell_id": "UNDEF-02 B4_20MHz_2050",
				"band": "B4",
				"centerChannel": "2050",
				"label": "F3",
				"bandWidth": "20MHz",
				"XC_VZ_BAND_CLASS":"B4"

			},
			{
				"tx_id": "UNDEF-03 B4_20MHz_2050 Equipment Bundle Demo(RING)",
				"cell_id": "UNDEF-03 B4_20MHz_2050",
				"band": "B4",
				"centerChannel": "2050",
				"label": "F4",
				"bandWidth": "20MHz",
				"XC_VZ_BAND_CLASS":"B4"
			},
			{
				"tx_id": "UNDEF-01 B2_15MHz_1025 Equipment Bundle Demo(RING)",
				"cell_id": "UNDEF-01 B2_15MHz_1025",
				"band": "B2",
				"centerChannel": "1025",
				"label": "F4",
				"bandWidth": "15MHz",
				"XC_VZ_BAND_CLASS":"B4"
			},
			{
				"tx_id": "UNDEF-02 B2_15MHz_1025 Equipment Bundle Demo(RING)",
				"cell_id": "UNDEF-02 B2_15MHz_1025",
				"band": "B2",
				"centerChannel": "1025",
				"label": "F4",
				"bandWidth": "15MHz",
				"XC_VZ_BAND_CLASS":"B4"
			},
			{
				"tx_id": "UNDEF-03 B2_15MHz_1025 Equipment Bundle Demo(RING)",
				"cell_id": "UNDEF-03 B2_15MHz_1025",
				"band": "B2",
				"centerChannel": "1025",
				"label": "F4",
				"bandWidth": "15MHz",
				"XC_VZ_BAND_CLASS":"B4"
			}
			]
		},
		{
			"revisionID": 02,
			"name": "Revision 2",
			"createdBy": "Ahmed, Elhussein",
			"createdOn": "03/23/2021 14:13",
			"status": "active",
			"transmitters": [
				{
					"name": "VZ-3-700-SAM-DB-RFV01U-D2A",
					"layer": 18,
					"antennaName": "NHH-65B-R2B_2130",
					"tx_id": "UNDEF-01 B4_20MHz_2050 Equipment Bundle Demo(RING)",
					"height": 130,
					"tilt": 0,
					"electricalTilt": 0,
					"cellSize": 2000,
					"txType": 0,
					"bfModel": null,
					"btsName": "RRH_3.00_0.00",
					"tmaName": null,
					"feederName": null,
					"feederLengthDL": 0,
					"feederLengthUL": 0,
					"miscdll": 0,
					"miscull": 0,
					"noiseFigure": 3,
					"txLosses": 0,
					"rxLosses": 0,
					"nTxAntennas": 4,
					"nRxAntennas": 4,
					"redt": 0,
					"sharedMast": null,
					"sharedPattern": null,
					"maxRange": null,
					"nTxPA": null,
					"cellEdgeMargin": 0,
					"cellIndivOffset": 0,
					"cellSectionTH": 0,
					"cellType": 1,
					"cyclicPrefix": 0,
					"dlCellEdgeTraffic": 0,
					"dlDiversitySupport": 1,
					"dlExternalNoiseRise": 0,
					"dlLoad": 50,
					"dlMaxLoad": 100,
					"equipment": "VZ LTE Equipment",
					"frameConfig": 1,
					"hoMargin": 0,
					"maxNeighbNumber": null,
					"maxExtNeighbNumber": null,
					"maxNumberofUsers": null,
					"maxPower": null,
					"minRsrp": -124,
					"nRsPorts": 4,
					"ssPowerOffset": -3,
					"ssbNumerology": 1,
					"ssbPeriodicity": 0,
					"ssbOfdmSymbols": 0,
					"tddSsfConfig": 1,
					"trafficNumerology": 1,
					"dlUlRatio": 50,
					"vzEnodebVendor": "Samsung",
					"vzEnodebModel": null,
					"vzSector": 1,
					"vzTransmitterCode": null,
					"vzEnodebId": null,
					"vzEnodebFriendName": null,
					"vzLteCellType": "Macro",
					"vzNokLtePmax": 46,
					"vzNokLteDlcellpwrred": 0,
					"vzNokLteDlrsBoost": 0,
					"vzSeaMaxTXPower": 460,
					"vzSeaTXAttenuation": 0,
					"vzSeaPowerBoostFlag": 0,
					"vzSeaPowerOption": 0,
					"vzSeaSsGain": 0,
					"vzSeaPbchGain": 0,
					"vzRrhManufacturer": "ERC",
					"vzRrhModel": "4449",
					"vzMiscTxlossCom": null,
					"vzMiscRxlossCom": null,
					"vzLteVendorPower": "Off",
					"vz5GVendorPower": "Off",
					"vzLteMaxPower": 46,
					"vz5GMaxPower": null,
					"vzEriLteMaxpower": 490,
					"fipsCode": 0,
					"initiativeType": "AWS",
					"qtyPerSector": 1,
					"radioTotalPerSector": 2,
					"azimut": 120,
					"power": null,
					"solutionId": 7293166,
					"technology": "4G",
					"uuiId": "031700ad-b43c-40f3-9e84-573924d1eefc",
					"solutionId": 7293166
				},
				{
					"name": "VZ-3-700-SAM-DB-RFV01U-D2A",
					"layer": 18,
					"antennaName": "NHH-65B-R2B_0752",
					"tx_id": "UNDEF-02 B4_20MHz_2050 Equipment Bundle Demo(RING)",
					"height": 130,
					"tilt": 0,
					"electricalTilt": 0,
					"cellSize": 2000,
					"comment": null,
					"txType": 0,
					"bfModel": null,
					"btsName": "RRH_3.00_0.00",
					"tmaName": null,
					"feederName": null,
					"feederLengthDL": 0,
					"feederLengthUL": 0,
					"miscdll": 0,
					"miscull": 0,
					"noiseFigure": 3,
					"txLosses": 0,
					"rxLosses": 0,
					"nTxAntennas": 4,
					"nRxAntennas": 4,
					"redt": 0,
					"sharedMast": null,
					"sharedPattern": null,
					"maxRange": null,
					"nTxPA": null,
					"cellEdgeMargin": 0,
					"cellIndivOffset": 0,
					"cellSectionTH": 0,
					"cellType": 1,
					"cyclicPrefix": 0,
					"dlCellEdgeTraffic": 0,
					"dlDiversitySupport": 1,
					"dlExternalNoiseRise": 0,
					"dlLoad": 50,
					"dlMaxLoad": 100,
					"equipment": "VZ LTE Equipment",
					"frameConfig": 1,
					"hoMargin": 0,
					"maxNeighbNumber": null,
					"maxExtNeighbNumber": null,
					"maxNumberofUsers": null,
					"maxPower": null,
					"minRsrp": -124,
					"nRsPorts": 4,
					"ssPowerOffset": -3,
					"ssbNumerology": 1,
					"ssbPeriodicity": 0,
					"ssbOfdmSymbols": 0,
					"tddSsfConfig": 1,
					"ulCellEdgeNR": 0,
					"ulDiversitySupport": 3,
					"ulExternalNoiseRise": 0,
					"ulFpcCinrMax": 20,
					"ulFpcFactor": 1,
					"ulFpcNrMax": 6,
					"ulLoad": 50,
					"ulMaxLoad": 100,
					"ulNoiseRise": 3,
					"trafficNumerology": 1,
					"dlUlRatio": 50,
					"vzEnodebVendor": "Samsung",
					"vzEnodebModel": null,
					"vzSector": 2,
					"vzTransmitterCode": null,
					"vzEnodebId": null,
					"vzEnodebFriendName": null,
					"vzLteCellType": "Macro",
					"vzNokLtePmax": 46,
					"vzNokLteDlcellpwrred": 0,
					"vzNokLteDlrsBoost": 0,
					"vzSeaMaxTXPower": 460,
					"vzSeaTXAttenuation": 0,
					"vzSeaPowerBoostFlag": 0,
					"vzSeaPowerOption": 0,
					"vzSeaSsGain": 0,
					"vzSeaPbchGain": 0,
					"vzRrhManufacturer": "ERC",
					"vzRrhModel": "4449",
					"vzMiscTxlossCom": null,
					"vzMiscRxlossCom": null,
					"vzLteVendorPower": "Off",
					"vz5GVendorPower": "Off",
					"vzLteMaxPower": 46,
					"vz5GMaxPower": null,
					"vzEriLteMaxpower": 490,
					"fipsCode": 0,
					"initiativeType": "PCS",
					"qtyPerSector": 1,
					"radioTotalPerSector": 2,
					"azimut": 0,
					"power": null,
					"solutionId": 7293166,
					"technology": "4G",
					"uuiId": "22d668cb-162e-47a1-94d4-86b419612a7e",
					"solutionId": 7293166
				},
				{
					"name": "VZ-3-700-SAM-DB-RFV01U-D2A",
					"layer": 18,
					"antennaName": "NHH-65B-R2B_2130",
					"tx_id": "UNDEF-03 B4_20MHz_2050 Equipment Bundle Demo(RING)",
					"height": 130,
					"tilt": 0,
					"electricalTilt": 0,
					"cellSize": 2000,
					"txType": 0,
					"bfModel": null,
					"btsName": "RRH_3.00_0.00",
					"tmaName": null,
					"feederName": null,
					"feederLengthDL": 0,
					"feederLengthUL": 0,
					"miscdll": 0,
					"miscull": 0,
					"noiseFigure": 3,
					"txLosses": 0,
					"rxLosses": 0,
					"nTxAntennas": 4,
					"nRxAntennas": 4,
					"redt": 0,
					"sharedMast": null,
					"sharedPattern": null,
					"maxRange": null,
					"nTxPA": null,
					"cellEdgeMargin": 0,
					"cellIndivOffset": 0,
					"cellSectionTH": 0,
					"cellType": 1,
					"cyclicPrefix": 0,
					"dlCellEdgeTraffic": 0,
					"dlDiversitySupport": 1,
					"dlExternalNoiseRise": 0,
					"dlLoad": 50,
					"dlMaxLoad": 100,
					"equipment": "VZ LTE Equipment",
					"frameConfig": 1,
					"hoMargin": 0,
					"maxNeighbNumber": null,
					"maxExtNeighbNumber": null,
					"maxNumberofUsers": null,
					"maxPower": null,
					"minRsrp": -124,
					"nRsPorts": 4,
					"ssPowerOffset": -3,
					"ssbNumerology": 1,
					"ssbPeriodicity": 0,
					"ssbOfdmSymbols": 0,
					"tddSsfConfig": 1,
					"trafficNumerology": 1,
					"dlUlRatio": 50,
					"vzEnodebVendor": "Samsung",
					"vzEnodebModel": null,
					"vzSector": 1,
					"vzTransmitterCode": null,
					"vzEnodebId": null,
					"vzEnodebFriendName": null,
					"vzLteCellType": "Macro",
					"vzNokLtePmax": 46,
					"vzNokLteDlcellpwrred": 0,
					"vzNokLteDlrsBoost": 0,
					"vzSeaMaxTXPower": 460,
					"vzSeaTXAttenuation": 0,
					"vzSeaPowerBoostFlag": 0,
					"vzSeaPowerOption": 0,
					"vzSeaSsGain": 0,
					"vzSeaPbchGain": 0,
					"vzRrhManufacturer": "ERC",
					"vzRrhModel": "8843",
					"vzMiscTxlossCom": null,
					"vzMiscRxlossCom": null,
					"vzLteVendorPower": "Off",
					"vz5GVendorPower": "Off",
					"vzLteMaxPower": 46,
					"vz5GMaxPower": null,
					"vzEriLteMaxpower": 490,
					"fipsCode": 0,
					"initiativeType": "PCS",
					"qtyPerSector": 1,
					"radioTotalPerSector": 2,
					"azimut": 240,
					"power": null,
					"solutionId": 7293163,
					"technology": "4G",
					"uuiId": "92892a92-a1d5-43dc-8cea-1b0f0765e56e"
				},
				{
					"name": "VZ-3-700-SAM-DB-RFV01U-D2A",
					"layer": 18,
					"antennaName": "NHH-65B-R2B_2130",
					"tx_id": "UNDEF-01 B2_15MHz_1025 Equipment Bundle Demo(RING)",
					"height": 130,
					"tilt": 0,
					"electricalTilt": 0,
					"cellSize": 2000,
					"comment": null,
					"txType": 0,
					"bfModel": null,
					"btsName": "RRH_3.00_0.00",
					"tmaName": null,
					"feederName": null,
					"feederLengthDL": 0,
					"feederLengthUL": 0,
					"miscdll": 0,
					"miscull": 0,
					"noiseFigure": 3,
					"txLosses": 0,
					"rxLosses": 0,
					"nTxAntennas": 4,
					"nRxAntennas": 4,
					"redt": 0,
					"sharedMast": null,
					"sharedPattern": null,
					"maxRange": null,
					"nTxPA": null,
					"cellEdgeMargin": 0,
					"cellIndivOffset": 0,
					"cellSectionTH": 0,
					"cellType": 1,
					"cyclicPrefix": 0,
					"dlCellEdgeTraffic": 0,
					"dlDiversitySupport": 1,
					"dlExternalNoiseRise": 0,
					"dlLoad": 50,
					"dlMaxLoad": 100,
					"equipment": "VZ LTE Equipment",
					"frameConfig": 1,
					"hoMargin": 0,
					"maxNeighbNumber": null,
					"maxExtNeighbNumber": null,
					"maxNumberofUsers": null,
					"maxPower": null,
					"minRsrp": -124,
					"nRsPorts": 4,
					"ssPowerOffset": -3,
					"ssbNumerology": 1,
					"ssbPeriodicity": 0,
					"ssbOfdmSymbols": 0,
					"tddSsfConfig": 1,
					"ulCellEdgeNR": 0,
					"ulDiversitySupport": 3,
					"ulExternalNoiseRise": 0,
					"ulFpcCinrMax": 20,
					"ulFpcFactor": 1,
					"ulFpcNrMax": 6,
					"ulLoad": 50,
					"ulMaxLoad": 100,
					"ulNoiseRise": 3,
					"trafficNumerology": 1,
					"dlUlRatio": 50,
					"vzEnodebVendor": "Samsung",
					"vzEnodebModel": null,
					"vzSector": 2,
					"vzTransmitterCode": null,
					"vzEnodebId": null,
					"vzEnodebFriendName": null,
					"vzLteCellType": "Macro",
					"vzNokLtePmax": 46,
					"vzNokLteDlcellpwrred": 0,
					"vzNokLteDlrsBoost": 0,
					"vzSeaMaxTXPower": 460,
					"vzSeaTXAttenuation": 0,
					"vzSeaPowerBoostFlag": 0,
					"vzSeaPowerOption": 0,
					"vzSeaSsGain": 0,
					"vzSeaPbchGain": 0,
					"vzRrhManufacturer": "ERC",
					"vzRrhModel": "8843",
					"vzMiscTxlossCom": null,
					"vzMiscRxlossCom": null,
					"vzLteVendorPower": "Off",
					"vz5GVendorPower": "Off",
					"vzLteMaxPower": 46,
					"vz5GMaxPower": null,
					"vzEriLteMaxpower": 490,
					"fipsCode": 0,
					"initiativeType": "PCS",
					"qtyPerSector": 1,
					"radioTotalPerSector": 2,
					"azimut": 0,
					"power": null,
					"solutionId": 7293163,
					"technology": "4G",
					"uuiId": "cf5acc83-ccfe-4b15-9e1e-b4dbfbac4e92"
				},
				{
					"name": "VZ-3-700-SAM-DB-RFV01U-D2A",
					"layer": 18,
					"antennaName": "NHH-65B-R2B_2130",
					"tx_id": "UNDEF-02 B2_15MHz_1025 Equipment Bundle Demo(RING)",
					"height": 130,
					"tilt": 0,
					"electricalTilt": 0,
					"cellSize": 2000,
					"comment": null,
					"txType": 0,
					"bfModel": null,
					"btsName": "RRH_3.00_0.00",
					"tmaName": null,
					"feederName": null,
					"feederLengthDL": 0,
					"feederLengthUL": 0,
					"miscdll": 0,
					"miscull": 0,
					"noiseFigure": 3,
					"txLosses": 0,
					"rxLosses": 0,
					"nTxAntennas": 4,
					"nRxAntennas": 4,
					"redt": 0,
					"sharedMast": null,
					"sharedPattern": null,
					"maxRange": null,
					"nTxPA": null,
					"cellEdgeMargin": 0,
					"cellIndivOffset": 0,
					"cellSectionTH": 0,
					"cellType": 1,
					"cyclicPrefix": 0,
					"dlCellEdgeTraffic": 0,
					"dlDiversitySupport": 1,
					"dlExternalNoiseRise": 0,
					"dlLoad": 50,
					"dlMaxLoad": 100,
					"equipment": "VZ LTE Equipment",
					"frameConfig": 1,
					"hoMargin": 0,
					"maxNeighbNumber": null,
					"maxExtNeighbNumber": null,
					"maxNumberofUsers": null,
					"maxPower": null,
					"minRsrp": -124,
					"nRsPorts": 4,
					"ssPowerOffset": -3,
					"ssbNumerology": 1,
					"ssbPeriodicity": 0,
					"ssbOfdmSymbols": 0,
					"tddSsfConfig": 1,
					"ulCellEdgeNR": 0,
					"ulDiversitySupport": 3,
					"ulExternalNoiseRise": 0,
					"ulFpcCinrMax": 20,
					"ulFpcFactor": 1,
					"ulFpcNrMax": 6,
					"ulLoad": 50,
					"ulMaxLoad": 100,
					"ulNoiseRise": 3,
					"trafficNumerology": 1,
					"dlUlRatio": 50,
					"vzEnodebVendor": "Samsung",
					"vzEnodebModel": null,
					"vzSector": 2,
					"vzTransmitterCode": null,
					"vzEnodebId": null,
					"vzEnodebFriendName": null,
					"vzLteCellType": "Macro",
					"vzNokLtePmax": 46,
					"vzNokLteDlcellpwrred": 0,
					"vzNokLteDlrsBoost": 0,
					"vzSeaMaxTXPower": 460,
					"vzSeaTXAttenuation": 0,
					"vzSeaPowerBoostFlag": 0,
					"vzSeaPowerOption": 0,
					"vzSeaSsGain": 0,
					"vzSeaPbchGain": 0,
					"vzRrhManufacturer": "ERC",
					"vzRrhModel": "8843",
					"vzMiscTxlossCom": null,
					"vzMiscRxlossCom": null,
					"vzLteVendorPower": "Off",
					"vz5GVendorPower": "Off",
					"vzLteMaxPower": 46,
					"vz5GMaxPower": null,
					"vzEriLteMaxpower": 490,
					"fipsCode": 0,
					"initiativeType": "PCS",
					"qtyPerSector": 1,
					"radioTotalPerSector": 2,
					"azimut": 120,
					"power": null,
					"solutionId": 7293163,
					"technology": "4G",
					"uuiId": "cf5acc83-ccfe-4b15-9e1e-b4dbfbac4e92"
				},
				{
					"name": "VZ-3-700-SAM-DB-RFV01U-D2A",
					"layer": 18,
					"antennaName": "NHH-65B-R2B_2130",
					"tx_id": "UNDEF-03 B2_15MHz_1025 Equipment Bundle Demo(RING)",
					"height": 130,
					"tilt": 0,
					"electricalTilt": 0,
					"cellSize": 2000,
					"comment": null,
					"txType": 0,
					"bfModel": null,
					"btsName": "RRH_3.00_0.00",
					"tmaName": null,
					"feederName": null,
					"feederLengthDL": 0,
					"feederLengthUL": 0,
					"miscdll": 0,
					"miscull": 0,
					"noiseFigure": 3,
					"txLosses": 0,
					"rxLosses": 0,
					"nTxAntennas": 4,
					"nRxAntennas": 4,
					"redt": 0,
					"sharedMast": null,
					"sharedPattern": null,
					"maxRange": null,
					"nTxPA": null,
					"cellEdgeMargin": 0,
					"cellIndivOffset": 0,
					"cellSectionTH": 0,
					"cellType": 1,
					"cyclicPrefix": 0,
					"dlCellEdgeTraffic": 0,
					"dlDiversitySupport": 1,
					"dlExternalNoiseRise": 0,
					"dlLoad": 50,
					"dlMaxLoad": 100,
					"equipment": "VZ LTE Equipment",
					"frameConfig": 1,
					"hoMargin": 0,
					"maxNeighbNumber": null,
					"maxExtNeighbNumber": null,
					"maxNumberofUsers": null,
					"maxPower": null,
					"minRsrp": -124,
					"nRsPorts": 4,
					"ssPowerOffset": -3,
					"ssbNumerology": 1,
					"ssbPeriodicity": 0,
					"ssbOfdmSymbols": 0,
					"tddSsfConfig": 1,
					"ulCellEdgeNR": 0,
					"ulDiversitySupport": 3,
					"ulExternalNoiseRise": 0,
					"ulFpcCinrMax": 20,
					"ulFpcFactor": 1,
					"ulFpcNrMax": 6,
					"ulLoad": 50,
					"ulMaxLoad": 100,
					"ulNoiseRise": 3,
					"trafficNumerology": 1,
					"dlUlRatio": 50,
					"vzEnodebVendor": "Samsung",
					"vzEnodebModel": null,
					"vzSector": 2,
					"vzTransmitterCode": null,
					"vzEnodebId": null,
					"vzEnodebFriendName": null,
					"vzLteCellType": "Macro",
					"vzNokLtePmax": 46,
					"vzNokLteDlcellpwrred": 0,
					"vzNokLteDlrsBoost": 0,
					"vzSeaMaxTXPower": 460,
					"vzSeaTXAttenuation": 0,
					"vzSeaPowerBoostFlag": 0,
					"vzSeaPowerOption": 0,
					"vzSeaSsGain": 0,
					"vzSeaPbchGain": 0,
					"vzRrhManufacturer": "ERC",
					"vzRrhModel": "8843",
					"vzMiscTxlossCom": null,
					"vzMiscRxlossCom": null,
					"vzLteVendorPower": "Off",
					"vz5GVendorPower": "Off",
					"vzLteMaxPower": 46,
					"vz5GMaxPower": null,
					"vzEriLteMaxpower": 490,
					"fipsCode": 0,
					"initiativeType": "PCS",
					"qtyPerSector": 1,
					"radioTotalPerSector": 2,
					"azimut": 240,
					"power": null,
					"solutionId": 7293163,
					"technology": "4G",
					"uuiId": "cf5acc83-ccfe-4b15-9e1e-b4dbfbac4e92"
				}
			],
			"carriers": [{
				"tx_id": "UNDEF-01 B4_20MHz_2050 Equipment Bundle Demo(RING)",
				"cell_id": "UNDEF-01 B4_20MHz_2050",
				"band": "B4",
				"centerChannel": "2050",
				"label": "F1",
				"bandWidth": "20MHz",
				"XC_VZ_BAND_CLASS":"B4"
			},
			{
				"tx_id": "UNDEF-02 B4_20MHz_2050 Equipment Bundle Demo(RING)",
				"cell_id": "UNDEF-02 B4_20MHz_2050",
				"band": "B4",
				"centerChannel": "2050",
				"label": "F1",
				"bandWidth": "20MHz",
				"XC_VZ_BAND_CLASS":"B4"
			},
			{
				"tx_id": "UNDEF-03 B4_20MHz_2050 Equipment Bundle Demo(RING)",
				"cell_id": "UNDEF-03 B4_20MHz_2050",
				"band": "B4",
				"centerChannel": "2050",
				"label": "F4",
				"bandWidth": "20MHz",
				"XC_VZ_BAND_CLASS":"B4"
			},
			{
				"tx_id": "UNDEF-01 B2_15MHz_1025 Equipment Bundle Demo(RING)",
				"cell_id": "UNDEF-01 B2_15MHz_1025",
				"band": "B2",
				"centerChannel": "1025",
				"label": "F4",
				"bandWidth": "15MHz",
				"XC_VZ_BAND_CLASS":"B4"
			},
			{
				"tx_id": "UNDEF-02 B2_15MHz_1025 Equipment Bundle Demo(RING)",
				"cell_id": "UNDEF-02 B2_15MHz_1025",
				"band": "B2",
				"centerChannel": "1025",
				"label": "F4",
				"bandWidth": "15MHz",
				"XC_VZ_BAND_CLASS":"B4"
			},
			{
				"tx_id": "UNDEF-03 B2_15MHz_1025 Equipment Bundle Demo(RING)",
				"cell_id": "UNDEF-03 B2_15MHz_1025",
				"band": "B2",
				"centerChannel": "1025",
				"label": "F4",
				"bandWidth": "15MHz",
				"XC_VZ_BAND_CLASS":"B4"
			}
			]
		}
	]

};
var dummyTransmitterRecords = [{
	azimuth: "Test",
	antennaModel: "TestModel",
	electricalTilt: "TestElec",
	mechanicalDt: "TestMec",
	heightAndCenterline: "10",
	maxPower: "100",
	rxTxPorts: "9090",
	mountingFace: "NORTH",
	mountingPosition: "DOWN",
	radioModel: "TestModel",
	txRxLosses: "TestRx",
	txRxLossesComments: "RxComments",
	feederEquipment: "testEqup",
	feederLength: "19",
	regulatoryPowerFields: "field1",
	sectorId: "12"
},
{
	azimuth: "Test2",
	antennaModel: "TestModel2",
	electricalTilt: "TestElec",
	mechanicalDt: "TestMec",
	heightAndCenterline: "20",
	maxPower: "200",
	rxTxPorts: "9090",
	mountingFace: "SOUTH",
	mountingPosition: "DOWN",
	radioModel: "TestModel1",
	txRxLosses: "TestRx2",
	txRxLossesComments: "RxComments",
	feederEquipment: "testEqup",
	feederLength: "15",
	regulatoryPowerFields: "field1",
	sectorId: "12"
},
{
	azimuth: "Test3",
	antennaModel: "TestModel2",
	electricalTilt: "TestElec",
	mechanicalDt: "TestMec",
	heightAndCenterline: "10",
	maxPower: "700",
	rxTxPorts: "8090",
	mountingFace: "EAST",
	mountingPosition: "DOWN",
	radioModel: "TestModel",
	txRxLosses: "TestRx",
	txRxLossesComments: "RxComments",
	feederEquipment: "testEqup",
	feederLength: "59",
	regulatoryPowerFields: "field1",
	sectorId: "13"
},
{
	azimuth: "Test4",
	antennaModel: "TestModel4",
	electricalTilt: "TestElec",
	mechanicalDt: "TestMec",
	heightAndCenterline: "20",
	maxPower: "100",
	rxTxPorts: "7090",
	mountingFace: "NORTH",
	mountingPosition: "DOWN",
	radioModel: "TestMode1l",
	txRxLosses: "TestRx",
	txRxLossesComments: "RxComments2",
	feederEquipment: "testEqup",
	feederLength: "20",
	regulatoryPowerFields: "field1",
	sectorId: "22"
},
{
	azimuth: "Test5",
	antennaModel: "TestModel5",
	electricalTilt: "TestElec3",
	mechanicalDt: "TestMec",
	heightAndCenterline: "30",
	maxPower: "100",
	rxTxPorts: "7040",
	mountingFace: "NORTH",
	mountingPosition: "DOWN",
	radioModel: "TestModel",
	txRxLosses: "TestRx",
	txRxLossesComments: "RxComments4",
	feederEquipment: "testEqup3",
	feederLength: "50",
	regulatoryPowerFields: "field1",
	sectorId: "30"
}];
var dummycellInfoRecords = [
	{ carrierLabel: "Carrier 1", carrier: "carrier1" }, { carrierLabel: "Carrier 2", carrier: "carrier2" }, { carrierLabel: "Carrier 3", carrier: "carrier3" }, { carrierLabel: "Carrier 4", carrier: "carrier4" }, { carrierLabel: "Carrier 5", carrier: "carrier5" }];

var coverages = {

	"RLOPL": [
		"120 dB", "133 dB"
	]
	,
	"RSRP": [
		"-95 dBm", "-105 dBm", "-115 dBm"
	]
	,
	"RSSI": [
		"-96 dBm"
	]
	,
	"SINR or C/I": [
		"20 dB", "15 dB", "10 dB", "5 dB", "0 dB"
	]

};
var cardsData = [{
	"revisionID": 01,
	"name": "Revision 1",
	"createdBy": "Tushar",
	"createdOn": "03/23/2021 14:13",
	"status": "active"
}, {
	"revisionID": 02,
	"name": "Revision 2",
	"createdBy": "White",
	"createdOn": "03/22/2021 13:12",
	"status": "active"
}, {
	"revisionID": 03,
	"name": "Revision 3",
	"createdBy": "Tangsali",
	"createdOn": "03/21/2021 12:11",
	"status": "active"
}, {
	"revisionID": 04,
	"name": "Revision 4",
	"createdBy": "Tushar",
	"createdOn": "03/20/2021 11:10",
	"status": "active"
}, {
	"revisionID": 05,
	"name": "Revision 5",
	"createdBy": "Tushar",
	"createdOn": "03/23/2021 14:13",
	"status": "active"
}, {
	"revisionID": 06,
	"name": "Revision 6",
	"createdBy": "White",
	"createdOn": "03/22/2021 13:12",
	"status": "active"
}, {
	"revisionID": 07,
	"name": "Revision 7",
	"createdBy": "Tangsali",
	"createdOn": "03/21/2021 12:11",
	"status": "active"
}, {
	"revisionID": 08,
	"name": "Revision 8",
	"createdBy": "Tushar",
	"createdOn": "03/20/2021 11:10",
	"status": "active"
}, {
	"revisionID": 09,
	"name": "Revision 9",
	"createdBy": "Tushar",
	"createdOn": "03/23/2021 14:13",
	"status": "active"
}, {
	"revisionID": 10,
	"name": "Revision 10",
	"createdBy": "White",
	"createdOn": "03/22/2021 13:12",
	"status": "active"
}, {
	"revisionID": 11,
	"name": "Revision 11",
	"createdBy": "Tangsali",
	"createdOn": "03/21/2021 12:11",
	"status": "active"
}, {
	"revisionID": 12,
	"name": "Revision 12",
	"createdBy": "Tushar",
	"createdOn": "03/20/2021 11:10",
	"status": "active"
}, {
	"revisionID": 13,
	"name": "Revision 13",
	"createdBy": "Tushar",
	"createdOn": "03/23/2021 14:13",
	"status": "active"
}, {
	"revisionID": 14,
	"name": "Revision 14",
	"createdBy": "White",
	"createdOn": "03/22/2021 13:12",
	"status": "active"
}, {
	"revisionID": 15,
	"name": "Revision 15",
	"createdBy": "Tangsali",
	"createdOn": "03/21/2021 12:11",
	"status": "active"
}, {
	"revisionID": 16,
	"name": "Revision 16",
	"createdBy": "Tushar",
	"createdOn": "03/20/2021 11:10",
	"status": "active"
}];

function getGeoJson(name, flag) {
	if (name === "UNDEF-01 B4_20MHz_2050 Equipment Bundle Demo(RING)") {
		var res = {
			"request_obj": [
				{
					"json_agg": [
						{
							"id": 2709,
							"type": "Feature",
							"geometry": {
								"type": "MultiPolygon",
								"coordinates": [
									[
										[
											[
												-71.01685478,
												42.24204443
											],
											[
												-71.017026865,
												42.247444845
											],
											[
												-71.016300009,
												42.24745763
											],
											[
												-71.016386038,
												42.250157837
											],
											[
												-71.017112926,
												42.25014505
											],
											[
												-71.017130139,
												42.250685091
											],
											[
												-71.016403245,
												42.250697878
											],
											[
												-71.016420453,
												42.251237919
											],
											[
												-71.018601152,
												42.251199545
											],
											[
												-71.018618379,
												42.251739585
											],
											[
												-71.019345284,
												42.251726784
											],
											[
												-71.019362517,
												42.252266824
											],
											[
												-71.020816338,
												42.252241208
											],
											[
												-71.020833584,
												42.252781248
											],
											[
												-71.0215605,
												42.252768433
											],
											[
												-71.021577753,
												42.253308472
											],
											[
												-71.022304674,
												42.253295652
											],
											[
												-71.022321934,
												42.253835691
											],
											[
												-71.021595006,
												42.253848511
											],
											[
												-71.02161226,
												42.25438855
											],
											[
												-71.020158391,
												42.254414177
											],
											[
												-71.020175633,
												42.254954216
											],
											[
												-71.019448692,
												42.254967023
											],
											[
												-71.019500402,
												42.256587142
											],
											[
												-71.018773441,
												42.256599945
											],
											[
												-71.01875621,
												42.256059905
											],
											[
												-71.018029255,
												42.256072703
											],
											[
												-71.01804648,
												42.256612743
											],
											[
												-71.017319519,
												42.256625537
											],
											[
												-71.017336738,
												42.257165577
											],
											[
												-71.01660977,
												42.257178367
											],
											[
												-71.016626983,
												42.257718407
											],
											[
												-71.017353957,
												42.257705618
											],
											[
												-71.017371178,
												42.258245658
											],
											[
												-71.016644197,
												42.258258448
											],
											[
												-71.016730274,
												42.260958648
											],
											[
												-71.017457285,
												42.260945857
											],
											[
												-71.017629536,
												42.266346252
											],
											[
												-71.016902462,
												42.266359046
											],
											[
												-71.016868021,
												42.265278967
											],
											[
												-71.016140959,
												42.265291755
											],
											[
												-71.015986051,
												42.260431394
											],
											[
												-71.015259045,
												42.260444176
											],
											[
												-71.015138631,
												42.256663891
											],
											[
												-71.013684704,
												42.256689437
											],
											[
												-71.01373627,
												42.258309561
											],
											[
												-71.013009287,
												42.258322328
											],
											[
												-71.012974922,
												42.257242245
											],
											[
												-71.012247951,
												42.257255007
											],
											[
												-71.012265127,
												42.257795048
											],
											[
												-71.011538149,
												42.257807806
											],
											[
												-71.011503809,
												42.256727722
											],
											[
												-71.012230775,
												42.256714965
											],
											[
												-71.012213599,
												42.256174923
											],
											[
												-71.01148664,
												42.256187679
											],
											[
												-71.011469472,
												42.255647637
											],
											[
												-71.012196425,
												42.255634881
											],
											[
												-71.01217925,
												42.255094839
											],
											[
												-71.010725356,
												42.255120346
											],
											[
												-71.010742518,
												42.255660389
											],
											[
												-71.010015564,
												42.255673136
											],
											[
												-71.010032721,
												42.256213179
											],
											[
												-71.008578799,
												42.25623866
											],
											[
												-71.008561655,
												42.255698617
											],
											[
												-71.00928861,
												42.255685879
											],
											[
												-71.00927146,
												42.255145836
											],
											[
												-71.009998409,
												42.255133094
											],
											[
												-71.009981253,
												42.254593051
											],
											[
												-71.010708195,
												42.254580304
											],
											[
												-71.010673873,
												42.253500219
											],
											[
												-71.009220015,
												42.253525707
											],
											[
												-71.009202867,
												42.252985663
											],
											[
												-71.010656713,
												42.252960176
											],
											[
												-71.010622394,
												42.25188009
											],
											[
												-71.009895484,
												42.251892836
											],
											[
												-71.009878331,
												42.251352793
											],
											[
												-71.009151426,
												42.251365533
											],
											[
												-71.009134281,
												42.25082549
											],
											[
												-71.010588077,
												42.250800004
											],
											[
												-71.010605236,
												42.251340047
											],
											[
												-71.011332139,
												42.251327297
											],
											[
												-71.011349304,
												42.25186734
											],
											[
												-71.012076214,
												42.251854585
											],
											[
												-71.012041872,
												42.2507745
											],
											[
												-71.012768769,
												42.250761741
											],
											[
												-71.012751593,
												42.250221699
											],
											[
												-71.013478483,
												42.250208936
											],
											[
												-71.013461301,
												42.249668894
											],
											[
												-71.014188184,
												42.249656126
											],
											[
												-71.014205372,
												42.250196168
											],
											[
												-71.014932261,
												42.250183395
											],
											[
												-71.014949456,
												42.250723437
											],
											[
												-71.015676351,
												42.25071066
											],
											[
												-71.015487165,
												42.244770202
											],
											[
												-71.016213991,
												42.244757422
											],
											[
												-71.016127985,
												42.242057213
											],
											[
												-71.01685478,
												42.24204443
											]
										],
										[
											[
												-71.018029255,
												42.256072703
											],
											[
												-71.018012031,
												42.255532663
											],
											[
												-71.017285082,
												42.255545457
											],
											[
												-71.0173023,
												42.256085497
											],
											[
												-71.018029255,
												42.256072703
											]
										],
										[
											[
												-71.012076214,
												42.251854585
											],
											[
												-71.012093385,
												42.252394628
											],
											[
												-71.012820301,
												42.252381868
											],
											[
												-71.012803123,
												42.251841826
											],
											[
												-71.012076214,
												42.251854585
											]
										]
									],
									[
										[
											[
												-71.012734417,
												42.249681657
											],
											[
												-71.012751593,
												42.250221699
											],
											[
												-71.012024702,
												42.250234458
											],
											[
												-71.012007532,
												42.249694415
											],
											[
												-71.012734417,
												42.249681657
											]
										]
									],
									[
										[
											[
												-71.012024702,
												42.250234458
											],
											[
												-71.012041872,
												42.2507745
											],
											[
												-71.011314975,
												42.250787255
											],
											[
												-71.011297811,
												42.250247212
											],
											[
												-71.012024702,
												42.250234458
											]
										]
									],
									[
										[
											[
												-71.01148664,
												42.256187679
											],
											[
												-71.011503809,
												42.256727722
											],
											[
												-71.010776844,
												42.256740474
											],
											[
												-71.010759681,
												42.256200431
											],
											[
												-71.01148664,
												42.256187679
											]
										]
									]
								]
							},
							"properties": {
								"threshold": 138
							}
						},
						{
							"id": 2710,
							"type": "Feature",
							"geometry": {
								"type": "MultiPolygon",
								"coordinates": [
									[
										[
											[
												-71.0162656,
												42.246377547
											],
											[
												-71.016420453,
												42.251237919
											],
											[
												-71.018601152,
												42.251199545
											],
											[
												-71.018635606,
												42.252279625
											],
											[
												-71.019362517,
												42.252266824
											],
											[
												-71.019379751,
												42.252806864
											],
											[
												-71.020833584,
												42.252781248
											],
											[
												-71.020868078,
												42.253861327
											],
											[
												-71.020141149,
												42.253874137
											],
											[
												-71.020158391,
												42.254414177
											],
											[
												-71.01870452,
												42.254439786
											],
											[
												-71.01873898,
												42.255519865
											],
											[
												-71.016558132,
												42.255558245
											],
											[
												-71.016575344,
												42.256098286
											],
											[
												-71.015848388,
												42.25611107
											],
											[
												-71.015865594,
												42.256651111
											],
											[
												-71.016592557,
												42.256638326
											],
											[
												-71.016781925,
												42.262578768
											],
											[
												-71.016054895,
												42.262591555
											],
											[
												-71.015951633,
												42.259351314
											],
											[
												-71.015224639,
												42.259364095
											],
											[
												-71.015121431,
												42.25612385
											],
											[
												-71.014394474,
												42.256136625
											],
											[
												-71.014411668,
												42.256676666
											],
											[
												-71.012230775,
												42.256714965
											],
											[
												-71.012213599,
												42.256174923
											],
											[
												-71.012940558,
												42.256162161
											],
											[
												-71.012923377,
												42.25562212
											],
											[
												-71.012196425,
												42.255634881
											],
											[
												-71.01217925,
												42.255094839
											],
											[
												-71.012906196,
												42.255082078
											],
											[
												-71.012871837,
												42.254001994
											],
											[
												-71.012144903,
												42.254014754
											],
											[
												-71.012162076,
												42.254554797
											],
											[
												-71.011435136,
												42.254567553
											],
											[
												-71.011452303,
												42.255107595
											],
											[
												-71.010725356,
												42.255120346
											],
											[
												-71.010691034,
												42.254040261
											],
											[
												-71.011417969,
												42.25402751
											],
											[
												-71.01136647,
												42.252407383
											],
											[
												-71.010639553,
												42.252420133
											],
											[
												-71.010605236,
												42.251340047
											],
											[
												-71.011332139,
												42.251327297
											],
											[
												-71.011349304,
												42.25186734
											],
											[
												-71.012076214,
												42.251854585
											],
											[
												-71.012093385,
												42.252394628
											],
											[
												-71.012820301,
												42.252381868
											],
											[
												-71.012803123,
												42.251841826
											],
											[
												-71.013530032,
												42.251829062
											],
											[
												-71.013512848,
												42.25128902
											],
											[
												-71.012059043,
												42.251314543
											],
											[
												-71.012041872,
												42.2507745
											],
											[
												-71.015676351,
												42.25071066
											],
											[
												-71.015538755,
												42.246390327
											],
											[
												-71.0162656,
												42.246377547
											]
										]
									],
									[
										[
											[
												-71.010725356,
												42.255120346
											],
											[
												-71.010742518,
												42.255660389
											],
											[
												-71.010015564,
												42.255673136
											],
											[
												-71.009998409,
												42.255133094
											],
											[
												-71.010725356,
												42.255120346
											]
										]
									],
									[
										[
											[
												-71.012196425,
												42.255634881
											],
											[
												-71.012213599,
												42.256174923
											],
											[
												-71.01148664,
												42.256187679
											],
											[
												-71.011469472,
												42.255647637
											],
											[
												-71.012196425,
												42.255634881
											]
										]
									]
								]
							},
							"properties": {
								"threshold": 133
							}
						},
						{
							"id": 2711,
							"type": "Feature",
							"geometry": {
								"type": "MultiPolygon",
								"coordinates": [
									[
										[
											[
												-71.015693553,
												42.251250701
											],
											[
												-71.015710755,
												42.251790742
											],
											[
												-71.016437661,
												42.25177796
											],
											[
												-71.01645487,
												42.252318001
											],
											[
												-71.017181783,
												42.252305214
											],
											[
												-71.017198998,
												42.252845254
											],
											[
												-71.017925916,
												42.252832462
											],
											[
												-71.017977584,
												42.254452583
											],
											[
												-71.01652371,
												42.254478164
											],
											[
												-71.016540921,
												42.255018205
											],
											[
												-71.015813977,
												42.255030989
											],
											[
												-71.015865594,
												42.256651111
											],
											[
												-71.015138631,
												42.256663891
											],
											[
												-71.015069834,
												42.254503727
											],
											[
												-71.012889016,
												42.254542036
											],
											[
												-71.012871837,
												42.254001994
											],
											[
												-71.01359877,
												42.253989229
											],
											[
												-71.0135644,
												42.252909146
											],
											[
												-71.01429132,
												42.252896377
											],
											[
												-71.01427413,
												42.252356335
											],
											[
												-71.013547216,
												42.252369104
											],
											[
												-71.013530032,
												42.251829062
											],
											[
												-71.014983847,
												42.25180352
											],
											[
												-71.014966652,
												42.251263479
											],
											[
												-71.015693553,
												42.251250701
											]
										]
									],
									[
										[
											[
												-71.012837479,
												42.25292191
											],
											[
												-71.012871837,
												42.254001994
											],
											[
												-71.012144903,
												42.254014754
											],
											[
												-71.012110557,
												42.25293467
											],
											[
												-71.012837479,
												42.25292191
											]
										]
									]
								]
							},
							"properties": {
								"threshold": 120
							}
						}
					]
				}
			],
			"meta": {
				"status": "ok"
			}
		}
	}


	if (name === 'UNDEF-02 B4_20MHz_2050 Equipment Bundle Demo(RING)') {
		var res = {
			"request_obj": [
				{
					"json_agg": [
						{
							"id": 2715,
							"type": "Feature",
							"geometry": {
								"type": "MultiPolygon",
								"coordinates": [
									[
										[
											[
												-71.01685478,
												42.24204443
											],
											[
												-71.017026865,
												42.247444845
											],
											[
												-71.016300009,
												42.24745763
											],
											[
												-71.016386038,
												42.250157837
											],
											[
												-71.017112926,
												42.25014505
											],
											[
												-71.017130139,
												42.250685091
											],
											[
												-71.016403245,
												42.250697878
											],
											[
												-71.016420453,
												42.251237919
											],
											[
												-71.018601152,
												42.251199545
											],
											[
												-71.018618379,
												42.251739585
											],
											[
												-71.019345284,
												42.251726784
											],
											[
												-71.019362517,
												42.252266824
											],
											[
												-71.020816338,
												42.252241208
											],
											[
												-71.020833584,
												42.252781248
											],
											[
												-71.0215605,
												42.252768433
											],
											[
												-71.021577753,
												42.253308472
											],
											[
												-71.022304674,
												42.253295652
											],
											[
												-71.022321934,
												42.253835691
											],
											[
												-71.021595006,
												42.253848511
											],
											[
												-71.02161226,
												42.25438855
											],
											[
												-71.020158391,
												42.254414177
											],
											[
												-71.020175633,
												42.254954216
											],
											[
												-71.019448692,
												42.254967023
											],
											[
												-71.019500402,
												42.256587142
											],
											[
												-71.018773441,
												42.256599945
											],
											[
												-71.01875621,
												42.256059905
											],
											[
												-71.018029255,
												42.256072703
											],
											[
												-71.01804648,
												42.256612743
											],
											[
												-71.017319519,
												42.256625537
											],
											[
												-71.017336738,
												42.257165577
											],
											[
												-71.01660977,
												42.257178367
											],
											[
												-71.016626983,
												42.257718407
											],
											[
												-71.017353957,
												42.257705618
											],
											[
												-71.017371178,
												42.258245658
											],
											[
												-71.016644197,
												42.258258448
											],
											[
												-71.016730274,
												42.260958648
											],
											[
												-71.017457285,
												42.260945857
											],
											[
												-71.017629536,
												42.266346252
											],
											[
												-71.016902462,
												42.266359046
											],
											[
												-71.016868021,
												42.265278967
											],
											[
												-71.016140959,
												42.265291755
											],
											[
												-71.015986051,
												42.260431394
											],
											[
												-71.015259045,
												42.260444176
											],
											[
												-71.015138631,
												42.256663891
											],
											[
												-71.013684704,
												42.256689437
											],
											[
												-71.01373627,
												42.258309561
											],
											[
												-71.013009287,
												42.258322328
											],
											[
												-71.012974922,
												42.257242245
											],
											[
												-71.012247951,
												42.257255007
											],
											[
												-71.012265127,
												42.257795048
											],
											[
												-71.011538149,
												42.257807806
											],
											[
												-71.011503809,
												42.256727722
											],
											[
												-71.012230775,
												42.256714965
											],
											[
												-71.012213599,
												42.256174923
											],
											[
												-71.01148664,
												42.256187679
											],
											[
												-71.011469472,
												42.255647637
											],
											[
												-71.012196425,
												42.255634881
											],
											[
												-71.01217925,
												42.255094839
											],
											[
												-71.010725356,
												42.255120346
											],
											[
												-71.010742518,
												42.255660389
											],
											[
												-71.010015564,
												42.255673136
											],
											[
												-71.010032721,
												42.256213179
											],
											[
												-71.008578799,
												42.25623866
											],
											[
												-71.008561655,
												42.255698617
											],
											[
												-71.00928861,
												42.255685879
											],
											[
												-71.00927146,
												42.255145836
											],
											[
												-71.009998409,
												42.255133094
											],
											[
												-71.009981253,
												42.254593051
											],
											[
												-71.010708195,
												42.254580304
											],
											[
												-71.010673873,
												42.253500219
											],
											[
												-71.009220015,
												42.253525707
											],
											[
												-71.009202867,
												42.252985663
											],
											[
												-71.010656713,
												42.252960176
											],
											[
												-71.010622394,
												42.25188009
											],
											[
												-71.009895484,
												42.251892836
											],
											[
												-71.009878331,
												42.251352793
											],
											[
												-71.009151426,
												42.251365533
											],
											[
												-71.009134281,
												42.25082549
											],
											[
												-71.010588077,
												42.250800004
											],
											[
												-71.010605236,
												42.251340047
											],
											[
												-71.011332139,
												42.251327297
											],
											[
												-71.011349304,
												42.25186734
											],
											[
												-71.012076214,
												42.251854585
											],
											[
												-71.012041872,
												42.2507745
											],
											[
												-71.012768769,
												42.250761741
											],
											[
												-71.012751593,
												42.250221699
											],
											[
												-71.013478483,
												42.250208936
											],
											[
												-71.013461301,
												42.249668894
											],
											[
												-71.014188184,
												42.249656126
											],
											[
												-71.014205372,
												42.250196168
											],
											[
												-71.014932261,
												42.250183395
											],
											[
												-71.014949456,
												42.250723437
											],
											[
												-71.015676351,
												42.25071066
											],
											[
												-71.015487165,
												42.244770202
											],
											[
												-71.016213991,
												42.244757422
											],
											[
												-71.016127985,
												42.242057213
											],
											[
												-71.01685478,
												42.24204443
											]
										],
										[
											[
												-71.018029255,
												42.256072703
											],
											[
												-71.018012031,
												42.255532663
											],
											[
												-71.017285082,
												42.255545457
											],
											[
												-71.0173023,
												42.256085497
											],
											[
												-71.018029255,
												42.256072703
											]
										],
										[
											[
												-71.012076214,
												42.251854585
											],
											[
												-71.012093385,
												42.252394628
											],
											[
												-71.012820301,
												42.252381868
											],
											[
												-71.012803123,
												42.251841826
											],
											[
												-71.012076214,
												42.251854585
											]
										]
									],
									[
										[
											[
												-71.012734417,
												42.249681657
											],
											[
												-71.012751593,
												42.250221699
											],
											[
												-71.012024702,
												42.250234458
											],
											[
												-71.012007532,
												42.249694415
											],
											[
												-71.012734417,
												42.249681657
											]
										]
									],
									[
										[
											[
												-71.012024702,
												42.250234458
											],
											[
												-71.012041872,
												42.2507745
											],
											[
												-71.011314975,
												42.250787255
											],
											[
												-71.011297811,
												42.250247212
											],
											[
												-71.012024702,
												42.250234458
											]
										]
									],
									[
										[
											[
												-71.01148664,
												42.256187679
											],
											[
												-71.011503809,
												42.256727722
											],
											[
												-71.010776844,
												42.256740474
											],
											[
												-71.010759681,
												42.256200431
											],
											[
												-71.01148664,
												42.256187679
											]
										]
									]
								]
							},
							"properties": {
								"threshold": 138
							}
						},
						{
							"id": 2716,
							"type": "Feature",
							"geometry": {
								"type": "MultiPolygon",
								"coordinates": [
									[
										[
											[
												-71.0162656,
												42.246377547
											],
											[
												-71.016420453,
												42.251237919
											],
											[
												-71.018601152,
												42.251199545
											],
											[
												-71.018635606,
												42.252279625
											],
											[
												-71.019362517,
												42.252266824
											],
											[
												-71.019379751,
												42.252806864
											],
											[
												-71.020833584,
												42.252781248
											],
											[
												-71.020868078,
												42.253861327
											],
											[
												-71.020141149,
												42.253874137
											],
											[
												-71.020158391,
												42.254414177
											],
											[
												-71.01870452,
												42.254439786
											],
											[
												-71.01873898,
												42.255519865
											],
											[
												-71.016558132,
												42.255558245
											],
											[
												-71.016575344,
												42.256098286
											],
											[
												-71.015848388,
												42.25611107
											],
											[
												-71.015865594,
												42.256651111
											],
											[
												-71.016592557,
												42.256638326
											],
											[
												-71.016781925,
												42.262578768
											],
											[
												-71.016054895,
												42.262591555
											],
											[
												-71.015951633,
												42.259351314
											],
											[
												-71.015224639,
												42.259364095
											],
											[
												-71.015121431,
												42.25612385
											],
											[
												-71.014394474,
												42.256136625
											],
											[
												-71.014411668,
												42.256676666
											],
											[
												-71.012230775,
												42.256714965
											],
											[
												-71.012213599,
												42.256174923
											],
											[
												-71.012940558,
												42.256162161
											],
											[
												-71.012923377,
												42.25562212
											],
											[
												-71.012196425,
												42.255634881
											],
											[
												-71.01217925,
												42.255094839
											],
											[
												-71.012906196,
												42.255082078
											],
											[
												-71.012871837,
												42.254001994
											],
											[
												-71.012144903,
												42.254014754
											],
											[
												-71.012162076,
												42.254554797
											],
											[
												-71.011435136,
												42.254567553
											],
											[
												-71.011452303,
												42.255107595
											],
											[
												-71.010725356,
												42.255120346
											],
											[
												-71.010691034,
												42.254040261
											],
											[
												-71.011417969,
												42.25402751
											],
											[
												-71.01136647,
												42.252407383
											],
											[
												-71.010639553,
												42.252420133
											],
											[
												-71.010605236,
												42.251340047
											],
											[
												-71.011332139,
												42.251327297
											],
											[
												-71.011349304,
												42.25186734
											],
											[
												-71.012076214,
												42.251854585
											],
											[
												-71.012093385,
												42.252394628
											],
											[
												-71.012820301,
												42.252381868
											],
											[
												-71.012803123,
												42.251841826
											],
											[
												-71.013530032,
												42.251829062
											],
											[
												-71.013512848,
												42.25128902
											],
											[
												-71.012059043,
												42.251314543
											],
											[
												-71.012041872,
												42.2507745
											],
											[
												-71.015676351,
												42.25071066
											],
											[
												-71.015538755,
												42.246390327
											],
											[
												-71.0162656,
												42.246377547
											]
										]
									],
									[
										[
											[
												-71.010725356,
												42.255120346
											],
											[
												-71.010742518,
												42.255660389
											],
											[
												-71.010015564,
												42.255673136
											],
											[
												-71.009998409,
												42.255133094
											],
											[
												-71.010725356,
												42.255120346
											]
										]
									],
									[
										[
											[
												-71.012196425,
												42.255634881
											],
											[
												-71.012213599,
												42.256174923
											],
											[
												-71.01148664,
												42.256187679
											],
											[
												-71.011469472,
												42.255647637
											],
											[
												-71.012196425,
												42.255634881
											]
										]
									]
								]
							},
							"properties": {
								"threshold": 133
							}
						},
						{
							"id": 2717,
							"type": "Feature",
							"geometry": {
								"type": "MultiPolygon",
								"coordinates": [
									[
										[
											[
												-71.015693553,
												42.251250701
											],
											[
												-71.015710755,
												42.251790742
											],
											[
												-71.016437661,
												42.25177796
											],
											[
												-71.01645487,
												42.252318001
											],
											[
												-71.017181783,
												42.252305214
											],
											[
												-71.017198998,
												42.252845254
											],
											[
												-71.017925916,
												42.252832462
											],
											[
												-71.017977584,
												42.254452583
											],
											[
												-71.01652371,
												42.254478164
											],
											[
												-71.016540921,
												42.255018205
											],
											[
												-71.015813977,
												42.255030989
											],
											[
												-71.015865594,
												42.256651111
											],
											[
												-71.015138631,
												42.256663891
											],
											[
												-71.015069834,
												42.254503727
											],
											[
												-71.012889016,
												42.254542036
											],
											[
												-71.012871837,
												42.254001994
											],
											[
												-71.01359877,
												42.253989229
											],
											[
												-71.0135644,
												42.252909146
											],
											[
												-71.01429132,
												42.252896377
											],
											[
												-71.01427413,
												42.252356335
											],
											[
												-71.013547216,
												42.252369104
											],
											[
												-71.013530032,
												42.251829062
											],
											[
												-71.014983847,
												42.25180352
											],
											[
												-71.014966652,
												42.251263479
											],
											[
												-71.015693553,
												42.251250701
											]
										]
									],
									[
										[
											[
												-71.012837479,
												42.25292191
											],
											[
												-71.012871837,
												42.254001994
											],
											[
												-71.012144903,
												42.254014754
											],
											[
												-71.012110557,
												42.25293467
											],
											[
												-71.012837479,
												42.25292191
											]
										]
									]
								]
							},
							"properties": {
								"threshold": 120
							}
						}
					]
				}
			],
			"meta": {
				"status": "ok"
			}
		}


	}
	if (name === "UNDEF-03 B4_20MHz_2050 Equipment Bundle Demo(RING)") {
		var res = {
			"request_obj": [
				{
					"json_agg": [
						{
							"id": 2722,
							"type": "Feature",
							"geometry": {
								"type": "MultiPolygon",
								"coordinates": [
									[
										[
											[
												-71.0162656,
												42.246377547
											],
											[
												-71.016420453,
												42.251237919
											],
											[
												-71.018601152,
												42.251199545
											],
											[
												-71.018635606,
												42.252279625
											],
											[
												-71.019362517,
												42.252266824
											],
											[
												-71.019379751,
												42.252806864
											],
											[
												-71.020833584,
												42.252781248
											],
											[
												-71.020868078,
												42.253861327
											],
											[
												-71.020141149,
												42.253874137
											],
											[
												-71.020158391,
												42.254414177
											],
											[
												-71.01870452,
												42.254439786
											],
											[
												-71.01873898,
												42.255519865
											],
											[
												-71.016558132,
												42.255558245
											],
											[
												-71.016575344,
												42.256098286
											],
											[
												-71.015848388,
												42.25611107
											],
											[
												-71.015865594,
												42.256651111
											],
											[
												-71.016592557,
												42.256638326
											],
											[
												-71.016781925,
												42.262578768
											],
											[
												-71.016054895,
												42.262591555
											],
											[
												-71.015951633,
												42.259351314
											],
											[
												-71.015224639,
												42.259364095
											],
											[
												-71.015121431,
												42.25612385
											],
											[
												-71.014394474,
												42.256136625
											],
											[
												-71.014411668,
												42.256676666
											],
											[
												-71.012230775,
												42.256714965
											],
											[
												-71.012213599,
												42.256174923
											],
											[
												-71.012940558,
												42.256162161
											],
											[
												-71.012923377,
												42.25562212
											],
											[
												-71.012196425,
												42.255634881
											],
											[
												-71.01217925,
												42.255094839
											],
											[
												-71.012906196,
												42.255082078
											],
											[
												-71.012871837,
												42.254001994
											],
											[
												-71.012144903,
												42.254014754
											],
											[
												-71.012162076,
												42.254554797
											],
											[
												-71.011435136,
												42.254567553
											],
											[
												-71.011452303,
												42.255107595
											],
											[
												-71.010725356,
												42.255120346
											],
											[
												-71.010691034,
												42.254040261
											],
											[
												-71.011417969,
												42.25402751
											],
											[
												-71.01136647,
												42.252407383
											],
											[
												-71.010639553,
												42.252420133
											],
											[
												-71.010605236,
												42.251340047
											],
											[
												-71.011332139,
												42.251327297
											],
											[
												-71.011349304,
												42.25186734
											],
											[
												-71.012076214,
												42.251854585
											],
											[
												-71.012093385,
												42.252394628
											],
											[
												-71.012820301,
												42.252381868
											],
											[
												-71.012803123,
												42.251841826
											],
											[
												-71.013530032,
												42.251829062
											],
											[
												-71.013512848,
												42.25128902
											],
											[
												-71.012059043,
												42.251314543
											],
											[
												-71.012041872,
												42.2507745
											],
											[
												-71.015676351,
												42.25071066
											],
											[
												-71.015538755,
												42.246390327
											],
											[
												-71.0162656,
												42.246377547
											]
										]
									],
									[
										[
											[
												-71.010725356,
												42.255120346
											],
											[
												-71.010742518,
												42.255660389
											],
											[
												-71.010015564,
												42.255673136
											],
											[
												-71.009998409,
												42.255133094
											],
											[
												-71.010725356,
												42.255120346
											]
										]
									],
									[
										[
											[
												-71.012196425,
												42.255634881
											],
											[
												-71.012213599,
												42.256174923
											],
											[
												-71.01148664,
												42.256187679
											],
											[
												-71.011469472,
												42.255647637
											],
											[
												-71.012196425,
												42.255634881
											]
										]
									]
								]
							},
							"properties": {
								"threshold": 133
							}
						},
						{
							"id": 2723,
							"type": "Feature",
							"geometry": {
								"type": "MultiPolygon",
								"coordinates": [
									[
										[
											[
												-71.015693553,
												42.251250701
											],
											[
												-71.015710755,
												42.251790742
											],
											[
												-71.016437661,
												42.25177796
											],
											[
												-71.01645487,
												42.252318001
											],
											[
												-71.017181783,
												42.252305214
											],
											[
												-71.017198998,
												42.252845254
											],
											[
												-71.017925916,
												42.252832462
											],
											[
												-71.017977584,
												42.254452583
											],
											[
												-71.01652371,
												42.254478164
											],
											[
												-71.016540921,
												42.255018205
											],
											[
												-71.015813977,
												42.255030989
											],
											[
												-71.015865594,
												42.256651111
											],
											[
												-71.015138631,
												42.256663891
											],
											[
												-71.015069834,
												42.254503727
											],
											[
												-71.012889016,
												42.254542036
											],
											[
												-71.012871837,
												42.254001994
											],
											[
												-71.01359877,
												42.253989229
											],
											[
												-71.0135644,
												42.252909146
											],
											[
												-71.01429132,
												42.252896377
											],
											[
												-71.01427413,
												42.252356335
											],
											[
												-71.013547216,
												42.252369104
											],
											[
												-71.013530032,
												42.251829062
											],
											[
												-71.014983847,
												42.25180352
											],
											[
												-71.014966652,
												42.251263479
											],
											[
												-71.015693553,
												42.251250701
											]
										]
									],
									[
										[
											[
												-71.012837479,
												42.25292191
											],
											[
												-71.012871837,
												42.254001994
											],
											[
												-71.012144903,
												42.254014754
											],
											[
												-71.012110557,
												42.25293467
											],
											[
												-71.012837479,
												42.25292191
											]
										]
									]
								]
							},
							"properties": {
								"threshold": 120
							}
						},
						{
							"id": 2721,
							"type": "Feature",
							"geometry": {
								"type": "MultiPolygon",
								"coordinates": [
									[
										[
											[
												-71.01685478,
												42.24204443
											],
											[
												-71.017026865,
												42.247444845
											],
											[
												-71.016300009,
												42.24745763
											],
											[
												-71.016386038,
												42.250157837
											],
											[
												-71.017112926,
												42.25014505
											],
											[
												-71.017130139,
												42.250685091
											],
											[
												-71.016403245,
												42.250697878
											],
											[
												-71.016420453,
												42.251237919
											],
											[
												-71.018601152,
												42.251199545
											],
											[
												-71.018618379,
												42.251739585
											],
											[
												-71.019345284,
												42.251726784
											],
											[
												-71.019362517,
												42.252266824
											],
											[
												-71.020816338,
												42.252241208
											],
											[
												-71.020833584,
												42.252781248
											],
											[
												-71.0215605,
												42.252768433
											],
											[
												-71.021577753,
												42.253308472
											],
											[
												-71.022304674,
												42.253295652
											],
											[
												-71.022321934,
												42.253835691
											],
											[
												-71.021595006,
												42.253848511
											],
											[
												-71.02161226,
												42.25438855
											],
											[
												-71.020158391,
												42.254414177
											],
											[
												-71.020175633,
												42.254954216
											],
											[
												-71.019448692,
												42.254967023
											],
											[
												-71.019500402,
												42.256587142
											],
											[
												-71.018773441,
												42.256599945
											],
											[
												-71.01875621,
												42.256059905
											],
											[
												-71.018029255,
												42.256072703
											],
											[
												-71.01804648,
												42.256612743
											],
											[
												-71.017319519,
												42.256625537
											],
											[
												-71.017336738,
												42.257165577
											],
											[
												-71.01660977,
												42.257178367
											],
											[
												-71.016626983,
												42.257718407
											],
											[
												-71.017353957,
												42.257705618
											],
											[
												-71.017371178,
												42.258245658
											],
											[
												-71.016644197,
												42.258258448
											],
											[
												-71.016730274,
												42.260958648
											],
											[
												-71.017457285,
												42.260945857
											],
											[
												-71.017629536,
												42.266346252
											],
											[
												-71.016902462,
												42.266359046
											],
											[
												-71.016868021,
												42.265278967
											],
											[
												-71.016140959,
												42.265291755
											],
											[
												-71.015986051,
												42.260431394
											],
											[
												-71.015259045,
												42.260444176
											],
											[
												-71.015138631,
												42.256663891
											],
											[
												-71.013684704,
												42.256689437
											],
											[
												-71.01373627,
												42.258309561
											],
											[
												-71.013009287,
												42.258322328
											],
											[
												-71.012974922,
												42.257242245
											],
											[
												-71.012247951,
												42.257255007
											],
											[
												-71.012265127,
												42.257795048
											],
											[
												-71.011538149,
												42.257807806
											],
											[
												-71.011503809,
												42.256727722
											],
											[
												-71.012230775,
												42.256714965
											],
											[
												-71.012213599,
												42.256174923
											],
											[
												-71.01148664,
												42.256187679
											],
											[
												-71.011469472,
												42.255647637
											],
											[
												-71.012196425,
												42.255634881
											],
											[
												-71.01217925,
												42.255094839
											],
											[
												-71.010725356,
												42.255120346
											],
											[
												-71.010742518,
												42.255660389
											],
											[
												-71.010015564,
												42.255673136
											],
											[
												-71.010032721,
												42.256213179
											],
											[
												-71.008578799,
												42.25623866
											],
											[
												-71.008561655,
												42.255698617
											],
											[
												-71.00928861,
												42.255685879
											],
											[
												-71.00927146,
												42.255145836
											],
											[
												-71.009998409,
												42.255133094
											],
											[
												-71.009981253,
												42.254593051
											],
											[
												-71.010708195,
												42.254580304
											],
											[
												-71.010673873,
												42.253500219
											],
											[
												-71.009220015,
												42.253525707
											],
											[
												-71.009202867,
												42.252985663
											],
											[
												-71.010656713,
												42.252960176
											],
											[
												-71.010622394,
												42.25188009
											],
											[
												-71.009895484,
												42.251892836
											],
											[
												-71.009878331,
												42.251352793
											],
											[
												-71.009151426,
												42.251365533
											],
											[
												-71.009134281,
												42.25082549
											],
											[
												-71.010588077,
												42.250800004
											],
											[
												-71.010605236,
												42.251340047
											],
											[
												-71.011332139,
												42.251327297
											],
											[
												-71.011349304,
												42.25186734
											],
											[
												-71.012076214,
												42.251854585
											],
											[
												-71.012041872,
												42.2507745
											],
											[
												-71.012768769,
												42.250761741
											],
											[
												-71.012751593,
												42.250221699
											],
											[
												-71.013478483,
												42.250208936
											],
											[
												-71.013461301,
												42.249668894
											],
											[
												-71.014188184,
												42.249656126
											],
											[
												-71.014205372,
												42.250196168
											],
											[
												-71.014932261,
												42.250183395
											],
											[
												-71.014949456,
												42.250723437
											],
											[
												-71.015676351,
												42.25071066
											],
											[
												-71.015487165,
												42.244770202
											],
											[
												-71.016213991,
												42.244757422
											],
											[
												-71.016127985,
												42.242057213
											],
											[
												-71.01685478,
												42.24204443
											]
										],
										[
											[
												-71.018029255,
												42.256072703
											],
											[
												-71.018012031,
												42.255532663
											],
											[
												-71.017285082,
												42.255545457
											],
											[
												-71.0173023,
												42.256085497
											],
											[
												-71.018029255,
												42.256072703
											]
										],
										[
											[
												-71.012076214,
												42.251854585
											],
											[
												-71.012093385,
												42.252394628
											],
											[
												-71.012820301,
												42.252381868
											],
											[
												-71.012803123,
												42.251841826
											],
											[
												-71.012076214,
												42.251854585
											]
										]
									],
									[
										[
											[
												-71.012734417,
												42.249681657
											],
											[
												-71.012751593,
												42.250221699
											],
											[
												-71.012024702,
												42.250234458
											],
											[
												-71.012007532,
												42.249694415
											],
											[
												-71.012734417,
												42.249681657
											]
										]
									],
									[
										[
											[
												-71.012024702,
												42.250234458
											],
											[
												-71.012041872,
												42.2507745
											],
											[
												-71.011314975,
												42.250787255
											],
											[
												-71.011297811,
												42.250247212
											],
											[
												-71.012024702,
												42.250234458
											]
										]
									],
									[
										[
											[
												-71.01148664,
												42.256187679
											],
											[
												-71.011503809,
												42.256727722
											],
											[
												-71.010776844,
												42.256740474
											],
											[
												-71.010759681,
												42.256200431
											],
											[
												-71.01148664,
												42.256187679
											]
										]
									]
								]
							},
							"properties": {
								"threshold": 138
							}
						}
					]
				}
			],
			"meta": {
				"status": "ok"
			}
		}
	}

	if (name === "UNDEF-01 B2_15MHz_1025 Equipment Bundle Demo(RING)") {
		var res = {
			"request_obj": [
				{
					"json_agg": [
						{
							"id": 2707,
							"type": "Feature",
							"geometry": {
								"type": "MultiPolygon",
								"coordinates": [
									[
										[
											[
												-71.01685478,
												42.24204443
											],
											[
												-71.017026865,
												42.247444845
											],
											[
												-71.016300009,
												42.24745763
											],
											[
												-71.016351625,
												42.249077754
											],
											[
												-71.0170785,
												42.249064969
											],
											[
												-71.017095713,
												42.249605009
											],
											[
												-71.016368831,
												42.249617796
											],
											[
												-71.016386038,
												42.250157837
											],
											[
												-71.017112926,
												42.25014505
											],
											[
												-71.017130139,
												42.250685091
											],
											[
												-71.016403245,
												42.250697878
											],
											[
												-71.016420453,
												42.251237919
											],
											[
												-71.017147353,
												42.251225132
											],
											[
												-71.017164568,
												42.251765173
											],
											[
												-71.017891473,
												42.251752381
											],
											[
												-71.017874253,
												42.251212341
											],
											[
												-71.018601152,
												42.251199545
											],
											[
												-71.018583926,
												42.250659504
											],
											[
												-71.019310818,
												42.250646704
											],
											[
												-71.019345284,
												42.251726784
											],
											[
												-71.018618379,
												42.251739585
											],
											[
												-71.018652834,
												42.252819665
											],
											[
												-71.019379751,
												42.252806864
											],
											[
												-71.01941422,
												42.253886944
											],
											[
												-71.018687291,
												42.253899746
											],
											[
												-71.01872175,
												42.254979826
											],
											[
												-71.019448692,
												42.254967023
											],
											[
												-71.019483165,
												42.256047103
											],
											[
												-71.01875621,
												42.256059905
											],
											[
												-71.01873898,
												42.255519865
											],
											[
												-71.018012031,
												42.255532663
											],
											[
												-71.017994807,
												42.254992623
											],
											[
												-71.017267864,
												42.255005416
											],
											[
												-71.017319519,
												42.256625537
											],
											[
												-71.016592557,
												42.256638326
											],
											[
												-71.016626983,
												42.257718407
											],
											[
												-71.017353957,
												42.257705618
											],
											[
												-71.017371178,
												42.258245658
											],
											[
												-71.016644197,
												42.258258448
											],
											[
												-71.016730274,
												42.260958648
											],
											[
												-71.017457285,
												42.260945857
											],
											[
												-71.017646763,
												42.266886291
											],
											[
												-71.016919684,
												42.266899085
											],
											[
												-71.016885241,
												42.265819006
											],
											[
												-71.016158173,
												42.265831795
											],
											[
												-71.016020472,
												42.261511475
											],
											[
												-71.015293453,
												42.261524257
											],
											[
												-71.015121431,
												42.25612385
											],
											[
												-71.012940558,
												42.256162161
											],
											[
												-71.01295774,
												42.256702203
											],
											[
												-71.014411668,
												42.256676666
											],
											[
												-71.014446057,
												42.257756748
											],
											[
												-71.012992104,
												42.257782286
											],
											[
												-71.012974922,
												42.257242245
											],
											[
												-71.011520979,
												42.257267764
											],
											[
												-71.01155532,
												42.258347848
											],
											[
												-71.010828335,
												42.258360601
											],
											[
												-71.0108455,
												42.258900643
											],
											[
												-71.010118509,
												42.258913392
											],
											[
												-71.010084192,
												42.257833307
											],
											[
												-71.010811171,
												42.257820559
											],
											[
												-71.010776844,
												42.256740474
											],
											[
												-71.011503809,
												42.256727722
											],
											[
												-71.011435136,
												42.254567553
											],
											[
												-71.012162076,
												42.254554797
											],
											[
												-71.01212773,
												42.253474712
											],
											[
												-71.010673873,
												42.253500219
											],
											[
												-71.010656713,
												42.252960176
											],
											[
												-71.012110557,
												42.25293467
											],
											[
												-71.012024702,
												42.250234458
											],
											[
												-71.011297811,
												42.250247212
											],
											[
												-71.011280648,
												42.249707169
											],
											[
												-71.010553762,
												42.249719918
											],
											[
												-71.010519449,
												42.248639832
											],
											[
												-71.011246322,
												42.248627083
											],
											[
												-71.011263485,
												42.249167126
											],
											[
												-71.011990363,
												42.249154372
											],
											[
												-71.012007532,
												42.249694415
											],
											[
												-71.012734417,
												42.249681657
											],
											[
												-71.012751593,
												42.250221699
											],
											[
												-71.014932261,
												42.250183395
											],
											[
												-71.014915067,
												42.249643354
											],
											[
												-71.015641949,
												42.249630577
											],
											[
												-71.015469969,
												42.24423016
											],
											[
												-71.016196789,
												42.244217381
											],
											[
												-71.016127985,
												42.242057213
											],
											[
												-71.01685478,
												42.24204443
											]
										]
									],
									[
										[
											[
												-71.020210119,
												42.256034295
											],
											[
												-71.020227362,
												42.256574335
											],
											[
												-71.019500402,
												42.256587142
											],
											[
												-71.019483165,
												42.256047103
											],
											[
												-71.020210119,
												42.256034295
											]
										]
									]
								]
							},
							"properties": {
								"threshold": 133
							}
						},
						{
							"id": 2708,
							"type": "Feature",
							"geometry": {
								"type": "MultiPolygon",
								"coordinates": [
									[
										[
											[
												-71.016334419,
												42.248537713
											],
											[
												-71.016386038,
												42.250157837
											],
											[
												-71.01565915,
												42.250170618
											],
											[
												-71.015607549,
												42.248550494
											],
											[
												-71.016334419,
												42.248537713
											]
										]
									],
									[
										[
											[
												-71.016420453,
												42.251237919
											],
											[
												-71.016472079,
												42.252858042
											],
											[
												-71.017198998,
												42.252845254
											],
											[
												-71.01723343,
												42.253925335
											],
											[
												-71.017960361,
												42.253912543
											],
											[
												-71.017994807,
												42.254992623
											],
											[
												-71.017267864,
												42.255005416
											],
											[
												-71.017250647,
												42.254465376
											],
											[
												-71.01652371,
												42.254478164
											],
											[
												-71.016540921,
												42.255018205
											],
											[
												-71.015813977,
												42.255030989
											],
											[
												-71.015831182,
												42.255571029
											],
											[
												-71.016558132,
												42.255558245
											],
											[
												-71.016575344,
												42.256098286
											],
											[
												-71.015848388,
												42.25611107
											],
											[
												-71.015900008,
												42.257731192
											],
											[
												-71.015173033,
												42.257743973
											],
											[
												-71.015087032,
												42.255043768
											],
											[
												-71.013633142,
												42.255069312
											],
											[
												-71.013650329,
												42.255609354
											],
											[
												-71.012923377,
												42.25562212
											],
											[
												-71.012820301,
												42.252381868
											],
											[
												-71.013547216,
												42.252369104
											],
											[
												-71.013530032,
												42.251829062
											],
											[
												-71.01425694,
												42.251816293
											],
											[
												-71.01423975,
												42.251276252
											],
											[
												-71.016420453,
												42.251237919
											]
										],
										[
											[
												-71.01425694,
												42.251816293
											],
											[
												-71.01427413,
												42.252356335
											],
											[
												-71.015001044,
												42.252343562
											],
											[
												-71.014983847,
												42.25180352
											],
											[
												-71.01425694,
												42.251816293
											]
										]
									],
									[
										[
											[
												-71.013512848,
												42.25128902
											],
											[
												-71.013530032,
												42.251829062
											],
											[
												-71.012803123,
												42.251841826
											],
											[
												-71.012785946,
												42.251301784
											],
											[
												-71.013512848,
												42.25128902
											]
										]
									],
									[
										[
											[
												-71.017908694,
												42.252292422
											],
											[
												-71.017925916,
												42.252832462
											],
											[
												-71.017198998,
												42.252845254
											],
											[
												-71.017181783,
												42.252305214
											],
											[
												-71.017908694,
												42.252292422
											]
										]
									],
									[
										[
											[
												-71.012923377,
												42.25562212
											],
											[
												-71.012940558,
												42.256162161
											],
											[
												-71.012213599,
												42.256174923
											],
											[
												-71.012196425,
												42.255634881
											],
											[
												-71.012923377,
												42.25562212
											]
										]
									],
									[
										[
											[
												-71.016626983,
												42.257718407
											],
											[
												-71.016661411,
												42.258798488
											],
											[
												-71.015934424,
												42.258811273
											],
											[
												-71.015900008,
												42.257731192
											],
											[
												-71.016626983,
												42.257718407
											]
										]
									]
								]
							},
							"properties": {
								"threshold": 120
							}
						},
						{
							"id": 2706,
							"type": "Feature",
							"geometry": {
								"type": "MultiPolygon",
								"coordinates": [
									[
										[
											[
												-71.0174611,
												42.238251351
											],
											[
												-71.017667642,
												42.24473185
											],
											[
												-71.016940817,
												42.244744639
											],
											[
												-71.017044077,
												42.247984886
											],
											[
												-71.016317214,
												42.247997672
											],
											[
												-71.016334419,
												42.248537713
											],
											[
												-71.017061288,
												42.248524927
											],
											[
												-71.0170785,
												42.249064969
											],
											[
												-71.017805375,
												42.249052178
											],
											[
												-71.017822594,
												42.249592219
											],
											[
												-71.017095713,
												42.249605009
											],
											[
												-71.017112926,
												42.25014505
											],
											[
												-71.017839813,
												42.25013226
											],
											[
												-71.017857033,
												42.2506723
											],
											[
												-71.017130139,
												42.250685091
											],
											[
												-71.017164568,
												42.251765173
											],
											[
												-71.017891473,
												42.251752381
											],
											[
												-71.017874253,
												42.251212341
											],
											[
												-71.018601152,
												42.251199545
											],
											[
												-71.018583926,
												42.250659504
											],
											[
												-71.019310818,
												42.250646704
											],
											[
												-71.019293586,
												42.250106664
											],
											[
												-71.020020472,
												42.250093859
											],
											[
												-71.020054949,
												42.251173939
											],
											[
												-71.019328051,
												42.251186744
											],
											[
												-71.019345284,
												42.251726784
											],
											[
												-71.018618379,
												42.251739585
											],
											[
												-71.018635606,
												42.252279625
											],
											[
												-71.019362517,
												42.252266824
											],
											[
												-71.019379751,
												42.252806864
											],
											[
												-71.020106668,
												42.252794058
											],
											[
												-71.020141149,
												42.253874137
											],
											[
												-71.01941422,
												42.253886944
											],
											[
												-71.019431456,
												42.254426984
											],
											[
												-71.01870452,
												42.254439786
											],
											[
												-71.01872175,
												42.254979826
											],
											[
												-71.019448692,
												42.254967023
											],
											[
												-71.019465928,
												42.255507063
											],
											[
												-71.020192876,
												42.255494256
											],
											[
												-71.020210119,
												42.256034295
											],
											[
												-71.020937072,
												42.256021483
											],
											[
												-71.020971572,
												42.257101561
											],
											[
												-71.020244606,
												42.257114374
											],
											[
												-71.020227362,
												42.256574335
											],
											[
												-71.019500402,
												42.256587142
											],
											[
												-71.019483165,
												42.256047103
											],
											[
												-71.01875621,
												42.256059905
											],
											[
												-71.01873898,
												42.255519865
											],
											[
												-71.018012031,
												42.255532663
											],
											[
												-71.018063706,
												42.257152783
											],
											[
												-71.017336738,
												42.257165577
											],
											[
												-71.017353957,
												42.257705618
											],
											[
												-71.018080931,
												42.257692823
											],
											[
												-71.018098158,
												42.258232863
											],
											[
												-71.017371178,
												42.258245658
											],
											[
												-71.017388398,
												42.258785698
											],
											[
												-71.016661411,
												42.258798488
											],
											[
												-71.016695842,
												42.259878568
											],
											[
												-71.017422841,
												42.259865778
											],
											[
												-71.017577856,
												42.264726134
											],
											[
												-71.01830491,
												42.264713337
											],
											[
												-71.018528969,
												42.271733841
											],
											[
												-71.017074698,
												42.271759437
											],
											[
												-71.017005798,
												42.269599281
											],
											[
												-71.016278687,
												42.269612072
											],
											[
												-71.016106532,
												42.264211675
											],
											[
												-71.015379482,
												42.264224459
											],
											[
												-71.015207436,
												42.258824054
											],
											[
												-71.014480448,
												42.258836831
											],
											[
												-71.014463252,
												42.25829679
											],
											[
												-71.01373627,
												42.258309561
											],
											[
												-71.013719081,
												42.25776952
											],
											[
												-71.012265127,
												42.257795048
											],
											[
												-71.012282304,
												42.25833509
											],
											[
												-71.013009287,
												42.258322328
											],
											[
												-71.013043654,
												42.259402411
											],
											[
												-71.012316658,
												42.259415173
											],
											[
												-71.012299481,
												42.258875132
											],
											[
												-71.011572491,
												42.25888789
											],
											[
												-71.01155532,
												42.258347848
											],
											[
												-71.010828335,
												42.258360601
											],
											[
												-71.010862665,
												42.259440685
											],
											[
												-71.010135668,
												42.259453434
											],
											[
												-71.010152828,
												42.259993476
											],
											[
												-71.009425824,
												42.260006221
											],
											[
												-71.009442978,
												42.260546263
											],
											[
												-71.008715967,
												42.260559004
											],
											[
												-71.008733115,
												42.261099046
											],
											[
												-71.008006098,
												42.261111782
											],
											[
												-71.007971815,
												42.260031696
											],
											[
												-71.008698819,
												42.260018961
											],
											[
												-71.008664526,
												42.258938875
											],
											[
												-71.009391518,
												42.258926136
											],
											[
												-71.009357213,
												42.25784605
											],
											[
												-71.010084192,
												42.257833307
											],
											[
												-71.010067035,
												42.257293264
											],
											[
												-71.010794007,
												42.257280516
											],
											[
												-71.010725356,
												42.255120346
											],
											[
												-71.011452303,
												42.255107595
											],
											[
												-71.011435136,
												42.254567553
											],
											[
												-71.009981253,
												42.254593051
											],
											[
												-71.009964098,
												42.254053008
											],
											[
												-71.009237163,
												42.25406575
											],
											[
												-71.00918572,
												42.25244562
											],
											[
												-71.01136647,
												42.252407383
											],
											[
												-71.011280648,
												42.249707169
											],
											[
												-71.010553762,
												42.249719918
											],
											[
												-71.010536606,
												42.249179875
											],
											[
												-71.009809726,
												42.249192619
											],
											[
												-71.009775426,
												42.248112532
											],
											[
												-71.009048559,
												42.248125272
											],
											[
												-71.009014273,
												42.247045184
											],
											[
												-71.009741128,
												42.247032445
											],
											[
												-71.009758277,
												42.247572489
											],
											[
												-71.010485138,
												42.247559745
											],
											[
												-71.010502293,
												42.248099788
											],
											[
												-71.01122916,
												42.24808704
											],
											[
												-71.011263485,
												42.249167126
											],
											[
												-71.012717241,
												42.249141614
											],
											[
												-71.012700066,
												42.248601572
											],
											[
												-71.013426938,
												42.248588809
											],
											[
												-71.013409757,
												42.248048767
											],
											[
												-71.014136622,
												42.248036
											],
											[
												-71.014170996,
												42.249116084
											],
											[
												-71.013444119,
												42.249128851
											],
											[
												-71.013478483,
												42.250208936
											],
											[
												-71.014932261,
												42.250183395
											],
											[
												-71.014897873,
												42.249103312
											],
											[
												-71.015624749,
												42.249090535
											],
											[
												-71.015469969,
												42.24423016
											],
											[
												-71.016196789,
												42.244217381
											],
											[
												-71.016179587,
												42.243677339
											],
											[
												-71.015452774,
												42.243690118
											],
											[
												-71.01540119,
												42.242069991
											],
											[
												-71.016127985,
												42.242057213
											],
											[
												-71.016024794,
												42.23881696
											],
											[
												-71.016751552,
												42.238804179
											],
											[
												-71.016734349,
												42.238264137
											],
											[
												-71.0174611,
												42.238251351
											]
										],
										[
											[
												-71.014411668,
												42.256676666
											],
											[
												-71.014446057,
												42.257756748
											],
											[
												-71.015173033,
												42.257743973
											],
											[
												-71.015138631,
												42.256663891
											],
											[
												-71.014411668,
												42.256676666
											]
										]
									],
									[
										[
											[
												-71.008997131,
												42.24650514
											],
											[
												-71.009014273,
												42.247045184
											],
											[
												-71.008287417,
												42.247057918
											],
											[
												-71.008270281,
												42.246517874
											],
											[
												-71.008997131,
												42.24650514
											]
										]
									]
								]
							},
							"properties": {
								"threshold": 138
							}
						}
					]
				}
			],
			"meta": {
				"status": "ok"
			}
		}
	}
	if (name === "UNDEF-02 B2_15MHz_1025 Equipment Bundle Demo(RING)") {
		var res = {
			"request_obj": [
				{
					"json_agg": [
						{
							"id": 2713,
							"type": "Feature",
							"geometry": {
								"type": "MultiPolygon",
								"coordinates": [
									[
										[
											[
												-71.01685478,
												42.24204443
											],
											[
												-71.017026865,
												42.247444845
											],
											[
												-71.016300009,
												42.24745763
											],
											[
												-71.016351625,
												42.249077754
											],
											[
												-71.0170785,
												42.249064969
											],
											[
												-71.017095713,
												42.249605009
											],
											[
												-71.016368831,
												42.249617796
											],
											[
												-71.016386038,
												42.250157837
											],
											[
												-71.017112926,
												42.25014505
											],
											[
												-71.017130139,
												42.250685091
											],
											[
												-71.016403245,
												42.250697878
											],
											[
												-71.016420453,
												42.251237919
											],
											[
												-71.017147353,
												42.251225132
											],
											[
												-71.017164568,
												42.251765173
											],
											[
												-71.017891473,
												42.251752381
											],
											[
												-71.017874253,
												42.251212341
											],
											[
												-71.018601152,
												42.251199545
											],
											[
												-71.018583926,
												42.250659504
											],
											[
												-71.019310818,
												42.250646704
											],
											[
												-71.019345284,
												42.251726784
											],
											[
												-71.018618379,
												42.251739585
											],
											[
												-71.018652834,
												42.252819665
											],
											[
												-71.019379751,
												42.252806864
											],
											[
												-71.01941422,
												42.253886944
											],
											[
												-71.018687291,
												42.253899746
											],
											[
												-71.01872175,
												42.254979826
											],
											[
												-71.019448692,
												42.254967023
											],
											[
												-71.019483165,
												42.256047103
											],
											[
												-71.01875621,
												42.256059905
											],
											[
												-71.01873898,
												42.255519865
											],
											[
												-71.018012031,
												42.255532663
											],
											[
												-71.017994807,
												42.254992623
											],
											[
												-71.017267864,
												42.255005416
											],
											[
												-71.017319519,
												42.256625537
											],
											[
												-71.016592557,
												42.256638326
											],
											[
												-71.016626983,
												42.257718407
											],
											[
												-71.017353957,
												42.257705618
											],
											[
												-71.017371178,
												42.258245658
											],
											[
												-71.016644197,
												42.258258448
											],
											[
												-71.016730274,
												42.260958648
											],
											[
												-71.017457285,
												42.260945857
											],
											[
												-71.017646763,
												42.266886291
											],
											[
												-71.016919684,
												42.266899085
											],
											[
												-71.016885241,
												42.265819006
											],
											[
												-71.016158173,
												42.265831795
											],
											[
												-71.016020472,
												42.261511475
											],
											[
												-71.015293453,
												42.261524257
											],
											[
												-71.015121431,
												42.25612385
											],
											[
												-71.012940558,
												42.256162161
											],
											[
												-71.01295774,
												42.256702203
											],
											[
												-71.014411668,
												42.256676666
											],
											[
												-71.014446057,
												42.257756748
											],
											[
												-71.012992104,
												42.257782286
											],
											[
												-71.012974922,
												42.257242245
											],
											[
												-71.011520979,
												42.257267764
											],
											[
												-71.01155532,
												42.258347848
											],
											[
												-71.010828335,
												42.258360601
											],
											[
												-71.0108455,
												42.258900643
											],
											[
												-71.010118509,
												42.258913392
											],
											[
												-71.010084192,
												42.257833307
											],
											[
												-71.010811171,
												42.257820559
											],
											[
												-71.010776844,
												42.256740474
											],
											[
												-71.011503809,
												42.256727722
											],
											[
												-71.011435136,
												42.254567553
											],
											[
												-71.012162076,
												42.254554797
											],
											[
												-71.01212773,
												42.253474712
											],
											[
												-71.010673873,
												42.253500219
											],
											[
												-71.010656713,
												42.252960176
											],
											[
												-71.012110557,
												42.25293467
											],
											[
												-71.012024702,
												42.250234458
											],
											[
												-71.011297811,
												42.250247212
											],
											[
												-71.011280648,
												42.249707169
											],
											[
												-71.010553762,
												42.249719918
											],
											[
												-71.010519449,
												42.248639832
											],
											[
												-71.011246322,
												42.248627083
											],
											[
												-71.011263485,
												42.249167126
											],
											[
												-71.011990363,
												42.249154372
											],
											[
												-71.012007532,
												42.249694415
											],
											[
												-71.012734417,
												42.249681657
											],
											[
												-71.012751593,
												42.250221699
											],
											[
												-71.014932261,
												42.250183395
											],
											[
												-71.014915067,
												42.249643354
											],
											[
												-71.015641949,
												42.249630577
											],
											[
												-71.015469969,
												42.24423016
											],
											[
												-71.016196789,
												42.244217381
											],
											[
												-71.016127985,
												42.242057213
											],
											[
												-71.01685478,
												42.24204443
											]
										]
									],
									[
										[
											[
												-71.020210119,
												42.256034295
											],
											[
												-71.020227362,
												42.256574335
											],
											[
												-71.019500402,
												42.256587142
											],
											[
												-71.019483165,
												42.256047103
											],
											[
												-71.020210119,
												42.256034295
											]
										]
									]
								]
							},
							"properties": {
								"threshold": 133
							}
						},
						{
							"id": 2714,
							"type": "Feature",
							"geometry": {
								"type": "MultiPolygon",
								"coordinates": [
									[
										[
											[
												-71.016334419,
												42.248537713
											],
											[
												-71.016386038,
												42.250157837
											],
											[
												-71.01565915,
												42.250170618
											],
											[
												-71.015607549,
												42.248550494
											],
											[
												-71.016334419,
												42.248537713
											]
										]
									],
									[
										[
											[
												-71.016420453,
												42.251237919
											],
											[
												-71.016472079,
												42.252858042
											],
											[
												-71.017198998,
												42.252845254
											],
											[
												-71.01723343,
												42.253925335
											],
											[
												-71.017960361,
												42.253912543
											],
											[
												-71.017994807,
												42.254992623
											],
											[
												-71.017267864,
												42.255005416
											],
											[
												-71.017250647,
												42.254465376
											],
											[
												-71.01652371,
												42.254478164
											],
											[
												-71.016540921,
												42.255018205
											],
											[
												-71.015813977,
												42.255030989
											],
											[
												-71.015831182,
												42.255571029
											],
											[
												-71.016558132,
												42.255558245
											],
											[
												-71.016575344,
												42.256098286
											],
											[
												-71.015848388,
												42.25611107
											],
											[
												-71.015900008,
												42.257731192
											],
											[
												-71.015173033,
												42.257743973
											],
											[
												-71.015087032,
												42.255043768
											],
											[
												-71.013633142,
												42.255069312
											],
											[
												-71.013650329,
												42.255609354
											],
											[
												-71.012923377,
												42.25562212
											],
											[
												-71.012820301,
												42.252381868
											],
											[
												-71.013547216,
												42.252369104
											],
											[
												-71.013530032,
												42.251829062
											],
											[
												-71.01425694,
												42.251816293
											],
											[
												-71.01423975,
												42.251276252
											],
											[
												-71.016420453,
												42.251237919
											]
										],
										[
											[
												-71.01425694,
												42.251816293
											],
											[
												-71.01427413,
												42.252356335
											],
											[
												-71.015001044,
												42.252343562
											],
											[
												-71.014983847,
												42.25180352
											],
											[
												-71.01425694,
												42.251816293
											]
										]
									],
									[
										[
											[
												-71.013512848,
												42.25128902
											],
											[
												-71.013530032,
												42.251829062
											],
											[
												-71.012803123,
												42.251841826
											],
											[
												-71.012785946,
												42.251301784
											],
											[
												-71.013512848,
												42.25128902
											]
										]
									],
									[
										[
											[
												-71.017908694,
												42.252292422
											],
											[
												-71.017925916,
												42.252832462
											],
											[
												-71.017198998,
												42.252845254
											],
											[
												-71.017181783,
												42.252305214
											],
											[
												-71.017908694,
												42.252292422
											]
										]
									],
									[
										[
											[
												-71.012923377,
												42.25562212
											],
											[
												-71.012940558,
												42.256162161
											],
											[
												-71.012213599,
												42.256174923
											],
											[
												-71.012196425,
												42.255634881
											],
											[
												-71.012923377,
												42.25562212
											]
										]
									],
									[
										[
											[
												-71.016626983,
												42.257718407
											],
											[
												-71.016661411,
												42.258798488
											],
											[
												-71.015934424,
												42.258811273
											],
											[
												-71.015900008,
												42.257731192
											],
											[
												-71.016626983,
												42.257718407
											]
										]
									]
								]
							},
							"properties": {
								"threshold": 120
							}
						},
						{
							"id": 2712,
							"type": "Feature",
							"geometry": {
								"type": "MultiPolygon",
								"coordinates": [
									[
										[
											[
												-71.0174611,
												42.238251351
											],
											[
												-71.017667642,
												42.24473185
											],
											[
												-71.016940817,
												42.244744639
											],
											[
												-71.017044077,
												42.247984886
											],
											[
												-71.016317214,
												42.247997672
											],
											[
												-71.016334419,
												42.248537713
											],
											[
												-71.017061288,
												42.248524927
											],
											[
												-71.0170785,
												42.249064969
											],
											[
												-71.017805375,
												42.249052178
											],
											[
												-71.017822594,
												42.249592219
											],
											[
												-71.017095713,
												42.249605009
											],
											[
												-71.017112926,
												42.25014505
											],
											[
												-71.017839813,
												42.25013226
											],
											[
												-71.017857033,
												42.2506723
											],
											[
												-71.017130139,
												42.250685091
											],
											[
												-71.017164568,
												42.251765173
											],
											[
												-71.017891473,
												42.251752381
											],
											[
												-71.017874253,
												42.251212341
											],
											[
												-71.018601152,
												42.251199545
											],
											[
												-71.018583926,
												42.250659504
											],
											[
												-71.019310818,
												42.250646704
											],
											[
												-71.019293586,
												42.250106664
											],
											[
												-71.020020472,
												42.250093859
											],
											[
												-71.020054949,
												42.251173939
											],
											[
												-71.019328051,
												42.251186744
											],
											[
												-71.019345284,
												42.251726784
											],
											[
												-71.018618379,
												42.251739585
											],
											[
												-71.018635606,
												42.252279625
											],
											[
												-71.019362517,
												42.252266824
											],
											[
												-71.019379751,
												42.252806864
											],
											[
												-71.020106668,
												42.252794058
											],
											[
												-71.020141149,
												42.253874137
											],
											[
												-71.01941422,
												42.253886944
											],
											[
												-71.019431456,
												42.254426984
											],
											[
												-71.01870452,
												42.254439786
											],
											[
												-71.01872175,
												42.254979826
											],
											[
												-71.019448692,
												42.254967023
											],
											[
												-71.019465928,
												42.255507063
											],
											[
												-71.020192876,
												42.255494256
											],
											[
												-71.020210119,
												42.256034295
											],
											[
												-71.020937072,
												42.256021483
											],
											[
												-71.020971572,
												42.257101561
											],
											[
												-71.020244606,
												42.257114374
											],
											[
												-71.020227362,
												42.256574335
											],
											[
												-71.019500402,
												42.256587142
											],
											[
												-71.019483165,
												42.256047103
											],
											[
												-71.01875621,
												42.256059905
											],
											[
												-71.01873898,
												42.255519865
											],
											[
												-71.018012031,
												42.255532663
											],
											[
												-71.018063706,
												42.257152783
											],
											[
												-71.017336738,
												42.257165577
											],
											[
												-71.017353957,
												42.257705618
											],
											[
												-71.018080931,
												42.257692823
											],
											[
												-71.018098158,
												42.258232863
											],
											[
												-71.017371178,
												42.258245658
											],
											[
												-71.017388398,
												42.258785698
											],
											[
												-71.016661411,
												42.258798488
											],
											[
												-71.016695842,
												42.259878568
											],
											[
												-71.017422841,
												42.259865778
											],
											[
												-71.017577856,
												42.264726134
											],
											[
												-71.01830491,
												42.264713337
											],
											[
												-71.018528969,
												42.271733841
											],
											[
												-71.017074698,
												42.271759437
											],
											[
												-71.017005798,
												42.269599281
											],
											[
												-71.016278687,
												42.269612072
											],
											[
												-71.016106532,
												42.264211675
											],
											[
												-71.015379482,
												42.264224459
											],
											[
												-71.015207436,
												42.258824054
											],
											[
												-71.014480448,
												42.258836831
											],
											[
												-71.014463252,
												42.25829679
											],
											[
												-71.01373627,
												42.258309561
											],
											[
												-71.013719081,
												42.25776952
											],
											[
												-71.012265127,
												42.257795048
											],
											[
												-71.012282304,
												42.25833509
											],
											[
												-71.013009287,
												42.258322328
											],
											[
												-71.013043654,
												42.259402411
											],
											[
												-71.012316658,
												42.259415173
											],
											[
												-71.012299481,
												42.258875132
											],
											[
												-71.011572491,
												42.25888789
											],
											[
												-71.01155532,
												42.258347848
											],
											[
												-71.010828335,
												42.258360601
											],
											[
												-71.010862665,
												42.259440685
											],
											[
												-71.010135668,
												42.259453434
											],
											[
												-71.010152828,
												42.259993476
											],
											[
												-71.009425824,
												42.260006221
											],
											[
												-71.009442978,
												42.260546263
											],
											[
												-71.008715967,
												42.260559004
											],
											[
												-71.008733115,
												42.261099046
											],
											[
												-71.008006098,
												42.261111782
											],
											[
												-71.007971815,
												42.260031696
											],
											[
												-71.008698819,
												42.260018961
											],
											[
												-71.008664526,
												42.258938875
											],
											[
												-71.009391518,
												42.258926136
											],
											[
												-71.009357213,
												42.25784605
											],
											[
												-71.010084192,
												42.257833307
											],
											[
												-71.010067035,
												42.257293264
											],
											[
												-71.010794007,
												42.257280516
											],
											[
												-71.010725356,
												42.255120346
											],
											[
												-71.011452303,
												42.255107595
											],
											[
												-71.011435136,
												42.254567553
											],
											[
												-71.009981253,
												42.254593051
											],
											[
												-71.009964098,
												42.254053008
											],
											[
												-71.009237163,
												42.25406575
											],
											[
												-71.00918572,
												42.25244562
											],
											[
												-71.01136647,
												42.252407383
											],
											[
												-71.011280648,
												42.249707169
											],
											[
												-71.010553762,
												42.249719918
											],
											[
												-71.010536606,
												42.249179875
											],
											[
												-71.009809726,
												42.249192619
											],
											[
												-71.009775426,
												42.248112532
											],
											[
												-71.009048559,
												42.248125272
											],
											[
												-71.009014273,
												42.247045184
											],
											[
												-71.009741128,
												42.247032445
											],
											[
												-71.009758277,
												42.247572489
											],
											[
												-71.010485138,
												42.247559745
											],
											[
												-71.010502293,
												42.248099788
											],
											[
												-71.01122916,
												42.24808704
											],
											[
												-71.011263485,
												42.249167126
											],
											[
												-71.012717241,
												42.249141614
											],
											[
												-71.012700066,
												42.248601572
											],
											[
												-71.013426938,
												42.248588809
											],
											[
												-71.013409757,
												42.248048767
											],
											[
												-71.014136622,
												42.248036
											],
											[
												-71.014170996,
												42.249116084
											],
											[
												-71.013444119,
												42.249128851
											],
											[
												-71.013478483,
												42.250208936
											],
											[
												-71.014932261,
												42.250183395
											],
											[
												-71.014897873,
												42.249103312
											],
											[
												-71.015624749,
												42.249090535
											],
											[
												-71.015469969,
												42.24423016
											],
											[
												-71.016196789,
												42.244217381
											],
											[
												-71.016179587,
												42.243677339
											],
											[
												-71.015452774,
												42.243690118
											],
											[
												-71.01540119,
												42.242069991
											],
											[
												-71.016127985,
												42.242057213
											],
											[
												-71.016024794,
												42.23881696
											],
											[
												-71.016751552,
												42.238804179
											],
											[
												-71.016734349,
												42.238264137
											],
											[
												-71.0174611,
												42.238251351
											]
										],
										[
											[
												-71.014411668,
												42.256676666
											],
											[
												-71.014446057,
												42.257756748
											],
											[
												-71.015173033,
												42.257743973
											],
											[
												-71.015138631,
												42.256663891
											],
											[
												-71.014411668,
												42.256676666
											]
										]
									],
									[
										[
											[
												-71.008997131,
												42.24650514
											],
											[
												-71.009014273,
												42.247045184
											],
											[
												-71.008287417,
												42.247057918
											],
											[
												-71.008270281,
												42.246517874
											],
											[
												-71.008997131,
												42.24650514
											]
										]
									]
								]
							},
							"properties": {
								"threshold": 138
							}
						}
					]
				}
			],
			"meta": {
				"status": "ok"
			}
		}
	}
	if (name === "UNDEF-03 B2_15MHz_1025 Equipment Bundle Demo(RING)") {
		var res = {
			"request_obj": [
				{
					"json_agg": [
						{
							"id": 2718,
							"type": "Feature",
							"geometry": {
								"type": "MultiPolygon",
								"coordinates": [
									[
										[
											[
												-71.0174611,
												42.238251351
											],
											[
												-71.017667642,
												42.24473185
											],
											[
												-71.016940817,
												42.244744639
											],
											[
												-71.017044077,
												42.247984886
											],
											[
												-71.016317214,
												42.247997672
											],
											[
												-71.016334419,
												42.248537713
											],
											[
												-71.017061288,
												42.248524927
											],
											[
												-71.0170785,
												42.249064969
											],
											[
												-71.017805375,
												42.249052178
											],
											[
												-71.017822594,
												42.249592219
											],
											[
												-71.017095713,
												42.249605009
											],
											[
												-71.017112926,
												42.25014505
											],
											[
												-71.017839813,
												42.25013226
											],
											[
												-71.017857033,
												42.2506723
											],
											[
												-71.017130139,
												42.250685091
											],
											[
												-71.017164568,
												42.251765173
											],
											[
												-71.017891473,
												42.251752381
											],
											[
												-71.017874253,
												42.251212341
											],
											[
												-71.018601152,
												42.251199545
											],
											[
												-71.018583926,
												42.250659504
											],
											[
												-71.019310818,
												42.250646704
											],
											[
												-71.019293586,
												42.250106664
											],
											[
												-71.020020472,
												42.250093859
											],
											[
												-71.020054949,
												42.251173939
											],
											[
												-71.019328051,
												42.251186744
											],
											[
												-71.019345284,
												42.251726784
											],
											[
												-71.018618379,
												42.251739585
											],
											[
												-71.018635606,
												42.252279625
											],
											[
												-71.019362517,
												42.252266824
											],
											[
												-71.019379751,
												42.252806864
											],
											[
												-71.020106668,
												42.252794058
											],
											[
												-71.020141149,
												42.253874137
											],
											[
												-71.01941422,
												42.253886944
											],
											[
												-71.019431456,
												42.254426984
											],
											[
												-71.01870452,
												42.254439786
											],
											[
												-71.01872175,
												42.254979826
											],
											[
												-71.019448692,
												42.254967023
											],
											[
												-71.019465928,
												42.255507063
											],
											[
												-71.020192876,
												42.255494256
											],
											[
												-71.020210119,
												42.256034295
											],
											[
												-71.020937072,
												42.256021483
											],
											[
												-71.020971572,
												42.257101561
											],
											[
												-71.020244606,
												42.257114374
											],
											[
												-71.020227362,
												42.256574335
											],
											[
												-71.019500402,
												42.256587142
											],
											[
												-71.019483165,
												42.256047103
											],
											[
												-71.01875621,
												42.256059905
											],
											[
												-71.01873898,
												42.255519865
											],
											[
												-71.018012031,
												42.255532663
											],
											[
												-71.018063706,
												42.257152783
											],
											[
												-71.017336738,
												42.257165577
											],
											[
												-71.017353957,
												42.257705618
											],
											[
												-71.018080931,
												42.257692823
											],
											[
												-71.018098158,
												42.258232863
											],
											[
												-71.017371178,
												42.258245658
											],
											[
												-71.017388398,
												42.258785698
											],
											[
												-71.016661411,
												42.258798488
											],
											[
												-71.016695842,
												42.259878568
											],
											[
												-71.017422841,
												42.259865778
											],
											[
												-71.017577856,
												42.264726134
											],
											[
												-71.01830491,
												42.264713337
											],
											[
												-71.018528969,
												42.271733841
											],
											[
												-71.017074698,
												42.271759437
											],
											[
												-71.017005798,
												42.269599281
											],
											[
												-71.016278687,
												42.269612072
											],
											[
												-71.016106532,
												42.264211675
											],
											[
												-71.015379482,
												42.264224459
											],
											[
												-71.015207436,
												42.258824054
											],
											[
												-71.014480448,
												42.258836831
											],
											[
												-71.014463252,
												42.25829679
											],
											[
												-71.01373627,
												42.258309561
											],
											[
												-71.013719081,
												42.25776952
											],
											[
												-71.012265127,
												42.257795048
											],
											[
												-71.012282304,
												42.25833509
											],
											[
												-71.013009287,
												42.258322328
											],
											[
												-71.013043654,
												42.259402411
											],
											[
												-71.012316658,
												42.259415173
											],
											[
												-71.012299481,
												42.258875132
											],
											[
												-71.011572491,
												42.25888789
											],
											[
												-71.01155532,
												42.258347848
											],
											[
												-71.010828335,
												42.258360601
											],
											[
												-71.010862665,
												42.259440685
											],
											[
												-71.010135668,
												42.259453434
											],
											[
												-71.010152828,
												42.259993476
											],
											[
												-71.009425824,
												42.260006221
											],
											[
												-71.009442978,
												42.260546263
											],
											[
												-71.008715967,
												42.260559004
											],
											[
												-71.008733115,
												42.261099046
											],
											[
												-71.008006098,
												42.261111782
											],
											[
												-71.007971815,
												42.260031696
											],
											[
												-71.008698819,
												42.260018961
											],
											[
												-71.008664526,
												42.258938875
											],
											[
												-71.009391518,
												42.258926136
											],
											[
												-71.009357213,
												42.25784605
											],
											[
												-71.010084192,
												42.257833307
											],
											[
												-71.010067035,
												42.257293264
											],
											[
												-71.010794007,
												42.257280516
											],
											[
												-71.010725356,
												42.255120346
											],
											[
												-71.011452303,
												42.255107595
											],
											[
												-71.011435136,
												42.254567553
											],
											[
												-71.009981253,
												42.254593051
											],
											[
												-71.009964098,
												42.254053008
											],
											[
												-71.009237163,
												42.25406575
											],
											[
												-71.00918572,
												42.25244562
											],
											[
												-71.01136647,
												42.252407383
											],
											[
												-71.011280648,
												42.249707169
											],
											[
												-71.010553762,
												42.249719918
											],
											[
												-71.010536606,
												42.249179875
											],
											[
												-71.009809726,
												42.249192619
											],
											[
												-71.009775426,
												42.248112532
											],
											[
												-71.009048559,
												42.248125272
											],
											[
												-71.009014273,
												42.247045184
											],
											[
												-71.009741128,
												42.247032445
											],
											[
												-71.009758277,
												42.247572489
											],
											[
												-71.010485138,
												42.247559745
											],
											[
												-71.010502293,
												42.248099788
											],
											[
												-71.01122916,
												42.24808704
											],
											[
												-71.011263485,
												42.249167126
											],
											[
												-71.012717241,
												42.249141614
											],
											[
												-71.012700066,
												42.248601572
											],
											[
												-71.013426938,
												42.248588809
											],
											[
												-71.013409757,
												42.248048767
											],
											[
												-71.014136622,
												42.248036
											],
											[
												-71.014170996,
												42.249116084
											],
											[
												-71.013444119,
												42.249128851
											],
											[
												-71.013478483,
												42.250208936
											],
											[
												-71.014932261,
												42.250183395
											],
											[
												-71.014897873,
												42.249103312
											],
											[
												-71.015624749,
												42.249090535
											],
											[
												-71.015469969,
												42.24423016
											],
											[
												-71.016196789,
												42.244217381
											],
											[
												-71.016179587,
												42.243677339
											],
											[
												-71.015452774,
												42.243690118
											],
											[
												-71.01540119,
												42.242069991
											],
											[
												-71.016127985,
												42.242057213
											],
											[
												-71.016024794,
												42.23881696
											],
											[
												-71.016751552,
												42.238804179
											],
											[
												-71.016734349,
												42.238264137
											],
											[
												-71.0174611,
												42.238251351
											]
										],
										[
											[
												-71.014411668,
												42.256676666
											],
											[
												-71.014446057,
												42.257756748
											],
											[
												-71.015173033,
												42.257743973
											],
											[
												-71.015138631,
												42.256663891
											],
											[
												-71.014411668,
												42.256676666
											]
										]
									],
									[
										[
											[
												-71.008997131,
												42.24650514
											],
											[
												-71.009014273,
												42.247045184
											],
											[
												-71.008287417,
												42.247057918
											],
											[
												-71.008270281,
												42.246517874
											],
											[
												-71.008997131,
												42.24650514
											]
										]
									]
								]
							},
							"properties": {
								"threshold": 138
							}
						},
						{
							"id": 2719,
							"type": "Feature",
							"geometry": {
								"type": "MultiPolygon",
								"coordinates": [
									[
										[
											[
												-71.01685478,
												42.24204443
											],
											[
												-71.017026865,
												42.247444845
											],
											[
												-71.016300009,
												42.24745763
											],
											[
												-71.016351625,
												42.249077754
											],
											[
												-71.0170785,
												42.249064969
											],
											[
												-71.017095713,
												42.249605009
											],
											[
												-71.016368831,
												42.249617796
											],
											[
												-71.016386038,
												42.250157837
											],
											[
												-71.017112926,
												42.25014505
											],
											[
												-71.017130139,
												42.250685091
											],
											[
												-71.016403245,
												42.250697878
											],
											[
												-71.016420453,
												42.251237919
											],
											[
												-71.017147353,
												42.251225132
											],
											[
												-71.017164568,
												42.251765173
											],
											[
												-71.017891473,
												42.251752381
											],
											[
												-71.017874253,
												42.251212341
											],
											[
												-71.018601152,
												42.251199545
											],
											[
												-71.018583926,
												42.250659504
											],
											[
												-71.019310818,
												42.250646704
											],
											[
												-71.019345284,
												42.251726784
											],
											[
												-71.018618379,
												42.251739585
											],
											[
												-71.018652834,
												42.252819665
											],
											[
												-71.019379751,
												42.252806864
											],
											[
												-71.01941422,
												42.253886944
											],
											[
												-71.018687291,
												42.253899746
											],
											[
												-71.01872175,
												42.254979826
											],
											[
												-71.019448692,
												42.254967023
											],
											[
												-71.019483165,
												42.256047103
											],
											[
												-71.01875621,
												42.256059905
											],
											[
												-71.01873898,
												42.255519865
											],
											[
												-71.018012031,
												42.255532663
											],
											[
												-71.017994807,
												42.254992623
											],
											[
												-71.017267864,
												42.255005416
											],
											[
												-71.017319519,
												42.256625537
											],
											[
												-71.016592557,
												42.256638326
											],
											[
												-71.016626983,
												42.257718407
											],
											[
												-71.017353957,
												42.257705618
											],
											[
												-71.017371178,
												42.258245658
											],
											[
												-71.016644197,
												42.258258448
											],
											[
												-71.016730274,
												42.260958648
											],
											[
												-71.017457285,
												42.260945857
											],
											[
												-71.017646763,
												42.266886291
											],
											[
												-71.016919684,
												42.266899085
											],
											[
												-71.016885241,
												42.265819006
											],
											[
												-71.016158173,
												42.265831795
											],
											[
												-71.016020472,
												42.261511475
											],
											[
												-71.015293453,
												42.261524257
											],
											[
												-71.015121431,
												42.25612385
											],
											[
												-71.012940558,
												42.256162161
											],
											[
												-71.01295774,
												42.256702203
											],
											[
												-71.014411668,
												42.256676666
											],
											[
												-71.014446057,
												42.257756748
											],
											[
												-71.012992104,
												42.257782286
											],
											[
												-71.012974922,
												42.257242245
											],
											[
												-71.011520979,
												42.257267764
											],
											[
												-71.01155532,
												42.258347848
											],
											[
												-71.010828335,
												42.258360601
											],
											[
												-71.0108455,
												42.258900643
											],
											[
												-71.010118509,
												42.258913392
											],
											[
												-71.010084192,
												42.257833307
											],
											[
												-71.010811171,
												42.257820559
											],
											[
												-71.010776844,
												42.256740474
											],
											[
												-71.011503809,
												42.256727722
											],
											[
												-71.011435136,
												42.254567553
											],
											[
												-71.012162076,
												42.254554797
											],
											[
												-71.01212773,
												42.253474712
											],
											[
												-71.010673873,
												42.253500219
											],
											[
												-71.010656713,
												42.252960176
											],
											[
												-71.012110557,
												42.25293467
											],
											[
												-71.012024702,
												42.250234458
											],
											[
												-71.011297811,
												42.250247212
											],
											[
												-71.011280648,
												42.249707169
											],
											[
												-71.010553762,
												42.249719918
											],
											[
												-71.010519449,
												42.248639832
											],
											[
												-71.011246322,
												42.248627083
											],
											[
												-71.011263485,
												42.249167126
											],
											[
												-71.011990363,
												42.249154372
											],
											[
												-71.012007532,
												42.249694415
											],
											[
												-71.012734417,
												42.249681657
											],
											[
												-71.012751593,
												42.250221699
											],
											[
												-71.014932261,
												42.250183395
											],
											[
												-71.014915067,
												42.249643354
											],
											[
												-71.015641949,
												42.249630577
											],
											[
												-71.015469969,
												42.24423016
											],
											[
												-71.016196789,
												42.244217381
											],
											[
												-71.016127985,
												42.242057213
											],
											[
												-71.01685478,
												42.24204443
											]
										]
									],
									[
										[
											[
												-71.020210119,
												42.256034295
											],
											[
												-71.020227362,
												42.256574335
											],
											[
												-71.019500402,
												42.256587142
											],
											[
												-71.019483165,
												42.256047103
											],
											[
												-71.020210119,
												42.256034295
											]
										]
									]
								]
							},
							"properties": {
								"threshold": 133
							}
						},
						{
							"id": 2720,
							"type": "Feature",
							"geometry": {
								"type": "MultiPolygon",
								"coordinates": [
									[
										[
											[
												-71.016334419,
												42.248537713
											],
											[
												-71.016386038,
												42.250157837
											],
											[
												-71.01565915,
												42.250170618
											],
											[
												-71.015607549,
												42.248550494
											],
											[
												-71.016334419,
												42.248537713
											]
										]
									],
									[
										[
											[
												-71.016420453,
												42.251237919
											],
											[
												-71.016472079,
												42.252858042
											],
											[
												-71.017198998,
												42.252845254
											],
											[
												-71.01723343,
												42.253925335
											],
											[
												-71.017960361,
												42.253912543
											],
											[
												-71.017994807,
												42.254992623
											],
											[
												-71.017267864,
												42.255005416
											],
											[
												-71.017250647,
												42.254465376
											],
											[
												-71.01652371,
												42.254478164
											],
											[
												-71.016540921,
												42.255018205
											],
											[
												-71.015813977,
												42.255030989
											],
											[
												-71.015831182,
												42.255571029
											],
											[
												-71.016558132,
												42.255558245
											],
											[
												-71.016575344,
												42.256098286
											],
											[
												-71.015848388,
												42.25611107
											],
											[
												-71.015900008,
												42.257731192
											],
											[
												-71.015173033,
												42.257743973
											],
											[
												-71.015087032,
												42.255043768
											],
											[
												-71.013633142,
												42.255069312
											],
											[
												-71.013650329,
												42.255609354
											],
											[
												-71.012923377,
												42.25562212
											],
											[
												-71.012820301,
												42.252381868
											],
											[
												-71.013547216,
												42.252369104
											],
											[
												-71.013530032,
												42.251829062
											],
											[
												-71.01425694,
												42.251816293
											],
											[
												-71.01423975,
												42.251276252
											],
											[
												-71.016420453,
												42.251237919
											]
										],
										[
											[
												-71.01425694,
												42.251816293
											],
											[
												-71.01427413,
												42.252356335
											],
											[
												-71.015001044,
												42.252343562
											],
											[
												-71.014983847,
												42.25180352
											],
											[
												-71.01425694,
												42.251816293
											]
										]
									],
									[
										[
											[
												-71.013512848,
												42.25128902
											],
											[
												-71.013530032,
												42.251829062
											],
											[
												-71.012803123,
												42.251841826
											],
											[
												-71.012785946,
												42.251301784
											],
											[
												-71.013512848,
												42.25128902
											]
										]
									],
									[
										[
											[
												-71.017908694,
												42.252292422
											],
											[
												-71.017925916,
												42.252832462
											],
											[
												-71.017198998,
												42.252845254
											],
											[
												-71.017181783,
												42.252305214
											],
											[
												-71.017908694,
												42.252292422
											]
										]
									],
									[
										[
											[
												-71.012923377,
												42.25562212
											],
											[
												-71.012940558,
												42.256162161
											],
											[
												-71.012213599,
												42.256174923
											],
											[
												-71.012196425,
												42.255634881
											],
											[
												-71.012923377,
												42.25562212
											]
										]
									],
									[
										[
											[
												-71.016626983,
												42.257718407
											],
											[
												-71.016661411,
												42.258798488
											],
											[
												-71.015934424,
												42.258811273
											],
											[
												-71.015900008,
												42.257731192
											],
											[
												-71.016626983,
												42.257718407
											]
										]
									]
								]
							},
							"properties": {
								"threshold": 120
							}
						}
					]
				}
			],
			"meta": {
				"status": "ok"
			}
		}
	}

	return res;

}

var anayticsData1 = {
	"results": [
		{
			"resultID": 01,
			"name": "Revision 1",
			"createdBy": "priyadarshani",
			"createdOn": "04/28/2021 14:13",
			"status": "active",
			"analytics": [
				{
					"tx_id": "UNDEF-01 B4_20MHz_2050 Equipment Bundle Demo(RING)",
					"POP_S": "pop1",
					"CUMULATIVE_OFFLOAD": 0,
					"LICENSE_VIOLATIONS": 0,
					"CIMM": "45342342",
					"AREA": "area1",
				},
				{
					"tx_id": "UNDEF-01 B4_20MHz_2050 Equipment Bundle Demo(RING)",
					"POP_S": "pop2",
					"CUMULATIVE_OFFLOAD": 0,
					"LICENSE_VIOLATIONS": 0,
					"CIMM": "123445",
					"AREA": "area2",
				},
				{
					"tx_id": "UNDEF-01 B4_20MHz_2050 Equipment Bundle Demo(RING)",
					"POP_S": "pop3",
					"CUMULATIVE_OFFLOAD": 0,
					"LICENSE_VIOLATIONS": 0,
					"CIMM": "3232323",
					"AREA": "area3",
				},
			]
		}
]
}

var anayticsData = {
	"marketIdentifier": "NewEnglandEast",
	"fuzeSpmId": 16448474,
	"fuzeSiteId": 441707,
	"fuzeSiteName": "9999 Equipment Bundle Demo (STA-RING)",
	"parentSolutionId": 1052303,
	"siteVersion": "RING",
	"equipmentBundleId": "D01a",
	"vendor": "Samsung",
	"locationInfo": {
		"locationName": "Equipment Bundle Demo",
		"coordinates": [42.25342602519468, -71.01545333862306]
	},

	"revisions": [
		{
			"revisionID": 01,
			"name": "Revision 1",
			"createdBy": "Ahmed, Elhussein",
			"createdOn": "03/23/2021 14:13",
			"status": "active",
			"analytics": [
				{
					"tx_id": "UNDEF-01 B4_20MHz_2050 Equipment Bundle Demo(RING)",
					"POP_S": "pop1",
					"CUMULATIVE_OFFLOAD": 2,
					"LICENSE_VIOLATIONS": 10,
					"OFS": "ofs",
					"CIMM": "45342342",
					"AREA": "area1",
				},
				{
					"tx_id": "UNDEF-01 B4_20MHz_2050 Equipment Bundle Demo(RING1)",
					"POP_S": "pop",
					"CUMULATIVE_OFFLOAD": 0,
					"LICENSE_VIOLATIONS": 0,
					"OFS": "ofs",
					"CIMM": "123445",
					"AREA": "area2",
				},
				{
					"tx_id": "UNDEF-01 B4_20MHz_2050 Equipment Bundle Demo(RING2)",
					"POP_S": "pop3",
					"CUMULATIVE_OFFLOAD": 0,
					"LICENSE_VIOLATIONS": 0,
					"OFS": "ofs",
					"CIMM": "3232323",
					"AREA": "area3",
				},
			]
		},
		{
			"revisionID": 02,
			"name": "Revision 2",
			"createdBy": "Ahmed, Elhussein",
			"createdOn": "03/23/2021 14:13",
			"status": "active",
			"analytics": [
				{
					"tx_id": "UNDEF-01 B4_20MHz_2050 Equipment Bundle Demo(RING)",
					"POP_S": "pop1",
					"CUMULATIVE_OFFLOAD": 0,
					"LICENSE_VIOLATIONS": 0,
					"OFS": "ofs",
					"CIMM": "45342342",
					"AREA": "area1",
				},
				{
					"tx_id": "UNDEF-01 B4_20MHz_2050 Equipment Bundle Demo(RING1)",
					"POP_S": "pop2",
					"CUMULATIVE_OFFLOAD": 0,
					"LICENSE_VIOLATIONS": 0,
					"OFS": "ofs",
					"CIMM": "123445",
					"AREA": "area2",
				},
				{
					"tx_id": "UNDEF-01 B4_20MHz_2050 Equipment Bundle Demo(RING2)",
					"POP_S": "pop3",
					"CUMULATIVE_OFFLOAD": 0,
					"LICENSE_VIOLATIONS": 0,
					"OFS": "ofs",
					"CIMM": "3232323",
					"AREA": "area3",
				},
			]
		}
	]

};

var sites = [
	{"SITE_ID":616570065,"AREA_ID":4565,"FUZE_SITE_ID":616570065,"NAME":"BILLY WATSON HWY - A","STATUS":"Primary","ADDRESS":"4807 Hwy 51 South","CITY":"Ariton","STATE":"AL","COUNTY":"Barbour","ZIPCODE":"36311","LATITUDE":43.204966,"LONGITUDE":-72.015465,"SITE_TYPE":"MACRO","GRANITE_SITE_ID":616570065,"PSLC":"593919","AREA_NAME":"1005","FIBER_STATUS":"","RADIO_STATUS":"","SECTOR_TRIGGER":"","MPT_SITETYPE":"MACRO","IS_5G":0,"LOCAL_MARKET":"309#Southern AL/GA\r","MARKET":"","ENODEBGRPLOGIC":""},
	{"SITE_ID":5036958,"AREA_ID":4565,"FUZE_SITE_ID":5036958,"FUZE_SECTORS":"1,2,3","NAME":"BRENDEN","STATUS":"Live","ADDRESS":"County Road 33","CITY":"Clio","STATE":"AL","COUNTY":"Barbour","ZIPCODE":"36017","LATITUDE":43.14966,"LONGITUDE":-71.115185,"LOCATIONNAME":"BRENDEN - A|BRENDEN - A|BRENDEN - A|BRENDEN - A|BRENDEN - A|BRENDEN - A|BRENDEN - A","SITE_TYPE":"MICRO","GRANITE_SITE_ID":5036958,"AREA_NAME":"1005","FIBER_STATUS":"","RADIO_STATUS":"","SECTOR_TRIGGER":"","MPT_SITETYPE":"MICRO","IS_5G":0,"ENODEBS":"170370","LOCAL_MARKET":"309#Southern AL/GA\r","ATOLL_SCHEMA_NAME":"Atlanta","MARKET":"170","ENODEBGRPLOGIC":"[170][5036958]","TECHNOLOGYTYPE":"4G","TECHNOLOGYTYPE_NON_3G":"4G"},
	{"SITE_ID":5068105,"AREA_ID":4565,"FUZE_SITE_ID":5068105,"NAME":"CLIO - RELO - A","STATUS":"Primary","ADDRESS":"298 County Road 15 ","CITY":"Clio","STATE":"AL","COUNTY":"Barbour","ZIPCODE":"36017","LATITUDE":42.355111,"LONGITUDE":-71.415420,"SITE_TYPE":"MACRO","GRANITE_SITE_ID":5068105,"PSLC":"165847","AREA_NAME":"1005","FIBER_STATUS":"","RADIO_STATUS":"","SECTOR_TRIGGER":"","MPT_SITETYPE":"MACRO","IS_5G":0,"LOCAL_MARKET":"309#Southern AL/GA\r","MARKET":"","ENODEBGRPLOGIC":""},
	{"SITE_ID":680636,"AREA_ID":4565,"FUZE_SITE_ID":680636,"FUZE_SECTORS":"1,2,3","NAME":"CLIO","STATUS":"Live","ADDRESS":"County Hwy 15 1.3Mi S. of Clio","CITY":"Clio","STATE":"AL","COUNTY":"Barbour","ZIPCODE":"36017","LATITUDE":42.36413,"LONGITUDE":-71.025424,"LOCATIONNAME":"CLIO|CLIO|CLIO|CLIO|CLIO|CLIO","SITE_TYPE":"MACRO","GRANITE_SITE_ID":680636,"PSLC":"165847","AREA_NAME":"1005","FIBER_STATUS":"","RADIO_STATUS":"","SECTOR_TRIGGER":"","MPT_SITETYPE":"MACRO","IS_5G":0,"ENODEBS":"170536","LOCAL_MARKET":"309#Southern AL/GA\r","ATOLL_SCHEMA_NAME":"Atlanta","MARKET":"170","ENODEBGRPLOGIC":"[170][680636]","TECHNOLOGYTYPE":"4G","TECHNOLOGYTYPE_3G":"1xEV-DO,1xRTT","TECHNOLOGYTYPE_NON_3G":"4G","CELL":"536"},
	{"SITE_ID":680636,"AREA_ID":4565,"FUZE_SITE_ID":680636,"FUZE_SECTORS":"1,2,3","NAME":"CLIO","STATUS":"Live","ADDRESS":"County Hwy 15 1.3Mi S. of Clio","CITY":"Clio","STATE":"AL","COUNTY":"Barbour","ZIPCODE":"36017","LATITUDE":41.3713,"LONGITUDE":-71.0351424,"LOCATIONNAME":"CLIO","SITE_TYPE":"MACRO","GRANITE_SITE_ID":680636,"PSLC":"165847","AREA_NAME":"1005","FIBER_STATUS":"","RADIO_STATUS":"","SECTOR_TRIGGER":"","MPT_SITETYPE":"MACRO","IS_5G":0,"ENODEBS":"170536","LOCAL_MARKET":"309#Southern AL/GA\r","ATOLL_SCHEMA_NAME":"Atlanta","MARKET":"170","ENODEBGRPLOGIC":"170-536","TECHNOLOGYTYPE":"1xEV-DO","TECHNOLOGYTYPE_3G":"1xEV-DO,1xRTT","TECHNOLOGYTYPE_NON_3G":"4G","CELL":"536"},
	{"SITE_ID":616570065,"AREA_ID":4565,"FUZE_SITE_ID":616570065,"NAME":"BILLY WATSON HWY - A","STATUS":"Primary","ADDRESS":"4807 Hwy 51 South","CITY":"Ariton","STATE":"AL","COUNTY":"Barbour","ZIPCODE":"36311","LATITUDE":42.4404966,"LONGITUDE":-71.415465,"SITE_TYPE":"MACRO","GRANITE_SITE_ID":616570065,"PSLC":"593919","AREA_NAME":"1005","FIBER_STATUS":"","RADIO_STATUS":"","SECTOR_TRIGGER":"","MPT_SITETYPE":"MACRO","IS_5G":0,"LOCAL_MARKET":"309#Southern AL/GA\r","MARKET":"","ENODEBGRPLOGIC":""},
	{"SITE_ID":5036958,"AREA_ID":4565,"FUZE_SITE_ID":5036958,"FUZE_SECTORS":"1,2,3","NAME":"BRENDEN","STATUS":"Live","ADDRESS":"County Road 33","CITY":"Clio","STATE":"AL","COUNTY":"Barbour","ZIPCODE":"36017","LATITUDE":42.35498,"LONGITUDE":-71.8115185,"LOCATIONNAME":"BRENDEN - A|BRENDEN - A|BRENDEN - A|BRENDEN - A|BRENDEN - A|BRENDEN - A|BRENDEN - A","SITE_TYPE":"MICRO","GRANITE_SITE_ID":5036958,"AREA_NAME":"1005","FIBER_STATUS":"","RADIO_STATUS":"","SECTOR_TRIGGER":"","MPT_SITETYPE":"MICRO","IS_5G":0,"ENODEBS":"170370","LOCAL_MARKET":"309#Southern AL/GA\r","ATOLL_SCHEMA_NAME":"Atlanta","MARKET":"170","ENODEBGRPLOGIC":"[170][5036958]","TECHNOLOGYTYPE":"4G","TECHNOLOGYTYPE_NON_3G":"4G"},
	{"SITE_ID":5068105,"AREA_ID":4565,"FUZE_SITE_ID":5068105,"NAME":"CLIO - RELO - A","STATUS":"Primary","ADDRESS":"298 County Road 15 ","CITY":"Clio","STATE":"AL","COUNTY":"Barbour","ZIPCODE":"36017","LATITUDE":42.504711,"LONGITUDE":-71.015420,"SITE_TYPE":"MACRO","GRANITE_SITE_ID":5068105,"PSLC":"165847","AREA_NAME":"1005","FIBER_STATUS":"","RADIO_STATUS":"","SECTOR_TRIGGER":"","MPT_SITETYPE":"MACRO","IS_5G":0,"LOCAL_MARKET":"309#Southern AL/GA\r","MARKET":"","ENODEBGRPLOGIC":""},
	{"SITE_ID":680636,"AREA_ID":4565,"FUZE_SITE_ID":680636,"FUZE_SECTORS":"1,2,3","NAME":"CLIO","STATUS":"Live","ADDRESS":"County Hwy 15 1.3Mi S. of Clio","CITY":"Clio","STATE":"AL","COUNTY":"Barbour","ZIPCODE":"36017","LATITUDE":42.42413,"LONGITUDE":-71.515424,"LOCATIONNAME":"CLIO|CLIO|CLIO|CLIO|CLIO|CLIO","SITE_TYPE":"MACRO","GRANITE_SITE_ID":680636,"PSLC":"165847","AREA_NAME":"1005","FIBER_STATUS":"","RADIO_STATUS":"","SECTOR_TRIGGER":"","MPT_SITETYPE":"MACRO","IS_5G":0,"ENODEBS":"170536","LOCAL_MARKET":"309#Southern AL/GA\r","ATOLL_SCHEMA_NAME":"Atlanta","MARKET":"170","ENODEBGRPLOGIC":"[170][680636]","TECHNOLOGYTYPE":"4G","TECHNOLOGYTYPE_3G":"1xEV-DO,1xRTT","TECHNOLOGYTYPE_NON_3G":"4G","CELL":"536"},
	{"SITE_ID":680636,"AREA_ID":4565,"FUZE_SITE_ID":680636,"FUZE_SECTORS":"1,2,3","NAME":"CLIO","STATUS":"Live","ADDRESS":"County Hwy 15 1.3Mi S. of Clio","CITY":"Clio","STATE":"AL","COUNTY":"Barbour","ZIPCODE":"36017","LATITUDE":42.64713,"LONGITUDE":-72.4151424,"LOCATIONNAME":"CLIO","SITE_TYPE":"MACRO","GRANITE_SITE_ID":680636,"PSLC":"165847","AREA_NAME":"1005","FIBER_STATUS":"","RADIO_STATUS":"","SECTOR_TRIGGER":"","MPT_SITETYPE":"MACRO","IS_5G":0,"ENODEBS":"170536","LOCAL_MARKET":"309#Southern AL/GA\r","ATOLL_SCHEMA_NAME":"Atlanta","MARKET":"170","ENODEBGRPLOGIC":"170-536","TECHNOLOGYTYPE":"1xEV-DO","TECHNOLOGYTYPE_3G":"1xEV-DO,1xRTT","TECHNOLOGYTYPE_NON_3G":"4G","CELL":"536"},
	{"SITE_ID":616570065,"AREA_ID":4565,"FUZE_SITE_ID":616570065,"NAME":"BILLY WATSON HWY - A","STATUS":"Primary","ADDRESS":"4807 Hwy 51 South","CITY":"Ariton","STATE":"AL","COUNTY":"Barbour","ZIPCODE":"36311","LATITUDE":42.664066,"LONGITUDE":-71.915465,"SITE_TYPE":"MACRO","GRANITE_SITE_ID":616570065,"PSLC":"593919","AREA_NAME":"1005","FIBER_STATUS":"","RADIO_STATUS":"","SECTOR_TRIGGER":"","MPT_SITETYPE":"MACRO","IS_5G":0,"LOCAL_MARKET":"309#Southern AL/GA\r","MARKET":"","ENODEBGRPLOGIC":""},
	{"SITE_ID":5036958,"AREA_ID":4565,"FUZE_SITE_ID":5036958,"FUZE_SECTORS":"1,2,3","NAME":"BRENDEN","STATUS":"Live","ADDRESS":"County Road 33","CITY":"Clio","STATE":"AL","COUNTY":"Barbour","ZIPCODE":"36017","LATITUDE":42.05528,"LONGITUDE":-71.415185,"LOCATIONNAME":"BRENDEN - A|BRENDEN - A|BRENDEN - A|BRENDEN - A|BRENDEN - A|BRENDEN - A|BRENDEN - A","SITE_TYPE":"MICRO","GRANITE_SITE_ID":5036958,"AREA_NAME":"1005","FIBER_STATUS":"","RADIO_STATUS":"","SECTOR_TRIGGER":"","MPT_SITETYPE":"MICRO","IS_5G":0,"ENODEBS":"170370","LOCAL_MARKET":"309#Southern AL/GA\r","ATOLL_SCHEMA_NAME":"Atlanta","MARKET":"170","ENODEBGRPLOGIC":"[170][5036958]","TECHNOLOGYTYPE":"4G","TECHNOLOGYTYPE_NON_3G":"4G"},
	{"SITE_ID":5068105,"AREA_ID":4565,"FUZE_SITE_ID":5068105,"NAME":"CLIO - RELO - A","STATUS":"Primary","ADDRESS":"298 County Road 15 ","CITY":"Clio","STATE":"AL","COUNTY":"Barbour","ZIPCODE":"36017","LATITUDE":42.756111,"LONGITUDE":-71.315420,"SITE_TYPE":"MACRO","GRANITE_SITE_ID":5068105,"PSLC":"165847","AREA_NAME":"1005","FIBER_STATUS":"","RADIO_STATUS":"","SECTOR_TRIGGER":"","MPT_SITETYPE":"MACRO","IS_5G":0,"LOCAL_MARKET":"309#Southern AL/GA\r","MARKET":"","ENODEBGRPLOGIC":""},
	{"SITE_ID":680636,"AREA_ID":4565,"FUZE_SITE_ID":680636,"FUZE_SECTORS":"1,2,3","NAME":"CLIO","STATUS":"Live","ADDRESS":"County Hwy 15 1.3Mi S. of Clio","CITY":"Clio","STATE":"AL","COUNTY":"Barbour","ZIPCODE":"36017","LATITUDE":42.446453,"LONGITUDE":-71.115424,"LOCATIONNAME":"CLIO|CLIO|CLIO|CLIO|CLIO|CLIO","SITE_TYPE":"MACRO","GRANITE_SITE_ID":680636,"PSLC":"165847","AREA_NAME":"1005","FIBER_STATUS":"","RADIO_STATUS":"","SECTOR_TRIGGER":"","MPT_SITETYPE":"MACRO","IS_5G":0,"ENODEBS":"170536","LOCAL_MARKET":"309#Southern AL/GA\r","ATOLL_SCHEMA_NAME":"Atlanta","MARKET":"170","ENODEBGRPLOGIC":"[170][680636]","TECHNOLOGYTYPE":"4G","TECHNOLOGYTYPE_3G":"1xEV-DO,1xRTT","TECHNOLOGYTYPE_NON_3G":"4G","CELL":"536"},
	{"SITE_ID":680636,"AREA_ID":4565,"FUZE_SITE_ID":680636,"FUZE_SECTORS":"1,2,3","NAME":"CLIO","STATUS":"Live","ADDRESS":"County Hwy 15 1.3Mi S. of Clio","CITY":"Clio","STATE":"AL","COUNTY":"Barbour","ZIPCODE":"36017","LATITUDE":41.95713,"LONGITUDE":-72.1151424,"LOCATIONNAME":"CLIO","SITE_TYPE":"MACRO","GRANITE_SITE_ID":680636,"PSLC":"165847","AREA_NAME":"1005","FIBER_STATUS":"","RADIO_STATUS":"","SECTOR_TRIGGER":"","MPT_SITETYPE":"MACRO","IS_5G":0,"ENODEBS":"170536","LOCAL_MARKET":"309#Southern AL/GA\r","ATOLL_SCHEMA_NAME":"Atlanta","MARKET":"170","ENODEBGRPLOGIC":"170-536","TECHNOLOGYTYPE":"1xEV-DO","TECHNOLOGYTYPE_3G":"1xEV-DO,1xRTT","TECHNOLOGYTYPE_NON_3G":"4G","CELL":"536"},
	{"SITE_ID":616570065,"AREA_ID":4565,"FUZE_SITE_ID":616570065,"NAME":"BILLY WATSON HWY - A","STATUS":"Primary","ADDRESS":"4807 Hwy 51 South","CITY":"Ariton","STATE":"AL","COUNTY":"Barbour","ZIPCODE":"36311","LATITUDE":42.2904966,"LONGITUDE":-71.115465,"SITE_TYPE":"MACRO","GRANITE_SITE_ID":616570065,"PSLC":"593919","AREA_NAME":"1005","FIBER_STATUS":"","RADIO_STATUS":"","SECTOR_TRIGGER":"","MPT_SITETYPE":"MACRO","IS_5G":0,"LOCAL_MARKET":"309#Southern AL/GA\r","MARKET":"","ENODEBGRPLOGIC":""},
	{"SITE_ID":5036958,"AREA_ID":4565,"FUZE_SITE_ID":5036958,"FUZE_SECTORS":"1,2,3","NAME":"BRENDEN","STATUS":"Live","ADDRESS":"County Road 33","CITY":"Clio","STATE":"AL","COUNTY":"Barbour","ZIPCODE":"36017","LATITUDE":42.28598,"LONGITUDE":-71.2115185,"LOCATIONNAME":"BRENDEN - A|BRENDEN - A|BRENDEN - A|BRENDEN - A|BRENDEN - A|BRENDEN - A|BRENDEN - A","SITE_TYPE":"MICRO","GRANITE_SITE_ID":5036958,"AREA_NAME":"1005","FIBER_STATUS":"","RADIO_STATUS":"","SECTOR_TRIGGER":"","MPT_SITETYPE":"MICRO","IS_5G":0,"ENODEBS":"170370","LOCAL_MARKET":"309#Southern AL/GA\r","ATOLL_SCHEMA_NAME":"Atlanta","MARKET":"170","ENODEBGRPLOGIC":"[170][5036958]","TECHNOLOGYTYPE":"4G","TECHNOLOGYTYPE_NON_3G":"4G"},
	{"SITE_ID":5068105,"AREA_ID":4565,"FUZE_SITE_ID":5068105,"NAME":"CLIO - RELO - A","STATUS":"Primary","ADDRESS":"298 County Road 15 ","CITY":"Clio","STATE":"AL","COUNTY":"Barbour","ZIPCODE":"36017","LATITUDE":42.204911,"LONGITUDE":-71.015420,"SITE_TYPE":"MACRO","GRANITE_SITE_ID":5068105,"PSLC":"165847","AREA_NAME":"1005","FIBER_STATUS":"","RADIO_STATUS":"","SECTOR_TRIGGER":"","MPT_SITETYPE":"MACRO","IS_5G":0,"LOCAL_MARKET":"309#Southern AL/GA\r","MARKET":"","ENODEBGRPLOGIC":""},
	{"SITE_ID":680636,"AREA_ID":4565,"FUZE_SITE_ID":680636,"FUZE_SECTORS":"1,2,3","NAME":"CLIO","STATUS":"Live","ADDRESS":"County Hwy 15 1.3Mi S. of Clio","CITY":"Clio","STATE":"AL","COUNTY":"Barbour","ZIPCODE":"36017","LATITUDE":42.32413,"LONGITUDE":-71.315424,"LOCATIONNAME":"CLIO|CLIO|CLIO|CLIO|CLIO|CLIO","SITE_TYPE":"MACRO","GRANITE_SITE_ID":680636,"PSLC":"165847","AREA_NAME":"1005","FIBER_STATUS":"","RADIO_STATUS":"","SECTOR_TRIGGER":"","MPT_SITETYPE":"MACRO","IS_5G":0,"ENODEBS":"170536","LOCAL_MARKET":"309#Southern AL/GA\r","ATOLL_SCHEMA_NAME":"Atlanta","MARKET":"170","ENODEBGRPLOGIC":"[170][680636]","TECHNOLOGYTYPE":"4G","TECHNOLOGYTYPE_3G":"1xEV-DO,1xRTT","TECHNOLOGYTYPE_NON_3G":"4G","CELL":"536"},
	{"SITE_ID":680636,"AREA_ID":4565,"FUZE_SITE_ID":680636,"FUZE_SECTORS":"1,2,3","NAME":"CLIO","STATUS":"Live","ADDRESS":"County Hwy 15 1.3Mi S. of Clio","CITY":"Clio","STATE":"AL","COUNTY":"Barbour","ZIPCODE":"36017","LATITUDE":42.273426025,"LONGITUDE":-71.11545333,"LOCATIONNAME":"CLIO","SITE_TYPE":"MACRO","GRANITE_SITE_ID":680636,"PSLC":"165847","AREA_NAME":"1005","FIBER_STATUS":"","RADIO_STATUS":"","SECTOR_TRIGGER":"","MPT_SITETYPE":"MACRO","IS_5G":0,"ENODEBS":"170536","LOCAL_MARKET":"309#Southern AL/GA\r","ATOLL_SCHEMA_NAME":"Atlanta","MARKET":"170","ENODEBGRPLOGIC":"170-536","TECHNOLOGYTYPE":"1xEV-DO","TECHNOLOGYTYPE_3G":"1xEV-DO,1xRTT","TECHNOLOGYTYPE_NON_3G":"4G","CELL":"536"}
	
	]

var candidateSelectionResponse = {
	"marketIdentifier": "NewEnglandEast",
	"projectId": 16448474,
	"fuzeSiteId": 32323,
	"region": "New England ",
	"status": "Active",
	"parentSolutionId": 1052303,
	"projectName": "16448474",
	"CandidateSelectionData": [
				{
					"createdBy": "Ahmed, Elhussein",
				    "createdOn": "03/23/2021 14:13",
					"candidate_id": 10,
					"fuze_site_id": 4565,
					"site_name":"0720 ALTON_NH (STA-0000)",
					"latitude": 42.2534260251946,
					"longitude": -71.0154533,
					"hub_location": "AUSTIN" ,
					"releaseState_cost": 313,
					"equipment_cost":223,
					"fiber_cost":432,
					"rationale": "",
					"score":5
				},
				{
					"createdBy": "Ahmed, Elhussein",
					"createdOn": "03/23/2021 14:13",
					"status": "active",
					"candidate_id": 12,
					"fuze_site_id": 4565,
					"site_name":"0230 Sayre OK (STA-0000)",
					"latitude": 44.382531,
					"longitude": -70.003769,
					"hub_location": "AUSTIN" ,
					"releaseState_cost": 313,
					"equipment_cost":223,
					"fiber_cost":432,
					"rationale": "",
					"score":5
				}
	]
}			
	
