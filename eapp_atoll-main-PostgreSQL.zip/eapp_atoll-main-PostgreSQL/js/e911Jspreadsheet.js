var emptyDataSource = new kendo.data.DataSource({
	data: [],
});
var siteAutoAjax;
var leaf;
var leafCompare;
var initZoom = 4;
var t = XYZ.map();
var google_api_key = "AIzaSyBCDhGdiIbpa3jV-e7xuhwPfvJUUDZJNN8";
var attributionLeaf = "<span id='attributionSpanLeaf'>Cursor out of map bounds</span>";
var attributionCompare = "<span id='attributionSpanCompare'>Cursor out of map bounds</span>";
var satellite_url = 'http://netgeo.vh.eng.vzwcorp.com/arcgis/rest/services/basemap_webmer/World_Imagery/MapServer/tile/{z}/{y}/{x}';
var grayscale_url = 'http://netgeo.vh.eng.vzwcorp.com/arcgis/rest/services/basemap_webmer/World_Topo_Map/MapServer/tile/{z}/{y}/{x}'
var streetmap_url = 'http://netgeo.vh.eng.vzwcorp.com/arcgis/rest/services/basemap_webmer/World_Street_Map/MapServer/tile/{z}/{y}/{x}';
var satellite_url = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
var grayscale_url = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}'
var streetmap_url = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}';
var multiplier = 1.0;
var disableZoom = 20;
var selectedDrawnGeom;
var computativeZoneGeom;
var popupDivTag;
var selectedFileType = '';
var splitClusters = null;
var plotLayersArr = new Map();
var sectorLayerArr = new Map();
var sourceplotLayersArr = new Map();
var destplotLayersArr = new Map();
//var plotLayersArrCompare = new Map();
var colorMapping = new Map();
var transmitterMap = new Map();
var transmitterMapCompare = new Map();
var rloplLayerGroup;
var rloplleftLayerGroup;
var rloplLayerGroupCompare;
var tileOptions = { maxZoom: 19, minZoom: 2, opacity: .2, attribution: attributionLeaf, stamp: Date.now };
var tileOptionsCompare = { maxZoom: 19, minZoom: 2, opacity: .2, attribution: attributionCompare, stamp: Date.now };
var clusterOptions = { maxRad: 1900, disableZoom: disableZoom, splitClusters: splitClusters };
var current_url = streetmap_url;
var defaultPageSize = 10;
var featureSectorGroup = null;
var editableLayers = null;
var featureGroupCompare = null;
var featureleftSectorGroup = null;
var comptransmitterGrid = null;
var compcellInfoGridInstance = null;
var analyticsGrid = null;
var comptAnalyticsGrid = null;
var createRev = false;
var tileLayers = new Map();
var tileLayersRight = new Map();
var marketLayers = new Map();
var marketLayersRight = new Map();
var vectorLayers = {};
var vectorLayersRight = {};
var marketOpacities = {};
var tileOpacities = {};
var filterInfo = {};
var polygonsInfo = {};
var layerInfoFromUISetting = [];
var tileLayersInitialized = false;
var wavePolygonList = [];
var peaPolygons = {};
var peapol = [];
var qmarketList = [];
var vectorTileLayerStyles = {};
var selectedCoverageType;
var selectedThreshold;
var selectedCoverageTypeFilter;
var selectedThresholdFilter;
var isUniqueRevisionName;
var uniqueRevisionName;
var onMapTransGrid;
var uploadedKmlHistory = [];
var selectedTxId = [];
var selectedTransmitterRows = new Set();

var transCellTypeSourceList = [
	"Macro",
	"C-RAN Macro",
	"Macro Fronthaul",
	"Macro Midhaul",
	"Outdoor Small Cell",
	"C-RAN Small Cell",
	"Small Cell Fronthaul",
	"Small Cell Midhaul",
	"In-Building Small Cell",
	"Outdoor DAS",
	"C-RAN DAS",
	"In-Building DAS",
	"E-RAN",
	"Medium" ];
var dlOnlyChannelList = ["Yes", "No"];


var svg_site_color = {
	svg_site_without_fuze_site_id: "#fa4632",
	svg_site_with_fuze_site_id: "#4ec8fc"
};
var site_fuze_site_id_status = {
	"without-fuze-site-id": "#fa4632",
	"with-fuze-site-id": "#4ec8fc"
};
var stype_map = {
	"OTHER": {
		name: "pentagon",
		shape: '<polygon points="2,7 7,2 12,7 9,12 5,12" stroke-width="1" stroke="#000" stroke-opacity="1" fill="{fill}" fill-opacity="1" />'
	},
	"MACRO": {
		name: "circle",
		shape: '<circle cx="7" cy="7" r="5" stroke-width="1" stroke="#000" stroke-opacity="1" fill="{fill}" fill-opacity="1"/>'
	},
	"SMALL-CELL": {
		name: "diamond",
		shape: '<polygon points="1,7 7,1 13,7 7,13" stroke-width="1" stroke="#000" stroke-opacity="1" fill="{fill}" fill-opacity="1" />'
	},
	"SC/ODAS": {
		name: "hexagon",
		shape: '<polygon points="3,5 7,2 11,5 11,9 7,12 3,9" stroke-width="1" stroke="#000" stroke-opacity="1" fill="{fill}" fill-opacity="1" />'
	},
	"INBLD": {
		name: "rectangle",
		shape: '<rect x="3" y="3" width="10" height="10" stroke-width="1" stroke="#000" stroke-opacity="1" fill="{fill}" fill-opacity="1"/>'
	}
};
var wo_split = CONTEXT_PATH + '/uui/espresso/static/planning_pg/css/images/layout_icons/split-icon-rotated-small.png';
var wo_map = CONTEXT_PATH + '/uui/espresso/static/planning_pg/css/images/layout_icons/map-icon-small.png';
var wo_tab = CONTEXT_PATH + '/uui/espresso/static/planning_pg/css/images/layout_icons/tabular-icon-small.png';
var bestviewrent = CONTEXT_PATH + '/uui/espresso/static/planning_pg/css/images/bestviewrent.png';

var split = CONTEXT_PATH + '/uui/espresso/static/planning_pg/css/images/layout_icons/split-icon-rotated-small-color.png';
var map = CONTEXT_PATH + '/uui/espresso/static/planning_pg/css/images/layout_icons/map-icon-small-color.png';
var tab = CONTEXT_PATH + '/uui/espresso/static/planning_pg/css/images/layout_icons/tabular-icon-small-color.png';

var transmitterGrid = null;
var cellInfoGridInstance = null;
var currentCardInstance = null;
var transmitterInfoGridModelSchemaDefinition = {};
var cellInfoGridModelSchemaDefinition = {};
var analyticGridModelSchemaDefinition = {};

var intialBounds = {};
var currentYear = new Date().getFullYear();
var snSectors = [];
var isFinalised = false;

var revisionDropDownOpen = false;
var pin;
var uploadedKmlLayer = null;
var geoJson = null;
var uploadedPolygon;
var selectedZone;
var preSelectedZone = "";
var fzwsID = '';
var parentSolId;
var spmPID;
var prevIds = null;
var transData1 = [];
var mySpreadsheet1;
var sitesInfo;
var sitesInfoPayLoad;
var fetchCoordinates = {};
var routerParams = {};
var selectedtransmitterMap = new Map();
var ecgincgi =[];
var dynamicTransimittertablecolumns = [
	
	{ type: 'checkbox', title: 'Action', width: 80 },
	{ name: 'ecgincgi', type: 'text', title: 'ECGI/NCGI', width: 100, readOnly: true,},
	{ name: 'siteName', type: 'text', title: 'Site', width: 100, readOnly: true },
	{ name: 'transCellType', type: 'dropdown', title: 'Trans Cell Type', width: 100,source : transCellTypeSourceList, readOnly: false },
	{ name: 'fBand', type: 'text', title: 'Frequency Band', width: 100, readOnly: true },
	{ name: 'dlOnlyChannel', type: 'dropdown', title: 'DL Only Channel', width: 100,source : dlOnlyChannelList, readOnly: false },
	{ name: 'fiveGsector', type: 'text', title: '5G Sector', width: 100, readOnly: true },
	{ name: 'lteSector', type: 'text', title: 'LTE Sector', width: 100, readOnly: true },
	{ name: 'gNBId', type: 'text', title: 'gNB ID', width: 100, readOnly: true },
	{ name: 'eNBUd', type: 'text', title: 'eNB ID', width: 100, readOnly: true },
	{ name: 'baseMarketId', type: 'text', title: 'Base Market ID', width: 100, readOnly: true },
	{ name: '', type: 'checkbox', title: 'Use Absolute Coordinates' },
	{ name: 'latitude', type: 'text', title: 'Lattitude', width: 100, readOnly: false },
	{ name: 'longitude', type: 'text', title: 'Longitude', width: 100, readOnly: false },
	{ name: 'antennaModel', type: 'text', title: 'Antenna', width: 100, readOnly: true },
	{ name: 'antennaHBwDeg', type: 'text', title: 'Antenna H-BW (deg)', width: 100, readOnly: true },
	{ name: 'antennaVBwDeg', type: 'text', title: 'Antenna V-BW (deg)', width: 100, readOnly: true },
	{ name: 'azimuthDeg', type: 'text', title: 'Azimuth', width: 100, readOnly: true },
	{ name: 'transmitterTilt', type: 'text', title: 'Mechanical Downtilt', width: 100, readOnly: true },
	{ name: 'antennaCenterlineft', type: 'text', title: 'Centerline Fit', width: 100, readOnly: true },
	{ name: 'latitude', type: 'text', title: 'E-911 Latitude Degrees (NAD83)', width: 100, readOnly: true },
	{ name: 'longitude', type: 'text', title: 'E-911 Longitude Degrees (NAD83)', width: 100, readOnly: true },
	{ name: 'streetAddress', type: 'text', title: 'E-911 Street Address', width: 100, readOnly: false },
	{ name: 'city', type: 'text', title: 'E-911 City', width: 100, readOnly: false },
	{ name: 'state', type: 'text', title: 'E-911 State', width: 300, readOnly: false },
	{ name: 'county', type: 'text', title: 'E-911 County', width: 100, readOnly: false },
	{ name: 'zipcode', type: 'number', title: 'E-911 Zip Code', width: 100, readOnly: false },
	{ name: 'dispatchableLocation', type: 'number', title: 'E-911 Dispatchable Location', width: 100, readOnly: false },
	{ name: 'txId', type: 'number', title: 'TxId', width: 100, readOnly: true },
	{ name: 'siteNumber', type: 'hidden', title: 'TxId', width: 100, readOnly: true},


	{ name: '', type: 'hidden', title: '', width: 100, readOnly: false },
	{ name: '', type: 'hidden', title: '', width: 100, readOnly: false },
	{ name: '', type: 'hidden', title: '', width: 100, readOnly: false },
	{ name: '', type: 'hidden', title: '', width: 100, readOnly: false },
	{ name: '', type: 'hidden', title: '', width: 100, readOnly: false },
	{ name: '', type: 'hidden', title: '', width: 100, readOnly: false },
	{ name: '', type: 'hidden', title: '', width: 100, readOnly: false },
	{ name: '', type: 'hidden', title: '', width: 100, readOnly: false },
	{ name: '', type: 'hidden', title: '', width: 100, readOnly: false },
	{ name: '', type: 'hidden', title: '', width: 100, readOnly: false },
	{ name: '', type: 'hidden', title: '', width: 100, readOnly: false },
	{ name: '', type: 'hidden', title: '', width: 100, readOnly: false },
	{ name: '', type: 'hidden', title: '', width: 100, readOnly: false },
	{ name: '', type: 'hidden', title: '', width: 100, readOnly: false },
	{ name: '', type: 'hidden', title: '', width: 100, readOnly: false },





];
var TERRITORY_DUMP = [];
var AREA_DUMP = [];
var REGION_DUMP = [];
var MARKET_DUMP = [];
var mySpreadsheet1;
var marketsDataProvider;
var entireMarketList;
var marketsMapping = {};
var isParamPresentInUrl = false;

/*Document Ready*/
$(document).ready(function () {

	try {
		var env = window.location.href.includes('canvasple') ? '-PLE' : '';
        window.initClickstream({
            "system_name": "Network Planning Platform",
            "app_name": "ATOLL" + env,
            "screen_name": "E911 Submit Tool",
            "showLogs" : "true"
        });
    } catch(e) {
        return false;
    }

	if (Object.keys(featureToggleMap).includes("F90711") && featureToggleMap['F90711']) {
		$('#isNotCommonSchemaSearch').hide();
		$('#commonE911ReportSchemaSearch').show();
		
		commonSchemaSearch('commonE911ReportSchemaSearch');
	} else {
		$('#isNotCommonSchemaSearch').show();
		$('#commonE911ReportSchemaSearch').hide();
		
	}
	var spreadsheetTransmitter = 'transmitterInfoGridMain';
	creatingJSpreadsheete911(dynamicTransimittertablecolumns, spreadsheetTransmitter);
	$('#marketDropdown').append('<option id="selectMarket" >Select Market</option>');
	document.getElementById("selectMarket").disabled = true;
	
	initMap();
	loadDumpVariables();
	
	if (Object.keys(featureToggleMap).includes("F90711") && featureToggleMap['F90711']) {
		if (window.location.href.includes("?")) {
			(localStorage.getItem('atollSchema')) ? routerParams.atollSchema = localStorage.getItem('atollSchema') : '';
			console.log("atollSchemaLocal", routerParams.atollSchema);
			console.log(window.location.href);
			let url = window.location.href;
			let splitUrl = url.split("?");
			let params = (splitUrl[1]) ? splitUrl[1].split('&') : [];
			console.log(params);
			params.forEach(element => {
				if (element) {
					var obj = {};
					var a = element.split("=");
					if (a.length > 0) {
						obj[a[0]] = a[1];
						routerParams = { ...obj, ...routerParams };
					}
				}
			});
			if (routerParams) {
                isParamPresentInUrl = true;
            }
			routerParams["siteVersion"] = (routerParams.siteVersion) ? routerParams.siteVersion.split(",") : [];
			console.log(routerParams);
			if (routerParams.projectNumber) {
                getDataUsingProjectNumber(routerParams.projectNumber);
				updateSiteVersionDropdown(routerParams.projectNumber, 'commonE911ReportSchemaSearch');
				routerParams.siteVersion = $('#' + 'commonE911ReportSchemaSearch' + 'VersionList').val();
				if (routerParams.siteVersion != null) {
					routerParams.siteVersion = [routerParams.siteVersion[0].split(" ")[0]];
					atollSchemaCommonSearch('commonE911ReportSchemaSearch', routerParams.atollSchema, routerParams.fuzeSiteId, routerParams.siteVersion, 'e911Jspreadsheet');
				}
            } else if (routerParams.siteRecordId) {
                getDataUsingSiteRecordId(routerParams.siteRecordId);
            } else {
                setTimeout(() => {
                    atollSchemaCommonSearch('commonE911ReportSchemaSearch', routerParams.atollSchema, routerParams.fuzeSiteId, routerParams.siteVersion, 'e911Jspreadsheet');
                }, 200);
            }
		}
	}
});

function getDataUsingSiteRecordId(siteRecordId) {
    $.ajax({
        //url: 'http://localhost:8100/npp-atoll-services/atollUtility/fetchSchemaAndFuzeSiteIdBySiteRecordId?siteRecordId=' + siteRecordId,
        url: fetchSchemaAndFuzeSiteIdBySiteRecordIdURL + siteRecordId,
        dataType: 'json',
        type: "POST",
        async: false,
        success: function(projectData) {
            console.log('roles Data ===>', projectData);
            routerParams.fuzeSiteId = projectData.VZ_SITE_INFO_ID;
            routerParams.atollSchema = projectData.ATOLL_SCHEMA;
            atollSchemaCommonSearch('commonE911ReportSchemaSearch', routerParams.atollSchema, routerParams.fuzeSiteId, routerParams.siteVersion, 'e911Jspreadsheet');
        },
        error: function(data) {
            aptAlert('Warning', 'Failed to load data!');
        }
    });
}
function getDataUsingProjectNumber(projectNumber) {
    $.ajax({
        //url: 'http://localhost:8100/npp-atoll-services/atollUtility/fetchSchemaAndFuzeSiteIdByProjectNumber?projectNumber=' + projectNumber,
        url: fetchSchemaAndFuzeSiteIdByProjectNumberURL + projectNumber,
        dataType: 'json',
        type: "POST",
        async: false,
        success: function(projectData) {
            console.log('roles Data ===>', projectData);
            routerParams.fuzeSiteId = projectData.data[0].fuzeSiteIdList[0];
            routerParams.atollSchema = projectData.data[0].schema;
            atollSchemaCommonSearch('commonE911ReportSchemaSearch', routerParams.atollSchema, routerParams.fuzeSiteId, routerParams.siteVersion, 'e911Jspreadsheet');
        },
        error: function(data) {
            aptAlert('Warning', 'Failed to load data!');
        }
    });
}





var leafInControl = false;
var leafCompareInControl = false;

function initMap() {

	L.CursorHandler = L.Handler.extend({

		addHooks: function () {
			this._popup = new L.Popup();
			this._map.on('mouseover', this._open, this);
			this._map.on('mousemove', this._update, this);
			this._map.on('mouseout', this._close, this);
		},

		removeHooks: function () {
			this._map.off('mouseover', this._open, this);
			this._map.off('mousemove', this._update, this);
			this._map.off('mouseout', this._close, this);
		},

		_open: function (e) {
			leafInControl = true;
			this._update(e);
		},

		_close: function (e) {
			$('#attributionSpanLeaf').text("Zoom Level: " + this._map.getZoom() + " Coordinates: " + parseFloat(e.latlng.lat).toFixed(5) + ", " + parseFloat(e.latlng.lng).toFixed(5));
			leafInControl = false;
		},

		_update: function (e) {
			$('#attributionSpanLeaf').text("Zoom Level: " + this._map.getZoom() + " Coordinates: " + parseFloat(e.latlng.lat).toFixed(5) + ", " + parseFloat(e.latlng.lng).toFixed(5));
		}
	});

	L.Map.addInitHook('addHandler', 'cursor', L.CursorHandler);
	leaf = t.initialize("map", {
		"zoomPos": 'topright',
		"clusterPie": false,
		"cursor": true,
		"tileOptions": tileOptions,
		"clusterOptions": clusterOptions,
		"stamp": "?_={stamp}",
		'url': current_url,
		'resourcePath': CONTEXT_PATH + '/uui/espresso/static',
		"legendPos": "bottomleft"
	})._map;
	leaf.cursor.enable();
	L.control.scale({ position: "bottomleft" }).addTo(leaf);

	t.setEdgeAttr(XYZ.ATTR.EDGE_AGGR_TEXT | XYZ.ATTR.EDGE_TEXT | XYZ.ATTR.EDGE_AGGR_POPUP);
	t.setMode(XYZ.MODE.STATIC);

	googleRoadMutant = L.gridLayer.googleMutant({ maxZoom: 24, type: 'roadmap' });
	//googleTerrainMutant  = L.gridLayer.googleMutant({maxZoom: 24,type:'terrain'});
	googleRoadMutant.addTo(leaf);

	leaf.on('moveend', function () {
		let text = $('#attributionSpanLeaf').text();
		//console.log('coordinates:-', text);
		text = text.slice(0, 12) + leaf.getZoom() + " " + text.slice(14, text.length);
		$('#attributionSpanLeaf').text(text);
		if (viewType == "CompareView" && leafInControl) {
			leafCompare.flyTo(leaf.getCenter(), leaf.getZoom());
		}
		enableMapZoom();
	});

	leaf.on('moveend', function () {
		//console.log("In Zoom loaded");
		var zoom = leaf.getZoom();
		let multiplier1 = 1;
		if (zoom <= 1) {
			multiplier1 = .1;
		} else if (zoom <= 2) {
			multiplier1 = .2;
		} else if (zoom <= 3) {
			multiplier1 = .3;
		} else if (zoom <= 4) {
			multiplier1 = .4;
		} else if (zoom <= 5) {
			multiplier1 = .5;
		} else if (zoom <= 6) {
			multiplier1 = .6;
		} else if (zoom <= 7) {
			multiplier1 = .7;
		} else if (zoom <= 9) {
			multiplier1 = .9;
		} else if (zoom <= 11) {
			multiplier1 = .8;
		} else if (zoom <= 15) {
			multiplier1 = 1;
		} else {
			multiplier1 = 1.25
		}
		if (viewType != "CompareView") {
			for (let i = 0; i < snSectors.length; i++) {
				let sn = snSectors[i].sn;
				let sector = snSectors[i].sector;
				sn.marker.setIcon(new L.divIcon({
					iconSize: [100 * multiplier1, 100 * multiplier1],
					popupAnchor: [0, 0],
					className: "transparent-background vpi-sector-icon",
					html: sector
				}));
			}
		}
		if ($(".selectedDataTables").css("display") != "none") {
			markTransmittersOnMap();
		}
	});

	//enableDrawingPolygon();



	function hideDropdown() {
		$(".multiselect-native-select").children().removeClass("open");
	}

	L.DivIcon.SVGIcon.include({
		initialize: function (options) {
			options = L.Util.setOptions(this, options)

			//iconSize needs to be converted to a Point object if it is not passed as one
			options.iconSize = L.point(options.iconSize)

			//in addition to setting option dependant defaults, Point-based options are converted to Point objects
			if (!options.circleAnchor) {
				options.circleAnchor = L.point(Number(options.iconSize.x) / 2, Number(options.iconSize.x) / 2)
			}
			else {
				options.circleAnchor = L.point(options.circleAnchor)
			}
			if (!options.circleColor) {
				options.circleColor = options.color
			}
			if (!options.circleFillOpacity) {
				options.circleFillOpacity = options.opacity
			}
			if (!options.circleOpacity) {
				options.circleOpacity = options.opacity
			}
			if (!options.circleWeight) {
				options.circleWeight = options.weight
			}
			if (!options.fillColor) {
				options.fillColor = options.color
			}
			if (!options.fontSize) {
				options.fontSize = Number(options.iconSize.x / 4)
			}
			if (!options.iconAnchor) {
				options.iconAnchor = L.point(Number(options.iconSize.x) / 2, Number(options.iconSize.y) / 2)
			}
			else {
				options.iconAnchor = L.point(options.iconAnchor)
			}
			if (!options.popupAnchor) {
				options.popupAnchor = L.point(0, 0)
			}
			else {
				options.popupAnchor = L.point(options.popupAnchor)
			}

			var path = this._createPath()
			var circle = this._createCircle()

			options.html = this._createSVG()
		},
		_createSVG: function () {
			var path = this._createPath();
			var circle = this._createCircle();
			var text = this._createText();
			var img = this._createImage();
			var className = this.options.className + "-svg";

			var style = "width:" + this.options.iconSize.x + "; height:" + this.options.iconSize.y + ";";

			var svg = '<svg xmlns="http://www.w3.org/2000/svg" version="1.1" class="' + className + '" style="' + style + '">' + path + circle + text + img + '</svg>';

			return svg;
		},
		_createPath: function () {
			var pathDescription = this._createPathDescription();
			var strokeWidth = this.options.weight
			var stroke = this.options.color
			var strokeOpacity = this.options.Opacity
			var fill = this.options.fillColor
			var fillOpacity = this.options.fillOpacity
			var className = this.options.className + "-path"
			var height = Number(this.options.iconSize.y)
			var width = Number(this.options.iconSize.x)
			var r = (width - strokeWidth - 8) / 2;
			var h = width - strokeWidth - 8;
			var hr = (width - 2) / 2;
			var hh = width - 2;
			var path = "";
			if (this.options.definedPath) {
				path = this.options.definedPath
					.split("{stroke}").join(stroke)
					.split("{fill}").join(fill);
			}
			else if (this.options.shape === "rectangle") {
				if (this.options.highlight) path += '<rect class="rect-highlight" x="' + ((width / 2) - hr) + '" y="' + ((height / 2) - hr) + '" width="' + hh + '" height="' + hh + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1"/>';
				path += '<rect class="' + className + '" x="' + ((width / 2) - r) + '" y="' + ((height / 2) - r) + '" width="' + h + '" height="' + h + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '"/>';
			}
			else if (this.options.shape === "rhombus") {
				if (this.options.highlight) path += '<rect class="rect-highlight" x="8.5" y="-8.5" width="' + (hh - 5) + '" height="' + (hh - 5) + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1" transform="rotate(45)"/>';
				path += '<rect class="' + className + '" x="' + (this.options.iconSize.x === 24 ? 11 : 9) + '" y="' + (this.options.iconSize.y === 24 ? -6 : -5) + '" width="' + (h - 2) + '" height="' + (h - 2) + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '" transform="rotate(45)"/>';
			}
			else if (this.options.shape === "inverted_triangle") {
				if (this.options.highlight) path += '<polygon points="' + '2,2 ' + (width - 2) + ',2 ' + (width / 2) + ',' + (height - 2) + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1" />';
				path += '<polygon points="' + (this.options.iconSize.x === 24 ? 7 : 5) + ',' + (this.options.iconSize.y === 24 ? 7 : 5) + ' ' + (this.options.iconSize.x === 24 ? width - 6 : width - 5) + ',' + (this.options.iconSize.y === 24 ? 7 : 5) + ' ' + (width / 2) + ',' + (height - 5) + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '" />';
			}
			else if (this.options.shape === "triangle") {
				if (this.options.highlight) path += '<polygon points="' + (width / 2) + ',2 ' + (width - 2) + ',' + (height - 2) + ' 2,' + (height - 2) + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1" />';
				path += '<polygon points="' + (width / 2) + ',' + (this.options.iconSize.y === 24 ? 7 : 5) + ' ' + (this.options.iconSize.y === 24 ? width - 6 : width - 5) + ',' + (height - 5) + ' ' + (this.options.iconSize.y === 24 ? 7 : 5) + ',' + (height - 5) + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '" />';
			}
			else if (this.options.shape === "trapezoid") {
				if (this.options.highlight) path += '<polygon points="6,2 ' + (width - 6) + ',2 ' + (width - 2) + ',' + (height - 2) + ' 2,' + (height - 2) + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1" />';
				path += '<polygon points="8,5 ' + (width - 8) + ',5 ' + (width - 5) + ',' + (height - 5) + ' 5,' + (height - 5) + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '" />';
			}
			else if (this.options.shape === "pentagon") {
				if (this.options.highlight) path += '<polygon points="2,' + (height / 2) + ' ' + (width / 2) + ',2 ' + (width - 2) + ',' + (height / 2) + ' ' + (width - 5) + ',' + (height - 2) + ' 5,' + (height - 2) + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1" />';
				path += '<polygon points="4,' + ((height / 2) - 1) + ' ' + (width / 2) + ',4 ' + (width - 4) + ',' + ((height / 2) - 1) + ' ' + (width - 7) + ',' + (height - 4) + ' 7,' + (height - 4) + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '" />';
			}
			else if (this.options.shape === "hexagon") {
				if (this.options.highlight) path += '<polygon points="2,' + (height / 2) + ' 6,2 ' + (width - 6) + ',2 ' + (width - 2) + ',' + (height / 2) + ' ' + (width - 6) + ',' + (height - 2) + ' 6,' + (height - 2) + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1" />';
				path += '<polygon points="5,' + ((height / 2) - 3) + ' ' + (width / 2) + ',4 ' + (width - 5) + ',' + ((height / 2) - 3) + ' ' + (width - 5) + ',' + ((height / 2) + 3) + ' ' + (width / 2) + ',' + (height - 4) + ' 5,' + ((height / 2) + 3) + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '" />';
			}
			else if (this.options.shape === "circle") {
				if (this.options.highlight) path += '<circle class="circle-highlight" cx="' + (width / 2) + '" cy="' + (height / 2) + '" r="' + hr + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1"/>';
				path += '<circle class="' + className + '" cx="' + (width / 2) + '" cy="' + (height / 2) + '" r="' + r + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '"/>';
			}
			else if (this.options.shape === "diamond") {
				if (this.options.highlight) path += '<rect class="rect-highlight" x="8.5" y="-8.5" width="' + (hh - 5) + '" height="' + (hh - 5) + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1" transform="rotate(45)"/>';
				path += '<rect class="' + className + '" x="' + (this.options.iconSize.x === 24 ? 11 : 9) + '" y="' + (this.options.iconSize.y === 24 ? -6 : -5) + '" width="' + (h - 2) + '" height="' + (h - 2) + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '" transform="rotate(45)"/>';
			}
			else {
				path += '<path class="' + className + '" d="' + pathDescription + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '"/>';
			}
			return path;
		},
		_createCircle: function () {
			var cx = Number(this.options.circleAnchor.x)
			var cy = Number(this.options.circleAnchor.y)
			var radius = (this.options.iconSize.x - 8) / 2 * Number(this.options.circleRatio)
			var fill = this.options.circleFillColor
			var fillOpacity = this.options.circleFillOpacity
			var stroke = this.options.circleColor
			var strokeOpacity = this.options.circleOpacity
			var strokeWidth = this.options.circleWeight
			var className = this.options.className + "-circle"

			var circle = '<circle class="' + className + '" cx="' + cx + '" cy="' + cy + '" r="' + radius +
				'" fill="' + fill + '" fill-opacity="' + fillOpacity +
				'" stroke="' + stroke + '" stroke-opacity=' + strokeOpacity + '" stroke-width="' + strokeWidth + '"/>'

			return circle
		},
		_createImage: function () {
			if (!this.options.img) return "";
			var x = this.options.img.x;
			var y = this.options.img.y;
			var height = this.options.img.height + "px";
			var width = this.options.img.width + "px";
			var url = this.options.img.url;

			var text = "<image xlink:href='" + url + "' x='" + x + "' y='" + y + "' width='" + width + "' height='" + height + "' />";

			return text;
		},
		_createText: function () {
			var fontSize = this.options.fontSize + "px"
			var lineHeight = Number(this.options.fontSize)

			var x = Number(this.options.iconSize.x) / 2
			var y = x + (lineHeight * 0.35) //35% was found experimentally 
			var circleText = this.options.circleText;
			if (!circleText) return "";
			var textColor = this.options.fontColor.replace("rgb(", "rgba(").replace(")", "," + this.options.fontOpacity + ")")

			var text = '<text text-anchor="middle" x="' + x + '" y="' + y + '" style="font-size: ' + fontSize + '" fill="' + textColor + '">' + circleText + '</text>'

			return text;
		}


	});

	for (var j in stype_map) {
		for (const i in site_fuze_site_id_status) {
			t.addIcon("svg_site_mpt_" + j + "_" + i, L.divIcon.svgIcon({
				circleRatio: 0,
				circleFillColor: "#ffffff",
				fillOpacity: 1,
				opacity: 1,
				shape: stype_map[j].name,
				iconSize: [22, 22],
				color: "#000000",
				fillColor: site_fuze_site_id_status[i],
				popupAnchor: [0, -15],
				weight: 1
			}));
		}
	}

	//initiateJStree1();
	featureSectorGroup = L.featureGroup().addTo(leaf);
	rloplLayerGroup = L.featureGroup().addTo(leaf);
	leaf.on('dragend', function (e) {
		$('<style id="vpisectorstyle">div.vpi-sector-icon {pointer-events: none !important;}</style>').appendTo("head");
	});

	leaf.on("zoomstart", function () {
		oldzoom = leaf.getZoom();
	});

	editableLayers = new L.FeatureGroup();
	leaf.addLayer(editableLayers);
	popupDivTag = $(".popupSiteInfo")[0];
	var drawPluginOptions = {
		position: 'topright',
		draw: {
			polyline: {
				shapeOptions: {
					color: '#f357a1',
					weight: 10
				}
			},
			polygon: {
				allowIntersection: false, // Restricts shapes to simple polygons
				drawError: {
					color: '#e1e100', // Color the shape will turn when intersects
					message: '<strong>Polygon draw does not allow intersections!<strong> (allowIntersection: false)' // Message that will show when intersect
				},
				shapeOptions: {
					color: '#bada55'
				}
			},
			polygon: true,
			polyline: false,
			circlemarker: false,
			marker: false,
			circle: false, // Turns off this drawing tool
			rectangle: true,
		},
		edit: {
			featureGroup: editableLayers, //REQUIRED!!
			remove: true
		}
	};

	// Initialise the draw control and pass it the FeatureGroup of editable layers
	var drawControl = new L.Control.Draw(drawPluginOptions);
	leaf.addControl(drawControl);

	
	$(".leaflet-draw-edit-edit").css('display', 'none');
	//$(".leaflet-draw-edit-remove").removeClass('leaflet-disabled');


	leaf.on('draw:created', function (e) {
		var SelectedZone1 = $('#selectedZone').val();
		var zoom1 = leaf.getZoom();
		if (!SelectedZone1) {
			errorAlert("Error", "<p> Please select Zone </p>.");
		} else if (preSelectedZone != "" && preSelectedZone == SelectedZone1) {
			errorAlert("Error", "<p> Please select different Zone </p>.");
		}
		else {
			if (zoom1 >= 12) {
				$(".leaflet-draw-edit-remove").removeClass('leaflet-disabled');
				var type = e.layerType,
					layer = e.layer;
				filterPolygon();
				e.layer.bindPopup(popupDivTag);
				$(".popupSiteInfo").css('display', 'block');

				if ($('#selectedZone').val() === 'Computation') {
					var popup = "<div class='popupComputativeInfo' style='padding: 0px;text-align: center;'>"
						+ "<button style='width: 160px;' class='btn btn-danger btn-sm dummy' onclick='showFilterCoverages(true)'>"
						+ "Generate Coverages"
						+ "</button></div>";
					computativeZoneGeom = e.layer.toGeoJSON().geometry;
					e.layer.bindPopup(popup);
					//$(".popupSiteInfo").css('display', 'block');
				} else {
					preSelectedZone = e.layer.toGeoJSON().geometry;
					e.layer.bindPopup(popupDivTag);
					$(".popupSiteInfo").css('display', 'block');
				}

				editableLayers.addLayer(layer);
				e.layer.openPopup();
				selectedDrawnGeom = e.layer.toGeoJSON().geometry;
				//preSelectedZone = SelectedZone1;
				if (preSelectedZone && computativeZoneGeom) {
					var requestjson = {
						"originalGeom": JSON.stringify(preSelectedZone),
						"drawnGeom": JSON.stringify(computativeZoneGeom)
					};
					$.ajax({
						url: CONTEXT_PATH + '/uui/eapp/atoll_pg/getComputativeCoverage',
						type: 'POST',
						contentType: 'application/json',
						data: JSON.stringify(requestjson),
						success: function (data) {
							if (!data[0].geom) {
								errorAlert('Error', 'Please draw the computative zone with in the filter zone');
							}
						}, error: function (response) {
							errorAlert('Error', 'Error occured in finalization');
							$('#loading').hide();
						}
					});
				}
			} else {
				errorAlert("Error", "<p> Please draw the polygon above the zoom level 12</p>.");
			}
		}
	});

	leaf.on('draw:deletestop', function (e) {
		preSelectedZone = "";
		computativeZoneGeom = "";

		if (uploadedKmlLayer) {
			// leaf.removeLayer(uploadedKmlLayer);
			// uploadedKmlLayer.clearLayers();
		}
		editableLayers.clearLayers();
		$(".selectedSiteInfoPanel").css("display", "none");
		$(".selectedDataTables").css("display", "none");
	})
}


function enableMapZoom() {
	leaf.dragging.enable();
	leaf.doubleClickZoom.enable();
	leaf.scrollWheelZoom.enable();
	leaf.boxZoom.enable();
	leaf.keyboard.enable();
	if (leafCompare) {
		leafCompare.dragging.enable();
		leafCompare.doubleClickZoom.enable();
		leafCompare.scrollWheelZoom.enable();
		leafCompare.boxZoom.enable();
		leafCompare.keyboard.enable();
	}

}









var plotColors = {};

function getRandomColor() {
	var letters = '0123456789ABCDEF';
	var color = '#';
	for (var i = 0; i < 6; i++) {
		color += letters[Math.floor(Math.random() * 16)];
	}
	return color;
}


function getDistinctValues(arr) {
	var result = arr.filter(function (a) {
		var key = a.VZ_SECTOR + '|' + a.AZIMUT + '|' + a.SITE_ID;
		if (!this[key]) {
			this[key] = true;
			return true;
		}
	}, Object.create(null));
	//console.log(result);
	return result;
}

var sectorCount = [];
function getCountOfDuplicate(result) {
	var current = {};
	var count = 0;
	var keyValue;
	for (var i = 0; i < result.length; i++) {
		if (!current[result[i].SITE_ID]) {
			if (count > 0) {
				sectorCount.push({
					key: keyValue,
					count: count
				});
			}
			current[result[i].SITE_ID] = true;
			keyValue = result[i].SITE_ID;
			count = 1;
		} else {
			count++;
		}
	}
	if (sectorCount > 0) {
		sectorCount.push({
			key: keyValue,
			count: count
		});
	}
}




function drawTransmitter(data, id, sectorLayer) {
	if (transmitterMap.size) {
		transmitterMap.forEach(function (index, value) {
			if (leaf.hasLayer(transmitterMap.get(value)))
				leaf.removeLayer(transmitterMap.get(value));
		});

	}
	//data = data && data: [];
	var elist = [];
	
	var sitename = data[0] ? data[0].SITE_NAME : "";
	if (leaf.getZoom() <= 6) {
		multiplier = .6;
	} else if (leaf.getZoom() <= 10) {
		multiplier = .75;
	} else if (leaf.getZoom() <= 15) {
		multiplier = 1;
	} else {
		multiplier = 1.25
	}
	var count = 0.0;
	var sectorsData = {};

	$.each(data, function (i, v) {
		if (!sectorsData[i]) {
			sectorsData[i] = {};
			sectorsData[i].ABS_X = v.ABS_X;
			sectorsData[i].ABS_Y = v.ABS_Y;
			sectorsData[i].BANDStr = v.FBAND;
			sectorsData[i].SECTOR = v.VZ_SECTOR;
			sectorsData[i].VZ_LTE_MAX_POWER = v.VZ_LTE_MAX_POWER;
			sectorsData[i].AZIMUT = v.AZIMUT;
			sectorsData[i].TX_ID = v.TX_ID;
			sectorsData[i].FUZE_SITE_ID = v.SITE_ID;
			sectorsData[i].SITE_NAME = v.SITE_NAME;
			sectorsData[i].TILT = v.TILT;
			var result = sectorCount.filter(function (a) {
				if (v.SITE_ID == a.key) { return a }
			}, Object.create(null));
			sectorsData[i].SECTOR_COUNT = (result && result[0]) ? result[0].count : 0;
			sectorsData[i].band = [];
			count++;
		}
		//sectorsData[i].BANDStr += sectorsData[i].BANDStr == "" ? v.FBAND : ";" + v.FBAND;
		sectorsData[i].band.push(v);
	});


	

	var degree = 45;
	// var azimuth = 0;
	for (var i in sectorsData) {
		var uid = name + ":" + i;
		//verisonTxMap[name] = verisonTxMap[name] ? verisonTxMap[name] : [];
		//console.log
		/*if(sectorsData[i].FUZE_SITE_ID != 0){
			debugger;
			return false;			
		}*/

		var azlist = [];
		//if (!transmitterNodeList["sect_" + uid]) {
		var sector = '<svg viewBox="0 0 160 160" height="100%" width="100%" className="vpi-sector-container" style="pointer-events: none;">';
		var color = getRandomColor();//"#00ac3e";
		$.each(sectorsData[i].band, function (j, v1) {
			var radius = 10 + ((69 / (sectorsData[i].band.length)) * (sectorsData[i].band.length - j));
			//if (verisonTxMap[name].indexOf(uid) < 0) {
			//   verisonTxMap[name].push("sect_" + uid);
			//}

			var azimuth = v1.AZIMUT;

			if (azlist.indexOf(azimuth) < 0) azlist.push(azimuth);
			var bd = v1.FBAND;
			var txid = v1.TX_ID;
			//var siteName = v1.SITE_NAME;
			var sect = v1.VZ_SECTOR;
			/*var degree = 180 / sectorsData[i].SECTOR_COUNT;
			if (360 === degree || 0 === degree) {
				degree = 359.9
			}*/
			//transmitterIdBandMap[name] = transmitterIdBandMap[name] ? transmitterIdBandMap[name] : {};
			//transmitterIdBandMap[name][sect] = transmitterIdBandMap[name][sect] ? transmitterIdBandMap[name][sect] : {};
			//transmitterIdBandMap[name][sect][bd] = v1;


			const x0 = 80, y0 = 80;
			const th0 = (azimuth - 90) * (Math.PI / 180);
			const half_width = (degree / 2) * (Math.PI / 180);
			const thA = th0 + half_width, thB = th0 - half_width;
			const xA = x0 + radius * Math.cos(thA), yA = y0 + radius * Math.sin(thA);
			const xB = x0 + radius * Math.cos(thB), yB = y0 + radius * Math.sin(thB);
			var r2 = 10 + ((69 / (sectorsData[i].band.length)) * (sectorsData[i].band.length - j - 1));
			const xAi = x0 + r2 * Math.cos(thA), yAi = y0 + r2 * Math.sin(thA);
			const xBi = x0 + r2 * Math.cos(thB), yBi = y0 + r2 * Math.sin(thB);
			var txr = (radius + r2) * 0.5;
			var txa = (thA + (thB < thA ? thB : thB + Math.PI * 2)) * 0.5;
			var txx = x0 + Math.cos(txa) * txr;
			var txy = y0 + Math.sin(txa) * txr;
			var opac = current_url === satellite_url ? 0.9 : 0.6;
			sector += '<g style="pointer-events: auto;" class="sector ' + sectorsData[i].FUZE_SITE_ID + "-" + sectorsData[i].SECTOR
				+ '" value="' + txid + '"><path '
				+ 'class=""'
				+ 'd="M ' + xA + ' ' + yA + ' A ' + radius + ' ' + radius + ' ' + th0 + ' ' + (180 < degree ? 1 : 0) + ' 0 ' + xB + ' ' + yB + ' L ' + xBi + ' ' + yBi + ' A ' + r2 + ' ' + r2 + ' ' + th0 + ' ' + (180 <= degree ? 1 : 0) + ' 1 ' + xAi + ' ' + yAi + ' L ' + xA + ' ' + yA + '"' + 'stroke="' + '#00ff00' + '" '
				+ 'stroke-width="2" '
				+ 'fill="' + color + '" fill-opacity=0.8 '
				+ 'className="antenna-sector" '
				+ '><title>Transmitter Id: ' + txid + '| Sector: ' + sect + ' | Band:' + bd + '</title></path>'
				+ '<text x="' + txx + '" y="' + txy + '" >' + bd + '</text></g>';
		});
		sector += '</svg>';
		azlist.sort();
		var markerOptions = {
			isSector: true,
			isVpi: true,
			txId : sectorsData[i].TX_ID,
			azimuth : sectorsData[i].AZIMUT,
			sector : sectorsData[i].SECTOR,
			siteNumber : sectorsData[i].FUZE_SITE_ID,
		};
		var popup = "<div style='background:white;width:100%'>"
			+ "<h4>" + sectorsData[i].SITE_NAME + "</h4>"
			+ "<div class='popup-inner' style='border: 1px solid #d7d7d7;background: #f7f7f7;padding:5px 20px;'>"
			+ "<div><div class='halfdiv'><h5>Sector</h5></div><div class='halfdiv' style='margin-top: 7px;'>" + sectorsData[i].SECTOR + "</div></div>"
			+ "<div><div class='halfdiv'><h5>Band</h5></div><div class='halfdiv' id='txtBand' style='margin-top: 7px;'>" + sectorsData[i].BANDStr + "</div></div>"
			+ "<div><div class='halfdiv'><h5>Azimuth</h5></div><div class='halfdiv' style='margin-top: 7px;'>" + sectorsData[i].AZIMUT + "</div></div>"
			+ "<div><div class='halfdiv'><h5>Tilt</h5></div><div class='halfdiv' id='txtBand' style='margin-top: 7px;'>" +sectorsData[i].TILT + "</div></div>"
			+ "<button style='width: 150px;height: 20px;min-height: 32px;' class='btn btn-danger btn-sm dummy' hidden onclick='addDataToGrid(" + '"' + sectorsData[i].TX_ID + '"' + ")'>Mark as Edited</button>"
			+ "</div>";
		//circleMarker.bindPopup(popup);
		var sn = XYZ.node("sect_" + uid, Number(sectorsData[i].ABS_X), Number(sectorsData[i].ABS_Y), {
			icon: "svg_site_mpt_MACRO",
			markerOptions: markerOptions,
			tooltip: {
				options: {
					direction: "bottom",
					className: "nitro-tooltip",
					sticky: true,
					permanent: false
				}
			},
			popup: {
				html: popup
			}
		});
		snSectors.push({
			'sn': sn,
			'sector': sector
		});
		//transmitterNodeList["sect_" + uid] = sn;
		try {
			sn.marker.setIcon(new L.divIcon({
				iconSize: [100 * multiplier, 100 * multiplier],
				popupAnchor: [0, 0],
				className: "transparent-background vpi-sector-icon",
				html: sector
			}));


			transmitterMap.set(sectorsData[i].TX_ID, sn.marker);
			sectorLayer.addLayer(sn.marker);
			// disable the dragging for the sector pie
			//sn.marker.dragging.disable();

			sn.marker.on('dragend', function (e) {
				console.log(e);
				fetchCoordinates = e.target.getLatLng();
				//e.target.setLatLng(new L.LatLng(fetchCoordinates.lat, fetchCoordinates.lng), { draggable: 'true' });
				console.log('fetchCoordinates:-', fetchCoordinates);
				var spreadsheetLength = $("#transmitterInfoGridMain tbody tr").length;
for(let i =1; i<=spreadsheetLength; i++){
	let azimutFromSheet = parseInt($("#transmitterInfoGridMain table tbody tr:nth-child("+i+") td:nth-child(19)").text());
	let SectorFromSheet = parseInt($("#transmitterInfoGridMain table tbody tr:nth-child("+i+") td:nth-child(9)").text());
	let siteIdFromSheet = ($("#transmitterInfoGridMain table tbody tr:nth-child("+i+") td:nth-child(31)").text()==''? null : parseInt($("#transmitterInfoGridMain table tbody tr:nth-child("+i+") td:nth-child(31)").text()));
	

	if(azimutFromSheet==e.target.azimuth && SectorFromSheet == e.target.sector && siteIdFromSheet == e.target.siteNumber){
				$("#transmitterInfoGridMain table tbody tr:nth-child("+i+") td:nth-child(14)").text(fetchCoordinates.lat);
				$("#transmitterInfoGridMain table tbody tr:nth-child("+i+") td:nth-child(15)").text(fetchCoordinates.lng);
				$("#transmitterInfoGridMain table tbody tr:nth-child("+i+") td:nth-child(22)").text(fetchCoordinates.lat);
				$("#transmitterInfoGridMain table tbody tr:nth-child("+i+") td:nth-child(23)").text(fetchCoordinates.lng);
	}
}
			});

		} catch (err) {
		}
	}
}




var viewType = "CoverageView";
function getMapView(e) {
	if (e.id === "compareIcon" || e.id === "compareIconTab") {
		$(".mainView").css("height", "100%");
		$("#compareIcon").show();
		$("#coverageIcon").show();
		disabledSchemaEditing();
		viewType = 'CompareView';
		if ($('.overlay-view').length > 0) {
			$('.overlay-view').remove();
		}
		if ($('.layerlist').length > 0) {
			$('.layerlist').remove();
		}
		$("#comparemap .leaflet-control-container").append("<div id='layersIcon' class='button-container layerlist leaflet-bar leaflet-control' style='background-color: white;4px;cursor: pointer;float: right;margin-top: 80px;margin-right: 11px;'><a onclick='openPopup(this)' class='leaflet-control-dropdown-layer fas fa-layer-group'></a></div>");
		closeAllPanel();
		showCompareView();


		$("#mapModal").css("height", "550px");

		tileLayersInitialized = true;
		$("#restToPerviousVersionBtn").hide();
		$("#saveAndCreateNewVersionBtn").hide();
		$("#finalizeDesign").hide();
		$("#layerWindowLeft").hide();
		$(".header-tabs").hide();
	} else if (e.id === "coverageIcon" || e.id === "coverageIconTab") {
		if (!isFinalised) {
			enableSchemaEditing();
		}

		$(".header-tabs").show();

		$("#selectCoverageType").show();
		$("#selectThreshold").show();

		viewType = 'CoverageView';
		if ($('.layerlist').length > 0) {
			$('.layerlist').remove();
		}
		$("#map .leaflet-control-container").append("<div id='layersIcon' class='button-container layerlist leaflet-bar leaflet-control' style='background-color: white;cursor: pointer;float: right;margin-top: 204px;margin-right: 9px;'><a onclick='openPopup(this)' class='leaflet-control-dropdown-layer fas fa-layer-group'></a></div>");


		showCoveragView();
		//enableDropdowns();
		DropdownChange();

		$("#restToPerviousVersionBtn").show();
		$("#saveAndCreateNewVersionBtn").show();
		if (!isFinalised) {
			$("#finalizeDesign").show();
		}

		$("#layerWindowLeft").hide();
		removeAnalyticsStyle(e.id);
		$(".mainView").css("height", "86vh");
		$("#mapViewMain").click();

	} else {
		disabledSchemaEditing();
		//$(".button-container").remove();		
		if ($("#overlayIcon").hasClass("overlay_icon_selected")) {
			$('#overlayIcon').addClass('overlay_icon').removeClass('overlay_icon_selected');
			splitView();
			viewType = 'CompareView';
			$("#rightcoverage-tab").attr('class', 'active');
			$("#rightcoverageTab").attr('class', 'tab-pane active');
		} else {
			viewType = 'OverlayView';
			$('#overlayIcon').addClass('overlay_icon_selected').removeClass('overlay_icon');
			if ($("#rightcoverage-tab").hasClass("active")) {
				$("#rightcoverage-tab").removeClass("active");
			}
			if ($("#rightcoverageTab").hasClass("active")) {
				$("#rightcoverageTab").removeClass("active");
			}
			fullView();
		}
		ShowRevisionComparision();
		if ($("#transmitterInfoGrid thead input:checkbox").prop("checked")) {
			$("#transmitterInfoGrid thead input:checkbox").trigger("click");
		}
		$("#layerWindowLeft").hide();
	}

	setTimeout(function () {
		if (rloplleftLayerGroup.getBounds().isValid()) {
			leafCompare.fitBounds(rloplleftLayerGroup.getBounds());
		}

		if (rloplLayerGroup.getBounds().isValid()) {
			leaf.fitBounds(rloplLayerGroup.getBounds());
		}
	}, 1100);

}




function markTransmittersOnMap() {
	var sectors = $(".sector");
	for (var i = 0; i < sectors.length; i++) {
		sectors[i].style.opacity = 0.3;
	}

	var sectClsLst = [];
	for (var data in selectedTransmitters) {
		var sectCls = "." + selectedTransmitters[data].fuze_site_id + "-" + selectedTransmitters[data].sector;
		if (!sectClsLst.includes(sectCls)) {
			sectClsLst.push(sectCls);
			var sectGrp = $(sectCls);
			sectGrp[0].style.opacity = 1;
			sectGrp[0].children[0].style.stroke = "red";
			sectGrp[0].children[0].style.strokeWidth = "4px";
			sectGrp[0].children[0].style.fillOpacity = 1;
		}
	}
}






var selectedTransmitters = [];
function setUpSelectedSitesPanelFunctionality() {

	initSelectedTransmitterDataGrid();
	initSelectedCellInfoDataGrid();
	initSelectedTransSiteInfoDataGrid();
}

function initSelectedTransmitterDataGrid() {
	selectedTransmitterInfoPanel.setDataSource(
		new kendo.data.DataSource({
			pageSize: 8,
			data: [],
			schema: {
				model: {
					fields: {
						transmitter_name: { editable: false },
						sector: { editable: false },
						azimuth: { type: "number" },
						antenna_centerline: { type: "number" },
						electrical_tilt: { type: "number" },
						number_of_tx_antenna_ports: { type: "number" },
						number_of_rx_antenna_ports: { type: "number" },
						max_power: { editable: false },
						antenna_model: { editable: false },
						mechanical_tilt: { type: "number" },
						radio_model: { type: "string" }
					}
				}
			}
		})
	);
}

function initSelectedCellInfoDataGrid() {
	selectedCellInfoPanel.setDataSource(
		new kendo.data.DataSource({
			pageSize: 8,
			data: [],
			schema: {
				model: {
					fields: {
						transmitter_name: { editable: false },
						cell_id: { editable: false },
						trans_cell_type: { editable: false },
						band: { editable: false },
						band_class: { editable: false },
						band_info: { editable: false },
						channel_bw: { editable: false },
						channel_number: { editable: false },
						enodeb_eutrancellfdd: { editable: false }
					}
				}
			}
		})
	);
}

function initSelectedTransSiteInfoDataGrid() {
	selectedTransSiteInfoPanel.setDataSource(
		new kendo.data.DataSource({
			pageSize: 8,
			data: [],
			schema: {
				model: {
					fields: {
						transmitter_name: { editable: false },
						fuze_site_id: { editable: false },
						site_record_name: { editable: false },
						site_version: { editable: false },
						city: { editable: false },
						network_market: { editable: false },
						network_local_market: { editable: false },
						network_territory: { editable: false },
						site_record_id: { editable: false },
						technology: { editable: false }
					}
				}
			}
		})
	);
}

var atollList;
$('#marketDropdown').change(function () {
	atollList = $('#marketDropdown').val();
	console.log('atollList', atollList);
});

var getsampleData = [];
function searchSiteNameAndVersion() {
	getsampleData = [];
	$("#transmitterInfoGridMain").html("");
	editableLayers.clearLayers();
	if (Object.keys(featureToggleMap).includes("F90711") && featureToggleMap['F90711']) {
		spreadsheetTransmitter = 'transmitterInfoGridMain';
		console.log(commonSchemaSearchPayload);
		atollList = commonSchemaSearchPayload.atollSchema;
		getsiteName =  commonSchemaSearchPayload.siteName;
		getsiteVersion = commonSchemaSearchPayload.siteVersion;
	} else {
		var spreadsheetTransmitter = 'transmitterInfoGridMain';
		var getsiteName = document.getElementById('siteName').value;   //Macro  , uno_testing
		var getsiteVersion =[];
		getsiteVersion.push(document.getElementById('siteVersion').value);  //RING, eb17
	}	
	e911PayLoad = {
			"marketNumber": atollList,
			"siteName": getsiteName,
			"siteVersion": getsiteVersion
	}
	if(e911PayLoad.marketNumber == undefined  || e911PayLoad.siteName == '' || e911PayLoad.siteName == undefined || (!(Object.keys(featureToggleMap).includes("F90711") && featureToggleMap['F90711']) && e911PayLoad.siteVersion == '')) {
		alert("Please Select All the Mandatory Dropdowns");
		getsampleData = [];
		var spreadsheetTransmitter = 'transmitterInfoGridMain';
				creatingJSpreadsheete911(dynamicTransimittertablecolumns, spreadsheetTransmitter);
	} else {
		$.ajax({
			type: 'POST',
			async: false,
			url: fetchTransmittersBySiteNameAndVersionURL,
			//url: "http://localhost:8100/npp-atoll-services/atollUtility/fetchTransmittersBySiteNameAndVersion",
			dataType: 'json',
			data: JSON.stringify(e911PayLoad),
			contentType: 'application/json; charset=UTF-8',
			cache: false,
			success: function (data) {
				$('#loading').show();
				
				for (var k = 0; k < data.length; k++) {

					if (data[k].ecgi != null) {
						ecgincgi = data[k].ecgi;
					} else if (data[k].ncgi != null) {
						ecgincgi = data[k].ncgi;
					} else {
						ecgincgi = null;
					}
					var payload = {

						"marketSid":  data[k].baseMarketId,
						"switchNumber":  data[k].switchNumber,
						"switchName": data[k].switchName,
						"siteName": data[k].siteName,
						"siteNumber": data[k].siteNumber,
						"siteVersion": data[k].siteVersion,
						"txId":  data[k].txId,
						"vzChannel": data[k].vzChannel,
						"latitude": data[k].latitude,
						"longitude":data[k].longitude,
						"streetAddress": data[k].streetAddress,
						"city":  data[k].city,
						"county": data[k].county,
						"state": data[k].state,
						"zipcode": data[k].zipcode,
						"dispatchableLocation": data[k].dispatchableLocation,
						"sector": data[k].sector,
						"azimuthDeg": data[k].azimuthDeg,
						"antennaModel": data[k].antennaModel,
						"antennaManufacturer": data[k].antennaManufacturer,
						"antennaMaxGainDbd":data[k].antennaMaxGainDbd,
						"antennaHBwDeg":data[k].antennaHBwDeg,
						"antennaCenterlineft": data[k].antennaCenterlineft,
						"transmitterTilt": data[k].transmitterTilt,
						"technology": data[k].technology,
						"pilotErpW": data[k].pilotErpW,
						"lteTotalEIRPE": data[k].lteTotalEIRPE,
						"mcc": data[k].mcc,
						"mnc": data[k].mnc,
						"ecgincgi": ecgincgi,
						"bandClass": data[k].bandClass,
						"lteMarket": data[k].lteMarket,
						"enodeBSiteName": data[k].enodeBSiteName,
						"transCellType": data[k].transCellType,
						"antennaEnvironment": data[k].antennaEnvironment,
						"avgSectorRadius": data[k].avgSectorRadius,
						"dlOnlyChannel":  data[k].dlOnlyChannel,
						"fiveGsector":  data[k].fiveGsector,
						"lteSector":  data[k].lteSector,
						"gNBId":  data[k].gNBId,
						"eNBUd": data[k].eNBUd
					};
					getsampleData.push(payload);
				}
				creatingJSpreadsheete911(dynamicTransimittertablecolumns, spreadsheetTransmitter);
				var transData = [];
				for (let i = 0; i < getsampleData.length; i++) {
					var markerOptions = {
						"LATITUDE": getsampleData[i].latitude,
						"LONGITUDE": getsampleData[i].longitude,
						"SITENAME": getsampleData[i].siteName,
						"Technology": getsampleData[i].technology
	
					};
					var flag = "with-fuze-site-id";
					var icon = "svg_site_mpt_" + "MACRO" + "_" + flag;
					var circleMarker = 
						L.marker([Number(markerOptions.LATITUDE), Number(markerOptions.LONGITUDE)], {
							icon: XYZ._icon_map[icon],
							markerOptions: markerOptions,
	
						});
					editableLayers.addLayer(circleMarker);
					leaf.setView(new L.LatLng(Number(markerOptions.LATITUDE), Number(markerOptions.LONGITUDE)), 20);
					var popup = "<div class='selectedFilterZoneSitePopup' style='background:white;'>"
						+ "<h4>" + markerOptions.SITENAME + "</h4>"
						+ "<div class='popup-inner' style='border:1px solid #d7d7d7;background: #f7f7f7; margin-bottom:10px; padding:0 5px;'>"
						+ "<div><div class='halfdiv'><h5>Technology Info</h5></div><div class='halfdiv'>" + markerOptions.Technology + "</div></div>"
						+ "</div>"
						+ "<div><button id='chooseTransToEditBtn' onclick='chooseTransmitterToEdit()'>Show All Transmitters</button></div>";
					circleMarker.bindPopup(popup);
	
					transData.push({
						"ABS_X": getsampleData[i].longitude,
						"ABS_Y": getsampleData[i].latitude,
						"FBAND": getsampleData[i].bandClass,
						"VZ_SECTOR": getsampleData[i].sector,
						"VZ_LTE_MAX_POWER": getsampleData[i].marketSid,                   //max_power,
						"AZIMUT": getsampleData[i].azimuthDeg,
						"TX_ID": getsampleData[i].txId,
						"SITE_NAME": getsampleData[i].siteName,
						'SITE_ID': getsampleData[i].siteNumber,
						"TILT": getsampleData[i].transmitterTilt
					});
					transData1.push(
						{
							"TRANSMITTER_DATA": JSON.stringify(transData),
							"ATOLL_TRANSMITTER_TX_ID": getsampleData[i].tx_id
						});
				}
				transData = getDistinctValues(transData);
				getCountOfDuplicate(transData);
				drawTransmitter(transData, '', editableLayers);
				selectedtransmitterMap = new Map();
$('#loading').hide();
			}, error: function (data) {
				errorAlert('Error', 'Error occured in fetching Transmitters Data');
				var spreadsheetTransmitter = 'transmitterInfoGridMain';
				creatingJSpreadsheete911(dynamicTransimittertablecolumns, spreadsheetTransmitter);
				$('#loading').hide();
			}
		});
	}
}

var spreadsheetTransmitterObj;

function creatingJSpreadsheete911(dynamicTransimittertablecolumns, spreadsheetTransmitter) {

	if (spreadsheetTransmitter == 'transmitterInfoGridMain') {

		spreadsheetTransmitterObj = jspreadsheet(document.getElementById(spreadsheetTransmitter), {
			data: getsampleData,
			columns: dynamicTransimittertablecolumns,
			tableOverflow: true,
			tableWidth: '100%',
			minSpareRows: 0,
			autoIncrement:false,
			//onchange: transmittergridinfoChange,
			onchange: function (instance, cell, c, r, value) {
				transmittergridinfoChange(c,r, value);
			},
		});
	}
}
var atollSchemaDto = [];
function  transmittergridinfoChange(c,r, value) {
	var getRowsData = document.getElementById('transmitterInfoGridMain').jexcel.getRowData(r);
	if (c == 0 && value == true) {
		selectedTransmitterRows.add(r);
		//for fetching updated co-ordinates 
		let updatedRow = parseInt(r)+1; 
		l1 = $("#transmitterInfoGridMain table tbody tr:nth-child("+updatedRow+") td:nth-child(14)").text(); //lat
		l2 = $("#transmitterInfoGridMain table tbody tr:nth-child("+updatedRow+") td:nth-child(15)").text(); //lng
		if(l1 == undefined || l2 == undefined)
		{
			l1 = getRowsData[12];
			l2 = getRowsData[13];
		}
		console.log(getRowsData[12], getRowsData[13]);
		getRowsData[12] = l1;
		getRowsData[13] = l2;
		var selectedRowForPayload = {};
		
//removed if condition
			selectedRowForPayload = {
				
				  "marketSid" : "",
				  "switchNumber" : "",
				  "switchName" : "",
				  "siteName" : "",
				  "siteNumber" : "",
				  "siteVersion" : "",
				  "txId" : getRowsData[28],
				  "vzChannel" : "",
				  "latitude" : getRowsData[12],
				  "longitude" : getRowsData[13],
				  "streetAddress" : getRowsData[22],
				  "city" : getRowsData[23],
				  "county" : getRowsData[25],
				  "state" : getRowsData[24],
				  "zipcode" : getRowsData[26],
				  "dispatchableLocation" : getRowsData[27],
				  "sector" : "",
				  "azimuthDeg" : "",
				  "antennaModel" : "",
				  "antennaManufacturer" : "",
				  "antennaMaxGainDbd" : "",
				  "antennaHBwDeg" : "",
				  "antennaCenterlineft" : getRowsData[19],
				  "transmitterTilt" : "",
				  "technology" : "",
				  "pilotErpW" : "",
				  "lteTotalEIRPE" : "",
				  "mcc" : "",
				  "mnc" : "",
				  "ecgi" : "",
				  "bandClass" : "",
				  "lteMarket" : "",
				  "enodeBSiteName" : "",
				  "transCellType" : getRowsData[3],
				  "antennaEnvironment" : "",
				  "avgSectorRadius" : "",
				  "dlOnlyChannel" : getRowsData[5],
				  "fiveGsector" : getRowsData[6],
				  "lteSector" : getRowsData[7],
				  "gNBId" : getRowsData[8],
				  "eNBUd" : getRowsData[9]
					};
		


		if(!selectedtransmitterMap.has(getRowsData[28]))
			selectedtransmitterMap.set(getRowsData[28], selectedRowForPayload)
		else
		{
			let rData = selectedtransmitterMap.get(getRowsData[28]);

			rData = selectedRowForPayload;

			selectedtransmitterMap.set(getRowsData[28],rData);
		}
		console.log(getRowsData[11], getRowsData[12]);
		
		console.log(getRowsData);
		console.log("atollSchemaDto", atollSchemaDto);
	} else if (c == 0 && selectedTransmitterRows.has(r) && value != true) {
		if(selectedtransmitterMap.has(getRowsData[28]))
				selectedtransmitterMap.delete(getRowsData[28])

		selectedTransmitterRows.delete(r);
		atollSchemaDto.splice(r, 1);
	}
}
var selectedMarket;
function saveTransmitterantennaDto() {
	let transmitterPayload = Array.from(selectedtransmitterMap.values());
	//transmitterPayload = atollSchemaDto;
  console.log(atollSchemaDto);
   if (Object.keys(featureToggleMap).includes("F90711") && featureToggleMap['F90711']) {
	 selectedMarket = $('#commonE911ReportSchemaSearchSchemalist option:selected').text();
  } else {
	 selectedMarket = $('#marketDropdown option:selected').text().split("-")[0].trim();
  }
  if(transmitterPayload.length == 0) {
	alert("No Rows Selected");
  } else {
	$.ajax({
		type: 'POST',
		//url: "http://localhost:8100/npp-atoll-services/transmitter/updateTransmitterAntennaDto/"+selectedMarket,
		url: updateTransmitterAntennaDtoURL+"/"+selectedMarket,
		contentType: 'application/json',
		cache: false,
		data: JSON.stringify(transmitterPayload),
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function (data) {
			console.log(data);
			aptAlert('Success', 'Successfully Updated');
			selectedTransmitterRows.clear();
			atollSchemaDto = [];

		},
		error: function (data) {
		}
	});
  }


}

function aptAlert(status, message) {
	$("#alertsuccess").hide();
	$("#alerterror").hide();
	$("#alertinfo").hide();
	$("#alertwarning").hide();

	$("#alertTitle").html(status + '!');
	$("#alert" + status.toLowerCase()).html(message);
	$("#alert" + status.toLowerCase()).show();
	$("#myModal").css(
		"margin-top",
		Math.max(0, ($(window).height() - ($("#myModal").height() + 100)) / 2));
	$("#myModal").css(
		"margin-left",
		Math.max(0, ($(window).width() - $("#myModal").width()) / 2));
	$("#myModal").modal("show");
}

function e911ResetClick() {
	getsampleData = [];
	spreadsheetTransmitterObj.destroy();
	var spreadsheetTransmitter = 'transmitterInfoGridMain';
	creatingJSpreadsheete911(dynamicTransimittertablecolumns, spreadsheetTransmitter);
	editableLayers.clearLayers();
	clearCommonSearchDropdown();
	if (leaf && leaf.remove) {
		leaf.off();
		leaf.remove();
	}
	initMap();
}
