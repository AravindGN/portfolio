var optgroups = [];
var baseoptgroups = [
    {
        label: 'Standard Views', children: []
    },
    {
        label: 'My Views', children: []
    }
];
var defaultFilterName = [];
var originFilterName = [];
var selectedFilterName = [];
var userTemplates = [];
var solutionTamplateColumnMap = {};
var originalTamplateColumnMap = {};

$(document).ready(function(){
    // console.log(page, pape == "version");
    var innerHeight = window.innerHeight;
    if(innerHeight < 510){
        $('#modifyCurViewContainer').css("overflow", "auto");
    }

    // init tamplate dropdown
    $('#tamplateSelect').multiselect({
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
    });
    if(page == "version"){
        // set dropdown value based on the page source
        // get custom templates
        // build default column list
        getBaseView("ATOLL.CARRIER.VERSION.VIEWS", "version");
        getColumnNames('ATOLL.CARRIER.VERSION.DEFAULT');
    }else if(page == "tx"){
        // set dropdown value based on the page source
        // get custom templates
        getBaseView("ATOLL.CARRIER.TX.VIEWS", "tx");
        // build default column list
        getColumnNames('ATOLL.CARRIER.TX.DEFAULT');
    }else{
        // set dropdown value based on the page source
        // get custom templates
        getBaseView("ATOLL.CARRIER.CELL.VIEWS", "cell");
        // build default column list
        getColumnNames('ATOLL.CARRIER.CELL.DEFAULT');
    }

    // update tamplate dropdown
    $('#tamplateSelect').multiselect('dataprovider', optgroups);

    //update columns in default/selected list based when tamplate dropdown changed
    $('#tamplateSelect').change(function(i){
        // clear the search input for default & selected column list
        $('#searchAvailableDefaultCols').val("");
        $('#searchAvailableSelectedCols').val("");
        var val = $(this).val();
        // val = val.indexOf("ATOLL.CARRIER.") >= 0? val.split("ATOLL.CARRIER.")[1] : val;
        var publicTemplateArray = _.find(optgroups, {label: 'Standard Views'}).children;
        var col = _.cloneDeep(solutionTamplateColumnMap[val]);
        if(_.findIndex(publicTemplateArray, {value: val}) >= 0){
            // default view
            if(col){
                // reset the selected list
                resetSelectedList(col);
                var defaultCol = [];
                if(page == "version"){
                    originFilterName = _.cloneDeep(originalTamplateColumnMap["ATOLL.CARRIER.VERSION.DEFAULT"]);
                    defaultCol =  _.cloneDeep(solutionTamplateColumnMap["ATOLL.CARRIER.VERSION.DEFAULT"]);
                }else if(page == "tx"){
                    originFilterName = _.cloneDeep(originalTamplateColumnMap["ATOLL.CARRIER.TX.DEFAULT"]);
                    defaultCol =  _.cloneDeep(solutionTamplateColumnMap["ATOLL.CARRIER.TX.DEFAULT"]);
                }else{
                    originFilterName = _.cloneDeep(originalTamplateColumnMap["ATOLL.CARRIER.CELL.DEFAULT"]);
                    defaultCol =  _.cloneDeep(solutionTamplateColumnMap["ATOLL.CARRIER.CELL.DEFAULT"]);
                }
                resetDefaultList(defaultCol, "selected", col);
            }else{
                getColumnNames(val);
            }
            $('#delete_btn').attr('disabled', true);
        }else{
            // custom view
            $('#delete_btn').attr('disabled', false);
            if(col){
                // reset the selected list
                resetSelectedList(col);
                var obj = userTemplates[val];
                var defaultCol = [];
                if(page == "version"){
                    defaultCol =  _.cloneDeep(solutionTamplateColumnMap["ATOLL.CARRIER.VERSION.DEFAULT"]);
                }else if(page == "tx"){
                    defaultCol =  _.cloneDeep(solutionTamplateColumnMap["ATOLL.CARRIER.TX.DEFAULT"]);
                }else{
                    defaultCol =  _.cloneDeep(solutionTamplateColumnMap["ATOLL.CARRIER.CELL.DEFAULT"]);
                }
                //reset the default list based on the custom view
                if(defaultCol){
                    if(page == "version"){
                        originFilterName = _.cloneDeep(originalTamplateColumnMap["ATOLL.CARRIER.VERSION.DEFAULT"]);
                    }else if(page == "tx"){
                        originFilterName = _.cloneDeep(originalTamplateColumnMap["ATOLL.CARRIER.TX.DEFAULT"]);
                    }else{
                        originFilterName = _.cloneDeep(originalTamplateColumnMap["ATOLL.CARRIER.CELL.DEFAULT"]);
                    }
                    resetDefaultList(defaultCol, "selected", solutionTamplateColumnMap[val]);
                }else{
                    getColumnNames(obj.templateFrom, true);
                }
            }
        }
        if(val.split('ATOLL.CARRIER.')[1]){
            val = val.split('ATOLL.CARRIER.')[1];
        }else if(val.split('NPP.RAN.SECTOR.')[1]){
            val = val.split('NPP.RAN.SECTOR.')[1];
        }
        $('#templateName').val(val);
        validate();
    });
    
    // delete template
    $('#delete_btn').click(function(e){
        var name = $('#templateName').val();
        if(page == "version"){
            name = "ATOLL.CARRIER.VERSION." + name;
        }else if(page == "tx"){
            name = "ATOLL.CARRIER.TX." + name;
        }else{
            name = "ATOLL.CARRIER.CELL." + name;
        }
        deleteTemplate(name, "deleteOnly");
    });

    $('#close_btn').click(function(e){
        $(window.parent.document).find('#closeViewManagerPopupBtn').click();
    });

    // add selected column to the custom column list
    $(".vzuui-filt-sort-right-arrow").click(function() {
        $("#selectedColumnList li.selectedLiColor").removeClass("selectedLiColor");
        var columnsArray = $($("#defaultColumnList li").get().reverse());
        columnsArray.each(function(index, obj) {
            if ($(obj).hasClass("selectedLiColor")) {
                $(obj).remove();
                var value = $(obj).attr("value");
                selectedFilterName.unshift(value);
                var resultContent = "<li value='" + value + "'>" + value + "</li>"
                $("#selectedColumnList").prepend(resultContent);
                $(obj).removeClass("selectedLiColor");
            }
        });
        // bind click event to new row
        $("#selectedColumnList li").off("click");
        $("#selectedColumnList li").click(function(e) {
            if (!lastCheckedSelected) {
                lastCheckedSelected = this;
                if ($(this).hasClass("selectedLiColor")) {
                    $(this).removeClass("selectedLiColor");
                } else {
                    $(this).addClass("selectedLiColor");
                }
                return;
            }
            if (e.shiftKey) {
                var start = $("#selectedColumnList li").index(this);
                var end = $("#selectedColumnList li").index(lastCheckedSelected);
                var flag = false;
                $("#selectedColumnList li").slice(Math.min(start,end), Math.max(start,end)+ 1).each(function(){
                    if ($(this).hasClass("selectedLiColor")) {
                    }else{
                        flag = true;
                    }
                })
                $("#selectedColumnList li").slice(Math.min(start,end), Math.max(start,end)+ 1).each(function(){
                    if (flag == true) {
                        $(this).addClass("selectedLiColor");
                    } else {
                        $(this).removeClass("selectedLiColor");
                    }
                })
                lastCheckedSelected = this;
            }else{
                lastCheckedSelected = this;
                if ($(this).hasClass("selectedLiColor")) {
                    $(this).removeClass("selectedLiColor");
                } else {
                    $(this).addClass("selectedLiColor");
                }
            }
        });

        $("#selectedColumnList").scrollTop(0);
        validate();
        $("#selectAllForAvailableList").prop('checked', false);
    });

    // remove selected column from custom column list
    $(".vzuui-filt-sort-left-arrow").click(function() {
        $("#defaultColumnList li.selectedLiColor").removeClass("selectedLiColor");
        var columnsArray = $($("#selectedColumnList li").get().reverse());
        columnsArray.each(function(index, obj) {
            if ($(obj).hasClass("selectedLiColor")) {
                $(obj).remove();
                var value = $(obj).attr("value");
                var valueTrans = $(obj).attr("value").replace(/&/g, "&amp;").replace(/>/g, "&gt;").replace(/</g, "&lt;").replace(/"/g, "&quot;");
                if(value && value != "undefined"){
                    defaultFilterName.push(value);
                    var resultContent = "<li value='" + value + "'>" + value + "</li>"
                    $("#defaultColumnList").prepend(resultContent);
                    $(obj).removeClass("selectedLiColor");
                    _.pull(selectedFilterName, value);
                    _.pull(selectedFilterName, valueTrans);
                }
            }
        });
        // bind click event to new row
        $("#defaultColumnList li").off("click");
        $("#defaultColumnList li").click(function(e) {
            // var lastCheckedSelected = null;
            if (!lastCheckedDefault) {
                lastCheckedDefault = this;
                if ($(this).hasClass("selectedLiColor")) {
                    $(this).removeClass("selectedLiColor");
                } else {
                    $(this).addClass("selectedLiColor");
                }
                return;
            }
            if (e.shiftKey) {
                var start = $("#defaultColumnList li").index(this);
                var end = $("#defaultColumnList li").index(lastCheckedDefault);
                var flag = false;
                $("#defaultColumnList li").slice(Math.min(start,end), Math.max(start,end)+ 1).each(function(){
                    if ($(this).hasClass("selectedLiColor")) {
                    }else{
                        flag = true;
                    }
                })
                $("#defaultColumnList li").slice(Math.min(start,end), Math.max(start,end)+ 1).each(function(){
                    if (flag == true) {
                        $(this).addClass("selectedLiColor");
                    } else {
                        $(this).removeClass("selectedLiColor");
                    }
                })
                lastCheckedDefault = this;
            }else{
                lastCheckedDefault = this;
                if ($(this).hasClass("selectedLiColor")) {
                    $(this).removeClass("selectedLiColor");
                } else {
                    $(this).addClass("selectedLiColor");
                }
            }
        });
        validate();
        $("#selectAllForSelectedList").prop('checked', false);
    });

    // selected column move up
    $("#selectedColumnMoveUpBtn").click(function() {
        var columnsArray = $($("#selectedColumnList li"));
        columnsArray.each(function(index, obj) {
            if ($(obj).hasClass("selectedLiColor")) {
                $(obj).insertBefore($(obj).prevAll(":first"));
            }
        });
        var firstElementpos = $(".vzuui-filt-sort-selected .vzuui-filt-sort-deselected-head").position().top + 20;
        if ($($("#selectedColumnList li.selectedLiColor:first")).position().top < firstElementpos) {
            var position = $(".vzuui-filt-sort-selected .vzuui-filt-sort-selected-table-body").scrollTop() - 20;
            $(".vzuui-filt-sort-selected .vzuui-filt-sort-selected-table-body").scrollTop(position);
        }
        // reorder selected list
        columnsArray = $($("#selectedColumnList li"));
        var newOrder = [];
        columnsArray.each(function(index, obj) {
            var value = $(obj).attr("value");
            newOrder.push(value);
        });
        selectedFilterName = newOrder;
    });
    
    // selected column move down
    $(".vzuui-filt-sort-down-arrow").click(function() {
        var columnsArray = $($("#selectedColumnList li").get().reverse());
        columnsArray.each(function(index, obj) {
            if ($(obj).hasClass("selectedLiColor")) {
                $(obj).insertAfter($(obj).nextAll(":first"));
            }
        });
        var lastElementpos = $(".vzuui-filt-sort-selected .vzuui-filt-sort-deselected-head").position().top + $(window).scrollTop();
        if ($($("#selectedColumnList li.selectedLiColor:last")).position().top > lastElementpos) {
            var position = $(".vzuui-filt-sort-selected .vzuui-filt-sort-selected-table-body").scrollTop() + 20;
            $(".vzuui-filt-sort-selected .vzuui-filt-sort-selected-table-body").scrollTop(position);
        }
        // reorder selected list
        columnsArray = $($("#selectedColumnList li"));
        var newOrder = [];
        columnsArray.each(function(index, obj) {
            var value = $(obj).attr("value");
            newOrder.push(value);
        });
        selectedFilterName = newOrder;
    });

    // select/unselect columns in default List
    $("#defaultColumnList li").click(function(e) {
        if (!lastCheckedDefault) {
            lastCheckedDefault = this;
            if ($(this).hasClass("selectedLiColor")) {
                $(this).removeClass("selectedLiColor");
            } else {
                $(this).addClass("selectedLiColor");
            }
            return;
        }
        if (e.shiftKey) {
            var start = $("#defaultColumnList li").index(this);
            var end = $("#defaultColumnList li").index(lastCheckedDefault);
            var flag = false;
            $("#defaultColumnList li").slice(Math.min(start,end), Math.max(start,end)+ 1).each(function(){
                if ($(this).hasClass("selectedLiColor")) {
                }else{
                    flag = true;
                }
            })
            $("#defaultColumnList li").slice(Math.min(start,end), Math.max(start,end)+ 1).each(function(){
                if (flag == true) {
                    $(this).addClass("selectedLiColor");
                } else {
                    $(this).removeClass("selectedLiColor");
                }
            })
            lastCheckedDefault = this;
        }else{
            lastCheckedDefault = this;
            if ($(this).hasClass("selectedLiColor")) {
                $(this).removeClass("selectedLiColor");
            } else {
                $(this).addClass("selectedLiColor");
            }
        }
    });

    // select/unselect columns in selected List
    $("#selectedColumnList li").click(function(e) {
        if (!lastCheckedSelected) {
            lastCheckedSelected = this;
            if ($(this).hasClass("selectedLiColor")) {
                $(this).removeClass("selectedLiColor");
            } else {
                $(this).addClass("selectedLiColor");
            }
            return;
        }
        if (e.shiftKey) {
            var start = $("#selectedColumnList li").index(this);
            var end = $("#selectedColumnList li").index(lastCheckedSelected);
            var flag = false;
            $("#selectedColumnList li").slice(Math.min(start,end), Math.max(start,end)+ 1).each(function(){
                if ($(this).hasClass("selectedLiColor")) {
                }else{
                    flag = true;
                }
            })
            $("#selectedColumnList li").slice(Math.min(start,end), Math.max(start,end)+ 1).each(function(){
                if (flag == true) {
                    $(this).addClass("selectedLiColor");
                } else {
                    $(this).removeClass("selectedLiColor");
                }
            })
            lastCheckedSelected = this;
        }else{
            lastCheckedSelected = this;
            if ($(this).hasClass("selectedLiColor")) {
                $(this).removeClass("selectedLiColor");
            } else {
                $(this).addClass("selectedLiColor");
            }
        }
    });

    // search filed in default List
    $("#searchAvailableDefaultCols").on("keyup input", function() {
        if (!$("#searchAvailableDefaultCols").val() || $("#searchAvailableDefaultCols").val().length == 0) {
            $("#defaultColumnList li").removeClass("_flt_hide");
        }
    });
    $("#searchAvailableDefaultCols").autocomplete({
        source: defaultFilterName,
        response: function(event, ui) {
            var filterColumns = $("#defaultColumnList li");
            filterColumns.removeClass("selectedLiColor");
            filterColumns.addClass("_flt_hide");
            for (var i = 0; i < ui.content.length; i++) {
                for (var j = 0; j < filterColumns.length; j++) {
                    var li_obj = filterColumns[j];
                    if ($(li_obj).html() == ui.content[i].label) {
                        $(li_obj).removeClass("_flt_hide");
                    }
                }
                $("ul.ui-autocomplete").remove();
            }
        }
    });

    // search filed in selected List
    $("#searchAvailableSelectedCols").on("keyup input", function() {
        if (!$("#searchAvailableSelectedCols").val() || $("#searchAvailableSelectedCols").val().length == 0) {
            $("#selectedColumnList li").removeClass("_flt_hide");
        }
    });
    $("#searchAvailableSelectedCols").autocomplete({
        source: selectedFilterName,
        response: function(event, ui) {
            var filterColumns = $("#selectedColumnList li");
            filterColumns.removeClass("selectedLiColor");
            filterColumns.addClass("_flt_hide");
            for (var i = 0; i < ui.content.length; i++) {
                for (var j = 0; j < filterColumns.length; j++) {
                    var li_obj = filterColumns[j];
                    if ($(li_obj).html() == ui.content[i].label) {
                        $(li_obj).removeClass("_flt_hide");
                    }
                }
                $("ul.ui-autocomplete").remove();
            }
        }
    });

    // keyup event of template name input 
    $('#templateName').keyup(function(e){
        validate();
    });

    // save template
    $('#save_btn').click(function(e){
        saveNewTemplate();
    });
    
    // contact search input event
    $('#firstNameInput').on("keypress", function(e) {
        if (e.keyCode == 13) {
            $('#contactSearchBtn').trigger('click');
            return false; // prevent the button click from happening
        }
    });
    $('#lastNameInput').on("keypress", function(e) {
        if (e.keyCode == 13) {
            $('#contactSearchBtn').trigger('click');
            return false; // prevent the button click from happening
        }
    });
    // contact search btn click event
    $('#contactSearchBtn').click(function(e){
        var firstName = $('#firstNameInput').val();
        var lastName = $('#lastNameInput').val();
        $.ajax({
            url: '/uuigui/uui/eapp/atoll_pg/searchContractFromApi?firstName=' + firstName + '&lastName=' + lastName,
            type: 'GET',
            contentType: 'application/json',
            success: function(data) {
                // contractDatasource
                data = JSON.parse(data);
                if(data && data.length>0){
                    $('#recordsFound').show();
                    $('#recordsFound #contactCount').text(data.length);
                }else{
                    $('#recordsFound').show();
                    $('#recordsFound #contactCount').text(0);
                }
                var dataSource = new kendo.data.DataSource({ data: data,pageSize: 100 });
                var grid = $('#contactsDetailsGrid').data("kendoGrid");
                dataSource.read();
                grid.setDataSource(dataSource);
                grid.setOptions({
                    // height:135,
                    pageable: {  
                        alwaysVisible:false,  
                        pageSizes: [20, 40, 60, 80,100]
                    },  
                });
                $('#contactsDetailsGrid .k-pager-wrap').hide();
            },
            error: function(err) {

            },
            complete: function(e) {
                $('#loading').hide();
            }
        });
    });

    // initial contact grid
    contractDatasource = new kendo.data.DataSource({
        type: "odata",
        data: [],
        pageSize: 100
    });
    $("#contactsDetailsGrid").kendoGrid({
        dataSource: contractDatasource,
        sortable: true,
        pageable: {  
            alwaysVisible:false,  
            pageSizes: [20, 40, 60, 80,100]
        },  
        filterable: true,
        columnMenu: true,
        reorderable: true,
        detailTemplate: kendo.template($("#viewDetail").html()),
        detailInit: viewDetailInit,
        resizable: true,
        columns:[
            {
                "title": "Id",
                "field": "VZ_ID", 
                width: 150,
                hidden: true,
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains"
                    }
                }
            }, {
                "title": "Last Name",
                "field": "LAST_NAME", 
                width: 150,
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains"
                    }
                }
            }, {
                "title": "First Name",
                "field": "FIRST_NAME", 
                width: 150,
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains"
                    }
                }
            },{
                "title": "Company",
                "field": "LOB_NAME", 
                width: 150,
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains"
                    }
                }
            }, {
                "title": "Phone",
                "field": "PRIMARY_TN", 
                width: 130,
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains"
                    }
                }
            }, {
                "title": "Email",
                "field": "USER_EMAIL", 
                width: 250,
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains"
                    }
                }
            }
        ]
    });
    $("#contactsDetailsGrid").css("height", 438);
    

    $('.viewGroup').change(function(){
        if ($(this).is(':checked')){
            if($(this).val() == "Modify Current View"){
                $('#modifyCurViewContainer').show();
                $('#cloneViewContainer').hide();
            }else if($(this).val() == "Clone View From Other User"){
                $('#cloneViewContainer').show();
                $('#modifyCurViewContainer').hide();
            }
        }
    });

    $('#selectAllForAvailableList').change(function(e){
        if($("#selectAllForAvailableList").prop('checked') == true){
            $('#defaultColumnList').find('li').addClass('selectedLiColor')
        }else{
            $('#defaultColumnList').find('li').removeClass('selectedLiColor')
        }
    });

    $('#selectAllForSelectedList').change(function(e){
        if($("#selectAllForSelectedList").prop('checked') == true){
            $('#selectedColumnList').find('li').addClass('selectedLiColor')
        }else{
            $('#selectedColumnList').find('li').removeClass('selectedLiColor')
        }
    });
})

var lastCheckedDefault = null;
var lastCheckedSelected = null;
// get Column names from UI-SETTING
function getColumnNames(ui_obj_name, reset) {
    var displayColumns = [];
    UiSettingsRetrieve(ui_obj_name, function (data) {
        var name = $('#tamplateSelect').val();
        if (data && data != "ERROR" && data.prop_params && data.prop_params != '' && data.prop_params.columns) {
            $.each(data.prop_params.columns, function(i, v){
                if(!v.hidden && v.title && v.title != "undefined" && v.title != "&nbsp;"){
                    if(v.columns && v.columns.length > 0){
                        $.each(v.columns, function(i1, v1){
                            displayColumns.push(v1.title + v.title);
                        })
                    }else{
                        displayColumns.push(v.title);
                    }
                }
            })
            name = name? name : ui_obj_name;
            originalTamplateColumnMap[name] = data.prop_params.columns;
            if(page == "version"){
                originFilterName = _.cloneDeep(originalTamplateColumnMap["ATOLL.CARRIER.VERSION.DEFAULT"]);
            }else if(page == "tx"){
                originFilterName = _.cloneDeep(originalTamplateColumnMap["ATOLL.CARRIER.TX.DEFAULT"]);
            }else{
                originFilterName = _.cloneDeep(originalTamplateColumnMap["ATOLL.CARRIER.CELL.DEFAULT"]);
            }
        }
        if(ui_obj_name != "ATOLL.CARRIER.VERSION.DEFAULT" && ui_obj_name != "ATOLL.CARRIER.TX.DEFAULT" && ui_obj_name != "ATOLL.CARRIER.CELL.DEFAULT"){
            selectedFilterName = _.cloneDeep(displayColumns);
        }else{
            displayColumns.sort((a,b) => a > b? 1 : -1);
        }
        solutionTamplateColumnMap[ui_obj_name] = displayColumns;
        if(reset == true){
            var val = $('#tamplateSelect').val();
            var obj = _.filter(userTemplates, {prop_params: {name: val}})? _.filter(userTemplates, {prop_params: {name: val}})[0] : {};
            obj = obj == undefined && userTemplates[val]? userTemplates[val] : {};
            obj = obj && obj.prop_params? obj.prop_params : obj;
            var col = _.cloneDeep(solutionTamplateColumnMap[val]);
            if(page == "version"){
                resetDefaultList(solutionTamplateColumnMap["ATOLL.CARRIER.VERSION.DEFAULT"], "selected", col);
            }else if(page == "tx"){
                resetDefaultList(solutionTamplateColumnMap["ATOLL.CARRIER.TX.DEFAULT"], "selected", col);
            }else{
                resetDefaultList(solutionTamplateColumnMap["ATOLL.CARRIER.CELL.DEFAULT"], "selected", col);
            }
        }else{
            if(ui_obj_name != "ATOLL.CARRIER.VERSION.DEFAULT" && ui_obj_name != "ATOLL.CARRIER.TX.DEFAULT" && ui_obj_name != "ATOLL.CARRIER.CELL.DEFAULT"){
                resetSelectedList(selectedFilterName);
            }
            var val = $('#tamplateSelect').val();
            var col = val && solutionTamplateColumnMap[val] ?  _.cloneDeep(solutionTamplateColumnMap[val]) : [];
            if(page == "version"){
                resetDefaultList(solutionTamplateColumnMap["ATOLL.CARRIER.VERSION.DEFAULT"], "selected", col);
            }else if(page == "tx"){
                resetDefaultList(solutionTamplateColumnMap["ATOLL.CARRIER.TX.DEFAULT"], "selected", col);
            }else{
                resetDefaultList(solutionTamplateColumnMap["ATOLL.CARRIER.CELL.DEFAULT"], "selected", col);
            }
        }
    });
}

function resetDefaultList(columns, source, selectedColumns){
    $('#defaultColumnList').empty();
    var col = _.cloneDeep(columns);
    if(source == "default"){
        $('#selectedColumnList').empty();
    }else if(source == "selected"){
        var temp = _.cloneDeep(selectedColumns);
        $.each(temp, function(i, v){
            temp[i] = v.replace("&amp;","&").replace("&gt;", ">").replace("&lt;", "<").replace("&quot;", "\"");
        })
        _.remove(col, function(el) {
            var a = el.replace("&amp;","&").replace("&gt;", ">").replace("&lt;", "<").replace("&quot;", "\"");
            return !a || a == "undefined" || temp.indexOf(a) >= 0;
        });
    }
    defaultFilterName = col;
    col = col? col : [];
    $.each(col, function(i, v){
        $('#defaultColumnList').append("<li value='" + v + "'>" + v + "</li>");
    });
    // select/unselect columns in default List
    $("#defaultColumnList li").click(function(e) {
        // var lastCheckedSelected = null;
        if (!lastCheckedDefault) {
            lastCheckedDefault = this;
            if ($(this).hasClass("selectedLiColor")) {
                $(this).removeClass("selectedLiColor");
            } else {
                $(this).addClass("selectedLiColor");
            }
            return;
        }
        if (e.shiftKey) {
            var start = $("#defaultColumnList li").index(this);
            var end = $("#defaultColumnList li").index(lastCheckedDefault);
            var flag = false;
            $("#defaultColumnList li").slice(Math.min(start,end), Math.max(start,end)+ 1).each(function(){
                if ($(this).hasClass("selectedLiColor")) {
                }else{
                    flag = true;
                }
            })
            $("#defaultColumnList li").slice(Math.min(start,end), Math.max(start,end)+ 1).each(function(){
                if (flag == true) {
                    $(this).addClass("selectedLiColor");
                } else {
                    $(this).removeClass("selectedLiColor");
                }
            })
            lastCheckedDefault = this;
        }else{
            lastCheckedDefault = this;
            if ($(this).hasClass("selectedLiColor")) {
                $(this).removeClass("selectedLiColor");
            } else {
                $(this).addClass("selectedLiColor");
            }
        }
    });
    // reset source of autocomplete
    $("#searchAvailableDefaultCols").autocomplete("destroy");
    // search filed in default List
    $("#searchAvailableDefaultCols").on("keyup input", function() {
        if (!$("#searchAvailableDefaultCols").val() || $("#searchAvailableDefaultCols").val().length == 0) {
            $("#defaultColumnList li").removeClass("_flt_hide");
        }
    });
    $("#searchAvailableDefaultCols").autocomplete({
        source: defaultFilterName,
        response: function(event, ui) {
            var filterColumns = $("#defaultColumnList li");
            filterColumns.removeClass("selectedLiColor");
            filterColumns.addClass("_flt_hide");
            for (var i = 0; i < ui.content.length; i++) {
                for (var j = 0; j < filterColumns.length; j++) {
                    var li_obj = filterColumns[j];
                    if ($(li_obj).html() == ui.content[i].label) {
                        $(li_obj).removeClass("_flt_hide");
                    }
                }
                $("ul.ui-autocomplete").remove();
            }
        }
    });
}

function resetSelectedList(columns){
    // $('#defaultColumnList').empty();
    $('#selectedColumnList').empty();
    selectedFilterName = columns;
    columns = columns? columns : [];
    $.each(columns, function(i, v){
        $('#selectedColumnList').append("<li value='" + v + "'>" + v + "</li>");
    });
    // select/unselect columns in selected List
    $("#selectedColumnList li").click(function(e) {
        if (!lastCheckedSelected) {
            lastCheckedSelected = this;
            if ($(this).hasClass("selectedLiColor")) {
                $(this).removeClass("selectedLiColor");
            } else {
                $(this).addClass("selectedLiColor");
            }
            return;
        }
        if (e.shiftKey) {
            var start = $("#selectedColumnList li").index(this);
            var end = $("#selectedColumnList li").index(lastCheckedSelected);
            var flag = false;
            $("#selectedColumnList li").slice(Math.min(start,end), Math.max(start,end)+ 1).each(function(){
                if ($(this).hasClass("selectedLiColor")) {
                }else{
                    flag = true;
                }
            })
            $("#selectedColumnList li").slice(Math.min(start,end), Math.max(start,end)+ 1).each(function(){
                if (flag == true) {
                    $(this).addClass("selectedLiColor");
                } else {
                    $(this).removeClass("selectedLiColor");
                }
            })
            lastCheckedSelected = this;
        }else{
            lastCheckedSelected = this;
            if ($(this).hasClass("selectedLiColor")) {
                $(this).removeClass("selectedLiColor");
            } else {
                $(this).addClass("selectedLiColor");
            }
        }
    });
    // reset source of autocomplete
    $("#searchAvailableSelectedCols").autocomplete("destroy");
    // search filed in selected List
    $("#searchAvailableSelectedCols").on("keyup input", function() {
        if (!$("#searchAvailableSelectedCols").val() || $("#searchAvailableSelectedCols").val().length == 0) {
            $("#selectedColumnList li").removeClass("_flt_hide");
        }
    });
    $("#searchAvailableSelectedCols").autocomplete({
        source: selectedFilterName,
        response: function(event, ui) {
            var filterColumns = $("#selectedColumnList li");
            filterColumns.removeClass("selectedLiColor");
            filterColumns.addClass("_flt_hide");
            for (var i = 0; i < ui.content.length; i++) {
                for (var j = 0; j < filterColumns.length; j++) {
                    var li_obj = filterColumns[j];
                    if ($(li_obj).html() == ui.content[i].label) {
                        $(li_obj).removeClass("_flt_hide");
                    }
                }
                $("ul.ui-autocomplete").remove();
            }
        }
    });
}

function getCustomTemplates(name){
    $.ajax({
        url: '/uuigui/uui/eapp/atoll_pg/getCustomTemplates?name=' + name,
        type: 'GET',
        contentType: 'application/json',
        success: function (data) {
            data = JSON.parse(data);
            optgroups = _.cloneDeep(baseoptgroups);
            $.each(data, function(i, v){
                var setting = v.SETTING? v.SETTING : "{}";
                setting = JSON.parse(setting);
                if(setting.name){
                    optgroups[1].children.push({label: setting.name, value: setting.name});
                    solutionTamplateColumnMap[setting.name] = [];
                    setting.columns = setting.columns? setting.columns : setting;
                    $.each(setting.columns, function(i, v){
                        if(v.title != "&nbsp;" && v.hidden == false){
                            if(v.columns && v.columns.length > 0){
                                $.each(v.columns, function(i1, v1){
                                    if(v1.hidden == false){
                                        solutionTamplateColumnMap[setting.name].push(v1.title + v.title);
                                    }
                                })
                            }else{
                                solutionTamplateColumnMap[setting.name].push(v.title);
                            }
                        }
                    })
                    userTemplates[setting.name] = setting;
                }
            })
            $('#tamplateSelect').multiselect('dataprovider', optgroups);
            $('#tamplateSelect').val([]).multiselect('refresh');
        },
        error: function (err) {
            $('#loading').hide();
        }
    });
}

function getBaseView(name, source){
    UiSettingsRetrieveSystem(name, function (data) {
        var configs = data && data.configs? data.configs : [];
        if(source == "version"){
            $.each(configs, function(i, v){
                baseoptgroups[0].children.push({label: v.label, value: "ATOLL.CARRIER.VERSION." + v.label});
            });
            getCustomTemplates("ATOLL.CARRIER.VERSION.");
        }else if(source == "tx"){
            $.each(configs, function(i, v){
                baseoptgroups[0].children.push({label: v.label, value: "ATOLL.CARRIER.TX." + v.label});
            });
            getCustomTemplates("ATOLL.CARRIER.TX.");
        }else{
            $.each(configs, function(i, v){
                baseoptgroups[0].children.push({label: v.label, value: "ATOLL.CARRIER.CELL." + v.label});
            });
            getCustomTemplates("ATOLL.CARRIER.CELL.");
        }
    });
}

function validate(){
    var templateName = $('#templateName').val()? $('#templateName').val().trim() : "";
    // check duplicate template name
    var publicTemplateArray = _.find(optgroups, {label: 'Standard Views'}).children;
    
    if(_.findIndex(publicTemplateArray, {value: templateName}) >= 0 || _.findIndex(publicTemplateArray, {label: templateName}) >= 0){
        $('#duplicateTemplateNameErrorMsg').show();
        $('#save_btn').attr('disabled', true);
        return;
    }
    else{
        for(var p in solutionTamplateColumnMap){
            if(solutionTamplateColumnMap.hasOwnProperty(p) && (templateName != $('#tamplateSelect').val() && templateName == (p+ ""))){
                $('#duplicateTemplateNameErrorMsg').show();
                $('#save_btn').attr('disabled', true);
                return;
            }
        }
    }
    $('#duplicateTemplateNameErrorMsg').hide();
    if($('#templateName').val().trim() == "" || $("#selectedColumnList li").length == 0){
        $('#save_btn').attr('disabled', true);
    }else{
        $('#save_btn').attr('disabled', false);
    }
}

function validateClone(){
    $('#duplicateTemplateNameErrorMsgForClone').hide();
    var templateName = $('#cloneName').val();
    if(!templateName){
        $('#cloneName').parents('.k-confirm').find('.k-primary').attr('disabled', true);
        return;
    }
    // check duplicate template name
    for(var p in solutionTamplateColumnMap){
        if(solutionTamplateColumnMap.hasOwnProperty(p) && templateName.toLowerCase() == (p+ "").toLowerCase()){
            $('#duplicateTemplateNameErrorMsgForClone').show();
            $('#cloneName').parents('.k-confirm').find('.k-primary').attr('disabled', true);
            return;
        }
    }
    if($('#cloneName').val().trim() == ""){
        $('#cloneName').parents('.k-confirm').find('.k-primary').attr('disabled', true);
    }else{
        $('#cloneName').parents('.k-confirm').find('.k-primary').attr('disabled', false);
    }
}

function saveNewTemplate(){
    $("#loading").show();
    var templateName = $('#templateName').val().trim();
    var templateFrom = $('#tamplateSelect').val()? $('#tamplateSelect').val().trim() : "";
    templateFrom = userTemplates[templateFrom] && userTemplates[templateFrom].templateFrom? userTemplates[templateFrom].templateFrom : templateFrom;
    var columns = [];    
    $.each(originFilterName, function(i, v){
        var count = 0;
        var insertIdx = -1;
        if(v.columns && v.columns.length > 0){
            count = 0;
            $.each(v.columns, function(i1, v1){
                var title = v1.title + v.title;
                if(selectedFilterName.indexOf(title) > -1){
                    v1.hidden = false;
                    count++;
                    if(insertIdx < 0){
                        insertIdx = selectedFilterName.indexOf(title);
                    }else{
                        insertIdx = Math.min(insertIdx, selectedFilterName.indexOf(title));
                    }
                }else{
                    v1.hidden = true;
                }
            });
            v.hidden == count > 0? false : true;
        }
        var transTitle = v.title.replace("&gt;", ">");
        if(v.title == "&nbsp;"){
            v.hidden = false;
        }else if(selectedFilterName.indexOf(v.title)> -1 || selectedFilterName.indexOf(transTitle)> -1){
            v.hidden = false;
        }else if(count > 0){
            v.hidden = false;
            selectedFilterName.splice(insertIdx, 0, v.title);
        }else{
            v.hidden = true;
        }
    });
    
    originFilterName.sort(function(a, b){
        var titleA = a.title.replace("&gt;", ">");
        var titleB = b.title.replace("&gt;", ">");
        return selectedFilterName.indexOf(titleA) - selectedFilterName.indexOf(titleB);
    });

    $.each(originFilterName, function(i, v){
        if(v.columns && v.columns.length > 0){
            v.columns.sort(function(a, b){
                var titleA = a.title.replace("&gt;", ">") + v.title;
                var titleB = b.title.replace("&gt;", ">") + v.title;
                return selectedFilterName.indexOf(titleA) - selectedFilterName.indexOf(titleB);
            });
        }
    });

    var state = {
        columns: originFilterName,
        templateFrom: templateFrom,
        name: templateName
    };
    userTemplates[templateName] = state;
    var name = "";
    if(page == "version"){
        name = "ATOLL.CARRIER.VERSION.";
    }else if(page == "tx"){
        name = "ATOLL.CARRIER.TX.";
    }else{
        name = "ATOLL.CARRIER.CELL.";
    }
    name = name + templateName;
    UiSettingsSave(name, state, function(res){
        $("#loading").hide();
        if(res == "SUCCESS"){
            $("#successAlert").fadeIn(1000, function() {
                setTimeout(function() {
                    $("#successAlert").fadeOut(1000);
                }, 5000);
            });
        }else{
            $("#createViewFailedAlert").fadeIn(500, function () {
                setTimeout(function () {
                    $("#createViewFailedAlert").fadeOut(500);
                }, 5000);
            });
        }
    });
    // $('#save_btn').attr('disabled', true);
    var columns = _.clone(selectedFilterName);
    // update template name dropdown
    var idx = _.findIndex(optgroups[1].children, {value: templateName});
    if(idx < 0){
        optgroups[1].children.push({label: templateName, value: templateName});
    }
    solutionTamplateColumnMap[templateName] = columns;
    if(page == "version"){
        resetDefaultList(solutionTamplateColumnMap["ATOLL.CARRIER.VERSION.DEFAULT"], "selected", solutionTamplateColumnMap[templateName]);
    }else if(page == "tx"){
        resetDefaultList(solutionTamplateColumnMap["ATOLL.CARRIER.TX.DEFAULT"], "selected", solutionTamplateColumnMap[templateName]);
    }else{
        resetDefaultList(solutionTamplateColumnMap["ATOLL.CARRIER.CELL.DEFAULT"], "selected", solutionTamplateColumnMap[templateName]);
    }
    $('#tamplateSelect').multiselect('dataprovider', optgroups);
    $('#tamplateSelect').val(templateName);
    $('#tamplateSelect').multiselect('refresh');
    $('#delete_btn').attr('disabled', false);
}

function cloneTemplate(item, templateName){
    var name = "";
    if(page == "version"){
        name = "ATOLL.CARRIER.VERSION.";
    }else if(page == "tx"){
        name = "ATOLL.CARRIER.TX.";
    }else{
        name = "ATOLL.CARRIER.CELL.";
    }
    userTemplates[templateName] = item;
    name = name + templateName;
    $('#loading').show();
    UiSettingsSave(name, item, function(msg){
        $('#loading').hide();
        if(msg == "SUCCESS"){
            window.myalert("Clone successfully", "Clone");
            var columns = [];
            var col = item.columns;
            $.each(col, function(i, v){
                if(v.title != "&nbsp;" && v.hidden == false){
                    columns.push(v.title);
                }
            });
            // update template name dropdown
            optgroups[1].children.push({label: templateName, value: templateName});
            solutionTamplateColumnMap[templateName] = _.cloneDeep(columns);
            $('#tamplateSelect').multiselect('dataprovider', optgroups);
            $('#tamplateSelect').multiselect('refresh');
        }else{
            window.myalert("Clone Failed", "Clone");
        }
    });
}

function viewDetailInit(e) {
    var detailRow = e.detailRow;
    var userId = e.data.VZ_ID;
    var name = "";
    if(page == "version"){
        name = "ATOLL.CARRIER.VERSION.";
    }else if(page == "tx"){
        name = "ATOLL.CARRIER.TX.";
    }else{
        name = "ATOLL.CARRIER.CELL.";
    }
    $.ajax({
        url: '/uuigui/uui/eapp/atoll_pg/getCustomTemplates?name=' + name + '&userId=' + userId,
        type: 'GET',
        contentType: 'application/json',
        success: function (data) {
            data = data ? JSON.parse(data) : [];
            if (data != undefined) {
                $.each(data, function (i, v) {
                    v.NAME = v.UI_OBJECT_NAME && v.UI_OBJECT_NAME.split(name)[1] ? v.UI_OBJECT_NAME.split(name)[1] : "";
                });
            }
            detailRow.find(".viewDetail").kendoGrid({
                dataSource: {
                    data: data
                },
                scrollable: false,
                sortable: true,
                pageable: false,
                dataBound: function () {},
                columns: [
                    {
                        field: "NAME",
                        title: "View Name",
                        width: "200px"
                    }, {
                        field: "SETTING",
                        title: "Settings",
                        width: "200px",
                        hidden: true
                    },
                    {
                        title: "Actions",
                        command: [
                            {
                                // for click to work when there is template, add class "k-grid-[command.name]" to some element, otherwise the click handler will not be triggered
                                name: "clone",
                                template: "<a class='k-button k-grid-clone'><span class='k-icon k-i-settings'></span>Clone</a>",
                                click(e){
                                    var grid = $(e.target).parents(".viewDetail").data("kendoGrid");
                                    var row = $(e.target).parents('tr');
                                    var selectedItem = grid.dataItem(row)? grid.dataItem(row) : {};
                                    var settings = selectedItem.SETTING? JSON.parse(selectedItem.SETTING) : {}
                                    // validateClone();
                                    window.confirmClone().then(function () {
                                        var templateName = $('#cloneName').val().trim();
                                        $('#cloneName').val(templateName);
                                        settings.name = templateName;
                                        cloneTemplate(settings, templateName);
                                    }, function () {
                                        
                                    });
                                }
                            }
                        ] 
                    }
                ],
                editable: "popup",
            });
        }
    });
    detailRow.find(".tabstrip").kendoTabStrip({
        animation: {
            open: { effects: "fadeIn" }
        }
    });
}

function confirmClone(){
    return $("<div id='clonePopup'></div>").kendoConfirm({
        title: "Clone View",
        content: "<span><b>Name:</b><span style='color:red;'>* </span></span><input id='cloneName' maxlength = '112' style='width:320px;'/><br><span id='duplicateTemplateNameErrorMsgForClone' style='color:red; display:none;'>The view name entered already exists, please enter another name.</span>",
        messages:{
            okText: "Clone"
        },
        open: onOpen,
    }).data("kendoConfirm").open().result;
}
function myalert(content, title){
    $("<div></div>").kendoAlert({
      title: title,
      content: content
    }).data("kendoAlert").open();
}

function onOpen(e) {
    $('#clonePopup').css("padding", "0px 10px 20px 10px");
    $('#clonePopup').css("width", "400px");
    $('#cloneName').parents('.k-confirm').find('.k-primary').attr('disabled', true);
    $('#cloneName').off("keyup");
    $('#cloneName').on("keyup", function(){
        validateClone();
    })
}

function deleteTemplate(name, source, state){
    $.ajax({
        url: '/uuigui/uui/eapp/atoll_pg/deleteColumnTemplate?name=' + name,
        type: 'GET',
        contentType: 'application/json',
        success: function (data) {
            _.remove(optgroups[1].children, {
                value: $('#templateName').val()
            });
            if(source == "deleteOnly"){
                delete solutionTamplateColumnMap[$('#templateName').val()];
                if(page == "version"){
                    resetDefaultList(solutionTamplateColumnMap["ATOLL.CARRIER.VERSION.DEFAULT"], "default", []);
                }else if(page == "tx"){
                    resetDefaultList(solutionTamplateColumnMap["ATOLL.CARRIER.TX.DEFAULT"], "default", []);
                }else{
                    resetDefaultList(solutionTamplateColumnMap["ATOLL.CARRIER.CELL.DEFAULT"], "default", []);
                }
                $('#tamplateSelect').multiselect('dataprovider', optgroups);
                $('#tamplateSelect').val([]);
                $('#tamplateSelect').multiselect('refresh');
                $('#delete_btn').attr('disabled', true);
                $("#deleteSuccessAlert").fadeIn(1000, function() {
                    setTimeout(function() {
                        $("#deleteSuccessAlert").fadeOut(1000);
                    }, 5000);
                });
            }else if(source == "deleteAndUpdate"){
                var templateName = $('#templateName').val().trim();
                UiSettingsSave(name, state);
                $('#save_btn').attr('disabled', true);
                var columns = _.clone(selectedFilterName);
                // update template name dropdown
                var idx = _.findIndex(optgroups[1].children, {value: templateName});
                if(idx < 0){
                    optgroups[1].children.push({label: templateName, value: templateName});
                }
                solutionTamplateColumnMap[templateName] = columns;
                if(page == "version"){
                    resetDefaultList(solutionTamplateColumnMap["ATOLL.CARRIER.VERSION.DEFAULT"], "selected", solutionTamplateColumnMap[templateName]);
                }else if(page == "tx"){
                    resetDefaultList(solutionTamplateColumnMap["ATOLL.CARRIER.TX.DEFAULT"], "selected", solutionTamplateColumnMap[templateName]);
                }else{
                    resetDefaultList(solutionTamplateColumnMap["ATOLL.CARRIER.CELL.DEFAULT"], "selected", solutionTamplateColumnMap[templateName]);
                }
                $('#tamplateSelect').multiselect('dataprovider', optgroups);
                $('#tamplateSelect').val(templateName);
                $('#tamplateSelect').multiselect('refresh');
            }
        },
        error: function (err) {
            $('#loading').hide();
        }
    });
}