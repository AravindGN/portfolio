$(document).ready(function () {
  $('#results-section').hide();
    function validateInteger(value) {
        return /^\d*$/.test(value);
    }

    function validateAlphaNum(value) {
        return /^[a-zA-Z0-9\s_-]*$/.test(value);
    }

    // $('#site-info-id, #site-record-id').on('input', function () {
    //   if($(this).val() === ''){
    //     alert('Please enter some ID.')
    //     $('#site-record-id').val('');
    //   $('#site-name').val('');
    //     return;
    //   }
    // });

    $('#site-name').on('input', function () {
      const siteId = $('#site-info-id').val().trim();
      const recordId = $('#site-record-id').val().trim();
      const nameVal = $(this).val().trim();
      if (siteId === '' && recordId === '') {
      //   if (nameVal === '') {
      //     alert('Please enter site Name.');
      //     $('#site-record-id').val('');
      // $('#site-name').val('');
      //     return;
      //   }
  
      //   if (!validateAlphaNum(nameVal)) {
      //     alert('Only alphanumeric characters allowed.');
      //     $(this).val('');
      //     $('#site-record-id').val('');
      // $('#site-name').val('');
      // $('#site-info-id').val('')
      //   }
      }
    });

    let fullData = [];
  let currentPage = 1;
  const rowsPerPage = 5;

  $('#searchRecords').off('click').on('click', function () {
     fetchSiteRecords();      
  });
  function fetchSiteRecords(){
    $('#loading').show();
    $('#results-section').show();
    const siteRecordId = $('#site-record-id').val().trim();
    const siteName = $('#site-name').val().trim();
    const fuzeSiteId = $('#site-info-id').val().trim();

    if (!siteRecordId && !siteName && !fuzeSiteId) {
      alert("Please enter Site Record ID/Site Record Name");
      $('#site-record-id').val('');
      $('#site-name').val('');
      $('#site-info-id').val('');
      $('#loading').hide();
      return;
    }

    if (siteRecordId && !validateInteger(siteRecordId)) {
      alert("Only numeric values allowed");
      $('#site-record-id').val('');
      $('#site-name').val('');
      $('#site-info-id').val('');
      $('#loading').hide();
      return;
    }

    if (fuzeSiteId && !validateInteger(fuzeSiteId)) {
      alert("Only numeric values allowed");
      $('#site-record-id').val('');
      $('#site-name').val('');
      $('#site-info-id').val('');
      $('#loading').hide();
      return;
    }

    const queryData = {};
    if (siteRecordId) queryData.siteRecordId = siteRecordId;
    if (siteName) queryData.siteName = siteName;
    if (fuzeSiteId) queryData.fuzeSiteId = fuzeSiteId;
    $.ajax({
      url: siteRecordsUrl,
      method: 'GET',
      cache: true,
      data: queryData,
      success: function (response) {
        $('#loading').hide();

        if (response && response.length > 0) {
          fullData = response;
          currentPage = 1;
          loadKendoGrid(fullData); 
        } else {
          alert("No records found for the given input.");
          $('#results-table-body').html('<tr><td colspan="5">No records found</td></tr>');
          $('#pagination').empty();
        }
      },
      error:  function (xhr, status, error) {
        try {
          const errorMessage = JSON.parse(xhr.responseText)?.error?.split('|').pop().trim();
          alert(errorMessage || 'Unexpected error format.');
          $('#loading').hide();
        } catch (e) {
          alert('Failed to fetch records: ' + (xhr.statusText || 'Unknown Error'));
          $('#loading').hide();
        }
      }
    });
  
}
  const columns = [
    {
      // headerTemplate: '<input type="checkbox" id="select-all" />',
      template: '<input type="radio" class="row-checkbox" data-id="#=siteRecordId #"/>',
      width: 40,
      sortable: false,
      filterable: false
    },
    { field: "siteRecordId", title: "Site Record ID" },
    { field: "fuzeSiteId", title: "Fuze Site ID" },
    { field: "version", title: "Version" },
    { field: "siteName", title: "Site Name" }
  ];

  function loadKendoGrid(data) {
    const grid = $("#results-table").data("kendoGrid");

    if (grid) {
      grid.dataSource.data(data); 
    } else {
      $("#results-table").kendoGrid({
        dataSource: {
          data: data,
          pageSize: rowsPerPage,
          schema: {
            data: function (response) {
              return response;
            },
            total: function (response) {
              return response.length;
            }
          }
        },
        pageable: {
          refresh: true,
          pageSizes: [5, 10, 20, 50],
          buttonCount: 5
        },
        columns: columns,
        dataBound: function (){
          $('.row-checkbox').on('change', function () {
            $('.row-checkbox').not(this).prop('checked',false);
            const isChecked = $('.row-checkbox:checked').length > 0;
            $('#restore-button').prop('disabled', !isChecked);
      
            $('#results-table').find(' tbody > tr').css({'background-color':'', 'color':'#000'});
            if($(this).is(':checked')){
              $(this).closest('tr').css({'background-color':'#b00000', 'color':'#fff'});
            }
        });
        }
      });
    }
    


  }

    $('#clearInputs').click(function () {
      $('#site-record-id').val('');
      $('#site-name').val('');
      $('#site-info-id').val('');
      $('#results-section').hide();
      $('#results-table-body').empty();
      $('#siteNameSuggestionsName').hide()
    })

    $('#restore-button').click(function () {
      const selectedRecords = [];
      $('#results-section').show();
      const grid = $("#results-table").data("kendoGrid");
      const allData = grid.dataSource.data(); 
    
      $('.row-checkbox:checked').each(function () {
        const siteRecordId = parseInt($(this).data('id'));
    
        const matchedRecord = allData.find(item => item.siteRecordId === siteRecordId);
    console.log(matchedRecord,"matchedrecord")
        if (matchedRecord) {
          selectedRecords.push({
            siteRecordId: matchedRecord.siteRecordId,
            fuzeSiteId: matchedRecord.fuzeSiteId,
            version: matchedRecord.version,
            schema: matchedRecord.schema,
            siteName:matchedRecord.siteName,
            modifiedBy: userID,
          });
        }
      });
    
      if (selectedRecords.length === 0) {
        alert("Please select at least one record to restore.");
        return;
      }
    
      console.log("Payload:", JSON.stringify(selectedRecords));
      $('#loading').show();
      $('#restore-button').prop('disabled', true);
    
      $.ajax({
        url: restoreRecordsUrl,
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(selectedRecords),
        success: function (response) {
          alert(response.message || "Restored successfully!");
          const restoreIds = selectedRecords.map(rec => rec.siteRecordId);
          fullData = fullData.filter(item => !restoreIds.includes(item.siteRecordId));
          loadKendoGrid(fullData)
        },
        error: function (xhr) {
          try {
            const errorMessage = JSON.parse(xhr.responseText)?.error?.split('|').pop().trim();
            alert(errorMessage || 'Unexpected error format.');
          } catch (e) {
            alert('Failed to fetch records: ' + (xhr.statusText || 'Unknown Error'));
          }
        },
        complete: function () {
          $('#loading').hide();
          $('#restore-button').prop('disabled', false);
        }
      });
    });
    let debounceTimer;

    $('#site-name').on('input', function () {
    clearTimeout(debounceTimer);

    let query = $(this).val().trim(); 
    
    if (query.length === 0) {
        $('#siteNameSuggestionsName').empty().hide();
        return;
      }
      query = query.toUpperCase();
      debounceTimer = setTimeout(() => {
        fetchSiteNameSuggestionsRestore(query);
      }, 300);
    });
    
});
$(document).on('click', function(e){
  if(!$(e.target).closest('#site-name').length && !$(e.target).closest('#siteNameSuggestionsName').length){
    $('#siteNameSuggestionsName').hide()
  }
})
function fetchSiteNameSuggestionsRestore(siteName='') {
  const apiUrl = getAtollGlobalSiteHistoryName;
  let queryParams = [];


  if (siteName) {
    queryParams.push(`siteName=${encodeURIComponent(siteName.toUpperCase())}`);
  }

  const finalUrl = `${apiUrl}?${queryParams.join('&')}`;
  console.log(finalUrl);

  $.ajax({
    url: finalUrl,
    method: 'GET',
    headers: {
      'Accept': 'application/json'
    },
    cache: true,
 
    success: function (data) {
      renderSuggestionsRestore(data);
    },
    error: function () {
      $('#siteNameSuggestionsName').html('<div style="padding:5px;">No results found</div>').show();
    }
  });
}

function renderSuggestionsRestore(data) {
  const $suggestions = $('#siteNameSuggestionsName');
  $suggestions.empty();

  if (!data || data.length === 0) {
    $suggestions.html('<div style="padding:5px;">No suggestions</div>').show();
    return;
  }

  data.forEach(function (item) {
    const $item = $('<div></div>')
      .addClass('suggestion-items')
      .text(item)
      .css({ padding: '5px', cursor: 'pointer' })
      .hover(function () {
        $(this).css('background-color', '#f0f0f0');
      }, function () {
        $(this).css('background-color', '#fff');
      })
      .click(function () {
        $('#site-name').val(item);
        $suggestions.empty().hide();
      });

    $suggestions.append($item);
  
  });

  $suggestions.show();
}
