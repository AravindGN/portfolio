var versionData = []
var atollSchema = ["albuquerque","atlanta","austin","bismarck","bocaraton","boise","carolinas","centralillinois","chicago","cincinnati","cleveland","dallas","denver","desmoines","detroit","dublin","eugene","fargo","hawaii","houston","indianapolis","jacksonville","kansas","lasvegas","losangeles","louisville","milwaukee","minneapolis","montana","nashville","newenglandeast","newenglandwest","newjersey","neworleans","nymetro","nyupstate","orlando","philadelphia","phoenix","pittsburgh","portland","rockford","sacramento","saltlake","sandiego","sanfrancisco","sdakota","seattle","southcentral","spokane","stlouis","tampa","virginia","washington"]
var initialFlag = true;
var Market;
var versionDisplayColumns = [];
var siteAutoAjax;
var fuzeSiteIdGlobal;
var isParamPresentInUrl = false;
var kendoGridManager = {
		stringFilterOperator:
		{
		contains: "Contains",
		startswith: "Starts with",
		eq: "Equal to",
		endswith: "Ends with",
		}
		}

$(document).ready(function(e){
    
    try {
        var env = window.location.href.includes('canvasple') ? '-PLE' : '';
		window.initClickstream({
			"system_name": "Network Planning Platform",
			"app_name": "ATOLL" + env,
			"screen_name": "E911 Report",

			"showLogs": "true"
		});
	} catch (e) {
		return false;
	}

    if (Object.keys(featureToggleMap).includes("F92681") && featureToggleMap['F92681']) {
		$('#isNotCommonSchemaSearch').hide();
		$('#e911ReportLaunchButton').show();
		commonSchemaSearch('commonE911ReportSearchPanel');
        loadAtollRFModules();
	} else {
		$('#isNotCommonSchemaSearch').show();
		$('#e911ReportLaunchButton').hide();
	}
    roles.push("BETA_USER");
    getUserSchema();
    buildVersionGrids(); 
    reloadData();
    $.widget("custom.catautocomplete", $.ui.autocomplete, {
        _create: function() {
            this._super();
            this.widget().menu( "option", "items", "> :not(.ui-autocomplete-category)" );
        },
        _renderMenu: function(ul, items) {
            var self = this;
            var current = "";
            $.each(items, function(index, item) {
                if (item.category != current) {
                    ul.append("<li class='ui-autocomplete-category'>"+item.category+"</li>");
                    current = item.category;
                }
                self._renderItemData(ul,item);
            });
        },
    });
    buildCatauto($('#siteName'));
    buildCatautoSiteVersion($('#siteVersion'));
    $('#atollSchemaDropdown').on('change',function(e){
    	reloadData();
    });
    
    $('#siteName').on('change',function(e){
		buildCatautoSiteVersion($('#siteVersion'));
    });
    $('#searchBtn').click(function(e){
	    	
    	reloadData();
        

    });
    
  

    if(receivedSchema && receivedSchema != ""){
        // call from map page and need to populate data
        $('#atollSchemaDropdown').val(receivedSchema).multiselect("refresh");
        $('#siteName').val(receivedSiteName);
        siteNameGlobal = receivedSiteName;
        $('#searchBtn').attr("disabled", false);
        $("#searchBtn").trigger( "click" );
    }
     $('#loading').hide();
     if (Object.keys(featureToggleMap).includes("F90711") && featureToggleMap['F90711']) {
		if (window.location.href.includes("?")) {
			(localStorage.getItem('atollSchema')) ? routerParams.atollSchema = localStorage.getItem('atollSchema') : '';
			console.log("atollSchemaLocal", routerParams.atollSchema);
			console.log(window.location.href);
			let url = window.location.href;
			let splitUrl = url.split("?");
			let params = (splitUrl[1]) ? splitUrl[1].split('&') : [];
			console.log(params);
			params.forEach(element => {
				if (element) {
					var obj = {};
					var a = element.split("=");
					if (a.length > 0) {
						obj[a[0]] = a[1];
						routerParams = { ...obj, ...routerParams };
					}
				}
			});
			if (routerParams) {
				isParamPresentInUrl = true;
			}
			routerParams["siteVersion"] = (routerParams.siteVersion) ? routerParams.siteVersion.split(",") : [];
			console.log(routerParams);
			if (routerParams.projectNumber) {
                getDataUsingProjectNumber(routerParams.projectNumber);
                updateSiteVersionDropdown(routerParams.projectNumber, 'commonE911ReportSearchPanel');
                routerParams.siteVersion = $('#' + 'commonE911ReportSearchPanel' + 'VersionList').val();
				if (routerParams.siteVersion != null) {
					routerParams.siteVersion = [routerParams.siteVersion[0].split(" ")[0]];
					atollSchemaCommonSearch('commonE911ReportSearchPanel', routerParams.atollSchema, routerParams.fuzeSiteId, routerParams.siteVersion, 'e911Report');
				}
            } else if (routerParams.siteRecordId) {
                getDataUsingSiteRecordId(routerParams.siteRecordId);
            } else {
                setTimeout(() => {
                    atollSchemaCommonSearch('commonE911ReportSearchPanel', routerParams.atollSchema, routerParams.fuzeSiteId, routerParams.siteVersion, 'e911Report');
                }, 200);
            }
		}
	}
});
function getDataUsingSiteRecordId(siteRecordId) {
    $.ajax({
        //url: 'http://localhost:8100/npp-atoll-services/atollUtility/fetchSchemaAndFuzeSiteIdBySiteRecordId?siteRecordId=' + siteRecordId,
        url: fetchSchemaAndFuzeSiteIdBySiteRecordIdURL + siteRecordId,
        dataType: 'json',
        type: "POST",
        async: false,
        success: function(projectData) {
            console.log('roles Data ===>', projectData);
            routerParams.fuzeSiteId = projectData.VZ_SITE_INFO_ID;
            routerParams.atollSchema = projectData.ATOLL_SCHEMA;
            atollSchemaCommonSearch('commonE911ReportSearchPanel', routerParams.atollSchema, routerParams.fuzeSiteId, routerParams.siteVersion, 'e911Report');
        },
        error: function(data) {
            aptAlert('Warning', 'Failed to load data!');
        }
    });
}
function getDataUsingProjectNumber(projectNumber) {
    $.ajax({
        //url: 'http://localhost:8100/npp-atoll-services/atollUtility/fetchSchemaAndFuzeSiteIdByProjectNumber?projectNumber=' + projectNumber,
        url: fetchSchemaAndFuzeSiteIdByProjectNumberURL + projectNumber,
        dataType: 'json',
        type: "POST",
        async: false,
        success: function(projectData) {
            console.log('roles Data ===>', projectData);
            routerParams.fuzeSiteId = projectData.data[0].fuzeSiteIdList[0];
            routerParams.atollSchema = projectData.data[0].schema;
            atollSchemaCommonSearch('commonE911ReportSearchPanel', routerParams.atollSchema, routerParams.fuzeSiteId, routerParams.siteVersion, 'e911Report');
        },
        error: function(data) {
            aptAlert('Warning', 'Failed to load data!');
        }
    });
}
var routerParams = {};
function reloadData(){
	if(document.getElementById('siteName').value == '') {
        fuzeSiteIdGlobal = '';
    }
if (Object.keys(featureToggleMap).includes("F92681") && featureToggleMap['F92681']) {
        console.log(commonSchemaSearchPayload);
       
        var grid = $("#versionGrid").data("kendoGrid");
        
	    grid.dataSource.read({
            "market" :commonSchemaSearchPayload.atollSchema,
	         "siteName":"",
	         "siteVersion": commonSchemaSearchPayload.siteVersion,
              "fuzeSiteId":commonSchemaSearchPayload.siteName
	        });
	    grid.dataSource.page(1);
    } else {
	var grid = $("#versionGrid").data("kendoGrid");
	    grid.dataSource.read({
	     "market" :$('#atollSchemaDropdown').val(),
	         "siteName":$('#siteName').val(),
	         "siteVersion":$('#siteVersion').val(),
	         "fuzeSiteId":fuzeSiteIdGlobal
	        });
	    grid.dataSource.page(1);
	}
}
	

function buildVersionGrids() {
    if($('#versionGrid').data().kendoGrid){
        $('#versionGrid').data().kendoGrid.destroy();
        $('#versionGrid').empty();
    }
     var dataSource = new kendo.data.DataSource({
        type: "data",
        transport: {
            read: {
                url: CONTEXT_PATH + "/uui/eapp/atoll_pg/e911",
                dataType: "json",
                type: "POST"
            },
           parameterMap: function (data, type) {
                $('<div class="k-loading-mask" id="versionLoadSpin" style="width: 100%; height: 100%; top: 0px; left: 0px;"><span class="k-loading-text">Loading...</span><div class="k-loading-image"></div><div class="k-loading-color"></div></div>').appendTo('#versionGrid .k-grid-content');
               if (Object.keys(featureToggleMap).includes("F92681") && featureToggleMap['F92681']) {
                   data.market = commonSchemaSearchPayload.atollSchema,
                       data.siteName = "",
                       data.siteVersion = kendo.stringify(commonSchemaSearchPayload.siteVersion),
                       data.fuzeSiteId = commonSchemaSearchPayload.siteName
               } else {
                   data["market"] = $('#atollSchemaDropdown').val();
                   data["siteVersion"] = $('#siteVersion').val();
                   data["siteName"] = $('#siteName').val();
                   data["fuzeSiteId"] = fuzeSiteIdGlobal;
               }
              	
              	if(data["fuzeSiteId"]!=null && Object.keys(featureToggleMap).includes("F90711") && featureToggleMap['F90711']){
              		data["siteName"] = null;
              	}else{
              		data["fuzeSiteId"] =null;
              	}
              	if (data.filter && data.filter.filters.length>0){
                	
                	for(var i=0 ;i<data.filter.filters.length;i++){
                		let filter=data.filter.filters[i];
                		
                		if(filter.field=='SITE_NAME' ){
                			data["siteName"]=filter.value;
                			data["siteNameOpr"]=filter.operator;
                		}
                		/*if(filter.field=='SITE_VERSION' ){
                			data["siteVersion"]=filter.value;
                			data["siteVersionOpr"]=filter.operator;
                		}*/
                		
                	}
                }
				return data;
            }
        },
        schema: {
            data: function (response) {
                siteVersion = response && response.data[0] && response.data[0].NAME? response.data[0].NAME : "";
                return response.data; // twitter's response is { "statuses": [ /* results  ] }
            },
            total: function (data) {
                // $('#loading').hide();
                return data.totalCount;
            }
        },
		
        pageSize: 50,
        serverPaging: true,
        serverFiltering: true,
        serverSorting: true
		
		
    });
     var exportFlag = false;
    $("#versionGrid").kendoGrid({
		toolbar: [
            "excel"
        ],
        excel: {
            fileName: "E911 Report Export.xlsx",
            allPages: true
        },
        excelExport: function(e) {
        	 if (!exportFlag) {
                 e.sender.hideColumn('SITE_VERSION'); // index of the column you want to exclude
                 e.preventDefault();
                 exportFlag = true;
                 setTimeout(function () {
                     e.sender.saveAsExcel();
                 });
             } else {
                 e.sender.showColumn('SITE_VERSION');
                 exportFlag = false;
                 $(".k-loading-mask").hide();
             }
        },
        autoBind: false,
        height: 500,
        sortable: true,
		scrollable: true,
		//scrollable : scrollable.Virtual(true))
        pageable: {
            pageSizes: [10, 25, 50, 100, 150, 200, 500],
            input: false,
            numeric: false,
            messages :{}
        },
        columns: versionDisplayColumns,
        dataSource: dataSource,
        dataBound: versionDataBound,
        //change: versionGridChange,
       
         columns: [
            {
                "title": "Technology",
                "field": "TECHNOLOGY",
				width: 85,
				filterable: false
				
            },
            {
                "title": "eNodeB/gNB Site Name",
                "field": "ENB_GNBSITENAME",
				width: 120,
				filterable: false
            },
			{
                "title": "4G/5G Cell Name",
                "field": "CELLNAME_4G_5G",
				width: 120,
				filterable: false
            },
			{
                "title": "ECGI/NCGI",
                "field": "ECGI_NCGI",
				width: 110,
            },
            {
                "title": "MCC",
                "field": "VZ_MCC",
				width: 75,
				
            },
			{
                "title": "MNC",
                "field": "VZ_MNC",
				width: 75,
				filterable: false
            },
			{
                "title": "Market Id",
                "field": "MARKET_ID",
				width: 125,
				filterable: false
            },
			{
                "title": "eNodeB/gNB ID",
                "field": "ENODEB_GNBID",
				width:125,
				filterable: false
            },
			{
                "title": "Cell ID",
                "field": "CELLID",
                width: 95,
                filterable: false
            },
			{
                "title": "Sector ID",
                "field": "SECTORID",
                width: 75,
                filterable: false
            },
			{
                "title": "Carrier ID",
                "field": "CARRIERID",
                width: 75,
                filterable: false
            },
			{
                "title": "Band Class",
                "field": "BANDCLASS",
                width: 75,
                filterable: false
            },
			{
                "title": "Azimuth(dez)",
                "field": "AZIMUTH_DEG",
                width: 100,
                filterable: false
            },
			{
                "title": "Antenna Centerline (ft)",
                "field": "ANTENNACENTERLINE",
                width: 85,
                filterable: false
            },
			{
                "title": "E-911 Latitude Degrees (NAD83)",
                "field": "E911_LATITUDE",
                width: 75,
                filterable: false
            },
			{
                "title": "E-911 Longitude Degrees (NAD83)",
                "field": "E911_LONGITUDE",
                width: 85,
                filterable: false
            },
			{
                "title": "E-911 Street Address",
                "field": "E911_STREET_ADDRESS",
                width: 100,
                filterable: false
            },
            {
                "title": "E-911 City",
                "field": "E911_CITY",
                width: 75,
                filterable: false
            },
			{
                "title": "E-911 County",
                "field": "E911_COUNTY",
                width: 75,
                filterable: false
            },
			{
                "title": "E-911 State",
                "field": "E911_STATE",
                width: 75,
                filterable: false
            },
			{
                "title": "E-911 Zip Code",
                "field": "E911_ZIP_CODE",
                width: 85,
                filterable: false
            },
			{
                "title": "E-911 Dispatchable Location",
                "field": "E911_DISPATCHABLE_LOCATION",
                width: 125,
                filterable: false
            },
			{
                "title": "Antenna H-BW (deg)",
                "field": "ANTENNA_H_BW",
                width: 105,
                filterable: false
            },
			{
                "title": "Mechanical Tilt (deg)",
                "field": "MECHANICAL_TILT",
                width: 105,
                filterable: false
            },
			{
                "title": "Antenna Environment",
                "field": "ANTENNA_ENVIRONMENT",
                width: 105,
                filterable: false
            },
            {
                "title": "LTE/5G Total EIRP(W)",
                "field": "LTE_5G_TOTAL_EIRP",
                width: 135,
                filterable: false
            },
            {
                "title": "Average_Sector_Radius (Miles)",
                "field": "AVERAGE_SECTOR_RADIUS",
                width: 155,
                filterable: false
            },
            {
                "title": "Trans-Cell Type",
                "field": "TRANS_CELL_TYPE",
                width: 105,
                filterable: false
            },
            {
          	  "title": "5G Cell Type",
                "field": "FIVEG_CELL_TYPE",
                 width: 135,
                filterable:true,
                
          },
          {
            "title": "gNB Bit Length",
            "field": "GNB_BIT_LENGTH",
            width: 95,
            filterable: false
        }
        ],
        sortable: true,
        filterable: {
            extra: false,
            operators: {
                string: {
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to"
                }
            }
        },
        columnMenu: {
            columns: true
        },
        reorderable: true,
        resizable: true
    });
    $('#versionGrid').find(".k-grid-content").css("height", "300px");
    $('#versionGrid').find(".k-grid-content-locked").css("height", "300px");
    $("a.k-button.k-button-icontext.k-grid-excel").html('<span class="k-icon k-i-file-excel"></span> Export To Excel ');
	
}



var preUid, preTxUid, preCellUid;
function versionDataBound(e){
    $("#versionGrid").data('kendoGrid').select('tr:eq(0)');
    var grid = $("#versionGrid").data("kendoGrid");
    $("#versionLoadSpin").remove();
    //getNewTXData();
    var grid = e.sender;
    $("#versionGrid").find('tbody').find("[role='row']").find('td').on("click", function(e){
    	var grid = $("#versionGrid").data("kendoGrid");
        var row = $(e.target).closest("tr");

		
    });
}

function displayViewManagement(view){
    var url = CONTEXT_PATH + "/uui/eapp/atoll_pg/viewFilterPopup?page=" + view;
    var height = window.innerHeight - 60;
    height = height > 520? 520 : height;
    $('#viewManagerPageIframe').css("height", height);
    $('#viewManagerPageIframe').attr('page', view);
    $('#viewManagerPageIframe').attr('src', url);
    $('#viewManagerPage').show();
    $('#alertMask').show();
}
function backToOriginPage(){
    $('#viewManagerPage').hide();
    $('#solutionSearchPage').show();
    $('#alertMask').hide();
    // update view dropdown value
    if($('#viewManagerPageIframe').attr('page') == "version"){
        getCustomTemplates("ATOLL.CARRIER.VERSION.", "fromPopup", "version");
    }else if($('#viewManagerPageIframe').attr('page') == "version"){
        getCustomTemplates("ATOLL.CARRIER.TX.", "fromPopup", "tx");
    }else{
        getCustomTemplates("ATOLL.CARRIER.CELL.", "fromPopup", "cell");
    }
}
function buildCatautoSiteVersion(element){
    $(element).catautocomplete({
        minLength: 0,
        delay: 600,
        source: function(request, response) {
            $(element).addClass("ui-autocomplete-loading");
            var term = request.term;
            var suggestions = [];
            runSiteVersionAutocomplete(term).then(function(results) {
                if(!results || !results.data || results.data.length == 0){
                    suggestions.push({ label: "Not Found.", value: "Not found.", category: "Site Results" });
                    siteNameGlobal = term;
                    // fuzeSiteIdGlobal = term;
                }else{
                    var obj =  _.map(results.data, function convertResult(result) {
                        return {
                            // label: result.NAME,
                            label: result.VZ_SITE_VERSION,
                            value: result.VZ_SITE_VERSION,
                            siteName: result.VZ_SITE_NAME,
                            fuzeSiteId: result.VZ_SITE_VERSION,
                            category: "Site Version Results",
                        };
                    });
                    suggestions = obj
                }
                response(_.flatten(_.filter(suggestions, Boolean)));
                $(element).removeClass("ui-autocomplete-loading");
            });
        },
        select: function(event, ui) {
            $(element).removeClass("ui-autocomplete-loading");
        }
    });
}
function buildCatauto(element){
    $(element).catautocomplete({
        minLength: 2,
        delay: 600,
        source: function(request, response) {
            $(element).addClass("ui-autocomplete-loading");
            var term = request.term;
            var suggestions = [];
            runSiteAutocomplete(term).then(function(results) {
                if(!results || !results.data || results.data.length == 0){
                    suggestions.push({ label: "Not Found.", value: "Not found.", category: "Site Results" });
                    siteNameGlobal = term;
                    // fuzeSiteIdGlobal = term;
                }else{
                    var obj =  _.map(results.data, function convertResult(result) {
                        return {
                            // label: result.NAME,
                            label: "(" + result.VZ_SITE_INFO_ID + ") " + result.VZ_SITE_NAME,
                            value: result.VZ_SITE_NAME,
                            siteName: result.VZ_SITE_NAME,
                            fuzeSiteId: result.VZ_SITE_INFO_ID,
                            category: "Site Results",
                        };
                    });
                    suggestions = obj
                }
                response(_.flatten(_.filter(suggestions, Boolean)));
                $(element).removeClass("ui-autocomplete-loading");
            });
        },
        select: function(event, ui) {
            $(element).removeClass("ui-autocomplete-loading");
            	fuzeSiteIdGlobal = ui.item.fuzeSiteId;
        }
    });
}
function runSiteVersionAutocomplete(term, response) {
    if(siteAutoAjax){
        siteAutoAjax.abort();
        siteAutoAjax = null;
    }
    term = term.toUpperCase();
    siteAutoAjax =  $.get(CONTEXT_PATH + "/uui/eapp/atoll_pg/siteVersionAutocomplete", { query: term, atollSchema: $('#atollSchemaDropdown').val(), siteName:$('#siteName').val() }).success().error(
        function handleError(error) {
            // console.error("Something went wrong with the site search", error);
            return [];
        }
    );
    return siteAutoAjax;
}
function runSiteAutocomplete(term, response) {
    if(siteAutoAjax){
        siteAutoAjax.abort();
        siteAutoAjax = null;
    }
    term = term.toUpperCase();
    siteAutoAjax =  $.get(CONTEXT_PATH + "/uui/eapp/atoll_pg/siteAutocomplete", { query: term, atollSchema: $('#atollSchemaDropdown').val() }).success().error(
        function handleError(error) {
            // console.error("Something went wrong with the site search", error);
            return [];
        }
    );
    return siteAutoAjax;
}

function getUserSchema(){
	if(roles.indexOf("BETA_USER") >= 0){
        $.each(atollSchema, function(i, v){
            $('#atollSchemaDropdown').append("<option>" + v.toUpperCase() + "</option>");
        });
        $('#atollSchemaDropdown').multiselect({
            includeSelectAllOption: true,
            enableFiltering:true,
            enableCaseInsensitiveFiltering: true,
            buttonClass: 'btn btn-default whitebg btn-sm',
            numberDisplayed: 1
        });
    }else{
        $.ajax({
            url: '/uuigui/uui/eapp/atoll_pg/getUserSchemas',
            type: 'GET',
            contentType: 'application/json',
            success: function (data) {
                data = data && data.data? data.data : [];
                $.each(data, function(i, v){
                    $('#atollSchemaDropdown').append("<option>" + v.SCHEMA + "</option>");
                });
                $('#atollSchemaDropdown').multiselect({
                    includeSelectAllOption: true,
                    enableFiltering:true,
                    enableCaseInsensitiveFiltering: true,
                    buttonClass: 'btn btn-default whitebg btn-sm',
                    numberDisplayed: 1
                });
            }
        });
    }
}
function e911ReportResetClick() {
    clearCommonSearchDropdown();
    buildVersionGrids(); 
    reloadData();
}
