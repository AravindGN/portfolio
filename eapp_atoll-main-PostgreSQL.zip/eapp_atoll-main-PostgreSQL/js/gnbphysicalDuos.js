var fiveGVirtualDataSource = new kendo.data.DataSource({
	data: [],
});
var carrierLteDataSource = new kendo.data.DataSource({
	data: [],
});
var physicalSampledata;
var getAtollSchemaMarkets;
var marketIdOrName;
let fetchPhy5gGnbs = [];
let physicalMarket5g = "";
var assignedCellPercentCapChng;
var getIndex;
var sectorCarrierLteData = []
var lteSelData;
var cranHubNameHide;


var cranHubNameHide = false;
var carrierLteGridColumns = [
	{
		"title": geolabelDetail(),
		"field": "market",

		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "70px",

		editable: () => false
	},
	{
		"title": "Fuze Site ID",
		"field": "siteFUZEID",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "90px",
		template: function(dataItem) {

			if (dataItem.enbsectorcarrier.siteFUZEID == '<Multiple>')
				return '&ltMultiple&gt';
			else if (dataItem.enbsectorcarrier.siteFUZEID == null || dataItem.enbsectorcarrier.siteFUZEID == 'null') {
				return '';
			}
			return dataItem.enbsectorcarrier.siteFUZEID;
		},
		editable: () => false
	},
	{
		"title": "Site Name",
		"field": "siteName",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "80px",
		template: function(dataItem) {
			if (dataItem.enbsectorcarrier.siteName == '<Multiple>')
				return '&lt;Multiple&gt;';
			else if (dataItem.enbsectorcarrier.siteName == null || dataItem.enbsectorcarrier.siteName == 'null') {
				return '';
			}
			return dataItem.enbsectorcarrier.siteName;
		},
		editable: () => false
	},
	{
		"title": "Site Version",
		"field": "siteVersion",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "60px",
		template: function(dataItem) {
			if (dataItem.enbsectorcarrier.siteVersion == null || dataItem.enbsectorcarrier.siteVersion == 'null') {
				return '';
			} else {
				return dataItem.enbsectorcarrier.siteVersion;
			}

		},
		editable: () => false
	},
	{
		title: "Vendor",
		field: "vendor",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		width: "80px",
		template: function(dataItem) {
			if (dataItem.vendor == null || dataItem.vendor == 'null')
				return '';
			else
				return dataItem.vendor;
		},
		editable: () => false
	},
	{
		title: "eNB",
		field: "eNB",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		width: "80px",
		template: function(dataItem) {

			if (dataItem.eNB == null || dataItem.eNB == 'null')
				return '';
			else
				return dataItem.eNB;

		},
		editable: () => false
	},
	{
		"title": "Sector",
		"field": "sector",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "80px",
		template: function(dataItem) {
			if (dataItem.sector == null || dataItem.sector == 'null')
				return '';
			else
				return dataItem.sector;
		},
		editable: () => false
	},
	{
		"title": "Carrier",
		"field": "carrier",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "80px",
		template: function(dataItem) {
			if (dataItem.carrier == null || dataItem.carrier == 'null')
				return '';
			else
				return dataItem.carrier;

		},
		editable: () => false
	},
	{
		"title": "Frequency Band",
		"field": "frequencyBand",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "80px",
		template: function(dataItem) {
			if (dataItem.frequencyBand == null || dataItem.frequencyBand == 'null')
				return '';
			else
				return dataItem.frequencyBand;
		},
		editable: () => false
	},
	{
		"title": "Center Channel",
		"field": "centreChannel",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "80px",
		template: function(dataItem) {
			if (dataItem.centreChannel == null || dataItem.centreChannel == 'null')
				return '';
			else
				return dataItem.centreChannel;

		},
		editable: () => false
	},
	{
		"title": "BW",
		"field": "bw",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "60px",
		template: function(dataItem) {
			if (dataItem.bw == null || dataItem.bw == 'null')
				return '';
			else
				return dataItem.bw;
		},
		editable: () => false
	},
	{
		"title": "Status",
		"field": "status",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "60px",
		template: function(dataItem) {
			if (dataItem.status == null || dataItem.status == 'null')
				return '';
			else
				return dataItem.status;
		},
		editable: () => false
	},
	{
		"title": "Hub Name",
		"field": "cranHubName",
		"filterable": {
			"cell": {
				"operator": "contains",
				"suggestionOperator": "contains"
			}
		},
		"width": "60px",
		template: function(dataItem) {
			if (dataItem.cranHubName == null || dataItem.cranHubName == 'null')
				return '';
			else
				return dataItem.cranHubName;
		},
		editable: () => false,
		hidden: cranHubNameHide
	}
];
function getAtollMarketDb(selectAtollSchema) {

	$.ajax({
		async: false,
		url: getAtollSchemaMarketsURL + selectAtollSchema,
		// url: "http://localhost:8100/npp-atoll-services/atollUtility/getAtollSchemaMarkets?atollSchema="+selectAtollSchema,
		dataType: 'json',
		type: "POST",
		contentType: 'application/json; charset=UTF-8',
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function(data) {
			getAtollSchemaMarkets = data;
		},
		error: function(data) {
			aptAlert('error', 'Failed to load Market Data');
			$("#atollMarketDb").multiselect("disable");
		}
	});
	$('#atollMarketDb').html('');
	$('#atollMarketDb').multiselect('destroy');
	if (Object.keys(featureToggleMap).includes("F79052") && featureToggleMap['F79052']) {
		marketIdOrName = getAtollSchemaMarkets[0].lteMarketId;
	}
	for (var i in getAtollSchemaMarkets) {
		$('#atollMarketDb').append("<option value='" + getAtollSchemaMarkets[i].lteMarketId + "' class='multis'>" + getAtollSchemaMarkets[i].lteMarketId + " - " + getAtollSchemaMarkets[i].lteMarketName + "</option>");
	}
	$('#atollMarketDb').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		numberDisplayed: 1,

	});
	$("#atollMarketDb").multiselect("disable");
}
$('#atollMarketDb').change(function() {
	marketIdOrName = $('#atollMarketDb').val();
	rightSidePanelResultSet();
		// fetchGnbDUNumbers='';
		// fetchGnbIdRows='';
		// assignmentEnodeData='';
		atollData='';
		virtualFiveGData='';
		fivegfetchGnbIdRows='';
		$("#fiveGVirtualView").hide();
		$("#fiveGVirtualDuIdss").hide();
		$("#showFiveGphysicalduids").hide();
		$('#lteSectorResults').show();
		$("#carrierLteGrid").show();
		$("#eNodeBLteDrillView").show();
	if (getIndex == '1') {
		$("#marketLTETabs").hide();
		$("#physicalTabView").hide();
		rightSidePanelResultSet();
	} else if (getIndex == '2') {
		$("#marketLTETabs").hide();
		fiveGphyiscalView();
	} else if (getIndex == '3') {
		$("#physicalTabView").hide();
		getLTETabView();
	}
});

$('#atollUpdateRightSiteVersion').change(function() {
	rightSiteVersion = $('#atollUpdateRightSiteVersion').val();
	gnbAtollFlag=false
	atollData=''
	if(rightSiteVersion){
	fivegfetchGnbIdRows=''
	$("#fiveGVirtualView").hide();
	$("#fiveGVirtualDuIdss").hide();
	if (getIndex == '1') {
		$("#marketLTETabs").hide();
		$("#physicalTabView").hide();
		rightSidePanelResultSet();
	} else if (getIndex == '2') {
		$("#marketLTETabs").hide();
		fiveGphyiscalView();
	} else if (getIndex == '3') {
		$("#physicalTabView").hide();
		getLTETabView();
	}
}else {
	assignmentData=''
	assignmentEmptyTable("#assignFiveGVirtualGrid", assignmentData, assignmentGridColumns)
	// $("#physicalTabView").hide();
	$("#fiveGVirtualView").hide();
	$("#fiveGVirtualDuIdss").hide();
	$("#physicalTabView").hide();
	$("#marketLTETabs").hide()
	$("#showFiveGphysicalduids").hide()


	alert('Kindly select at least one Site Version');
}
});

function carrierLteEmptyTable() {

	$("#carrierLteGrid").kendoGrid({
		dataSource: carrierLteDataSource,
		columns: carrierLteGridColumns,
		sortable: true,
		filterable: {
			extra: false,
			operators: {
				string: {
					startswith: "Starts with",
					eq: "Is equal to",
					neq: "Is not equal to"
				}
			}
		},
		pageable: {
			pageSizes: 5,
			input: true,
			numeric: false,
			pageSizes: [25, 50, 75, 100, 150, 200, "All"]

		},
		change: function() {
		},
		dataBound: function(e) {

		},
		noRecords: {
			template: "<div style='font-size:12px;color:red'>No data available</div>"
		},

	});
	grid1 = $("#carrierLteGrid").data("kendoGrid");
}

var fetchFiveVirtualGnbDUNumbers = [];
var fiveGVirtualGnbData = [];
var fiveGVirtualCsvData = [];

var virtualDuIds = [];
var five5GIndex;
var fivegfetchGnbIdRows;
var atollData;
function populate5GTables(five5GIndex) {

	if (five5GIndex == "0") {
		getIndex = five5GIndex;
		$("#assignFiveGVirtualGrid").hide();
		$("#exportToExcelLte").hide();
		$("#lteSectorexportToExcel").hide();
	} else if (five5GIndex == "1") {
		rightSidePanelResultSet();
		getIndex = five5GIndex;
		fiveGVirtualFlag=true;
		$("#hideHeaderNames").show();
		$("#assignFiveGVirtualGrid").show();
		$("#exportToExcelLte").hide();
		$("#lteSectorexportToExcel").hide();
		$("#fiveGVirtualGridToolbar").show();
		$("#errGnbView").hide();
		$("#marketLTETabs").hide();
		$("#physicalTabView").hide();
		$("#fiveGVirtualGnbView").show();
		$("#showFiveGphysicalduids").hide();
		if(virtualFiveGData&&gnbAtollFlag){
			$("#fiveGVirtualView").show();
			$("#fiveGexportToExcel").show();
			$("#fiveGVirtualDuIdss").show();
			$("#fiveGSectorexportToExcel").show();
		}

	} else if (five5GIndex == "2" && phyLteFlag) {
		getIndex = five5GIndex;
		fiveGVirtualFlag=false;
		$("#fiveGVirtualGridToolbar").hide();
		$("#assignFiveGVirtualGrid").hide();
		$("#marketLTETabs").hide();
		$("#fiveGVirtualDuIdss").hide();
		$("#fiveGVirtualView").hide();
		$("#exportToExcelLte").hide();
		$("#lteSectorexportToExcel").hide();
		fiveGphyiscalView();
		if(fivegfetchGnbIdRows){
			$("#showFiveGphysicalduids").show();
			$('#fiveGphysicalSectorExportToExcel').show();
		}
		else if (!fivegfetchGnbIdRows) {
			$("#showFiveGphysicalduids").hide();

		}

	} else if (five5GIndex == "3" && phyLteFlag) {
		fiveGVirtualFlag=false;
		getIndex = five5GIndex;
		$("#fiveGVirtualGridToolbar").hide();
		$("#assignFiveGVirtualGrid").hide();
		$("#fiveGVirtualGnbView").hide();
		$("#fiveGVirtualDuIdss").hide();
		$("#hideHeaderNames").hide();
		$("#marketLTETabs").show();
		$("#physicalTabView").hide();
		$("#showFiveGphysicalduids").hide();
		$("#exportToExcelLte").show();
		$("#lteSectorexportToExcel").show();
		getLTETabView();
		if(atollData){
			$('#lteSectorResults').show();
			$("#carrierLteGrid").show();
			$("#eNodeBLteDrillView").show();
		}
	} else {
		$("#fiveGVirtualGridToolbar").hide();
		alert("Please Select search criteria and Click on Search");
		document.querySelector('#atollSearchCriteria ul li.active').classList.remove('active');
		$('#5GVirtualTab-tab').addClass('active');

		$("#assignFiveGVirtualGrid").hide();
	}
}
function fiveGphyiscalView() {
	if(tabIndexGnbAtollUpdate == 1) {
		loadGnbIdsDrillView();
	} else if(tabIndexGnbAtollUpdate == 3) {
		loadGnbIdsDrillView();
	}
	if(($("#atollUpdateRightSiteVersion").val())){
	$("#physicalTabView").show();
    $('#exportToExcelPh5gGnbView').show();
	}
}

function showFiveGPhysicalFirst() {
	current_page = 1;
	$("#fiveGPhysicaldusRows1").show();
	$("#fiveGPhysicaldusRows2").hide();
	$("#fiveGPhysicaldusRows3").hide();
	$("#fiveGPhysicaldusRows4").hide();
	$("#fiveGPhysicaldusRows5").hide();
	$("#fiveGPhysicaldusRows6").hide();
	$("#fiveGPhysicaldusRows7").hide();
	$("#fiveGPhysicaldusRows8").hide();
	$("#fiveGPhysicaldusRows9").hide();
	$("#fiveGPhysicaldusRows10").hide();
}
function showFiveGPhysicalSecond() {
	current_page = 2;
	$("#fiveGPhysicaldusRows1").hide();
	$("#fiveGPhysicaldusRows2").show();
	$("#fiveGPhysicaldusRows3").hide();
	$("#fiveGPhysicaldusRows4").hide();
	$("#fiveGPhysicaldusRows5").hide();
	$("#fiveGPhysicaldusRows6").hide();
	$("#fiveGPhysicaldusRows7").hide();
	$("#fiveGPhysicaldusRows8").hide();
	$("#fiveGPhysicaldusRows9").hide();
	$("#fiveGPhysicaldusRows10").hide();
}
function showFiveGPhysicalThird() {
	current_page = 3;
	$("#fiveGPhysicaldusRows1").hide();
	$("#fiveGPhysicaldusRows2").hide();
	$("#fiveGPhysicaldusRows3").show();
	$("#fiveGPhysicaldusRows4").hide();
	$("#fiveGPhysicaldusRows5").hide();
	$("#fiveGPhysicaldusRows6").hide();
	$("#fiveGPhysicaldusRows7").hide();
	$("#fiveGPhysicaldusRows8").hide();
	$("#fiveGPhysicaldusRows9").hide();
	$("#fiveGPhysicaldusRows10").hide();
}
function showFiveGPhysicalFourth() {
	current_page = 4;
	$("#fiveGPhysicaldusRows1").hide();
	$("#fiveGPhysicaldusRows2").hide();
	$("#fiveGPhysicaldusRows3").hide();
	$("#fiveGPhysicaldusRows4").show();
	$("#fiveGPhysicaldusRows5").hide();
	$("#fiveGPhysicaldusRows6").hide();
	$("#fiveGPhysicaldusRows7").hide();
	$("#fiveGPhysicaldusRows8").hide();
	$("#fiveGPhysicaldusRows9").hide();
	$("#fiveGPhysicaldusRows10").hide();
}
function showFiveGPhysicalFifth() {
	current_page = 5;
	$("#fiveGPhysicaldusRows1").hide();
	$("#fiveGPhysicaldusRows2").hide();
	$("#fiveGPhysicaldusRows3").hide();
	$("#fiveGPhysicaldusRows4").hide();
	$("#fiveGPhysicaldusRows5").show();
	$("#fiveGPhysicaldusRows6").hide();
	$("#fiveGPhysicaldusRows7").hide();
	$("#fiveGPhysicaldusRows8").hide();
	$("#fiveGPhysicaldusRows9").hide();
	$("#fiveGPhysicaldusRows10").hide();
}
function showFiveGPhysicalNext() {
	if (current_page == 1)
		showFiveGPhysicalSecond();
	else if (current_page == 2)
		showFiveGPhysicalThird();
	else if (current_page == 3)
		showFiveGPhysicalFourth();
	else if (current_page == 4)
		showFiveGPhysicalFifth();
	else if (current_page == 5)
		showFiveGPhysicalFifth();
	else
		showFiveGPhysicalSecond();
}
function showFiveGPhysicalPrevious() {
	if (current_page == 1)
		showfiveGPhysicalFirst();
	else if (current_page == 2)
		showfiveGPhysicalFirst();
	else if (current_page == 3)
		showFiveGPhysicalSecond();
	else if (current_page == 4)
		showFiveGPhysicalThird();
	else if (current_page == 5)
		showFiveGPhysicalFourth();
}
function goToPage(pageNumber,totalPages){
	current_page = pageNumber;
	if(current_page == 1){
		showfiveGPhysicalFirst()
	}else{
	for(let i =1 ; i<= totalPages;i++){
		const rows = document.querySelectorAll(`#fiveGPhysicaldusRows${i}`);
		if(rows) {
			rows[0].style.display = (i === pageNumber) ? 'block' :'none';
		}
	}
	}
}
function expandTableSize() {
	$(".jexcel_content").css("height", "auto");
}
function resetTableSize() {
	var resetTableSizeVirtualView = $("virtualAssignmentGridInfo table tr").length;

	if (resetTableSizeVirtualView > 7) {
		$("#virtualAssignmentGridInfo .jexcel_content").css("height", "200px");
	}
	else {
		$("#virtualAssignmentGridInfo .jexcel_content").css("height", "auto");
	}
}
function removeSpreadsheetFiltersFromSplitView() {
	spreadsheetTransmitterObj.resetFilters();
}
var fetchGnbIdRows;
function selectPhysicalDuId(getPhysicalduId, phySite, phySVersion, phySFId) {
	if ((Object.keys(featureToggleMap).includes("F90277") && featureToggleMap['F90277'])) {
		document.querySelectorAll("#physicalDus1").forEach(el => el.className = "geohierarchydiv");
		document.querySelectorAll("#singlePhysicaLayout").forEach(el => el.className = "geohierarchydiv");
		 document.querySelectorAll("#erricssonGnbSectorHeader").forEach(el => el.className = "geohierarchydiv");
		document.querySelectorAll("#erricssonSectorHeader").forEach(el => el.className = "geohierarchydiv");

		} else {
			document.querySelectorAll("#physicalDus1").forEach(el => el.removeClass = "geohierarchydiv");
			document.querySelectorAll("#singlePhysicaLayout").forEach(el => el.removeClass = "geohierarchydiv");
			document.querySelectorAll("#erricssonGnbSectorHeader").forEach(el => el.className = "geohierarchydiv");
			document.querySelectorAll("#erricssonSectorHeader").forEach(el => el.removeClass = "geohierarchydiv");

		}
	gnbID = getPhysicalduId;
	console.log(getPhysicalduId, phySite, phySVersion, phySFId);
	if (tabIndexGnbAtollUpdate == 1) {
	document.getElementById("phGnodebId").innerHTML = getPhysicalduId;
	document.getElementById("phGnodebVendor").innerHTML = 'Ericsson';
	document.getElementById("phMarket").innerHTML = getMarketName[1];

	if (phySite == 'null' || phySite == null) {
		document.getElementById("phySiteName").innerHTML = '';
	} else {
		document.getElementById("phySiteName").innerHTML = phySite;
	}
	if (phySVersion == 'null' || phySVersion == null) {
		document.getElementById("phySiteVersion").innerHTML = '';
	} else {
		document.getElementById("phySiteVersion").innerHTML = phySVersion;
	}
	if (phySFId == 'null' || phySFId == null) {
		document.getElementById("phySiteFId").innerHTML = '';
	} else {
		document.getElementById("phySiteFId").innerHTML = phySFId;
	}
	$('#showphysicalduids').show();
	$("#showVirtualDuIdss").hide();

	window.scrollTo(0, document.getElementById("showphysicalduids").scrollHeight);
	$('html, body').animate({
		scrollTop: $("#showphysicalduids").offset().top
	}, "slow");

	document.getElementById("physicalDus1").outerHTML = "<div class='containerSinglePhycal' id='physicalDus1'></div>";
	document.getElementById("physicalDus2").outerHTML = "<div class='containerSinglePhycal' id='physicalDus2'></div>";

	var phycallPayload = {
		"marketName": marketsSelected,
		"vzGnodebId": getPhysicalduId,
		"vendor": "Ericsson",
		"fR2": "",
		siteVersions: [phySVersion]
	}

	} else {

		fiveGphySite = phySite;
		fiveGphySVersion = phySVersion;
		fiveGphySFId = phySFId;
		document.getElementById("fiveGphGnodebId").innerHTML = getPhysicalduId;
		document.getElementById("fiveGphGnodebVendor").innerHTML = 'Ericsson';
		document.getElementById("fiveGphMarket").innerHTML = marketIdOrName;

		if (fiveGphySite == 'null' || fiveGphySite == null) {
			document.getElementById("fiveGphySiteName").innerHTML = '';
		} else {
			document.getElementById("fiveGphySiteName").innerHTML = fiveGphySite;
		}
		if (fiveGphySVersion == 'null' || fiveGphySVersion == null) {
			document.getElementById("fiveGphySiteVersion").innerHTML = '';
		} else {
			document.getElementById("fiveGphySiteVersion").innerHTML = fiveGphySVersion;
		}
		if (fiveGphySFId == 'null' || fiveGphySFId == null) {
			document.getElementById("fiveGphySiteFId").innerHTML = '';
		} else {
			document.getElementById("fiveGphySiteFId").innerHTML = fiveGphySFId;
		}
		$('#showphysicalduids').hide();
		// $("#showVirtualDuIdss").show();
		$("#showFiveGphysicalduids").show();
		$('#fiveGphysicalSectorExportToExcel').show();

		window.scrollTo(0, document.getElementById("singlePhysicaLayout").scrollHeight);
	$('html, body').animate({
		scrollTop: $("#singlePhysicaLayout").offset().bottom
	}, "slow");

		document.getElementById("fiveGphysicalDus1").outerHTML = "<div class='containerSingleFiveGPhycal' id='fiveGphysicalDus1'></div>";
		document.getElementById("fiveGphysicalDus2").outerHTML = "<div class='containerSingleFiveGPhycal' id='fiveGphysicalDus2'></div>";
		var phycallPayload = {
			atollSchema: sechmaList,
			marketName:marketIdOrName,
			vzGnodebId: getPhysicalduId,
			vendor: "Ericsson",
			siteVersions: [fiveGphySVersion]

		}
	}


	$.ajax({
		type: 'POST',
		async: false,
		//url: "http://localhost:8100/npp-atoll-services/enbgnbAssignment/getVirtualandPhysicalGNBSecAssignments",
		url: getVirtualandPhysicalGNBSecAssignmentsUrl,
		dataType: 'json',
		contentType: 'application/json; charset=UTF-8',
		cache: false,
		data: JSON.stringify(phycallPayload),
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function(data) {
			physicalGnbSectorViewData = data.SectorList;
			if(tabIndexGnbAtollUpdate==1){
				gnbphysicalGnbSectorViewData=physicalGnbSectorViewData;
			}
			physicalSampledata = data.SectorList;
			var fetchGnbIdslength = physicalSampledata.length;
			fetchGnbIdRows = Math.ceil(fetchGnbIdslength / 25);
			if(tabIndexGnbAtollUpdate==3){
				fivegfetchGnbIdRows=fetchGnbIdRows;
			}
				$('#physicalSectorExportToExcel').show();



			if (fetchGnbIdRows <= 40) {
				// $("#showHidePage").hide();
				var flag = false;
				for (var i = 0; i < fetchGnbIdRows; i++) {
					var sId = tabIndexGnbAtollUpdate == 1 ? "seatingrowPhysicaldu" + i : "seatingFiveGPhysicalSector" + i;
					if (tabIndexGnbAtollUpdate == 1) {
					$("#physicalDus1").append('<div class="seatingrowPhysicaldu" id="' + sId + '" style="text-align:center; display: flex;"></div>');
					} else {
						$("#fiveGphysicalDus1").append('<div class="seatingFiveGPhysicalSector" id="' + sId + '" style="text-align:center; display: flex;"></div>');
					}
					for (var j = 1; j <= 25; j++) {
						if (j + i * 25 > fetchGnbIdslength) {
							flag = true;
							break;
						}
						if (physicalSampledata[j - 1 + i * 25].status == "On Air") {
							$("#" + sId).append('<div class="onAir" id="showtooltip"  data-title="SiteName:' + physicalSampledata[j - 1 + i * 25].siteName + '\nSiteVersion: ' + physicalSampledata[j - 1 + i * 25].siteVersion + '\nFuzeSiteId: ' + physicalSampledata[j - 1 + i * 25].siteFuzeId + '\nHub Name: ' + physicalSampledata[j - 1 + i * 25].cranHubName +'">' + physicalSampledata[j - 1 + i * 25].sector + ' </div>');

						} else if (physicalSampledata[j - 1 + i * 25].status == "Assigned") {
							$("#" + sId).append('<div class="assigned" id="showtooltip"  data-title="SiteName:' + physicalSampledata[j - 1 + i * 25].siteName + '\nSiteVersion: ' + physicalSampledata[j - 1 + i * 25].siteVersion + '\nFuzeSiteId: ' + physicalSampledata[j - 1 + i * 25].siteFuzeId + '\nHub Name: ' + physicalSampledata[j - 1 + i * 25].cranHubName +'">' + physicalSampledata[j - 1 + i * 25].sector + ' </div>');
						} else {
							$("#" + sId).append('<div class="avliable">' + physicalSampledata[j - 1 + i * 25].sector + ' </div>');
						}

					}
					if (flag) {
						break;
					}
				}
			}
		}, error: function(response) {
			$('#loading').hide();
			aptAlert('error', 'failed');
		}
	});
}
function selectFiveGPhysicalDus(getFiveGPhysicalduId, fiveGphySite, fiveGphySVersion, fiveGphySFId) {
	selectPhysicalDuId(getFiveGPhysicalduId, fiveGphySite, fiveGphySVersion, fiveGphySFId);


}
var marketLteTabeOne;
var marketLteTabeTwo;
var marketLteTabeThree;
var fetchLteMOneData;
var fetchLteMTwoData;
var fetchLteMThreeData;
var getMarketNum;
let lteValues = [];
var lteValueKeys = [];
function getLTETabView() {
	// enbSecTabData='';
if ((Object.keys(featureToggleMap).includes("F90277") && featureToggleMap['F90277'])) {
		document.querySelectorAll("#marketLTETabs").forEach(el => el.className = "geohierarchydiv1");
		  document.querySelectorAll("#dusMarketRows1").forEach(el => el.className = "geohierarchydiv");

		} else {
			document.querySelectorAll("#marketLTETabs").forEach(el => el.removeClass = "geohierarchydiv");
		     document.querySelectorAll("#dusMarketRows1").forEach(el => el.removeClass = "geohierarchydiv");

		}
	$("#assignFiveGVirtualGrid").hide();
	$("#fiveGVirtualDuIdss").hide();
	$("#fiveGVirtualView").hide();
	$("#eNodeBLteDrillView").hide();
	$("#carrierLteGrid").hide();
	$("#lteSectorResults").hide();
	$("#showMarketTabs li").removeClass('active');
	$("#showMarketTabs li:first").addClass('active');
	document.getElementById("marketLteIdOne").innerHTML = '';
	document.getElementById("marketLteIdTwo").innerHTML = '';
	document.getElementById("marketLteIdThree").innerHTML = '';

	result2Keys=[];
	var enBAssignmentPayload = {

		atollSchema: sechmaList,
		marketName: marketIdOrName,
		vzEnodebId: "",
		siteVersions:$("#atollUpdateRightSiteVersion").val()
	};

	$("#marketLTETabs").show();
	document.getElementById("lteMarketRows1").outerHTML = "<div class='containerLteMarketseating' id='lteMarketRows1'></div>";
	$.ajax({
		type: 'POST',
		async: false,
		//url: "http://localhost:8100/npp-atoll-services/enbgnbAssignment/getENBAssignments",
		url: getENBAssignmentsUrl,
		dataType: 'json',
		contentType: 'application/json; charset=UTF-8',
		cache: false,
		data: JSON.stringify(enBAssignmentPayload),
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function(data) {
			if (data.ERROR) {
				$("#marketLTETabs").hide();
				alert("MarketId is not Found");
			} else {


				 lteKeys = Object.keys(data);
				 lteKeyVal = Object.values(data);
				 enbAssignmentAtollUpdateLteCommonView();

			}

		}, error: function(response) {
			$('#loading').hide();
			$("#marketLTETabs").hide();
			if(($("#atollUpdateRightSiteVersion").val())==null){
				alert('Kindly select at least one Site Version');

			}else{
			aptAlert('error', 'failed');
			}
		}
	});

}
var fetchLteBoxId;
var sectorCarrierLteTabData = [];
function SectorCarrierLteView(boxLteId, selectedMarketId, siteVersion) {

	if ((Object.keys(featureToggleMap).includes("F90277") && featureToggleMap['F90277'])) {
		document.querySelectorAll("#eNodeBLteDrillView").forEach(el => el.className = "geohierarchydiv");

		} else {
			document.querySelectorAll("#eNodeBLteDrillView").forEach(el => el.removeClass = "geohierarchydiv");

		}
	fetchLteBoxId = boxLteId;
		$('#lteSectorResults').show();

	var updatedMarketList = [];
	updatedMarketList = [marketLteTabeOne, marketLteTabeTwo, marketLteTabeThree];

	if (updatedMarketList.length > 0) {
		marketIdOrName = updatedMarketList[selectedMarketId];
		getMarketNum = updatedMarketList[selectedMarketId];
	}

	sectorCarrirLtePayload = {
		atollSchema: sechmaList,
		marketName: marketLteTabeOne,
		validationFlag: [],
		vzEnodebId: getMarketNum + fetchLteBoxId,
		siteVersions: [siteVersion]
	};

	lteSelData = getMarketNum + fetchLteBoxId;
	$.ajax({
		type: 'POST',
		async: false,
		//url: "http://localhost:8100/npp-atoll-services/enbgnbAssignment/getSectorCarrierAssignments",
		url: getSectorCarrierAssignmentsURL,
		dataType: 'json',
		contentType: 'application/json; charset=UTF-8',
		cache: false,
		data: JSON.stringify(sectorCarrirLtePayload),
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function(data) {

			var carrierLteData = data;
			sectorCarrierLteData = carrierLteData.SectorCarrierDetails;
			sectorCarrierLteTabData = data.SectorCarrier;
			carrierLteEmptyTable();
			$("#carrierLteGrid").show();
			$("#eNodeBLteDrillView").show();
			window.scrollTo(0, document.getElementById("carrierLteGrid").scrollHeight);
			$('html, body').animate({
				scrollTop: $("#carrierLteGrid").offset().top
			}, "slow");
			$('#carrierLteGrid')
				.getKendoGrid()
				.setDataSource(
					new kendo.data.DataSource({
						pageSize: 25,
						data: carrierLteData.SectorCarrier,
					})
				);


			document.getElementById("dusLteRows1").outerHTML = "<div class='lteEnbseating' id='dusLteRows1'></div>";
			if (!sectorCarrierLteData) {
				alert("MarketId is not Found");
				$("#enodeAssignmentGrid").hide();
				$("#eNodeBDrillView").hide();
				$('#loading').fadeOut();
			} else {


				var drillSampleDatalength = sectorCarrierLteData.length;
				var fetchGnbDUSRows = Math.ceil(drillSampleDatalength / 10);

				if (fetchGnbDUSRows <= 26) {
					$("#showHidePage").hide();
					var flag = false;
					for (var i = 0; i < fetchGnbDUSRows; i++) {
						var sId = "lteSeatinenBrow" + i;
						$("#dusLteRows1").append('<div class="lteSeatinenBrow" id="' + sId + '" style="text-align:center"></div>');
						for (var j = 1; j <= 10; j++) {
							if (j + i * 10 > drillSampleDatalength) {
								flag = true;
								break;
							}
							if (sectorCarrierLteData[j - 1 + i * 10].status == "On Air") {
									$("#" + sId).append('<div class="onAir" id="onAirtooltip"  data-title="SiteName: ' + sectorCarrierLteData[j - 1 + i * 10].siteName + '\nSiteVersion: ' + sectorCarrierLteData[j - 1 + i * 10].siteVersion + '\nFuzeSiteId: ' + sectorCarrierLteData[j - 1 + i * 10].siteFUZEID + '\nHubName: ' + sectorCarrierLteData[j - 1 + i * 10].cranHubName + '">' + sectorCarrierLteData[j - 1 + i * 10].sectorCarrier + ' </div>');
								} else if (sectorCarrierLteData[j - 1 + i * 10].status == "Assigned") {
									$("#" + sId).append('<div class="assigned" id="assignedtooltip"  data-title="SiteName: ' + sectorCarrierLteData[j - 1 + i * 10].siteName + '\nSiteVersion: ' + sectorCarrierLteData[j - 1 + i * 10].siteVersion + '\nFuzeSiteId: ' + sectorCarrierLteData[j - 1 + i * 10].siteFUZEID + '\nHubName: ' + sectorCarrierLteData[j - 1 + i * 10].cranHubName + '">' + sectorCarrierLteData[j - 1 + i * 10].sectorCarrier + ' </div>');
								} else {
									$("#" + sId).append('<div class="avliable" onclick="avliableEnbDuId()">' + sectorCarrierLteData[j - 1 + i * 10].sectorCarrier + ' </div>');
								}

						}

						if (flag) {
							break;
						}
					}
				}

			}

		},

		error: function(data) {
			alert("No Data SectorCarrier View");
			$("#carrierLteGrid").hide();
			$("#eNodeBLteDrillView").hide();

		}
	});
}
function exportToExcelPhysicalSector(jsonObject, fileName, gnodeBId) {
	let newJsonArray = [];
	if(tabIndexGnbAtollUpdate == 1) {
		marketNum  = marketsSelected;
	} else if(tabIndexGnbAtollUpdate == 3) {
		marketNum  = marketIdOrName;
	}
	if (parseInt(marketNum) < 10) {
		marketNum = '00' + marketNum;
	} else if (parseInt(marketNum) < 100) {
		marketNum = '0' + marketNum;
	}
	for (const obj of jsonObject) {
		let newJsonObject = {
			"gNBId": gnodeBId != null ? '="' + marketNum + gnodeBId + '"' : "",
			"Sector": obj.sector != null ? '="' + obj.sector + '"' : "",
			"siteName": (obj.siteName != null && obj.siteName != "" && obj.siteName != '<Multiple>') ? obj.siteName : "",
			"siteVersion": (obj.siteVersion != null && obj.siteVersion != "") ? '="' + obj.siteVersion + '"' : "",
			"siteFuzeId": (obj.siteFuzeId != null && obj.siteFuzeId != '<Multiple>') ? obj.siteFuzeId : "",
			"Status": obj.status != null ? obj.status : "",
			"hubName": obj.cranHubName != null ? obj.cranHubName : ""

		}
		newJsonArray.push(newJsonObject)
	}
	var jsonObject = JSON.stringify(newJsonArray);
	var array = typeof jsonObject != 'object' ? JSON.parse(jsonObject) : jsonObject;
	var str = '';
	str = 'gNB ID,Sector,Site Name,Site Version,Fuze Site ID,Status,Hub Name,\r\n';

	for (var i = 0; i < array.length; i++) {
		var line = '';
		for (var index in array[i]) {
			if (line != '') line += ','

			line += array[i][index];
		}

		str += line + '\r\n';
	}
	var link = document.createElement("a");
	link.id = "lnkDwnldLnk";
	document.body.appendChild(link);
	var csv = str;
	blob = new Blob([str], { type: 'text/csv' });
	var csvUrl = window.webkitURL.createObjectURL(blob);
	$("#lnkDwnldLnk")
		.attr({
			'download': fileName,
			'href': csvUrl
		});

	$('#lnkDwnldLnk')[0].click();
	document.body.removeChild(link);
}

function handleBlank(value){
	if(value===null || value===undefined) return "";
	return value;
}

function exportToExcelEnbAssignment(jsonObject, jsonObjectKeys, fileName) {
	var str = 'eNB ID,Site Name, Site Version, Fuze Site ID, Reserved ,Status,Hub Name\r\n';
	let enbDataArray = jsonObject;
	let newJsonArray = [];
	let marketsLength = 0;
	let recordsLowerValue = 0;
	let recordsUpperValue = 50;
	let currentArray;

	while (recordsUpperValue < 1050) {
		for (var i = recordsLowerValue; i < recordsUpperValue; i++) {
			currentArray = jsonObject[0];
					let newJsonObject1 = {

						"eNBID": '="' + jsonObjectKeys[0] + currentArray[i].enodebId + '"',
						"siteName": currentArray[i].siteName != null ? '="' + currentArray[i].siteName + '"' : "",
						"siteVersion": currentArray[i].siteVersion != null ? '="' + currentArray[i].siteVersion + '"' : "",
						"siteFuzeID": currentArray[i].siteInfoId != null ? '="' + currentArray[i].siteInfoId + '"' : "",
						"siteType": currentArray[i].siteType != null ? '="' + currentArray[i].siteType + '"' : "",
						"status": currentArray[i].status != null ? '="' + currentArray[i].status + '"' : "",
						"hubName": currentArray[i].cranHubName != null ? '="' + currentArray[i].cranHubName + '"' : ""

				}
				currentArray = jsonObject[1];
				let newJsonObject2 = {
					"eNBID": '="' + jsonObjectKeys[1] + currentArray[i].enodebId + '"',
					"siteName": currentArray[i].siteName != null ? '="' + currentArray[i].siteName + '"' : "",
					"siteVersion": currentArray[i].siteVersion != null ? '="' + currentArray[i].siteVersion + '"' : "",
					"siteFuzeID": currentArray[i].siteInfoId != null ? '="' + currentArray[i].siteInfoId + '"' : "",
					"siteType": currentArray[i].siteType != null ? '="' + currentArray[i].siteType + '"' : "",
					"status": currentArray[i].status != null ? '="' + currentArray[i].status + '"' : "",
					"hubName": currentArray[i].cranHubName != null ? '="' + currentArray[i].cranHubName + '"' : ""
				}
				currentArray = jsonObject[2];
				let newJsonObject3 = {
					"eNBID": '="' + jsonObjectKeys[2] + currentArray[i].enodebId + '"',
					"siteName": currentArray[i].siteName != null ? '="' + currentArray[i].siteName + '"' : "",
					"siteVersion": currentArray[i].siteVersion != null ? '="' + currentArray[i].siteVersion + '"' : "",
					"siteFuzeID": currentArray[i].siteInfoId != null ? '="' + currentArray[i].siteInfoId + '"' : "",
					"siteType": currentArray[i].siteType != null ? '="' + currentArray[i].siteType + '"' : "",
					"status": currentArray[i].status != null ? '="' + currentArray[i].status + '"' : "",
					"hubName": currentArray[i].cranHubName != null ? '="' + currentArray[i].cranHubName + '"' : ""

				}
				newJsonArray.push(newJsonObject1);
				newJsonArray.push(newJsonObject2);
				newJsonArray.push(newJsonObject3);
		}

		let temp = recordsUpperValue;
		recordsUpperValue = recordsUpperValue + 50;
		recordsLowerValue = temp;
				let blankObject = {
					"eNBID": "",
					"siteName": "",
					"siteVersion": "",
					"siteFuzeID": "",
					"siteType":"",
					"status": "",
					"hubName": ""
			  };
			newJsonArray.push(blankObject);

	}

	var jsonObject = JSON.stringify(newJsonArray);
	var array = typeof jsonObject != 'object' ? JSON.parse(jsonObject) : jsonObject;


	for (var i = 0; i < array.length; i++) {
		var line = '';
		for (var index in array[i]) {
			if (line != '') line += ','

			line += array[i][index];
		}

		str += line + '\r\n';
	}

	if(featureToggleMap && featureToggleMap['F94116']){
		let maxRowCount = enbDataArray.map(data => data.length).reduce((x,y) => x>y?x:y,0);
		let headLine = "Mkt,";
		for(let subMarketKey of jsonObjectKeys){
			headLine += `${subMarketKey},"","","","","","",`
		}
		let allSubHeaders = "";
		for(let _ in jsonObjectKeys){
			allSubHeaders += `eNB ID,Site Name,Site Version,Fuze Site ID,Reserved,Status,Hub Name,`
		}

		let enbCsvLines = [headLine];
		enbCsvLines.push(allSubHeaders);

		for(let i=0;i<maxRowCount;i++){
			let line = ``;
			for(let subMarketKey in jsonObjectKeys){
				if(enbDataArray[subMarketKey] && enbDataArray[subMarketKey][i]){
					line += `="${jsonObjectKeys[subMarketKey]+handleBlank(enbDataArray[0][i].enodebId)}",`+
							`="${handleBlank(enbDataArray[subMarketKey][i].siteName)}",`+
							`="${handleBlank(enbDataArray[subMarketKey][i].siteVersion)}",`+
							`="${handleBlank(enbDataArray[subMarketKey][i].siteInfoId)}",`+
							`="${handleBlank(enbDataArray[subMarketKey][i].siteType)}",`+
							`="${handleBlank(enbDataArray[subMarketKey][i].status)}",`+
							`="${handleBlank(enbDataArray[subMarketKey][i].cranHubName)}",`
				}
				else{
					line += `"${''}","${''}","${''}","${''}","${''}","${''}","${''}",`
				}
			}
			enbCsvLines.push(line);
		}
		str = "";
		for(let line of enbCsvLines) str += line+"\n";
	}

	var link = document.createElement("a");
	link.id = "lnkDwnldLnk";
	document.body.appendChild(link);
	var csv = str;
	blob = new Blob([str], { type: 'text/csv' });
	var csvUrl = window.webkitURL.createObjectURL(blob);
	$("#lnkDwnldLnk")
		.attr({
			'download': fileName,
			'href': csvUrl
		});

	$('#lnkDwnldLnk')[0].click();
	document.body.removeChild(link);

}

let fiveGexportToExcelButtonId = document.getElementById('fiveGexportToExcel');
fiveGexportToExcelButtonId.onclick = () => exportToExcel(fetchGnbDUNumbers, "5gVirtualDuView.csv", virtualFiveGData.vzGnodebId)
let fiveGsectexportToExcelButtonId = document.getElementById('fiveGSectorexportToExcel');
fiveGsectexportToExcelButtonId.onclick = () => sectorexportToExcel(virtualDuIds, "5gVirtualSectorView.csv", virtualFiveGData.vzGnodebId)
let fiveGenbsectexportToExcelButtonId = document.getElementById('lteSectorexportToExcel');
fiveGenbsectexportToExcelButtonId.onclick = () => enbsectorexportToExcel(enbSecData, "lteSectorView.csv", enbSelData);
let exportToExcelPh5gGnbViewButtonId = document.getElementById('exportToExcelPh5gGnbView');
exportToExcelPh5gGnbViewButtonId.onclick = () => exportToExcelPhGnbView(fetchPhyGnbs, "Physical5gGnbView.csv", physicalMarket5g)
document.getElementById("exportToExcelLte").onclick = () =>exportToExcelEnbAssignment(lteKeyVal,result2Keys,'enbLteAssignmentView.csv');

function duViewGnodeAssignmentAtollUpdate(data) {
	$('#exportToExcelPhGnbView').hide();
		$('#exportToExcel').show();
	$("#fiveGDuPageList").empty();
    $("#showFiveGVirtualDuPage").hide();

	if(tabIndexGnbAtollUpdate == '1') {
		fetchGnbDUNumbers = data;
		$("#AssignmentDrillView").show();
		window.scrollTo(0, document.getElementById("AssignmentDrillView").scrollHeight);
		$('html, body').animate({
			scrollTop: $("#AssignmentDrillView").offset().top
		}, "slow");
	} else {
		fetchGnbDUNumbers = data;
		$("#fiveGVirtualView").show();
		$("#fiveGexportToExcel").show();
		window.scrollTo(0, document.getElementById("fiveGVirtualView").scrollHeight);
		$('html, body').animate({
			scrollTop: $("#fiveGVirtualView").offset().top
		}, "slow");
	}
	if (!fetchGnbDUNumbers || !Array.isArray(fetchGnbDUNumbers) || fetchGnbDUNumbers.length === 0) {
        alert("Not found GnbDUNumbers");

        // HIDES THE PAGINATION AND THE BLACK BOXES
        $("#showHidePageID").hide();
        $("#showFiveGVirtualDuPage").hide();
//        $("#showHidePage").hide();
				if (tabIndexGnbAtollUpdate == '1') {
					$("#AssignmentDrillView").hide();
				} else {
					// Keep the 5G DU container visible for Atoll Update even with no DU rows.
					$("#fiveGVirtualView").show();
					$("#fiveGVirtualDuIdss").show();
					$("#fiveGexportToExcel").hide();
				}
    } else {
		var fetchGnbDUNumberslength = fetchGnbDUNumbers.length;
		var fetchGnbDUSRows = Math.ceil(fetchGnbDUNumberslength / 25);
		var totalDuPages = 1;
		var pagePrefix = tabIndexGnbAtollUpdate == 1 ? "dusRows" : "fiveGdusRows";
		var pageClassName = tabIndexGnbAtollUpdate == 1 ? "containerseating" : "containerseatingFivegVirtual";
		var firstPageContainer = document.getElementById(pagePrefix + "1");
		var pageContainerParent = firstPageContainer ? firstPageContainer.parentNode : null;
		var existingPageCount = 0;
		while (document.getElementById(pagePrefix + (existingPageCount + 1))) {
			existingPageCount++;
		}
		for (var clearIdx = 1; clearIdx <= existingPageCount; clearIdx++) {
			$("#" + pagePrefix + clearIdx).empty().hide();
		}
		if (fetchGnbDUSRows <= 40) {
			// No pagination needed – hide both nav bars

			var flag = false;
			for (var i = 0; i < fetchGnbDUSRows; i++) {
				var sId = tabIndexGnbAtollUpdate == 1 ?"seatingrow" + i : "seatingFiveGDus" + i;
						if (tabIndexGnbAtollUpdate == 1 ) {
							$("#dusRows1").append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
						} else {
							$("#fiveGdusRows1").append('<div class="seatingFiveGDus" id="' + sId + '" style="text-align:center"></div>');

						}
											for (var j = 1; j <= 25; j++) {
					if (j + i * 25 > fetchGnbDUNumberslength) {
						flag = true;
						break;
					}
					if (fetchGnbDUNumbers[j - 1 + i * 25].status == "On Air") {


						$("#" + sId).append('<div class="onAir"  id="onAirtooltip"  data-title="SiteName: ' + fetchGnbDUNumbers[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbDUNumbers[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbDUNumbers[j - 1 + i * 25].vzSiteInfoId + '\nHubname: ' + fetchGnbDUNumbers[j - 1 + i * 25].cranHubName + '">' + fetchGnbDUNumbers[j - 1 + i * 25].vz5GgNBDUNumber + ' </div>');
					} else if (fetchGnbDUNumbers[j - 1 + i * 25].status == "Assigned") {

						$("#" + sId).append('<div class="assigned"  id="assignedtooltip"  data-title="SiteName: ' + fetchGnbDUNumbers[j - 1 + i * 25].vzSiteName + '\nSiteVersion: ' + fetchGnbDUNumbers[j - 1 + i * 25].siteVersionLast + '\nFuzeSiteId: ' + fetchGnbDUNumbers[j - 1 + i * 25].vzSiteInfoId + '\nHubName: ' + fetchGnbDUNumbers[j - 1 + i * 25].cranHubName + '">' + fetchGnbDUNumbers[j - 1 + i * 25].vz5GgNBDUNumber + ' </div>');
					} else {
						$("#" + sId).append('<div class="avliable">' + fetchGnbDUNumbers[j - 1 + i * 25].vz5GgNBDUNumber + ' </div>');
					}

				}

				if (flag) {
					break;
				}

			}
		if (tabIndexGnbAtollUpdate == 1) {
        				var pageListEl = document.getElementById("showHidePageIDList");
        				var pageListHtml = '<li class="page-item disabled"><span aria-hidden="true">&laquo;</span><span class="sr-only">Previous</span></li>';
        				pageListHtml += '<li class="page-item active"><span style="cursor:default">1</span></li>';
        				pageListHtml += '<li class="page-item disabled"><span aria-hidden="true">&raquo;</span><span class="sr-only">Next</span></li>';
        				pageListEl.innerHTML = pageListHtml;
        				$("#showHidePageID").show();
        			} else {
//        				var $fiveGNav = $("#showHidePage");
        				var $fiveGNav = $("#showFiveGVirtualDuPage");
        				var fiveGUl = $("#fiveGDuPageList");
        				var fiveGHtml = '<li class="page-item disabled"><span aria-hidden="true">&laquo;</span><span class="sr-only">Previous</span></li>';
        				fiveGHtml += '<li class="page-item active"><span style="cursor:default">1</span></li>';
        				fiveGHtml += '<li class="page-item disabled"><span aria-hidden="true">&raquo;</span><span class="sr-only">Next</span></li>';
        				if (fiveGUl.length > 0) {
        					fiveGUl.html(fiveGHtml);
        				}
        				$fiveGNav.show();
        			}
		} else {
			// --- Dynamic Pagination: 1,000 records per page (40 rows × 25 cols) ---
			onlyExceptionFlag = true;
			var flag = false;
			var ROWS_PER_PAGE = 40; // 40 rows × 25 cols = 1,000 records per page
			totalDuPages = Math.ceil(fetchGnbDUSRows / ROWS_PER_PAGE);
			console.log("Pagination: totalRecords=" + fetchGnbDUNumberslength + ", totalRows=" + fetchGnbDUSRows + ", totalPages=" + totalDuPages + ", is5G=" + (tabIndexGnbAtollUpdate != 1));

			// Draw each page into its own container (dusRows1…N or fiveGdusRows1…N)
			for (var page = 1; page <= totalDuPages; page++) {
				var pageContainerId = pagePrefix + page;
				var existingContainer = document.getElementById(pageContainerId);
				if (!existingContainer) {
					if (pageContainerParent) {
						var pageContainer = document.createElement("div");
						pageContainer.className = pageClassName;
						pageContainer.id = pageContainerId;
						pageContainerParent.appendChild(pageContainer);
						console.log("Created missing page container: " + pageContainerId);
					} else {
						console.warn("Cannot create page container " + pageContainerId + " - parent not found");
					}
				}

				var startRow = (page - 1) * ROWS_PER_PAGE;
				var endRow   = Math.min(page * ROWS_PER_PAGE, fetchGnbDUSRows);
				for (var i = startRow; i < endRow; i++) {
					var sId = tabIndexGnbAtollUpdate == 1 ? "seatingrow" + i : "seatingFiveGDus" + i;
					if (tabIndexGnbAtollUpdate == 1) {
						$("#" + pageContainerId).append('<div class="seatingrow" id="' + sId + '" style="text-align:center"></div>');
					} else {
						$("#" + pageContainerId).append('<div class="seatingFiveGDus" id="' + sId + '" style="text-align:center"></div>');
					}
					for (var j = 1; j <= 25; j++) {
						if (j + i * 25 > fetchGnbDUNumberslength) {
							flag = true;
							break;
						}
						var rec = fetchGnbDUNumbers[j - 1 + i * 25];
						if (rec.status == "On Air") {

							$("#" + sId).append('<div class="onAir" id="showtooltip" data-title="SiteName:' + rec.vzSiteName + '\nSiteVersion: ' + rec.siteVersionLast + '\nFuzeSiteId: ' + rec.vzSiteInfoId + '\nHubName: ' + rec.cranHubName + '">' + rec.vz5GgNBDUNumber + ' </div>');
						} else if (rec.status == "Assigned") {

							$("#" + sId).append('<div class="assigned" id="showtooltip" data-title="SiteName:' + rec.vzSiteName + '\nSiteVersion: ' + rec.siteVersionLast + '\nFuzeSiteId: ' + rec.vzSiteInfoId + '\nHubName: ' + rec.cranHubName + '">' + rec.vz5GgNBDUNumber + ' </div>');
						} else {
							$("#" + sId).append('<div class="avliable">' + rec.vz5GgNBDUNumber + ' </div>');
						}
					}
					if (flag) break;
				}
				if (flag) break;
			}

			// Build and show the correct pagination nav
			if (tabIndexGnbAtollUpdate == 1) {
				// DU View – populate the showHidePageIDList ul dynamically
				currentPage = 1; // reset to page 1 for the new dataset
				var pageListEl = document.getElementById("showHidePageIDList");
				var pageListHtml = '<li class="page-item"><span onclick="showPreviousList(' + totalDuPages + ');" aria-hidden="true">&laquo;</span><span class="sr-only">Previous</span></li>';
				pageListHtml += '<li class="page-item active" id="showHidePageIDItem1"><span onclick="goToPageList(1,' + totalDuPages + ');">1</span></li>';
				for (var p = 2; p <= totalDuPages; p++) {
					pageListHtml += '<li class="page-item" id="showHidePageIDItem' + p + '"><span onclick="goToPageList(' + p + ',' + totalDuPages + ');">' + p + '</span></li>';
				}
				pageListHtml += '<li class="page-item"><span onclick="showNextList(' + totalDuPages + ');" aria-hidden="true">&raquo;</span><span class="sr-only">Next</span></li>';
				pageListEl.innerHTML = pageListHtml;
				$("#showHidePageID").show();
				console.log("DU View pagination shown with " + totalDuPages + " pages");
			} else {
				// 5G Virtual DU View – populate the fiveGDuPageList ul dynamically
				fiveGDuCurrentPage = 1; // reset to page 1 for the new dataset
//				var $fiveGNav = $("#showHidePage");
				var $fiveGNav = $("#showFiveGVirtualDuPage");
				var fiveGUl = $("#fiveGDuPageList");
				var fiveGHtml = '<li class="page-item"><span onclick="showFiveGVirtualDuPrev(' + totalDuPages + ');" aria-hidden="true">&laquo;</span><span class="sr-only">Previous</span></li>';
				fiveGHtml += '<li class="page-item active" id="showHideFiveGPageItem1"><span onclick="goToFiveGDuPage(1,' + totalDuPages + ');">1</span></li>';
				for (var p = 2; p <= totalDuPages; p++) {
					fiveGHtml += '<li class="page-item" id="showHideFiveGPageItem' + p + '"><span onclick="goToFiveGDuPage(' + p + ',' + totalDuPages + ');">' + p + '</span></li>';
				}
				fiveGHtml += '<li class="page-item"><span onclick="showFiveGVirtualDuNext(' + totalDuPages + ');" aria-hidden="true">&raquo;</span><span class="sr-only">Next</span></li>';
				if (fiveGUl.length > 0) {
					fiveGUl.html(fiveGHtml);
				} else {
					console.error("5G DU pagination nav ul (#fiveGDuPageList) not found!");
				}
				$fiveGNav.show();
				console.log("5G DU View pagination shown with " + totalDuPages + " pages, nav visible: " + $fiveGNav.is(":visible"));
			}
		}
		var visiblePages = fetchGnbDUSRows <= 40 ? 1 : totalDuPages;
		var pageLoopLimit = Math.max(existingPageCount, visiblePages);
		for (var pageIdx = 1; pageIdx <= pageLoopLimit; pageIdx++) {
			var pageEl = document.getElementById(pagePrefix + pageIdx);
			if (pageEl) {
				pageEl.style.display = pageIdx === 1 ? 'block' : 'none';
			}
		}




	}


}
var resultVal;


function enbAssignmentAtollUpdateLteCommonView(){
	// var result = Object.keys(data);
	// resultVal = Object.values(data);
	// var result2Keys='';

	if(tabIndexEnbAtollUpdate==2){
		result2=result;
		result2Val=resultVal;
	}
	else{
		result2=lteKeys;
		result2Val=lteKeyVal;
	}


	mrkNumOne = result2[0];
	mrkNumTwo = result2[1];
	mrkNumThree = result2[2];

	if (result2[0] < result2[1] && result2[2]) {
		mrkNumOne = result2[0];
		if (result2[1] < result2[2]) {
			mrkNumTwo = result2[1];
			mrkNumThree = result2[2];
			fetchEnbM1Data = result2Val[0];
			fetchEnbM2Data = result2Val[1];
			fetchEnbM3Data = result2Val[2];
		} else {
			mrkNumOne = result2[2]
			mrkNumTwo = result2[0];
			mrkNumThree = result2[1];
			fetchEnbM1Data = result2Val[2];
			fetchEnbM2Data = result2Val[0];
			fetchEnbM3Data = result2Val[1];
		}

	} else if (result2[1] < result2[0] && result2[2]) {
		mrkNumOne = result2[1];
		if (result2[0] < result2[2]) {
			mrkNumTwo = result2[0];
			mrkNumThree = result2[2];
		}
		else {
			mrkNumTwo = result2[2];
			mrkNumThree = result2[0];
		}
	}
	else if (result2[2] < result2[0] && result2[1]) {
		mrkNumOne = result2[2];
		if (result2[0] < result2[1]) {
			mrkNumTwo = result2[0];
			mrkNumThree = result2[1];
		}
		else {
			mrkNumTwo = result2[1];
			mrkNumThree = result2[0];
		}
	}



	if (mrkNumOne.length == 1) {
		mrkNumOne = '00' + mrkNumOne;

	} else if (mrkNumOne.length == 2) {
		mrkNumOne = '0' + mrkNumOne;
	}
	if(tabIndexEnbAtollUpdate==2){
		resultKeys.push(mrkNumOne);
		resultKeys.push(mrkNumTwo);
		resultKeys.push(mrkNumThree);
	}
	else{
		result2Keys.push(mrkNumOne);
		result2Keys.push(mrkNumTwo);
		result2Keys.push(mrkNumThree);
	}
	if(tabIndexEnbAtollUpdate==2){
	document.getElementById("marketIdtab").innerHTML = mrkNumOne;
	document.getElementById("marketId300tab").innerHTML = mrkNumTwo;
	document.getElementById("marketId600tab").innerHTML = mrkNumThree;
	}
	else{
	document.getElementById("marketLteIdOne").innerHTML = mrkNumOne;
	document.getElementById("marketLteIdTwo").innerHTML = mrkNumTwo;
	document.getElementById("marketLteIdThree").innerHTML = mrkNumThree;
	}
	golbelMId = mrkNumOne;

	if (fetchEnbM1Data.length == 0) {
		alert("Not found enbDUNumbers");
		$('#loading').fadeOut();
	} else {

		var fetchGnbDUMarkets = fetchEnbM1Data.length;
		var fetchGnbDUSRows = Math.ceil(fetchGnbDUMarkets / 50);
		if (fetchGnbDUSRows <= 20) {
			$("#showHideMarkets").hide();
			var flag = false;
			for (var i = 0; i < fetchGnbDUSRows; i++) {

				var sId = tabIndexEnbAtollUpdate==2?"seatingMarketrow" + i:"seatingLTEMarketrow" + i;
				if(tabIndexEnbAtollUpdate==2){
					$("#dusMarketRows1").append('<div class="seatingMarketrow" id="' + sId + '" style="text-align:center"></div>');
				}
				else{
					$("#lteMarketRows1").append('<div class="seatingLTEMarketrow" id="' + sId + '" style="text-align:center"></div>');

				}
				for (var j = 1; j <= 50; j++) {
					if (j + i * 50 > fetchGnbDUMarkets) {
						flag = true;
						break;
					}
					if (fetchEnbM1Data[j - 1 + i * 50].status == "On Air") {
						if(fetchEnbM1Data[j - 1 + i * 50].siteType !=null && fetchEnbM1Data[j - 1 + i * 50].siteType != ""){
							$("#" + sId).append('<div class="onAir" id="onAirtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM1Data[j - 1 + i * 50].enodebId + '\', 0, \'' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM1Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\nSiteInfoId: ' + fetchEnbM1Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM1Data[j - 1 + i * 50].cranHubName + '\nReserved: ' + fetchEnbM1Data[j - 1 + i * 50].siteType + '" " style="border: 2px solid red">' + fetchEnbM1Data[j - 1 + i * 50].enodebId + ' </div>');
						}else{
							$("#" + sId).append('<div class="onAir" id="onAirtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM1Data[j - 1 + i * 50].enodebId + '\', 0, \'' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM1Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\nSiteInfoId: ' + fetchEnbM1Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM1Data[j - 1 + i * 50].cranHubName + '">' + fetchEnbM1Data[j - 1 + i * 50].enodebId + ' </div>');
						}

						} else if (fetchEnbM1Data[j - 1 + i * 50].status == "Assigned") {
							if(fetchEnbM1Data[j - 1 + i * 50].siteType !=null && fetchEnbM1Data[j - 1 + i * 50].siteType != ""){
								$("#" + sId).append('<div class="assigned" id="assignedtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM1Data[j - 1 + i * 50].enodebId + '\', 0, \'' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM1Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\nSiteInfoId: ' + fetchEnbM1Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM1Data[j - 1 + i * 50].cranHubName + '\nReserved: ' + fetchEnbM1Data[j - 1 + i * 50].siteType + '" " style="border: 2px solid red">' + fetchEnbM1Data[j - 1 + i * 50].enodebId + ' </div>');
							}else{
								$("#" + sId).append('<div class="assigned" id="assignedtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM1Data[j - 1 + i * 50].enodebId + '\', 0, \'' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM1Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\nSiteInfoId: ' + fetchEnbM1Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM1Data[j - 1 + i * 50].cranHubName + '">' + fetchEnbM1Data[j - 1 + i * 50].enodebId + ' </div>');
							}
						} else {
							if(fetchEnbM1Data[j - 1 + i * 50].siteType !=null && fetchEnbM1Data[j - 1 + i * 50].siteType != ""){
								$("#" + sId).append('<div class="avliable" style="border: 2px solid red">' + fetchEnbM1Data[j - 1 + i * 50].enodebId + ' </div>');
							}else{
								$("#" + sId).append('<div class="avliable" >' + fetchEnbM1Data[j - 1 + i * 50].enodebId + ' </div>');
							}

						}

				}
				// second
				var fetchGnbDUMarkets2 = fetchEnbM2Data.length;
				var fetchGnbDUSRows = Math.ceil(fetchGnbDUMarkets2 / 50);
				if (fetchGnbDUSRows) {
					$("#showHideMarkets").hide();
					var sId =tabIndexEnbAtollUpdate==2? "seatingMarketrow2" + i:"seatingLTEMarketrow2" + i;
					if(tabIndexEnbAtollUpdate==2){
						$("#dusMarketRows1").append('<div class="seatingMarketrow2" id="' + sId + '" style="text-align:center"></div>');
					}
					else{
						$("#lteMarketRows1").append('<div class="seatingLTEMarketrow2" id="' + sId + '" style="text-align:center"></div>');
					}
					for (var j = 1; j <= 50; j++) {
						if (j + i * 50 > fetchGnbDUMarkets2) {
							flag = true;
							break;
						}
						if (fetchEnbM2Data[j - 1 + i * 50].status == "On Air") {
								if(fetchEnbM2Data[j - 1 + i * 50].siteType !=null && fetchEnbM2Data[j - 1 + i * 50].siteType != ""){
									$("#" + sId).append('<div class="onAir" id="onAirtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM2Data[j - 1 + i * 50].enodebId + '\', 1, \'' + fetchEnbM2Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM2Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM2Data[j - 1 + i * 50].siteVersion + '\nFuzeSiteId: ' + fetchEnbM2Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM2Data[j - 1 + i * 50].cranHubName + '\nReserved: ' + fetchEnbM2Data[j - 1 + i * 50].siteType + '" style="border: 2px solid red">' + fetchEnbM2Data[j - 1 + i * 50].enodebId + ' </div>');
								}else{
									$("#" + sId).append('<div class="onAir" id="onAirtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM2Data[j - 1 + i * 50].enodebId + '\', 1, \'' + fetchEnbM2Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM2Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM2Data[j - 1 + i * 50].siteVersion + '\nFuzeSiteId: ' + fetchEnbM2Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM2Data[j - 1 + i * 50].cranHubName + '">' + fetchEnbM2Data[j - 1 + i * 50].enodebId + ' </div>');
								}
							} else if (fetchEnbM2Data[j - 1 + i * 50].status == "Assigned") {
								if(fetchEnbM2Data[j - 1 + i * 50].siteType !=null && fetchEnbM2Data[j - 1 + i * 50].siteType != ""){
									$("#" + sId).append('<div class="assigned" id="assignedtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM2Data[j - 1 + i * 50].enodebId + '\', 1, \'' + fetchEnbM2Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM2Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM2Data[j - 1 + i * 50].siteVersion + '\nFuzeSiteId: ' + fetchEnbM2Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM2Data[j - 1 + i * 50].cranHubName + '\nReserved: ' + fetchEnbM2Data[j - 1 + i * 50].siteType + '" style="border: 2px solid red">' + fetchEnbM2Data[j - 1 + i * 50].enodebId + ' </div>');
								}else{
									$("#" + sId).append('<div class="assigned" id="assignedtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM2Data[j - 1 + i * 50].enodebId + '\', 1, \'' + fetchEnbM2Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM2Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM2Data[j - 1 + i * 50].siteVersion + '\nFuzeSiteId: ' + fetchEnbM2Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM2Data[j - 1 + i * 50].cranHubName + '">' + fetchEnbM2Data[j - 1 + i * 50].enodebId + ' </div>');
								}
							} else {
								if(fetchEnbM2Data[j - 1 + i * 50].siteType !=null && fetchEnbM2Data[j - 1 + i * 50].siteType != ""){
									$("#" + sId).append('<div class="avliable" style="border: 2px solid red">' + fetchEnbM2Data[j - 1 + i * 50].enodebId + ' </div>');
								}else{
									$("#" + sId).append('<div class="avliable" >' + fetchEnbM2Data[j - 1 + i * 50].enodebId + ' </div>');
								}
							}

					}

				}

				var fetchGnbDUMarkets3 = fetchEnbM3Data.length;
				var fetchGnbDUSRows = Math.ceil(fetchGnbDUMarkets3 / 50);
				if (fetchGnbDUSRows) {
					$("#showHideMarkets").hide();
					var sId = tabIndexEnbAtollUpdate==2?"seatingMarketrow3" + i:"seatingLTEMarketrow3" + i;
					if(tabIndexEnbAtollUpdate==2){
						$("#dusMarketRows1").append('<div class="seatingMarketrow3" id="' + sId + '" style="text-align:center"></div>');
					}
					else{
						$("#lteMarketRows1").append('<div class="seatingLTEMarketrow3" id="' + sId + '" style="text-align:center"></div>');
					}

					for (var j = 1; j <= 50; j++) {
						if (j + i * 50 > fetchGnbDUMarkets3) {
							flag = true;
							break;
						}
						if (fetchEnbM3Data[j - 1 + i * 50].status == "On Air") {
								if(fetchEnbM3Data[j - 1 + i * 50].siteType !=null && fetchEnbM3Data[j - 1 + i * 50].siteType != ""){
									$("#" + sId).append('<div class="onAir" id="onAirtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM3Data[j - 1 + i * 50].enodebId + '\', 2, \'' + fetchEnbM3Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM3Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM3Data[j - 1 + i * 50].siteVersion + '\nFuzeSiteId: ' + fetchEnbM3Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM3Data[j - 1 + i * 50].cranHubName + '\nReserved: ' + fetchEnbM3Data[j - 1 + i * 50].siteType + '" style="border: 2px solid red" >' + fetchEnbM3Data[j - 1 + i * 50].enodebId + ' </div>');
								}else{
									$("#" + sId).append('<div class="onAir" id="onAirtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM3Data[j - 1 + i * 50].enodebId + '\', 2, \'' + fetchEnbM3Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM3Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM3Data[j - 1 + i * 50].siteVersion + '\nFuzeSiteId: ' + fetchEnbM3Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM3Data[j - 1 + i * 50].cranHubName + '">' + fetchEnbM3Data[j - 1 + i * 50].enodebId + ' </div>');
								}
							} else if (fetchEnbM3Data[j - 1 + i * 50].status == "Assigned") {
								if(fetchEnbM3Data[j - 1 + i * 50].siteType !=null && fetchEnbM3Data[j - 1 + i * 50].siteType != ""){
									$("#" + sId).append('<div class="assigned" id="assignedtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM3Data[j - 1 + i * 50].enodebId + '\', 2, \'' + fetchEnbM3Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM3Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM3Data[j - 1 + i * 50].siteVersion + '\nFuzeSiteId: ' + fetchEnbM3Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM3Data[j - 1 + i * 50].cranHubName + '\nReserved: ' + fetchEnbM3Data[j - 1 + i * 50].siteType + '" style="border: 2px solid red">' + fetchEnbM3Data[j - 1 + i * 50].enodebId + ' </div>');
								}else{
									$("#" + sId).append('<div class="assigned" id="assignedtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM3Data[j - 1 + i * 50].enodebId + '\', 2, \'' + fetchEnbM3Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM3Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM3Data[j - 1 + i * 50].siteVersion + '\nFuzeSiteId: ' + fetchEnbM3Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM3Data[j - 1 + i * 50].cranHubName + '">' + fetchEnbM3Data[j - 1 + i * 50].enodebId + ' </div>');
							}
							} else {
								if(fetchEnbM3Data[j - 1 + i * 50].siteType !=null && fetchEnbM3Data[j - 1 + i * 50].siteType != ""){
									$("#" + sId).append('<div class="avliable" style="border: 2px solid red" >' + fetchEnbM3Data[j - 1 + i * 50].enodebId + ' </div>');
								}else{
									$("#" + sId).append('<div class="avliable" >' + fetchEnbM3Data[j - 1 + i * 50].enodebId + ' </div>');
								}
							}
						}

				}
				// close
			}
		} else {
			$("#showHideMarkets").show();
			var flag = false;
			for (var i = 0; i < 40; i++) {
				var sId = tabIndexEnbAtollUpdate==2?"seatingMarketrow" + i:"seatingLTEMarketrow" + i;
				if(tabIndexEnbAtollUpdate==2){
					$("#dusMarketRows1").append('<div class="seatingMarketrow" id="' + sId + '" style="text-align:center"></div>');
				}
				else{
					$("#lteMarketRows1").append('<div class="seatingLTEMarketrow" id="' + sId + '" style="text-align:center"></div>');
				}
				for (var j = 1; j <= 50; j++) {
					if (fetchEnbM1Data[j - 1 + i * 50].status == "On Air") {
							if(Object.keys(fetchEnbM1Data[j - 1 + i * 50].siteType !=null && fetchEnbM1Data[j - 1 + i * 50].siteType != "")){
								$("#" + sId).append('<div class="onAir" id="onAirtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM1Data[j - 1 + i * 50].enodebId + '\', 0, \'' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM1Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\nSiteInfoId: ' + fetchEnbM1Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM1Data[j - 1 + i * 50].cranHubName + '\nReserved: ' + fetchEnbM1Data[j - 1 + i * 50].siteType + '" style="border: 2px solid red">' + fetchEnbM1Data[j - 1 + i * 50].enodebId + ' </div>');
							} else{
								$("#" + sId).append('<div class="onAir" id="onAirtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM1Data[j - 1 + i * 50].enodebId + '\', 0, \'' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM1Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\nSiteInfoId: ' + fetchEnbM1Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM1Data[j - 1 + i * 50].cranHubName + '">' + fetchEnbM1Data[j - 1 + i * 50].enodebId + ' </div>');
							}
						} else if (fetchEnbM1Data[j - 1 + i * 50].status == "Assigned") {
							if(fetchEnbM1Data[j - 1 + i * 50].siteType !=null && fetchEnbM1Data[j - 1 + i * 50].siteType != ""){
								$("#" + sId).append('<div class="assigned" id="assignedtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM1Data[j - 1 + i * 50].enodebId + '\', 0, \'' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM1Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\nSiteInfoId: ' + fetchEnbM1Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM1Data[j - 1 + i * 50].cranHubName + '\nReserved: ' + fetchEnbM1Data[j - 1 + i * 50].siteType + '" style="border: 2px solid red">' + fetchEnbM1Data[j - 1 + i * 50].enodebId + ' </div>');
							} else{
								$("#" + sId).append('<div class="assigned" id="assignedtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM1Data[j - 1 + i * 50].enodebId + '\', 0, \'' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM1Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\nSiteInfoId: ' + fetchEnbM1Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM1Data[j - 1 + i * 50].cranHubName + '">' + fetchEnbM1Data[j - 1 + i * 50].enodebId + ' </div>');
							}
						} else {
							if(fetchEnbM1Data[j - 1 + i * 50].siteType !=null && fetchEnbM1Data[j - 1 + i * 50].siteType !=""){
								$("#" + sId).append('<div class="avliable" style="border: 2px solid red">' + fetchEnbM1Data[j - 1 + i * 50].enodebId + ' </div>');
							}else{
								$("#" + sId).append('<div class="avliable">' + fetchEnbM1Data[j - 1 + i * 50].enodebId + ' </div>');
							}
						}

				}

				// second
				var fetchGnbDUMarkets2 = fetchEnbM2Data.length;
				var fetchGnbDUSRows = Math.ceil(fetchGnbDUMarkets2 / 50);
				if (fetchGnbDUSRows) {
					$("#showHideMarkets").hide();
					var sId = tabIndexEnbAtollUpdate==2?"seatingMarketrow2" + i:"seatingLTEMarketrow2" + i;
					if(tabIndexEnbAtollUpdate==2){
						$("#dusMarketRows1").append('<div class="seatingMarketrow2" id="' + sId + '" style="text-align:center"></div>');
					}
					else{
						$("#lteMarketRows1").append('<div class="seatingLTEMarketrow2" id="' + sId + '" style="text-align:center"></div>');
					}
					for (var j = 1; j <= 50; j++) {
						if (j + i * 50 > fetchGnbDUMarkets2) {
							flag = true;
							break;
						}
						if (fetchEnbM2Data[j - 1 + i * 50].status == "On Air") {
								if(fetchEnbM2Data[j - 1 + i * 50].siteType !=null && fetchEnbM2Data[j - 1 + i * 50].siteType != ""){
									$("#" + sId).append('<div class="onAir" id="onAirtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM2Data[j - 1 + i * 50].enodebId + '\', 1, \'' + fetchEnbM2Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM2Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM2Data[j - 1 + i * 50].siteVersion + '\nFuzeSiteId: ' + fetchEnbM2Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM2Data[j - 1 + i * 50].cranHubName + '\nReserved: ' + fetchEnbM2Data[j - 1 + i * 50].siteType + '" style="border: 2px solid red">' + fetchEnbM2Data[j - 1 + i * 50].enodebId + ' </div>');
								}else{
									$("#" + sId).append('<div class="onAir" id="onAirtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM2Data[j - 1 + i * 50].enodebId + '\', 1, \'' + fetchEnbM2Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM2Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM2Data[j - 1 + i * 50].siteVersion + '\nFuzeSiteId: ' + fetchEnbM2Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM2Data[j - 1 + i * 50].cranHubName + '">' + fetchEnbM2Data[j - 1 + i * 50].enodebId + ' </div>');
								}
							} else if (fetchEnbM2Data[j - 1 + i * 50].status == "Assigned") {
								if(fetchEnbM2Data[j - 1 + i * 50].siteType !=null && fetchEnbM2Data[j - 1 + i * 50].siteType != ""){
									$("#" + sId).append('<div class="assigned" id="assignedtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM2Data[j - 1 + i * 50].enodebId + '\', 1, \'' + fetchEnbM2Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM2Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM2Data[j - 1 + i * 50].siteVersion + '\nFuzeSiteId: ' + fetchEnbM2Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM2Data[j - 1 + i * 50].cranHubName + '\nReserved: ' + fetchEnbM2Data[j - 1 + i * 50].siteType + '" style="border: 2px solid red">' + fetchEnbM2Data[j - 1 + i * 50].enodebId + ' </div>');
								}else{
									$("#" + sId).append('<div class="assigned" id="assignedtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM2Data[j - 1 + i * 50].enodebId + '\', 1, \'' + fetchEnbM2Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM2Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM2Data[j - 1 + i * 50].siteVersion + '\nFuzeSiteId: ' + fetchEnbM2Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM2Data[j - 1 + i * 50].cranHubName + '">' + fetchEnbM2Data[j - 1 + i * 50].enodebId + ' </div>');
								}
							} else {
								if(fetchEnbM2Data[j - 1 + i * 50].siteType !=null && fetchEnbM2Data[j - 1 + i * 50].siteType != ""){
									$("#" + sId).append('<div class="avliable" style="border: 2px solid red">' + fetchEnbM2Data[j - 1 + i * 50].enodebId + ' </div>');
								}else{
									$("#" + sId).append('<div class="avliable" >' + fetchEnbM2Data[j - 1 + i * 50].enodebId + ' </div>');
								}
							}

					}

				}

				var fetchGnbDUMarkets3 = fetchEnbM3Data.length;
				var fetchGnbDUSRows = Math.ceil(fetchGnbDUMarkets3 / 50);
				if (fetchGnbDUSRows) {
					$("#showHideMarkets").hide();
					var sId = tabIndexEnbAtollUpdate==2?"seatingMarketrow3" + i:"seatingLTEMarketrow3" + i;
					if(tabIndexEnbAtollUpdate==2){
						$("#dusMarketRows1").append('<div class="seatingMarketrow3" id="' + sId + '" style="text-align:center"></div>');
					}
					else{
						$("#lteMarketRows1").append('<div class="seatingLTEMarketrow3" id="' + sId + '" style="text-align:center"></div>');
					}

					for (var j = 1; j <= 50; j++) {
						if (j + i * 50 > fetchGnbDUMarkets3) {
							flag = true;
							break;
						}
						if (fetchEnbM3Data[j - 1 + i * 50].status == "On Air") {
								if(fetchEnbM3Data[j - 1 + i * 50].siteType !=null && fetchEnbM3Data[j - 1 + i * 50].siteType != ""){
									$("#" + sId).append('<div class="onAir" id="onAirtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM3Data[j - 1 + i * 50].enodebId + '\', 2, \'' + fetchEnbM3Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM3Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM3Data[j - 1 + i * 50].siteVersion + '\nFuzeSiteId: ' + fetchEnbM3Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM3Data[j - 1 + i * 50].cranHubName + '\nReserved: ' + fetchEnbM3Data[j - 1 + i * 50].siteType + '" style="border: 2px solid red" >' + fetchEnbM3Data[j - 1 + i * 50].enodebId + ' </div>');
								}else{
									$("#" + sId).append('<div class="onAir" id="onAirtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM3Data[j - 1 + i * 50].enodebId + '\', 2, \'' + fetchEnbM3Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM3Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM3Data[j - 1 + i * 50].siteVersion + '\nFuzeSiteId: ' + fetchEnbM3Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM3Data[j - 1 + i * 50].cranHubName + '">' + fetchEnbM3Data[j - 1 + i * 50].enodebId + ' </div>');
								}
							} else if (fetchEnbM3Data[j - 1 + i * 50].status == "Assigned") {
								if(fetchEnbM3Data[j - 1 + i * 50].siteType !=null && fetchEnbM3Data[j - 1 + i * 50].siteType != ""){
									$("#" + sId).append('<div class="assigned" id="assignedtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM3Data[j - 1 + i * 50].enodebId + '\', 2, \'' + fetchEnbM3Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM3Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM3Data[j - 1 + i * 50].siteVersion + '\nFuzeSiteId: ' + fetchEnbM3Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM3Data[j - 1 + i * 50].cranHubName + '\nReserved: ' + fetchEnbM3Data[j - 1 + i * 50].siteType + '" style="border: 2px solid red">' + fetchEnbM3Data[j - 1 + i * 50].enodebId + ' </div>');
								}else{
									$("#" + sId).append('<div class="assigned" id="assignedtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM3Data[j - 1 + i * 50].enodebId + '\', 2, \'' + fetchEnbM3Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM3Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM3Data[j - 1 + i * 50].siteVersion + '\nFuzeSiteId: ' + fetchEnbM3Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM3Data[j - 1 + i * 50].cranHubName + '">' + fetchEnbM3Data[j - 1 + i * 50].enodebId + ' </div>');
							}
							} else {
								if(fetchEnbM3Data[j - 1 + i * 50].siteType !=null && fetchEnbM3Data[j - 1 + i * 50].siteType != ""){
									$("#" + sId).append('<div class="avliable" style="border: 2px solid red" >' + fetchEnbM3Data[j - 1 + i * 50].enodebId + ' </div>');
								}else{
									$("#" + sId).append('<div class="avliable" >' + fetchEnbM3Data[j - 1 + i * 50].enodebId + ' </div>');
								}
							}
					}

				}
				// close

			}
			for (var i = 40; i < fetchGnbDUSRows; i++) {
				var sId =tabIndexEnbAtollUpdate==2? "seatingMarketrow" + i:"seatingLTEMarketrow" + i;
				if(tabIndexEnbAtollUpdate==2){
					$("#dusMarketRows2").append('<div class="seatingMarketrow" id="' + sId + '" style="text-align:center"></div>');
				}
				else{
					$("#lteMarketRows2").append('<div class="seatingLTEMarketrow" id="' + sId + '" style="text-align:center"></div>');
				}
				for (var j = 1; j <= 50; j++) {
					if (j + i * 50 > fetchGnbDUMarkets) {
						flag = true;
						break;
					}

					if (fetchEnbM1Data[j - 1 + i * 50].status == "On Air") {
							if(fetchEnbM1Data[j - 1 + i * 50].siteType !=null && fetchEnbM1Data[j - 1 + i * 50].siteType != ""){
								$("#" + sId).append('<div class="onAir" id="onAirtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM1Data[j - 1 + i * 50].enodebId + '\', \''+ null +'\',\'' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM1Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\nSiteInfoId: ' + fetchEnbM1Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM1Data[j - 1 + i * 50].cranHubName + '\nReserved: ' + fetchEnbM1Data[j - 1 + i * 50].siteType + '" style="border: 2px solid red">' + fetchEnbM1Data[j - 1 + i * 50].enodebId + ' </div>');
							} else{
								$("#" + sId).append('<div class="onAir" id="onAirtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM1Data[j - 1 + i * 50].enodebId + '\', \''+ null +'\',\'' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM1Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\nSiteInfoId: ' + fetchEnbM1Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM1Data[j - 1 + i * 50].cranHubName + '" >' + fetchEnbM1Data[j - 1 + i * 50].enodebId + ' </div>');
							}
						} else if (fetchEnbM1Data[j - 1 + i * 50].status == "Assigned") {
							if(fetchEnbM1Data[j - 1 + i * 50].siteType !=null && fetchEnbM1Data[j - 1 + i * 50].siteType != ""){
								$("#" + sId).append('<div class="assigned" id="assignedtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM1Data[j - 1 + i * 50].enodebId + '\', \''+ null +'\',\'' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM1Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\nSiteInfoId: ' + fetchEnbM1Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM1Data[j - 1 + i * 50].cranHubName + '\nReserved: ' + fetchEnbM1Data[j - 1 + i * 50].siteType + '" style="border: 2px solid red">' + fetchEnbM1Data[j - 1 + i * 50].enodebId + ' </div>');
							} else{
								$("#" + sId).append('<div class="assigned" id="assignedtooltip" onClick="showSectorCarrierView(\'' + fetchEnbM1Data[j - 1 + i * 50].enodebId + '\', \''+ null +'\',\'' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\')" data-title="SiteName:' + fetchEnbM1Data[j - 1 + i * 50].siteName + '\nSiteVersion: ' + fetchEnbM1Data[j - 1 + i * 50].siteVersion + '\nSiteInfoId: ' + fetchEnbM1Data[j - 1 + i * 50].siteInfoId + '\nHubName: ' + fetchEnbM1Data[j - 1 + i * 50].cranHubName + '">' + fetchEnbM1Data[j - 1 + i * 50].enodebId + ' </div>');
							}
						} else {
							if(fetchEnbM1Data[j - 1 + i * 50].siteType !=null && fetchEnbM1Data[j - 1 + i * 50].siteType != ""){
								$("#" + sId).append('<div class="avliable" style="border: 2px solid red">' + fetchEnbM1Data[j - 1 + i * 50].enodebId + ' </div>');
							}else{
								$("#" + sId).append('<div class="avliable">' + fetchEnbM1Data[j - 1 + i * 50].enodebId + ' </div>');
							}

						}

				}
				if (flag) {
					break;
				}
			}
		}
	}
}
