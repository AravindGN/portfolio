$(document).ready(function () {
    drawTable();

    $(function () {
        moment.tz.setDefault("America/New_York");
        $('input[name="datetimes"]').daterangepicker({
            timePicker: true,
            startDate: moment().startOf('hour'),  
            timePicker24Hour : true,
          endDate: moment().startOf('hour').add(32, 'hour'),
            locale: {
                format: 'M/DD HH:mm'
            }


        }, function (start, end, label) {

        }
        );
    });

    fetchAllMessages();
});


function postData() {
    if (!validateData())
        return;

    const message = document.getElementById('message').value;
    var drp = $('#daterange').data('daterangepicker');
    const startTimeStandard = drp.startDate.toISOString();
    const endTimeStandard = drp.endDate.toISOString()



    const data = {
        message: message,
        startStandardTime: startTimeStandard,
        endStandardTime: endTimeStandard

    };
    console.log("Calling postMessageAPI payload -> " + data);
    postMessageAPI(data);


}
var startTimePick;
var endTimePick;
document.getElementById('message').addEventListener('blur', validateData);

$('#daterange').on('showCalendar.daterangepicker', function (ev, picker) {
    //do something, like clearing an input
    startTimePick = null;
    endTimePick = null;
});

$('#daterange').on('apply.daterangepicker', function (ev, picker) {
    //do something, like clearing an input
    validateData();

});
$('#daterange').on('hide.daterangepicker', function (ev, picker) {
    //do something, like clearing an input
    validateData();
});
function convertToGMT(dateTime) {
    let date = new Date(dateTime);

    return date.toISOString();
}

function validateData() {
    let isValid = true;
    const message = document.getElementById('message').value;

    if (message != null && message != undefined && message != "" && message != " ")
        document.getElementById('messageError').style.display = 'none';
    else {
        isValid = false;
        document.getElementById('messageError').style.display = 'block';
    }

    var drp = $('#daterange').data('daterangepicker');
    if (drp != null && drp.startDate != null && drp.endDate != null)
        isValid = true;
    else
        isValid = false;


    if (isValid) {

        document.getElementById('postMessageButton').classList.remove('disableClick');
        document.getElementById('postMessageButton').disabled = false;
    }
    else {
        document.getElementById('postMessageButton').classList.add('disableClick');
        document.getElementById('postMessageButton').disabled = true;
    }
    return isValid;
}

function postMessageAPI(data) {

    $.ajax({
        type: 'POST',
        async: false,
        //  url: "http://localhost:8100/npp-atoll-services/atoll-in-app-notifications/postMessage",
        url: postMessageUrl,
        dataType: 'json',
        contentType: 'application/json; charset=UTF-8',
        cache: false,
        data: JSON.stringify(data),
        headers: {
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json'
        },
        success: function (data, textStatus, xhr) {
            console.log(data);
            let responseDate = data;
            if (textStatus != null && textStatus == "success") {
                // show Model
                aptAlert('Success', "Message posted Successfully");
            }
            else {
                aptAlert('Warning', 'Failed to post message');
            }
            // show failure

            fetchAllMessages();

        },
        error: function (data) {

            aptAlert('error', 'Failed to post message');
        }
    });


}


function aptAlert(status, message) {
    $("#alertsuccess").hide();
    $("#alerterror").hide();
    $("#alertinfo").hide();
    $("#alertwarning").hide();

    $("#alertTitle").html(status + '!');
    $("#alert" + status.toLowerCase()).html(message);
    $("#alert" + status.toLowerCase()).show();
    $("#myModal").css(
        "margin-top",
        Math.max(0, ($(window).height() - ($("#myModal").height() + 100)) / 2));
    $("#myModal").css(
        "margin-left",
        Math.max(0, ($(window).width() - $("#myModal").width()) / 2));
    $("#myModal").modal("show");
    $('#myModal').fadeIn(500, function () {
        setTimeout(function () {
            $('#myModal').fadeOut(500);
            $("#myModal").modal("hide");
        }, 5000);
      
    });}

var messageDataSource = new kendo.data.DataSource({
    data: [],
});
var messageId;
var messageColumns = [

    { title: 'Message ID', field: 'messageId', width: "100px" },
    {
        title: 'Message', field: 'message',
        template: ' <a target = "_self" id ="messageText"  onclick="openPopup(#=messageId#)"> #=message# </a>',
        width:"450px"
    },
    { title: 'Start Date (EST)', field: 'startTime', width: "180px" },
    { title: 'Expiry Date (EST)', field: 'endTime', width: "180px" },
    { "field": 'ACTION', "title": 'Action', template: '<button id="deleteMessageButton" class=" delete" onclick="deleteMessagePopup(#=messageId#)">Delete</button>', width: "75px" }];
    function deleteMessagePopup(data) {
        messageId = data;
        
        
        $("#deletConfirmationModal").modal("show");

    }


    $("#deletConfirmationCancel").click(function(){
        $('#loading').hide();
        $("#deletConfirmationModal").modal("hide");
    });

 // Show custom confirmation dialog
///

function deleteMessage(){
    console.log('success', messageId);
    $("#deletConfirmationModal").modal("hide");
   $.ajax({
       type: 'DELETE',
     url : deleteMessageUrl+"/"+messageId,
  //    url: "http://localhost:8100/npp-atoll-services/atoll-in-app-notifications/deleteMessage/"+messageId,
       success: function (data) {
           var returnedData = data;
           console.log('data', returnedData);
           console.log('success', 'All Messages successfully');
           aptAlert('Success', returnedData)
             fetchAllMessages();
    },
       error: function (err) {

           aptAlert('error', 'Something went wrong while fetching Messages');
           console.log('Fault', 'Something went wrong while fetching Project Details');
       }
   });
}
function drawTable() {

    $("#messageGrid").kendoGrid({
        dataSource: messageDataSource,
        columns: messageColumns,

        filterable: {
            operators: {
                //string:kendoGridManager.stringFilterOperator
            }
        },
        groupable: false,
        columnMenu: true,
        reorderable: true,
        pageable: {
            pageSizes: 5,
            input: true,
            numeric: false,
            pageSizes: [10, 20, 50, 100, "All"]

        },
        selectable: 'row',
        columnMenu: true,
        sortable: true,
        change: function () {
            // $('tbody tr').find('[type=checkbox]').prop('checked', false);
            // $(' tbody tr.k-state-selected').find('[type=checkbox]').prop('checked', true);
        },
        dataBound: function (e) {
            //			var rows = e.sender.element.find("tbody tr");
            //			rows.each(function(e){
            //				$(this).children().on("click", selectRow);
            //			})
        },
        noRecords: {
            template: "<div style='font-size:12px;color:red'>No data available</div>"
        },

    });
    grid = $("#messageGrid").data("kendoGrid");
}
var messageMap = new Map();
function fetchAllMessages() {
    $.ajax({
        type: 'GET',
        cache: false,
        contentType: 'application/json; charset=UTF-8',
        dataType: 'json',

        url : viewAllMessageUrl,
        // url: "http://localhost:8100/npp-atoll-services/atoll-in-app-notifications/all",
        success: function (data) {
            var returnedData = data;
            messageMap.clear();
            populateMessageMap(data);
            console.log('success', 'All Messages successfully');
            $('#messageGrid')
                .getKendoGrid()
                .setDataSource(
                    new kendo.data.DataSource({
                        pageSize: data.length,
                        data: limitMessages(data),

                    })
                );

        },
        error: function (err) {

            aptAlert('error', 'Something went wrong while fetching Messages');
            console.log('Fault', 'Something went wrong while fetching Project Details');
        }
    });
}


function limitMessages(data) {
    for (var i = 0; i < data.length; i++) {
        if (data[i].message.length > 100)
            data[i].message = formatMessage(data[i].message);

    }
    return data;
}
function formatMessage(message) {
    var msg = message.slice(0, 97);
    msg = msg.concat('...');
    return msg;
}

function populateMessageMap(data) {
    for (var i = 0; i < data.length; i++) {
        if (data[i].messageId != null && data[i].message != null) {
            messageMap.set(data[i].messageId, data[i].message);
        }
    }
}

function openPopup(id) {
    console.log("open Pop Up" + id);
    aptAlertessage('info', messageMap.get(id));
}

$(document).on('click', '#messageText', function(e){
    document.querySelectorAll('.k-state-selected').forEach(item => {
        item.classList.remove('k-state-selected');
    });
    var grid = $("#messageGrid").data("kendoGrid");
    var dataItem = grid.dataItem($(this).closest('tr'));
   var x = $("#messageGrid").data("kendoGrid")
    .tbody
    .find("tr[data-uid='" + dataItem.uid + "']");
    x.addClass('k-state-selected');
  });
function aptAlertessage(status, message) {
    $("#alertMsuccess").hide();
    $("#alertMerror").hide();
    $("#alertMinfo").hide();
    $("#alertMwarning").hide();

     
    $("#alertM" + status.toLowerCase()).html(editMessage(message));
    $("#alertM" + status.toLowerCase()).show();
    $("#myModalForMessage").css(
        "margin-top",
        Math.max(0, ($(window).height() - ($("#myModalForMessage").height() + 100)) / 2));
    $("#myModalForMessage").css(
        "margin-left",
        Math.max(0, ($(window).width() - $("#myModalForMessage").width()) / 2));
    $("#myModalForMessage").modal("show");
}

function editMessage(message)
{
  var msg =   message.replaceAll('\n', '<br/>');
  return msg;
}
