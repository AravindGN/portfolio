var grid = null
var siteDataGridColumns = [{ "field": 'ACTION', "title": 'Actions', template: '<i title="Project Inforamtion" onclick="getProjectInfo(event)" class="fas fa-eye" style="cursor: pointer; z-index:100;margin-left:11px;"></i>', width: "50px" }, { title: 'Site Name', field: 'siteName', width: "175px" }, { title: 'Fuze Site ID', field: 'fuzeSiteId' }, { title: 'eNB/gNB', field: 'eNodebId' }
	, { title: 'Site Type', field: 'siteType' }, { title: 'State', field: 'state' }, { title: 'County', field: 'county' }, { title: 'City', field: 'city' }, { title: 'Address', field: 'address' }];
var siteDatagrid;
var siteType = null;
var market = null;
var siteDataSource = new kendo.data.DataSource({
	data: [],
});
var loadOffScreenData = true;
var clearStatus = false;
var projectDataSource = new kendo.data.DataSource({
	data: [],
});
var leaf;
var t = XYZ.map();
var google_api_key = "AIzaSyBCDhGdiIbpa3jV-e7xuhwPfvJUUDZJNN8";
var attribution = "<span id='attributionSpan'>Cursor out of map bounds</span>";
var satellite_url = 'http://netgeo.vh.eng.vzwcorp.com/arcgis/rest/services/basemap_webmer/World_Imagery/MapServer/tile/{z}/{y}/{x}';
var grayscale_url = 'http://netgeo.vh.eng.vzwcorp.com/arcgis/rest/services/basemap_webmer/World_Topo_Map/MapServer/tile/{z}/{y}/{x}'
var streetmap_url = 'http://netgeo.vh.eng.vzwcorp.com/arcgis/rest/services/basemap_webmer/World_Street_Map/MapServer/tile/{z}/{y}/{x}';
var multiplier = 1.0;
var disableZoom = 20;
var splitClusters = null;
var tileOptions = { maxZoom: 19, minZoom: 2, opacity: .2, attribution: attribution, stamp: Date.now };
var clusterOptions = { maxRad: 1900, disableZoom: disableZoom, splitClusters: splitClusters };
var current_url = streetmap_url;
var defaultPageSize = 10;
var featureGroup = null;
var entireTerritoryList = [];
var entireAreaList = [];
var entireRegionList = [];
var entireMarketList = [];
var territoryDataProvider = [];
var areasDataProvider = [];
var regionsDataProvider = [];
var marketsDataProvider = [];
var siteStrucLocInfoObj = null;
var selectedSiteGridRowIndex = -1;
var selectedProjectGridRowIndex = -1;
var TERRITORY_DUMP = [];
var AREA_DUMP = [];
var REGION_DUMP = [];
var MARKET_DUMP = [];
var siteVersionDataProvider = [];
var e911DispatchableData = [];
var spreadsheetTransmitterObj;
var e911CharachterCount;
var currentRowSelected;
var updatedDl1;
var checkCharachterValue;
var selectedSiteVersion;
var intanceToCheckCellValidation;

var DL1;
var DL2;
var Zone;
var CVC;
var tempDL = [];
var tempDL2 = [];
var tempZone = [];
var tempCvc = [];
var tempCalCount;

var e911DynamicAssignmentcolumns = [
	{ name: 'transmitter', type: 'text', title: 'Transmitter', width: 300, readOnly: true, filter: true },
	{ name: 'dl1', type: 'dropdown', title: 'DL1', width: 80, source: DL1, filter: true },
	{ name: 'descp1', type: 'text', title: 'Descriptor 1', width: 140, filter: true },
	{ name: 'dl2', type: 'dropdown', title: 'DL2', width: 80, source: DL2, filter: true },
	{ name: 'descp2', type: 'text', title: 'Descriptor 2', width: 140, filter: true },
	{ name: 'zone', type: 'dropdown', title: 'Zone', width: 80, source: Zone, filter: true },
	{ name: 'descp3', type: 'text', title: 'Descriptor 3', width: 140, filter: true },
	{ name: 'cvc', type: 'dropdown', title: 'CVC', width: 80, source: CVC, filter: true },
	{ name: 'descp4', type: 'text', title: 'Descriptor 4', width: 140, filter: true },
	{ name: 'exisDespLoc', type: 'text', title: 'Existing E911 Dispatchable Location', width: 210, readOnly: true, wordWrap: true, filter: true },
	{ name: 'calcDespLoc', type: 'text', title: 'Calculated E911 Dispatchable Location', width: 220, readOnly: true, filter: true },
	{ name: 'charcount', type: 'number', title: 'Character Count', width: 100, readOnly: true, filter: true },
	{ name: 'updateAtoll', type: 'checkbox', title: 'Update Atoll', width: 70, filter: false },
];

var isDataPopulatingFromUploadFile = false;

// function getSummaryColumns() {
// 	return [

// 		{
// 			"title": "Site Name",
// 			"field": "sitename",
// 			width: 80,			
// 			headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		} ,
// 		{
// 			"title": "Fuze Site ID",
// 			"field": "fuzeSiteId",
// 			width: 80,			
// 			headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		},
// 		{
// 			"title": "eNB/gNB",
// 			"field": "eNodebId",
// 			width: 80,			
// 			headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		},
// 		{
// 			"title": "Site Type",
// 			"field": "sitetype",
// 			width: 80,			
// 			headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		},
// 		{
// 			"title": "State",
// 			"field": "state",
// 			width: 80,			
// 			headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		},

// 		{
// 			"title": "County",
// 			"field": "sitetype",
// 			width: 80,			
// 			headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		},

// 		{
// 			"title": "City",
// 			"field": "sitetype",
// 			width: 80,			
// 			headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		},

// 		{
// 			"title": "Address",
// 			"field": "sitetype",
// 			width: 80,			
// 			headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		},

// 		// {	"field": 'ACTION', "title": 'Actions', template: function() {
// 		// 		return '<i title="Edit" id="editProjectIcon" onclick="onProjectEditOrView(event, \'edit\')" class="fas fa-edit cloneIcon" style="cursor: pointer; z-index:100;float:left;margin-left:2px;"></i><i title="View" onclick="onProjectEditOrView(event, \'view\')" class="fas fa-eye" style="cursor: pointer; z-index:100;float:right;margin-right:4px;"></i>';
// 		// 	}, width: 50
// 		// }, {
// 		// 	"title": "Project Number",
// 		// 	"field": "projectnumber",
// 		// 	width: 50,			
//   		// 	headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		// }, {
// 		// 	"title": "Project Name",
// 		// 	"field": "projectname",
// 		// 	width: 80,			
// 		// 	headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		// },
// 		// {
// 		// 	"title": "NPP RFDS Project Id",
// 		// 	"field": "rfdsProjectId",
// 		// 	width: 80,			
// 		// 	headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		// },
// 		// {
// 		// 	"title": "SPM RFDS Project Id",
// 		// 	"field": "spmRfdsProjectId",
// 		// 	width: 80,			
// 		// 	headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		// },
// 		// {
// 		// 	"title": "Project Alt Name",
// 		// 	"field": "projectdescription",
// 		// 	width: 80,			
// 		// 	headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		// }, {
// 		// 	"title": "Project Template",
// 		// 	"field": "projecttemplate",
// 		// 	width: 80,			
// 		// 	headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		// },
// 		// {
// 		// 	"title": "Project Status",
// 		// 	"field": "projectstatus",
// 		// 	width: 70,			
// 		// 	headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		// },
// 		// {
// 		// 	"title": "Lock",
// 		// 	"field": "lock",
// 		// 	width: 80,			
// 		// 	headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		// },
// 		// {			
// 		// 	"title": "FP Solution",
// 		// 	"field": "fpSolution",
// 		// 	width: 70,			
// 		// 	headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		// }
// 		/*{
// 			"title": "Site Number",
// 			"field": "sitenumber",
// 			width: 50,		
// 			headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		}, {
// 			"title": "Site Name",
// 			"field": "sitename",
// 			width: 80,			
// 			headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		}, {
// 			"title": "Site Type",
// 			"field": "sitetype",
// 			width: 70,			
// 			headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		}, {
// 			"title": "Site Latitude",
// 			"field": "sitelatitude",
// 			width: 70,			
// 			headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		}, {
// 			"title": "Site Longitude",
// 			"field": "sitelongitude",
// 			width: 70,			
// 			headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		}*/
// 		// , {
// 		// 	"title": "Created By",
// 		// 	"field": "createdBy",
// 		// 	width: 70,			
// 		// 	headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		// }
// 		// , {
// 		// 	"title": "Created Date",
// 		// 	"field": "createdDate",
// 		// 	width: 70,			
// 		// 	headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		// }
// 		// , {
// 		// 	"title": "Updated Date",
// 		// 	"field": "updatedDate",
// 		// 	width: 70,			
// 		// 	headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		// }
// 		// , {
// 		// 	"title": "Submitted Date",
// 		// 	"field": "submittedDate",
// 		// 	width: 70,			
// 		// 	headerAttributes: { style: "white-space: normal; overflow : visible"}
// 		// }
// 	];
// }
function onProjectEditOrView(e, type) {
	//e.stopPropagation();
	let tr = $(e.target).closest("tr");
	let currentRowData;
	let mode;
	switch (type) {
		case 'edit':
			currentRowData = $("#projectGrid").data("kendoGrid").dataItem(tr);
			mode = (currentRowData != null && currentRowData.rpfProjectnumber != null) ? "2" : "1";
			break;

		case 'view':
			currentRowData = $("#projectGrid").data("kendoGrid").dataItem(tr);
			mode = (currentRowData != null && currentRowData.rpfProjectnumber != null) ? "4-2" : "4-3";
			break;
	}
	if (currentRowData && mode) {
		selectedProjectGridRowIndex = tr.index();
		storeState(currentRowData.fuzeSiteId);
		var url = CONTEXT_PATH + '/uui/eapp/rfds_pg/RfdsService?projectName=' + currentRowData.projectname + '&projectAltName=' + currentRowData.projectdescription + '&rfdsProjectId=' + currentRowData.rfdsProjectId + '&rfdsSpmStatus=' + currentRowData.projStatus + '&submittedDate=' + currentRowData.submittedDate + '&projectnumber=' + currentRowData.projectnumber + '&status=' + currentRowData.projectstatus + '&fuzeSiteId=' + currentRowData.fuzeSiteId + '&parentsolutionid=' + currentRowData.parentsolutionid + '&market=' + market + '&mode=' + mode + '&region=' + currentRowData.region + '&siteType=' + siteType + '&tmp=' + Date.parse(new Date());
		window.location.href = url;
	}
}
function getProjectInfo(e) {
	siteVersionDataProvider = [];
	siteVersionDataProvider = '';
	if (spreadsheetTransmitterObj) {
		spreadsheetTransmitterObj.destroy();
	}
	currentRowSelected = e;
	let tr = $(e.target).closest("tr");
	var selectedItem = $("#marketGrid").data("kendoGrid").dataItem(tr);
	if (selectedItem.fuzeSiteId && selectedItem.fuzeSiteId != "") {
		let payload = {
			fuzeSiteId: selectedItem.fuzeSiteId,
			siteVersion: ""
		};
		$.ajax({
			async: false,
			// url: "http://localhost:8100/npp-atoll-services/e911DispLocation/fetchSiteVersions",
			url: fetchSiteVersionsUrl,
			type: "POST",
			contentType: 'application/json; charset=UTF-8',
			data: JSON.stringify(payload),
			cache: false,
			success: function (data) {
				siteVersionDataProvider = data.respData;
				if (siteVersionDataProvider) {
					$('#versionDropdown').empty();
					$('#versionDropdown').append("<option>" + 'None Selected' + "</option>");
					$.each(siteVersionDataProvider, function (i, v) {
						$('#versionDropdown').append("<option>" + v + "</option>");

					});
				} else {
					$('#versionDropdown').empty();
					$('#versionDropdown').append("<option>" + 'None Selected' + "</option>");
					$('#updateE911LocationTable').hide();
					aptAlert('Warning', 'Versions are not Available for selected fuzesiteId');
				}

				VersionList = $('#versionDropdown').val() != null ? $('#versionDropdown').val() : siteVersionDataProvider;
			}
		});
	}

}

/*Document Ready*/
$(document).ready(function () {

	try {
		var env = window.location.href.includes('canvasple') ? '-PLE' : '';
        window.initClickstream({
            "system_name": "Network Planning Platform",
            "app_name": "ATOLL" + env,
            "screen_name": "E911 Dispatchable",
            "showLogs" : "true"
        });
    } catch(e) {
        return false;
    }

	kendo.pdf.defineFont({
		"DejaVuSans": "http://cdn.kendostatic.com/2014.3.1314/styles/fonts/DejaVu/DejaVuSans.ttf",
		"DejaVuSans-Bold": "http://cdn.kendostatic.com/2014.3.1314/styles/fonts/DejaVu/DejaVuSans-Bold.ttf"
	});

	$('#messageBanner').hide();
	loadDumpVariables();
	drawTable();
	//$('#siteNameSelect').attr("disabled", true);
	if (returnedFuzeSiteId == "") {
		populateTerritory(true);
		//		populateAreas(null, true);
		//		populateRegions(null, true);
		//		populateMarkets(null, true);
		$('#territoryDropdown').val('EAST').multiselect('refresh');
		populateAreas(['EAST'], true);
	}

	$("#siteNameSelect").val('');
	$('#aorFilterContainer').show();
	$("#aorfields").show();
	if (returnedFuzeSiteId == "") {
		//uiCache.loadAorData(function () {
		$('#siteNameDropdownContainer').show();
		//$("#aorfields").animate({ width: "0%" });
		//$("#aorfields").css("width", "0%" );
		//$("#aorfields").hide();	        	
		//$("#siteNameDropdownContainer").show();
		// disableAORFields();
		//});
	}

	//$('#siteNameDropdownContainer').show();
	//$("#aorfields").animate({ width: "0%" });
	//$("#aorfields").hide();	        	
	//$("#siteNameDropdownContainer").show();


	$("input[name='specificEnodeb']").change(function () {
		$('#aorFilterContainer').show();
		if ($("#specificEnodeb").prop('checked') == true) {
			$('#aorfields').show();
			//$('#aorfields').width = "0px";
			enableAORFields();
			if (returnedFuzeSiteId == "") {
				//uiCache.loadAorData(function () {
				$('#siteNameDropdownContainer').show();
				//$("#aorfields").animate({ width: "0%" });
				// Commenting below two lines to show aorfields - 09-07-2021 by Krishnakanth
				//$("#aorfields").css("width", "0%" );
				//$("#aorfields").hide();	        	
				//$("#siteNameDropdownContainer").show();
				// disableAORFields();
				//});
				uiCache.loadAorData(function () {
					$('#siteNameDropdownContainer').show();
				});
				// $('#territoryDropdown').val('EAST').multiselect('refresh');
				// populateAreas($('#territoryDropdown').val(), true);
			}
		} else {
			enableAORFields();
			$('#aorfields').show();
			// $("#aorfields").animate({ width: "90%" });
			//$("#aorfields").css("width", "90%" );
			// $('#aorfields').width = "600px";
			//$('#territoryDropdown').val('EAST').multiselect('refresh');
			populateAreas($('#territoryDropdown').val(), true);
		}
	});

	$("#siteSearchbtn").click(function () {
		$('.strip').hide();
		if (checkForMandatoryFields()) {
			let payloadData = formPayLoadForSiteSearchGrid();
			getSiteGridDetail(payloadData);
		}
	});
	$('#clearSearchBtn').click(function (e) {
		/*$('#territoryDropdown').multiselect("deselectAll", false).multiselect("refresh");
		populateAreas(null, true);
		populateRegions(null, true);
		populateMarkets(null, true);
		$('#siteNameSelect').attr("disabled", true);*/
		$("#siteNameSelect").val('');
		$("#eNodebIdSelect").val("");
		$("#projectNumberSelect").val("");
		$("#siteSearchbtn").attr('disabled',true);
		grid.setDataSource(
			new kendo.data.DataSource({
				pageSize: 10,
				data: [],
			}));
		$('#recentSitesData').addClass("in");
		$('#gridMinimize1').removeClass("collapsed");
		$('#siteDetailsData	').removeClass("in");
		$('#siteDetailsHeader').addClass("collapsed");
		selectedSiteGridRowIndex = -1;
		clearProjectDetils();

		//$("#specificEnodeb").prop('checked', true);

		$('#aorfields').show();
		//$('#aorfields').width = "0px";
		enableAORFields();
		if (returnedFuzeSiteId == "") {
			uiCache.loadAorData(function () {
				$('#siteNameDropdownContainer').show();
			});
		}
	});

	$("#onAir-tab").click(function () {
		$('#siteDetailsDiv').hide();
		$("#onAirServicesDiv").show();
	})
	$("#site-tab").click(function () {
		$('#siteDetailsDiv').show();
		$("#onAirServicesDiv").hide();
	});
	//drawProjectTable();
	//initMap();
	if (returnedFuzeSiteId == "") {
		setTimeout(function () {
			$('#siteDetailsData').removeClass("in");
		}, 2000);
	}
	$("#loading").hide();

	if (returnedFuzeSiteId != "") {
		//$("#specificEnodeb").prop('checked', false);
		restoreState(returnedFuzeSiteId);
		returnedFuzeSiteId = "";
	}
	else {
		$("input[name='specificEnodeb']").change();
	}

	$('#eNodebIdSelect').on('keypress', function (event) {
		if (event.which == 13) $('#siteSearchbtn').click();
	})
	$('#siteNameSelect').on('keypress', function (event) {
		if (event.which == 13 && $('#siteNameSelect').val().trim().length!=0)
		$('#siteSearchbtn').click();
	});
	$('#projectNumberSelect').on('keypress', function (event) {
		if (event.which == 13 && $('#projectNumberSelect').val().trim().length!=0) 
		$('#siteSearchbtn').click();
	});
	$('#siteNameSelect').on('change', function () {
		if ($('#siteNameSelect').val() === '') {			
			$('#siteSearchbtn').attr('disabled',true);
		}	
		else {
			if($('#siteNameSelect').val().trim().length!=0){
				$('#siteSearchbtn').attr('disabled',false);
			}
			else{
				$('#siteSearchbtn').attr('disabled',true);
			}
		}
	});
	$('#projectNumberSelect').on('change', function () {
		if ($('#projectNumberSelect').val() === '') {
			$('#eNodebIdSelect').prop('disabled', false);
			$('#siteNameSelect').prop('disabled', false);
			$('#territoryDropdown').multiselect('enable');
			$('#areaDropdown').multiselect('enable');
			$('#regionDropdown').multiselect('enable');
			$('#marketDropdown').multiselect('enable');
			$('#siteSearchbtn').attr('disabled',true);
		}
		else {
			$('#eNodebIdSelect').prop('disabled', true);
			$('#siteNameSelect').prop('disabled', true);
			$('#territoryDropdown').multiselect('disable');
			$('#areaDropdown').multiselect('disable');
			$('#regionDropdown').multiselect('disable');
			$('#marketDropdown').multiselect('disable');
			if($('#projectNumberSelect').val().trim().length!=0){
				$('#siteSearchbtn').attr('disabled',false);
			}
			else{
				$('#siteSearchbtn').attr('disabled',true);
			}
		}
	});

	document.getElementById("updateE911LocationTable").style.display = "none";
	$("#downloadTemplate").attr('disabled', 'disabled');

});

$(document).click(function (e) {

});
function populateTerritory(isServerCallReq) {

	if (isServerCallReq) {
		territoryDataProvider = [];
		$.ajax({
			url: CONTEXT_PATH + '/uui/eapp/rfds_pg/getTerritoryDropdown',
			dataType: 'json',
			type: "GET",
			async: false,
			success: function (data) {
				territoryDataProvider = data;
				if (loadOffScreenData) {
					entireTerritoryList = [];
					$.each(territoryDataProvider, function (index, value) {
						entireTerritoryList.push(value.TERRITORY);
					});
					populateAreas(entireTerritoryList, true);
				}
			},
			error: function (data) {
				showMessageBanner('error', 'Failed to load territory data!');
			}
		});
	} else {
		if (loadOffScreenData) {
			entireTerritoryList = [];
			$.each(territoryDataProvider, function (index, value) {
				entireTerritoryList.push(value.TERRITORY);
			});
			populateAreas(entireTerritoryList, true);
		}
	}


	$.each(territoryDataProvider, function (index, value) {
		$('#territoryDropdown').append("<option style='display:inline-block;' id='" + value.TERRITORY + "' value='" + value.TERRITORY + "' class='multis'>" + value.TERRITORY + "</option>");
	});

	$('#territoryDropdown').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		numberDisplayed: 1,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		nonSelectedText: 'Any',
		onChange: function (option, checked, select) {
			let tList = $('#territoryDropdown').val() != null ? $('#territoryDropdown').val() : entireTerritoryList;
			if (returnedFuzeSiteId == "") {
				populateAreas(tList, true);
			}
		},
		onDropdownHide: function (option, checked, select) {
			//            let tList = $('#territoryDropdown').val();
			//			if(returnedFuzeSiteId == "") {
			//				populateAreas(tList, true);
			//				populateRegions(null, true);
			//				populateMarkets(null, true);
			//				if(tList && tList.length > 0) {
			//					$('#siteNameSelect').removeAttr("disabled");
			//				}
			//				//$('#siteNameSelect').attr("disabled", true);
			//			}
			//           
			$("#siteNameSelect").val('');
		}
	});
}
function populateAreas(tList, isServerCallReq) {
	if (isServerCallReq) {
		areasDataProvider = [];
	}
	else {
		if (loadOffScreenData) {
			entireAreaList = [];
			$.each(areasDataProvider, function (index, value) {
				entireAreaList.push(value.area);
			});
			populateRegions(entireAreaList, true);
		}
	}
	if (tList != null) {
		var territoryList = JSON.stringify(tList);

		$.ajax({
			async: false,
			url: CONTEXT_PATH + '/uui/eapp/rfds_pg/getAreaForMarketBoundary',
			type: "POST",
			data: { territoryList: territoryList },
			cache: false,
			success: function (data) {
				areasDataProvider = JSON.parse(data).areas;
				if (loadOffScreenData) {
					entireAreaList = [];
					$.each(areasDataProvider, function (index, value) {
						entireAreaList.push(value.area);
					});
					populateRegions(entireAreaList, true);
				}
			}
		});
	}
	// $('.areaSel-block').html('');
	//$('.areaSel-block').html(' <select class="js-data-example-ajax" name="area" id="areaSel" style="width:100%;" multiple="multiple">  </select>');
	$('#areaDropdown').html('');
	$('#areaDropdown').multiselect('destroy');
	$.each(areasDataProvider, function (index, value) {
		$('#areaDropdown').append("<option value='" + value.area + "' class='multis'>" + value.areaname + "</option>");
	});

	$('#areaDropdown').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		numberDisplayed: 1,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		nonSelectedText: 'Any',
		onChange: function (option, checked, select) {
			let tList = $('#areaDropdown').val() != null ? $('#areaDropdown').val() : entireAreaList;
			if (returnedFuzeSiteId == "") {
				populateRegions(tList, true);
			}
		},
		onDropdownHide: function (option, checked, select) {
			//			if(returnedFuzeSiteId == "") {
			//				let areaList = $('#areaDropdown').val();
			//				populateRegions(areaList, true);
			//				populateMarkets(null, true);
			//				//$('#siteNameSelect').attr("disabled", true);	
			//			}

			$("#siteNameSelect").val('');
		}
	});
	setTimeout(function () {
		$('#areaDropdown').multiselect({
			includeSelectAllOption: true,
			enableFiltering: true,
			enableCaseInsensitiveFiltering: true,
			numberDisplayed: 1
		});
	}, 1);

}

function populateRegions(aList, isServerCallReq) {
	if (isServerCallReq) {
		regionsDataProvider = [];
	} else {
		if (loadOffScreenData) {
			entireRegionList = [];
			$.each(regionsDataProvider, function (index, value) {
				entireRegionList.push(value.region);
			});
			populateMarkets(entireRegionList, true);
		}
	}
	if (aList != null) {
		var areaList = JSON.stringify(aList);

		$.ajax({
			async: false,
			url: CONTEXT_PATH + '/uui/eapp/rfds_pg/getRegionsForMarketBoundary',
			type: "POST",
			data: { areaList: areaList },
			cache: false,
			success: function (data) {
				regionsDataProvider = JSON.parse(data).regions;
				if (loadOffScreenData) {
					entireRegionList = [];
					$.each(regionsDataProvider, function (index, value) {
						entireRegionList.push(value.region);
					});
					populateMarkets(entireRegionList, true);
				}
			}
		});
	}
	// $('.regionSel-block').html('');
	// $('.regionSel-block').html(' <select class="js-data-example-ajax" name="region" id="regionDropdown" style="width:100%;" multiple="multiple">  </select>');
	$('#regionDropdown').html('');
	$('#regionDropdown').multiselect('destroy');
	$.each(regionsDataProvider, function (index, value) {
		$('#regionDropdown').append("<option value='" + value.region + "' class='multis'>" + value.regionname + "</option>");
	});

	$('#regionDropdown').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		numberDisplayed: 1,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		nonSelectedText: 'Any',
		onChange: function (option, checked, select) {
			let tList = $('#regionDropdown').val() != null ? $('#regionDropdown').val() : entireRegionList;
			if (returnedFuzeSiteId == "") {
				populateMarkets(tList, true);
			}
		},
		onDropdownHide: function (option, checked, select) {
			//			if(returnedFuzeSiteId == "") {
			//				let regionList = $('#regionDropdown').val();
			//				populateMarkets(regionList, true);
			//				//$('#siteNameSelect').attr("disabled", true);
			//			}
			$("#siteNameSelect").val('');
		}
	});
	setTimeout(function () {
		$('#regionDropdown').multiselect({
			includeSelectAllOption: true,
			enableFiltering: true,
			enableCaseInsensitiveFiltering: true,
			numberDisplayed: 1
		});
	}, 1);
}

function populateMarkets(rList, isServerCallReq) {
	if (isServerCallReq) {
		marketsDataProvider = [];
	} else {
		if (loadOffScreenData) {
			entireMarketList = [];
			$.each(marketsDataProvider, function (index, value) {
				entireMarketList.push(value.MARKET);
			});
		}
	}
	if (rList != null) {
		var regionList = JSON.stringify(rList);
		$.ajax({
			async: false,
			url: CONTEXT_PATH + '/uui/eapp/rfds_pg/getMarketsForMarketBoundary',
			type: "POST",
			data: { regionList: regionList },
			cache: false,
			success: function (data) {
				marketsDataProvider = JSON.parse(data).markets;
				if (loadOffScreenData) {
					entireMarketList = [];
					$.each(marketsDataProvider, function (index, value) {
						entireMarketList.push(value.MARKET);
					});
				}
			}
		});
	}


	// $('.marketSel-block').html('');
	// $('.marketSel-block').html(' <select class="js-data-example-ajax" name="market" id="marketSel" style="width:100%;" multiple="multiple">  </select>');
	$('#marketDropdown').html('');
	$('#marketDropdown').multiselect('destroy');
	$.each(marketsDataProvider, function (index, value) {
		$('#marketDropdown').append("<option value='" + value.MARKET + "' class='multis'>" + value.MARKET + "-" + value.MARKETNAME + "</option>");
	});
	$('#marketDropdown').multiselect({
		includeSelectAllOption: true,
		enableFiltering: true,
		numberDisplayed: 1,
		enableCaseInsensitiveFiltering: true,
		buttonClass: 'btn btn-default whitebg btn-sm',
		nonSelectedText: 'Any',
		onDropdownHide: function (option, checked, select) {
			let marketValue = $('#marketDropdown').val();
			if (marketValue != null && marketValue.length > 0) {
				//$('#siteNameSelect').removeAttr("disabled");
				$("#siteNameSelect").val('');
			}

		},

	});

	$("#marketDropdown").attr("size", 3);
	setTimeout(function () {
		$('#marketDropdown').multiselect({
			includeSelectAllOption: true,
			enableFiltering: true,
			numberDisplayed: 1,
			enableCaseInsensitiveFiltering: true
		});
	}, 1);
}

function drawTable() {

	$("#marketGrid").kendoGrid({
		dataSource: siteDataSource,
		columns: siteDataGridColumns,

		filterable: {
			operators: {
				//string:kendoGridManager.stringFilterOperator
			}
		},
		groupable: false,
		columnMenu: true,
		reorderable: true,
		pageable: {
			pageSizes: 5,
			input: true,
			numeric: false,
			pageSizes: [10, 20, 50, 100, "All"]

		},
		selectable: 'row',
		columnMenu: true,
		sortable: true,
		change: function () {
			// $('tbody tr').find('[type=checkbox]').prop('checked', false);
			// $(' tbody tr.k-state-selected').find('[type=checkbox]').prop('checked', true);
		},
		dataBound: function (e) {
			//			var rows = e.sender.element.find("tbody tr");
			//			rows.each(function(e){
			//				$(this).children().on("click", selectRow);
			//			})
		},
		noRecords: {
			template: "<div style='font-size:12px;color:red'>No data available</div>"
		},
		// toolbar: [
		//     "excel", "pdf"
		// ],
		excel: {
			fileName: "SiteSearch Data.xlsx",
			allPages: true
		},
		pdf: {
			fileName: "SiteSearch Data.pdf",
			allPages: true
		}
	});
	grid = $("#marketGrid").data("kendoGrid");
}


function checkForMandatoryFields() {

	let mandatoryValue = $('#territoryDropdown').val();

	let siteNameValue = $("#siteNameSelect").val();
	if (typeof siteNameValue == 'undefined' || siteNameValue == null) {
		siteNameValue = '';
	}

	let enodebId = $("#eNodebIdSelect").val();
	if (typeof siteNameValue == 'undefined' || siteNameValue == null) {
		enodebId = '';
	}
	let projectNumber = $("#pojectNumberSelect").val();
	if (typeof siteNameValue == 'undefined' || siteNameValue == null) {
		projectNumber = '';
	}
	if (mandatoryValue == null && siteNameValue == '' && projectNumber == '' && enodebId == '') {
		showMessageBanner('warn', 'Please select Territory ');
		return false;
	}

	return true;
}
var siteSearchAjaxObj;
function getSiteGridDetail(payloadData) {
	$('#loading').show();
	$("#searchCancelIconContent").show();

	siteSearchAjaxObj = $.ajax({
		type: 'POST',
		//  url: baseUrl + '/siteinfo/fetchSiteDetails/',
		// url: "http://localhost:10803/plan-rfds/siteinfo/fetchSiteDetails",
		  url: fetchSiteDetailsUrl,
		dataType: 'json',
		contentType: 'application/json; charset=UTF-8',
		cache: false,
		data: JSON.stringify(payloadData),
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function (data) {
			var returnedData = data;
			$("#searchCancelIconContent").hide();
			if (returnedData.length < 1) {
				$('#loading').hide()

				showMessageBanner('info', 'No data found');
				//$('#clearSearchBtn').click();

				grid.setDataSource(
					new kendo.data.DataSource({
						pageSize: 10,
						data: [],
					}));
				$('#recentSitesData').addClass("in");
				$('#gridMinimize1').removeClass("collapsed");
				$('#siteDetailsData	').removeClass("in");
				$('#siteDetailsHeader').addClass("collapsed");
				selectedSiteGridRowIndex = -1;
				clearProjectDetils();
				return;
			}
			market = returnedData[0].market;
			$('#loading').hide();
			console.log('success', 'Site Search Record fetched successfully');
			$('#marketGrid')
				.getKendoGrid()
				.setDataSource(
					new kendo.data.DataSource({
						pageSize: data.length,
						data: data,
					})
				);
			clearProjectDetils();
			populateFields(data);
			//   if(data != null && data.length == 1) {
			// 	getProjectGridDetail({ projectNumber: $("#projectNumberSelect").val(),fuzeSiteId: data[0].fuzeSiteId }, -1);
			// 	// getSiteDetails(data[0].fuzeSiteId);
			//   } else {
			// 	$('#recentSitesData').addClass("in");
			// 	$('#gridMinimize1').removeClass("collapsed");
			// 	$('#siteDetailsData	').removeClass("in");
			// 	$('#siteDetailsHeader').addClass("collapsed");
			//   }

		},
		error: function (request, status, err) {
			$("#searchCancelIconContent").hide();
			$('#loading').hide();
			var statusText = request.statusText;
			if (statusText === 'abort') {
				//aptAlert('info', 'Cancelled Site Search');
				showMessageBanner("error", "Warning! Cancelled Site Search");
				console.log('Fault', 'Something went wrong while fetching Site Records '+err);
			}
			else {
				showMessageBanner('error', 'Something went wrong while fetching Site Records');
				console.log('Fault', 'Something went wrong while fetching Site Records '+err);
			}
		}
	});

}
function showMessageBanner(level, message) {
	$('#messageBanner').show();
	$('#messageBanner').text(message);
	if (level.toLowerCase() == "info") {
		$('#messageBanner').css("background-color", "yellow");
	}
	else if (level.toLowerCase() == "warn") {
		$('#messageBanner').css("background-color", "grey");
	}
	else if (level.toLowerCase() == "error") {
		$('#messageBanner').css("background-color", "pink");
	}
	setTimeout(function () {
		$('#messageBanner').hide();
	}, 3000);
}
function selectRow(e) {
	grid.clearSelection();
	//clearProjectDetils();
	var menuDiv = '<ul>' +
		'<li><span class="projectInfoIcon" id="projectInfo"></span><span id="projectInfo_a" class="icon-style">Project Information</span></li>' +
		'<li style="width: 1%;"><button id="closeBtn" type="button" class="close alphaBG" >&times;</button></li>' +
		'</ul>';
	$("#stripDiv").html(menuDiv);
	$('#closeBtn').bind('click', function () {
		$("#stripDiv").hide();
		e.stopPropagation();
	});
	$('#projectInfo, #projectInfo_a').bind('click', function () {
		var selectedItem = grid.dataItem(grid.select());
		if (selectedItem.fuzeSiteId && selectedItem.fuzeSiteId != "") {
			let payload = {
				projectNumber: $("#projectNumberSelect").val(),
				fuzeSiteId: selectedItem.fuzeSiteId
			};
			// getProjectGridDetail(payload, -1);
			// getSiteDetails(selectedItem.fuzeSiteId);

		} else {
			showMessageBanner('error', 'Site Name not available');
		}
		// var url = CONTEXT_PATH + '/uui/eapp/rfds_pg/RfdsSearch?tmp=' + Date.parse(new Date()) + '&fuzeSiteId=' + selectedItem.fuzeSiteId;
		// window.location.href = url;
	});
	var popupPosition = e.screenX < 100 ? 100 : e.screenX;
	if (popupPosition > 100) {
		if (popupPosition > 1100) {
			$("#stripDiv").css('right', 1300 - popupPosition);
		} else {
			$("#stripDiv").css('left', popupPosition);
		}

	} else {
		$("#stripDiv").css('left', popupPosition);
	}

	var offset = $(e.target).closest("tr").offset();
	$("#stripDiv").show().css('top', parseInt(offset.top) + 38);
	var tr = $(e.target).closest("tr");
	selectedSiteGridRowIndex = tr.index();
	if (tr.hasClass("k-state-selected") == false) {
		tr.addClass("k-state-selected");
	} else {
		tr.removeClass("k-state-selected");

		var rows = grid.select();
		if (rows == null || rows == undefined || rows.length == 0)
			$("#stripDiv").hide();
	}
}
function projectSelectRow(e) {
	let grid = $("#projectGrid").data("kendoGrid");
	grid.clearSelection();
	let menuDiv = '<ul>' +
		'<li><span class="editInfoIcon" id="editInfo"></span><span id="editInfo_a" class="icon-style">Edit</span></li>' +
		'<li><span class="fa fa-map-marker fa-2x viewInfoIcon" id="viewInfo"></span><span id="viewInfo_a" class="icon-style">View</span></li>' +
		'<li style="width: 10%;"><button id="projectCloseBtn" type="button" class="close alphaBG" >&times;</button></li>' +
		'</ul>';
	$("#projectStripDiv").html(menuDiv);
	$('#projectCloseBtn').bind('click', function () {
		$('#projectStripDiv').hide();
		e.stopPropagation();
	});
	$('#editInfo, #editInfo_a, #viewInfo, #viewInfo_a, #addInfo, #addInfo_a').bind('click', function (event) {

		let grid = $("#projectGrid").data("kendoGrid");
		let selectedItem = grid.dataItem(grid.select());
		let mode;

		if (event.target.id.includes("edit")) {
			mode = (selectedItem != null && selectedItem.rpfProjectnumber != null) ? "2" : "1";
		} else {
			mode = (selectedItem != null && selectedItem.rpfProjectnumber != null) ? "3-2" : "3-1";
		}

		storeState(selectedItem.fuzeSiteId);
		var url = CONTEXT_PATH + '/uui/eapp/rfds_pg/RfdsService?projectName=' + selectedItem.projectname + '&projectAltName=' + selectedItem.projectdescription + '&rfdsProjectId=' + selectedItem.rfdsProjectId + '&rfdsSpmStatus=' + currentRowData.projStatus + '&submittedDate=' + currentRowData.submittedDate + '&projectnumber=' + selectedItem.projectnumber + '&status=' + selectedItem.projectstatus + '&fuzeSiteId=' + selectedItem.fuzeSiteId + '&parentsolutionid=' + selectedItem.parentsolutionid + '&market=' + market + '&mode=' + mode + '&region=' + selectedItem.region + '&tmp=' + Date.parse(new Date());
		window.location.href = url;
	});
	let popupPosition = e.screenX < 100 ? 100 : e.screenX;
	if (popupPosition > 100) {
		if (popupPosition > 1100) {
			$("#projectStripDiv").css('right', 1300 - popupPosition);
		} else {
			$("#projectStripDiv").css('left', popupPosition);
		}

	} else {
		$("#projectStripDiv").css('left', popupPosition);
	}

	let offset = $(e.target).closest("tr").offset();
	$('#projectStripDiv').show().css('top', parseInt(offset.top) + 38);
	let tr = $(e.target).closest("tr");
	selectedProjectGridRowIndex = tr.index();
	if (tr.hasClass("k-state-selected") == false) {
		tr.addClass("k-state-selected");
	} else {
		tr.removeClass("k-state-selected");

		let rows = grid.select();
		if (rows == null || rows == undefined || rows.length == 0)
			$('#projectStripDiv').hide();
	}
}


function formPayLoadForSiteSearchGrid() {
	let payload = {};

	let territory = $('#territoryDropdown').val() != null ? $('#territoryDropdown').val() : TERRITORY_DUMP;
	payload.territory = territory;

	let area = ($('#areaDropdown').val() != null) ? $('#areaDropdown').val() : [...document.getElementById('areaDropdown')].map(o => o.value).length > 0 ? [...document.getElementById('areaDropdown')].map(o => o.value) : AREA_DUMP;
	payload.area = area;

	let region = ($('#regionDropdown').val() != null) ? $('#regionDropdown').val() : [...document.getElementById('regionDropdown')].map(o => o.value).length > 0 ? [...document.getElementById('regionDropdown')].map(o => o.value) : REGION_DUMP;
	payload.region = region;

	let market = $('#marketDropdown').val() != null ? $('#marketDropdown').val() : [...document.getElementById('marketDropdown')].map(o => o.value).length > 0 ? [...document.getElementById('marketDropdown')].map(o => o.value) : MARKET_DUMP;
	payload.market = market;

	let siteName = $('#siteNameSelect').val();
	payload.siteName = siteName;

	let enodebId = $('#eNodebIdSelect').val();
	payload.enodebId = enodebId;

	let projectNumber = $('#projectNumberSelect').val();
	payload.projectNumber = projectNumber;

	return payload;
}
function downloadProjectData() {
	var grid = $("#projectGrid").data("kendoGrid");
	grid.saveAsExcel();
}

var projectStatusNumbers = {
	"ACTIVE": 1,
	"PENDING": 2,
	"CANCELED": 3,
	"COMPLETED": 4
};

function getProjectGridDetail(payloadData, selectedIndex) {
	$('#loading').show();
	$.ajax({
		type: 'POST',
		cache: false,
		contentType: 'application/json; charset=UTF-8',
		dataType: 'json',
		data: JSON.stringify(payloadData),
		//url: baseUrl + '/siteinfo/fetchProjectDetails',
		// url: 'http://localhost:8100/npp-atoll-services/e911DispLocation/fetchDispLoc',
		url: fetchDispLocUrl,
		success: function (data) {
			$('#loading').hide();
			$("#virtualAssignmentGridInfo").show();
			$("#updateE911LocationTable").show();
			e911DispatchableData = data;
			$("#downloadTemplate").removeAttr('disabled');
			if (spreadsheetTransmitterObj) {
				spreadsheetTransmitterObj.destroy();
			}

			if (e911DispatchableData.length == 1 && !e911DispatchableData[0].transmitter) {
				aptAlert('error', 'No Data available');
				spreadsheetTransmitterObj.destroy();
				$("#virtualAssignmentGridInfo").hide();
				$("#updateE911LocationTable").hide();
			}
			creatingJSpreadsheeteAssignment(e911DynamicAssignmentcolumns, spreadsheetAssignmet, e911DispatchableData, false);

		},
		error: function (err) {
			$('#loading').hide();
			$('.strip').hide();
			$('#updateE911LocationTable').hide();
			showMessageBanner('error', 'Something went wrong while fetching Project Details');
			console.log('Fault', 'Something went wrong while fetching Project Details');
		}
	});
}
function compareFunc(a, b) {
	return projectStatusNumbers[a.projectstatus] - projectStatusNumbers[b.projectstatus];
}
function getSiteDetails(fuzeSiteId) {
	if (fuzeSiteId == null || fuzeSiteId == "" || fuzeSiteId == '0') {
		//aptAlert('error', 'Site Name not available');
		return;
	}
	var projectnumber = $("#projectNumberSelect").val();
	$('#loading').show();
	$.ajax({
		type: 'GET',
		cache: false,
		contentType: 'application/json; charset=UTF-8',
		dataType: 'json',
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		data: { fuzeSiteId: fuzeSiteId, rfdsProjectNumber: projectnumber },
		beforeSend: function (xhr) {
			xhr.setRequestHeader('user_id', VZID);
		},
		url: baseUrl + '/siteinfo/fetchSiteDetailsByFuzeSiteIdOrProjectNumber/',
		// url: 'http://10.118.229.72:10803/plan-rfds/siteinfo/fetchSiteDetailsByFuzeSiteId/',
		success: function (data) {
			var returnedData = data;
			$('#loading').hide();
			try {
				siteStrucLocInfoObj = returnedData
				populateFields(returnedData);
				market = returnedData[0].market;
			} catch (error) { console.log(error); }
			//showAlert('success', 'Required metadata loaded');
		},
		error: function (err) {
			$('#loading').hide();
			showMessageBanner('error', 'Something went wrong while fetching Site data');
		}
	});
}
function populateFields(returnedData) {
	if (returnedData != null && returnedData.length > 0) {
		let carryObj = returnedData[0];
		$('#siteId').html(carryObj.fuzeSiteId);
		$('#siteName').html(carryObj.siteName);
		$('#searchRing').html("");
		$('#eNodebId').html((carryObj.eNodebId != null && carryObj.eNodebId != undefined) ? carryObj.eNodebId : "");
		$('#switchName').html((carryObj.switchName != null && carryObj.switchName != undefined) ? carryObj.switchName : "");
		$('#towerOwner').html("");
		$('#siteType').html(carryObj.siteType);
		siteType = carryObj.siteType;
		$('#siteStatus').html(carryObj.status);
		$('#cellNumber').html((carryObj.marketId != null && carryObj.marketId != undefined) ? carryObj.marketId : "");

		$('#streetAddress').html(carryObj.address);
		$('#city').html(carryObj.city);
		$('#state').html(carryObj.state);
		$('#zipCode').html(carryObj.zipcode);
		$('#county').html(carryObj.county);
		$('#latitude').html(carryObj.latitude);
		$('#longitude').html(carryObj.longitude);

		// focusSiteOnMap(carryObj);
	}
}
function aptAlert(status, message) {
	$("#alertsuccess").hide();
	$("#alerterror").hide();
	$("#alertinfo").hide();
	$("#alertwarning").hide();

	$("#alertTitle").html(status + '!');
	$("#alert" + status.toLowerCase()).html(message);
	$("#alert" + status.toLowerCase()).show();
	$("#myModal").css(
		"margin-top",
		Math.max(0, ($(window).height() - ($("#myModal").height() + 100)) / 2));
	$("#myModal").css(
		"margin-left",
		Math.max(0, ($(window).width() - $("#myModal").width()) / 2));
	$("#myModal").modal("show");
}

function clearProjectDetils() {
	$('#siteId').html("");
	$('#searchRing').html("");
	$('#siteName').html("");
	$('#eNodebId').html("");
	$('#switchName').html("");
	$('#towerOwner').html("");
	$('#siteType').html("");
	$('#siteStatus').html("");
	$('#cellNumber').html("");

	$('#streetAddress').html("");
	$('#city').html("");
	$('#state').html("");
	$('#zipCode').html("");
	$('#county').html("");
	$('#latitude').html("");
	$('#longitude').html("");

	selectedProjectGridRowIndex = -1;

	if (featureGroup)
		featureGroup.clearLayers();

	$('#versionDropdown').empty();
	$('#versionDropdown').append("<option>" + 'None Selected' + "</option>");
	$('#updateE911LocationTable').hide();

	cleare911DataTable();
	if (spreadsheetTransmitterObj) {
		spreadsheetTransmitterObj.destroy();
	}
	e911DispatchableData = [];
	$("#downloadTemplate").attr('disabled', 'disabled');
	$('#uploadTemplate').attr('disabled', 'disabled');
}
function storeState(fuzeSiteId) {
	if (window.sessionStorage) {
		sessionStorage.removeItem(fuzeSiteId);
		sessionStorage.setItem(fuzeSiteId, JSON.stringify(formStateData()));
		try {
			sessionStorage.setItem(fuzeSiteId + "grid", JSON.stringify(getDatagridInfo()));
		} catch (exp) {
			console.log("Cannot retain datagrid records", exp);
		}
	}
}
function restoreState(fuzeSiteId) {
	if (window.sessionStorage && sessionStorage.getItem(fuzeSiteId)) {
		var prevState = JSON.parse(sessionStorage.getItem(fuzeSiteId));

		if (prevState != null && prevState != undefined) {
			let obj = prevState.isAorSettingEnabled;
			if (!obj || obj == "false") $("#specificEnodeb").prop('checked', false);
			else $("#specificEnodeb").prop('checked', obj);

			//if(obj!= null && (obj == "false" || obj == false)) {
			//$("#specificEnodeb").change();

			obj = prevState.territorySel;
			territoryDataProvider = getProvider(obj.dataProvider);
			populateTerritory(false);
			//fillMultiSelectDropdownProvider("#territoryDropdown", obj.dataProvider);
			obj.selectedValue != "" ? $("#territoryDropdown").val(obj.selectedValue).multiselect("refresh") : "";

			obj = prevState.areaSel;
			areasDataProvider = getProvider(obj.dataProvider);
			if (areasDataProvider != null && areasDataProvider.length > 0)
				populateAreas($("#territoryDropdown").val(), false);
			//fillMultiSelectDropdownProvider("#areaDropdown", obj.dataProvider);
			obj.selectedValue != "" ? $("#areaDropdown").val(obj.selectedValue).multiselect("refresh") : "";

			obj = prevState.regionSel;
			regionsDataProvider = getProvider(obj.dataProvider);
			if (regionsDataProvider != null && regionsDataProvider.length > 0)
				populateRegions($("#areaDropdown").val(), false);
			//fillMultiSelectDropdownProvider("#regionDropdown", obj.dataProvider);
			obj.selectedValue != "" ? $("#regionDropdown").val(obj.selectedValue).multiselect("refresh") : "";

			obj = prevState.marketSel;
			marketsDataProvider = getProvider(obj.dataProvider);
			if (marketsDataProvider != null && marketsDataProvider.length > 0)
				populateMarkets($("#regionDropdown").val(), false);
			//fillMultiSelectDropdownProvider("#marketDropdown", obj.dataProvider);
			obj.selectedValue != "" ? $("#marketDropdown").val(obj.selectedValue).multiselect("refresh") : "";
			//}


			obj = prevState.siteNameSelect;

			$('#siteNameSelect').removeAttr("disabled");

			obj = prevState.siteStrucLocInfoObj;
			siteStrucLocInfoObj = obj;
			if (obj != undefined && obj != null) {
				populateFields(obj);
			}
			console.log(prevState);
			$("#siteNameSelect").val(prevState.siteName);
			$("#eNodebIdSelect").val(prevState.enodebId);
			$("#projectNumberSelect").val(prevState.projectNumber);
		}
	}
	if (window.sessionStorage && sessionStorage.getItem(fuzeSiteId + "grid")) {
		var prevGridState = JSON.parse(sessionStorage.getItem(fuzeSiteId + "grid"));
		let obj = prevGridState.siteDataGrid
		if (obj != undefined && obj != null && obj.options) {
			$("#marketGrid").data("kendoGrid").setOptions(JSON.parse(obj.options));
			if (obj.selectedIndex != -1) {
				$("#marketGrid").data("kendoGrid").select("tr:eq(" + (obj.selectedIndex) + ")");
			}
		}
		obj = prevGridState.projectDataGrid
		if (obj != undefined && obj != null && obj.options) {

			let returnedProjectNumber = $("#projectNumberSelect").val();
			let payload = {
				fuzeSiteId: returnedFuzeSiteId,
				projectNumber: returnedProjectNumber
			};
			getSiteDetails(fuzeSiteId);
			// getProjectGridDetail(payload, obj.selectedIndex);

		}
	}
	sessionStorage.removeItem(fuzeSiteId);
	sessionStorage.removeItem(fuzeSiteId + "grid");
	//$("#siteSearchbtn").click();
}
function getProvider(dataProvider) {
	return (dataProvider != undefined && dataProvider != null && dataProvider != "" && dataProvider.length > 0) ? dataProvider : [];
}
function formStateData() {
	var stateObj = {};

	stateObj.isAorSettingEnabled = $("#specificEnodeb").prop('checked');
	//if((!$("#specificEnodeb").prop('checked'))) {
	stateObj.territorySel = { dataProvider: territoryDataProvider, selectedValue: ($('#territoryDropdown').val() != null ? $('#territoryDropdown').val() : "") };
	stateObj.areaSel = { dataProvider: areasDataProvider, selectedValue: ($('#areaDropdown').val() != null ? $('#areaDropdown').val() : "") };
	stateObj.regionSel = { dataProvider: regionsDataProvider, selectedValue: ($('#regionDropdown').val() != null ? $('#regionDropdown').val() : "") };
	stateObj.marketSel = { dataProvider: marketsDataProvider, selectedValue: ($('#marketDropdown').val() != null ? $('#marketDropdown').val() : "") };
	//}
	stateObj.siteNameSelect = { dataProvider: [], selectedValue: ($('#siteNameSelect').val() != null ? $('#siteNameSelect').val() : "") };
	stateObj.siteName = $('#siteNameSelect').val();
	stateObj.enodebId = $("#eNodebIdSelect").val();
	stateObj.projectNumber = $("#projectNumberSelect").val();

	if (siteStrucLocInfoObj != null && siteStrucLocInfoObj != undefined)
		stateObj.siteStrucLocInfoObj = siteStrucLocInfoObj;
	//Storing Site list datagrid


	return stateObj;
}
function getDatagridInfo() {
	let gridStateObj = {};

	try {
		gridStateObj.siteDataGrid = { selectedIndex: selectedSiteGridRowIndex, options: kendo.stringify($("#marketGrid").data("kendoGrid").getOptions()) };
	} catch (exp) {

		console.log("Cannot retain Site list records", exp);
	}

	//Storing Project list datagrid
	try {
		gridStateObj.projectDataGrid = { selectedIndex: selectedProjectGridRowIndex, options: kendo.stringify($("#projectGrid").data("kendoGrid").getOptions()) };
	} catch (exp) {
		console.log("Cannot retain Project list records", exp);
	}

	return gridStateObj;
}
function fillMultiSelectDropdownProvider(dropdownObj, providerObj) {
	if (providerObj != null) {
		switch (dropdownObj) {
			case "#marketDropdown":
				$.each(providerObj, function (index, value) {
					$(dropdownObj).append("<option style='display:inline-block;' id='" + value.MARKET + "' value='" + value.MARKET + "' class='multis'>" + value.MARKET + "-" + value.MARKETNAME + "</option>");
				});
				break;
			case "#territoryDropdown":
				$.each(providerObj, function (index, value) {
					$(dropdownObj).append("<option style='display:inline-block;' id='" + value.TERRITORY + "' value='" + value.TERRITORY + "' class='multis'>" + value.TERRITORY + "</option>");
				});
				break;
			case "#areaDropdown":
				$.each(providerObj, function (index, value) {
					$(dropdownObj).append("<option style='display:inline-block;' id='" + value.area + "' value='" + value.area + "' class='multis'>" + value.areaname + "</option>");
				});
				break;
			case "#regionDropdown":
				$.each(providerObj, function (index, value) {
					$(dropdownObj).append("<option style='display:inline-block;' id='" + value.region + "' value='" + value.region + "' class='multis'>" + value.regionname + "</option>");
				});
				break;
		}
	}
}

function enableAORFields() {
	$('#territoryDropdown').multiselect('enable');
	$('#areaDropdown').multiselect('enable');
	$('#regionDropdown').multiselect('enable');
	$('#marketDropdown').multiselect('enable');
	$('#countyDropdown').multiselect('enable');
	$('#rfEngDropdown').multiselect('enable');
	$("#enodebSearchInput").prop('disabled', false);
}

function disableAORFields() {
	$('#territoryDropdown').multiselect('disable');
	$('#areaDropdown').multiselect('disable');
	$('#regionDropdown').multiselect('disable');
	$('#marketDropdown').multiselect('disable');
	$('#countyDropdown').multiselect('disable');
	$("#enodebSearchInput").prop('disabled', true);
	$('#rfEngDropdown').multiselect('disable');
}

//Payload generation to fetch sitename
function formPayLoadForGetSiteName() {
	let payload = {};
	let temp = JSON.stringify(($('#territoryDropdown').val() != null) ? $('#territoryDropdown').val() : entireTerritoryList);
	payload.territory = temp;

	temp = JSON.stringify(($('#areaDropdown').val() != null) ? $('#areaDropdown').val() : entireAreaList);
	payload.area = temp;

	temp = JSON.stringify(($('#regionDropdown').val() != null) ? $('#regionDropdown').val() : entireRegionList);
	payload.region = temp;

	temp = JSON.stringify(($('#marketDropdown').val() != null) ? $('#marketDropdown').val() : entireMarketList);
	payload.market = temp;

	temp = JSON.stringify($('#siteNameSelect').val());
	payload.siteName = temp;

	temp = JSON.stringify($('#eNodebIdSelect')).val();
	payload.enodebId = temp;
	return payload;
}

var loadDumpVariables = function () {
	TERRITORY_DUMP = ['EAST', 'WEST'];
	$.ajax({
		async: false,
		url: CONTEXT_PATH + '/uui/eapp/rfds_pg/getAreaForMarketBoundary',
		type: "POST",
		data: { territoryList: TERRITORY_DUMP },
		success: function (data) {
			AREA_DUMP = JSON.parse(data).areas.map(x => x.area);
		}
	});
	$.ajax({
		async: false,
		url: CONTEXT_PATH + '/uui/eapp/rfds_pg/getRegionsForMarketBoundary',
		type: "POST",
		data: { areaList: JSON.stringify(AREA_DUMP) },
		success: function (data) {
			REGION_DUMP = JSON.parse(data).regions.map(x => x.region);
		}
	})
	$.ajax({
		async: false,
		url: CONTEXT_PATH + '/uui/eapp/rfds_pg/getMarketsForMarketBoundary',
		type: 'POST',
		data: { regionList: JSON.stringify(REGION_DUMP) },
		success: function (data) {
			MARKET_DUMP = JSON.parse(data).markets.map(x => x.MARKET);
		}
	})
}

$("#searchCancelIconContent").click(function () {
	siteSearchAjaxObj.abort();
	$("#searchCancelIconContent").hide();
});


// column validation code
// after selecting version showing data Table

var spreadsheetAssignmet = 'virtualAssignmentGridInfo';
var containerScroll;

function creatingJSpreadsheeteAssignment(e911DynamicAssignmentcolumns, spreadsheetAssignmet, e911DispatchableData, isFile) {

	if (spreadsheetTransmitterObj) {
		spreadsheetTransmitterObj.destroy();
	}

	$.each(e911DispatchableData, function (index, value) {
		delete value.market;
		delete value.fuzeSiteId;
		value.dl1 = value.dl1 ? value.dl1.toUpperCase(): '';
		value.descp1 = value.descp1 ? (typeof value.descp1 === 'number' ? value.descp1:value.descp1.toUpperCase()): '';
		value.dl2 = value.dl2 ? value.dl2.toUpperCase(): '';
		value.descp2 = value.descp2 ? (typeof value.descp2 === 'number' ? value.descp2:value.descp2.toUpperCase()): '';
		value.cvc = value.cvc ? value.cvc.toUpperCase(): '';
		value.descp3 = value.descp3 ? (typeof value.descp3 === 'number' ? value.descp3:value.descp3.toUpperCase()): '';
		value.zone = value.zone ? value.zone.toUpperCase(): '';
		value.descp4 = value.descp4 ? (typeof value.descp4 === 'number' ? value.descp4:value.descp4.toUpperCase()): '';
		value.calcDespLoc = value.calcDespLoc ? value.calcDespLoc.toUpperCase(): '';
	});

	if (spreadsheetAssignmet == 'virtualAssignmentGridInfo') {
		document.getElementById("updateE911LocationTable").style.display = "block"
		spreadsheetTransmitterObj = jspreadsheet(document.getElementById(spreadsheetAssignmet), {
			data: e911DispatchableData,
			autoIncrement : false,
			columns: e911DynamicAssignmentcolumns,
			tableOverflow: true,
			tableWidth: '100%',
			minSpareRows: 0,
			minDimensions: [0, 6],
			filters: false,

			onchange: function (instance, cell, c, r, value) {
				containerScroll = $( ".jexcel_content" ).scrollTop();
				isDataPopulatingFromUploadFile = false;
				cellValueChange = true;
				transmittergridinfoChange(instance, cell, c, r, value);
			},

			onload: function (instance) {

				// if(isFile) fileValid(instance);

				// on Cell change
				if (cellValueChange) {
					var row = document.getElementsByClassName('jexcel jexcel_overflow')[0].rows;
					for (var j = 1; j < row.length; j++) {
						if (updatedE911DispatchableDataNew[j - 1].calcDespLoc) {
							if (updatedE911DispatchableDataNew[j - 1].calcDespLoc.includes(',')) {
								var temp = updatedE911DispatchableDataNew[j - 1].calcDespLoc.split(',');
								row[j].cells[2].innerHTML = temp[0].trim();
								row[j].cells[4].innerHTML = temp[2].trim();
								row[j].cells[6].innerHTML = temp[4].trim();
								row[j].cells[8].innerHTML = temp[6].trim();

								if (!tempDL.includes(row[j].cells[2].innerHTML)) {
									if (row[j].cells[2].innerHTML) {
										document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[j].cells[2].className = "maxCharachterCount";
									}
								}
								if (!tempDL2.includes(row[j].cells[4].innerHTML)) {
									if (row[j].cells[4].innerHTML) {
										document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[j].cells[4].className = "maxCharachterCount";
									}
								}
								if (!tempZone.includes(row[j].cells[6].innerHTML)) {
									if (row[j].cells[6].innerHTML) {
										document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[j].cells[6].className = "maxCharachterCount";
									}
								}
								if (!tempCvc.includes(row[j].cells[8].innerHTML)) {
									if (row[j].cells[8].innerHTML) {
										document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[j].cells[8].className = "maxCharachterCount";
									}
								}

								row[j].cells[11].innerHTML = temp.toString().replace(/,/g, "");
								row[j].cells[11].innerHTML = row[j].cells[11].innerHTML.replace(/\s+/g, ' ').trim()
								row[j].cells[12].innerHTML = row[j].cells[11].innerHTML.length;
								console.log('row[j].cells[11].innerHTML', row[j].cells[11].innerHTML);
							} else {
								var newCalValues = updatedE911DispatchableDataNew[j - 1].calcDespLoc.split(' ');
								row[j].cells[2].innerHTML = newCalValues[0]? newCalValues[0]: '';
								row[j].cells[4].innerHTML = newCalValues[2]?newCalValues[2]: '';
								row[j].cells[6].innerHTML = newCalValues[4]? newCalValues[4]: '';
								row[j].cells[8].innerHTML =  newCalValues[6]? newCalValues[6]:'';
								console.log('tempDL2', tempDL2);
								if (!tempDL.includes(row[j].cells[2].innerHTML)) {
									if (row[j].cells[2].innerHTML) {
										document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[j].cells[2].className = "maxCharachterCount";
									}
								}
								if (!tempDL2.includes(row[j].cells[4].innerHTML)) {
									if (row[j].cells[4].innerHTML) {
									document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[j].cells[4].className = "maxCharachterCount";
								}
							}
								if (!tempZone.includes(row[j].cells[6].innerHTML)) {
									if (row[j].cells[6].innerHTML) {
									document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[j].cells[6].className = "maxCharachterCount";
									}
								}
								if (!tempCvc.includes(row[j].cells[8].innerHTML)) {
									if (row[j].cells[8].innerHTML) {
									document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[j].cells[8].className = "maxCharachterCount";
									}
								}
							}
						}
					}

				}
				// close


				var row = document.getElementsByClassName('jexcel jexcel_overflow')[0].rows;
				row.lengt
				for (var i = 1; i < row.length; i++) {

					// if (row[i].cells[11].innerHTML && !isDataPopulatingFromUploadFile && !cellValueChange) {
					// 	// console.log('row[i].cells[11]', row[i].cells[11].innerHTML);
					// 	var checkLengthofCalValue = [];
					// 	checkLengthofCalValue = row[i].cells[11].innerHTML.split(' ');

					// 	if (e911CharachterCount && !row[i].cells[2].innerHTML) {
					// 		document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[11].className = "maxCharachterCount";

					// 	}


						// if (!row[i].cells[4].innerHTML && (checkLengthofCalValue.length >= 3)) {
						// 	document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[4].innerHTML = checkLengthofCalValue[2];
						// 	document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[11].className = "maxCharachterCount";
						// 	document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[4].className = "maxCharachterCount";	
						// }
						// if (!row[i].cells[6].innerHTML && (checkLengthofCalValue.length >= 5)) {
						// 	document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[6].innerHTML = checkLengthofCalValue[4];
						// 	document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[11].className = "maxCharachterCount";
						// 	document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[6].className = "maxCharachterCount";	
						// }
						// if (!row[i].cells[8].innerHTML && (checkLengthofCalValue.length >= 7)) {
						// 	document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[8].innerHTML = checkLengthofCalValue[6];
						// 	document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[11].className = "maxCharachterCount";
						// 	document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[8].className = "maxCharachterCount";	
						// }
					// }
					
                 if((Object.keys(featureToggleMap).includes("F93108") && featureToggleMap['F93108'])) {
					if(row[i].cells[2].innerHTML) {
						if(row[i].cells[3].innerHTML==null || row[i].cells[3].innerHTML=='' || typeof row[i].cells[3].innerHTML == 'undefined'  ) {
							$(row[i].cells[13].children[0]).attr('disabled', true);
							$(row[i].cells[3]).kendoTooltip({
                             autoHide: true,
                             showOn: "mouseover",
                             content: function(){
                               let content = "<div id='helperTooltip'>" + "This field is mandatory"+ "</div>";
                               return content;
                             },
                             width: "150px" 
							});
                       }
                    }
                    if(row[i].cells[3].innerHTML) {
						if(row[i].cells[2].innerHTML==null || row[i].cells[2].innerHTML=='' || typeof row[i].cells[2].innerHTML == 'undefined'  ) {
							$(row[i].cells[13].children[0]).attr('disabled', true);
							row[i].cells[2].style.border = "1px solid red";
							$(row[i].cells[2]).kendoTooltip({
                             autoHide: true,
                             showOn: "mouseover",
                             content: function(){
                               let content = "<div id='helperTooltip'>" + "This field is mandatory"+ "</div>";
                               return content;
                             },
                             width: "150px" 
							});
                       }
                    }
					let tempDL=[];
					for(var j = 0; j< DL1.length; j++)
					{
						tempDL.push(DL1[j].name);
					}
					for(var j = 0; j< DL2.length; j++)
					{
						tempDL.push(DL2[j].name);
					}
					for(var j = 0; j< Zone.length; j++)
					{
						tempDL.push(Zone[j].name);
					}
					for(var j = 0; j< CVC.length; j++)
					{
						tempDL.push(CVC[j].name);
					}
					if(row[i].cells[3].innerHTML) {
						let DSCP1 = row[i].cells[3].innerHTML;
						for (var j = 0; j< tempDL.length; j++) {
							if(DSCP1===tempDL[j]){
								row[i].cells[3].classList.add("matching-descr-error");
								$(row[i].cells[13].children[0]).attr('disabled', true);
							}
						}
					}
					if(row[i].cells[5].innerHTML) {
						let DSCP2 = row[i].cells[5].innerHTML;
						for (var j = 0; j< tempDL.length; j++) {
							if(DSCP2===tempDL[j]){
								row[i].cells[5].classList.add("matching-descr-error");
								$(row[i].cells[13].children[0]).attr('disabled', true);
							}
						}
					}
					if(row[i].cells[7].innerHTML) {
						let DSCP3 = row[i].cells[7].innerHTML;
						for (var j = 0; j< tempDL.length; j++) {
							if(DSCP3===tempDL[j]){
								row[i].cells[7].classList.add("matching-descr-error");
								$(row[i].cells[13].children[0]).attr('disabled', true);
							}
						}
					}
					if(row[i].cells[9].innerHTML) {
						let DSCP4 = row[i].cells[9].innerHTML;
						for (var j = 0; j< tempDL.length; j++) {
							if(DSCP4===tempDL[j]){
								row[i].cells[9].classList.add("matching-descr-error");
								$(row[i].cells[13].children[0]).attr('disabled', true);
							}
						}
					}					
				}

					if (row[i].cells[11].innerHTML && isDataPopulatingFromUploadFile) {
						var checkLengthofCalValue = [];
						checkLengthofCalValue = row[i].cells[11].innerHTML.split(' ');

						if (!row[i].cells[2].innerHTML && checkLengthofCalValue.length >= 1) {
							if (checkLengthofCalValue[1]) {
								document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[2].innerHTML = checkLengthofCalValue[0];
								document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[2].className = "maxCharachterCount";
							}
							document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[11].className = "maxCharachterCount";
						}
						if (!row[i].cells[4].innerHTML && (checkLengthofCalValue.length >= 3)) {
							document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[4].innerHTML = checkLengthofCalValue[2];
							document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[11].className = "maxCharachterCount";
							document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[4].className = "maxCharachterCount";
							// var tempCheckDL2 = document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[4].innerHTML;
							// if (!DL2.includes(tempCheckDL2)) {
							// 	document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[13].innerHTML = false;
							// }
						}
						if (!row[i].cells[6].innerHTML && (checkLengthofCalValue.length >= 5)) {
							document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[6].innerHTML = checkLengthofCalValue[4];
							document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[11].className = "maxCharachterCount";
							document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[6].className = "maxCharachterCount";
						}
						if (!row[i].cells[8].innerHTML && (checkLengthofCalValue.length >= 7)) {
							document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[8].innerHTML = checkLengthofCalValue[6];
							document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[11].className = "maxCharachterCount";
							document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[8].className = "maxCharachterCount";
						}
					}

					for (var j = 0; j < row[i].cells.length; j++) {
						if (isFile) {
							isDataPopulatingFromUploadFile = true;
							transmittergridinfoChange(instance, row[i].cells[j], j, i, row[i].cells[j].innerHTML);
							if (j == 2) {
								checkDL1Validations(row[i].cells[j], i);
								if (row[i].cells[j].innerHTML && (e911CharachterCount <= 20)) {
									row[i].cells[13] = true;
								}
							}
							// fileValid(instance);
						}
						if (j == 3) {

							row[i].cells[j].id = i + '_r_' + j;
							row[i].cells[j].addEventListener('keypress', function (event) {
								var code = (event.which) ? event.which : event.keyCode;
								var test = document.getElementById(event.currentTarget.id);
								var test2 = test.getElementsByTagName('input');

								if ((code < 65 || code > 122) && (code < 48 || code > 57) || test2[0].value.length > 17) {
									event.preventDefault();
								} else if (code == 91 || code == 93 || code == 94) {
									event.preventDefault();
								}

							})
						} else if (j == 5) {
							row[i].cells[j].id = i + '_r9_' + j;
							row[i].cells[j].addEventListener('keypress', function (event) {
								var code = (event.which) ? event.which : event.keyCode;
								var test = document.getElementById(event.currentTarget.id);
								var test2 = test.getElementsByTagName('input');

								if ((code < 65 || code > 122) && (code < 48 || code > 57) || test2[0].value.length > 17) {
									event.preventDefault();
								} else if (code == 91 || code == 93 || code == 94) {
									event.preventDefault();
								}

							})
						} else if (j == 7) {

							row[i].cells[j].id = i + '_r9_' + j;
							row[i].cells[j].addEventListener('keypress', function (event) {
								var code = (event.which) ? event.which : event.keyCode;
								var test = document.getElementById(event.currentTarget.id);
								var test2 = test.getElementsByTagName('input');

								if ((code < 65 || code > 122) && (code < 48 || code > 57) || test2[0].value.length > 17) {
									event.preventDefault();
								} else if (code == 91 || code == 93 || code == 94) {
									event.preventDefault();
								}

							})
						} else if (j == 9) {

							row[i].cells[j].id = i + '_r9_' + j;
							row[i].cells[j].addEventListener('keypress', function (event) {
								var code = (event.which) ? event.which : event.keyCode;
								var test = document.getElementById(event.currentTarget.id);
								var test2 = test.getElementsByTagName('input');

								if ((code < 65 || code > 122) && (code < 48 || code > 57) || test2[0].value.length > 17) {
									event.preventDefault();
								} else if (code == 91 || code == 93 || code == 94) {
									event.preventDefault();
								}

							})
						} else if (j == 11) {

							row[i].cells[j].id = i + '_r9_' + j;
							row[i].cells[j].addEventListener('keypress', function (event) {
								var code = (event.which) ? event.which : event.keyCode;
								var test = document.getElementById(event.currentTarget.id);
								var test2 = test.getElementsByTagName('input');
								event.preventDefault();

							})
						} else if (j == 12) {

							row[i].cells[j].id = i + '_r9_' + j;
							if (row[i].cells[j].innerHTML > 20) {
								document.getElementById(row[i].cells[j].id).classList.add('maxCharachterCount');
							}
							row[i].cells[j].addEventListener('keypress', function (event) {
								var code = (event.which) ? event.which : event.keyCode;
								var test = document.getElementById(event.currentTarget.id);
								var test2 = test.getElementsByTagName('input');
								event.preventDefault();

							})
						} else if (j == 13) {

							row[i].cells[j].id = i + '_r9_' + j;
							if (row[i].cells[j].innerHTML > 20) {
								document.getElementById(row[i].cells[j].id).classList.add('maxCharachterCount');
							}
							row[i].cells[j].addEventListener('keypress', function (event) {
								var code = (event.which) ? event.which : event.keyCode;
								var test = document.getElementById(event.currentTarget.id);
								var test2 = test.getElementsByTagName('input');
								event.preventDefault();

							})
						}


					}
				}
				transmittergridinfoOnload(instance);
			},

		});
	}

}

function checkDL1Validations(dl1Cell, index) {
	if (dl1Cell.innerHTML) {
		validateDropdownValue(dl1Cell.innerHTML, 'dl1');
		var DL1ValueCheck = validateDropdownValue(dl1Cell.innerHTML, 'dl1');
		if (!DL1ValueCheck) {
			dl1Cell.className = "maxCharachterCount";
		}
	}
}

function fileValid(instance) {
	for (var i = 0; i < e911DispatchableData.length; i++) {
		let isdl1Validated = false;
		let isdl2Validated = false;
		let isZoneValidated = false;
		let iscvcValidated = false;
		let isCharCountValidated = false;
		let isUpdateAtollValidated = false;
		let rData = e911DispatchableData[i];
		if (validateDropdownValue(rData.dl1, 'dl1')) {
			isdl1Validated = true;
		}
		if (rData.charcount != null && rData.charcount != "" && rData.charcount <= 20) {
			isCharCountValidated = true;
		}

		isUpdateAtollValidated = isdl1Validated && isCharCountValidated;

		if (!isdl1Validated) document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[2].className = "maxCharachterCount";
		if (!isCharCountValidated) document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[12].className = "maxCharachterCount";

		if (!isUpdateAtollValidated) document.getElementsByClassName('jexcel jexcel_overflow')[0].rows[i].cells[11].className = "maxCharachterCount";
	}

}

var cellKeyMap = new Map();
cellKeyMap.set("1", "dl1");
cellKeyMap.set("2", "descp1");
cellKeyMap.set("3", "dl2");
cellKeyMap.set("4", "descp2");
cellKeyMap.set("5", "zone");
cellKeyMap.set("6", "descp3");
cellKeyMap.set("7", "cvc");
cellKeyMap.set("8", "descp4");
cellKeyMap.set("10", "calcDespLoc");
cellKeyMap.set("11", "charcount");
cellKeyMap.set("12", "updateAtoll");

// e911 dispatchable table validations 

function transmittergridinfoChange(instance, cell, c, r, value) {
	rowNumber = r;
	getRowsData = document.getElementById('virtualAssignmentGridInfo').jexcel.getRowData(r);
	let txId = getRowsData[0];
	let cellKey = "";
	if (cellKeyMap.has(c))
		cellKey = cellKeyMap.get(c);
	let cellValue = getRowsData[c];

	updateE911Dispatchabledata(txId, cell, cellKey, cellValue, e911DispatchableData);

}
var cellValueChange;
var changesInTransmitterIdRow;
var updatedE911DispatchableDataNew = [];
var scrollYPosition;

function updateE911Dispatchabledata(txId, cell, cellKey, cellValue, updatedE911DispatchableData) {

	$.each(updatedE911DispatchableData, function (key, value) {

		if (updatedE911DispatchableData[key] != null && updatedE911DispatchableData[key].hasOwnProperty("transmitter")) {
			if (updatedE911DispatchableData[key].transmitter == txId) {
				if (updatedE911DispatchableData[key].hasOwnProperty(cellKey)) {
					switch (cellKey) {
						case 'dl1':
							updatedE911DispatchableData[key].dl1 = cellValue;
							updatedE911DispatchableData[key].updateAtoll = true;
							break;
						case 'descp1':
							updatedE911DispatchableData[key].descp1 = cellValue;
							break;
						case 'dl2':
							updatedE911DispatchableData[key].dl2 = cellValue;
							break;
						case 'descp2':
							updatedE911DispatchableData[key].descp2 = cellValue;
							break;
						case 'zone':
							updatedE911DispatchableData[key].zone = cellValue;
							break;
						case 'descp3':
							updatedE911DispatchableData[key].descp3 = cellValue;
							break;
						case 'cvc':
							updatedE911DispatchableData[key].cvc = cellValue;
							break;
						case 'descp4':
							updatedE911DispatchableData[key].descp4 = cellValue;
							break;
						case 'updateAtoll':
							if (updatedE911DispatchableData[key].dl1) {
								updatedE911DispatchableData[key].updateAtoll = cellValue;
							} else {
								updatedE911DispatchableData[key].updateAtoll = false;
							}
							break;
						default:
							break;
					}
				}

				let updatedDl1 = updatedE911DispatchableData[key].dl1;
				let updateddescp1 = updatedE911DispatchableData[key].descp1;
				let updatedDl2 = updatedE911DispatchableData[key].dl2;
				let updateddescp2 = updatedE911DispatchableData[key].descp2;
				let updatedZone = updatedE911DispatchableData[key].zone;
				let updateddescp3 = updatedE911DispatchableData[key].descp3;
				let updatedCvc = updatedE911DispatchableData[key].cvc;
				var updateddescp4 = updatedE911DispatchableData[key].descp4;

				updatedDl1 = updatedDl1 ? updatedDl1 + ' ' : '';
				updateddescp1 = updatedDl1 && updateddescp1 ? updateddescp1 + ' ' : '';
				updatedDl2 = updatedDl2 ? updatedDl2 + ' ' : '';
				updateddescp2 = updatedDl2 && updateddescp2 ? updateddescp2 + ' ' : '';
				updatedZone = updatedZone ? updatedZone + ' ' : '';
				updateddescp3 = updatedZone && updateddescp3 ? updateddescp3 + ' ' : '';
				updatedCvc = updatedCvc ? updatedCvc + ' ' : '';
				updateddescp4 = updatedCvc && updateddescp4 ? updateddescp4 + ' ' : '';


				var calculated911Location = updatedDl1.concat(updateddescp1, updatedDl2, updateddescp2, updatedZone, updateddescp3, updatedCvc, updateddescp4);
				var calculated911LocationTemp = calculated911Location.trim();
				updatedE911DispatchableData[key].calcDespLoc = calculated911LocationTemp.toUpperCase();
				checkCharachterValue = updatedE911DispatchableData[key].calcDespLoc;
				// checkCharachterValue = checkCharachterValue.replace(/  +/g, ' ');
				updatedE911DispatchableData[key].charcount = calculated911LocationTemp.toUpperCase().length;

				if (updatedE911DispatchableData[key].charcount > 20) {
					updatedE911DispatchableData[key].updateAtoll = false;
				} else if (updatedE911DispatchableData[key].dl1) {
					updatedE911DispatchableData[key].updateAtoll = true;
				}
				if (cellKey == 'updateAtoll') {
					if (!updatedE911DispatchableData[key].dl1) {
						updatedE911DispatchableData[key].updateAtoll = false;
					} else {
						updatedE911DispatchableData[key].updateAtoll = cellValue;
					}
				}
				if (cellValueChange) {
					updatedE911DispatchableDataNew = updatedE911DispatchableData;
					changesInTransmitterIdRow = txId;
					updatedCellValues = [updatedDl1, updateddescp1, updatedDl2, updateddescp2, updatedZone, updateddescp3, updatedCvc, updateddescp4];
					var tempTest = updatedCellValues.toString();
					updatedE911DispatchableData.length;
					for (i = 0; i < updatedE911DispatchableData.length; i++) {
						if (updatedE911DispatchableData[i].transmitter) {
							if (updatedE911DispatchableData[i].transmitter == txId) {
								//updatedE911DispatchableDataNew[i].dl2 = updatedCellValues[2];
								updatedE911DispatchableDataNew[i].calcDespLoc = tempTest;
								tempCalCount= updatedE911DispatchableData[key].calcDespLoc.replace(/,/g, "");
								tempCalCount = tempCalCount.replace(/\s+/g, ' ').trim();
								if (tempCalCount.length <= 20) {
									updatedE911DispatchableData[key].updateAtoll = true;
								} else {
									updatedE911DispatchableData[key].updateAtoll = false;
								}

								if (!updatedE911DispatchableDataNew[i].dl1) {
									updatedE911DispatchableData[key].updateAtoll = false;
								}
							}
						}
					}
				}
				if (updatedDl1) {
					tempDL = [];
					tempDL2 = [];
					tempZone = [];
					tempCvc = [];
					// updatedE911DispatchableData[key].updateAtoll = true;

					for (var i = 0; i < DL1.length; i++) {
						if (DL1[i].name) {
						tempDL.push(DL1[i].id);
						}
					}
					for (var i = 0; i < DL2.length; i++) {
						tempDL2.push(DL2[i].id);
					}

					for (var i = 0; i < Zone.length; i++) {
						tempZone.push(Zone[i].id);

					}

					for (var i = 0; i < CVC.length; i++) {
						tempCvc.push(CVC[i].id);

					}

					// DL1 checking 
					if (!tempDL.includes(updatedDl1.trim()) && updatedDl1.trim()) {
						updatedE911DispatchableData[key].dl1 = updatedDl1.trim();
						updatedE911DispatchableData[key].updateAtoll = false;
					} else if (updatedE911DispatchableData[key].charcount <= 20) {
						updatedE911DispatchableData[key].updateAtoll = true;
					} else if (tempCalCount.length <= 20) {
						updatedE911DispatchableData[key].updateAtoll = true;
					} else {
						updatedE911DispatchableData[key].updateAtoll = false;
					}

					if (cellKey == 'updateAtoll') {
						if (!updatedE911DispatchableData[key].dl1) {
							updatedE911DispatchableData[key].updateAtoll = false;
						} else {
							updatedE911DispatchableData[key].updateAtoll = cellValue;
						}
						if (!tempDL.includes(updatedDl1.trim()) && updatedDl1.trim()) {
							updatedE911DispatchableData[key].updateAtoll = false;
						}
						if (updatedE911DispatchableData[key].calcDespLoc.includes(',')) {
							var afterChangeCharCount = updatedE911DispatchableData[key].calcDespLoc.replaceAll(',','').trim();
							if (afterChangeCharCount.length > 20) {
								updatedE911DispatchableData[key].updateAtoll = false;
							}
						}
					}

					// DL2 checking 
					if (!tempDL2.includes(updatedDl2.trim()) && updatedDl2.trim()) {
						updatedE911DispatchableData[key].updateAtoll = false;
					}

					// Zone checking 
					if (!tempZone.includes(updatedZone.trim()) && updatedZone.trim()) {
						updatedE911DispatchableData[key].updateAtoll = false;
					}

					// Cvc checking 
					if (!tempCvc.includes(updatedCvc.trim()) && updatedCvc.trim()) {
						updatedE911DispatchableData[key].updateAtoll = false;
					}

				}

				e911CharachterCount = updatedE911DispatchableData[key].charcount;
			}
		}
	});

	e911DispatchableData = updatedE911DispatchableData;

	scrollYPosition = window.scrollY;

	if (spreadsheetTransmitterObj) {
		spreadsheetTransmitterObj.destroy();
	}
	creatingJSpreadsheeteAssignment(e911DynamicAssignmentcolumns, spreadsheetAssignmet, e911DispatchableData, false);
	
	window.scrollTo(0, scrollYPosition);
	$(".jexcel_content").scrollTop(containerScroll);

}

function transmittergridinfoOnload(instance) {
	// console.log(instance);
}

function currentVersionChange(event) {
	cleare911DataTable();
	loadDropDownList();
	var selectElement = event.target;
	selectedSiteVersion = selectElement.value;
	if (selectedSiteVersion != 'None Selected') {
		if (spreadsheetTransmitterObj) {
			spreadsheetTransmitterObj.destroy();
		}
		let tr = $(currentRowSelected.target).closest("tr");
		var selectedItem = $("#marketGrid").data("kendoGrid").dataItem(tr);
		if (selectedItem.fuzeSiteId && selectedItem.fuzeSiteId != "") {
			// version: value; version param for payload
			let payload = {
				// projectNumber : $("#projectNumberSelect").val(),
				siteVersion: selectedSiteVersion,
				fuzeSiteId: selectedItem.fuzeSiteId
			};

			getProjectGridDetail(payload, -1);

			changeDownloadTemplateButtonStatus(true);

		} else {
			showMessageBanner('error', 'Site Name not available');
		}
	} else {
		cleare911DataTable();
		if (spreadsheetTransmitterObj) {
			spreadsheetTransmitterObj.destroy();
		}
		e911DispatchableData = [];
		$("#downloadTemplate").attr('disabled', 'disabled');
		$('#uploadTemplate').attr('disabled', 'disabled');
	}
}


// updateAtoll method for e911 location table update
function updateE911LocationTable() {
	var e911updateAtollPayload = [];
	let tr = $(currentRowSelected.target).closest("tr");
	let selectedItem = $("#marketGrid").data("kendoGrid").dataItem(tr);

	$.each(e911DispatchableData, function (index, value) {
		value.fuzeSiteId = selectedItem.fuzeSiteId;
		if (value.updateAtoll) {
			// comma removing 
			value.calcDespLoc = value.calcDespLoc.replace(/,/g, "");
			value.calcDespLoc = value.calcDespLoc.replace(/\s+/g, ' ').trim();
			value.dl1 = value.dl1.replace(/\s+/g, ' ').trim();
			value.dl2 = value.dl2.replace(/\s+/g, ' ').trim();
			value.zone = value.zone? value.dl2.replace(/\s+/g, ' ').trim(): '';
			value.cvc = value.cvc? value.cvc.replace(/\s+/g, ' ').trim(): '';
		}
		if (value.updateAtoll) {
			e911updateAtollPayload.push(value);
		}
	});

	if (e911updateAtollPayload.length > 0) {
		$.ajax({
			async: false,
			// url: "http://localhost:8100/npp-atoll-services/e911DispLocation/updateToAtoll",
			url: updateToAtollUrl,
			type: "POST",
			data: JSON.stringify(e911updateAtollPayload),
			contentType: 'application/json; charset=UTF-8',
			cache: false,
			success: function (data) {
				siteVersionDataProvider = data;
				aptAlert('Success', 'Data updated Successfully');
				cleare911DataTable();
				let payload = {
					siteVersion: selectedSiteVersion,
					fuzeSiteId: selectedItem.fuzeSiteId
				};
				getProjectGridDetail(payload, -1);
			},
			error: function (data) {
				aptAlert('Warning', 'Failed to update data');
			}
		});
	} else {
		aptAlert('Warning', 'Data not correct');
	}

}


function changeDownloadTemplateButtonStatus(flag) {
	if (flag)
		$("#downloadTemplate").removeAttr('disabled');
	else
		$("#downloadTemplate").attr('disabled', 'disabled');
}

function downloadTemplate() {

	convertAndDownloadToCSV(convertSpreadsheetDataToJSON());

}
function convertSpreadsheetDataToJSON() {
	//reading data from jSpreadsheet 
	let spreadsheetData = document.getElementById('virtualAssignmentGridInfo').jexcel.getData();
	let jsonRow = [];
	for (let i = 0; i < spreadsheetData.length; i++) {
		let rowData = spreadsheetData[i];
		if (rowData != null && rowData[0] != '') {
			let jsonData = {};
			jsonData.Transmitter = rowData[0];
			jsonData.DispatchableLocation = rowData[9];

			jsonRow.push(jsonData);
		}
	}

	return jsonRow;
}
function convertAndDownloadToCSV(jsonRow) {
	const repText = (key, value) => value === null ? '' : value // specify how you want to handle null values here
	const header = Object.keys(jsonRow[0])
	let csvData = jsonRow.map(row => header.map(fieldName =>
		JSON.stringify(row[fieldName], repText)).join(','))
	csvData.unshift(header.join(','))
	csvData = csvData.join('\r\n')

	// Create link and download
	var filename = 'E911DispatchableLocation.csv';
	var tempDownloadLink = document.createElement('a');
	tempDownloadLink.setAttribute('href', 'data:text/csv;charset=utf-8,%EF%BB%BF' + encodeURIComponent(csvData));
	tempDownloadLink.setAttribute('download', filename);
	tempDownloadLink.style.visibility = 'hidden';
	document.body.appendChild(tempDownloadLink);
	tempDownloadLink.click();
	document.body.removeChild(tempDownloadLink);
}



$('#uploadTemplate').attr('disabled', 'disabled');

document.getElementById('fileUpload').onchange = function () {
	if (this.value) {
		$("#uploadTemplate").removeAttr('disabled');
	} else {
		$('#uploadTemplate').attr('disabled', 'disabled');
	}
}


function uploadTemplate() {
	cleare911DataTable();
	isDataPopulatingFromUploadFile = true;
	if (!selectedSiteVersion) {
		aptAlert('Warning', 'Please select current version');
		spreadsheetTransmitterObj.destroy();
	}
	$('#loading').show();
	if (csvDataMap) csvDataMap.clear();
	if (spreadsheetTransmitterObj) {
		spreadsheetTransmitterObj.destroy();
	}

	let fileDataJson = {};
	Papa.parse(document.getElementById('fileUpload').files[0], {
		download: true,
		header: true,
		skipEmptyLines: true,
		complete: function (results) {
			fileDataJson = results.data;
			$("#uploadTemplate").removeAttr('disabled');
			$('#fileUpload').empty();

			createMapForCsvData(fileDataJson);

			if (csvDataMap != null && e911DispatchableData != null) {
				compareUiWithCSV()
			}
			$('#loading').hide();
			$('#fileUpload').empty();
			fileUpload
		}
	});


}
var csvDataMap = new Map();
function createMapForCsvData(data) {
	for (let i = 0; i < data.length; i++) {
		if (data[i] != null && data[i].hasOwnProperty('Transmitter') && data[i].hasOwnProperty('DispatchableLocation')) {
			csvDataMap.set(data[i].Transmitter, data[i].DispatchableLocation);
		}
	}
}

function compareUiWithCSV() {

	for (var i = 0; i < e911DispatchableData.length; i++) {
		//checking if TXID matches
		if (csvDataMap.has(e911DispatchableData[i].transmitter)) {
			let csvDispatchableLoc = csvDataMap.get(e911DispatchableData[i].transmitter);
			if (csvDispatchableLoc != e911DispatchableData[i].exisDespLoc) {
				const splitText = csvDispatchableLoc.split(' ');
				let splitTextLength = splitText.length;
				resetDropdownValuesInJSON(e911DispatchableData[i], false);
				populateCSVToUi(splitText, i + 1, csvDispatchableLoc, e911DispatchableData);
			}
			else {

				//resetDropdownValuesInJSON(e911DispatchableData[i],true);
			}
		}
	}

	if (spreadsheetTransmitterObj) {
		spreadsheetTransmitterObj.destroy();
	}
	$('#loading').hide();

	creatingJSpreadsheeteAssignment(e911DynamicAssignmentcolumns, spreadsheetAssignmet, e911DispatchableData, true);

}
// []['BIANCA', '3']
function resetDropdownValuesInJSON(data, flag) {

	if (flag) {
		data.calcDespLoc = "";
		data.charcount = "";
	}
	else {
		data.dl1 = "";
		data.dl2 = "";
		data.cvc = "";
		data.zone = "";
		data.descp1 = "";
		data.descp2 = "";
		data.descp3 = "";
		data.descp4 = "";
	}




}
function populateCSVToUi(dataArray, index, locationText, e911DispatchableData) {
	for (var i = 0; i < dataArray.length; i++) {
		// in dropdwon + column - (calc e911)
		//setText( index, dataArray[i])
		// data[i] -> should be available in dropdown source 
		// if true ->  set it else -> highlight it and move fwd (i+1) 


		if (i == 0) {
			//set

			e911DispatchableData[index - 1].dl1 = dataArray[i];
			if (!validateDropdownValue(dataArray[i], 'DL1')) {
				//

			}

		}
		else if (i == 1) {
			//set

			e911DispatchableData[index - 1].descp1 = dataArray[i];
		}
		else if (i == 2) {

			e911DispatchableData[index - 1].dl2 = dataArray[i];
			if (!validateDropdownValue(dataArray[i], 'DL2')) {

			}

		}
		else if (i == 3) {
			//set

			e911DispatchableData[index - 1].descp2 = dataArray[i];
		}
		else if (i == 4) {

			e911DispatchableData[index - 1].zone = dataArray[i];
			if (!validateDropdownValue(dataArray[i], 'Zone')) {

			}

		}
		else if (i == 5) {
			//set

			e911DispatchableData[index - 1].descp3 = dataArray[i];
		}
		else if (i == 6) {

			e911DispatchableData[index - 1].cvc = dataArray[i];
			if (!validateDropdownValue(dataArray[i], 'CVC')) {

			}

		}
		else if (i == 7) {
			e911DispatchableData[index - 1].descp4 = dataArray[i];
			//set
		}
		//setting calc e911 

		e911DispatchableData[index - 1].calcDespLoc = locationText;
		e911DispatchableData[index - 1].charcount = locationText.length;
		e911DispatchableData[index - 1].updateAtoll = false;



	}
}

function validateDropdownValue(val, type) {
	if (type == 'DL1')
		return (DL1.includes(val))

	if (type == 'DL2')
		return (DL2.includes(val))


	if (type == 'CVC')
		return (CVC.includes(val))


	if (type == 'Zone')
		return (Zone.includes(val))

}
function loadDropDownList() {
	$.ajax({
		// url: "http://localhost:8100/npp-atoll-services/e911DispLocation/fetchDropDownsData",
		url: fetchDropDownsDataUrl,
		dataType: 'json',
		type: "POST",
		async: false,
		success: function (data) {
			e911DropdownData = data;
			DL1 = e911DropdownData.DL1;
			DL2 = e911DropdownData.DL2
			Zone = e911DropdownData.Zone;
			CVC = e911DropdownData.CVC;
			e911DynamicAssignmentcolumns[1].source = e911DropdownData.DL1;
			e911DynamicAssignmentcolumns[3].source = e911DropdownData.DL2;
			e911DynamicAssignmentcolumns[5].source = e911DropdownData.Zone;
			e911DynamicAssignmentcolumns[7].source = e911DropdownData.CVC;
		},
		error: function (data) {
			aptAlert('Warning', 'Failed to load DL1 data!');
		}
	});
}

function cleare911DataTable() {
	$.each(e911DispatchableData, function (index, value) {
		value.dl1 = '';
		value.descp1 = '';
		value.dl2 = '';
		value.descp2 = '';
		value.cvc = '';
		value.descp3 ='';
		value.zone = '';
		value.descp4 = '';
		value.calcDespLoc = '';
		value.charcount = '';
		value.updateAtoll = false;
	});
}
