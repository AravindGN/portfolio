var atollSchema = ["albuquerque","atlanta","austin","bismarck","bocaraton","boise","carolinas","centralillinois","chicago","cincinnati","cleveland","dallas","denver","desmoines","detroit","dublin","eugene","fargo","hawaii","houston","indianapolis","jacksonville","kansas","lasvegas","losangeles","louisville","milwaukee","minneapolis","montana","nashville","newenglandeast","newenglandwest","newjersey","neworleans","nymetro","nyupstate","orlando","philadelphia","phoenix","pittsburgh","portland","rockford","sacramento","saltlake","sandiego","sanfrancisco","sdakota","seattle","southcentral","spokane","stlouis","tampa","virginia","washington"];
var t, leaf;
// var splitClusters =null;
// var disableZoom = 20;
var attribution = "<span id='attributionSpan'>Cursor out of map bounds</span>";
var tileOptions = { maxZoom: 19, minZoom: 2, opacity: .2, attribution: attribution, stamp: Date.now };
// var clusterOptions = { maxRad: 1900, disableZoom: disableZoom, splitClusters: splitClusters };
var current_url = grayscale_url;
var googleRoadMutant;
var googleTerrainMutant;
var initialFlag = true;
var gridHeight;
var siteIdList = {};  
var transmitterNodeList = {};
var verisonTxMap = {};
var individualNodes = {};
var txcoverageKml = {};
var checkTxStatusIntervalNew;
var checkTxStatusIntervalExisting;
var transmitterIdBandMap = {};
var compareData = {};
var checkApiCountNew = 0;
var checkApiCountExisting = 0;
var existingAjaxFlag = false;
var newAjaxFlag = false;
var currentViewModel = "map-and-grid";
var preUid;
var preTxUid;
var markerClusters=null;
var oldzoom = 4;
var multiplier = 1.0;
var totalResponseSecondsNew;
var totalResponseSecondsExisting;
var $vpiAjax;
var svg_site_color = {
    svg_site_without_fuze_site_id: "#fa4632",
    svg_site_with_fuze_site_id: "#4ec8fc"
};
var txData = {};
//defines shapes for various mpt site types
var site_fuze_site_id_status = {
    "without-fuze-site-id": "#fa4632",
    "with-fuze-site-id": "#4ec8fc"
};
var stype_map = {
    "OTHER": {
        name: "pentagon",
        shape: '<polygon points="2,7 7,2 12,7 9,12 5,12" stroke-width="1" stroke="#000" stroke-opacity="1" fill="{fill}" fill-opacity="1" />'
    },
    "MACRO": {
        name: "circle",
        shape: '<circle cx="7" cy="7" r="5" stroke-width="1" stroke="#000" stroke-opacity="1" fill="{fill}" fill-opacity="1"/>'
    },
    "SMALL-CELL": {
        name: "diamond",
        shape: '<polygon points="1,7 7,1 13,7 7,13" stroke-width="1" stroke="#000" stroke-opacity="1" fill="{fill}" fill-opacity="1" />'
    },
    "SC/ODAS": {
        name: "hexagon",
        shape: '<polygon points="3,5 7,2 11,5 11,9 7,12 3,9" stroke-width="1" stroke="#000" stroke-opacity="1" fill="{fill}" fill-opacity="1" />'
    },
    "INBLD": {
        name: "rectangle",
        shape: '<rect x="3" y="3" width="10" height="10" stroke-width="1" stroke="#000" stroke-opacity="1" fill="{fill}" fill-opacity="1"/>'
    }
};

//maps icon colors to solution years
var yarr = ["Current","New"];
var solyear_map = {};
solyear_map[yarr[0]] = "#bf00ff";
solyear_map[yarr[1]] = "#bff51d";

// icon changes on select
var wo_split = CONTEXT_PATH+'/uui/espresso/static/planning_pg/css/images/layout_icons/split-icon-rotated-small.png';
var wo_map = CONTEXT_PATH+'/uui/espresso/static/planning_pg/css/images/layout_icons/map-icon-small.png';
var wo_tab = CONTEXT_PATH+'/uui/espresso/static/planning_pg/css/images/layout_icons/tabular-icon-small.png';
var bestviewrent = CONTEXT_PATH+'/uui/espresso/static/planning_pg/css/images/bestviewrent.png';

var split = CONTEXT_PATH+'/uui/espresso/static/planning_pg/css/images/layout_icons/split-icon-rotated-small-color.png';
var map = CONTEXT_PATH+'/uui/espresso/static/planning_pg/css/images/layout_icons/map-icon-small-color.png';
var tab = CONTEXT_PATH+'/uui/espresso/static/planning_pg/css/images/layout_icons/tabular-icon-small-color.png';

$(document).ready(function(e){
    roles.push("BETA_USER"); 
    $('#legendbar').hide();
    gridHeight = $(window).height();
    gridHeight = gridHeight * 0.43;
    UiSettingsRetrieve("ATOLL.CARRIER.Map.Schema", function (data) {
        var receivedSchema = data? data.schema : data;
        getUserSchema(receivedSchema);
    });

    L.CursorHandler = L.Handler.extend({

        addHooks: function () {
            this._popup = new L.Popup();
            this._map.on('mouseover', this._open, this);
            this._map.on('mousemove', this._update, this);
            this._map.on('mouseout', this._close, this);
        },
    
        removeHooks: function () {
            this._map.off('mouseover', this._open, this);
            this._map.off('mousemove', this._update, this);
            this._map.off('mouseout', this._close, this);
        },
        
        _open: function (e) {
            this._update(e);
        },
    
        _close: function (e) {
            $('#attributionSpan').text("Zoom Level: " + this._map.getZoom() + " Coordinates: " + parseFloat(e.latlng.lat).toFixed(5) + ", " + parseFloat(e.latlng.lng).toFixed(5));
        },
    
        _update: function (e) {
            $('#attributionSpan').text("Zoom Level: " + this._map.getZoom() + " Coordinates: " + parseFloat(e.latlng.lat).toFixed(5) + ", " + parseFloat(e.latlng.lng).toFixed(5));
        }
    
        
    });
    t = XYZ.map();
    L.Map.addInitHook('addHandler', 'cursor', L.CursorHandler);
    leaf = t.initialize("map", { "zoomPos": 'topright', "drawControl": false, "drawControlPos": 'topleft', "drawPolyline": { showLength: true, metric: false, feet: false, nauticalMile: false, showAzimuth: true }, "clusterPie": false, "cursor":true, "tileOptions": tileOptions, "stamp": "?_={stamp}", 'url': current_url, 'resourcePath': CONTEXT_PATH + '/uui/espresso/static', "legend": renderLegend(), "legendPos": "bottomleft" })._map;
    t.setMode(XYZ.MODE.STATIC);
    leaf.cursor.enable();

    googleRoadMutant = L.gridLayer.googleMutant({maxZoom: 24,type:'roadmap'});
    googleTerrainMutant  = L.gridLayer.googleMutant({maxZoom: 24,type:'terrain'});

    leaf.on('dragstart', function (e) {
        $("#vpisectorstyle").remove();
    });

    leaf.on('dragend', function (e) {
        $('<style id="vpisectorstyle">div.vpi-sector-icon {pointer-events: none !important;}</style>').appendTo("head");
    });

    leaf.on("zoomstart", function () {
        oldzoom = leaf.getZoom();
    });

    leaf.on("zoomend", function () {
        setTimeout(function () {

            // check zoom level
            // if(leaf.getZoom() < 14){
            //     // remove transimiter node
            //     for(var i in verisonTxMap){
            //         $.each(verisonTxMap[i], function(i, v){
            //             if(transmitterNodeList[v]){
            //                 t.removeNode(transmitterNodeList[v]);
            //                 delete transmitterNodeList[v];
            //             }
            //         });
            //     }
            //     verisonTxMap = {};
            //     $(".transmitter-check").attr("disabled", true);  
            //     $("#txLabel").attr('style', 'cursor: not-allowed !important');
            // }else{
            //     $(".transmitter-check").attr("disabled", false);
            //     $("#txLabel").attr('style', 'cursor: default !important');  
            // }
            $(".transmitter-check").attr("disabled", false);
            $("#txLabel").attr('style', 'cursor: default !important');  
            
            $.each(transmitterNodeList, function (i, node) {
                if(leaf.getZoom() <= 6){
                    multiplier = .6;
                }else if(leaf.getZoom() <= 10){
                    multiplier = .75;
                }else if(leaf.getZoom() <= 15){
                    multiplier = 1;
                }else{
                    multiplier = 1.25
                }
                node.marker.setIcon(new L.divIcon({
                    iconSize: [100 * multiplier, 100 * multiplier],
                    popupAnchor: [0, 0],
                    className: "transparent-background vpi-sector-icon",
                    html: node.marker._icon.innerHTML
                }));
            });
        }, 100);
    });

    L.Polyline.include({
        getDistance: function (system, evtLayerType) {
            // distance in meters
            if(evtLayerType=="polyline") {
                var mDistance = 0, 
                length = this._latlngs.length;
    
                for (var i = 1; i < length; i++) {
                    mDistance += this._latlngs[i].distanceTo(this._latlngs[i - 1]);
                }
            } else if(evtLayerType=="polygon") {
                var mDistance = 0, 
                length = this._latlngs[0].length;
                for (var i = 1; i < length; i++) {
                    mDistance += this._latlngs[0][i].distanceTo(this._latlngs[0][i - 1]);
                }
            }
            // optional
            if (system === 'imperial') {
                return mDistance / 1609.34;
            } else {
                return mDistance / 1000;
            }
        }
    });

    L.DivIcon.SVGIcon.include({
        initialize: function (options) {
            options = L.Util.setOptions(this, options)

            //iconSize needs to be converted to a Point object if it is not passed as one
            options.iconSize = L.point(options.iconSize)

            //in addition to setting option dependant defaults, Point-based options are converted to Point objects
            if (!options.circleAnchor) {
                options.circleAnchor = L.point(Number(options.iconSize.x) / 2, Number(options.iconSize.x) / 2)
            }
            else {
                options.circleAnchor = L.point(options.circleAnchor)
            }
            if (!options.circleColor) {
                options.circleColor = options.color
            }
            if (!options.circleFillOpacity) {
                options.circleFillOpacity = options.opacity
            }
            if (!options.circleOpacity) {
                options.circleOpacity = options.opacity
            }
            if (!options.circleWeight) {
                options.circleWeight = options.weight
            }
            if (!options.fillColor) {
                options.fillColor = options.color
            }
            if (!options.fontSize) {
                options.fontSize = Number(options.iconSize.x / 4)
            }
            if (!options.iconAnchor) {
                options.iconAnchor = L.point(Number(options.iconSize.x) / 2, Number(options.iconSize.y) / 2)
            }
            else {
                options.iconAnchor = L.point(options.iconAnchor)
            }
            if (!options.popupAnchor) {
                options.popupAnchor = L.point(0, 0)
            }
            else {
                options.popupAnchor = L.point(options.popupAnchor)
            }

            var path = this._createPath()
            var circle = this._createCircle()

            options.html = this._createSVG()
        },
        _createSVG: function () {
            var path = this._createPath();
            var circle = this._createCircle();
            var text = this._createText();
            var img = this._createImage();
            var className = this.options.className + "-svg";

            var style = "width:" + this.options.iconSize.x + "; height:" + this.options.iconSize.y + ";";

            var svg = '<svg xmlns="http://www.w3.org/2000/svg" version="1.1" class="' + className + '" style="' + style + '">' + path + circle + text + img + '</svg>';

            return svg;
        },
        _createPath: function () {
            var pathDescription = this._createPathDescription();
            var strokeWidth = this.options.weight
            var stroke = this.options.color
            var strokeOpacity = this.options.Opacity
            var fill = this.options.fillColor
            var fillOpacity = this.options.fillOpacity
            var className = this.options.className + "-path"
            var height = Number(this.options.iconSize.y)
            var width = Number(this.options.iconSize.x)
            var r = (width - strokeWidth - 8) / 2;
            var h = width - strokeWidth - 8;
            var hr = (width - 2) / 2;
            var hh = width - 2;
            var path = "";
            if (this.options.definedPath) {
                path = this.options.definedPath
                  .split("{stroke}").join(stroke)
                  .split("{fill}").join(fill);
            }
            else if (this.options.shape === "rectangle") {
                if (this.options.highlight) path += '<rect class="rect-highlight" x="' + ((width / 2) - hr) + '" y="' + ((height / 2) - hr) + '" width="' + hh + '" height="' + hh + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1"/>';
                path += '<rect class="' + className + '" x="' + ((width / 2) - r) + '" y="' + ((height / 2) - r) + '" width="' + h + '" height="' + h + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '"/>';
            }
            else if (this.options.shape === "rhombus") {
                if (this.options.highlight) path += '<rect class="rect-highlight" x="8.5" y="-8.5" width="' + (hh - 5) + '" height="' + (hh - 5) + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1" transform="rotate(45)"/>';
                path += '<rect class="' + className + '" x="' + (this.options.iconSize.x === 24 ? 11 : 9) + '" y="' + (this.options.iconSize.y === 24 ? -6 : -5) + '" width="' + (h - 2) + '" height="' + (h - 2) + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '" transform="rotate(45)"/>';
            }
            else if (this.options.shape === "inverted_triangle") {
                if (this.options.highlight) path += '<polygon points="' + '2,2 ' + (width - 2) + ',2 ' + (width/2) + ',' + (height - 2) + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1" />';
                path += '<polygon points="' + (this.options.iconSize.x === 24 ? 7 : 5) + ',' + (this.options.iconSize.y === 24 ? 7 : 5) + ' ' + (this.options.iconSize.x === 24 ? width - 6 : width - 5) + ',' + (this.options.iconSize.y === 24 ? 7 : 5) + ' ' + (width/2) + ',' + (height - 5) + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '" />';
            }
            else if (this.options.shape === "triangle") {
                if (this.options.highlight) path += '<polygon points="' + (width / 2) + ',2 ' + (width - 2) + ',' + (height - 2) + ' 2,' + (height - 2) + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1" />';
                path += '<polygon points="' + (width / 2) + ',' + (this.options.iconSize.y === 24 ? 7 : 5) + ' ' + (this.options.iconSize.y === 24 ? width - 6 : width - 5) + ',' + (height - 5) + ' ' + (this.options.iconSize.y === 24 ? 7 : 5) + ',' + (height - 5) + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '" />';
            }
            else if (this.options.shape === "trapezoid") {
                if (this.options.highlight) path += '<polygon points="6,2 ' + (width - 6) + ',2 ' + (width - 2) + ',' + (height - 2) + ' 2,' + (height - 2) + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1" />';
                path += '<polygon points="8,5 ' + (width - 8) + ',5 ' + (width - 5) + ',' + (height - 5) + ' 5,' + (height - 5) + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '" />';
            }
            else if (this.options.shape === "pentagon") {
                if (this.options.highlight) path += '<polygon points="2,' + (height / 2) + ' ' + (width / 2) + ',2 ' + (width - 2) + ',' + (height / 2) + ' ' + (width - 5) + ',' + (height - 2) + ' 5,' + (height - 2) + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1" />';
                path += '<polygon points="4,' + ((height / 2) - 1) + ' ' + (width / 2) + ',4 ' + (width - 4) + ',' + ((height / 2) - 1) + ' ' + (width - 7) + ',' + (height - 4) + ' 7,' + (height - 4) + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '" />';
            }
            else if (this.options.shape === "hexagon") {
                if (this.options.highlight) path += '<polygon points="2,' + (height / 2) + ' 6,2 ' + (width - 6) + ',2 ' + (width - 2) + ',' + (height / 2) + ' ' + (width - 6) + ',' + (height - 2) + ' 6,' + (height - 2) + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1" />';
                path += '<polygon points="5,' + ((height / 2) - 3) + ' ' + (width / 2) + ',4 ' + (width - 5) + ',' + ((height / 2) - 3) + ' ' + (width - 5) + ',' + ((height / 2) + 3) + ' ' + (width / 2) + ',' + (height - 4) + ' 5,' + ((height / 2) + 3) + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '" />';
            }
            else if (this.options.shape === "circle") {
                if (this.options.highlight) path += '<circle class="circle-highlight" cx="' + (width / 2) + '" cy="' + (height / 2) + '" r="' + hr + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1"/>';
                path += '<circle class="' + className + '" cx="' + (width / 2) + '" cy="' + (height / 2) + '" r="' + r + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '"/>';
            }
            else if(this.options.shape === "diamond"){
                if (this.options.highlight) path += '<rect class="rect-highlight" x="8.5" y="-8.5" width="' + (hh - 5) + '" height="' + (hh - 5) + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1" transform="rotate(45)"/>';
                path += '<rect class="' + className + '" x="' + (this.options.iconSize.x === 24 ? 11 : 9) + '" y="' + (this.options.iconSize.y === 24 ? -6 : -5) + '" width="' + (h - 2) + '" height="' + (h - 2) + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '" transform="rotate(45)"/>';
            }
            else {
                path += '<path class="' + className + '" d="' + pathDescription + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '"/>';
            }
            return path;
        },
        _createCircle: function () {
            var cx = Number(this.options.circleAnchor.x)
            var cy = Number(this.options.circleAnchor.y)
            var radius = (this.options.iconSize.x - 8) / 2 * Number(this.options.circleRatio)
            var fill = this.options.circleFillColor
            var fillOpacity = this.options.circleFillOpacity
            var stroke = this.options.circleColor
            var strokeOpacity = this.options.circleOpacity
            var strokeWidth = this.options.circleWeight
            var className = this.options.className + "-circle"

            var circle = '<circle class="' + className + '" cx="' + cx + '" cy="' + cy + '" r="' + radius +
                '" fill="' + fill + '" fill-opacity="' + fillOpacity +
                '" stroke="' + stroke + '" stroke-opacity=' + strokeOpacity + '" stroke-width="' + strokeWidth + '"/>'

            return circle
        },
        _createImage: function () {
            if (!this.options.img) return "";
            var x = this.options.img.x;
            var y = this.options.img.y;
            var height = this.options.img.height + "px";
            var width = this.options.img.width + "px";
            var url = this.options.img.url;

            var text = "<image xlink:href='" + url + "' x='" + x + "' y='" + y + "' width='" + width + "' height='" + height + "' />";

            return text;
        },
        _createText: function () {
            var fontSize = this.options.fontSize + "px"
            var lineHeight = Number(this.options.fontSize)

            var x = Number(this.options.iconSize.x) / 2
            var y = x + (lineHeight * 0.35) //35% was found experimentally 
            var circleText = this.options.circleText;
            if (!circleText) return "";
            var textColor = this.options.fontColor.replace("rgb(", "rgba(").replace(")", "," + this.options.fontOpacity + ")")

            var text = '<text text-anchor="middle" x="' + x + '" y="' + y + '" style="font-size: ' + fontSize + '" fill="' + textColor + '">' + circleText + '</text>'

            return text;
        }
    });

    for (var j in stype_map) {
        for (const i in site_fuze_site_id_status) {
          t.addIcon("svg_site_mpt_" + j + "_" + i, L.divIcon.svgIcon({
              circleRatio: 0,
              circleFillColor: "#ffffff",
              fillOpacity: 1,
              opacity: 1,
              shape: stype_map[j].name,
              iconSize: [22, 22],
              color: "#000000",
              fillColor: site_fuze_site_id_status[i],
              popupAnchor: [0, -15],
              weight: 1
          }));
        }
    }
    L.Control.FilterControl = L.Control.extend({
        onAdd: function(_map) {
            var c = L.DomUtil.create("div", "leaflet-bar leaflet-bar-horizontal");
            // Prevent clicks from affecting the map
            L.DomEvent.disableClickPropagation(c);
            L.DomEvent.disableScrollPropagation(c);
            
            $("<label>")           
             .text("Atoll Schema: ")        
             .appendTo(c)          
             .css({
                 display: "inline-block",
                 float: "left",
                 marginTop: 5,
                 marginLeft: 5,
                 marginRight: 10
             });

            $("<select>")            
                .attr("id", "atollSchemaDropdown")
                .attr("name","atollSchema")
                .appendTo(c)            
                .css({
                    display: "inline-block",
                    float: "left",
                    marginTop: 2,
                });


            var a6 = L.DomUtil.create("a", "leaflet-control-tile fas fa-globe-americas map-icon map-align customBlobe", c);
            a6.title = "Change Map";
            return c;
        },
    });

    L.control.filterControl = function (options) {
        return new L.Control.FilterControl(options);
    }

    L.control.filterControl({ position: 'topleft' }).addTo(leaf);
    
    $('#mapContainer div.dash3-0-split-widget').css({'background-image': 'url(' + split + ')'});
    
    $(".dash3-0-tabular-widget").click(function (e) {
        currentViewModel = "grid-only";
        $("#map_split_container").css("height", "0vh");
        $("#site_split_container").css("height", "calc(100vh - 32px)");
        setTimeout(function () {
            updateLayout();
        }, 0);

        $('#mapContainer div.dash3-0-split-widget').css({'background-image': 'url(' + wo_split + ')'});
        $('#mapContainer div.dash3-0-map-widget').css({'background-image': 'url(' + wo_map + ')'});
        $('#mapContainer div.dash3-0-tabular-widget').css({'background-image': 'url(' + tab + ')'});

    });

    $(".dash3-0-map-widget").click(function (e) {
        fullMap(e);
    });

    $(".dash3-0-split-widget").click(function (e) {
        splitView(e);
    });

    $(document).on("change", ".transmitter-check", function (e) {
        var name = $(this).val();
        if($(this).is(":checked") == true){
            getTransmitterData(name);
        }else{
            if(verisonTxMap[name]){
                $.each(verisonTxMap[name], function(i, v){
                    if(transmitterNodeList[v]){
                        t.removeNode(transmitterNodeList[v]);
                        delete transmitterNodeList[v];
                    }
                });
                delete verisonTxMap[name];
            }
        }
    });

    $(document).on("change", ".singlecoverage-check", function (e) {
        showBands($(this).attr('txId'), $(this).prop('checked'), "sect_" + $(this).attr('name') + ":" + $(this).attr('sect'), $(this).attr('band'), $(this).attr('sect'));
    });

    $(document).on("click", ".editTxPopup", function (e) {
        showEditTxPopup($(this));
    });

    drawLegend($("#legendbar"));

    $('#submitEditTxPopupBtn').click(function(e){
        // remove existing coverage data
        
        compareData = {};
        var siteName = $('#txNameInEditPopup').val();
        var sector = $('.singlecoverage-check').parents('.leaflet-popup-content').find('.sectField').text();
        var band = $('.singlecoverage-check').parent().find('select').val().toString()
        removeTxCoverage(transmitterIdBandMap[siteName][sector][band].TX_ID);
        showLegends();
        
        // existing coverage data
        var json = {};
        json.tx_id = $('#txIdInEditPopup').val();
        json.site = $('#txNameInEditPopup').val();
        json.market = $('#atollSchemaDropdown').val().toString();
        json.request_type = "RLOPL";
        json.request_subtype = "A";
        json.output_request_list = '[{"type":"Vector","SubType":"Shape","Threshold":"133"},{"type":"Raster","SubType":"Bil","Threshold":"123"}]';
        json.user_id = VZID;
        json.modified_attributes = {};
        json.modified_attributes.azimut = $('#azimuthInEditPopup').attr("old-azimuth") + "";
        json.modified_attributes.tilt = $('#tiltInEditPopup').attr("old-tilt") + "";
        // json.modified_attributes.vz_lte_max_power = $('#lteMaxPowerInEditPopup').attr("old-lteMaxPower") + "";
        clearInterval(checkTxStatusIntervalNew);
        newAjaxFlag = false;

        compareData.current = {};
        compareData.current.columnName = "Current";
        compareData.current.TX_ID = $('#txIdInEditPopup').val();
        compareData.current.Site = $('#txNameInEditPopup').val();
        compareData.current.Azimuth = $('#azimuthInEditPopup').attr("old-azimuth") + "";
        compareData.current.Tilt = $('#tiltInEditPopup').attr("old-tilt") + "";
        // compareData.current.vz_lte_max_power = $('#lteMaxPowerInEditPopup').attr("old-lteMaxPower") + "";
        compareData.current.AreaCoverage = 10.156;
        compareData.current.PopsCovered = 3156;
        var d = new Date();
        totalResponseSecondsExisting = d;
        var month = d.getMonth()+1;
        var day = d.getDate();
        var time = d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds();
        var output = d.getFullYear() + '/' + (month<10 ? '0' : '') + month + '/' + (day<10 ? '0' : '') + day;
        // compareData.current.Time_to_generate_coverage = output + " " + time;


        submitTransmitterData(json, "existing");

        // new coverage data
        json = {};
        json.tx_id = $('#txIdInEditPopup').val();;
        json.site = $('#txNameInEditPopup').val();
        json.market = $('#atollSchemaDropdown').val().toString();
        json.request_type = "RLOPL";
        json.request_subtype = "A";
        json.output_request_list = '[{"type":"Vector","SubType":"Shape","Threshold":"133"},{"type":"Raster","SubType":"Bil","Threshold":"123"}]';
        json.user_id = VZID;
        json.modified_attributes = {};
        json.modified_attributes.azimut = $('#azimuthInEditPopup').val() + "";
        json.modified_attributes.tilt = $('#tiltInEditPopup').val();
        json.modified_attributes.vz_lte_max_power = $('#lteMaxPowerInEditPopup').val() + "";
        clearInterval(checkTxStatusIntervalExisting);
        existingAjaxFlag = false;

        
        compareData.new = {};
        compareData.new.columnName = "New";
        compareData.new.TX_ID = $('#txIdInEditPopup').val();
        compareData.new.Site = $('#txNameInEditPopup').val();
        compareData.new.Azimuth = $('#azimuthInEditPopup').val() + "";
        compareData.new.Tilt = $('#tiltInEditPopup').val();
        // compareData.new.vz_lte_max_power = $('#lteMaxPowerInEditPopup').val() + "";
        compareData.new.AreaCoverage = 8.79;
        compareData.new.PopsCovered = 2789;
        d = new Date();
        totalResponseSecondsNew = d;
        month = d.getMonth()+1;
        day = d.getDate();
        time = d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds();
        output = d.getFullYear() + '/' + (month<10 ? '0' : '') + month + '/' + (day<10 ? '0' : '') + day;
        // compareData.new.Time_to_generate_coverage = output + " " + time;

        submitTransmitterData(json, "new");
    });

    $(document).on('mouseup', ".leaflet-control > a.leaflet-control-tile", function (e) {
		if ($(this).hasClass('leaflet-disabled')) return;
	
		openUrl($(".leaflet-top.leaflet-left > .leaflet-control"));
    });
    
    $(document).on('change', "#urlgroup > input:radio", function () {
        var v = $(this).val();
        if (v === 'grayscale_url') current_url = grayscale_url;
        if (v === 'satellite_url') current_url = satellite_url;
        if (v === 'streetmap_url') current_url = streetmap_url;
       
        if (v === 'google_street') {
            googleRoadMutant.addTo(leaf);
            leaf.removeLayer(googleTerrainMutant);
        }else if(v === 'google_terrain'){
            googleTerrainMutant.addTo(leaf);
            leaf.removeLayer(googleRoadMutant);
        }else{
            leaf.removeLayer(googleRoadMutant);
            leaf.removeLayer(googleTerrainMutant);
            try {
                t.setMapUrl(current_url);
            }
            catch (e) {}
        }
    });

    buildsiteGrids();
   
    $('#loading').hide();
});

function openUrl(element) {
    var offset = $(element).offset();
    $('#urlWindow').show().css({ 'top': parseInt(offset.top), 'left': parseInt(offset.left + 36) });
    // if($('#urlWindow .filterHelpIcon').length == 0){
    //     $('#urlWindow .popup-close-button').after( "<a class='filterHelpIcon fa fa-question' onClick='showHelpText(\"Planning.Help.ChangeMap\")'></a>" );
    // }
}

function closeUrl() {
    $("#urlWindow").hide();
}

function getNewSiteData(flag){
    $("#siteGrid").data("kendoGrid").dataSource.filter({});
    $('#siteGrid').data('kendoGrid').dataSource.read();
    $('#siteGrid').data('kendoGrid').refresh();
    hideLegends();   
}

function showLegends(){
    $('#legendbar').show();
    const legendBarHeightShow = $("#legendbar").height();
        $("#legendbar").css('margin-top', function setHeight() {
            return -1 * (legendBarHeightShow - 28);
        });
        $("#map").height('calc(100% - ' + (legendBarHeightShow - 11) + 'px)');
}

function hideLegends(){
    $('#legendbar').hide();
    const legendBarHeight = $("#legendbar").height();
        $("#legendbar").css('margin-top', function setHeight() {
            return -1 * (legendBarHeight - 28);
        });
        $("#map").height('calc(100% - ' + (legendBarHeight - 35) + 'px)');
}

//creates legend icons for sites, solutions, and candidates
function drawLegend($elem) {   
    for (var i=yarr.length-1; i>=0; i--) {
        $('<span style="margin-right: 10px;"><svg width="14" height="14" xmlns="http://www.w3.org/2000/svg"><circle cx="7" cy="7" r="5" stroke-width="1" fill="' + solyear_map[yarr[i]] + '"/></svg><span>' + yarr[i] + '</span><span>').insertAfter("#secthead");
    }   
}

function buildsiteGrids() {
    var dataSource = new kendo.data.DataSource({
        type: "odata",
        transport: {
            read: {
                url: CONTEXT_PATH + "/uui/eapp/atoll_pg/siteGrid",
                dataType: "json",
                type: "POST"
            },
            parameterMap: function (data, type) {
                $('<div class="k-loading-mask" id="versionLoadSpin" style="width: 100%; height: 100%; top: 0px; left: 0px;"><span class="k-loading-text">Loading...</span><div class="k-loading-image"></div><div class="k-loading-color"></div></div>').appendTo('#siteGrid .k-grid-content');
                var dataSource = $("#siteGrid").data("kendoGrid").dataSource;
                // Gets the filter from the dataSource
                var filters = dataSource.filter();
                var sort = dataSource.sort();
                data.take = data.take;
                data.skip = data.skip;
                data.filter = JSON.stringify(filters);
                if (sort != undefined) {
                    data.sort = JSON.stringify(sort[0]);
                }
                if (initialFlag == true) {
                    data.initialFlag = "frominitialdontreturndata";
                }
                data.atollSchema = $('#atollSchemaDropdown').val()? $('#atollSchemaDropdown').val().toString() : "";
                return data;
            }
        },
        schema: {
            data: function (response) {
                refreshMapNew(response.data);
                return response.data; // twitter's response is { "statuses": [ /* results */ ] }
            },
            total: function (data) {
                // $('#loading').hide();
                return data.data.length;
            }
        },
        pageSize: 50,
        serverPaging: false,
        serverFiltering: false,
        serverSorting: false
    });
    $("#siteGrid").kendoGrid({
        autoBind: true,
        height: gridHeight,
        sortable: true,
        detailInit: detailInit,
        pageable: {
            pageSizes: [10, 25, 50, 100, 150, 200, 500],
            input: true,
            numeric: false,
            messages :{}
        },
        columns: [
            {
                selectable: true,
                width: "50px"
            },
            {
                "title": "Site Name",
                "field": "NAME",
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains"
                    }
                },
                template: function (dataItem) {
                    if (kendo.htmlEncode(dataItem.VZ_SITE_NAME) != null && kendo.htmlEncode(dataItem.VZ_SITE_NAME) != "null" && kendo.htmlEncode(dataItem.VZ_SITE_NAME) != "undefined" && kendo.htmlEncode(dataItem.VZ_SITE_NAME) != undefined) {
                        return "<a  href='" + CONTEXT_PATH + "/uui/eapp/atoll_pg/versionSearchPage?siteName=" + dataItem.VZ_SITE_NAME + "&fuzeSiteId=" + dataItem.VZ_SITE_INFO_ID + 
                        "&schema=" + $('#atollSchemaDropdown').val().toString() + "'" +
                        " target='_blank'>"
                        + dataItem.VZ_SITE_NAME + "</a>";
                    } else {
                        return "<span></span>"
                    }
                },
            },
            {
                "title": "Fuze Site Id",
                "field": "VZ_SITE_INFO_ID",
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains"
                    }
                },
                template: function (dataItem) {
                    if (kendo.htmlEncode(dataItem.VZ_SITE_INFO_ID) != null && kendo.htmlEncode(dataItem.VZ_SITE_INFO_ID) != "null" && kendo.htmlEncode(dataItem.VZ_SITE_INFO_ID) != "undefined" && kendo.htmlEncode(dataItem.VZ_SITE_INFO_ID) != undefined) {
                        return "<a href='https://fuze.verizon.com/spm/sites.jsp?siteId=" + dataItem.VZ_SITE_INFO_ID + "' target='_blank'>" + dataItem.VZ_SITE_INFO_ID + "</a>";
                    } else {
                        return "<span></span>"
                    }
                },
            },
            {
                "title": "Latitude",
                "field": "LATITUDE",
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains"
                    }
                }
            },
            {
                "title": "Longitude",
                "field": "LONGITUDE ",
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains"
                    }
                }
            }
        ],
        dataSource: dataSource,
        dataBound: siteDataBound,
        filterable: {
            // mode: "row",
            operators: {},
            extra: false
        },
        filter: function (e) {
            setTimeout(function () {
                var grid = $("#siteGrid").data("kendoGrid");
                var ds = grid.dataSource;;
                var nodeData = [];
                if (ds._filter == null) {
                    var allData = ds.data();
                    nodeData = allData;
                    // console.log("filter has been cleared");
                } else {
                    var filters = ds.filter();
                    var allData = ds.data();
                    var query = new kendo.data.Query(allData);
                    var data = query.filter(filters).data;
                    nodeData = data;
                    // console.log(data);
                }
                refreshMapNew(nodeData);
            }, 10);
        },
        columnMenu: {
            columns: false
        },
        reorderable: true,
        resizable: true
    });
}

function siteDataBound(e){

    $("#siteGrid").find('tbody').find("[role='row']").find('td').on("click", function(e){
    	var grid = $("#siteGrid").data("kendoGrid");
        var row = $(e.target).closest("tr");
        
        if (e.target.tagName == "INPUT") {
            // checkbox
            preUid = undefined;
            if ($(e.target).attr('aria-checked') == "false") {
                // select
                grid.clearSelection();
                grid.select(row);
                preUid = $(e.target).closest("tr").attr('data-uid');
                var selectedItem = grid.dataItem(row);
                var siteName = selectedItem? selectedItem.VZ_SITE_NAME : "";
                var fuzeSiteId = selectedItem? selectedItem.VZ_SITE_INFO_ID : undefined;
                if(siteIdList["node_" + siteName]){
                    leaf.setView([selectedItem.LATITUDE, selectedItem.LONGITUDE], 16);
                    siteIdList["node_" + siteName].fire('click').fire('mouseout');
                }else if(fuzeSiteId && siteIdList["node_" + siteName + fuzeSiteId]){
                    leaf.setView([selectedItem.LATITUDE, selectedItem.LONGITUDE], 16);
                    siteIdList["node_" + siteName + fuzeSiteId].fire('click').fire('mouseout');
                }
            } else {
                // deselect
                grid.clearSelection();
                preUid = undefined;
                return;
            }
            return;
        }
        if (preUid == $(e.target).closest("tr").attr('data-uid')) {
            // deselect
            return;
        } else {
            // select
            grid.clearSelection();
            grid.select(row);
            preUid = $(e.target).closest("tr").attr('data-uid');
            var selectedItem = grid.dataItem(row);
            var siteName = selectedItem? selectedItem.NAME : "";
            var fuzeSiteId = selectedItem? selectedItem.VZ_SITE_INFO_ID : undefined;
            if(siteIdList["node_" + siteName]){
                leaf.setView([selectedItem.LATITUDE, selectedItem.LONGITUDE], 16);
                siteIdList["node_" + siteName].fire('click').fire('mouseout');
            }else if(fuzeSiteId && siteIdList["node_" + siteName + fuzeSiteId]){
                leaf.setView([selectedItem.LATITUDE, selectedItem.LONGITUDE], 16);
                siteIdList["node_" + siteName + fuzeSiteId].fire('click').fire('mouseout');
            }
        }
    });
}

function renderLegend(){

}

function refreshMap(data){
    // remvoe transmitter node
    for(var i in verisonTxMap){
        $.each(verisonTxMap[i], function(i, v){
            if(transmitterNodeList[v]){
                t.removeNode(transmitterNodeList[v]);
                delete transmitterNodeList[v];
            }
        });
    }
    verisonTxMap = {};
    siteIdList = {};
    leaf.setView([40, -102.4], 4);
    
    if(markerClusters){
        L.DomUtil.remove(markerClusters);
        leaf.removeLayer(markerClusters);
        markerClusters.clearLayers();
    }
    
    markerClusters=null;
  
    markerClusters = new L.MarkerClusterGroup({
        disableClusteringAtZoom : 14,
        maxClusterRadius : 50,
        animateAddingMarkers : true
    });
    
    var myRenderer = L.canvas({ padding: 0.5 });
    if (!data || $.isEmptyObject(data)) {
        return;
    }
    for (var i in data) {
        if(siteIdList["node_" + data[i].NAME]){
            continue;
        }
        var flag = "without_fuze_site_id";
        if(data[i].VZ_SITE_INFO_ID){
            flag = "with_fuze_site_id";
        }
        var colorType = svg_site_color["svg_site_" + flag];
            
        var markerOptions = {
            "LATITUDE": data[i].LATITUDE,
            "LONGITUDE": data[i].LONGITUDE,
            "VZ_SITE_INFO_ID": data[i].VZ_SITE_INFO_ID,
            "VZ_SITE_NAME": data[i].VZ_SITE_NAME,
            "NAME": data[i].NAME,
        };
        
        var circleMarker = L.circleMarker([Number(data[i].LATITUDE), Number(data[i].LONGITUDE)], {
            renderer: myRenderer,
            color: colorType,
            markerOptions: markerOptions
        });
        // if(data[i].VZ_SITE_INFO_ID){
        //     siteIdList["node_" + data[i].NAME] = circleMarker;
        // }else{
        //     siteIdList["node_" + data[i].NAME] = circleMarker;
        // }
        siteIdList["node_" + data[i].NAME] = circleMarker;
        markerClusters.addLayer(circleMarker);
    }
    markerClusters.addTo(leaf);
    
    $.each(siteIdList, function(i, v){
        if(v && v.options && v.options.markerOptions){
            bindSiteNodePopup(v.options.markerOptions.NAME, v.options.markerOptions.VZ_SITE_NAME, v.options.markerOptions.VZ_SITE_INFO_ID, v.options.markerOptions.LATITUDE, v.options.markerOptions.LONGITUDE, v);
        }
    })
    $('#loading').hide();
}


function refreshMapNew(data){
    // remvoe transmitter node
    for(var i in verisonTxMap){
        $.each(verisonTxMap[i], function(i1, v){
            if(transmitterNodeList[v]){
                t.removeNode(transmitterNodeList[v]);
                delete transmitterNodeList[v];
            }
        });
    }
    verisonTxMap = {};
    siteIdList = {};
    leaf.setView([40, -102.4], 4);
    
    if(markerClusters){
        L.DomUtil.remove(markerClusters);
        leaf.removeLayer(markerClusters);
        markerClusters.clearLayers();
    }
    for(var i in txcoverageKml){
        for(j in txcoverageKml[i]){
            if(txcoverageKml[i][j]["existing"]){
                leaf.removeLayer(txcoverageKml[i][j]["existing"]);
            }
            if(txcoverageKml[i][j]["newCoverage"]){
                leaf.removeLayer(txcoverageKml[i][j]["newCoverage"]);
            }
            delete txcoverageKml[i][j];
        }
    }
    $('#txGridBox').removeClass("col-sm-6").addClass("col-sm-12");
    $('#compareTxGridBox').show();

    markerClusters=null;
  
    markerClusters = new L.MarkerClusterGroup({
        disableClusteringAtZoom : 14,
        maxClusterRadius : 50,
        animateAddingMarkers : true
    });
    
    if (!data || $.isEmptyObject(data)) {
        return;
    }
    for (var i in data) {
        if(siteIdList["node_" + data[i].NAME] || !data[i] || isNaN(data[i].LATITUDE) || isNaN(data[i].LONGITUDE)){
            continue;
        }
        var flag = "without-fuze-site-id";
        if(data[i].VZ_SITE_INFO_ID){
            flag = "with-fuze-site-id";
        }
        var markerOptions = {
            "LATITUDE": data[i].LATITUDE,
            "LONGITUDE": data[i].LONGITUDE,
            "VZ_SITE_INFO_ID": data[i].VZ_SITE_INFO_ID,
            "VZ_SITE_NAME": data[i].VZ_SITE_NAME,
            "NAME": data[i].NAME,
        };
        var shape = "";
        // var tp = data[i]["MPT_SITETYPE"].toUpperCase();
        // if (tp.indexOf("MACRO") >= 0) shape = "MACRO";
        // else if (tp.indexOf("SC") >= 0 || tp.indexOf("DAS") >= 0) shape = "SC/ODAS";
        // else if (tp.indexOf("IB") >= 0 || tp.indexOf("INBLD") >= 0 || tp.indexOf("IN-BUILDING") >= 0) shape = "INBLD";
        // else if (tp.indexOf("SMALL-CELL") >= 0 || tp.indexOf("Small Cell") >= 0) shape = "SMALL-CELL";
        // else shape = "OTHER";
        // var icon = "svg_site_mpt_" + shape;
        var icon = "svg_site_mpt_" + "MACRO" + "_" + flag;
        var circleMarker = L.marker([Number(data[i].LATITUDE), Number(data[i].LONGITUDE)], {
            icon: XYZ._icon_map[icon],
            markerOptions: markerOptions
        });
        siteIdList["node_" + data[i].NAME] = circleMarker;
        markerClusters.addLayer(circleMarker);
    }
    markerClusters.addTo(leaf);
    
    $.each(siteIdList, function(i, v){
        if(v && v.options && v.options.markerOptions){
            bindSiteNodePopup(v.options.markerOptions.NAME, v.options.markerOptions.VZ_SITE_NAME, v.options.markerOptions.VZ_SITE_INFO_ID, v.options.markerOptions.LATITUDE, v.options.markerOptions.LONGITUDE, v);
        }
    })
    $('#loading').hide();
}

function bindSiteNodePopup(name, siteName, fuzeSiteId, lat, lng, n){
    fuzeSiteId = fuzeSiteId? fuzeSiteId : "";
   
    var popup = "<div style='background:white;width: 300px !important;'>"
        + "<h4><a href='" + CONTEXT_PATH + "/uui/eapp/atoll_pg/versionSearchPage?siteName=" + siteName + "&fuzeSiteId=" + fuzeSiteId + "&schema=" + $('#atollSchemaDropdown').val().toString() + "' target='_blank'>" + siteName + "</a></h4>"
        + "<div class='popup-inner' style='border:1px solid #d7d7d7;background: #f7f7f7; margin-bottom:10px; padding:0 5px;'>"
        + "<div><div class='halfdiv'><h5>Fuze Site Id</h5></div><div class='halfdiv'><a href='https://fuze.verizon.com/spm/sites.jsp?siteId=" + fuzeSiteId + "' target='_blank'>" + fuzeSiteId + "</a></div></div>"
        + "<div><div class='halfdiv'><h5>Latitude</h5></div><div class='halfdiv'>" + lat + "</div></div>"
        + "<div><div class='halfdiv'><h5>Longitude</h5></div><div class='halfdiv'>" + lng + "</div></div>"
        + "<span class='checkbox vzbs-checkbox vzbs-transmitter' style=''><input id='transmitter_" + siteName + "'value='" + name + "' class='transmitter-check' siteName='" + siteName + "' siteId='" + fuzeSiteId + "' type='checkbox'><label id='txLabel' title='Please zoom in to level 14 to see transmitter data' for='transmitter_" + siteName + "'>Transmitter</label></span></div>"
        + "</div>";   
        
    if(!n){
        return;
    }
    n.unbindPopup();
    n.bindPopup(popup);
    n.on('popupopen', function (e) {
        var name = e.target && e.target.options && e.target.options.markerOptions? e.target.options.markerOptions.NAME : "";
        if (verisonTxMap[name]) {
            $(".leaflet-popup-content .vzbs-transmitter > input.transmitter-check").prop("checked", true);
            $(".leaflet-popup-content .vzbs-transmitter > input.transmitter-check").trigger('change');
        }
        //$(document).on("change", ".transmitter-check", function (e) {

            // if(leaf.getZoom()>=14){
            //     $(".transmitter-check").attr("disabled", false);
            //     $("#txLabel").attr('style', 'cursor: default !important');  
            // }
            // else{
            //     $(".transmitter-check").attr("disabled", true);  
            //     $("#txLabel").attr('style', 'cursor: not-allowed !important');
            // }
            $(".transmitter-check").attr("disabled", false);
            $("#txLabel").attr('style', 'cursor: default !important');  
    });
    n.on('click', function (e) {
        if(e.originalEvent){
            var name = e && e.target && e.target.options && e.target.options.markerOptions && e.target.options.markerOptions.NAME? e.target.options.markerOptions.NAME : "";
            if(name && name != ""){
                selectGridRow(name);
            }
        }
    });
}

function selectGridRow(name){
    var grid = $("#siteGrid").data("kendoGrid");
    var dataSource = grid.dataSource;
    var filters = dataSource.filter() || {};
    var sort = dataSource.sort() || {};
    var models = dataSource.data();
    // We are using a Query object to get a sorted and filtered representation of the data, without paging applied, so we can search for the row on all pages
    var query = new kendo.data.Query(models);
    var rowNum = 0;
    var modelToSelect = null;
    models = query.filter(filters).sort(sort).data;
    // Now that we have an accurate representation of data, let's get the item position
    for (var i = 0; i < models.length; ++i) {
        var model = models[i];
        if (model && model.NAME == name) {
            modelToSelect = model;
            rowNum = i;
            break;
        }
    }
    // Now go to the page holding the record and select the row
    var currentPageSize = grid.dataSource.pageSize();
    var pageWithRow = parseInt((rowNum / currentPageSize)) + 1; // pages are one-based
    grid.dataSource.page(pageWithRow);
    if(modelToSelect){
        var row = grid.element.find("tr[data-uid='" + modelToSelect.uid + "']");
        if (row.length > 0) {
            grid.select(row);
            // Scroll to the item to ensure it is visible
            if (grid.select().offset() != undefined) {
                grid.element.find(".k-grid-content").scrollTop(grid.select().offset().top - grid.tbody.offset().top);
            }
        }
    }
  }
function getUserSchema(schemaVal){
    if(roles.indexOf("BETA_USER") >= 0){
        $.each(atollSchema, function(i, v){
            $('#atollSchemaDropdown').append("<option>" + v.toUpperCase() + "</option>");
        });
        $('#atollSchemaDropdown').multiselect({
            includeSelectAllOption: true,
            enableFiltering:true,
            enableCaseInsensitiveFiltering: true,
            buttonClass: 'btn btn-default whitebg btn-sm',
            numberDisplayed: 1
        });
    }else{
        $.ajax({
            url: '/uuigui/uui/eapp/atoll_pg/getUserSchemas',
            type: 'GET',
            contentType: 'application/json',
            success: function (data) {
                data = data && data.data? data.data : [];
                $.each(data, function(i, v){
                    $('#atollSchemaDropdown').append("<option>" + v.SCHEMA + "</option>");
                });
                $('#atollSchemaDropdown').multiselect({
                    includeSelectAllOption: true,
                    enableFiltering:true,
                    enableCaseInsensitiveFiltering: true,
                    buttonClass: 'btn btn-default whitebg btn-sm',
                    numberDisplayed: 1
                });
            }
        });
    }
    $('#atollSchemaDropdown').change(function(e){
        initialFlag = false;
        $('#loading').show();
        getNewSiteData();
        var state = {
            schema: $('#atollSchemaDropdown').val()
        };
        UiSettingsSave("ATOLL.CARRIER.Map.Schema", state, function(res){
            
        });
    });
    if(schemaVal){
        $('#atollSchemaDropdown').val(schemaVal).multiselect("refresh");
        $('#atollSchemaDropdown').trigger('change');
    }
}


function drawTransmitter(name, data){
    data = data && data.data? data.data : [];
    var elist = [];
    var n = siteIdList["node_" + name];
    // markerClusters.removeLayer(n);
    // //bindSiteNodePopup(n.options.markerOptions.NAME, n.options.markerOptions.VZ_SITE_NAME, n.options.markerOptions.VZ_SITE_INFO_ID, n.options.markerOptions.LATITUDE, n.options.markerOptions.LONGITUDE, n);
    // var nLat = n.options.markerOptions.LATITUDE;
    // var nLon = n.options.markerOptions.LONGITUDE;
    // var nZoom = leaf.getZoom() + 1;
    
    if (!n) return;
    var sitename = data[0]? data[0].SITE_NAME : "";
    if(leaf.getZoom() <= 6){
        multiplier = .6;
    }else if(leaf.getZoom() <= 10){
        multiplier = .75;
    }else if(leaf.getZoom() <= 15){
        multiplier = 1;
    }else{
        multiplier = 1.25
    }
    var count = 0.0;
    var sectorsData = {};
    $.each(data, function(i, v){
        if(!sectorsData[v.VZ_SECTOR]){
            sectorsData[v.VZ_SECTOR] = {};
            sectorsData[v.VZ_SECTOR].ABS_X = v.ABS_X;
            sectorsData[v.VZ_SECTOR].ABS_Y = v.ABS_Y;
            sectorsData[v.VZ_SECTOR].BANDStr = "";
            sectorsData[v.VZ_SECTOR].SECTOR = v.VZ_SECTOR;
            sectorsData[v.VZ_SECTOR].VZ_LTE_MAX_POWER = v.VZ_LTE_MAX_POWER;
            sectorsData[v.VZ_SECTOR].AZIMUT = v.AZIMUT;
            sectorsData[v.VZ_SECTOR].TX_ID = v.TX_ID;
            sectorsData[v.VZ_SECTOR].band = [];
            count++;
        }
        sectorsData[v.VZ_SECTOR].BANDStr += sectorsData[v.VZ_SECTOR].BANDStr == ""? v.FBAND : ";" + v.FBAND;
        sectorsData[v.VZ_SECTOR].band.push(v);
    });
    var degree = 180 / count;
    if (360 === degree || 0 === degree) {
        degree = 359.9
    }
    // var azimuth = 0;
    for(var i in sectorsData){
        var uid = name + ":" + i;
        verisonTxMap[name] = verisonTxMap[name]? verisonTxMap[name] : [];
        if(verisonTxMap[name].indexOf(uid) < 0){
            verisonTxMap[name].push("sect_" + uid);
        }
        var azlist = [];
        if( !transmitterNodeList["sect_" + uid]){
            var sector = '<svg viewBox="0 0 160 160" height="100%" width="100%" className="vpi-sector-container" style="pointer-events: none;">';
            var color = "#00ac3e";
            $.each(sectorsData[i].band, function(j, v1){
                var radius = 10 + ((69 / (sectorsData[i].band.length)) * (sectorsData[i].band.length - j));
                var azimuth = v1.AZIMUT;
                if (azlist.indexOf(azimuth) < 0) azlist.push(azimuth);
                var bd = v1.FBAND;
                var txid= v1.TX_ID;

                var sect = v1.VZ_SECTOR;
                transmitterIdBandMap[name] = transmitterIdBandMap[name]? transmitterIdBandMap[name] : {};
                transmitterIdBandMap[name][sect] = transmitterIdBandMap[name][sect]? transmitterIdBandMap[name][sect] : {};
                transmitterIdBandMap[name][sect][bd] = v1;


                const x0 = 80, y0 = 80;
                const th0 = (azimuth - 90) * (Math.PI / 180);
                const half_width = (degree / 2) * (Math.PI / 180);
                const thA = th0 + half_width, thB = th0 - half_width;
                const xA = x0 + radius * Math.cos(thA), yA = y0 + radius * Math.sin(thA);
                const xB = x0 + radius * Math.cos(thB), yB = y0 + radius * Math.sin(thB);
                var r2 = 10 + ((69 / (sectorsData[i].band.length)) * (sectorsData[i].band.length - j - 1));
                const xAi = x0 + r2 * Math.cos(thA), yAi = y0 + r2 * Math.sin(thA);
                const xBi = x0 + r2 * Math.cos(thB), yBi = y0 + r2 * Math.sin(thB);
                var txr = (radius + r2) * 0.5;
                var txa = (thA + (thB < thA ? thB : thB + Math.PI * 2)) * 0.5;
                var txx = x0 + Math.cos(txa) * txr;
                var txy = y0 + Math.sin(txa) * txr;
                var opac = current_url === satellite_url ? 0.9 : 0.6;
                sector += '<g style="pointer-events: auto;"><path '
                    + 'class=""'
                    + 'd="M ' + xA + ' ' + yA + ' A ' + radius + ' ' + radius + ' ' + th0 + ' ' + (180 < degree ? 1 : 0) + ' 0 ' + xB + ' ' + yB + ' L ' + xBi + ' ' + yBi + ' A ' + r2 + ' ' + r2 + ' ' + th0 + ' ' + (180 <= degree ? 1 : 0) + ' 1 ' + xAi + ' ' + yAi + ' L ' + xA + ' ' + yA + '"' + 'stroke="' + '#00ff00' + '" '
                    + 'stroke-width="2" '
                    + 'fill="' + color + '" fill-opacity="0.65" '
                    + 'className="antenna-sector" '
                    + '><title>Transmitter Id: ' + txid + '| Sector: ' + i + ' | Band:' + bd + '</title></path>'
                    + '<text x="' + txx + '" y="' + txy + '" >' + bd + '</text></g>';
            });
            sector += '</svg>';
            azlist.sort();
            var markerOptions = {
                isSector: true,
                isVpi: true,
            };
            var sn = XYZ.node("sect_" + uid, Number(sectorsData[i].ABS_X), Number(sectorsData[i].ABS_Y), {
                icon: "svg_site_mpt_MACRO",
                markerOptions: markerOptions,
                tooltip: {
                    options: {
                        direction: "bottom",
                        className: "nitro-tooltip",
                        sticky: true,
                        permanent: false
                    }
                },
                popup: {
                    html: ""
                }
            });
            transmitterNodeList["sect_"+uid] = sn;
            try{
                t.addNode(sn);
            }catch(err){
                
            }
            
            sn.marker.setIcon(new L.divIcon({
                iconSize: [100 * multiplier, 100 * multiplier],
                popupAnchor: [0, 0],
                className: "transparent-background vpi-sector-icon",
                html: sector
            }));

            // disable the dragging for the sector pie
            sn.marker.dragging.disable();
            bindSectorPopup("sect_" + uid, sectorsData[i].TX_ID, name, sectorsData[i].ABS_X, sectorsData[i].ABS_Y, sectorsData[i]);
        }
    }
}

function bindSectorPopup(id, txId, name, lat, lng, data) {
    var band = data.BANDStr;
    var sect = data.SECTOR;
    var azimuth = data.AZIMUT;
    var lteMaxPower = data.VZ_LTE_MAX_POWER;
    var n = transmitterNodeList[id];
    // var n = t.hasNode("sect_" + enodeb + ":" + sect);
    var popup = "<div style='background:white;width: 300px;'>"
        + "<h4 txId = '" + txId + "' class='siteNameInTxPopup'>" + name + "</h4>"
        + "<div class='popup-inner' style='border:1px solid #d7d7d7;background: #f7f7f7; margin-bottom:10px; padding:0 5px;'>"
        + "<div><div class='halfdiv'><h5>Sector</h5></div><div class='halfdiv sectField'>" + sect + "</div></div>"
        + "<div><div class='halfdiv'><h5>Bands</h5></div><div class='halfdiv'>" + band + "</div></div>"
        + "<div><div class='halfdiv'><h5>Azimuth</h5></div><div class='halfdiv azimuthValueInTxPopup'>" + azimuth + "</div></div>"
        + "<div><div class='halfdiv'><h5>LTE Max Power</h5></div><div class='halfdiv lteMaxPowerInTxPopup'>" + lteMaxPower + "</div></div>"
        + "<div><div class='halfdiv'><h5>Latitude</h5></div><div class='halfdiv'>" + lat + "</div></div>"
        + "<div><div class='halfdiv'><h5>Longitude</h5></div><div class='halfdiv'>" + lng + "</div></div>"
        +"</div>"
        +"<span class='checkbox vzbs-checkbox vzbs-coverage' style=''><input id='singlecoverage_" + id + "' class='singlecoverage-check' name='" + name + "' sect='" + sect + "' band='" + band + "' txid='" + txId + "' value='" + sect + "' type='checkbox'><label for='singlecoverage_" + id + "'>ATOLL Coverage</label></span>"
        +"<button class='btn btn-small btn-danger editTxPopup' style='line-height: 25px;min-height: 25px;padding: 0px;padding-left: 5px;' disabled>Send to Atoll</button>"
        + "</div>"
        + "</div>";
    if(!n){
        return;
    }
    n.marker.bindPopup(popup);
    
    n.marker.on('popupopen', function (e) {
        var $single = $(".leaflet-popup-content .singlecoverage-check");
        // var siteName = $(e).parents(".leaflet-popup-content").find('.siteNameInTxPopup').text();
        // var band = $(e).parents(".leaflet-popup-content").find('select').val()[0];
        // var sector = $(e).parents(".leaflet-popup-content").find('.sectField').text();
        // transmitterIdBandMap[siteId][sector][band].TX_ID;
        var txid = $single.attr("txid");// todo
        if ($single.length) {
            var txid = $single.attr("txid");
            if (txcoverageKml[txid]) {
                $(".leaflet-popup-content .vzbs-coverage > input.singlecoverage-check").prop("checked", true);
                $(".leaflet-popup-content .vzbs-coverage > input.singlecoverage-check").trigger('change');
                var bands = [];
                for (var x in txcoverageKml[txid]) {
                    if(x && bands.indexOf(x) < 0){
                        bands.push(x);
                    }
                }
                if(bands.length == 1 && existingAjaxFlag == false && newAjaxFlag == false){
                    $(".leaflet-popup-content select").parents('.leaflet-popup-content').find('.editTxPopup').attr('disabled', false)
                }else{
                    $(".leaflet-popup-content select").parents('.leaflet-popup-content').find('.editTxPopup').attr('disabled', true)
                }
                setTimeout(function () {
                    $(".leaflet-popup-content select").multiselect('select', bands).multiselect('refresh');
                }, 100);
            }
        }
    })
}

function getTransmitterData(name) {
    if ($vpiAjax) {
        $vpiAjax.abort();
        $vpiAjax = null;
    }
    //$('#loadingDiv').show();
    // $("#loadingIcon").show();
    // $("#loadingTxt").show();
    var json = {
        "atollSchema": $('#atollSchemaDropdown').val()? $('#atollSchemaDropdown').val().toString() : "",
        "name":name
    };
    var d = {json:JSON.stringify(json)};
    $vpiAjax = $.ajax({
        url: CONTEXT_PATH + "/uui/eapp/atoll_pg/getTxDataForMap",
        type: "POST",
        // async: false,
        data: d,
        success: function (data) {
            if (!data || $.isEmptyObject(data)) {
                return;
            }
            drawTransmitter(name, data);
            if(!txData[name]){
                txData[name] = data.data;
            }
        },
        error: function (data) {},
        complete: function (data) {
            $vpiAjax = null;
        }
    });
}

function detailInit(e) {
    var dataSource = new kendo.data.DataSource({
        type: "odata",
        transport: {
            read: {
                url: CONTEXT_PATH + "/uui/eapp/atoll_pg/getTxDataForMapGrid",
                dataType: "json",
                type: "POST"
            },
            parameterMap: function (data, type) {
                var dataSource = $("#siteGrid").data("kendoGrid").dataSource;
                // Gets the filter from the dataSource
                var filters = dataSource.filter();
                var sort = dataSource.sort();
                data.take = data.take;
                data.skip = data.skip;
                data.filter = JSON.stringify(filters);
                if (sort != undefined) {
                    data.sort = JSON.stringify(sort[0]);
                }
                data.atollSchema = $('#atollSchemaDropdown').val()? $('#atollSchemaDropdown').val().toString() : "";
                data.siteName = e.data.NAME;
                return data;
            }
        },
        schema: {
            data: function (response) {
                return response && response.request_obj? response.request_obj : []; // twitter's response is { "statuses": [ /* results */ ] }
            },
            total: function (data) {
                // $('#loading').hide();
                return data && data.request_obj && data.request_obj.length> 0? data.request_obj.length : 0;
            }
        },
        pageSize: 10,
        serverPaging: false,
        serverFiltering: false,
        serverSorting: false
    });

    $("<div/>").appendTo(e.detailCell).kendoGrid({
        dataSource: dataSource,
        scrollable: false,
        dataBound: transimitterDataBound,
        sortable: true,
        pageable: true,
        columns: [
            { 
                selectable: true,
                width: "50px", 
                attributes: {
                    "class": "#=(status != 'Success') ? 'k-state-disabled':''#"
                }
            },
            {
                field: "ACTION",
                filterable: false,
                sortable: false,
                template: function(dataItem) {
                    if(dataItem.status != "Success"){
                        return '<i title="Edit Site" onclick="refreshTxCoverage(this)" class="fas fa-sync-alt" style="cursor: pointer; z-index:100;margin-left:10px;"></i>';
                    }else{
                        return '<i title="Edit Site" class="fas fa-sync-alt" style="cursor: not-allowed; opacity: 0.4; z-index:100;margin-left:10px;"></i>';
                    }
                },
                title: "&nbsp;",
                width: "50px"
            },
            {
                field: "tx_id", 
                title:"TX_ID"
            },
            {
                field: "site",
                title:"Site Name"
            },
            {
                field: "market",
                title:"Market"
            },
            {
                field: "status",
                title:"Status"
            },
            {
                field: "create_time",
                title:"Create Time"
            },
            {
                field: "request_id",
                title: "Request Id"
            }
        ]
    });
}

function transimitterDataBound(e){

    $(e.sender.element).find("[aria-label='Select all rows']").click(function(e) {
        var grid = $(e.sender.element).data("kendoGrid");
        var data = grid.dataSource.data();
        for (var i = 0; i < data.length; i++) {
            var currentDataItem = data[i];
            var row = grid.tbody.find("tr[data-uid='" +  currentDataItem.uid +  "']");
            if(currentDataItem.name == "Jan" && currentDataItem.age > 30){
                setTimeout(function() {
                    $(row).removeClass("k-state-selected"); 
                    var currRowCheckbox = $(row).find(".k-checkbox")
                    $(currRowCheckbox).attr("checked", false);
                });
            }
        }
    });


    $(e.sender.element).find('tbody').find("[role='row']").find('td').on("click", function(e1){
    	var grid = $(e.sender.element).data("kendoGrid");
        var row = $(e1.target).closest("tr");
        
        if (e1.target.tagName == "INPUT") {
            // checkbox
            if ($(e1.target).attr('aria-checked') == "false") {
                // select
                grid.select(row);
                var selectedItem = grid.dataItem(row);
                var request_id = selectedItem? selectedItem.request_id : "";
            } else {
                // deselect
            }
        }
    }); 

    // $(e.sender.element).find('tbody').find("[role='row']").find('td').on("click", function(e1){
    // 	var grid = $(e.sender.element).data("kendoGrid");
    //     var row = $(e1.target).closest("tr");
    // 	var sitegrid = $("#siteGrid").data("kendoGrid");
        
    //     if (e1.target.tagName == "INPUT") {
    //         // checkbox
    //         preTxUid = undefined;
    //         if ($(e1.target).attr('aria-checked') == "false") {
    //             // select
    //             grid.clearSelection();
    //             grid.select(row);
    //             preTxUid = $(e1.target).closest("tr").attr('data-uid');
    //             var selectedItem = grid.dataItem(row);
    //             var siteselectedItem = sitegrid.dataItem(sitegrid.select());
    //             var name = siteselectedItem? siteselectedItem.NAME : "";
    //             var sector = selectedItem? selectedItem.VZ_SECTOR : undefined;
    //             var uid = name + ":" + sector;
    //             if(transmitterNodeList["sect_" + uid] && transmitterNodeList["sect_" + uid].marker){
    //                 leaf.setView([selectedItem.ABS_Y, selectedItem.ABS_X], 16);
    //                 transmitterNodeList["sect_" + uid].marker.fire('click').fire('mouseout');
    //             }
    //         } else {
    //             // deselect
    //             grid.clearSelection();
    //             preTxUid = undefined;
    //             return;
    //         }
    //         return;
    //     }
    //     if (preTxUid == $(e1.target).closest("tr").attr('data-uid')) {
    //         // deselect
    //         return;
    //     } else {
    //         // select
    //         grid.clearSelection();
    //         grid.select(row);
    //         preTxUid = $(e1.target).closest("tr").attr('data-uid');
    //         var selectedItem = grid.dataItem(row);
    //         var siteselectedItem = sitegrid.dataItem(sitegrid.select());
    //         var name = siteselectedItem? siteselectedItem.NAME : "";
    //         var sector = selectedItem? selectedItem.VZ_SECTOR : undefined;
    //         var uid = name + ":" + sector;
    //         if(transmitterNodeList["sect_" + uid] && transmitterNodeList["sect_" + uid].marker){
    //             leaf.setView([selectedItem.ABS_Y, selectedItem.ABS_X], 16);
    //             transmitterNodeList["sect_" + uid].marker.fire('click').fire('mouseout');
    //         }
    //     }
    // });
}

function showEditTxPopup(e){
    $('#editTxPopup').show();
    $('#txNameInEditPopup').val($(e).parents(".leaflet-popup-content").find('.siteNameInTxPopup').text());
    var siteName = $(e).parents(".leaflet-popup-content").find('.siteNameInTxPopup').text()
    var band = $(e).parents(".leaflet-popup-content").find('select').val()[0];
    var sector = $(e).parents(".leaflet-popup-content").find('.sectField').text();
    var txId = transmitterIdBandMap[siteName][sector][band].TX_ID;
    var tilt = transmitterIdBandMap[siteName][sector][band].TILT;
    $('#txIdInEditPopup').val(txId);
    $('#azimuthInEditPopup').val($(e).parents(".leaflet-popup-content").find('.azimuthValueInTxPopup').text());
    $('#azimuthInEditPopup').attr("old-azimuth", $(e).parents(".leaflet-popup-content").find('.azimuthValueInTxPopup').text());

    $('#lteMaxPowerInEditPopup').val($(e).parents(".leaflet-popup-content").find('.lteMaxPowerInTxPopup').text());
    $('#lteMaxPowerInEditPopup').attr("old-lteMaxPower", $(e).parents(".leaflet-popup-content").find('.lteMaxPowerInTxPopup').text());
    
    $('#tiltInEditPopup').attr("old-tilt", tilt);
    $('#tiltInEditPopup').val(tilt);
    $('#alertMask').show();
}

function closeEditTxPopup(e){
    $('#editTxPopup').hide();
    $('#alertMask').hide();
}
function showBands(transmitterId, checked, uniqueId, band, sect) {
    var n = transmitterNodeList[uniqueId];
    var y = leaf.latLngToContainerPoint(n.marker.getLatLng()).y;
    var $popup = $(".leaflet-popup-content");
    $popup.find('.multiholder').remove();

    if (!checked) {
        $popup.find('.vzbs-coverage > label').text("ATOLL Coverage").css({ "color": "black" });
        return;
    }

    var $multi = $("<select multiple='multiple' transmitterId = '" + transmitterId + "' sect='" + sect + "'></select>");
    var bs = band.split(';');
    for (var i in bs) {
        $multi.append("<option value='" + bs[i] + "'>" + bs[i] + "</option>");
    }
    var $div = $("<div class='multiholder' style='width:74%; display:inline-block;'></div>");
    $div.append($multi);
    $popup.find('.vzbs-coverage > label').text("l").css({ "color": "transparent" });
    $popup.find('.vzbs-coverage').append($div);
    $multi.multiselect({
        buttonClass: 'btn btn-default whitebg btn-sm',
        dropUp: y > 200,
        maxHeight: 150,
        nonSelectedText: 'Select Bands',
        includeSelectAllOption: true,
        onDropdownHide: function () {
            var bd = $(".leaflet-popup-content select").val();
            var siteName = $('.singlecoverage-check').attr('name');
            var sector = $('.singlecoverage-check').parents('.leaflet-popup-content').find('.sectField').text();
            // var tx_id = $(".leaflet-popup-content select").attr("transmitterId");
            

            if(bd && bd.length > 0){
                $.each(bd, function(i, v){
                    var txid = transmitterIdBandMap[siteName][sector][v].TX_ID;
                    var tx_record_id = transmitterIdBandMap[siteName][sector][v].VZ_TX_RECORD_ID;
                    var azimuth = transmitterIdBandMap[siteName][sector][v].AZIMUT;
                    var tilt = transmitterIdBandMap[siteName][sector][v].TILT;
                    var market = $('#atollSchemaDropdown').val();
                    if(!txcoverageKml[txid] || !txcoverageKml[txid][v]){
                        getCoverageAreas(v, txid, market,undefined,tx_record_id, azimuth, tilt);
                    }
                })
            }else{
                for(var i in transmitterIdBandMap[siteName][sector]){
                    removeTxCoverage(transmitterIdBandMap[siteName][sector][i].TX_ID);
                }
            }
            if(bd && bd.length == 1){
                $(".leaflet-popup-content select").parents('.leaflet-popup-content').find('.editTxPopup').attr('disabled', false)
            }else{
                $(".leaflet-popup-content select").parents('.leaflet-popup-content').find('.editTxPopup').attr('disabled', true)
            }
        }
    });
}

function getCoverageAreas(band, tx_id, market, threshold, tx_record_id, azimuth, tilt) {
    var json = {}
    json.band = band;
    json.tx_id = tx_id;
    json.tx_record_id = tx_record_id + "";
    json.market = market;
    json.threshold = "133";
    json.request_type = "RLOPL";
    json.user_id = VZID;
    if(threshold){
        json.threshold = threshold;
    }
    $('#loading').show();
    $.ajax({
        url: '/uuigui/uui/eapp/atoll_pg/getCoverageAreas',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(json),
        success: function (data) {
            data = JSON.parse(data);
            if(data && data.request_obj){
                var info = {};
                info.tx_id = tx_id;
                info.threshold = 133;
                info.azimut = azimuth;
                info.tilt = tilt;
                drawCoverage(data, tx_id, band, "existing", info);
            }else{
                $('#loading').hide();     
            }
        },
        complete: function () {

        }
    });
}

function drawCoverage(data, tx_id, band, flag, payload){
    $.each(data.request_obj, function(i, v){
        if(v){
            $.each(v, function(i1, v1){
                if(v1.properties.threshold <= 120){
                    // green
                    color = "#0ff52d";
                }else if(v1.properties.threshold > 120 && v1.properties.threshold <= 133){
                    // greenish yellow
                    color = "#bf00ff";
                }else if(v1.properties.threshold > 133 && v1.properties.threshold <= 138){
                    // yellowish orange
                    color = "#f5e60f";
                }else if(v1.properties.threshold > 138 && v1.properties.threshold <= 143){
                    // orange
                    color = "#f79707";
                }else{
                    // red
                    color = "#ff1e05";
                }
                if(flag == "new"){
                    // black
                    color = "#bff51d";
                }
                var myStyle = {
                    "color": color
                };
                var layer = L.geoJSON(v1, {
                    style: myStyle
                });
                // var tx_id = payload.tx_id;
                var threshold = payload.threshold;
                var azimut = payload.azimut;
                var tilt = payload.tilt;

                var popup = "<div style='background:white;width: 300px !important;'>"
                    // + "<h4><a href='" + CONTEXT_PATH + "/uui/eapp/atoll_pg/versionSearchPage?siteName=" + siteName + "&fuzeSiteId=" + fuzeSiteId + "&schema=" + $('#atollSchemaDropdown').val().toString() + "' target='_blank'>" + siteName + "</a></h4>"
                    + "<div class='popup-inner' style='border:1px solid #d7d7d7;background: #f7f7f7; margin-bottom:10px; padding:0 5px;'>"
                    // + "<div><div class='halfdiv'><h5>Fuze Site Id</h5></div><div class='halfdiv'><a href='https://fuze.verizon.com/spm/sites.jsp?siteId=" + fuzeSiteId + "' target='_blank'>" + fuzeSiteId + "</a></div></div>"
                    + "<div><div class='halfdiv'><h5>TX ID: </h5></div><div class='halfdiv'>" + tx_id + "</div></div>"
                    + "<div><div class='halfdiv'><h5>Threshold</h5></div><div class='halfdiv'>" + threshold + "</div></div>"
                    + "<div><div class='halfdiv'><h5>Azimuth</h5></div><div class='halfdiv'>" + azimut + "</div></div>"
                    + "<div><div class='halfdiv'><h5>Tilt</h5></div><div class='halfdiv'>" + tilt + "</div></div>"
                    // + "<span class='checkbox vzbs-checkbox vzbs-transmitter' style=''><input id='transmitter_" + siteName + "'value='" + name + "' class='transmitter-check' siteName='" + siteName + "' siteId='" + fuzeSiteId + "' type='checkbox'><label id='txLabel' title='Please zoom in to level 14 to see transmitter data' for='transmitter_" + siteName + "'>Transmitter</label></span></div>"
                    + "</div>";   
                    
                layer.unbindPopup();
                layer.bindPopup(popup);
                layer.addTo(leaf);
                txcoverageKml[tx_id] = txcoverageKml[tx_id]? txcoverageKml[tx_id] : {};
                txcoverageKml[tx_id][band] = txcoverageKml[tx_id][band]? txcoverageKml[tx_id][band] : {};
                if(flag == "new"){
                    txcoverageKml[tx_id][band]["newCoverage"] = layer;
                }else{
                    txcoverageKml[tx_id][band]["existing"] = layer;
                }
            })
        }
    })
    $('#loading').hide();
}

function removeTxCoverage(tx_id){
    $('#txGridBox').removeClass("col-sm-6").addClass("col-sm-12");
    $('#compareTxGridBox').show();
    hideLegends();

    if(txcoverageKml[tx_id]){
        for(var i in txcoverageKml[tx_id]){
            if(txcoverageKml[tx_id][i]["existing"]){
                leaf.removeLayer(txcoverageKml[tx_id][i]["existing"]);
            }
            if(txcoverageKml[tx_id][i]["newCoverage"]){
                leaf.removeLayer(txcoverageKml[tx_id][i]["newCoverage"]);
            }
            delete txcoverageKml[tx_id][i];
        }
    }
}

function refreshTxCoverage(e){
    var grid = $(e).closest('.k-widget').data("kendoGrid");
    var row = $(e).closest("tr");
    var selectedItem = grid.dataItem(row);
    var tx_id = selectedItem.tx_id;
    var site = selectedItem.site;
    var json = {};
    json.tx_id = tx_id;
    json.site = site;
    $.ajax({
        url: "/uuigui/uui/eapp/atoll_pg/refreshTxDataByTxId",
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(json),
        success: function (data) {
            data = JSON.parse(data);
            if(data && data.request_obj){
                for (var i in data.request_obj) {
                    if (data.request_obj.hasOwnProperty(i)) {
                        selectedItem.set(i, data.request_obj[i]);
                    }
                }
            }
        }
    });
}

function checkTransmitterStatus(requestId, tx_id, band, flag, info){
    if(flag == "new"){
        checkTxStatusIntervalNew = setInterval(function(){
            var json = {};
            json.request_id = requestId;
            json.threshold = 133;
            $.ajax({
                url: '/uuigui/uui/eapp/atoll_pg/checkTransmitterStatus',
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(json),
                success: function (data) {
                    data = JSON.parse(data);
                    checkApiCountNew++;
                    if(data && data.meta && data.meta.status == 'ok'){
                        clearInterval(checkTxStatusIntervalNew);
                        newAjaxFlag = false;
                        checkApiCountNew = 0;
                        if(data.request_obj){
                            var d = new Date();
                            var difference = (d - totalResponseSecondsNew) / 1000;
                            // compareData.new.Time_to_generate_coverage = Number(difference).toFixed() + " seconds";
                            compareData.new.Time_to_generate_coverage = 31 + " seconds";
                            drawCoverage(data, tx_id, band, flag, info);
                        }
                    }else if(checkApiCountNew == 100){
                        clearInterval(checkTxStatusIntervalNew);
                        checkApiCountNew = 0;
                        newAjaxFlag = false;
                    }
                    if(existingAjaxFlag == false && newAjaxFlag == false){
                        $(".leaflet-popup-content select").parents('.leaflet-popup-content').find('.editTxPopup').attr('disabled', false)
                        generateCompareGrid();
                        $("#loadingIcon").hide();
                        $("#loadingTxt").hide();
                        // closeEditTxPopup();
                    }
                }
            });
        }, 3000);
    }else{
        checkTxStatusIntervalExisting = setInterval(function(){
            var json = {};
            json.request_id = requestId;
            json.threshold = 133;
            $.ajax({
                url: '/uuigui/uui/eapp/atoll_pg/checkTransmitterStatus',
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(json),
                success: function (data) {
                    data = JSON.parse(data);
                    checkApiCountExisting++;
                    if(data && data.meta && data.meta.status == 'ok'){
                        clearInterval(checkTxStatusIntervalExisting);
                        existingAjaxFlag = false;
                        checkApiCountExisting = 0;
                        if(data.request_obj){
                            var d = new Date();
                            var difference = (d - totalResponseSecondsExisting) / 1000;
                            // compareData.current.Time_to_generate_coverage = Number(difference).toFixed() + " seconds";
                            compareData.current.Time_to_generate_coverage = 28 + " seconds";
                            drawCoverage(data, tx_id, band, flag, info);
                        }
                    }else if(checkApiCountExisting == 100){
                        clearInterval(checkTxStatusIntervalExisting);
                        checkApiCountExisting = 0;
                        existingAjaxFlag = false;
                    }
                    if(existingAjaxFlag == false && newAjaxFlag == false){
                        $(".leaflet-popup-content select").parents('.leaflet-popup-content').find('.editTxPopup').attr('disabled', false)
                        generateCompareGrid();
                        $("#loadingIcon").hide();
                        $("#loadingTxt").hide();
                        // closeEditTxPopup();
                    }
                }
            });
        }, 3000);
    }
}

function submitTransmitterData(json, flag){
    // close
    closeEditTxPopup();
    $.ajax({
        url: '/uuigui/uui/eapp/atoll_pg/submitTransmitterData',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(json),
        success: function (data) {
            data = JSON.parse(data);
            if(data && data.request_obj && data.request_obj[0] && data.request_obj[0].request_id){
                var json1 = {};
                var requestId = data.request_obj[0].request_id;
                json1.request_id = requestId;
                json1.threshold = 133;
                $("#loadingIcon").show();
                $("#loadingTxt").show();
                if(flag == "new"){
                    newAjaxFlag = true;
                    checkApiCountNew = 0;
                    $(".leaflet-popup-content select").parents('.leaflet-popup-content').find('.editTxPopup').attr('disabled', true)
                }else{
                    existingAjaxFlag = true;
                    checkApiCountExisting = 0;
                    $(".leaflet-popup-content select").parents('.leaflet-popup-content').find('.editTxPopup').attr('disabled', true)
                }
                $.ajax({
                    url: '/uuigui/uui/eapp/atoll_pg/checkTransmitterStatus',
                    type: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify(json1),
                    success: function (data) {
                        data = JSON.parse(data);
                        var info = {};
                        info.tx_id = json.tx_id;
                        info.threshold = 133;
                        info.azimut = json.modified_attributes.azimut;
                        info.tilt = json.modified_attributes.tilt;
                        if(data && data.meta && data.meta.status == 'ok'){
                            if(flag == "new"){
                                if(checkTxStatusIntervalNew){
                                    clearInterval(checkTxStatusIntervalNew);
                                    newAjaxFlag = false;
                                }
                            }else{
                                if(checkTxStatusIntervalExisting){
                                    clearInterval(checkTxStatusIntervalExisting);
                                    existingAjaxFlag = false;
                                }
                            }
                            if(data.request_obj){
                                var d = new Date();
                                if(flag == "new"){
                                    var difference = (d - totalResponseSecondsNew) / 1000;
                                    // compareData.new.Time_to_generate_coverage = Number(difference).toFixed() + " seconds";
                                    compareData.new.Time_to_generate_coverage = 31 + " seconds";
                                }else{
                                    var difference = (d - totalResponseSecondsExisting) / 1000;
                                    // compareData.current.Time_to_generate_coverage = Number(difference).toFixed() + " seconds";
                                    compareData.current.Time_to_generate_coverage = 28 + " seconds";
                                }
                                drawCoverage(data, json.tx_id, $(".leaflet-popup-content select").val()[0], flag, info);
                            }
                            if(existingAjaxFlag == false && newAjaxFlag == false){
                                $(".leaflet-popup-content select").parents('.leaflet-popup-content').find('.editTxPopup').attr('disabled', false)
                                generateCompareGrid();
                                $("#loadingIcon").hide();
                                $("#loadingTxt").hide();
                            }
                            // closeEditTxPopup();
                           // $('#legendbar').show();
                        }else{
                            checkTransmitterStatus(requestId, json.tx_id, $(".leaflet-popup-content select").val()[0], flag, info);
                            
                        }
                    }
                });
            }
        }
    });
}

function generateCompareGrid(){
    $('#txGridBox').removeClass("col-sm-12").addClass("col-sm-6");
    $('#compareTxGridBox').show();
    var rawData = [], data = [], model = {}, length, dataLength, propertiesLength;
    rawData.push(compareData.current);
    rawData.push(compareData.new);

    dataLength = rawData.length;
    propertiesLength = Object.keys(rawData[0]).length;

    for(var i=0; i <propertiesLength; i+=1){
        data[i] = {};
        for(var j =0; j < dataLength; j+=1 ){
            var currentItem = rawData[j]
            var property = Object.keys(currentItem)[i];
            if(j === 0){
                data[i]["Comparison"] = property;
            }
            data[i][currentItem.columnName] = currentItem[property]
        }
    }
    var grid = $("#compareTxGrid").data("kendoGrid");
    if(grid){
        grid.destroy();
    }
    $("#compareTxGrid").kendoGrid({
        dataSource: {
            data: data,
            pageSize: 20,
        },
        scrollable:true,
        height: gridHeight,
        dataBound: compareTxDataBound,
    });
}
function compareTxDataBound(){
    var grid = $('#compareTxGrid').data('kendoGrid');
    var items = grid.dataSource.view();
    var uid = "";
    for (var i = 0; i < items.length; i++) {
        if (items[i].Comparison == "columnName") {
            uid = items[i].uid
        }
    }
    if(uid != ""){
        $("tr[data-uid='" + uid + "']").remove()
    }
}

function fullMap(e){
    currentViewModel = "map-only";
    $("#map_split_container").css("height", "calc(100vh - 32px)");
    $("#site_split_container").css("height", "0vh");
    setTimeout(function () {
        updateLayout();
        t._map.invalidateSize(true);
    }, 0);
    $('.leaflet-control-container').find('.leaflet-bar').css('zoom','1');
    $('#mapContainer div.dash3-0-split-widget').css({'background-image': 'url(' + wo_split + ')'});
    $('#mapContainer div.dash3-0-map-widget').css({'background-image': 'url(' + map + ')'});
    $('#mapContainer div.dash3-0-tabular-widget').css({'background-image': 'url(' + wo_tab + ')'});
    // $('#legendbar').css("top", "calc(98%)");
}

function splitView(e){
    currentViewModel = "map-and-grid";
    $("#map_split_container").css("height", "calc(50vh - 16px)");
    $("#site_split_container").css("height", "calc(50vh - 16px)");
    setTimeout(function () {
        updateLayout();
    }, 0);
    if(window.innerHeight < 800){
        $('.leaflet-control-container').find('.leaflet-bar').css('zoom','0.65');
    }else{
        $('.leaflet-control-container').find('.leaflet-bar').css('zoom','1');
    }
    $('#mapContainer div.dash3-0-split-widget').css({'background-image': 'url(' + split + ')'});
    $('#mapContainer div.dash3-0-map-widget').css({'background-image': 'url(' + wo_map + ')'});
    $('#mapContainer div.dash3-0-tabular-widget').css({'background-image': 'url(' + wo_tab + ')'});
    // $('#legendbar').css("top", "calc(50%)");
}


function updateLayout() {
    setTimeout(function () {
        setGridHeight($("#siteGrid"));
        setGridHeight($("#compareTxGrid"));
        t.updateSize();
    }, 250);
    var width = $(window).width();
    $('#mapContainer').css("width", (width+2) + "px");
}

function setGridHeight(el) {
    $(el).css({ height: "auto" });
    var ch = $("#site_split_container").height();
    var gh = $(el).height();
    var d = gh - ch;
    //
    if (d < 0) { d = -d; }
    $(el).find(".k-grid-content").first().height(d);

    var toolbar_h = $(el).find(".k-grid-toolbar").height();
    var header_h = $(el).find(".k-grid-header").height();
    var footer_h = $(el).find(".k-grid-pager").height();

    $(el).find(".k-grid-content").first().height(ch - toolbar_h - header_h - footer_h - 20);
}              