var sitesZoomLevel = 11;
var loadedArea = {};
var loadedSolutionArea = [];


function openPopup() {
    if (viewType == "CoverageView") {
        $("#layerWindowLeft").addClass("singleViewLayer");
    } else {
        $("#layerWindowLeft").removeClass("singleViewLayer");
    }
    $("#layerWindowLeft").show();
    openLayerArea();
    setTimeout(function() {
        var selectedNodes = $("#layer-list-left").jstree('get_selected', true);
        var siteFilterSelected = false;
        for (index in selectedNodes){
            if (selectedNodes[index].id && selectedNodes[index].id.indexOf("sites") >= 0)
                siteFilterSelected = true;
        }
        if (!siteFilterSelected) $("#layer-list-left").jstree('select_node', 'sitesView');
    }, 500);
}
function openLayerArea() {
    openLayers();
    $('.dropdown-content').hide();
    $(".layer-reset-button").off('click');
    $(".layer-reset-button").on('click', function (e) {
        
        treeNodes = changeOrder(treeNodes);
        $("#layer-list-left").jstree('deselect_all');
        showHideFilteredArea();
        // remove wave polygon
        if (waveKml.length) {
            for (var i in waveKml) leaf.removeLayer(waveKml[i]);
        }
        $("#layer-list-left").jstree('close_all');
        const tree = $("#layer-list-left").jstree(true);
        tree.settings.core.data = treeNodes.map(_.unary(formatLayer));
        setTimeout(function(){
            tree.refresh(false);
        }, 500);
        for(var service in tileOpacities){
            var layer = tileLayers.get(service);
            if (layer) {
                tileOpacities[service] = 0.7;
                layer.setOpacity(0.7);
            }
        }
        saveToHistory("layer", []);
        saveToHistory("layerOrder", []);
        sitesFlag = false;
    });
    solutionDataFromHistory = [];
    solutionSarfDataFromHistory = [];
}

function openLayers() {
    if(tileLayersInitialized){
        return;
    }
    setMarketStyle();
    $(".popup-close-button").on('click', function (e) {
        $(this).closest('.toolWindow').hide();
    });
    selNodes = $("#layer-list-left").jstree(true).get_selected(true);
		 return $.get('http://nj51uuivqa2v.nss.vzwnet.com:7003/uuigui/uui/eapp/planning_pg/mapLayersProxy')
		 .then(function loadJSTree(response) {
			// Find the tree
			// response = layersData;
			const tree = $("#layer-list-left").jstree(true);
			if(response){
				response.find(layer => layer.name == "Solutions").children = [];
				response.find(layer => layer.name == "Sites").children = [];
				_.remove(response, layer => layer.name == "Sites Old" || layer.name == "Solutions Old");
				// change order of layer based on ui-setting
				response = changeOrder(response, null);
				// var hqIndex = _.findIndex(response, { "name": 'HQ Wave Polygon' });
				// if(hqIndex >= 0){
				//     response[hqIndex].children = wavePolygonList;
				// }
			};
			treeNodes = response;
			// Format the response, and set it as the underlying tree data
			tree.settings.core.data = response.map(_.unary(formatLayer));
			// Force refresh the tree
			tree.refresh(false, true);

			// Add the tooltips
			$("#layer-list-left").popover({
                selector: ".layer-item-text",
                content() {
                    const node = $("#layer-list-left").jstree(true).get_node($(this).closest(".jstree-node"));
                    return node.original.description;
                },
                html: true,
                trigger: "hover",
                container: "#mainContainer",
                template: "<div class='popover' style='z-index:2000;' role='tooltip'><div class='arrow'></div><div class='popover-content layer-popover'></div></div>",
			})
			
			// const filterGroups = [
			// 	{ id: "solutions", filters: solutionFilters },
			// 	{ id: "sites", filters: siteFilters },
			// 	{ id: "solutionSarf", filters: solutionSARFFilters },
			// ];

			// filterGroups.forEach(function createFilterPopup(filterGroup) {
			// 	var name = _.capitalize(filterGroup.id);
			// 	if(filterGroup.id == "solutionSarf"){
			// 		name = "Solution SARF"
			// 	}
			// 	const title = $("<div>")
			// 	.css("display", "flex")
			// 	.append($("<h4 style='margin-top:-5px;margin-bottom:0px;'>").text(`${name} Filters`))
			// 	.append($("<span>").css("flex", "auto"))
			// 	.append($("<a>").addClass("popup-close-button").css("outline", "none").css("cursor","pointer").text("x").click(() => tooltip.hide()));
			// 	//.append($("<button>").addClass("btn btn-sm btn-primary applybtn layerpopupbtn").text("Apply"));
			// 	//.append($("<button>").addClass("btn btn-sm btn-default").text("Close").click(() => tooltip.hide()));
	
			// 	var tooltip = $("<div>")
			// 	.attr("id", `filter-window-${filterGroup.id}`)
			// 	.addClass("toolWindow filter-window")
			// 	.append(title)
			// 	.appendTo("#mainContainer");
				
			// 	filterGroup.filters.forEach(function createMultiSelects(filter) {
			// 	const options = _.map(filter.options, (selected, key) => $("<option>").text(key).attr({ selected }));
			// 	const select = $("<select>")
			// 			.data("name", filter.name)
			// 			.attr("name", filter.name)
			// 			.attr("multiple", true)
			// 			.append(options);
			// 		const label = $("<h5>").text(filter.name);
			// 		const inputGroup = $("<div>").append(label, select);
			// 		$(inputGroup)
			// 		.appendTo(tooltip)
			// 		.find("select[multiple]")
			// 		.change(function updateFilter() {
			// 			filter.options = _($(this).find("option").get())
			// 			.map(option => [option.value, option.selected])
			// 			.fromPairs()
			// 			.value();
			// 		})
			// 		.multiselect({ 
			// 			buttonClass: "btn btn-default whitebg btn-sm",  
			// 			includeSelectAllOption: filter.key.includes("InitiativeType")? true: false,
			// 			selectAllText: filter.key.includes("InitiativeType")? 'Select All' : ''
			// 		})
			// 	});
			// 	const actionBtn = $("<div>")
			// 		.append($("<button>").addClass("btn btn-sm btn-primary applybtn layerpopupbtn").text("Apply"))
			// 		.append($("<button>").addClass("btn btn-sm btn-default layerpopupbtn").text("Close").click(() => tooltip.hide()));            
			// 	$(actionBtn).appendTo(tooltip);
				
			// 	$('#filter-window-' + filterGroup.id).find('.applybtn').click(function(e){
			// 		if(filterGroup.id == "solutions"){
			// 			// solution
			// 			var hasFilter = false;
			// 			let filterMap = {};
			// 			for (const filter of solutionFilters) {
			// 				filterMap[filter.key] = [];
			// 				for (const prop in filter.options) {
			// 					if (filter.options[prop]) {
			// 						filterMap[filter.key].push(prop);
			// 						hasFilter = true;
			// 					}
			// 				}
			// 			}
			// 			if(!_.isEqual(_.sortBy(oldSolutionSelected), _.sortBy(filterMap))){
			// 				if(displaySolution){
			// 					getAreaInBounds(undefined, "solution", true, undefined, true);
			// 					oldSolutionSelected = filterMap;
			// 				}
			// 				saveToHistory("projSolutionFilter", filterMap);
			// 			}
			// 			if(hasFilter == true){
			// 				$('.solutionFilterBtn').css("color", "rgb(38, 172, 253)");
			// 			}else{
			// 				$('.solutionFilterBtn').css("color", "#37314f");
			// 			}
			// 		}else if(filterGroup.id == "solutionSarf"){
			// 			let sarffilterMap = {};
			// 			var hasFilter = false;
			// 			for (const filter of solutionSARFFilters) {
			// 				sarffilterMap[filter.key] = [];
			// 				for (const prop in filter.options) {
			// 					if (filter.options[prop]) {
			// 						sarffilterMap[filter.key].push(prop);
			// 						hasFilter = true;
			// 					}
			// 				}
			// 			}
			// 			if(!_.isEqual(_.sortBy(oldSarfSolutionSelected), _.sortBy(sarffilterMap))){
			// 				if(displaySarfSolution){
			// 					getAreaInBounds(undefined, "solutionSARF", true, undefined, true);
			// 					oldSarfSolutionSelected = sarffilterMap;
			// 				}
			// 				saveToHistory("sarfSolutionFilter", sarffilterMap);
			// 			}
			// 			if(hasFilter == true){
			// 				$('.sarfSolutionFilterBtn').css("color", "rgb(38, 172, 253)");
			// 			}else{
			// 				$('.sarfSolutionFilterBtn').css("color", "#37314f");
			// 			}
			// 		}else{
			// 			// site
			// 			filterSiteResultsAreaNew();
			// 		}
			// 	});
	
			// 	const observer = new MutationObserver(function onLayerMutate(mutationList) {
			// 	const shouldHide = _(mutationList)
			// 		.filter(["attributeName", "style"])
			// 		.some(["target.style.display", "none"]);
			// 	if (shouldHide) tooltip.hide();
			// 	});
	
			// 	observer.observe($("#layerWindowLeft").get(0), { attributes: true });
			// });

			// getHistory("vectorFilter").then(function drawMap(data){
			// 	if(data){  
			// 		if(!layerInfoFromUISetting.filters){
			// 			layerInfoFromUISetting.filters = {};
			// 		}
			// 		vectorFilters = data; 
			// 		layerInfoFromUISetting.filters = data;
			// 	}
			// });
	
			// getHistory("projSolutionFilter").then(function drawMap(data){
			// 	if(data){  
			// 		$.each(data, function(i, v){
			// 			var obj = _.find(solutionFilters, { "key":i});
			// 			var name = obj? obj.name : undefined;
			// 			if(obj && v){
			// 				$.each(v, function(ind, val){
			// 					obj['options'][val] = true;
			// 					projSolutionFilterFlag = true;
			// 				})
			// 			}
			// 			if(name){
			// 				$('#filter-window-solutions').find('select[name="' + name + '"]').val(v).multiselect('refresh');
			// 			}
			// 		})  
			// 	}
			// });
			// getHistory("sarfSolutionFilter").then(function drawMap(data){
			// 	if(data){  
			// 		$.each(data, function(i, v){
			// 			var obj = _.find(solutionSARFFilters, { "key":i});
			// 			var name = obj? obj.name : undefined;
			// 			if(obj && v){
			// 				$.each(v, function(ind, val){
			// 					obj['options'][val] = true;
			// 					sarfSolutionFilterFlag = true;
			// 				})
			// 			}
			// 			if(name){
			// 				$('#filter-window-solutionSarf').find('select[name="' + name + '"]').val(v).multiselect('refresh');
			// 			}
			// 		})
			// 	}
			// });
			// getHistory("siteFilter").then(function drawMap(data){
			// 	if(data){
			// 		$.each(data, function(i, v){
			// 			var obj = _.find(siteFilters, { "key":i});
			// 			var name = obj? obj.name : undefined;
			// 			if(i == "is5g"){
			// 				var newVal = [];
			// 				$.each(v, function(ind, val){
			// 					if(val == 1){
			// 						newVal.push("5G");
			// 					}else if(val == 0){
			// 						newVal.push("4G");
			// 					}
			// 				})
			// 				v = newVal;
			// 			}
			// 			if(obj && v){
			// 				$.each(v, function(ind, val){
			// 					obj['options'][val] = true;
			// 					siteFilterFlag = true;
			// 				})
			// 			}
			// 			if(name){
			// 				$('#filter-window-sites').find('select[name="' + name + '"]').val(v).multiselect('refresh');
			// 			}
			// 		})
			// 		// if(isSectorDetails == true){
			// 		// 	// only for sector details
			// 		// 	// load filter first, then get site info
			// 		// 	sitesFlag = true;
			// 		// 	let filterMap = {};
			// 		// 	for (const filter of siteFilters) {
			// 		// 		filterMap[filter.key] = [];
			// 		// 		for (const prop in filter.options) {
			// 		// 			if (filter.options[prop]) {
			// 		// 				if(filter.key == "is5g"){
			// 		// 					var k = "";
			// 		// 					if(prop == "4G"){
			// 		// 						k = 0;
			// 		// 					}else if(prop == "5G"){
			// 		// 						k = 1;
			// 		// 					}
			// 		// 					filterMap[filter.key].push(k);
			// 		// 				}else{
			// 		// 					filterMap[filter.key].push(prop);
			// 		// 				}
			// 		// 			}
			// 		// 		}
			// 		// 	}
			// 		// 	if (qareaId && qareaId != "undefined" && qareaId != "null") {
			// 		// 		oldSiteSelected = filterMap;
			// 		// 		currentAreaId = qareaId;
			// 		// 		searchAreaSites(qareaId, null, true, qsiteId);
			// 		// 	}else if(filterMap !== undefined && qareaId !== undefined && !_.isEqual(_.sortBy(oldSiteSelected), _.sortBy(filterMap))){
			// 		// 		oldSiteSelected = filterMap;
			// 		// 		currentAreaId = qareaId;
			// 		// 		turnOffSites();
			// 		// 		searchAreaSites(qareaId, filterMap, true, qsiteId);
			// 		// 	}
			// 		// 	else if (qsiteId && qsiteId != "undefined" && qsiteId != "null") {
			// 		// 		searchSiteId(qsiteId, true);
			// 		// 	}
			// 		// }
			// 	}
			// });
			// popup.on("click", ".js-layer-filter", function showFilters() {
			// $("[id|=filter-window]").hide();
			// if($(this).data("name") == "solution sarf"){
			// 	$('#filter-window-solutionSarf').show();
			// }else{
			// 	//$(`#filter-window-${$(this).data("name")}`).show();
			// 	var name = $(this).data("name")? $(this).data("name").replaceAll(" ","").toLowerCase() : $(this).data("name");
			// 	if($('#filter-window-' + name) && $('#filter-window-' + name).length > 0){
			// 		$('#filter-window-' + name).show();
			// 	}else{
			// 		var obj = findLayerObj($(this).data("name"), treeNodes);
			// 		if(obj){
			// 			buildFilterPopup(obj);
			// 		}
			// 	}
			// }
			// });  
			// popup.on("click", ".marketBoundaryDownloadBtn", function downloadkml(e) {
			// 	var node = popup.jstree(true).get_node($(e.target).attr("id"));
			// 	var lteMarkets = [];
			// 	//$("#layer-spinner").show();
			// 	if(node.children_d && node.children_d.length){
			// 		for(let i of node.children_d){
			// 			let childNode = popup.jstree(true).get_node(i);
			// 			if(popup.jstree(true).is_leaf(i) && childNode.state.selected){
			// 				lteMarkets.push(childNode.original.name);
			// 			}
			// 		}
			// 	}
			// 	if(!lteMarkets.length){
			// 		if(!popup.jstree(true).is_leaf(node)){
			// 			lteMarkets = getMarketsList(node.original, node.children);
			// 		}else{
			// 			lteMarkets.push(node.original.name);
			// 		}
			// 	} 
			// 	e.preventDefault();
			// 	getPolygonDetailsByMarket(lteMarkets, node.original.name, popup.jstree(true).is_parent(node));
				
			// });
			// $(".fa-spinner").hide();
		// }, function handleError(error) {
		// 	console.error("Something went wrong with getting the layers", error);
		// });
	});
}
function setMarketStyle(name,color,opacity){
	styleObj={
        weight: 2,
        color: color ? color : 'blue',
        opacity: 1,
        fill: true,
        fillOpacity: opacity?opacity:0.33,
        fillColor: color ? color : 'blue'
    };
    // if(marketLayers.has(Number(name)))
    // 	marketLayers.get(Number(name)).setStyle(styleObj);
}
function initiateJStree() {
	$("#layer-list-left").jstree({
        'core': {
            "check_callback": true,
            "themes": {
                "responsive": false
            }
        },
        "ui": {
            "select_limit": 1,
        },
        "plugins": ["themes", "wholerow", "types", "checkbox", "ui", "crrm", "search", "contextmenu", "conditionalselect"],
        "checkbox": {
            "three_state": true,
            "real_checkboxes": false,
            "tie_selection": true
        },
        "search": {
            "case_insensitive": true,
            "show_only_matches": true,
            "show_only_matches_children": true
        },
        conditionalselect: function(_node, event) {
          const $checkbox = $(event.target).closest(".jstree-checkbox");
          return $checkbox.length != 0;
        }
    }).bind('ready.jstree', function (e, data) {
        // Future Use Bind Event

    }).on('refresh.jstree', function (_event, data) {
        
		$.each(layerInfoFromUISetting, function(i,v){
			$("#layer-list-left").jstree('select_node', v.id);
		});
		selectedLayerBasedonUISetting = true;
    
    }).on('open_node.jstree', function (e, data) {
        setupOpacitySliders(data.instance, data.node);
    }).on("select_node.jstree", function (e, data) {
		if(e.target.closest("#layerWindowLeft")) {
			mapName = leafCompare;
		} else  {
			mapName = leaf;
		}
        $("#layer-list-left").jstree().open_node(data.node.id);
        if(data.node.original.name == 'HQ 5G Polygon'){
            $("#loadingIcon").show();
            $("#loadingTxt").show();
            if(!wavePolygonList || wavePolygonList.length == 0){
                setTimeout(function(){ getWavePolygonsList(); }, 100);
            }else{
                setTimeout(function(){ drawWavePolygonsFromPanel(); }, 100);                
            }
        }else if(data.node.original.name == 'Solutions'){
            solutionViewWithArea("solution");
        }else if(data.node.original.name == 'Solution SARF'){
            solutionViewWithArea("solutionSARF");
        }else if(data.node.original.name == 'Partial Economic Areas (PEA)'){
            $("#loadingIcon").show();
            $("#loadingTxt").show();
            if(!peaPolygons || jQuery.isEmptyObject(peaPolygons)){
                setTimeout(function(){ getPEAShapes(); }, 100);
            }else{
                setTimeout(function(){ drawPEAPolygonsFromPanel(); }, 100);                
            }
        }
        if(data.node.original.path.includes("Market Boundaries")){
            selectedNodes = $("#layer-list-left").jstree(true).get_selected();
            let marketIds={};
            for(let i of selectedNodes){
  				let childNode = $("#layer-list-left").jstree(true).get_node(i);
  				if(childNode && childNode.original && childNode.original.name
  						&& childNode.original.color ){
  					if(childNode.original.name =="0"||Number(childNode.original.name)){
  						marketIds[Number(childNode.original.name)]={};
  						marketIds[Number(childNode.original.name)].color=childNode.original.color;
  						marketIds[Number(childNode.original.name)].opacity=
  							(marketOpacities[childNode.original.path] && Number(marketOpacities[childNode.original.path]))?
  									Number(marketOpacities[childNode.original.path]):0.33;
  					}
  				}
            }
            addMarketGeoJson(marketIds);
        }
        // if(!filterInfo[data.node.original.name]){
        //     filterInfo[data.node.original.name] = {};
        // }
        // filterInfo[data.node.original.name].filter = [];
        // if(layerInfoFromUISetting && layerInfoFromUISetting.filters && layerInfoFromUISetting.filters[data.node.original.name]){
        //     $.each(layerInfoFromUISetting.filters[data.node.original.name], function(i, v){
        //         var obj = {};
        //         obj = v;
        //         filterInfo[data.node.original.name].filter.push(obj);
        //     });
        // }
        // filterInfo[data.node.original.name].show = true;
        // if(data.node.original.layerType == "geojson"){
        //     getGeojsonInfo(filterInfo[data.node.original.name].filter, data.node.original, data.node.original.name);
        // }
        
    }).on("deselect_node.jstree", function (e, data) {
		// Future Use Unselect Node Event
		if(e.target.closest("#layerWindowLeft")) {
			mapName = leafCompare;
		} else  {
			mapName = leaf;
		}
        if(data.node.original.name == 'HQ 5G Polygon'){
            if (waveKml.length) {
                for (var i in waveKml) leaf.removeLayer(waveKml[i]);
            }
        }else if(data.node.original.name == 'Solutions'){
            if($solutionAjax){
                $.when($solutionAjax).done(function(){
                    cancelSolutionView();
                })
            }
        }else if(data.node.original.name == 'Solution SARF'){
            if($sarfSolutionAjax){
                $.when($sarfSolutionAjax).done(function(){
                    cancelSARFSolutionView();
                })
            }
        } else if(data.node.original.name == 'Partial Economic Areas (PEA)'){            
            if (peapol.length) {
                for (var i in peapol) leaf.removeLayer(peapol[i]);
                peapol.length=0;
            }
        }
    }).on("move_node.jstree", function(_event, data) {
      const jstree = data.instance;

      setupOpacitySliders(jstree, jstree.get_parent(data.node));

      // Builds a quick tree of all the nodes
      function buildTree(node) {
        if (node.children.length == 0) {
          return node.id;
        } else {
          return node.children.map(function(id) { return jstree.get_node(id); }).map(buildTree);
        }
      }
      // not sure if "#" is always guarenteed to be the root
      const root = jstree.get_node("#");
      // This fun little section gets all the nodes in a "tree" (nested arrays) in the
      // order that they're displayed, then flattens them out into an array,
      // then maps them to their services, removes the nullish values,
      // so we can set the z-indices for the layers in the reverse order that they're displayed
      _(buildTree(root))
        .flattenDeep()
        .map(function(id) { return jstree.get_node(id); })
        .map(function(node) { return node.original.service; })
        .compact()
        .forEach(function(service, idx, arr) {
          const layer = tileLayers.get(service);
          if (layer) layer.setZIndex(arr.length - idx);
        });
    }).on("click", "button[data-dir]", function reorderLayers(event) {
      const jstree = $("#layer-list-left").jstree(true);
      const dir = $(event.target).closest("button[data-dir]").data("dir");
      const $node = $(event.target).closest(".jstree-node");
      const node = jstree.get_node($node);
      const index = jstree.get_node(jstree.get_parent(node)).children.indexOf(node.id);
      const newIndex = dir == "down" ? index + 2 : index - 1;
      if(node.original.path.includes("Market Boundaries")&& marketLayers.has(Number(node.original.name))){
    	  if(dir=="down"){
    		  marketLayers.get(Number(node.original.name)).bringToBack()
    	  }else{
    		  marketLayers.get(Number(node.original.name)).bringToFront()
    	  }
      }
      jstree.move_node(node, jstree.get_parent(node), Math.max(newIndex, 0));
      getLayerOrder($("#layer-list-left"));
    }).on("input", "input[type=range][data-service]", function(event) {
      const service = $(event.target).data("service");
      const layer = tileLayers.get(service);
      var layerType = $(event.target).attr('layerType');
      var name = $(this).parent('.layer-item').attr('layer-name');
      if($(event.target).attr('path')){
      	$(".layer-item .opacity-market-slider").each(function(a,val){
	         if($(val).attr("path") && $(val).attr("path").includes(event.target.attributes["path"].value)){
	        	 $(val).val(event.target.value);
	        	 marketOpacities[$(val).attr("path")] = event.target.value;
	        	 setMarketStyle($(val).attr("name"),$(val).attr("color"),event.target.value);
	         }
	     });
      	updateMarketOpacity(event, $("#layer-list-left"));
      }
      if(layerType == "geojson"){
          const layer = polygonsInfo[name];
          if (layer) {
              $.each(layer, function(i, v){
                  for(var k in v._layers){
                      v._layers[k].setStyle({opacity: event.target.value, fillOpacity: event.target.value});
                  }
              })
              tileOpacities[service] = event.target.value;
              
          }
      }else if(layerType == "tile"){
          const layer = tileLayers.get(service);
          if (layer) {
            tileOpacities[service] = event.target.value;
            layer.setOpacity(event.target.value);
          }
      }else if (layerType == "vector") {
          const layer = tileLayers.get(service);
          if (layer) {
              var v = vectorLayers[service];
              v.setOpacity(event.target.value);
              var temp = !!layerInfoFromUISetting.filters && layerInfoFromUISetting.filters[name] ? layerInfoFromUISetting.filters[name] : {};
              if (temp) {
                  var o = {};
                  o.service = service;
                  filterVectors(temp, o, name);
              }
          }
      }
    }).on("input", "input[type=range][data-service]",  _.debounce(function(event) {
        saveToHistory("OpacityOfLayer", tileOpacities);
    }, 200, { 'maxWait': 1500 })).on("changed.jstree", function showHideLayers(_event, data) {
        const jstree = data.instance;

        // Hide unselected layers
        
        _(jstree.get_node("#").children_d)
        .map(id => jstree.get_node(id))
        .filter(node => jstree.is_leaf(node))
        .filter(node => !jstree.is_selected(node))
        .map(node => tileLayers.get(node.original.service))
        .compact()
        .forEach(layer => layer.removeFrom(leafCompare));
    
        _(jstree.get_node("#").children_d)
        .map(id => jstree.get_node(id))
        .filter(node => jstree.is_leaf(node))
        .filter(node => !jstree.is_selected(node))
        .map(node => tileLayersRight.get(node.original.service))
        .compact()
        .forEach(layer => layer.removeFrom(leaf));
        
        
        
        // Hide unselected markets
        _(jstree.get_node("#").children_d)
        .map(id => jstree.get_node(id))
        .filter(node => jstree.is_leaf(node))
        .filter(node => !jstree.is_selected(node))
        .map(node => marketLayers.get(Number(node.original.name)))
        .compact()
        .forEach(layer => layer.removeFrom(leafCompare));
    
        _(jstree.get_node("#").children_d)
        .map(id => jstree.get_node(id))
        .filter(node => jstree.is_leaf(node))
        .filter(node => !jstree.is_selected(node))
        .map(node => marketLayersRight.get(Number(node.original.name)))
        .compact()
        .forEach(layer => layer.removeFrom(leaf));
        
        
        _(jstree.get_node("#").children_d)
        .map(id => jstree.get_node(id))
        .filter(node => jstree.is_leaf(node))
        .filter(node => !jstree.is_selected(node))
        .map(node => node.original.name)
        .compact()
        .forEach(layer => removePolygons(layer, leafCompare));
    
        _(jstree.get_node("#").children_d)
        .map(id => jstree.get_node(id))
        .filter(node => jstree.is_leaf(node))
        .filter(node => !jstree.is_selected(node))
        .map(node => node.original.name)
        .compact()
        .forEach(layer => removePolygons(layer, leaf));
        
        
        //for vectors, temporary
        _(jstree.get_node("#").children_d)
        .map(id => jstree.get_node(id))
        .filter(node => !jstree.is_selected(node))
        .map(node => vectorLayers[node.original.service])
        .compact()
        .forEach(layer => layer.removeFrom(leafCompare));
    
        _(jstree.get_node("#").children_d)
        .map(id => jstree.get_node(id))
        .filter(node => !jstree.is_selected(node))
        .map(node => vectorLayersRight[node.original.service])
        .compact()
        .forEach(layer => layer.removeFrom(leaf));
        

        const selectedLeafNodes = _(data.selected)
        .filter(node => jstree.is_leaf(node))
        .map(id => jstree.get_node(id));
        
        // Show all selected tile layers
        
        selectedLeafNodes
        .map(node => node.original.layerType == 'tile'? node.original.service : undefined)
        .map(service => tileLayersRight.get(service))
        .compact()
        .forEach(layer => layer.addTo(leaf));
    
        selectedLeafNodes
        .map(node => node.original.layerType == 'tile'? node.original.service : undefined)
        .map(service => tileLayers.get(service))
        .compact()
        .forEach(layer => layer.addTo(leafCompare));
        
        
        //show all selected market Layers
        _(data.selected)
        .filter(node => jstree.is_leaf(node))
        .map(id => jstree.get_node(id))
        .map(node => marketLayers.get(Number(node.original.name)) && node.original.name? marketLayers.get(Number(node.original.name)): undefined)
        .compact()
        .forEach(layer => layer.addTo(leafCompare));
    
        _(data.selected)
        .filter(node => jstree.is_leaf(node))
        .map(id => jstree.get_node(id))
        .map(node => marketLayersRight.get(Number(node.original.name)) && node.original.name? marketLayersRight.get(Number(node.original.name)): undefined)
        .compact()
        .forEach(layer => layer.addTo(leaf));
        
        
        //Show all selected vector layers
        selectedLeafNodes
        .map(id => jstree.get_node(id))
        .map(node => node.original.layerType == 'vector' ? node.original : undefined)
        .compact()
        .forEach((layer) => addVectorLayerRight(layer));

        selectedLeafNodes
        .map(id => jstree.get_node(id))
        .map(node => node.original.layerType == 'vector' ? node.original : undefined)
        .compact()
        .forEach((layer) => addVectorLayer(layer));

        // Show layer spinner till all tile layers load
        //$("#layer-spinner").show();
        const promises = selectedLeafNodes
        .map(node => tileLayers.get(node.original.service))
        .compact()
        .map(layer => new Promise(resolve => layer.once("load", resolve)));
        Promise.all(promises).then(() => $("#layer-spinner").hide());
        var dummyArray = selectedLeafNodes.some(["original.path", "#Sites"]) ? ['site'] : [];
        //sitesView(dummyArray);


        
        let sel = $("#layer-list-left").jstree(true).get_selected(true);

        if ($("#layer-list-left").jstree("is_loaded")) {
            $('a.leaflet-control-dropdown-layer').css({"color": sel.length != 0 ? "#26acfd" : "black" });
        }
        // Hard-Coded Filters
        let hardFilters = {}, base, key;
        let hardParents = ["Sites"];
        for(const parent of hardParents){
            if(sel && sel.length >0){
                $.each(sel, function(idx, val){
                    if(!hardFilters[parent]){
                        hardFilters[parent] = [];
                    }
                    if(val.original.path.startsWith("#" + parent)){
                        hardFilters[parent].push(val);
                    }
                });
            }
        }
		hardFilters.Sites = hardFilters.Sites? hardFilters.Sites : [];
		
		// if(rloplLayerGroup.getBounds().isValid()){
		//     leaf.fitBounds(rloplLayerGroup.getBounds());
		// }else{
		// 	leaf.fitBounds(intialBounds);
		// }
        
        // $("a.leaflet-control-dropdown-layer").css({ color: selectedLeafNodes.size() != 0 ? "#26acfd": "black" });
        // if(selectedLeafNodes.size() != 0){
        //     mapName.off("moveend", getAreaInBounds);
        //     mapName.off("moveend", getStateCountyBounds);
        //     mapName.on("moveend", getAreaInBounds);
        //     mapName.on("moveend", getStateCountyBounds);
        // }
        return saveToHistory("layer", selectedLeafNodes.value()
        		.filter(node=>node.original && node.original.path ?!node.original.path.includes("Market Boundaries"):true)
        		);
    }).on("model.jstree", function parentOpacity(_event, data) {
        $(this).one("redraw.jstree", () => setupOpacitySliders(data.instance, data.parent));
    });
    openLayers();
}

function solutionViewWithArea(flag){
    if(flag){
        getAreaInBounds(undefined, flag,false);
    }else{
        getAreaInBounds(undefined, "solution",false);
        getAreaInBounds(undefined, "solutionSARF",false);
    }
}



function formatLayer(layer, path) {
    // Set Path
    styleObj[layer.name] = layer.style;
    let currentPath;
    if (!path){
        currentPath = "#" + layer.name;
    } else {
        currentPath = path + "." + layer.name;
    }
    // Parent
    const children = layer.children.map(function(child) {
        return formatLayer(child, currentPath);
    });
    const $container = $("<span>").addClass("layer-item").append(
      $("<span>").addClass("layer-item-text").text(layer.name)
    );
    if (children.length == 0) {
        if (layer.service != "placeholder" && layer.service != null) {
            if (currentPath.indexOf("Market Boundaries") == -1) {
                if (!tileLayers.has(layer.service) && (layer.layerType == "tile" || layer.layerType == "vector")) {
                    tileLayers.set(layer.service, L.tileLayer(layer.service, { opacity: 0.7, errorTileUrl: "" }));
                }
                if (!tileLayersRight.has(layer.service) && (layer.layerType == "tile" || layer.layerType == "vector")) {
                    tileLayersRight.set(layer.service, L.tileLayer(layer.service, { opacity: 0.7, errorTileUrl: "" }));
                }
                if (currentPath.indexOf("Morphology") == -1) {
                    $container.append(
                        $("<input>").attr({
                            class: "opacity-slider",
                            "data-service": layer.service,
                            "layerType": layer.layerType,
                            type: "range",
                            min: 0,
                            max: 1,
                            value: 0.7,
                            step: 0.01,
                        })
                    );
                }
            } else {
                if (!tileLayers.has(layer.service) && (layer.layerType == "tile" || layer.layerType == "vector")) {
                    tileLayers.set(layer.service, L.tileLayer(layer.service, { opacity: 0.33, errorTileUrl: errorTileUrl }));
                }
            }
        }
        $container
            .attr("layer-name", layer.name)
            .prepend(
                $("<i>")
                    .addClass("fas fa-circle layer-color")
                    // can't do .css() since it's getting turned into a string
                    .attr("style", "color: " + layer.color)
            );
    }
    const $directionalButton = $("<button>").addClass("fas btn-reorder");
    $container.append(
      $directionalButton.clone().addClass("fa-angle-up").attr("data-dir", "up"),
      $directionalButton.clone().addClass("fa-angle-down").attr("data-dir", "down"),
    );
    if (layer.name == "Solutions") {
        $container.append($("<button>").addClass("fas fa-filter btn-reorder solutionFilterBtn js-layer-filter").attr("data-name", _.lowerCase(layer.name)));
    } else if (layer.name == "Sites") {
        $container.append($("<button>").addClass("fas fa-filter btn-reorder siteFilterBtn js-layer-filter").attr("data-name", _.lowerCase(layer.name)));
    } else if (layer.name == "Solution SARF") {
        $container.append($("<button>").addClass("fas fa-filter btn-reorder sarfSolutionFilterBtn js-layer-filter").attr("data-name", _.lowerCase(layer.name)));
    }else if(layer.name == "Market Boundaries" || currentPath.indexOf("Market Boundaries") != -1){
    	let marketName = currentPath;
    	$container.append($("<button>").addClass("fas fa-download btn-reorder marketBoundaryDownloadBtn").attr({
    		"data-name": _.lowerCase(layer.name),
    		"id": layer.id
    	}));
    	$container.append(
		        $("<input>").attr({
		            class: "opacity-market-slider opacity-slider",
		            "data-service": layer.service,
		            "layerType": layer.layerType,
		            type: "range",
		            min: 0,
		            max: 1,
		            value: 0.33,
		            step: 0.01,
		            path: currentPath,
		            name: layer.name,
		            id: layer.id,
		            color:layer.color
		        })
		 );
    }
    if (layer.filterUrl) {
        var className = layer.name;
        $container.append($("<button>").addClass("fas fa-filter btn-reorder js-layer-filter " + className + "Filter").attr("data-name", _.lowerCase(layer.name)));
    }
    return _.assign(_.clone(layer), {
        state: { selected: false, opened: false },
        path: currentPath,
        children: children,
        text: $container.get(0).outerHTML,
    });
}
function changeOrder(data, orderData){
    var d = data;
    d.sort(function(a, b){
        if(orderData){
            return _.findIndex(orderData, ['id', a.id + ""]) - _.findIndex(orderData, ['id', b.id + ""]);
        }else{
            return Number(a.id) - Number(b.id);
        }
    });
    $.each(d, function(i,v){
        if(orderData){
            if(v.children && v.children.length > 1 && orderData[i] && orderData[i].children && orderData[i].children.length > 1){
                v.children = changeOrder(v.children, orderData[i].children);
            }
        }else{
            if(v.children && v.children.length > 1){
                v.children = changeOrder(v.children);
            }
        }
    });
    return d;
}
function getHistory(type) {
    var promise = $.Deferred();
    UiSettingsRetrieve("planning-map-search-history-" + type, function(result) {
        if(type == 'layer'){
            layerInfoFromUISetting = result? result : [];
            promise.resolve(result);
        }else if(type == 'transmitterFlag'){
            promise.resolve(result);
        }else if(type == 'layerOrder'){
            layerOrder = result? result : [];
        }else if(type == 'OpacityOfLayer'){
            if(result){
                tileOpacities = result;
            }
        }else if(type == 'projSolutionFilter'){
            promise.resolve(result);
        }else if(type == 'sarfSolutionFilter'){
            promise.resolve(result);
        }else if(type == 'siteFilter'){
            promise.resolve(result);
        }
        else if(type == 'vectorFilter'){
            promise.resolve(result);
        }
    });
    return promise;
}
function removePolygons(name, mapName) {
    if(polygonsInfo[name]){
        $.each(polygonsInfo[name], function(i, v){
            mapName.removeLayer(v);
        })
        delete polygonsInfo[name];
    }
}
function setupOpacitySliders(jstree, node) {
	const $node = jstree.get_node(node, true)

	// Set every element to not be draggable
	// Yes, I know this is overkill, but I can't figure
	// out a better way to do this
	$node.find("*").attr("draggable", false);

	// Since the jstree elements are dynamically recreated
	// everytime a node is opened, the opacity sliders will
	// be reset to their default.
	// So we need to find the current opacity for each layer
	// and set the range correctly
	$node
	  .find("input[type=range]")
	  .each(function(_index, element) {
		 if($(element).attr("path")){
				 let marketKeys = Object.keys(marketOpacities);
				 let matchedMarkets = marketKeys.filter((item)=>$(element).attr("path").includes(item));
				 if(matchedMarkets.length > 0)
					 $(element).val(marketOpacities[matchedMarkets[matchedMarkets.length-1]]);
				 else 
					 $(element).val(0.33);
		 }else {
			const value = tileOpacities[$(element).data("service")];
			$(element).val(value != null ? value : 0.7);
		 }
	  });
}
function updateMarketOpacity(){
	let node = $("#layer-list-left").jstree(true).get_node($(e.target).attr("id"));
	if(node.original && node.original.path.includes("Market Boundaries")){
			  if(node.children_d && node.children_d.length > 0){
				  for(let i of node.children_d){
					  let childNode = $("#layer-list-left").jstree(true).get_node(i);
					  if(childNode.original.path && childNode.original.name && childNode.original.color){
						  marketOpacities[childNode.original.path] = event.target.value;
						   setMarketStyle(childNode.original.name, childNode.original.color, e.target.value);
					   }
				  }
			  }
	 }
}
function getLayerOrder(){    
    var n = $("#layer-list-left").jstree(true).get_json('#', {flat:false})
    var order = retrieveLayer(n);
    saveToHistory("layerOrder", order);
}

function retrieveLayer(n){
    var array = [];
    if(n){
        $.each(n, function(i, v){
            var obj = {id: v.id};
            if(v.children && v.children.length > 0){
                obj.children = retrieveLayer(v.children);
            }
            array.push(obj);
        })
    }
    return array;
}
function saveToHistory(key, id) {
    if (id == null) return;
    var historyID = "planning-map-search-history-" + key;
    UiSettingsRetrieve(historyID, function saveHistory(oldHistory) {
        var newHistory = [];
        if(key == 'layer'){
            newHistory = id? id : [];
            layerInfoFromUISetting = id;
        }else if(key == 'layerOrder'){
            newHistory = id? id : [];
            layerOrder = id;
        }else if(key == 'OpacityOfLayer'){
            newHistory = id? id : [];
            layerOrder = id;
        }else if(key == 'transmitterFlag'){
            newHistory = id;
        }else if(key == 'projSolutionFilter'){
            newHistory = id;
        }else if(key == 'sarfSolutionFilter'){
            newHistory = id;
        }else if(key == 'siteFilter'){
            newHistory = id;
        }
        else if(key == 'vectorFilter'){
            newHistory = id;
        }
        
        UiSettingsSave(historyID, newHistory);
    });
}
function showHideFilteredArea(onlySites, onlySolutions, onlySarfSolutions) {
    
    if (onlySites === undefined){
        onlySites = false;
    }
    if (onlySolutions === undefined){
        onlySolutions = false;
    }
    if (onlySarfSolutions === undefined){
        onlySarfSolutions = false;
    }
    
    // Find Selected Layers
    let sel = $("#layer-list").jstree(true).get_selected(true);
    if(sel && sel.length > 0 ){
        if(solutionDataFromHistory){
            sel = sel.concat(solutionDataFromHistory);
        }
        if(solutionSarfDataFromHistory){
            sel = sel.concat(solutionSarfDataFromHistory);
        }
    }else if(solutionDataFromHistory && solutionDataFromHistory.length > 0){
        sel = solutionDataFromHistory;
        if(solutionSarfDataFromHistory){
            sel = sel.concat(solutionSarfDataFromHistory);
        }
    }else if(solutionSarfDataFromHistory && solutionSarfDataFromHistory.length > 0){
        sel = solutionSarfDataFromHistory;
    }
    if ($("#layer-list").jstree("is_loaded")) {
        $('a.leaflet-control-dropdown-layer').css({"color": sel.length != 0 ? "#26acfd" : "black" });
    }
    // Hard-Coded Filters
    let hardFilters = {}, base, key;
    let hardParents = ["Sites", "Solutions", "Solution SARF"];
    for(const parent of hardParents){
        if(sel && sel.length >0){
            $.each(sel, function(idx, val){
                if(!hardFilters[parent]){
                    hardFilters[parent] = [];
                }
                if(val.original.path.startsWith("#" + parent)){
                    hardFilters[parent].push(val);
                }
            });
        }
    }
    // save config in ui-setting
    // saveToHistory("layer", sel);

    if(onlySites){
        sitesView(hardFilters["Sites"]);
        return;
    }
    if(onlySolutions && onlySarfSolutions){
        getAreaInBounds(undefined, "solution",false);
        getAreaInBounds(undefined, "solutionSARF",false);
        return;
    }
    if(onlySolutions){
        getAreaInBounds(undefined, "solution",false);
        // solutionView(hardFilters["Solutions"], false);
        return;
    }
    if(onlySarfSolutions){
        getAreaInBounds(undefined, "solutionSARF",false);
        // solutionView(hardFilters["Solutions"], false);
        return;
    }
    sitesView(hardFilters["Sites"]);
    // solutionView(hardFilters["Solutions"], true);
    getAreaInBounds(undefined, "solution",true);
    getAreaInBounds(undefined, "solutionSARF",true);
    // Show/Hide Tile Layers    
    for(const [service, layer] of tileLayers.entries()) {
        layer.removeFrom(leaf);
    }

    // Wait for all the layers to finish loading
    const promises = sel
      .map(selection => tileLayers.get(selection.original.service))
      .filter(Boolean)
      .map(layer => new Promise(resolve => {
        layer.on("load", resolve);
      }));
    Promise.all(promises).then(() => $("#layer-spinner").hide());
    $.each(sel, function(idx, val){
        // Show Selected Layers
        let layer = tileLayers.get(val.original.service);
        if (layer !== undefined){
            layer.addTo(leaf);
        }
    });
    // $("#loading").show();
    // drawWavePolygonsFromPanel(sel);
}
function addMarketGeoJson(marketList){
	let ids=Object.keys(marketList);
	ids=ids.filter(id=>!marketLayers.has(Number(id))).map(id=>+id);
	if(ids.length>0){
		$.ajax({
	        url: "http://nj51uuivqa2v.nss.vzwnet.com:7003/uuigui/uui/eapp/planning_pg/getMarketGeom",
	        type: "POST",
	        data: {marketIds:JSON.stringify(ids)},
	        success: function (data) {
	        	data=JSON.parse(data);
	        	for(let obj of data){
	        		obj.geom=JSON.parse(obj.geom);
	        		let marketStyle={
	                        weight: 2,
	                        color: marketList[obj.market_id].color?marketList[obj.market_id].color:'blue',
	                        opacity: 1,
	                        fill: true,	
	                        fillOpacity: marketList[obj.market_id].opacity?marketList[obj.market_id].opacity:0.33,
	                        fillcolor:  marketList[obj.market_id]?marketList[obj.market_id]:'blue',
	                    };
	        		let layer=L.geoJson(obj.geom,{
	                    style: function (feature) {
	                        return marketStyle;
	                    }
	                }).on("click", function (e) {
	             	   var popupHeading = Number(obj.market_id)+"-"+obj.market_name;
	                   var $popup = $("<div></div>");
	                   let color=marketList[obj.market_id].color?marketList[obj.market_id].color:'blue';
	                   var $div = $("<div style='max-height:100px; max-width: fit-content; overflow-y: auto;'><h4><b style='color:"+color+";'>" + popupHeading + "</b></h4></div>");
	                   $popup.append($div);
	                   L.popup().setContent($popup.html()).setLatLng(e.latlng).addTo(leaf);
	               }).addTo(leaf);
	        		marketLayers.set(Number(obj.market_id),layer);
	        	}
	        },error:function(err){
	               console.log("error",err);
	        }
		});
	}
		
}
function addVectorLayerRight(layer) {
    var alreadyAdded = false;
    $.each(leaf._layers, function(i, v) {
        if (leaf._layers[i]._url == layer.service){
            alreadyAdded = true;
            return false;
        }
    });
    
    if (alreadyAdded) return;
    
    var styleKey = layer.style && layer.style.length != 0 ? layer.style[0].layerKey : layer.name;
    var defaultColor = layer.style && layer.style.length != 0 ? layer.style[0].color : 'blue';
    var defaultFill = layer.style && layer.style.length != 0 ? layer.style[0].fillColor : 'blue';
    var opacity = tileOpacities[layer.service];
    vectorTileLayerStyles[styleKey] = function (properties, zoom) {
        return {
            weight: 1,
            color: properties.color ? properties.color : defaultColor,
            opacity: opacity,
            fill: true,
            fillOpacity: opacity,
            fillColor: properties.color ? properties.color : defaultFill
        }
    };
    styleObj[layer.name] = vectorTileLayerStyles[styleKey];
    var options = {
            interactive: true,
            vectorTileLayerStyles: vectorTileLayerStyles,
            getFeatureId: function(f) {
                return f.properties.id;
            }
        };
    var vectorGridLayer = L.vectorGrid
       .protobuf(layer.service, options)
       .on("click", function (e) {
    	   var popupHeading = e.layer.properties.layer_name ? e.layer.properties.layer_name : e.layer.properties.name? e.layer.properties.name :e.layer.properties['Layer name'];
           var $popup = $("<div></div>");
           var $div = $("<div style='max-height:300px; width: 300px; overflow-y: auto;'><h4>" + popupHeading + "</h4></div>");
    	   var $table = $("<table class='table-striped table-hover attr-table'></table>");
           var $bod = $("<tbody style='font-size:11px;'></tbody>");
           $.each(e.layer.properties, function(idx, val){
               if(layer.name.toUpperCase()=="ROOT" && idx=="color"){
                   return;
               }else{
                    $bod.append("<tr><td style='font-weight:bold;'>"+idx+"</td><td>"+val+"</td></tr>");
                }
           })
           $table.append($bod);
           $div.append($table);
           $popup.append($div);
           L.popup().setContent($popup.html()).setLatLng(e.latlng).addTo(leaf);
       })
       .on("load", function (e) {
           scrollingVectorFilter(e);
       })
       .addTo(leaf);
    
    vectorLayersRight[layer.service] = vectorGridLayer;
}
function addVectorLayer(layer) {
    var alreadyAdded = false;
    $.each(leafCompare._layers, function(i, v) {
        if (leafCompare._layers[i]._url == layer.service){
            alreadyAdded = true;
            return false;
        }
    });
    
    if (alreadyAdded) return;
    
    var styleKey = layer.style && layer.style.length != 0 ? layer.style[0].layerKey : layer.name;
    var defaultColor = layer.style && layer.style.length != 0 ? layer.style[0].color : 'blue';
    var defaultFill = layer.style && layer.style.length != 0 ? layer.style[0].fillColor : 'blue';
    var opacity = tileOpacities[layer.service];
    vectorTileLayerStyles[styleKey] = function (properties, zoom) {
        return {
            weight: 1,
            color: properties.color ? properties.color : defaultColor,
            opacity: opacity,
            fill: true,
            fillOpacity: opacity,
            fillColor: properties.color ? properties.color : defaultFill
        }
    };
    styleObj[layer.name] = vectorTileLayerStyles[styleKey];
    var options = {
            interactive: true,
            vectorTileLayerStyles: vectorTileLayerStyles,
            getFeatureId: function(f) {
                return f.properties.id;
            }
        };
    var vectorGridLayer = L.vectorGrid
       .protobuf(layer.service, options)
       .on("click", function (e) {
    	   var popupHeading = e.layer.properties.layer_name ? e.layer.properties.layer_name : e.layer.properties.name? e.layer.properties.name :e.layer.properties['Layer name'];
           var $popup = $("<div></div>");
           var $div = $("<div style='max-height:300px; width: 300px; overflow-y: auto;'><h4>" + popupHeading + "</h4></div>");
    	   var $table = $("<table class='table-striped table-hover attr-table'></table>");
           var $bod = $("<tbody style='font-size:11px;'></tbody>");
           $.each(e.layer.properties, function(idx, val){
               if(layer.name.toUpperCase()=="ROOT" && idx=="color"){
                   return;
               }else{
                    $bod.append("<tr><td style='font-weight:bold;'>"+idx+"</td><td>"+val+"</td></tr>");
                }
           })
           $table.append($bod);
           $div.append($table);
           $popup.append($div);
           L.popup().setContent($popup.html()).setLatLng(e.latlng).addTo(leafCompare);
       })
       .on("load", function (e) {
           scrollingVectorFilter(e);
       })
       .addTo(leafCompare);
    
       vectorLayers[layer.service] = vectorGridLayer;
}
function getWavePolygonsList() {    

    // $("#loading").show();
    var marketl = qmarketList.toString();
    // if (marketl && (!wavemarket || wavemarket != marketl)) {
    //  wavemarket = marketl;
        $.ajax({
            url: "http://nj51uuivqa2v.nss.vzwnet.com:7003/uuigui/uui/eapp/planning_pg/getWavePolygons?markets=" + marketl,
            type: "GET",
            async : false,
            success: function (data) {
                wavePolygons = {};
                wavePolygonList = [];
                for (var i in data) {
                    var d = data[i];
                    var pid = d.planning_area_id;
                    wavePolygonList.push({ "id": "wave_"+d.planning_area_id, "name": ""+d.planning_area_name, "service": "placeholder", "state": { "selected": false, "opened": false }, "children": [] });
                    wavePolygons[pid] = d.planning_area;
                }
                drawWavePolygonsFromPanel();
            }
        });
    // }    
}
function drawWavePolygonsFromPanel() {
       
    if(wavePolygonList){
        $.each(wavePolygonList ,function(i,element) {
            if(wavePolygonList[i].id.indexOf("wave_") > -1) {
                var _value = wavePolygonList[i].id.replace("wave_","");
                var w = wavePolygons[_value];
                var wk = $.parseXML(w);
                var wg = toGeoJSON.kml(wk);
                var pol = L.geoJson(wg, {
                    onEachFeature: function(feature, layer) {
                        if (!layer.coords) layer.coords = [];
                        if (feature.coordinates) {
                            coords = layer.coords.push(feature.coordinates);
                        }
                        else if (feature.geometry && feature.geometry.coordinates) {
                            layer.coords.push(feature.geometry.coordinates);
                        }
                        else if (feature.geometry && feature.geometry.geometries) {
                            $.each(feature.geometry.geometries, function(i, fg) {
                                layer.coords.push(fg.coordinates);
                            });
                        }
                    }
                });
                leafCompare.addLayer(pol);
                var polRight = L.geoJson(wg, {
                    onEachFeature: function(feature, layer) {
                        if (!layer.coords) layer.coords = [];
                        if (feature.coordinates) {
                            coords = layer.coords.push(feature.coordinates);
                        }
                        else if (feature.geometry && feature.geometry.coordinates) {
                            layer.coords.push(feature.geometry.coordinates);
                        }
                        else if (feature.geometry && feature.geometry.geometries) {
                            $.each(feature.geometry.geometries, function(i, fg) {
                                layer.coords.push(fg.coordinates);
                            });
                        }
                    }
                });
                leaf.addLayer(polRight);
                var lid = pol._leaflet_id;
                var lid_text = "";
                $.each(wavePolygonList,function(j,elem){
                    if(elem.id==element){
                        lid_text = elem.text;
                    }
                })
                var popup = "<div style='text-align: center;'><label style='font-weight: 800; font-size: 18px;'>"+lid_text+"</label></div><div class='checkbox vzbs-checkbox'><input id='candcheck-" + lid + "' class='gj-candcheck' value='" + lid + "' type='checkbox' name='candcomp' checked><label for='candcheck-" + lid + "'>Candidate Zone</label>"
                    + "<input id='compucheck-" + lid + "' class='gj-compucheck' value='" + lid + "' type='checkbox' name='candcomp'><label for='compucheck-" + lid + "'>ACP Computation Zone</label>"
                    + "<input id='filtercheck-" + lid + "' class='gj-filtercheck' value='" + lid + "' type='checkbox' name='candcomp'><label for='filtercheck-" + lid + "'>ACP Filter Zone</label></div>";
                pol.bindPopup(popup);
                pol.on('popupopen', function (y) {
                    openWave = y.target;
                    if (compuPoly && y.target === compuPoly) $(".leaflet-popup-content .gj-compucheck").prop("checked", true);
                    //if (selectedPoly && y.target === selectedPoly) $(".leaflet-popup-content .gj-candcheck").prop("checked", true);
                    if (filterPoly && y.target === filterPoly) $(".leaflet-popup-content .gj-filtercheck").prop("checked", true);
                     $(".leaflet-popup-content .gj-candcheck").prop("checked", false);
                });
                pol.on('click', function (x) {
                    if (dropPin) {
                        x.target.closePopup();
                        return;
                    }
                });
                wkt = new Wkt.Wkt();
                pol.eachLayer(function(l) {
                    var va = l.toGeoJSON() != undefined && l.toGeoJSON().geometry != undefined? l.toGeoJSON().geometry : [{}];
                    if(va.geometries != undefined){
                        $.each(va.geometries, function(i,v){
                            wkt.read(JSON.stringify(v));
                        })
                    }else{
                        wkt.read(JSON.stringify(va));
                    }
                });
                polyShape = wkt.write();
                $("#candidateBtn").prop("disabled", false); $("#get4gbtn").prop("disabled", false);
                waveKml.push(pol);
            }
        });
    }
    // $("#loadingDiv").hide();
    // $("#loadingIcon").hide();
    // $("#loadingTxt").hide();
}
function getPEAShapes() {    
    $.ajax({
        url: "http://nj51uuivqa2v.nss.vzwnet.com:7003/uuigui/uui/eapp/planning_pg/getPEAShapes",
        type: "GET",
        async : false,
        success: function (data) {
            peaPolygons = {};                
            for (var i in data) {
                var d = data[i];
                var pid = d.pea_num;                    
                peaPolygons[pid] = d.pea_geom;
            }
            drawPEAPolygonsFromPanel();
        }
    });
}
function drawPEAPolygonsFromPanel() {
    
    if(peaPolygons){
        $.each(peaPolygons ,function(i,element) {            
            var w = jQuery.parseJSON(element);
            var pol = L.geoJson(w, {
                onEachFeature: function(feature, layer) {
                    if (!layer.coords) layer.coords = [];
                    if (feature.coordinates) {
                        coords = layer.coords.push(feature.coordinates);
                    }
                    else if (feature.geometry && feature.geometry.coordinates) {
                        layer.coords.push(feature.geometry.coordinates);
                    }
                    else if (feature.geometry && feature.geometry.geometries) {
                        $.each(feature.geometry.geometries, function(i, fg) {
                            layer.coords.push(fg.coordinates);
                        });
                    }
                }
            });
            leafCompare.addLayer(pol); 
            var polRight = L.geoJson(w, {
                onEachFeature: function(feature, layer) {
                    if (!layer.coords) layer.coords = [];
                    if (feature.coordinates) {
                        coords = layer.coords.push(feature.coordinates);
                    }
                    else if (feature.geometry && feature.geometry.coordinates) {
                        layer.coords.push(feature.geometry.coordinates);
                    }
                    else if (feature.geometry && feature.geometry.geometries) {
                        $.each(feature.geometry.geometries, function(i, fg) {
                            layer.coords.push(fg.coordinates);
                        });
                    }
                }
            });
            leaf.addLayer(polRight);            
            peapol.push(pol);
        });
    }
    // $("#loadingDiv").hide();
    // $("#loadingIcon").hide();
    // $("#loadingTxt").hide();
}
function scrollingVectorFilter(e) {
    if (vectorLayers) {
        $.each(vectorLayers, function(a, b) {
            var vtemp = vectorLayers[a];
            var dataLayer = vtemp._dataLayerNames;
            var keyName = Object.keys(dataLayer);
            if (keyName.length == 0)
                return false;
            var splitIndex = keyName[0].indexOf("_");
            var name = keyName[0].substring(0,splitIndex);
            var temp = filterInfo[name] ? filterInfo[name].filter : undefined;
            if (temp) {
                var o = {};
                o.service = vtemp._url;
                filterVectors(temp, o, name);
            }
        });     
    }
}



function getAreaInBounds(e, flag, filterFlag, selected) {
    if (leaf.getZoom() < sitesZoomLevel) {
        if($("#layer-list").jstree(true)){
            let sel = $("#layer-list").jstree(true).get_selected(true);
            if(sel && sel.length > 0 ){
                if(solutionDataFromHistory){
                    sel = sel.concat(solutionDataFromHistory);
                }
                if(solutionSarfDataFromHistory){
                    sel = sel.concat(solutionSarfDataFromHistory);
                }
            }else if(solutionDataFromHistory && solutionDataFromHistory.length > 0){
                sel = solutionDataFromHistory;
                if(solutionSarfDataFromHistory){
                    sel = sel.concat(solutionSarfDataFromHistory);
                }
            }else if(solutionSarfDataFromHistory && solutionSarfDataFromHistory.length > 0){
                sel = solutionSarfDataFromHistory;
            }
            var removeSolutionNode = true;
            if(sel){
                $.each(sel, function(idx, val){
                    if(val.original.path.startsWith("#Solutions")){
                        removeSolutionNode = false;
                    }
                    if(val.original.path.startsWith("#Solution SARF")){
                        removeSolutionNode = false;
                    }
                });
                if(removeSolutionNode == true && solutionDataFromHistory && solutionDataFromHistory.length == 0){
                    //if($solutionAjax){
                        //$.when($solutionAjax).done(function(){
                            cancelSolutionView();
                        //})
                    //}
                }
                if(removeSolutionNode == true && solutionSarfDataFromHistory && solutionSarfDataFromHistory.length == 0){
                    //if($sarfSolutionAjax){
                        //$.when($sarfSolutionAjax).done(function(){
                            cancelSARFSolutionView();
                        //})
                    //}
                }
            }
        }
        return;
    }
    var ll = leaf.getCenter();
    var exclude = "";
    var excludeFlag = false;
    if(flag != "solution" && flag != "solutionSARF"){
        for (var i in loadedArea) {
            exclude += i + ",";
        }
    }
    $.ajax({
        url: CONTEXT_PATH + "/uui/eapp/planning_pg/getAreaFromPoint?longitude=" + ll.lng + "&latitude=" + ll.lat + "&exclude=" + exclude,
        type: 'GET',
        success: function (data) {
            data = JSON.parse(data);
            var allArea = data.allArea && data.allArea != ""? JSON.parse(data.allArea) : [];
            data = JSON.parse(data.data);
            for (var i in loadedArea) {
                var x = _.findIndex(allArea, { "AREA_ID": i*1 });
                if(x >= 0){
                    excludeFlag = true;
                }
            }
            if(flag == "solution"){
                displaySolution = true;
                let hardFilters = {};
                let sel = $("#layer-list").jstree('get_selected', true);
                sel = sel != undefined && sel.length > 0? sel: solutionDataFromHistory;
                if(sel && sel.length > 0){
                   $.each(sel, function(idx, val){
                        if(!hardFilters["Solutions"]){
                            hardFilters["Solutions"] = [];
                        }
                        if(val.original.path.startsWith("#Solutions")){
                            hardFilters["Solutions"].push(val);
                        }
                    });
                }
                if(filterFlag == true){
                    if($solutionAjax){
                        $.when($solutionAjax).done(function(){
                            cancelSolutionView();
                            if (data && data.length > 0 && loadedSolutionArea.indexOf(data[0].AREA_ID) < 0){
                                solutionView(hardFilters["Solutions"], filterFlag, data[0].AREA_ID, flag);
                            }else if(data && data.length > 0 && filterFlag == true){
                                solutionView(hardFilters["Solutions"], filterFlag, data[0].AREA_ID, flag);
                            }else{
                                solutionView(hardFilters["Solutions"], filterFlag, undefined, flag);
                            }
                            return;
                        })
                    }else{
                        cancelSolutionView();
                    }
                }
                if (data && data.length > 0 && loadedSolutionArea.indexOf(data[0].AREA_ID) < 0){
                    solutionView(hardFilters["Solutions"], filterFlag, data[0].AREA_ID, flag);
                }else if(data && data.length > 0 && filterFlag == true){
                    solutionView(hardFilters["Solutions"], filterFlag, data[0].AREA_ID, flag);
                }else{
                    solutionView(hardFilters["Solutions"], filterFlag, undefined, flag);
                }
                return;
            }
            if(flag == "solutionSARF"){
                displaySarfSolution = true;
                let hardFilters = {};
                let sel = $("#layer-list").jstree(true).get_selected(true);
                sel = sel != undefined && sel.length > 0? sel: solutionSarfDataFromHistory;
                if(sel && sel.length > 0){
                   $.each(sel, function(idx, val){
                        if(!hardFilters["Solution SARF"]){
                            hardFilters["Solution SARF"] = [];
                        }
                        if(val.original.path.startsWith("#Solution SARF")){
                            hardFilters["Solution SARF"].push(val);
                        }
                    });
                }                
                if(filterFlag == true){
                    if($sarfSolutionAjax){
                        $.when($sarfSolutionAjax).done(function(){
                            cancelSARFSolutionView();
                            if (data && data.length > 0 && loadedSarfSolutionArea.indexOf(data[0].AREA_ID) < 0){
                                solutionView(hardFilters["Solution SARF"], filterFlag, data[0].AREA_ID, flag);
                            }else if(data && data.length > 0 && filterFlag == true){
                                solutionView(hardFilters["Solution SARF"], filterFlag, data[0].AREA_ID, flag);
                            }else{
                                solutionView(hardFilters["Solution SARF"], filterFlag, undefined, flag);
                            }
                            return;
                        })
                    }else{
                        cancelSARFSolutionView();
                    }
                }
                if (data && data.length > 0 && loadedSarfSolutionArea.indexOf(data[0].AREA_ID) < 0){
                    solutionView(hardFilters["Solution SARF"], filterFlag, data[0].AREA_ID, flag);
                }else if(data && data.length > 0 && filterFlag == true){
                    solutionView(hardFilters["Solution SARF"], filterFlag, data[0].AREA_ID, flag);
                }else{
                    solutionView(hardFilters["Solution SARF"], filterFlag, undefined, flag);
                }
                return;
            }
            if (!data || !data.length){
                solRefresh();
                return;
            }
            if (!qmarket || (excludeFlag == false && qmarket != Number(data[0].NAME))) {
                qmarket = Number(data[0].NAME);
                qmarketName = data[0].MARKETNAME;
                qatollMarket = data[0].ATOLL_MARKET_NAME;
            }
            qmarketList = []
            for(var i=0;i<data.length;i++){
                qmarketList.push(data[i].NAME);
            }
            let filterMap = {};
            for (const filter of siteFilters) {
                filterMap[filter.key] = [];
                if(filter.key == "is5g"){
                    filterMap['is1x'] = [];
                }
                for (const prop in filter.options) {
                    if (filter.options[prop]) {
                        if(filter.key == "is5g"){
                            var k = "";
                            if(prop == "4G" || prop == "5G"){
                                filterMap[filter.key].push(prop);
                            }else{
                                if(prop == "1X (3G)"){
                                    k = '1xRTT';
                                }else if(prop == "EVDO (3G)"){
                                    k = '1xEV-DO';
                                }
                                filterMap['is1x'].push(k);
                            }
                        }else{
                            filterMap[filter.key].push(prop);
                        }
                    }
                }
            }
            // if(isSectorDetails == false){
                let hardFilters = {};
                let hardParents = ["Sites"];
                let sel = $("#layer-list").jstree(true).get_selected(true);
                for(const parent of hardParents){
                    $.each(sel, function(idx, val){
                        if(!hardFilters[parent]){
                            hardFilters[parent] = [];
                        }
                        if(val.original.path.startsWith("#" + parent)){
                            hardFilters[parent].push(val);
                        }
                    });
                }
                if(!hardFilters["Sites"] || hardFilters["Sites"].length == 0){
                    return;
                }
            // }
            if (!loadedArea[data[0].AREA_ID] && data[0].DIST <= 1.0) {
                currentAreaId = data[0].AREA_ID;
                if(isSectorDetails == false && filterMap !== undefined && data[0].AREA_ID !== undefined && !_.isEqual(_.sortBy(oldSiteSelected), _.sortBy(filterMap))){
                    turnOffSites();
                }
                oldSiteSelected = filterMap;
                searchAreaSites(data[0].AREA_ID, null, true, null);
            }else if(filterMap !== undefined && data[0].AREA_ID !== undefined && !_.isEqual(_.sortBy(oldSiteSelected), _.sortBy(filterMap))){
                currentAreaId = data[0].AREA_ID;
                oldSiteSelected = filterMap;
                turnOffSites();
                searchAreaSites(data[0].AREA_ID, null, true, null);
            }else{
                solRefresh();
            }
            if(isSectorDetails == true){
                isSectorDetails = false;
            }
        }
    });
}


function solutionView(selected, filterFlag, areaId, flag) {
    // displaySolution = true;
    if(!selected || selected.length == 0){
        if(flag == "solution"){
            if($solutionAjax){
                $.when($solutionAjax).done(function(){
                    cancelSolutionView();
                    displaySolution = false;
                })
            }
        }else if(flag == "solutionSARF"){
            if($sarfSolutionAjax){
                $.when($sarfSolutionAjax).done(function(){
                    cancelSARFSolutionView();
                    displaySarfSolution = false;
                })
            }
        }else{
            if($solutionAjax){
                $.when($solutionAjax).done(function(){
                    cancelSolutionView();
                    displaySolution = false;
                })
            }
            if($sarfSolutionAjax){
                $.when($sarfSolutionAjax).done(function(){
                    cancelSARFSolutionView();
                    displaySarfSolution = false;
                })
            }
        }
        return;
    }
    if(leaf.getZoom() < 11) {
        return;
    }
    if(!areaId && flag == "solution"){
        return;
    }
    // let filterMap = undefined;
    var ajaxCallName = ["$solutionAjax", "$sarfSolutionAjax"];
    var nameIndex = 0;
    if(flag == "solution"){
        displaySolution = true;
        if ($solutionAjax) {
            $solutionAjax.abort();
            $solutionAjax = null;
        }
        nameIndex = 0;
    }else if(flag == "solutionSARF"){
        displaySarfSolution = true;
        if ($sarfSolutionAjax) {
            $sarfSolutionAjax.abort();
            $sarfSolutionAjax = null;
        }
        nameIndex = 1;
    }
    let filterMap = {};
    let sarffilterMap = {};
    let requestBody = {}
    if(flag == "solution"){
        for (const filter of solutionFilters) {
            filterMap[filter.key] = [];
            for (const prop in filter.options) {
                if (filter.options[prop]) {
                    if(filter.key == "piSolutionType"){
                        var k = [];
                        if(prop == "Carrier Add"){
                            k = ["4TX","700","850","AWS","AWS3","CBRS","FDMIMO","LAA","Modification","OPTM","PCS","SSPT"];
                        }else if(prop == "In-Building"){
                            k = ['IB', 'INBLD'];
                        }else if(prop == "Macro"){
                            k = ['MCR', 'MCRPT', 'MC'];
                        }else if(prop == "SC/ODAS"){
                            k = ['ODAS', 'SC', 'SCPT'];
                        }
                        filterMap[filter.key].push(k.toString());
                    }else{
                        filterMap[filter.key].push(prop);
                    }
                }
            }
        }
        oldSolutionSelected = filterMap;
        if(!loadedSolutions[qmarket]) {
            loadedSolutions[qmarket] = {};
            loadedSolutions[qmarket].mptsols = [];
            loadedSolutions[qmarket].sols = [];
            loadedSolutions[qmarket].fullsols = [];
            loadedSolutions[qmarket].offloadNodes = [];
            loadedSolutions[qmarket].offloadEdges = [];
            loadedSolutions[qmarket].sarfsols = [];
            loadedSolutions[qmarket].fullsarfsols = [];
            loadedSolutions[qmarket].mptsarfsols = [];
            loadedSolutions[qmarket].sarfoffloadNodes = [];
            loadedSolutions[qmarket].sarfoffloadEdges = [];
            loadedSolutions[qmarket].sarfEdges = [];
        }
        requestBody["areaId"] = areaId;
        if(filterMap["piOnAirYear"]){
            requestBody["onAirYear_project"] = filterMap["piOnAirYear"].toString();
        }
        if(filterMap["piPorYear"]){
            requestBody["porYear_project"] = filterMap["piPorYear"].toString();
        }
        if(filterMap["piSolutionType"]){
            requestBody["solutionType_project"] = filterMap["piSolutionType"].toString();
        }
        if(filterMap["piProjectStatus"]){
            requestBody["projectStatus_project"] = filterMap["piProjectStatus"].toString();
        }
        if(filterMap["piBuildPlanYear"]){
            requestBody["buildPlanYear_project"] = filterMap["piBuildPlanYear"].toString();
        }
        if(filterMap["piTechnologyType"]){
            requestBody["technologyType_project"] = filterMap["piTechnologyType"].toString();
        }
        if(filterMap["piInitiativeType"]){
            requestBody["initiativeType_project"] = filterMap["piInitiativeType"].toString();
        }
        requestBody["allProject"] = "true";
        loadedSolutionArea = [];
        if(loadedSolutionArea.indexOf(areaId) < 0){
            loadedSolutionArea.push(areaId);
        }
    }else if(flag == "solutionSARF"){
        for (const filter of solutionSARFFilters) {
            sarffilterMap[filter.key] = [];
            for (const prop in filter.options) {
                if (filter.options[prop]) {
                    if(filter.key == "siSolutionType"){
                        var k = [];
                        if(prop == "Carrier Add"){
                            k = ["4TX","700","850","AWS","AWS3","CBRS","FDMIMO","LAA","Modification","OPTM","PCS","SSPT"];
                        }else if(prop == "In-Building"){
                            k = ['IB', 'INBLD'];
                        }else if(prop == "Macro"){
                            k = ['MCR', 'MCRPT', 'MC'];
                        }else if(prop == "SC/ODAS"){
                            k = ['ODAS', 'SC', 'SCPT'];
                        }
                        sarffilterMap[filter.key].push(k.toString());
                    }else{
                        sarffilterMap[filter.key].push(prop);
                    }
                }
            }
        }
        oldSarfSolutionSelected = sarffilterMap;
        if(!loadedSolutions[qmarket]) {
            loadedSolutions[qmarket] = {};
            loadedSolutions[qmarket].mptsols = [];
            loadedSolutions[qmarket].sols = [];
            loadedSolutions[qmarket].fullsols = [];
            loadedSolutions[qmarket].offloadNodes = [];
            loadedSolutions[qmarket].offloadEdges = [];
            loadedSolutions[qmarket].sarfsols = [];
            loadedSolutions[qmarket].fullsarfsols = [];
            loadedSolutions[qmarket].mptsarfsols = [];
            loadedSolutions[qmarket].sarfoffloadNodes = [];
            loadedSolutions[qmarket].sarfoffloadEdges = [];
            loadedSolutions[qmarket].sarfEdges = [];
        }
        if(sarffilterMap["siPorYear"]){
            requestBody["porYear_sarf"] = sarffilterMap["siPorYear"].toString();
        }
        if(filterMap["siProjectStatus"]){
            requestBody["projectStatus_sarf"] = filterMap["siProjectStatus"].toString();
        }
        if(filterMap["siTechnologyType"]){
            requestBody["technologyType_sarf"] = filterMap["siTechnologyType"].toString();
        }
        if(sarffilterMap["siBuildPlanYear"]){
            requestBody["buildPlanYear_sarf"] = sarffilterMap["siBuildPlanYear"].toString();
        }
        if(sarffilterMap["siSolutionType"]){
            requestBody["solutionType_sarf"] = sarffilterMap["siSolutionType"].toString();
        }
        if(sarffilterMap["siInitiativeType"]){
            requestBody["initiativeType_sarf"] = sarffilterMap["siInitiativeType"].toString();
        }
        var b = leaf.getBounds();
        var n = b.getNorth();
        var s = b.getSouth();
        var e = b.getEast();
        var w = b.getWest();
        requestBody["minLat"] = s;
        requestBody["maxLat"] = n;
        requestBody["minLong"] = w;
        requestBody["maxLong"] = e;
        requestBody["allSarfProject"] = "true";
        loadedSarfSolutionArea = [];
        if(loadedSarfSolutionArea.indexOf(areaId) < 0){
            loadedSarfSolutionArea.push(areaId);
        }
    }
    $("#solviewBtn").find('.btntext').hide();
    $("#solviewBtn").find('.fa-pulse').show();
    $("#loadingIcon").show();
    $("#loadingTxt").show();
    window[ajaxCallName[nameIndex]] = $.ajax({
        url: CONTEXT_PATH + "/uui/eapp/planning_pg/getSolutionsInBounds",
        type: "POST",
        data: requestBody,
        success: function (records) {
            if (!records) return;
            previousAreaId = areaId;
            /*if(loadedSolutions[qmarket]){
                t.removeEdges(loadedSolutions[qmarket].offloadEdges);
                t.removeEdges(loadedSolutions[qmarket].sarfEdges);
                t.removeNodes(loadedSolutions[qmarket].offloadNodes);
                t.removeNodes(loadedSolutions[qmarket].sols);
            }*/
            if (!loadedSolutions[qmarket]) {
                loadedSolutions[qmarket] = {};
                loadedSolutions[qmarket].sols = [];
                loadedSolutions[qmarket].fullsols = [];
                loadedSolutions[qmarket].mptsols = [];
                loadedSolutions[qmarket].offloadNodes = [];
                loadedSolutions[qmarket].offloadEdges = [];
                loadedSolutions[qmarket].sarfsols = [];
                loadedSolutions[qmarket].fullsarfsols = [];
                loadedSolutions[qmarket].mptsarfsols = [];
                loadedSolutions[qmarket].sarfoffloadNodes = [];
                loadedSolutions[qmarket].sarfoffloadEdges = [];
                loadedSolutions[qmarket].sarfEdges = [];
                // t.addClusterGroup('solutions:' + qmarket, 20, true);
                // setClusterGroup('solutions:' + qmarket, true);
            }
            var toAdd = [];
            var toAddIds = [];
            var sameIdArray = {};
            if(records.project.length>0){
                var data = records.project;
                for (var i in data) {
                    if (allSolutions.indexOf("sol_" + data[i].PARENTSOLUTIONID) >= 0) continue;
                    if (loadedSolutions[qmarket].sols.indexOf("sol_" + data[i].PARENTSOLUTIONID) >= 0) continue;
                    if (loadedSolutions[qmarket].mptsols && loadedSolutions[qmarket].mptsols.length && loadedSolutions[qmarket].mptsols.indexOf("sol_" + data[i].PARENTSOLUTIONID) >= 0) {
                        loadedSolutions[qmarket].sols.push("sol_" + data[i].PARENTSOLUTIONID);
                        continue;
                    }
                    var tp = data[i].SOLUTIONTYPE;
                    var tt = '';
                    // check later
                    for (var j in soltype_map) {
                        if (soltype_map[j].types.indexOf(tp) >= 0) { tt = j; break; }
                    }
                    if (!tt) tt = 'carradd';
                    var oay = data[i].BUILDPLANYEAR;
                    var pory = data[i].PORY;
                    if (oay < currentYear) oay = "Before "+currentYear;
                    else if (oay >= (currentYear+5)) oay = (currentYear+5)+" or later";  
                    if (pory < currentYear) pory = "Before "+currentYear;               
                    else if (pory >= (currentYear+5)) pory = (currentYear+5)+" or later";                
                    var buildPlanYearIcon = "svg_solution_" + tt + "_" + oay + "_" + _.camelCase(data[i].PROJECTSTATUS);
                    var porYearIcon = "svg_solution_" + tt + "_" + pory + "_" + _.camelCase(data[i].PROJECTSTATUS);
                    var icon;
                    var solutionView = $('#solyearheadSel').val();
                    if(solutionView == "Build Plan Year"){
                        icon = buildPlanYearIcon;
                    }else{
                        icon = porYearIcon;
                    }
                    var markerOptions = {
                        "clusterName": 'solutions:' + qmarket,
                        "latitude": data[i].LATITUDE,
                        "longitude": data[i].LONGITUDE,
                        "isSolution": true,
                        "solutionId": data[i].SOLUTIONID,
                        "buildPlanYear": data[i].BUILDPLANYEAR,
                        "PORYear": data[i].PORY,
                        "buildPlanYearIcon": buildPlanYearIcon,
                        "porYearIcon": porYearIcon
                    };
                    var lk = "";
                    if (data[i].PROJECTNUMBER) lk = "<a href='" + sitemanagementUrl + "/projects.jsp?projectId=" + data[i].PROJECTNUMBER + "' target='_blank' class='projectLink'>" + data[i].PROJECTNUMBER + "</a>";
                    var popup = "<div style='background:white;'>"
                        + "<h4>" + data[i].SOLUTIONNAME + "</h4>"
                        + "<div class='popup-inner' style='border:1px solid #d7d7d7;background: #f7f7f7; margin-bottom:10px; padding:0 5px;'>"
                        + "<div><div class='halfdiv'><h5>Solution ID</h5></div><div class='halfdiv'>" + data[i].SOLUTIONID + "</div></div>";
                    if (data[i].PARENTSOLUTIONID)
                        popup += "<div><div class='halfdiv'><h5>Parent Solution ID</h5></div><div class='halfdiv'>" + data[i].PARENTSOLUTIONID + "</div></div>";
                    popup += "<div><div class='halfdiv'><h5>POR Year</h5></div><div class='halfdiv'>" + data[i].PORY + "</div></div>";
                    popup += "<div><div class='halfdiv'><h5>Build Plan Year</h5></div><div class='halfdiv'>" + data[i].BUILDPLANYEAR + "</div></div>";
                    popup += "<div><div class='halfdiv'><h5>Solution Type</h5></div><div class='halfdiv'>" + data[i].SOLUTIONTYPE + "</div></div>";
                    popup += "<div><div class='halfdiv'><h5>Project Status</h5></div><div class='halfdiv'>" + data[i].PROJECTSTATUS + "</div></div>";
                    if (data[i].SOLUTIONINITIATIVE)
                        popup += "<div><div class='halfdiv'><h5>Initiative</h5></div><div class='halfdiv'>" + data[i].SOLUTIONINITIATIVE + "</div></div>";
                    popup += "<div><div class='halfdiv'><h5>SPM Project Number</h5></div><div class='halfdiv'>"+lk+"</div></div>"
                        + "</table></div>";
                    popup += "<div class='vzbs-holder'><span class='checkbox vzbs-checkbox' style=''><input id='spider-" + data[i].SOLUTIONID + "' class='spider-check' parentSolutionId='" + data[i].PARENTSOLUTIONID + "' value='" + data[i].SOLUTIONID + "' project='" + data[i].PROJECTNUMBER + "' type='checkbox'><label for='spider-" + data[i].SOLUTIONID + "'>Reverse Solution Spider</label></span></div>";
                    popup += "</div>";
                    var n = {
                        'id': "sol_" + data[i].PARENTSOLUTIONID,
                        'x': data[i].LONGITUDE,
                        'y': data[i].LATITUDE,
                        'options': {
                            icon: icon,
                            tooltip: {
                                text: data[i].SOLUTIONNAME,
                                options: {
                                    direction: "bottom",
                                    className: "nitro-tooltip",
                                    sticky: true,
                                    permanent: false
                                }
                            },
                            markerOptions: markerOptions,
                            popup: {
                                html: popup
                            }
                        }
                    };
                    loadedSolutions[qmarket].sols.push("sol_" + data[i].PARENTSOLUTIONID);
                    toAddIds.push("sol_" + data[i].PARENTSOLUTIONID);
                    loadedSolutions[qmarket].fullsols.push(n);
                    sameIdArray[data[i].PARENTSOLUTIONID] = {
                        "d": [],
                        "color":sarfEdgeColorMap[tt + "_" + oay]
                    };
                    sameIdArray[data[i].PARENTSOLUTIONID].d.push("sol_" + data[i].PARENTSOLUTIONID);
                    allSolutions.push("sol_" + data[i].PARENTSOLUTIONID);
                    toAdd.push(n);
                }
            }
            if(records.sarf.length>0){
                var data = records.sarf;
                for (var i in data) {
                    if (allSARFSolutions.indexOf("sol_sarf_" + data[i].PARENTSOLUTIONID) >= 0) continue;
                    if (loadedSolutions[qmarket].sarfsols.indexOf("sol_sarf_" + data[i].PARENTSOLUTIONID) >= 0) continue;
                    if (loadedSolutions[qmarket].mptsarfsols && loadedSolutions[qmarket].mptsarfsols.length && loadedSolutions[qmarket].mptsarfsols.indexOf("sol_sarf_" + data[i].PARENTSOLUTIONID) >= 0) {
                        loadedSolutions[qmarket].sarfsols.push("sol_sarf_" + data[i].PARENTSOLUTIONID);
                        continue;
                    }
                    if(allLoadedSARFSolution.indexOf("sol_sarf_" + data[i].PARENTSOLUTIONID) >= 0){
                        continue;
                    }
                    allLoadedSARFSolution.push("sol_sarf_" + data[i].PARENTSOLUTIONID);
                    var tp = data[i].SOLUTIONTYPE;
                    var tt = '';
                    for (var j in soltype_map) {
                        if (soltype_map[j].types.indexOf(tp) >= 0) { tt = j; break; }
                    }
                    if (!tt) tt = 'carradd';
                    var oay = data[i].BUILDPLANYEAR;
                    if (oay < currentYear) oay = "Before "+currentYear;             
                    else if (oay >= (currentYear+5)) oay = (currentYear+5)+" or later";  
                    var pory = data[i].PORY;
                    if (pory < currentYear) pory = "Before "+currentYear;               
                    else if (pory >= (currentYear+5)) pory = (currentYear+5)+" or later";
                    var buildPlanYearIcon = "svg_sarf_solution_" + tt + "_" + oay;
                    var porYearIcon = "svg_sarf_solution_" + tt + "_" + pory;
                    var icon;
                    var solutionView = $('#solyearheadSel').val();
                    if(solutionView == "Build Plan Year"){
                        icon = buildPlanYearIcon;
                    }else{
                        icon = porYearIcon;
                    }
                    var markerOptions = {
                        "clusterName": 'solutions:' + qmarket,
                        "latitude": Number(data[i].LATITUDE),
                        "longitude": Number(data[i].LONGITUDE),
                        "isSolution": true,
                        "solutionId": data[i].SOLUTIONID,
                        "buildPlanYearIcon": buildPlanYearIcon,
                        "porYearIcon": porYearIcon
                    };
                    var lk = "";
                    if (data[i].PROJECTNUMBER) lk = "<a href='" + sitemanagementUrl + "/projects.jsp?projectId=" + data[i].PROJECTNUMBER + "' target='_blank' class='projectLink'>" + data[i].PROJECTNUMBER + "</a>";
                    var popup = "<div style='background:white;'>"
                        + "<h4>" + data[i].SOLUTIONNAME + "</h4>"
                        + "<div class='popup-inner' style='border:1px solid #d7d7d7;background: #f7f7f7; margin-bottom:10px; padding:0 5px;'>"
                        + "<div><div class='halfdiv'><h5>Solution ID</h5></div><div class='halfdiv'>" + data[i].SOLUTIONID + "</div></div>";
                    if (data[i].PARENTSOLUTIONID)
                        popup += "<div><div class='halfdiv'><h5>Parent Solution ID</h5></div><div class='halfdiv'>" + data[i].PARENTSOLUTIONID + "</div></div>";
                    popup += "<div><div class='halfdiv'><h5>POR Year</h5></div><div class='halfdiv'>" + data[i].PORY + "</div></div>";
                    popup += "<div><div class='halfdiv'><h5>Build Plan Year</h5></div><div class='halfdiv'>" + data[i].BUILDPLANYEAR + "</div></div>";
                    popup += "<div><div class='halfdiv'><h5>Solution Type</h5></div><div class='halfdiv'>" + data[i].SOLUTIONTYPE + "</div></div>";
                    popup += "<div><div class='halfdiv'><h5>Solution Status</h5></div><div class='halfdiv'>" + data[i].STATUS + "</div></div>";
                    if (data[i].SOLUTIONINITIATIVE)
                        popup += "<div><div class='halfdiv'><h5>Initiative</h5></div><div class='halfdiv'>" + data[i].SOLUTIONINITIATIVE + "</div></div>";
                        + "</table></div>";
                    popup += "<div class='vzbs-holder'><span class='checkbox vzbs-checkbox' style=''><input id='sarf-spider-" + data[i].SOLUTIONID + "' class='sarf-spider-check' parentSolutionId='" + data[i].PARENTSOLUTIONID + "' value='" + data[i].SOLUTIONID + "' project='" + data[i].PROJECTNUMBER + "' type='checkbox'><label for='sarf-spider-" + data[i].SOLUTIONID + "'>Reverse Solution Spider</label></span></div>";
                    popup += "</div>";
                    var n = {
                        'id': "sol_sarf_" + data[i].PARENTSOLUTIONID,
                        'x': Number(data[i].LONGITUDE),
                        'y': Number(data[i].LATITUDE),
                        'options': {
                            icon: icon,
                            tooltip: {
                                text: data[i].SOLUTIONNAME,
                                options: {
                                    direction: "bottom",
                                    className: "nitro-tooltip",
                                    sticky: true,
                                    permanent: false
                                }
                            },
                            markerOptions: markerOptions,
                            popup: {
                                html: popup
                            }
                        }
                    };
                    loadedSolutions[qmarket].sarfsols.push("sol_sarf_" + data[i].PARENTSOLUTIONID);
                    toAddIds.push("sol_sarf_" + data[i].PARENTSOLUTIONID);
                    loadedSolutions[qmarket].fullsarfsols.push(n);
                    if(data[i].PARENTSOLUTIONID in sameIdArray){
                        sameIdArray[data[i].PARENTSOLUTIONID].d.push("sol_sarf_" + data[i].PARENTSOLUTIONID);
                    }
                    allSARFSolutions.push("sol_sarf_" + data[i].PARENTSOLUTIONID);
                    toAdd.push(n);
                }
            }
            loadedSolutions[qmarket].mptsols = [];
            loadedSolutions[qmarket].mptsarfsols = [];
            t.addNodes(toAdd);
            for(var i in sameIdArray){
                if(sameIdArray[i].d.length > 1){
                    var a = t.hasNode(sameIdArray[i].d[0]);
                    var z = t.hasNode(sameIdArray[i].d[1]);
                    var e = XYZ.edge(sameIdArray[i].d[0] + "-" + sameIdArray[i].d[1], a, z, {
                        tooltip: {
                            text: "",
                            options: {
                                direction: "top",
                                data: "nitro-tooltip",
                                sticky: true,
                                permanent: false
                            }
                        },
                        line_attr: {
                            data: "standard-edge",
                            weight: 1.0,
                            dashArray : "20, 10",
                            color: sameIdArray[i].color
                        }
                    });
                    loadedSolutions[qmarket].sarfEdges.push(e);
                    t.addEdge(e);
                }
            };
            $.each(toAddIds, solNodeClick);
            if (splitSolClusters && leaf.getZoom() >= splitSolClusters) {
                t.freezeClusterGroup('solutions:' + qmarket);
            }
        },
        complete: function () {
            $("#solviewBtn").find('.btntext').show();
            $("#solviewBtn").find('.fa-pulse').hide();
            $("#loadingDiv").hide();
            leaf.off("moveend", solutionsMove);
            leaf.on("moveend", solutionsMove);
            if(!$vpiAjax && !searchAreaSitesAjax){
                $("#loadingIcon").hide();
                $("#loadingTxt").hide();
            }
        }
    });
}

