
var versionData = []
var atollSchema = ["albuquerque","atlanta","austin","bismarck","bocaraton","boise","carolinas","centralillinois","chicago","cincinnati","cleveland","dallas","denver","desmoines","detroit","dublin","eugene","fargo","hawaii","houston","indianapolis","jacksonville","kansas","lasvegas","losangeles","louisville","milwaukee","minneapolis","montana","nashville","newenglandeast","newenglandwest","newjersey","neworleans","nymetro","nyupstate","orlando","philadelphia","phoenix","pittsburgh","portland","rockford","sacramento","saltlake","sandiego","sanfrancisco","sdakota","seattle","southcentral","spokane","stlouis","tampa","virginia","washington"]
var initialFlag = true;
var siteName;
var carrierDLMapInSite = {};
var carrierDLMapInCell = {};
var stationTemplateInCarrier = {};
var siteNameGlobal, fuzeSiteIdGlobal;
var txId;
var siteAutoAjax;
var versionTamplate = [], txTamplate = [], cellTamplate = [];
var versionDefaultViewName = 'ATOLL.CARRIER.VERSION.DEFAULT';
var txDefaultViewName = 'ATOLL.CARRIER.TX.DEFAULT';
var cellDefaultViewName = 'ATOLL.CARRIER.CELL.DEFAULT';
var versionOptgroups = [], txOptgroups = [], cellOptgroups = [];
var versionDefaultColumns = [], txDefaultColumns = [], cellDefaultColumns = [];
var versionDisplayColumns = [], txDisplayColumns = [], cellDisplayColumns = [];
var versionOriginFilterName = [], txOriginFilterName = [], cellOriginFilterName = [];
var versionOriginalTamplateColumnMap = {}, txOriginalTamplateColumnMap = {}, cellOriginalTamplateColumnMap = {};
var versionDefaultViewName = 'ATOLL.CARRIER.VERSION.DEFAULT';
var txDefaultViewName = 'ATOLL.CARRIER.TX.DEFAULT';
var cellDefaultViewName = 'ATOLL.CARRIER.CELL.DEFAULT';
var versionBaseoptgroups = [
    {
        label: 'Standard Views', children: []
    },
    {
        label: 'My Views', children: []
    }
];
var txBaseoptgroups = [
    {
        label: 'Standard Views', children: []
    },
    {
        label: 'My Views', children: []
    }
];
var cellBaseoptgroups = [
    {
        label: 'Standard Views', children: []
    },
    {
        label: 'My Views', children: []
    }
];
$(document).ready(function(e){

    try {
        var env = window.location.href.includes('canvasple') ? '-PLE' : '';
        window.initClickstream({
            "system_name": "Network Planning Platform",
            "app_name": "ATOLL" + env,
            "screen_name": "Atoll Site Management",
            "showLogs": "true"
        });
    } catch (e) {
        return false;
    }

    // roles.push("BETA_USER");
    getUserSchema();
    getDefaultColumns("ATOLL.CARRIER.VERSION.DEFAULT", "version");
    getDefaultColumns("ATOLL.CARRIER.TX.DEFAULT", "tx");
    getDefaultColumns("ATOLL.CARRIER.CELL.DEFAULT", "cell");


    $.each(versionTamplate, function(i, v){
        $('#versionTamplateSelect').append("<option>" + v + "</option>");
    })    
    $('#versionTamplateSelect').multiselect({
        includeSelectAllOption: true,
        enableFiltering:true,
        enableCaseInsensitiveFiltering: true,
        buttonClass: 'btn btn-default whitebg btn-sm',
        numberDisplayed: 1
    });
    bindEventForTemplate("versionTamplateSelect", "version");

    $.each(txTamplate, function(i, v){
        $('#txTamplateSelect').append("<option>" + v + "</option>");
    })    
    $('#txTamplateSelect').multiselect({
        includeSelectAllOption: true,
        enableFiltering:true,
        enableCaseInsensitiveFiltering: true,
        buttonClass: 'btn btn-default whitebg btn-sm',
        numberDisplayed: 1
    });

    bindEventForTemplate("txTamplateSelect", "tx");
    
    $.each(cellTamplate, function(i, v){
        $('#cellTamplateSelect').append("<option>" + v + "</option>");
    })
    $('#cellTamplateSelect').multiselect({
        includeSelectAllOption: true,
        enableFiltering:true,
        enableCaseInsensitiveFiltering: true,
        buttonClass: 'btn btn-default whitebg btn-sm',
        numberDisplayed: 1
    });
    bindEventForTemplate("cellTamplateSelect", "cell");

    $.widget("custom.catautocomplete", $.ui.autocomplete, {
        _create: function() {
            this._super();
            this.widget().menu( "option", "items", "> :not(.ui-autocomplete-category)" );
        },
        _renderMenu: function(ul, items) {
            var self = this;
            var current = "";
            $.each(items, function(index, item) {
                if (item.category != current) {
                    ul.append("<li class='ui-autocomplete-category'>"+item.category+"</li>");
                    current = item.category;
                }
                self._renderItemData(ul,item);
            });
        },
    });
    buildCatauto($('#siteName'));

    // buildVersionGrids();
    // buildTXGrids()
    // buildCellGrids();
    getBaseView("ATOLL.CARRIER.VERSION.VIEWS", "version");
    getBaseView("ATOLL.CARRIER.TX.VIEWS", "tx");
    getBaseView("ATOLL.CARRIER.CELL.VIEWS", "cell");
    $('#atollSchemaDropdown').change(function(){
        validate();
        buildVersionGrids();
        $('#siteName').val("");
        $('#searchBtn').attr("disabled", true);
    })
    $('#numOfSectorsInAddCarrierPopup').change(function(){
    	validatecarrier();
    })
     
    $('#fuzeSiteId').on("keyup", function(){
        validate();
    })
    $('#fuzeSiteId').on("change", function(){
        validate();
    })
    $('#siteName').on("keyup", function(){
        validate();
    })
    $('#siteName').on("change", function(){
        siteNameGlobal = $('#siteName').val();
        validate();
    })
    $('#searchBtn').click(function(e){
        initialFlag = false;
        buildVersionGrids();
    });       
    $('#newSiteVersionInPopup').on("keyup", function(){
        validateCopy();
    })
    $('#newSiteVersionInPopup').on("change", function(){
        validateCopy();
    })
    
    $('#newSiteVersionInClonePopup').on("keyup", function(){
        validateClone();
    })
    $('#newSiteVersionInClonePopup').on("change", function(){
        validateClone();
    })
    $('#closeViewManagerPopupBtn').click(function(e){
        backToOriginPage();
    })
    $('#deleteVersionBtn').click(function(e){
        $('#loading').show();
        $('#deleteErrorMsg').hide();
        var grid = $("#versionGrid").data("kendoGrid");
        var selectedItem = grid.dataItem(grid.select());
        var json = {};
        json.siteName = selectedItem.NAME;               
        json.schema = $('#atollSchemaDropdown').val().toString();
    	$.ajax({
            url: '/uuigui/uui/eapp/atoll_pg/deleteSite',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(json),
            success: function (data) {
                $('#loading').hide();
                data = JSON.parse(data)
                if(data == "SUCCESS"){
                    closeDeleteVersionPopup();
                    getNewVersionData();
                }else{
                    $('#deleteErrorMsg').text(data);
                    $('#deleteErrorMsg').show();
                    $('#loading').hide();
                }
            },
            error: function (err) {
                $('#deleteErrorMsg').text(err);
                $('#deleteErrorMsg').show();
                $('#loading').hide();
            }
        });       
    });
    
    $('#deleteTxBtn').click(function(e){
   	 	$('#loading').show();
        $('#deleteTxErrorMsg').hide();
        var grid = $("#transmitterGrid").data("kendoGrid");
        var selectedItem = grid.dataItem(grid.select());
        var json = {};
        json.txId = selectedItem.TX_ID;               
        json.schema = $('#atollSchemaDropdown').val().toString();
        $.ajax({
            url: '/uuigui/uui/eapp/atoll_pg/deleteTx',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(json),
            success: function (data) {
                $('#loading').hide();
                data = JSON.parse(data)
                if(data == "SUCCESS"){
                    closeDeleteTxPopup();
                    getNewTXData();
                }else{
                    $('#deleteTxErrorMsg').text(data);
                    $('#deleteTxErrorMsg').show();
                    $('#loading').hide();
                }
            },
            error: function (err) {
                $('#deleteTxErrorMsg').text(err);
                $('#deleteTxErrorMsg').show();
                $('#loading').hide();
            }
       });       
   });
    
    $('#deleteCellBtn').click(function(e){
   	 	$('#loading').show();
        $('#deleteCellErrorMsg').hide();
        var grid = $("#cellsGrid").data("kendoGrid");
        var selectedItem = grid.dataItem(grid.select());
        var json = {};
        json.cellId = selectedItem.CELL_ID;               
        json.schema = $('#atollSchemaDropdown').val().toString();
        $.ajax({
            url: '/uuigui/uui/eapp/atoll_pg/deleteCell',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(json),
            success: function (data) {
                $('#loading').hide();
                data = JSON.parse(data)
                if(data == "SUCCESS"){
                    closeDeleteCellPopup();
                    getNewCellData();
                }else{
                    $('#deleteCellErrorMsg').text(data);
                    $('#deleteCellErrorMsg').show();
                    $('#loading').hide();
                }
            },
            error: function (err) {
                $('#deleteCellErrorMsg').text(err);
                $('#deleteCellErrorMsg').show();
                $('#loading').hide();
            }
        });       
   });
    
    $('#editSubmitBtn').click(function(e){
        $('#loading').show();
        $('#editErrorMsg').hide();
        // var grid = $("#versionGrid").data("kendoGrid");
        // var selectedItem = grid.dataItem(grid.select());
        var json = {};
        $.each($('#editForm').find('.form-group').find('input'), function(i, v){
        	var val = $(this).val()? $(this).val().trim() : $(this).val();
        	if($(this).hasClass("DOUBLE")){
        		json[$(this).attr("name") + "@" + "DOUBLE" ] = val;
        	}
        	else if($(this).hasClass("SINGLE")){
        		json[$(this).attr("name") + "@" + "SINGLE" ] = val;
        	}
        	else if($(this).hasClass("LONG INTEGER")){
        		json[$(this).attr("name") + "@" + "LONG INTEGER" ] = val;
        	}
        	else if($(this).hasClass("TEXT")){
        		json[$(this).attr("name") + "@" + "TEXT" ] = val;
        	}
        	else{
        		json[$(this).attr("name") + "@" + "DATE" ] = val;
        	}
        });
        json.SCHEMA = $('#atollSchemaDropdown').val().toString();
        $.ajax({
            url: '/uuigui/uui/eapp/atoll_pg/editSite',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(json),
            success: function (data) {
                $('#loading').hide();
                data = JSON.parse(data)
                if(data == "SUCCESS"){                    
                	closeEditSitePopup();
                    getNewVersionData();
                }else{
                    $('#editErrorMsg').text(data);
                    $('#editErrorMsg').show();
                    $('#loading').hide();
                }
            },
            error: function (err) {
                $('#editErrorMsg').text(err);
                $('#editErrorMsg').show();
                $('#loading').hide();
            }
        });
    
    });
    
    $('#editTxSubmitBtn').click(function(e){
        $('#loading').show();
        $('#editTxErrorMsg').hide();
        var json = {};
        $.each($('#editTxForm').find('.form-group').find('input'), function(i, v){
        	if($(this).hasClass("DOUBLE")){
        		json[$(this).attr("name") + "@" + "DOUBLE" ] = $(this).val();
        	}
        	else if($(this).hasClass("SINGLE")){
        		json[$(this).attr("name") + "@" + "SINGLE" ] = $(this).val();
        	}
        	else if($(this).hasClass("LONG INTEGER")){
        		json[$(this).attr("name") + "@" + "LONG INTEGER" ] = $(this).val();
        	}
        	else if($(this).hasClass("SHORT INTEGER")){
        		json[$(this).attr("name") + "@" + "SHORT INTEGER" ] = $(this).val();
        	}
        	else if($(this).hasClass("TEXT")){
        		json[$(this).attr("name") + "@" + "TEXT" ] = $(this).val();
        	}
        	else if($(this).hasClass("BOOLEAN")){
        		json[$(this).attr("name") + "@" + "BOOLEAN" ] = $(this).val();
        	}
        	else{
        		json[$(this).attr("name") + "@" + "DATE" ] = $(this).val();
        	}
        });
        $.each($('#editTxForm').find('.form-group').find('select'), function(i, v){
        		json[$(this).attr("name") + "@" + "BOOLEAN" ] = $(this).val();       	
        });
        json.SCHEMA = $('#atollSchemaDropdown').val().toString();
        $.ajax({
            url: '/uuigui/uui/eapp/atoll_pg/editTx',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(json),
            success: function (data) {
                $('#loading').hide();
                data = JSON.parse(data)
                if(data == "SUCCESS"){
                	closeEditTxPopup();
                    getNewTXData();
                }else{
                    $('#editTxErrorMsg').text(data);
                    $('#editTxErrorMsg').show();
                    $('#loading').hide();
                }
            },
            error: function (err) {
                $('#editTxErrorMsg').text(data);
                $('#editTxErrorMsg').show();
                $('#loading').hide();
            }
        });
    });
       
    $('#editCellSubmitBtn').click(function(e){
        $('#loading').show();
        $('#editCellErrorMsg').hide();      
        var json = {};
        $.each($('#editCellPopup').find('.form-group').find('input'), function(i, v){         
        	if($(this).hasClass("DOUBLE")){
        		json[$(this).attr("name") + "@" + "DOUBLE" ] = $(this).val();
        	}
        	else if($(this).hasClass("SINGLE")){
        		json[$(this).attr("name") + "@" + "SINGLE" ] = $(this).val();
        	}
        	else if($(this).hasClass("LONG INTEGER")){
        		json[$(this).attr("name") + "@" + "LONG INTEGER" ] = $(this).val();
        	}
        	else if($(this).hasClass("SHORT INTEGER")){
        		json[$(this).attr("name") + "@" + "SHORT INTEGER" ] = $(this).val();
        	}
        	else if($(this).hasClass("TEXT")){
        		json[$(this).attr("name") + "@" + "TEXT" ] = $(this).val();
        	}
        	else if($(this).hasClass("BOOLEAN")){
        		json[$(this).attr("name") + "@" + "BOOLEAN" ] = $(this).val();
        	}
        	else{
        		json[$(this).attr("name") + "@" + "DATE" ] = $(this).val();
        	}
        });
        $.each($('#editCellPopup').find('.form-group').find('select'), function(i, v){         
        		json[$(this).attr("name") + "@" + "BOOLEAN"] = $(this).val();            	
        });
        json.SCHEMA = $('#atollSchemaDropdown').val().toString();
        $.ajax({
            url: '/uuigui/uui/eapp/atoll_pg/editCell',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(json),
            success: function (data) {
                $('#loading').hide();
                data = JSON.parse(data)
                if(data == "SUCCESS"){                    
                	closeEditCellPopup();
                    getNewCellData();
                }else{
                    $('#editCellErrorMsg').text(data);
                    $('#editCellErrorMsg').show();
                    $('#loading').hide();
                }
            },
            error: function (err) {
                $('#editCellErrorMsg').text(err);
                $('#editCellErrorMsg').show();
                $('#loading').hide();
            }
        });
    });
    
     $('#cloneSubmitBtn').click(function(e){
        $('#loading').show();
        $('#cloneErrorMsg').hide();
        var grid = $("#versionGrid").data("kendoGrid");
        var selectedItem = grid.dataItem(grid.select());
        var json = {};
        json.siteName = selectedItem.NAME;
        json.oldVersion = selectedItem.VZ_SITE_VERSION;
        json.latitude = selectedItem.LATITUDE + "";
        json.longitude = selectedItem.LONGITUDE + "";
        json.siteRecordId = selectedItem.VZ_SITE_RECORD_ID + "";
        json.newVersion = $('#newSiteVersionInClonePopup').val().trim();
        json.schema = $('#atollSchemaDropdown').val().toString();
        $.ajax({
            url: '/uuigui/uui/eapp/atoll_pg/cloneSite',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(json),
            success: function (data) {
                $('#loading').hide();
                data = JSON.parse(data)
                if(data == "SUCCESS"){
                    closeCopySitePopup();
                    getNewVersionData();
                }else{
                    $('#cloneErrorMsg').text(data);
                    $('#cloneErrorMsg').show();
                    $('#loading').hide();
                }
            },
            error: function (err) {
                $('#cloneErrorMsg').text(err);
                $('#cloneErrorMsg').show();
                $('#loading').hide();
            }
        });
    });
    $('#copySubmitBtn').click(function(e){
        $('#loading').show();
        $('#copyErrorMsg').hide();
        var grid = $("#versionGrid").data("kendoGrid");
        var selectedItem = grid.dataItem(grid.select());
        var json = {};
        json.siteName = selectedItem.NAME;
        json.oldVersion = selectedItem.VZ_SITE_VERSION;
        json.fuzeSiteId = selectedItem.VZ_SITE_INFO_ID + "";
        json.siteRecordId = selectedItem.VZ_SITE_RECORD_ID + "";
        json.newVersion = $('#newSiteVersionInPopup').val().trim();
        json.schema = $('#atollSchemaDropdown').val().toString();
        $.ajax({
            url: '/uuigui/uui/eapp/atoll_pg/copySite',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(json),
            success: function (data) {
                $('#loading').hide();
                data = JSON.parse(data)
                if(data == "SUCCESS"){
                    closeCopySitePopup();
                    getNewVersionData();
                }else{
                    $('#copyErrorMsg').text(data);
                    $('#copyErrorMsg').show();
                    $('#loading').hide();
                }
            },
            error: function (err) {
                $('#copyErrorMsg').text(err);
                $('#copyErrorMsg').show();
                $('#loading').hide();
            }
        });
    });
    $("#addToListInCarrierPopup").click(function(e){
        var val = $('#carriersInAddCarrierPopup').val();
        var dl;
        $.each(carrierDLMapInSite, function(i, v){
            if(v.NAME == val){
                dl = v.DL_FREQUENCY
            }
        });
        $("#addCellFormInCarrierPopup").append('<div class="row cellRow carrierDataRow" style="margin: 2px 17x;padding-top: 6px;border: 1px solid #efefef;">'+
            '<div class="col-sm-5 carrierNameCarrier" style="padding-left: 2px;">'+
                '<label>' + $('#carriersInAddCarrierPopup').val() + '</label>'+
            '</div>'+
            '<div class="col-sm-5 dlCarrier" style="padding-left: 2px;">'+
                '<label>' + dl + '</label>'+
            '</div>'+
            '<div class="col-sm-2 labelInCarrier">'+
                '<select><option>F0</option><option>F1</option><option>F2</option><option>F3</option><option>F4</option><option>F5</option><option>F6</option><option>F7</option><option>F8</option><option>F9</option><option>F10</option><option>F11</option><option>F12</option><option>F13</option><option>F14</option><option>F15</option></select>'+
                '<i style="padding-left: 30px;cursor: pointer;" onclick="deleteOneCarrier(this)" class="fas fa-trash"></i>'+
            '</div>'+
        '</div>');
        validatecarrier(); 
    });

    $("#addToListInCellPopup").click(function(e){
        var val = $('#carriersInAddCellPopup').val();
        var dl;
        $.each(carrierDLMapInCell, function(i, v){
            if(v.NAME == val){
                dl = v.DL_FREQUENCY
            }
        });
        $("#addCellFormInCellPopup").append('<div class="row cellRow cellDataRow" style="margin: 2px 17x;padding-top: 6px;border: 1px solid #efefef;">'+
            '<div class="col-sm-5 carrierNameCarrier" style="padding-left: 2px;">'+
                '<label>' + $('#carriersInAddCellPopup').val() + '</label>'+
            '</div>'+
            '<div class="col-sm-5 dlCarrier" style="padding-left: 2px;">'+
                '<label>' + dl + '</label>'+
            '</div>'+
            '<div class="col-sm-2 labelInCarrier">'+
                '<select><option>F0</option><option>F1</option><option>F2</option><option>F3</option><option>F4</option><option>F5</option><option>F6</option><option>F7</option><option>F8</option><option>F9</option><option>F10</option><option>F11</option><option>F12</option><option>F13</option><option>F14</option><option>F15</option></select>'+
                '<i style="padding-left: 30px;cursor: pointer;" onclick="deleteOneCell(this)" class="fas fa-trash"></i>'+
            '</div>'+
        '</div>');
        validatecells(); 
    });

    $('#addCarrierSubmitBtn').click(function(e){   	
        var grid = $("#versionGrid").data("kendoGrid");
        var selectedItem = grid.dataItem(grid.select());
        var json = {}

        var carrier = [];
        $( ".carrierDataRow" ).each(function( index ) {
            var obj = {};
            obj.template = $(this).find('.carrierNameCarrier').find('label').text();
            obj.label = $(this).find('.labelInCarrier').find('select').val();
            carrier.push(obj);
        });
        json.market = $('#atollSchemaDropdown').val().toString();
        json.site_record_id = selectedItem.VZ_SITE_RECORD_ID + "";
        json.number_of_Sector = $('#numOfSectorsInAddCarrierPopup').val().toString();
        json.station_template = $('#stationTemplateInAddCarrierPopup').val().toString();
        json.carriers = carrier;
        json.update_db = false;
        json.band = $('#bandClassInAddCarrierPopup').val();
        $('#loading').show();
        $.ajax({
            url: '/uuigui/uui/eapp/atoll_pg/addCarrierOnExistingSite',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(json),
            success: function (data) {
                data = JSON.parse(data);
                $('#loading').hide();
                if(data == "SUCCESS"){
                    closeAddCarrierPopup();
                    getNewTXData();
                }else{
                    $('#copyErrorMsgInCarrierPopup').text(data);
                    $('#copyErrorMsgInCarrierPopup').show();
                }
            },
            error: function (err) {
                $('#copyErrorMsgInCarrierPopup').text(data);
                $('#copyErrorMsgInCarrierPopup').show();
                $('#loading').hide();
            }
        });
    });

    $('#addCellSubmitBtn').click(function(e){
        var grid = $("#versionGrid").data("kendoGrid");
        var selectedItem = grid.dataItem(grid.select());
        var json = {}

        var carrier = [];
        $( ".cellDataRow" ).each(function( index ) {
            var obj = {};
            obj.template = $(this).find('.carrierNameCarrier').find('label').text();
            obj.label = $(this).find('.labelInCarrier').find('select').val();
            carrier.push(obj);
        });
        json.market = $('#atollSchemaDropdown').val().toString();
        json.tx_id = $('#txNameInAddCellPopup').val().toString();
        json.site_record_id = selectedItem.VZ_SITE_RECORD_ID + "";
        json.carriers = carrier;
        json.update_db = false;
        json.band = $('#bandClassInAddCellPopup').val();
        $('#loading').show();
        $.ajax({
            url: '/uuigui/uui/eapp/atoll_pg/addCell',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(json),
            success: function (data) {
                $('#loading').hide();
                data = JSON.parse(data);
                if(data == "SUCCESS"){
                    closeAddCellPopup();
                    getNewCellData();
                }else{
                    $('#copyErrorMsgInCellPopup').text(data);
                    $('#copyErrorMsgInCellPopup').show();
                }
            },
            error: function (err) {
                $('#copyErrorMsgInCellPopup').text(data);
                $('#copyErrorMsgInCellPopup').show();
                $('#loading').hide();
            }
        });
    });
    if(receivedSchema && receivedSchema != ""){
        // call from map page and need to populate data
        $('#atollSchemaDropdown').val(receivedSchema).multiselect("refresh");
        $('#siteName').val(receivedSiteName);
        siteNameGlobal = receivedSiteName;
        $('#searchBtn').attr("disabled", false);
        $("#searchBtn").trigger( "click" );
    }
    // $('#loading').hide();
});

function validate(){
    if($('#atollSchemaDropdown').val() != null && $('#atollSchemaDropdown').val() != undefined && $('#siteName').val() != undefined && $('#siteName').val().trim() != ""){
        $('#searchBtn').attr("disabled", false);
    }else{
        $('#searchBtn').attr("disabled", true);
    }
}

function getNewCellData(flag){
    $('#cellsGrid').data('kendoGrid').dataSource.read();
    $('#cellsGrid').data('kendoGrid').refresh();
}
function getNewTXData(flag){
    $('#transmitterGrid').data('kendoGrid').dataSource.read();
    $('#transmitterGrid').data('kendoGrid').refresh();
}
function getNewVersionData(flag){
    $('#versionGrid').data('kendoGrid').dataSource.read();
    $('#versionGrid').data('kendoGrid').refresh();
}

function buildVersionGrids() {
    if($('#versionGrid').data().kendoGrid){
        $('#versionGrid').data().kendoGrid.destroy();
        $('#versionGrid').empty();
    }
    var dataSource = new kendo.data.DataSource({
        type: "odata",
        transport: {
            read: {
                url: CONTEXT_PATH + "/uui/eapp/atoll_pg/versionGrid",
                dataType: "json",
                type: "POST"
            },
            parameterMap: function (data, type) {
                $('<div class="k-loading-mask" id="versionLoadSpin" style="width: 100%; height: 100%; top: 0px; left: 0px;"><span class="k-loading-text">Loading...</span><div class="k-loading-image"></div><div class="k-loading-color"></div></div>').appendTo('#versionGrid .k-grid-content');
                var dataSource = $("#versionGrid").data("kendoGrid").dataSource;
                // Gets the filter from the dataSource
                var filters = dataSource.filter();
                var sort = dataSource.sort();
                data.take = data.take;
                data.skip = data.skip;
                data.filter = JSON.stringify(filters);
                if (sort != undefined) {
                    data.sort = JSON.stringify(sort[0]);
                }
                if (initialFlag == true) {
                    data.initialFlag = "frominitialdontreturndata";
                }
                data.atollSchema = $('#atollSchemaDropdown').val()? $('#atollSchemaDropdown').val().toString() : $('#atollSchemaDropdown').val();
                // data.fuzeSiteId = $('#fuzeSiteId').val();
                data.siteName = siteNameGlobal;
                return data;
            }
        },
        schema: {
            data: function (response) {
                siteName = response && response.data[0] && response.data[0].NAME? response.data[0].NAME : "";
                return response.data; // twitter's response is { "statuses": [ /* results */ ] }
            },
            total: function (data) {
                // $('#loading').hide();
                return data.data.length;
            }
        },
        pageSize: 50,
        serverPaging: false,
        serverFiltering: false,
        serverSorting: false
    });
    $("#versionGrid").kendoGrid({
        autoBind: true,
        height: 210,
        sortable: true,
        pageable: {
            pageSizes: [10, 25, 50, 100, 150, 200, 500],
            input: true,
            numeric: false,
            messages :{}
        },
        columns: versionDisplayColumns,
        dataSource: dataSource,
        dataBound: versionDataBound,
//        change: versionGridChange,
        filterable: {
            // mode: "row",
            operators: {},
            extra: false
        },
        filter: function (e) {
        },
        columnMenu: {
            columns: false
        },
        reorderable: true,
        resizable: true
    });
    $('#versionGrid').find(".k-grid-content").css("height", "149px");
    $('#versionGrid').find(".k-grid-content-locked").css("height", "149px");
}
function buildTXGrids() {
    if($('#transmitterGrid').data().kendoGrid){
        $('#transmitterGrid').data().kendoGrid.destroy();
        $('#transmitterGrid').empty();
    }
    var dataSource = new kendo.data.DataSource({
        type: "odata",
        transport: {
            read: {
                url: CONTEXT_PATH + "/uui/eapp/atoll_pg/txGrid",
                dataType: "json",
                type: "POST"
            },
            parameterMap: function (data, type) {
                $('<div class="k-loading-mask" id="txLoadSpin" style="width: 100%; height: 100%; top: 0px; left: 0px;"><span class="k-loading-text">Loading...</span><div class="k-loading-image"></div><div class="k-loading-color"></div></div>').appendTo('#transmitterGrid .k-grid-content');
                var dataSource = $("#transmitterGrid").data("kendoGrid").dataSource;
                // Gets the filter from the dataSource
                var filters = dataSource.filter();
                var sort = dataSource.sort();
                data.take = data.take;
                data.skip = data.skip;
                data.filter = JSON.stringify(filters);
                if (sort != undefined) {
                    data.sort = JSON.stringify(sort[0]);
                }
                if (initialFlag == true) {
                    data.initialFlag = "frominitialdontreturndata";
                }
                data.atollSchema = $('#atollSchemaDropdown').val()? $('#atollSchemaDropdown').val().toString() : $('#atollSchemaDropdown').val();
                // data.fuzeSiteId = $('#fuzeSiteId').val();
                data.siteName = siteName;
                return data;
            }
        },
        schema: {
            data: function (response) {
                return response.data; // twitter's response is { "statuses": [ /* results */ ] }
            },
            total: function (data) {
                // $('#loading').hide();
                return data.data.length;
            }
        },
        pageSize: 50,
        serverPaging: false,
        serverFiltering: false,
        serverSorting: false
    });

    $("#transmitterGrid").kendoGrid({
        autoBind: true,
        height: 210,
        sortable: true,
        pageable: {
            pageSizes: [10, 25, 50, 100, 150, 200, 500],
            input: true,
            numeric: false,
            messages :{}
        },
        columns: txDisplayColumns,
        dataSource: dataSource,
        dataBound: txDataBound,
        filterable: {
            // mode: "row",
            operators: {},
            extra: false
        },
        filter: function (e) {
        },
        columnMenu: {
            columns: false
        },
        reorderable: true,
        resizable: true
    });
    $('#transmitterGrid').find(".k-grid-content").css("height", "149px");
    $('#transmitterGrid').find(".k-grid-content-locked").css("height", "149px");
}
function buildCellGrids() {
    if($('#cellsGrid').data().kendoGrid){
        $('#cellsGrid').data().kendoGrid.destroy();
        $('#cellsGrid').empty();
    }
    var dataSource = new kendo.data.DataSource({
        type: "odata",
        transport: {
            read: {
                url: CONTEXT_PATH + "/uui/eapp/atoll_pg/cellGrid",
                dataType: "json",
                type: "POST"
            },
            parameterMap: function (data, type) {
                $('<div class="k-loading-mask" id="cellsLoadSpin" style="width: 100%; height: 100%; top: 0px; left: 0px;"><span class="k-loading-text">Loading...</span><div class="k-loading-image"></div><div class="k-loading-color"></div></div>').appendTo('#cellsGrid .k-grid-content');
                var dataSource = $("#cellsGrid").data("kendoGrid").dataSource;
                // Gets the filter from the dataSource
                var filters = dataSource.filter();
                var sort = dataSource.sort();
                data.take = data.take;
                data.skip = data.skip;
                data.filter = JSON.stringify(filters);
                if (sort != undefined) {
                    data.sort = JSON.stringify(sort[0]);
                }
                if (initialFlag == true) {
                    data.initialFlag = "frominitialdontreturndata";
                }
                data.atollSchema = $('#atollSchemaDropdown').val()? $('#atollSchemaDropdown').val().toString() : $('#atollSchemaDropdown').val();
                // data.fuzeSiteId = $('#fuzeSiteId').val();
                data.txId = txId;
                return data;
            }
        },
        schema: {
            data: function (response) {
                return response.data; // twitter's response is { "statuses": [ /* results */ ] }
            },
            total: function (data) {
                return data.data.length;
            }
        },
        pageSize: 50,
        serverPaging: false,
        serverFiltering: false,
        serverSorting: false
    });
    $("#cellsGrid").kendoGrid({
        autoBind: true,
        height: 135,
        sortable: true,
        pageable: {
            pageSizes: [10, 25, 50, 100, 150, 200, 500],
            input: true,
            numeric: false,
            messages :{}
        },
        columns: cellDisplayColumns,
        dataSource: dataSource,
        dataBound: cellDataBound,
        filterable: {
            // mode: "row",
            operators: {},
            extra: false
        },
        filter: function (e) {
        },
        columnMenu: {
            columns: false
        },
        reorderable: true,
        resizable: true
    });
    $('#cellsGrid').find(".k-grid-content").css("height", "75px");
    $('#cellsGrid').find(".k-grid-content-locked").css("height", "75px");
    $('#loading').hide();
}

var preUid, preTxUid, preCellUid;
function versionDataBound(e){
    $("#versionGrid").data('kendoGrid').select('tr:eq(0)');
    var grid = $("#versionGrid").data("kendoGrid");
    var selectedItem = grid.dataItem(grid.select());
    if(selectedItem){
        var options = grid.getOptions();
        var g = _.find(options.columns, function (x) { return selectedItem[x.field] != null && selectedItem[x.field] != "null" && selectedItem[x.field] != undefined && selectedItem[x.field] != "undefined" && selectedItem[x.field] != "" });
        if(grid && g.field){
            grid.lockColumn(g.field);
        }
    }
    siteName = selectedItem? selectedItem.NAME : "";
    // $('#cloneIcon').css("cursor", "pointer");
    $("#versionLoadSpin").remove();
    buildTXGrids();
    var grid = e.sender;
    $("#versionGrid").find('tbody').find("[role='row']").find('td').on("click", function(e){
    	var grid = $("#versionGrid").data("kendoGrid");
        var row = $(e.target).closest("tr");
        
        if (e.target.tagName == "INPUT") {
            // checkbox
            preUid = undefined;
            if ($(e.target).attr('aria-checked') == "false") {
                // select
                grid.clearSelection();
                grid.select(row);
                // $('#cloneIcon').css("cursor", "pointer");
                preUid = $(e.target).closest("tr").attr('data-uid');
                var selectedItem1 = grid.dataItem(row);
                siteName = selectedItem1? selectedItem1.NAME : "";
                buildTXGrids();
            } else {
                // deselect
                grid.clearSelection();
                preUid = undefined;
                return;
                // $('#cloneIcon').css("cursor", "not-allowed");
            }
            return;
        }
        if (preUid == $(e.target).closest("tr").attr('data-uid')) {
            // deselect
            // grid.clearSelection();
            // preUid = undefined;
            return;
            // $('#cloneIcon').css("cursor", "not-allowed");
        } else {
            // select
            grid.clearSelection();
            grid.select(row);
            // $('#cloneIcon').css("cursor", "pointer");
            preUid = $(e.target).closest("tr").attr('data-uid');
            var selectedItem1 = grid.dataItem(row);
            siteName = selectedItem1? selectedItem1.NAME : "";
            buildTXGrids();
        }
    });
}
function txDataBound(e){
    $("#transmitterGrid").data('kendoGrid').select('tr:eq(0)');
    var grid = $("#transmitterGrid").data("kendoGrid");
    var selectedItem = grid.dataItem(grid.select());
    txId = selectedItem? selectedItem.TX_ID : "";
    $("#txLoadSpin").remove();
    if(selectedItem){
        var options = grid.getOptions();
        var g = _.find(options.columns, function (x) { return selectedItem[x.field] != null && selectedItem[x.field] != "null" && selectedItem[x.field] != undefined && selectedItem[x.field] != "undefined" && selectedItem[x.field] != "" });
        grid.lockColumn(g.field);
    }
    buildCellGrids()
    
    var grid = e.sender;
    $("#transmitterGrid").find('tbody').find("[role='row']").find('td').on("click", function(e){
    	var grid = $("#transmitterGrid").data("kendoGrid");
        var row = $(e.target).closest("tr");
        if (e.target.tagName == "INPUT") {
            // checkbox
            preTxUid = undefined;
            if ($(e.target).attr('aria-checked') == "false") {
                // select
                grid.clearSelection();
                grid.select(row);
                // $('#cloneIcon').css("cursor", "pointer");
                preTxUid = $(e.target).closest("tr").attr('data-uid');
                var selectedItem1 = grid.dataItem(row);
                txId = selectedItem1? selectedItem1.TX_ID : "";
                buildCellGrids()
            } else {
                // deselect
                grid.clearSelection();
                preTxUid = undefined;
                return;
                // $('#cloneIcon').css("cursor", "not-allowed");
            }
            return;
        }
        if (preTxUid == $(e.target).closest("tr").attr('data-uid')) {
            // deselect
            // grid.clearSelection();
            // preTxUid = undefined;
            return;
        } else {
            // select
            grid.clearSelection();
            grid.select(row);
            preTxUid = $(e.target).closest("tr").attr('data-uid');
            var selectedItem1 = grid.dataItem(row);
            txId = selectedItem1? selectedItem1.TX_ID : "";
            buildCellGrids()
        }
    });
}
function cellDataBound(e){
    $("#cellsLoadSpin").remove();
    var grid = $("#cellsGrid").data("kendoGrid");
    var selectedItem = grid.dataItem($('#cellsGrid').find('tr:eq(0)'));
    if(selectedItem){
        var options = grid.getOptions();
        var g = _.find(options.columns, function (x) { return selectedItem[x.field] != null && selectedItem[x.field] != "null" && selectedItem[x.field] != undefined && selectedItem[x.field] != "undefined" && selectedItem[x.field] != "" });
        grid.lockColumn(g.field);
    }
    $("#cellsGrid").find('tbody').find("[role='row']").find('td').on("click", function(e){
    	var grid = $("#cellsGrid").data("kendoGrid");
        var row = $(e.target).closest("tr");
        if (e.target.tagName == "INPUT") {
            // checkbox
            preCellUid = undefined;
            if ($(e.target).attr('aria-checked') == "false") {
                // select
                grid.clearSelection();
                grid.select(row);
                // $('#cloneIcon').css("cursor", "pointer");
                preCellUid = $(e.target).closest("tr").attr('data-uid');
            } else {
                // deselect
                grid.clearSelection();
                preCellUid = undefined;
                return;
                // $('#cloneIcon').css("cursor", "not-allowed");
            }
            return;
        }
        if (preCellUid == $(e.target).closest("tr").attr('data-uid')) {
            // deselect
            // grid.clearSelection();
            // preCellUid = undefined;
            return;
        } else {
            // select
            grid.clearSelection();
            grid.select(row);
            preCellUid = $(e.target).closest("tr").attr('data-uid');
            //getNewCellData()
        }
    });
}

function openClone_SitePopup(){
    $('#cloneSitePopup').show();
    $('#alertMask').show();
}

function closeCloneSitePopup(){
    $('#cloneSitePopup').hide();
    $('#alertMask').hide();
}

function openCopySitePopup(){
    $('#copySitePopup').show();
    $('#alertMask').show();
}

function closeCopySitePopup(){
    $('#copySitePopup').hide();
    $('#alertMask').hide();
}

function openAddCellPopup(e){
    var grid = $("#versionGrid").data("kendoGrid");
    var selectedItem = grid.dataItem(grid.select());
    $('#addToListInCellPopup').attr('disabled', true);
    $('#addCellSubmitBtn').attr("disabled",true);
    $('#copyErrorMsgInCellPopup').hide();
    selectedItem = selectedItem? selectedItem : {};
    var txgrid = $("#transmitterGrid").data("kendoGrid");
    var txrow = $(e).closest("tr");
    var txselectedItem = txgrid.dataItem(txrow);
    txselectedItem = txselectedItem? txselectedItem : {};
    $('#siteNameInAddCellPopup').val(selectedItem.NAME);
    $('#txNameInAddCellPopup').val(txselectedItem.TX_ID);
    var json = {}
    json.atollSchema = $('#atollSchemaDropdown').val().toString();
    $("#addCellFormInCellPopup").empty();
    $("#addCellFormInCellPopup").append('<div class="row cellRow" style="margin: 2px 17x;padding-top: 6px;border: 1px solid #efefef;">'+
        '<div class="col-sm-5" style="padding-left: 2px;">'+
            '<label>Carrier Name</label>'+
        '</div>'+
        '<div class="col-sm-5" style="padding-left: 2px;">'+
            '<label>DL Frequency</label>'+
        '</div>'+
        '<div class="col-sm-2" style="padding-left: 2px;">'+
            '<label>Carrier Label</label>'+
        '</div>'+
    '</div>');
    // $('#bandClassInAddCellPopup').html('').multiselect('destroy');
    var $par = $('#bandClassInAddCellPopup').parents(".col-sm-6");
    $('#bandClassInAddCellPopup').parents(".col-sm-6").empty();
    $par.append('<select class="form-control" style="width: 90%;" id="bandClassInAddCellPopup"></select>');
    $.ajax({
        url: '/uuigui/uui/eapp/atoll_pg/getBandClass',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(json),
        success: function (data) {
            var bandClass = data.data;
            $('#bandClassInAddCellPopup').append("<option value=''>-</option>");
            $.each(bandClass, function(i, v){
                $('#bandClassInAddCellPopup').append("<option>" + v.FBAND + "</option>");
            })    
            $('#bandClassInAddCellPopup').multiselect({
                includeSelectAllOption: true,
                enableFiltering:true,
                enableCaseInsensitiveFiltering: true,
                buttonClass: 'btn btn-default whitebg btn-sm',
                numberDisplayed: 1
            });
            $('#bandClassInAddCellPopup').change(function(e){
                // $('#carriersInAddCellPopup').html('').multiselect('destroy');
                var $par = $('#carriersInAddCellPopup').parents(".col-sm-6");
                $('#carriersInAddCellPopup').parents(".col-sm-6").empty();
                $par.append('<select class="form-control" style="width: 90%;" id="carriersInAddCellPopup"></select>');
                $('#carriersInAddCellPopup').append("<option value=''>-</option>");
                $('#carriersInAddCellPopup').multiselect({
                    includeSelectAllOption: true,
                    enableFiltering:true,
                    enableCaseInsensitiveFiltering: true,
                    buttonClass: 'btn btn-default whitebg btn-sm',
                    numberDisplayed: 1
                });
                // $('#dlSpectrumWidthInAddCellPopup').html('').multiselect('destroy');
                var $par1 = $('#dlSpectrumWidthInAddCellPopup').parents(".col-sm-6");
                $('#dlSpectrumWidthInAddCellPopup').parents(".col-sm-6").empty();
                $par1.append('<select class="form-control" style="width: 90%;" id="dlSpectrumWidthInAddCellPopup"></select>');
                $('#addToListInCellPopup').attr('disabled', true);
                var val = $(this).val().toString();
                if(val == ""){
                    $('#dlSpectrumWidthInAddCellPopup').append("<option value=''>-</option>");
                    $('#dlSpectrumWidthInAddCellPopup').multiselect({
                        includeSelectAllOption: true,
                        enableFiltering:true,
                        enableCaseInsensitiveFiltering: true,
                        buttonClass: 'btn btn-default whitebg btn-sm',
                        numberDisplayed: 1
                    });
                    return;
                }
                var json = {}
                json.atollSchema = $('#atollSchemaDropdown').val().toString();
                json.band = val;
                $.ajax({
                    url: '/uuigui/uui/eapp/atoll_pg/getDlWidth',
                    type: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify(json),
                    success: function (data) {
                        var carriers = data.data;
                        $('#dlSpectrumWidthInAddCellPopup').append("<option value=''>-</option>");
                        $.each(carriers, function(i, v){
                            $('#dlSpectrumWidthInAddCellPopup').append("<option>" + v.DL_WIDTH + "</option>");
                        })    
                        $('#dlSpectrumWidthInAddCellPopup').multiselect({
                            includeSelectAllOption: true,
                            enableFiltering:true,
                            enableCaseInsensitiveFiltering: true,
                            buttonClass: 'btn btn-default whitebg btn-sm',
                            numberDisplayed: 1
                        });
                        
                        $('#dlSpectrumWidthInAddCellPopup').change(function(e){
                            var val = $(this).val().toString();
                            // $('#carriersInAddCellPopup').html('').multiselect('destroy');
                            var $par = $('#carriersInAddCellPopup').parents(".col-sm-6");
                            $('#carriersInAddCellPopup').parents(".col-sm-6").empty();
                            $par.append('<select class="form-control" style="width: 90%;" id="carriersInAddCellPopup"></select>');
                            $('#addToListInCellPopup').attr('disabled', true);
                            if(val == ""){
                                $('#carriersInAddCellPopup').append("<option value=''>-</option>");
                                $('#carriersInAddCellPopup').multiselect({
                                    includeSelectAllOption: true,
                                    enableFiltering:true,
                                    enableCaseInsensitiveFiltering: true,
                                    buttonClass: 'btn btn-default whitebg btn-sm',
                                    numberDisplayed: 1
                                });
                                return;
                            }
                            var json = {}
                            json.atollSchema = $('#atollSchemaDropdown').val().toString();
                            json.band = $('#bandClassInAddCellPopup').val().toString();
                            json.dlWidth = val;
                            $.ajax({
                                url: '/uuigui/uui/eapp/atoll_pg/getCarrierDetails',
                                type: 'POST',
                                contentType: 'application/json',
                                data: JSON.stringify(json),
                                success: function (data) {
                                    var carriers = data.data;
                                    carrierDLMapInCell = data.data;
                                    $('#carriersInAddCellPopup').append("<option value=''>-</option>");
                                    $.each(carriers, function(i, v){
                                        $('#carriersInAddCellPopup').append("<option>" + v.NAME + "</option>");
                                    })    
                                    $('#carriersInAddCellPopup').multiselect({
                                        includeSelectAllOption: true,
                                        enableFiltering:true,
                                        enableCaseInsensitiveFiltering: true,
                                        buttonClass: 'btn btn-default whitebg btn-sm',
                                        numberDisplayed: 1
                                    });
                                    $('#carriersInAddCellPopup').change(function(e){
                                        if($('#carriersInAddCellPopup').val() == ""){
                                            $('#addToListInCellPopup').attr('disabled', true);
                                        }else{
                                            $('#addToListInCellPopup').attr('disabled', false);
                                        }
                                    });
                                },
                                error: function (err) {}
                            });
                        });
                    },
                    error: function (err) {}
                });
            });
        },
        error: function (err) {}
    });
    
    
    // $('#dlSpectrumWidthInAddCellPopup').html('').multiselect('destroy');
    var $par = $('#dlSpectrumWidthInAddCellPopup').parents(".col-sm-6");
    $('#dlSpectrumWidthInAddCellPopup').parents(".col-sm-6").empty();
    $par.append('<select class="form-control" style="width: 90%;" id="dlSpectrumWidthInAddCellPopup"></select>');
    $('#dlSpectrumWidthInAddCellPopup').append("<option value=''>-</option>");
    $('#dlSpectrumWidthInAddCellPopup').multiselect({
        includeSelectAllOption: true,
        enableFiltering:true,
        enableCaseInsensitiveFiltering: true,
        buttonClass: 'btn btn-default whitebg btn-sm',
        numberDisplayed: 1
    });
    
    // $('#carriersInAddCellPopup').html('').multiselect('destroy');
    var $par1 = $('#carriersInAddCellPopup').parents(".col-sm-6");
    $('#carriersInAddCellPopup').parents(".col-sm-6").empty();
    $par1.append('<select class="form-control" style="width: 90%;" id="carriersInAddCellPopup"></select>');
    $('#carriersInAddCellPopup').append("<option value=''>-</option>");
    $('#carriersInAddCellPopup').multiselect({
        includeSelectAllOption: true,
        enableFiltering:true,
        enableCaseInsensitiveFiltering: true,
        buttonClass: 'btn btn-default whitebg btn-sm',
        numberDisplayed: 1
    });


    var cellData = $("#cellsGrid").data("kendoGrid").dataSource.data();
    if ($("#cellGridInCellPopup").data("kendoGrid") != undefined) {
        $("#cellGridInCellPopup").data("kendoGrid").destroy();
        $('#cellGridInCellPopup').empty();
    }
    $("#cellGridInCellPopup").kendoGrid({
        autoBind: true,
        // height: 60,
        sortable: true,
        pageable: {
            pageSizes: [10, 25, 50, 100, 150, 200, 500],
            input: true,
            numeric: false,
            messages :{}
        },
        columns: [
            {
                "title": "TECHNOLOGY",
                "field": "VZ_CELL_RAT",
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains"
                    }
                }
            },
            {
                "title": "CELL ID",
                "field": "CELL_ID",
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains"
                    }
                }
            },
            {
                "title": "TYPE",
                "field": "CELL_TYPE",
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains"
                    }
                }
            },
            {
                "title": "CARRIER",
                "field": "CARRIER",
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains"
                    }
                }
            },
            {
                "title": "EQUIPMENT",
                "field": "EQUIPMENT",
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains"
                    }
                }
            }
        ],
        dataSource: {
            data: cellData,
            schema: {
                model: {
                }
            },
            pageSize: 5
        },
        filterable: {
            // mode: "row",
            operators: {},
            extra: false
        },
        filter: function (e) {
        },
        columnMenu: {
            columns: false
        },
        reorderable: true,
        resizable: true
    });
    $('#addCellPopup').show();
    $('#alertMask').show();
}

function closeAddCellPopup(){
    $('#addCellPopup').hide();
    $('#alertMask').hide();
}

function openCloneSitePopup(e){
    var grid = $("#versionGrid").data("kendoGrid");
    var row = $(e).closest("tr");
    var selectedItem = grid.dataItem(row);
    $('#siteNameInClonePopup').val(selectedItem.NAME);
    $('#siteVersionInClonePopup').val(selectedItem.VZ_SITE_VERSION);
    $('#latitudeInClonePopup').val(selectedItem.LATITUDE);  
    $('#longitudeInClonePopup').val(selectedItem.LONGITUDE);
    $('#newSiteVersionInClonePopup').val("");
    openClone_SitePopup();
}

function deleteVersionPopup(e){
    var grid = $("#versionGrid").data("kendoGrid");
    var row = $(e).closest("tr");
    var selectedItem = grid.dataItem(row);
    document.getElementById('deleteSiteName').innerHTML="Are you sure you want to delete the site, all the transmitters, and all the cells for " + String(selectedItem.NAME) + "?";
    $('#deleteVersion').show();
	$('#alertMask').show();
}

function deleteTxPopup(e){
	var grid = $("#transmitterGrid").data("kendoGrid");
    var row = $(e).closest("tr");
    var selectedItem = grid.dataItem(row);
    document.getElementById('deleteTxId').innerHTML="Are you sure you want to delete the transmitter and all the cells for " + String(selectedItem.TX_ID) + "?";
	$('#deleteTx').show();
	$('#alertMask').show();   
}

function deleteCellPopup(e){
	var grid = $("#cellsGrid").data("kendoGrid");
    var row = $(e).closest("tr");
    var selectedItem = grid.dataItem(row);
    document.getElementById('deleteCellId').innerHTML="Are you sure you want to delete cell " + String(selectedItem.CELL_ID) + "?";
	$('#deleteCell').show();
	$('#alertMask').show();   
}

function editVersionPopup(e){
    var grid = $("#versionGrid").data("kendoGrid");
    var row = $(e).closest("tr");
    var selectedItem = grid.dataItem(row);
    $('#editForm').empty();
    var cnt = 0;
    $.each(versionDefaultColumns, function(i, v){
        if(v.title && v.title != "&nbsp;"){
            if(cnt % 4 == 0){
                $('#editForm').append('<div class="row fieldRow" style="margin-bottom: 5px;"></div>');
            }
            var val = selectedItem[v.field] && selectedItem[v.field] != "null"? selectedItem[v.field] : "";
            var label = "";
            if(v.mandatory == true){
                label = '<label for="zipcodeProj" style="padding-right:5px;font-weight:700;">'+ v.title +'</label><span style="color:red;">*</span>';
            }else{
                label = '<label for="zipcodeProj" style="padding-right:5px;font-weight:700;">'+ v.title +'</label>';
            }
            if(v.type == "TEXT" || v.type == "DOUBLE" || v.type == "SINGLE" || v.type == "LONG INTEGER"){
            	var html = '<div class="col-sm-3" ><div class="form-group"><div class="">'+ label;
            	if (v.editable == false){
            		html += '<input id="editInputField-'+ cnt +'" readonly class="form-control '+ v.type +'" name="' + v.field + '" value="' + val + '" style="height: 25px;padding-left: 5px;background-color: #eee;cursor: not-allowed;"></div></div></div>'
            	}
            	else {
            		html += '<input id="editInputField-'+ cnt +'"  class="form-control '+ v.type +'" name="' + v.field + '" value="' + val + '" style="height: 25px;padding-left: 5px;"></div></div></div>'
            	}
            	$('#editForm').find(".fieldRow").last().append(html);
            	$('#editInputField-' + cnt).on("keyup", function(e){
                    // call validation function
                   editValidate();
                  
                });
            }
           
            else if(v.type == "DATE/TIME"){
            	var html = '<div class="col-sm-3" ><div class="form-group">'+ label + '<div class="">';
            	if(v.editable == false){
            		html += '<input name="' + v.field + '" id="datepicker-'+cnt+'" readonly value="'+val+'" title="datepicker" style="width: 100%;background-color: #eee;cursor: not-allowed;" /></div></div></div>';
            	}
            	else{
            		html += '<input name="' + v.field + '" id="datepicker-'+cnt+'" value="'+val+'" title="datepicker" style="width: 100%" /></div></div></div>';

            	}
            	$('#editForm').find(".fieldRow").last().append(html);
                $("#datepicker-" + cnt).kendoDatePicker();
                $('#editInputField-' + cnt).change(function(e){
                    // call validation function
                    editValidate();
                    
                });
            }else if(v.type == "BOOLEAN"){
                val = val? val.toUpperCase() : "";
                var html = '<div class="col-sm-3" ><div class="form-group">'+ label + '<div class="">';
                if(v.editable == false){
                	html += '<select style="width: 100%;height: 25px;border-color: #d1cfcf;" readonly name="' + v.field + '" id="dropdown-'+cnt+'" value="'+val+'" ><option></option><option>TRUE</option><option>FALSE</option></select></div></div></div>';
                }
                else{
                	html += '<select style="width: 100%;height: 25px;border-color: #d1cfcf;" name="' + v.field + '" id="dropdown-'+cnt+'" value="'+val+'" ><option></option><option>TRUE</option><option>FALSE</option></select></div></div></div>';
                }
                $('#editTxForm').find(".fieldRow").last().append(html);
                             
                $('#dropdown-' + cnt).change(function(e){
                    // call validation function
                    editValidate();
                });
            }
            cnt++;
        }
    });
    editValidate();
    $('#editSitePopup').show();
	$('#alertMask').show();
}
function editValidate(){
    var flag = true;
    var titleStr = "";
    var lengthStr = "";
    var numberStr = "";
    $.each($('#editForm').find('.form-group').find('input'), function(i, v){
    	var flagVersion = true;
        var name = $(this).attr("name");
        var val = $(this).val();
        var obj = _.find(versionDefaultColumns, {field: name});
        if (val && val.trim().length > obj.customizedValidation){
        	if (obj.type !== "DATE/TIME"){
        		if (lengthStr == ""){
        			lengthStr = "! The max length for " + obj.title + " is "+ obj.customizedValidation;
            	}
            	else{
            		lengthStr = lengthStr +", " +obj.title + " is "+ obj.customizedValidation;
            	}       		
	        	flag = false;
	        	flagVersion = false;
	        	$(this).css("background-color",'#ffced0');   
        	}         	
        }
        /*if(obj.type === "TEXT"){           
        var patt1 = new RegExp(/^([a-zA-Z0-9_-\s]+)$/);
        if(val.length !== 0 && !patt1.test(val)){              
              $("#editErrorMsg").html(" ! Please enter aplhanumeric characters only.");
              $("#editErrorMsg").show();
              flag = false;
          }  
      	}*/
        if (val.length == 0 && obj.mandatory == true){ 
        	if (titleStr == ""){
        		titleStr = "! Please type a value for " + obj.title;
        	}
        	else{
        		titleStr = titleStr+", " + obj.title;
        	}       	
            flag = false;
            flagVersion = false;
            $(this).css("background-color",'#ffced0');                    	
        }
        if (obj.type.toUpperCase() == "DOUBLE" || (obj.type.toUpperCase()) == "SINGLE" || (obj.type.toUpperCase()) == "LONG INTEGER"){
        	
        	if (val === ""){
        		val = 0;
        	}        	        	     	
        	if (isNaN(val)){
        		if (numberStr == ""){
        			numberStr = "! Please type a number for " + obj.title;
            	}
            	else{
            		numberStr = numberStr +", " +obj.title;
            	}
        		flag = false;
        		flagVersion = false;      		
                $(this).css("background-color",'#ffced0');          		      		
        	}        	
        }
        if (flagVersion === true && obj.editable === true){
	        $(this).css("background-color",'#fff');	      
        }
    });
    if(flag ==false){
    	if (titleStr !== ""){   	
    		titleStr = titleStr + "; ";
    	}
    	if (numberStr !== ""){  
    		numberStr = numberStr + "; ";
    	}
    	if (lengthStr !== ""){  
    		lengthStr = lengthStr + "; ";
    	}
    	$('#editSubmitBtn').attr("disabled", true);
    	$('#editErrorMsg').text(titleStr +"  "+ numberStr +"  "+ lengthStr);
    	$('#editErrorMsg').show();
    	return false;
    }else{
    	$('#editSubmitBtn').attr("disabled", false);
    	$('#editErrorMsg').hide();
    }
}

function editTxValidate(){
    var flag = true;
    var titleStr = "";
    var selectStr = "";
    var lengthStr = "";
    var numberStr = "";
    $.each($('#editTxForm').find('.form-group').find('input'), function(i, v){
    	var flagTx = true;
        var name = $(this).attr("name");
        var val = $(this).val();
        var obj = _.find(txDefaultColumns, {field: name});
        
        if (val.length > obj.customizedValidation){
        	if (obj.type !== "DATE/TIME"){
        		if (lengthStr == ""){
        			lengthStr = "! The max length for " + obj.title + " is "+ obj.customizedValidation;
            	}
            	else{
            		lengthStr = lengthStr +", " +obj.title + " is "+ obj.customizedValidation;
            	}       	
	        	flag = false;
	        	flagTx = false;
	        	$(this).css("background-color",'#ffced0');
        	}       	
        }
        /*if(obj.type === "TEXT"){           
        var patt1 = new RegExp(/^([a-zA-Z0-9_-\s]+)$/);
        if(val.length !== 0 && !patt1.test(val)){              
              $("#editErrorMsg").html(" ! Please enter aplhanumeric characters only.");
              $("#editErrorMsg").show();
              flag = false;
          }  
      	}*/
    
        if (val.length == 0 && obj.mandatory == true && obj.editable == true){
        	if(obj.type=="TEXT" ){
	        	if (titleStr == ""){
	        		titleStr = "! Please type a value for " + obj.title;
	        	}
	        	else{
	        		titleStr = titleStr+", " + obj.title;
	        	}
        	}
        	else if(obj.type =="BOOLEAN" && obj.editable == true){
        		if (selectStr == ""){
	        		selectStr = "! Please select a value for " + obj.title;
	        	}
	        	else{
	        		selectStr = selectStr+", " + obj.title;
	        	}
        	}
	            flag = false;
	            flagTx = false;
	            $(this).css("background-color",'#ffced0');  
        	        	
        }
        
        if (obj.type.toUpperCase() == "DOUBLE" || (obj.type.toUpperCase()) == "SINGLE" || (obj.type.toUpperCase()) == "LONG INTEGER" || (obj.type.toUpperCase()) == "SHORT INTEGER"){
        	
        	if (val === ""){
        		val = 0;
        	}        	
        	       	
        	if (isNaN(val)){
        		if (numberStr == ""){
        			numberStr = "! Please type a number for " + obj.title;
            	}
            	else{
            		numberStr = numberStr +", " +obj.title;
            	}
        		flag = false;
        		flagTx = false;       		
                $(this).css("background-color",'#ffced0');      		      		
        	}        	
        }
        if (flagTx === true && obj.editable === true){
	        $(this).css("background-color",'#fff');	      
        }
    });
    if(flag ==false){
    	if (titleStr !== ""){   	
    		titleStr = titleStr + "; ";
    	}
    	if (selectStr !== ""){   	
    		selectStr = selectStr + "; ";
    	}
    	if (numberStr !== ""){  
    		numberStr = numberStr + "; ";
    	}
    	if (lengthStr !== ""){  
    		lengthStr = lengthStr + "; ";
    	}
    	$('#editTxSubmitBtn').attr("disabled", true);
    	$('#editTxErrorMsg').text(titleStr +"  "+ numberStr +"  "+ lengthStr + "  "+ selectStr);
        $('#editTxErrorMsg').show();
    	return false;
    }else{
    	$('#editTxSubmitBtn').attr("disabled", false);
    	$('#editTxErrorMsg').hide();
    }   
}

function editCellValidate(){
    var flag = true;
    var titleStr = "";
    var lengthStr = "";
    var numberStr = "";
    $.each($('#editCellForm').find('.form-group').find('input'), function(i, v){
    	var flagCell = true;
        var name = $(this).attr("name");
        var val = $(this).val();
        var obj = _.find(cellDefaultColumns, {field: name});
        if (val.length > obj.customizedValidation){
        	if (obj.type !== "DATE/TIME"){
        		if (lengthStr == ""){
        			lengthStr = "! The max length for " + obj.title + " is "+ obj.customizedValidation;
            	}
            	else{
            		lengthStr = lengthStr +", " +obj.title + " is "+ obj.customizedValidation;
            	}      		
	        	flag = false;
	        	flagCell = false;
	        	$(this).css("background-color",'#ffced0');	        	
        	}       	
        }
        /*if(obj.type === "TEXT"){           
        var patt1 = new RegExp(/^([a-zA-Z0-9_-\s]+)$/);
        if(val.length !== 0 && !patt1.test(val)){              
              $("#editErrorMsg").html(" ! Please enter aplhanumeric characters only.");
              $("#editErrorMsg").show();
              flag = false;
          }  
      	}*/
        if (val.length == 0 && obj.mandatory == true){ 
        	if (titleStr == ""){
        		titleStr = "! Please type a value for " + obj.title;
        	}
        	else{
        		titleStr = titleStr+", " + obj.title;
        	}      	
            flag = false;
            flagCell = false;
        	$(this).css("background-color",'#ffced0');       	
        }
        if (obj.type.toUpperCase() == "DOUBLE" || (obj.type.toUpperCase()) == "SINGLE" || (obj.type.toUpperCase()) == "LONG INTEGER" || (obj.type.toUpperCase()) == "SHORT INTEGER"){
        	
        	if (val === ""){
        		val = 0;
        	}        	     	
        	if (isNaN(val)){
        		if (numberStr == ""){
        			numberStr = "! Please type a number for " + obj.title;
            	}
            	else{
            		numberStr = numberStr +", " +obj.title;
            	}
        		flag = false;
        		flagTx = false;       		
                $(this).css("background-color",'#ffced0');      		
        	}        	
        }
        if (flagCell === true && obj.editable == true){
	        $(this).css("background-color",'#fff');
        }
    });
    if(flag ==false){
    	if (titleStr !== ""){   	
    		titleStr = titleStr + "; ";
    	}
    	if (numberStr !== ""){  
    		numberStr = numberStr + "; ";
    	}
    	if (lengthStr !== ""){  
    		lengthStr = lengthStr + "; ";
    	}
    	$('#editCellSubmitBtn').attr("disabled", true);
    	$('#editCellErrorMsg').text(titleStr +"  "+ numberStr +"  "+ lengthStr);   	
        $('#editCellErrorMsg').show();
    }else{
    	$('#editCellSubmitBtn').attr("disabled", false);
    	$('#editCellErrorMsg').hide();
    }
}
function closeEditSitePopup(){
	$('#editSitePopup').hide();
    $('#alertMask').hide();
}

function editTxPopup(e){
    var grid = $("#transmitterGrid").data("kendoGrid");
    var row = $(e).closest("tr");
    var selectedItem = grid.dataItem(row);
    $('#editTxForm').empty();
    var cnt = 0;
    //editTxValidate();
    $.each(txDefaultColumns, function(i, v){
        if(v.title && v.title != "&nbsp;"){
            if(cnt % 4 == 0){
                $('#editTxForm').append('<div class="row fieldRow" style="margin-bottom: 5px;"></div>');
            }
            var val = selectedItem[v.field] && selectedItem[v.field] != "null"? selectedItem[v.field] : "";
            var label = "";
            if(v.mandatory == true){
                label = '<label for="zipcodeProj" style="padding-right:5px;font-weight:700;">'+ v.title +'</label><span style="color:red;">*</span>';
            }else{
                label = '<label for="zipcodeProj" style="padding-right:5px;font-weight:700;">'+ v.title +'</label>';
            }
            if(v.type == "TEXT" || v.type == "DOUBLE" || v.type == "SINGLE" || v.type == "LONG INTEGER" || v.type == "SHORT INTEGER"){
            	var html = '<div class="col-sm-3" ><div class="form-group"><div class="">'+ label;
            	if (v.editable == false){
            		html +=  '<input id="editTxInputField-'+ cnt +'" readonly class="form-control '+ v.type +'" name="' + v.field + '" value="' + val + '" style="height: 25px;padding-left: 5px;background-color: #eee;cursor:not-allowed;"></div></div></div>';
            	}
            	else{
            		html +=  '<input id="editTxInputField-'+ cnt +'" class="form-control '+ v.type +'" name="' + v.field + '" value="' + val + '" style="height: 25px;padding-left: 5px;"></div></div></div>';
            	}
            	  $('#editTxForm').find(".fieldRow").last().append(html);
                  
                  $('#editTxInputField-' + cnt).on("keyup", function(e){
                      // call validation function
                      editTxValidate();
                  });
            }                   
            else if(v.type == "DATE/TIME"){
            	var html = '<div class="col-sm-3" ><div class="form-group">'+ label + '<div class="">';
            	if(v.editable == false){
            		html += '<input name="' + v.field + '" readonly id="datepicker-'+cnt+'" value="'+val+'" title="datepicker" style="width: 100%;background-color: #eee;cursor: not-allowed;" /></div></div></div>';
            	}
            	else{
            		html += '<input name="' + v.field + '" id="datepicker-'+cnt+'" value="'+val+'" title="datepicker" style="width: 100%" /></div></div></div>';
            	}
            	$('#editTxForm').find(".fieldRow").last().append(html);           	
                $("#datepicker-" + cnt).kendoDatePicker();
                $('#editTxInputField-' + cnt).change(function(e){
                    // call validation function
                    editTxValidate();
                });
            }else if(v.type == "BOOLEAN" && v.field == "ACTIVE"){
            	var html = '<div class="col-sm-3" ><div class="form-group"><div class="">'+ label;
            	if (v.editable == false){
            		html += '<input id="editTxInputField-'+ cnt +'" readonly class="form-control '+ v.type +'" name="' + v.field + '" value="' + val + '" style="height: 25px;padding-left: 5px;background-color: #eee;cursor: not-allowed;"></div></div></div>';	
            	}
            	else{
            		html += '<input id="editTxInputField-'+ cnt +'" class="form-control '+ v.type +'" name="' + v.field + '" value="' + val + '" style="height: 25px;padding-left: 5px;"></div></div></div>';	
            	}
            	$('#editTxForm').find(".fieldRow").last().append(html);           	
        
                $('#editTxInputField-' + cnt).on("keyup", function(e){
                    // call validation function
                    editTxValidate();
                });
            }
            cnt++;
        }
    });
    editTxValidate();
    $('#editTxPopup').show();
	$('#alertMask').show();
}
function closeEditTxPopup(){
	$('#editTxPopup').hide();
    $('#alertMask').hide();
}
function editCellPopup(e){
    var grid = $("#cellsGrid").data("kendoGrid");
    var row = $(e).closest("tr");
    var selectedItem = grid.dataItem(row);
    $('#editCellForm').empty();
    var cnt = 0;
    $.each(cellDefaultColumns, function(i, v){
        if(v.title && v.title != "&nbsp;"){
            if(cnt % 4 == 0){
                $('#editCellForm').append('<div class="row fieldRow" style="margin-bottom: 5px;"></div>');
            }
            var val = selectedItem[v.field] && selectedItem[v.field] != "null"? selectedItem[v.field] : "";
            var label = "";
            if(v.mandatory == true){
                label = '<label for="zipcodeProj" style="padding-right:5px;font-weight:700;">'+ v.title +'</label><span style="color:red;">*</span>';
            }else{
                label = '<label for="zipcodeProj" style="padding-right:5px;font-weight:700;">'+ v.title +'</label>';
            }
           if(v.field == "VZ_CARRIER_LABEL"){
            	var html = '<div class="col-sm-3" ><div class="form-group">'+ label + '<div class="">';
            	html += '<select style="width: 100%;height: 25px;border-color: #d1cfcf;" name="' + v.field + '" id="cellCarrierLabeldropdown-'+cnt+'">';
            	for (var i =0; i <= 10;i++){
            		if (val == 'F'+i){
            			html +='<option value="F' + i + '" selected="selected">F' + i + '</option>';
            		} 
            		else{
            			html +='<option value="F' + i + '">F' + i + '</option>';
            		}       
            	}
            	$('#editCellForm').find(".fieldRow").last().append(html);
            
                $('#dropdown-' + cnt).change(function(e){
                    // call validation function
                    editCellValidate();
                });                   
            }
           else if(v.type == "TEXT" || v.type == "DOUBLE" || v.type == "SINGLE" || v.type == "LONG INTEGER" || v.type == "SHORT INTEGER"){
        	   var html = '<div class="col-sm-3"><div class="form-group"><div class="">'+ label;
        	   if (v.editable == false){
        		   html +=  '<input id="editCellInputField-'+ cnt +'" readonly class="form-control '+ v.type +'" name="' + v.field + '" value="' + val + '" style="height: 25px;padding-left: 5px;background-color: #eee;cursor:not-allowed;"></div></div></div>';
        	   }
        	   else{
        		   html +=  '<input id="editCellInputField-'+ cnt +'"  class="form-control '+ v.type +'" name="' + v.field + '" value="' + val + '" style="height: 25px;padding-left: 5px;"></div></div></div>';  
        	   }
        	   $('#editCellForm').find(".fieldRow").last().append(html);
        	   $('#editCellInputField-' + cnt).on("keyup", function(e){
                   // call validation function
                   editCellValidate();
               });
        	  }          
            else if(v.type == "DATE/TIME"){
            	var html = '<div class="col-sm-3"><div class="form-group">'+ label +'<div class="">';
            	if (v.editable == false){
            		html += '<input name="' + v.field + '" id="datepicker-'+cnt+'" readonly value="'+val+'" title="datepicker" style="width: 100%;background-color: #eee;cursor: not-allowed;" /></div></div></div>';
            	}
            	else{
            		html += '<input name="' + v.field + '" id="datepicker-'+cnt+'" value="'+val+'" title="datepicker" style="width: 100%" /></div></div></div>';
	
            	}
            	$('#editCellForm').find(".fieldRow").last().append(html);
            	          	
                $("#datepicker-" + cnt).kendoDatePicker();
                $('#editCellInputField-' + cnt).change(function(e){
                    // call validation function
                    editCellValidate();
                });
            }else if(v.type == "BOOLEAN" && v.field == "ACTIVE"){
            	var html = '<div class="col-sm-3"><div class="form-group"><div class="">'+ label;
            	if (v.editable == false){
            		html += '<input id="editCellInputField-'+ cnt +'" readonly class="form-control '+ v.type +'" name="' + v.field + '" value="' + val + '" style="height: 25px;padding-left: 5px;background-color: #eee;cursor: not-allowed;"></div></div></div>';
            	}
            	else{
            		html += '<input id="editCellInputField-'+ cnt +'" class="form-control '+ v.type +'" name="' + v.field + '" value="' + val + '" style="height: 25px;padding-left: 5px;"></div></div></div>';

            	}
            	$('#editCellForm').find(".fieldRow").last().append(html);
            	
                $('#editCellInputField-' + cnt).on("keyup", function(e){
                    // call validation function
                    editCellValidate();
                });
                /*$('#editCellForm').find(".fieldRow").last().append('<div class="col-sm-3" >'+
                    '<div class="form-group">'+ 
                        label +
                        '<div class="">'+
                            '<select style="width: 100%;height: 25px;border-color: #d1cfcf;" name="' + v.field + '" id="dropdown-'+cnt+'" value="'+val+'" >'+
                                '<option></option>'+
                                '<option>TRUE</option>'+
                                '<option>FALSE</option>'+
                            '</select>'+
                        '</div>'+
                    '</div>'+
                '</div>');
                $('#dropdown-' + cnt).change(function(e){
                    // call validation function
                    editCellValidate();
                });
                if(val == '-1' || val == 0){
                    $('#dropdown-' + cnt).val('FALSE');
                }else if(val == '1' || val == 1){
                    $('#dropdown-' + cnt).val('TRUE');
                }*/
            }
            cnt++;
        }
    });
    editCellValidate();
    $('#editCellPopup').show();
	$('#alertMask').show();
}
function closeEditCellPopup(){
	$('#editCellPopup').hide();
    $('#alertMask').hide();
}

function openAddCarrierPopup(e){
    var grid = $("#versionGrid").data("kendoGrid");
    var row = $(e).closest("tr");
    var selectedItem = grid.dataItem(row);
    $('#siteNameInAddCarrierPopup').val(selectedItem.NAME);
    $('#addCarrierSubmitBtn').attr("disabled",true);
    $('#addToListInCarrierPopup').attr('disabled', true);
    $('#copyErrorMsgInCarrierPopup').hide();
    var json = {}
    json.atollSchema = $('#atollSchemaDropdown').val().toString();
    $("#addCellFormInCarrierPopup").empty();
    $("#addCellFormInCarrierPopup").append('<div class="row cellRow" style="margin: 2px 17x;padding-top: 6px;border: 1px solid #efefef;">'+
        '<div class="col-sm-5" style="padding-left: 2px;">'+
            '<label>Carrier Name</label>'+
        '</div>'+
        '<div class="col-sm-5" style="padding-left: 2px;">'+
            '<label>DL Frequency</label>'+
        '</div>'+
        '<div class="col-sm-2" style="padding-left: 2px;">'+
            '<label>Carrier Label</label>'+
        '</div>'+
    '</div>');
    // $('#bandClassInAddCarrierPopup').html('').multiselect('destroy');
    var $par = $('#bandClassInAddCarrierPopup').parents(".col-sm-6");
    $('#bandClassInAddCarrierPopup').parents(".col-sm-6").empty();
    $par.append('<select class="form-control" style="width: 90%;" id="bandClassInAddCarrierPopup"></select>');
    $.ajax({
        url: '/uuigui/uui/eapp/atoll_pg/getBandClass',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(json),
        success: function (data) {
            var bandClass = data && data.data? data.data : [];
            $('#bandClassInAddCarrierPopup').append("<option value=''>-</option>");
            $.each(bandClass, function(i, v){
                $('#bandClassInAddCarrierPopup').append("<option>" + v.FBAND + "</option>");
            });

            $('#bandClassInAddCarrierPopup').multiselect({
                includeSelectAllOption: true,
                enableFiltering:true,
                enableCaseInsensitiveFiltering: true,
                buttonClass: 'btn btn-default whitebg btn-sm',
                numberDisplayed: 1
            });

            $('#bandClassInAddCarrierPopup').change(function(e){
                var val = $(this).val().toString();
                // $('#dlSpectrumWidthInAddCarrierPopup').html('').multiselect('destroy');
                // $('#carriersInAddCarrierPopup').html('').multiselect('destroy');
                var $par = $('#dlSpectrumWidthInAddCarrierPopup').parents(".col-sm-6");
                $('#dlSpectrumWidthInAddCarrierPopup').parents(".col-sm-6").empty();
                $par.append('<select class="form-control" style="width: 90%;" id="dlSpectrumWidthInAddCarrierPopup"></select>');
                
                var $par1 = $('#carriersInAddCarrierPopup').parents(".col-sm-6");
                $('#carriersInAddCarrierPopup').parents(".col-sm-6").empty();
                $par1.append('<select class="form-control" style="width: 90%;" id="carriersInAddCarrierPopup"></select>');
                $('#carriersInAddCarrierPopup').append("<option value=''>-</option>");
                $('#carriersInAddCarrierPopup').multiselect({
                    includeSelectAllOption: true,
                    enableFiltering:true,
                    enableCaseInsensitiveFiltering: true,
                    buttonClass: 'btn btn-default whitebg btn-sm',
                    numberDisplayed: 1
                });
                $('#addToListInCarrierPopup').attr('disabled', true);
                // $('#stationTemplateInAddCarrierPopup').html('').multiselect('destroy');
                var $par1 = $('#stationTemplateInAddCarrierPopup').parents(".col-sm-6");
                $('#stationTemplateInAddCarrierPopup').parents(".col-sm-6").empty();
                $par1.append('<select class="form-control" style="width: 90%;" id="stationTemplateInAddCarrierPopup"></select>');
                $('#stationTemplateInAddCarrierPopup').append("<option value=''>-</option>");
                $('#stationTemplateInAddCarrierPopup').multiselect({
                    includeSelectAllOption: true,
                    enableFiltering:true,
                    enableCaseInsensitiveFiltering: true,
                    buttonClass: 'btn btn-default whitebg btn-sm',
                    numberDisplayed: 1
                });
                if(val == ""){
                    $('#dlSpectrumWidthInAddCarrierPopup').append("<option value=''>-</option>");
                    $('#dlSpectrumWidthInAddCarrierPopup').multiselect({
                        includeSelectAllOption: true,
                        enableFiltering:true,
                        enableCaseInsensitiveFiltering: true,
                        buttonClass: 'btn btn-default whitebg btn-sm',
                        numberDisplayed: 1
                    });
                    return;
                }
                var json = {}
                json.atollSchema = $('#atollSchemaDropdown').val().toString();
                json.band = val;
                $.ajax({
                    url: '/uuigui/uui/eapp/atoll_pg/getDlWidth',
                    type: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify(json),
                    success: function (data) {
                        var carriers = data && data.data? data.data : [];
                        $('#dlSpectrumWidthInAddCarrierPopup').append("<option value=''>-</option>");
                        $.each(carriers, function(i, v){
                            $('#dlSpectrumWidthInAddCarrierPopup').append("<option>" + v.DL_WIDTH + "</option>");
                        })    
                        $('#dlSpectrumWidthInAddCarrierPopup').multiselect({
                            includeSelectAllOption: true,
                            enableFiltering:true,
                            enableCaseInsensitiveFiltering: true,
                            buttonClass: 'btn btn-default whitebg btn-sm',
                            numberDisplayed: 1
                        });
                        
                        $('#dlSpectrumWidthInAddCarrierPopup').change(function(e){
                            var val = $(this).val().toString();
                            // $('#carriersInAddCarrierPopup').html('').multiselect('destroy');
                            // $('#stationTemplateInAddCarrierPopup').html('').multiselect('destroy');
                            var $par = $('#carriersInAddCarrierPopup').parents(".col-sm-6");
                            $('#carriersInAddCarrierPopup').parents(".col-sm-6").empty();
                            $par.append('<select class="form-control" style="width: 90%;" id="carriersInAddCarrierPopup"></select>');
                            var $par1 = $('#stationTemplateInAddCarrierPopup').parents(".col-sm-6");
                            $('#stationTemplateInAddCarrierPopup').parents(".col-sm-6").empty();
                            $par1.append('<select class="form-control" style="width: 90%;" id="stationTemplateInAddCarrierPopup"></select>');
                            $('#addToListInCarrierPopup').attr('disabled', true);
                            if(val == ""){
                                $('#carriersInAddCarrierPopup').append("<option value=''>-</option>");
                                $('#carriersInAddCarrierPopup').multiselect({
                                    includeSelectAllOption: true,
                                    enableFiltering:true,
                                    enableCaseInsensitiveFiltering: true,
                                    buttonClass: 'btn btn-default whitebg btn-sm',
                                    numberDisplayed: 1
                                });
                                $('#stationTemplateInAddCarrierPopup').append("<option value=''>-</option>");
                                $('#stationTemplateInAddCarrierPopup').multiselect({
                                    includeSelectAllOption: true,
                                    enableFiltering:true,
                                    enableCaseInsensitiveFiltering: true,
                                    buttonClass: 'btn btn-default whitebg btn-sm',
                                    numberDisplayed: 1
                                });
                                return;
                            }
                            var json = {}
                            json.atollSchema = $('#atollSchemaDropdown').val().toString();
                            json.band = $('#bandClassInAddCarrierPopup').val().toString();
                            json.dlWidth = val;
                            
                            $.ajax({
                                url: '/uuigui/uui/eapp/atoll_pg/getCarrierDetails',
                                type: 'POST',
                                contentType: 'application/json',
                                data: JSON.stringify(json),
                                success: function (data) {
                                    // $('#carriersInAddCarrierPopup').html('').multiselect('destroy');
                                    var $par = $('#carriersInAddCarrierPopup').parents(".col-sm-6");
                                    $('#carriersInAddCarrierPopup').parents(".col-sm-6").empty();
                                    $par.append('<select class="form-control" style="width: 90%;" id="carriersInAddCarrierPopup"></select>');
                                    var carriers = data && data.data? data.data : [];
                                    carrierDLMapInSite = data.data;
                                    $('#carriersInAddCarrierPopup').append("<option value=''>-</option>");
                                    $.each(carriers, function(i, v){
                                        $('#carriersInAddCarrierPopup').append("<option>" + v.NAME + "</option>");
                                    })    
                                    $('#carriersInAddCarrierPopup').multiselect({
                                        includeSelectAllOption: true,
                                        enableFiltering:true,
                                        enableCaseInsensitiveFiltering: true,
                                        buttonClass: 'btn btn-default whitebg btn-sm',
                                        numberDisplayed: 1
                                    });
                                    $('#carriersInAddCarrierPopup').change(function(e){
                                        if($('#carriersInAddCarrierPopup').val() == ""){
                                            $('#addToListInCarrierPopup').attr('disabled', true);
                                        }else{
                                            $('#addToListInCarrierPopup').attr('disabled', false);
                                        }
                                    });
                                },
                                error: function (err) {}
                            });

                            $.ajax({
                                url: '/uuigui/uui/eapp/atoll_pg/getStationTemplates',
                                type: 'POST',
                                contentType: 'application/json',
                                data: JSON.stringify(json),
                                success: function (data) {
                                    var stationTemplate = data && data.data? data.data : [];
                                    stationTemplateInCarrier = data.data;
                                    $('#stationTemplateInAddCarrierPopup').append("<option value=''>-</option>");
                                    $.each(stationTemplate, function(i, v){
                                        $('#stationTemplateInAddCarrierPopup').append("<option>" + v.NAME + "</option>");
                                    })    
                                    $('#stationTemplateInAddCarrierPopup').multiselect({
                                        includeSelectAllOption: true,
                                        enableFiltering:true,
                                        enableCaseInsensitiveFiltering: true,
                                        buttonClass: 'btn btn-default whitebg btn-sm',
                                        numberDisplayed: 1
                                    });
                                    $('#stationTemplateInAddCarrierPopup').change(function(e){
                                        var val = $(this).val();
                                        var sector;
                                        $.each(stationTemplateInCarrier, function(i, v){
                                            if(v.NAME == val){
                                                sector = v.NUM_SECTORS;
                                            }
                                        });
                                        $('#numOfSectorsInAddCarrierPopup').val(sector).multiselect('refresh');
                                        validatecarrier();
                                    });
                                },
                                error: function (err) {}
                            });
                        });
                    },
                    error: function (err) {}
                });
            });
        },
        error: function (err) {}
    });
    
    // $('#dlSpectrumWidthInAddCarrierPopup').html('').multiselect('destroy');
    var $par = $('#dlSpectrumWidthInAddCarrierPopup').parents(".col-sm-6");
    $('#dlSpectrumWidthInAddCarrierPopup').parents(".col-sm-6").empty();
    $par.append('<select class="form-control" style="width: 90%;" id="dlSpectrumWidthInAddCarrierPopup"></select>');
    $('#dlSpectrumWidthInAddCarrierPopup').append("<option value=''>-</option>");
    $('#dlSpectrumWidthInAddCarrierPopup').multiselect({
        includeSelectAllOption: true,
        enableFiltering:true,
        enableCaseInsensitiveFiltering: true,
        buttonClass: 'btn btn-default whitebg btn-sm',
        numberDisplayed: 1
    });
    
    // $('#carriersInAddCarrierPopup').html('').multiselect('destroy');
    var $par1 = $('#carriersInAddCarrierPopup').parents(".col-sm-6");
    $('#carriersInAddCarrierPopup').parents(".col-sm-6").empty();
    $par1.append('<select class="form-control" style="width: 90%;" id="carriersInAddCarrierPopup"></select>');
    $('#carriersInAddCarrierPopup').append("<option value=''>-</option>");
    $('#carriersInAddCarrierPopup').multiselect({
        includeSelectAllOption: true,
        enableFiltering:true,
        enableCaseInsensitiveFiltering: true,
        buttonClass: 'btn btn-default whitebg btn-sm',
        numberDisplayed: 1
    });

    // $('#stationTemplateInAddCarrierPopup').html('').multiselect('destroy');
    var $par = $('#stationTemplateInAddCarrierPopup').parents(".col-sm-6");
    $('#stationTemplateInAddCarrierPopup').parents(".col-sm-6").empty();
    $par.append('<select class="form-control" style="width: 90%;" id="stationTemplateInAddCarrierPopup"></select>');
    $('#stationTemplateInAddCarrierPopup').append("<option value=''>-</option>");
    $('#stationTemplateInAddCarrierPopup').multiselect({
        includeSelectAllOption: true,
        enableFiltering:true,
        enableCaseInsensitiveFiltering: true,
        buttonClass: 'btn btn-default whitebg btn-sm',
        numberDisplayed: 1
    });

    // $('#numOfSectorsInAddCarrierPopup').html('').multiselect('destroy');
    var $par1 = $('#numOfSectorsInAddCarrierPopup').parents(".col-sm-6");
    $('#numOfSectorsInAddCarrierPopup').parents(".col-sm-6").empty();
    $par1.append('<select class="form-control" style="width: 90%;" id="numOfSectorsInAddCarrierPopup"></select>');
    $('#numOfSectorsInAddCarrierPopup').append("<option value=''>-</option>");
    for(var i = 1; i <= 6; i++){
        $('#numOfSectorsInAddCarrierPopup').append("<option>" + i + "</option>");
    }
    $('#numOfSectorsInAddCarrierPopup').multiselect({
        includeSelectAllOption: true,
        enableFiltering:true,
        enableCaseInsensitiveFiltering: true,
        buttonClass: 'btn btn-default whitebg btn-sm',
        numberDisplayed: 1
    });

    var txData = $("#transmitterGrid").data("kendoGrid").dataSource.data();
    if ($("#txGridInCarrierPopup").data("kendoGrid") != undefined) {
        $("#txGridInCarrierPopup").data("kendoGrid").destroy();
        $('#txGridInCarrierPopup').empty();
    }
    $("#txGridInCarrierPopup").kendoGrid({
        autoBind: true,
        // height: 60,
        sortable: true,
        pageable: {
            pageSizes: [10, 25, 50, 100, 150, 200, 500],
            input: true,
            numeric: false,
            messages :{}
        },
        columns: [
            {
                "title": "TX ID",
                "field": "TX_ID",
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains"
                    }
                },
                width: "300px"
            },
            {
                "title": "FBAND",
                "field": "FBAND",
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains"
                    }
                },
                width: "100px"
            },
            {
                "title": "ANTENNA NAME",
                "field": "ANTENNA_NAME",
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains"
                    }
                },
                width: "300px"
            },
            {
                "title": "Height",
                "field": "HEIGHT",
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains"
                    }
                },
                width: "150px"
            },
            {
                "title": "Azimuth",
                "field": "AZIMUT",
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains"
                    }
                },
                width: "100px"
            },
            {
                "title": "Tilt",
                "field": "TILT",
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains"
                    }
                },
                width: "100px"
            },
            {
                "title": "Sector",
                "field": "VZ_SECTOR",
                filterable: {
                    cell: {
                        operator: "contains",
                        suggestionOperator: "contains"
                    }
                },
                width: "100px"
            }
        ],
        dataSource: {
            data: txData,
            schema: {
                model: {
                }
            },
            pageSize: 5
        },
        // dataBound: versionDataBound,
        filterable: {
            // mode: "row",
            operators: {},
            extra: false
        },
        filter: function (e) {
        },
        columnMenu: {
            columns: false
        },
        reorderable: true,
        resizable: true
    });



    $('#addCarrierPopup').show();
    $('#alertMask').show();
}
function closeAddCarrierPopup(){
    $('#addCarrierPopup').hide();
    $('#alertMask').hide();
}
function closeDeleteVersionPopup(){
    $('#deleteVersion').hide();
    $('#alertMask').hide();
}
function closeDeleteTxPopup(){
    $('#deleteTx').hide();
    $('#alertMask').hide();
}

function closeDeleteCellPopup(){
    $('#deleteCell').hide();
    $('#alertMask').hide();
}
function validateCopy(){
    if($('#newSiteVersionInPopup').val() == undefined || $('#newSiteVersionInPopup').val() == null || $('#newSiteVersionInPopup').val().trim().length == 0){
        $('#copySubmitBtn').attr("disabled", true);
        return;
    }
    var dataSource = $("#versionGrid").data("kendoGrid").dataSource.data();
    dataSource = dataSource? dataSource : [];
    newVersion = $('#newSiteVersionInPopup').val().trim();
    var flag  = true;
    $.each(dataSource, function(i, v){
    	if(flag == true){
	        if(newVersion == v.VZ_SITE_VERSION){
	           flag = false;
	        }
    	}
    });
    if(flag == true){
    	$('#copySubmitBtn').attr("disabled", false);
    }else{
    	$('#copySubmitBtn').attr("disabled", true);
    }
    
}

function validateClone(){
    if($('#newSiteVersionInClonePopup').val() == undefined || $('#newSiteVersionInClonePopup').val() == null || $('#newSiteVersionInClonePopup').val().trim().length == 0){
        $('#cloneSubmitBtn').attr("disabled", true);
        return;
    }
    var dataSource = $("#versionGrid").data("kendoGrid").dataSource.data();
    dataSource = dataSource? dataSource : [];
    newVersion = $('#newSiteVersionInClonePopup').val().trim();
    var flag  = true;
    $.each(dataSource, function(i, v){
    	if(flag == true){
	        if(newVersion == v.VZ_SITE_VERSION){
	           flag = false;
	        }
    	}
    });
    if(flag == true){
    	$('#cloneSubmitBtn').attr("disabled", false);
    }else{
    	$('#cloneSubmitBtn').attr("disabled", true);
    }
    
}

function copySite(e){
    var grid = $("#versionGrid").data("kendoGrid");
    var row = $(e).closest("tr");
    var selectedItem = grid.dataItem(row);
    $('#siteNameInPopup').val(selectedItem.NAME);
    $('#siteVersionInPopup').val(selectedItem.VZ_SITE_VERSION);
    $('#fuzeSiteIdInPopup').val(selectedItem.VZ_SITE_INFO_ID);
    $('#newSiteVersionInPopup').val("");
    openCopySitePopup()
}

function deleteOneCell(e){
    $(e).parents('.cellRow').remove();
    validatecells(); 
}
function deleteOneCarrier(e){
    $(e).parents('.cellRow').remove();
    validatecarrier(); 
}

function validatecells(){
    if ($('#addCellFormInCellPopup').find('.cellDataRow').length == 0 ) {
		$('#addCellSubmitBtn').attr("disabled",true);
    }else{
		$('#addCellSubmitBtn').attr("disabled",false);
	}
}

function validatecarrier(){
	if ($('#addCellFormInCarrierPopup').find('.carrierDataRow').length != 0 && $('#numOfSectorsInAddCarrierPopup').val() !="") {
		$('#addCarrierSubmitBtn').attr("disabled",false);
    }else{
		$('#addCarrierSubmitBtn').attr("disabled",true);
	}
}

function buildCatauto(element){
    $(element).catautocomplete({
        minLength: 2,
        delay: 600,
        source: function(request, response) {
            $(element).addClass("ui-autocomplete-loading");
            var term = request.term;
            var suggestions = [];
            runSiteAutocomplete(term).then(function(results) {
                if(!results || !results.data || results.data.length == 0){
                    suggestions.push({ label: "Not Found.", value: "Not found.", category: "Site Results" });
                    siteNameGlobal = term;
                    // fuzeSiteIdGlobal = term;
                }else{
                    var obj =  _.map(results.data, function convertResult(result) {
                        return {
                            // label: result.NAME,
                            label: "(" + result.VZ_SITE_INFO_ID + ") " + result.VZ_SITE_NAME,
                            value: result.VZ_SITE_NAME,
                            siteName: result.VZ_SITE_NAME,
                            fuzeSiteId: result.VZ_SITE_INFO_ID,
                            category: "Site Results",
                        };
                    });
                    suggestions = obj
                }
                response(_.flatten(_.filter(suggestions, Boolean)));
                $(element).removeClass("ui-autocomplete-loading");
            });
        },
        select: function(event, ui) {
            $(element).removeClass("ui-autocomplete-loading");
            validate();
            siteNameGlobal = ui.item.siteName;
            // fuzeSiteIdGlobal = ui.item.fuzeSiteId;
        }
    });
}

function runSiteAutocomplete(term, response) {
    if(siteAutoAjax){
        siteAutoAjax.abort();
        siteAutoAjax = null;
    }
    term = term.toUpperCase();
    siteAutoAjax =  $.get(CONTEXT_PATH + "/uui/eapp/atoll_pg/siteAutocomplete", { query: term, atollSchema: $('#atollSchemaDropdown').val() }).success().error(
        function handleError(error) {
            // console.error("Something went wrong with the site search", error);
            return [];
        }
    );
    return siteAutoAjax;
}

function displayViewManagement(view){
    var url = CONTEXT_PATH + "/uui/eapp/atoll_pg/viewFilterPopup?page=" + view;
    var height = window.innerHeight - 60;
    height = height > 520? 520 : height;
    $('#viewManagerPageIframe').css("height", height);
    $('#viewManagerPageIframe').attr('page', view);
    $('#viewManagerPageIframe').attr('src', url);
    // document.getElementById('viewManagerPageIframe').contentWindow.location.reload();
    $('#viewManagerPage').show();
    $('#alertMask').show();
}
function backToOriginPage(){
    $('#viewManagerPage').hide();
    $('#solutionSearchPage').show();
    $('#alertMask').hide();
    // update view dropdown value
    if($('#viewManagerPageIframe').attr('page') == "version"){
        getCustomTemplates("ATOLL.CARRIER.VERSION.", "fromPopup", "version");
    }else if($('#viewManagerPageIframe').attr('page') == "tx"){
        getCustomTemplates("ATOLL.CARRIER.TX.", "fromPopup", "tx");
    }else{
        getCustomTemplates("ATOLL.CARRIER.CELL.", "fromPopup", "cell");
    }
}


function getCustomTemplates(name, source, view){
    $.ajax({
        url: '/uuigui/uui/eapp/atoll_pg/getCustomTemplates?name=' + name,
        type: 'GET',
        contentType: 'application/json',
        success: function (data) {
            data = JSON.parse(data);
            var originalTamplateColumnMap;
            if(view == "version"){
                versionOptgroups = _.cloneDeep(versionBaseoptgroups);
                $.each(versionOriginalTamplateColumnMap, function(i, v){
                    if(_.findIndex(versionOptgroups[0].children, {"value": i}) < 0){
                        delete versionOriginalTamplateColumnMap[i];
                    }
                })
                $.each(data, function(i, v){
                    var setting = v.SETTING? v.SETTING : "{}";
                    setting = JSON.parse(setting);
                    if(setting.name){
                        versionOptgroups[1].children.push({label: setting.name, value: setting.name});
                        versionOriginalTamplateColumnMap[setting.name] = setting;
                    }
                });
            }else if(view == "tx"){
                txOptgroups = _.cloneDeep(txBaseoptgroups);
                $.each(txOriginalTamplateColumnMap, function(i, v){
                    if(_.findIndex(txOptgroups[0].children, {"value": i}) < 0){
                        delete txOriginalTamplateColumnMap[i];
                    }
                })
                $.each(data, function(i, v){
                    var setting = v.SETTING? v.SETTING : "{}";
                    setting = JSON.parse(setting);
                    if(setting.name){
                        txOptgroups[1].children.push({label: setting.name, value: setting.name});
                        txOriginalTamplateColumnMap[setting.name] = setting;
                    }
                });
            }else{
                cellOptgroups = _.cloneDeep(cellBaseoptgroups);
                $.each(cellOriginalTamplateColumnMap, function(i, v){
                    if(_.findIndex(cellOptgroups[0].children, {"value": i}) < 0){
                        delete cellOriginalTamplateColumnMap[i];
                    }
                })
                $.each(data, function(i, v){
                    var setting = v.SETTING? v.SETTING : "{}";
                    setting = JSON.parse(setting);
                    if(setting.name){
                        cellOptgroups[1].children.push({label: setting.name, value: setting.name});
                        cellOriginalTamplateColumnMap[setting.name] = setting;
                    }
                });
            }
            var val;
            if(view == "version"){
                val = $('#versionTamplateSelect').val()? $('#versionTamplateSelect').val() : versionDefaultViewName;
                $('#versionTamplateSelect').multiselect('dataprovider', versionOptgroups);
                originalTamplateColumnMap = versionOriginalTamplateColumnMap;
            }else if(view == "tx"){
                val = $('#txTamplateSelect').val()? $('#txTamplateSelect').val() : txDefaultViewName;
                $('#txTamplateSelect').multiselect('dataprovider', txOptgroups);
                originalTamplateColumnMap = txOriginalTamplateColumnMap;
            }else{
                val = $('#cellTamplateSelect').val()? $('#cellTamplateSelect').val() : cellDefaultViewName;
                $('#cellTamplateSelect').multiselect('dataprovider', cellOptgroups);
                originalTamplateColumnMap = cellOriginalTamplateColumnMap;
            }
            if(source =="fromPopup"){
                if(view == "version" && versionOriginalTamplateColumnMap[val]){
                    $('#versionTamplateSelect').val(val).multiselect('refresh');
                }else if(view == "tx" && txOriginalTamplateColumnMap[val]){
                    $('#txTamplateSelect').val(val).multiselect('refresh');
                }else if(view == "cell" && cellOriginalTamplateColumnMap[val]){
                    $('#cellTamplateSelect').val(val).multiselect('refresh');
                }else{
                    if(view == "version"){
                        val = "ATOLL.CARRIER.VERSION.DEFAULT";
                        versionDefaultViewName = val;
                        $('#versionTamplateSelect').val(val).multiselect('refresh');
                    }else if(view == "tx"){
                        val = "ATOLL.CARRIER.TX.DEFAULT";
                        txDefaultViewName = val;
                        $('#txTamplateSelect').val(val).multiselect('refresh');
                    }else{
                        val = "ATOLL.CARRIER.CELL.DEFAULT";
                        cellDefaultViewName = val;
                        $('#cellTamplateSelect').val(val).multiselect('refresh');
                    }
                }
                defaultViewChange(val,view);
            }else{
                if(view == "version"){
                    $('#versionTamplateSelect').val(val).multiselect('refresh');
                }else if(view == "tx"){
                    $('#txTamplateSelect').val(val).multiselect('refresh');
                }else{
                    $('#cellTamplateSelect').val(val).multiselect('refresh');
                }
            }
            var ui_obj;
            if(view == "version"){
                ui_obj = versionDefaultColumns;
            }else if(view == "tx"){
                ui_obj = txDefaultColumns;
            }else{
                ui_obj = cellDefaultColumns;
            }
            var _locationcolumns = [];
            var displayCount = 0;
            // if(val == "ATOLL.CARRIER.VERSION.DEFAULT"){
            //     getColumnNames(versionDefaultViewName, view);
            //     return;
            // }else if(val == "ATOLL.CARRIER.TX.DEFAULT"){
            //     getColumnNames(txDefaultViewName, view);
            //     return;
            // }else if(val == "ATOLL.CARRIER.CELL.DEFAULT"){
            //     getColumnNames(cellDefaultViewName, view);
            //     return;
            // }else if(!versionOriginalTamplateColumnMap[val] && !txOriginalTamplateColumnMap[val] && !cellOriginalTamplateColumnMap[val]){
            //     getColumnNames(val, view);
            //     return;
            // }
            if(!versionOriginalTamplateColumnMap[val] && !txOriginalTamplateColumnMap[val] && !cellOriginalTamplateColumnMap[val]){
                getColumnNames(val, view);
                return;
            }
            for (var i = 0; i < originalTamplateColumnMap[val].columns.length; i++) {
                var _curr_columns = originalTamplateColumnMap[val].columns[i];
                for (var j = 0; j < ui_obj.length; j++) {
                    if (_curr_columns.field == ui_obj[j].field) {
                        var _temp = $.extend(true, {}, ui_obj[j]);
                        if (_curr_columns.hidden == true) {
                            _temp.hidden = true;
                        }else{
                            displayCount++;
                            _temp.hidden = false;
                            if(_temp.template && typeof _temp.template == "string" && _temp.template.length > 0){
                                _temp.template = new Function("return " + _temp.template)();
                            }
                            if(_temp.filterable){
                                if(_temp.filterable.dataSource && _temp.filterable.dataSource.transport && _temp.filterable.dataSource.transport.read){
                                    if(_temp.filterable.dataSource.transport.read.data && typeof _temp.filterable.dataSource.transport.read.data == "string" && _temp.filterable.dataSource.transport.read.data.length > 0){
                                        _temp.filterable.dataSource.transport.read.data = new Function("return " + _temp.filterable.dataSource.transport.read.data)();
                                    }
                                }
                            }
                            if(_temp.headerAttributes && _temp.headerAttributes["style"]){
                                delete _temp.headerAttributes["style"];
                            }
                            if(_temp.footerAttributes && _temp.footerAttributes["style"]){
                                delete _temp.footerAttributes["style"];
                            }
                            if(_temp.attributes && _temp.attributes["style"]){
                                delete _temp.attributes["style"];
                            }
                            _locationcolumns.push(_temp);
                        }
                        break;
                    }
                }
            }
            var last = _.findLastIndex(_locationcolumns, function(chr) {
                return !chr.hidden
            });
            if(last > -1 && displayCount < 10){
                delete _locationcolumns[last]["width"];
            }
            if(view == "version"){
                versionDisplayColumns = _locationcolumns;
                buildVersionGrids();
            }else if(view == "tx"){
                txDisplayColumns = _locationcolumns;
                buildTXGrids();
            }else{
                cellDisplayColumns = _locationcolumns;
                buildCellGrids();
            }
        },
        error: function (err) {
            $('#loading').hide();
        }
    });
}
function getBaseView(name, view){
    UiSettingsRetrieveSystem(name, function (data) {
        var configs = data && data.configs? data.configs : [];
        $.each(configs, function(i, v){
            if(view == "version"){
                versionBaseoptgroups[0].children.push({label: v.label, value: "ATOLL.CARRIER.VERSION." + v.label});
            }else if(view == "tx"){
                txBaseoptgroups[0].children.push({label: v.label, value: "ATOLL.CARRIER.TX." + v.label});
            }else{
                cellBaseoptgroups[0].children.push({label: v.label, value: "ATOLL.CARRIER.CELL." + v.label});
            }
        });
        if(view == "version"){
            getDefaultViewNameFromUISetting("ATOLL.CARRIER.VERSION.MYVIEWS.Config", view);
        }else if(view == "tx"){
            getDefaultViewNameFromUISetting("ATOLL.CARRIER.TX.MYVIEWS.Config", view);
        }else{
            getDefaultViewNameFromUISetting("ATOLL.CARRIER.CELL.MYVIEWS.Config", view);
        }
    });
}
// get Column names from UI-SETTING
function getColumnNames(ui_obj_name, view) {
    UiSettingsRetrieveSystem(ui_obj_name, function (data) {
        var name;
        if(view == "version") {
            name = $('#versionTamplateSelect').val()? $('#versionTamplateSelect').val(): versionDefaultViewName;
        }else if(view == "tx") {
            name = $('#txTamplateSelect').val()? $('#txTamplateSelect').val(): txDefaultViewName;
        }else{
            name = $('#cellTamplateSelect').val()? $('#cellTamplateSelect').val(): cellDefaultViewName;
        }
        data = data? JSON.parse(data) : [];
        data = data[0]? data[0] : {}
        data = data.SETTING? JSON.parse(data.SETTING) : {};

        if (data && data != "ERROR" && data.prop_params && data.prop_params != '' && data.prop_params.columns) {
            if(view == "version") {
                versionOriginalTamplateColumnMap[name] = data.prop_params;
                versionOriginFilterName = data.prop_params.columns;
            }else if(view == "tx") {
                txOriginalTamplateColumnMap[name] = data.prop_params;
                txOriginFilterName = data.prop_params.columns;
            }else{
                cellOriginalTamplateColumnMap[name] = data.prop_params;
                cellOriginFilterName = data.prop_params.columns;
            }
            var originFilterName = data.prop_params.columns;
            
            var ui_obj = [];
            if(view == "version") {
                ui_obj = versionDefaultColumns;
            }else if(view == "tx") {
                ui_obj = txDefaultColumns;
            }else{
                ui_obj = cellDefaultColumns;
            }

            var _locationcolumns = [];
            var displayCount = 0;
            for (var i = 0; i < originFilterName.length; i++) {
                var _curr_columns = originFilterName[i];
                for (var j = 0; j < ui_obj.length; j++) {
                    if (_curr_columns.field == ui_obj[j].field) {
                        var _temp = $.extend(true, {}, ui_obj[j]);
                        if (_curr_columns.hidden == true) {
                            _temp.hidden = true;
                        }else{
                            displayCount++;
                            _temp.hidden = false;
                            if(_temp.template && typeof _temp.template == "string" && _temp.template.length > 0){
                                _temp.template = new Function("return " + _temp.template)();
                            }
                            if(_temp.filterable){
                                if(_temp.filterable.dataSource && _temp.filterable.dataSource.transport && _temp.filterable.dataSource.transport.read){
                                    if(_temp.filterable.dataSource.transport.read.data && typeof _temp.filterable.dataSource.transport.read.data == "string" && _temp.filterable.dataSource.transport.read.data.length > 0){
                                        _temp.filterable.dataSource.transport.read.data = new Function("return " + _temp.filterable.dataSource.transport.read.data)();
                                    }
                                }
                            }
                            if(_temp.headerAttributes && _temp.headerAttributes["style"]){
                                delete _temp.headerAttributes["style"];
                            }
                            if(_temp.footerAttributes && _temp.footerAttributes["style"]){
                                delete _temp.footerAttributes["style"];
                            }
                            if(_temp.attributes && _temp.attributes["style"]){
                                delete _temp.attributes["style"];
                            }
                            _locationcolumns.push(_temp);
                        }
                        break;
                    }
                }
            }
            var last = _.findLastIndex(_locationcolumns, function(chr) {
                return !chr.hidden
            });
            if(last > -1 && displayCount < 10){
                delete _locationcolumns[last]["width"];
            }
            if(view == "version") {
                versionDisplayColumns = _locationcolumns;
            }else if(view == "tx") {
                txDisplayColumns = _locationcolumns;
            }else{
                cellDisplayColumns = _locationcolumns;
            }

            if(name){
                if(view == "version") {
                    buildVersionGrids();
                }else if(view == "tx") {
                    buildTXGrids();
                }else{
                    buildCellGrids();
                }
            }
        }
    });
}
function defaultViewChange(name, view){
    var obj = {
        "default_view": name
    }
    var d = {};
    d.setting = JSON.stringify(obj);
    if(view == "version") {
        d.name = "ATOLL.CARRIER.VERSION.MYVIEWS.Config";
    }else if(view == "tx") {
        d.name = "ATOLL.CARRIER.TX.MYVIEWS.Config";
    }else{
        d.name = "ATOLL.CARRIER.CELL.MYVIEWS.Config";
    }
    $.ajax({
        url: '/uuigui/uui/eapp/planning_pg/defaultViewChangeInUISetting',
        type: 'POST',
        data: JSON.stringify(d),
        contentType: 'application/json',
        success: function (data) {
            
        }
    });
}
function getDefaultViewNameFromUISetting(name, view){
    $.ajax({
        url: '/uuigui/uui/eapp/atoll_pg/getDefaultViewNameFromUISetting?name=' + name,
        type: 'GET',
        contentType: 'application/json',
        success: function (data) {
            if(data != "ERROR"){
                data = JSON.parse(data);
                if(data[0] && data[0].SETTING){
                    var t = JSON.parse(data[0].SETTING);
                    if(view == "version"){
                        versionDefaultViewName = t.default_view;
                    }else if(view == "tx"){
                        txDefaultViewName = t.default_view;
                    }else{
                        cellDefaultViewName = t.default_view;
                    }
                }
            }
            if(view == "version"){
                $('#versionTamplateSelect').val(versionDefaultViewName).multiselect('refresh');
                getCustomTemplates("ATOLL.CARRIER.VERSION.", "", "version");
            }else if(view == "tx"){
                $('#txTamplateSelect').val(txDefaultViewName).multiselect('refresh');
                getCustomTemplates("ATOLL.CARRIER.TX.", "", "tx");
            }else{
                $('#cellTamplateSelect').val(cellDefaultViewName).multiselect('refresh');
                getCustomTemplates("ATOLL.CARRIER.CELL.", "", "cell");
            }
        }
    });
}

function getDefaultColumns(name, view){
    UiSettingsRetrieveSystem(name, function (data) {
        data = data? data : {};
        if(view == "version"){
            versionDefaultColumns = data && data.prop_params && data.prop_params.columns? data.prop_params.columns : [];
            versionOriginalTamplateColumnMap[name] = {};
            versionOriginalTamplateColumnMap[name].columns = versionDefaultColumns;
        }else if(view == "tx"){
            txDefaultColumns = data && data.prop_params && data.prop_params.columns? data.prop_params.columns : [];
            txOriginalTamplateColumnMap[name] = {};
            txOriginalTamplateColumnMap[name].columns = txDefaultColumns;
        }else{
            cellDefaultColumns = data && data.prop_params && data.prop_params.columns? data.prop_params.columns : [];
            cellOriginalTamplateColumnMap[name] = {};
            cellOriginalTamplateColumnMap[name].columns = cellDefaultColumns;
        }
    });
}

function bindEventForTemplate(id, view){
    //update columns in default/selected list based when tamplate dropdown changed
    $('#' + id).change(function(i){
        var val = $(this).val();
        var ui_obj = [];
        var originalTamplateColumnMap;
        if(view == "version") {
            ui_obj = versionDefaultColumns;
            originalTamplateColumnMap = versionOriginalTamplateColumnMap;
        }else if(view == "tx") {
            ui_obj = txDefaultColumns;
            originalTamplateColumnMap = txOriginalTamplateColumnMap;
        }else{
            ui_obj = cellDefaultColumns;
            originalTamplateColumnMap = cellOriginalTamplateColumnMap;
        }
        if(originalTamplateColumnMap[val]){
            if(view == "version") {
                versionOriginFilterName = originalTamplateColumnMap[val];
            }else if(view == "tx") {
                txOriginFilterName = originalTamplateColumnMap[val];
            }else{
                cellOriginFilterName = originalTamplateColumnMap[val];
            }
            var state = originalTamplateColumnMap[val];
            var _locationcolumns = [];
            var displayCount = 0;
            for (var i = 0; i < state.columns.length; i++) {
                var _curr_columns = state.columns[i];
                for (var j = 0; j < ui_obj.length; j++) {
                    if (_curr_columns.field == ui_obj[j].field) {
                        var _temp = $.extend(true, {}, ui_obj[j]);
                        if (_curr_columns.hidden == true) {
                            _temp.hidden = true;
                        }else{
                            displayCount++;
                            _temp.hidden = false;
                            if(_temp.template && typeof _temp.template == "string" && _temp.template.length > 0){
                                _temp.template = new Function("return " + _temp.template)();
                            }
                            if(_temp.filterable){
                                if(_temp.filterable.dataSource && _temp.filterable.dataSource.transport && _temp.filterable.dataSource.transport.read){
                                    if(_temp.filterable.dataSource.transport.read.data && typeof _temp.filterable.dataSource.transport.read.data == "string" && _temp.filterable.dataSource.transport.read.data.length > 0){
                                        _temp.filterable.dataSource.transport.read.data = new Function("return " + _temp.filterable.dataSource.transport.read.data)();
                                    }
                                }
                            }
                            if(_temp.headerAttributes && _temp.headerAttributes["style"]){
                                delete _temp.headerAttributes["style"];
                            }
                            if(_temp.footerAttributes && _temp.footerAttributes["style"]){
                                delete _temp.footerAttributes["style"];
                            }
                            if(_temp.attributes && _temp.attributes["style"]){
                                delete _temp.attributes["style"];
                            }
                            _locationcolumns.push(_temp);
                        }
                        break;
                    }
                }
            }
            var last = _.findLastIndex(_locationcolumns, function(chr) {
                return !chr.hidden
            });
            if(last > -1 && displayCount < 10){
                delete _locationcolumns[last]["width"];
            }
            defaultViewChange(val,view);
            if(view == "version") {
                versionDisplayColumns = _locationcolumns;
                buildVersionGrids();
            }else if(view == "tx") {
                txDisplayColumns = _locationcolumns;
                buildTXGrids();
            }else{
                cellDisplayColumns = _locationcolumns;
                buildCellGrids();
            }
        }else{
            getColumnNames(val, view);
            defaultViewChange(val, view);
        }
    });
    
}

function getUserSchema(){
    // roles.push("BETA_USER")
	if(roles.indexOf("BETA_USER") >= 0){
        $.each(atollSchema, function(i, v){
            $('#atollSchemaDropdown').append("<option>" + v.toUpperCase() + "</option>");
        });
        $('#atollSchemaDropdown').multiselect({
            includeSelectAllOption: true,
            enableFiltering:true,
            enableCaseInsensitiveFiltering: true,
            buttonClass: 'btn btn-default whitebg btn-sm',
            numberDisplayed: 1
        });
    }else{
        $.ajax({
            url: '/uuigui/uui/eapp/atoll_pg/getUserSchemas',
            type: 'GET',
            contentType: 'application/json',
            success: function (data) {
                data = data && data.data? data.data : [];
                $.each(data, function(i, v){
                    $('#atollSchemaDropdown').append("<option>" + v.SCHEMA + "</option>");
                });
                $('#atollSchemaDropdown').multiselect({
                    includeSelectAllOption: true,
                    enableFiltering:true,
                    enableCaseInsensitiveFiltering: true,
                    buttonClass: 'btn btn-default whitebg btn-sm',
                    numberDisplayed: 1
                });
            }
        });
    }
}