var emptyDataSource = new kendo.data.DataSource({
    data: [],
});
var defaultGridRowCount = 10;
var checkChange = false;
var tileLayers = new Map();
var tileLayersRight = new Map();
var marketLayers=new Map();
var marketLayersRight=new Map();
var vectorLayers = {};
var vectorLayersRight = {};
var marketOpacities = {};
var vectorTileLayerStyles = {};
var tileOpacities = {};
var filterInfo = {};
var polygonsInfo = {};
var layerInfoFromUISetting = [];
var tileLayersInitialized = false;
var splitClusters = null;
var transmitterGrid = null;
var leafCompare;
var CandidateSelectionModelSchemaDefinition = {};
var candidateSelectionGrid = null;
var selectedCandidateDataItems = [];
var c = XYZ.map();
var disableZoom = 20;
var splitClusters = null;
var multiplier = 1.0;
var disableZoom = 20;
var current_url = streetmap_url;
var plotLayersArr = new Map();
var transmitterMap = new Map();
var leaf;
var coverageLayerGroup;
var sectorLayerGroup;
var leaf;
var google_api_key = "AIzaSyBCDhGdiIbpa3jV-e7xuhwPfvJUUDZJNN8";
var attribution = "<span id='attributionSpan'>Cursor out of map bounds</span>";
var satellite_url = 'http://netgeo.vh.eng.vzwcorp.com/arcgis/rest/services/basemap_webmer/World_Imagery/MapServer/tile/{z}/{y}/{x}';
var grayscale_url = 'http://netgeo.vh.eng.vzwcorp.com/arcgis/rest/services/basemap_webmer/World_Topo_Map/MapServer/tile/{z}/{y}/{x}'
var streetmap_url = 'http://netgeo.vh.eng.vzwcorp.com/arcgis/rest/services/basemap_webmer/World_Street_Map/MapServer/tile/{z}/{y}/{x}';
var satellite_url = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
var grayscale_url = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}'
var streetmap_url = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}';
var tileOptions = { maxZoom: 19, minZoom: 2, opacity: .2, attribution: attribution, stamp: Date.now };
var clusterOptions = { maxRad: 1900, disableZoom: disableZoom, splitClusters: splitClusters };
var current_url = streetmap_url;
var svg_site_color = {
		svg_site_without_fuze_site_id: "#fa4632",
		svg_site_with_fuze_site_id: "#4ec8fc"
	};
var site_fuze_site_id_status = {
	"without-fuze-site-id": "#fa4632",
	"with-fuze-site-id": "#4ec8fc"
};
var stype_map = {
	"OTHER": {
		name: "pentagon",
		shape: '<polygon points="2,7 7,2 12,7 9,12 5,12" stroke-width="1" stroke="#000" stroke-opacity="1" fill="{fill}" fill-opacity="1" />'
	},
	"MACRO": {
		name: "circle",
		shape: '<circle cx="7" cy="7" r="5" stroke-width="1" stroke="#000" stroke-opacity="1" fill="{fill}" fill-opacity="1"/>'
	},
	"SMALL-CELL": {
		name: "diamond",
		shape: '<polygon points="1,7 7,1 13,7 7,13" stroke-width="1" stroke="#000" stroke-opacity="1" fill="{fill}" fill-opacity="1" />'
	},
	"SC/ODAS": {
		name: "hexagon",
		shape: '<polygon points="3,5 7,2 11,5 11,9 7,12 3,9" stroke-width="1" stroke="#000" stroke-opacity="1" fill="{fill}" fill-opacity="1" />'
	},
	"INBLD": {
		name: "rectangle",
		shape: '<rect x="3" y="3" width="10" height="10" stroke-width="1" stroke="#000" stroke-opacity="1" fill="{fill}" fill-opacity="1"/>'
	}
};
var selectedRows = {};
var plottedMarker = new Array();
var plottedMarkerOfNearerSites = new Array();
var candidateSelectionResponse = {};

$(document).ready(function () {
    loadPlanInfo("new");
});

function getValue(data, value) {
	return (data[value] != null && data[value] != undefined) ? data[value] : "";
}
function fillValuesOfPlanInfo(data) {
    if (data != null && data != undefined) {
        $("#projectId").html(getValue(data, "projectId"));
        $("#projectId").attr("href", spm_project_id + "?projectId=" + getValue(data, "projectId"));

        $("#projectName").html(getValue(data, "projectName"));
        $("#region").html(getValue(data, "region"));
        $("#status").html(getValue(data, "status"));
        $("#parentSolutionId").html(getValue(data, "parentSolutionId"));
        $("#parentSolutionId").attr("href", parent_solution_id + "?parentSolutionId=" + getValue(data, "parentSolutionId"));
        // if (data.hasOwnProperty("CandidateSelectionData") && data.CandidateSelectionData.length > 0) {
        //     setCandidateSelection(data.CandidateSelectionData, candidateSelectionGrid);
        // }
    }
}

function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

function loadPlanInfo(format) {
    $.ajax({
        type: "POST",
        url: CONTEXT_PATH + '/uui/eapp/atoll_pg/LoadSiteInfo',
        contentType: 'application/json',
        data: JSON.stringify({
            "PARENT_SOLUTION_ID": parseInt(getUrlVars().parent_solution_id)

        }),
        success: function (data) {
            console.log('loadPlanInfo ');
            console.log(data);
            var arr = [];
            for (var index = 0; index < data.data.length; index++) {
                const element = data.data[index];
                candidateSelectionResponse.projectId = element.PROJECTNUMBER;
                candidateSelectionResponse.fuzeSiteId = element.FUZE_SITE_ID;
                candidateSelectionResponse.region = element.SITENAME;
                candidateSelectionResponse.parentSolutionId = element.PARENTSOLUTIONID;
                candidateSelectionResponse.projectName = element.PROJECTNAME;

                $("#projectId").html(element.PROJECTNUMBER);
                $("#projectId").attr("href", spm_project_id + "?projectId=" + element.PROJECTNUMBER);

                $("#projectName").html(element.PROJECTNAME);
                $("#region").html(element.SITENAME);
                $("#status").html(candidateSelectionResponse.status);
                $("#parentSolutionId").html(element.PARENTSOLUTIONID);
                $("#parentSolutionId").attr("href", parent_solution_id + "?parentSolutionId=" + element.PARENTSOLUTIONID);
            }
            fillValuesOfPlanInfo(candidateSelectionResponse);
            readyDataForCandidate();
        }, error: function (response) {
            $('#loading').hide();
            return null;
        }
    });
}

function readyDataForCandidate() {
    drawCandidateSelectionTable('candidateSelectionInfoGrid');

    candidateSelectionGrid = $("#candidateSelectionInfoGrid").data("kendoGrid");

    $.ajax({
        type: "POST",
        url: CONTEXT_PATH + '/uui/eapp/atoll_pg/candidateSelection',
        contentType: 'application/json',
        data: JSON.stringify({
            "PARENT_SOLUTION_ID": parseInt(getUrlVars().parent_solution_id)
        }),
        success: function (data) {
            console.log('getCandidateSelectionData ');
            console.log(data);
            var processdata = data;
            var tempCandidateSel = [];
            for (var index = 0; index < processdata.data.length; index++) {
                var element = processdata.data[index];
                var ele = {};

                ele.latitude = element.LATITUDE
                ele.longitude = element.LONGITUDE
                ele.site_name = element.SITE_NAME;
                ele.candidate_id = element.candidate_id;
                ele.fuze_site_id = element.fuze_site_id;
                ele.equipment_cost = element.proposed_equipment_cost;
                ele.fiber_cost = element.proposed_fiber_cost;
                ele.hub_location = element.proposed_hub_location;
                ele.releaseState_cost = element.proposed_realestate_cost;
                ele.rationale = element.rationale;
                ele.score = element.score;

                tempCandidateSel.push(ele);
                getAreaFromPointsOfCandidate(element.LATITUDE,element.LONGITUDE)
            }
            console.log(tempCandidateSel);

            //candidateSelectionResponse.CandidateSelectionData = tempCandidateSel;
            console.log(candidateSelectionResponse);
            fillValuesOfCandidateSelection(candidateSelectionResponse);
			drawCoverageOnMap();
			
        }, error: function (response) {
            $('#loading').hide();
            return null;
        }
    });
    initMapOfCandidates();
}

function drawCandidateSelectionTable(candidateSelectionId) {

    $("#" + candidateSelectionId).kendoGrid({
        dataSource: emptyDataSource,
        columns: getCandidateSelectionGridColumns(),
        filterable: {
            operators: {
                //string:kendoGridManager.stringFilterOperator
            }
        },
        groupable: false,
        columnMenu: true,
        reorderable: true,
        resizable: true,
        pageable: {
            pageSizes: defaultGridRowCount,
            input: true,
            numeric: false,
            pageSizes: [10, 20, 50, 100, "All"]

        },
        columnMenu: true,
        sortable: true,
        editable: true,
        change: function (e) {
            var rows = e.sender.element.find("tbody tr");
            // var offset = $(e.target).closest("tr").offset();
            console.log("candidateSelection " + rows);
            var noselection = true;
             selectedRows = this.select();
            console.log("candidateSelection " + selectedRows.length);
            
           /* if(selectedRows.length <= 1){
                if ($('#candidateSelectionInfoGrid').find("tr").hasClass("k-state-selected")) {
                    // $('#stripDivPeerSite').show().css('top', parseInt(offset.top) + 60);
                    $('#stripDivPeerSite').show().css('top', 150);
                } else {
                    $('#stripDivPeerSite').hide();
                }
            }*/
            var cnt = 0;
            $.each($("#candidateSelectionInfoGrid").data("kendoGrid").items(), function (index, item) {
				let candidateID = $("#candidateSelectionInfoGrid").data("kendoGrid").dataItem(item).candidate_id;
				//let lat = $("#candidateSelectionInfoGrid").data("kendoGrid").dataItem(item).latitude;
				//let long = $("#candidateSelectionInfoGrid").data("kendoGrid").dataItem(item).longitude;
				if ($(item).hasClass("k-state-selected")){
					cnt++;
				} 
				for(var x in result){
					//var geoData = processdata[x];
					sectorData = [];
					for(var i=0; i<result[x].length;i++){
						//result[x][i].selected = true;
						var geoData1 =  result[x][i].geom_data;
						if ($(item).hasClass("k-state-selected") && result[x][i].candidate_id == candidateID) {
		                    addSelectedCandidateSite();	
		                    //cnt++;
							noselection = false;
							result[x][i].selected = true;
						}else if(result[x][i].candidate_id == candidateID){
							result[x][i].selected = false;
							removeSelectedCandidateSite();
		                    removeNearerSites();
						}  
					}
				}            
            });
            
            if (noselection) {
            	cnt = 0;
            	removeAllLayers();
            	removeAllSectorLayers();
            }
            if(cnt == 1){
            	 $('#stripDivPeerSite').show().css('top', 150);
            }else{
            	cnt = 0;
            	$('#stripDivPeerSite').hide();
            }
            createCoverageonMap();
            selectedCandidateDataItems = [];
            for (var i = 0; i < selectedRows.length; i++) {
                var dataItem = this.dataItem(selectedRows[i]);
                selectedCandidateDataItems.push(dataItem);
            }

        },
        dataBound: function (e) {
            if (!$("#" + candidateSelectionId + " thead input:checkbox").prop("checked")) {
                $("#" + candidateSelectionId + " thead  input:checkbox").trigger("click");
            }
        },
        noRecords: {
            template: "<div style='font-size:12px;color:red'>No data available</div>"
        },
        cellClose: function (e) {
            $("#" + candidateSelectionId).data("kendoGrid").refresh();
            enableButtonsIfChanged("#" + candidateSelectionId);
        }
    });
}

function enableButtonsIfChanged(datagridId) {
    let datagridInstance = $(datagridId).data("kendoGrid")
    if (datagridInstance != null) {
        if (!checkChange) {
            let dataProvider = datagridInstance.dataSource.data();
            dataProvider.forEach(function (item) {
                if (item.dirty) {
                    checkChange = true;
                }
            });
            if (checkChange) {
                $("#pushToSpm").removeAttr("disabled");
                $("#cancel").removeAttr("disabled");
            }
        }
    }
}

function getCandidateSelectionGridColumns() {
    return [
        {
            selectable: true,
            width: "50px",
        },
        {
            "title": "Candidate Id",
            "field": "candidate_id",
            width: 100
        },
        {
            "title": "Fuze Site Id ",
            "field": "fuze_site_id",
            width: 100
        },
        {
            "title": "Site Name",
            "field": "site_name",
            width: 100
        },
        {
            "title": "Latitude",
            "field": "latitude",
            width: 100
        },
        {
            "title": "Longitude",
            "field": "longitude",
            width: 100,
        },
        {
            "title": "Hub Location",
            "field": "hub_location",
            width: 100,
        },
        {
            "title": "ReleaseState Cost",
            "field": "releaseState_cost",
            width: 100,
        },
        {
            "title": "Equipment Cost",
            "field": "equipment_cost",
            width: 100,
        },
        {
            "title": "Fiber Cost",
            "field": "fiber_cost",
            width: 100,
        },
        {
            "title": "Rationale",
            "field": "rationale",
            width: 100,
        },
        {
            "title": "Score",
            "field": "score",
            width: 100,
        }
    ];
}

function fillValuesOfCandidateSelection(data) {
    if (data != null && data != undefined) {
        if (data.hasOwnProperty("CandidateSelectionData") && data.CandidateSelectionData.length > 0) {
            setCandidateSelection(data.CandidateSelectionData, candidateSelectionGrid);
        }
    }
}

function setCandidateSelection(currentResult, candidateSelectionGrid) {
    candidateSelectionGrid.setDataSource(
        new kendo.data.DataSource({
            pageSize: defaultGridRowCount,
            data: currentResult,
            schema: CandidateSelectionModelSchemaDefinition
        })
    );
}

function drawNearerSitesOfCandidate(data){
	// console.log("near data: ",data1);
	// let data = data1.fullsites;
	for(let i=0; i< data.length; i++){
		var markerOptions = {  
			"LATITUDE": data[i].LATITUDE,
			"LONGITUDE":  data[i].LONGITUDE,
			"VZ_SITE_INFO_ID": data[i].FUZE_SITE_ID,
			"VZ_SITE_NAME": data[i].NAME,
			"NAME": data[i].NAME,
		};
		var flag = "with-fuze-site-id";
		var icon = "svg_site_mpt_" + "MACRO" + "_" + flag;
		var circleMarker = //L.circle([Number(markerOptions.LATITUDE), Number(markerOptions.LONGITUDE)], {radius: 200, circleOptions: markerOptions}).addTo(leaf)
			L.marker([Number(markerOptions.LATITUDE), Number(markerOptions.LONGITUDE)], {
				icon: XYZ._icon_map[icon],
				markerOptions: markerOptions
			});
            plottedMarkerOfNearerSites.push(circleMarker);

		leaf.addLayer(plottedMarkerOfNearerSites[i]);

        //  bindSitePopupFromSite(data[i]);
        var popup = "<div style='background:white;'>"
        + "<h4>" + markerOptions.VZ_SITE_NAME + "</h4>"
        + "<div class='popup-inner' style='border:1px solid #d7d7d7;background: #f7f7f7; margin-bottom:10px; padding:0 5px;'>"
        + "<div><div class='halfdiv'><h5>Fuze Site Id</h5></div><div class='halfdiv'><a href='" + sitemanagementUrl + "/sites.jsp?siteId=" + markerOptions.VZ_SITE_INFO_ID + "' target='_blank' class='projectLink'>" + markerOptions.VZ_SITE_INFO_ID + "</a></div></div>"
        + "<div><div class='halfdiv'><h5>Site Location</h5></div><div class='halfdiv'>" + data[i].ADDRESS + "</div></div>"
        + "<div><div class='halfdiv'><h5>Site Type</h5></div><div class='halfdiv'>" + data[i].SITE_TYPE + "</div></div></div>"
        + "</div>";
        circleMarker.bindPopup(popup);

	}
	 leaf.setView(new L.LatLng(Number(markerOptions.LATITUDE), Number(markerOptions.LONGITUDE)),10)
}

function searchSites(areaId, draw){
    var filterMap1 = {};
    filterMap1.areaIdToSearch = areaId;
    filterMap1.naFlag = draw;

    $.ajax({
        url: CONTEXT_PATH + "/uui/eapp/planning_pg/service/SearchSites",
        type: 'POST',
        data: JSON.stringify(filterMap1),
        dataType: 'json',
        Accept: 'application/json',
        contentType: 'application/json; charset=UTF-8',
        headers: {
            'USER_ID': VZID,
            'FIRST_NAME': firstName,
            'LAST_NAME': lastName,
            "Authorization": window.encodedAuthHeader
        },
        success: function (data) {
            console.log('sites: ',data);
			console.log('sites: ',sites);
			drawNearerSitesOfCandidate(sites);
        }
    });
}

function getAreaFromPointsOfCandidate(lat,long){
    data1 = {};
	data1.latitude= 31.869585540150467;
    data1.longitude = -85.39321558198868;
    data1.exclude = 1620642807238;
    $.ajax({
        url: CONTEXT_PATH + "/uui/eapp/planning_pg/getAreaFromPoint?longitude=" + data1.longitude + "&latitude=" + data1.latitude + "&exclude=" + data1.exclude,
        type: 'GET',
        success: function (data) {
            data = JSON.parse(data);
            var allArea = data.allArea && data.allArea != ""? JSON.parse(data.allArea) : [];
            data = JSON.parse(data.data);
            
            searchSites(data[0].AREA_ID, true);
                
        }
    });
}

function enableMapZoom() {
	leaf.dragging.enable();
	leaf.doubleClickZoom.enable();
	leaf.scrollWheelZoom.enable();
	leaf.boxZoom.enable();
	leaf.keyboard.enable();
}
function initMapOfCandidates() {
	L.CursorHandler = L.Handler.extend({

		addHooks: function () {
			this._popup = new L.Popup();
			this._map.on('mouseover', this._open, this);
			this._map.on('mousemove', this._update, this);
			this._map.on('mouseout', this._close, this);
		},

		removeHooks: function () {
			this._map.off('mouseover', this._open, this);
			this._map.off('mousemove', this._update, this);
			this._map.off('mouseout', this._close, this);
		},

		_open: function (e) {
			this._update(e);
		},

		_close: function (e) {
			$('#attributionSpan').text("Zoom Level: " + this._map.getZoom() + " Coordinates: " + parseFloat(e.latlng.lat).toFixed(5) + ", " + parseFloat(e.latlng.lng).toFixed(5));
		},

		_update: function (e) {
			$('#attributionSpan').text("Zoom Level: " + this._map.getZoom() + " Coordinates: " + parseFloat(e.latlng.lat).toFixed(5) + ", " + parseFloat(e.latlng.lng).toFixed(5));
		}
	});

	L.Map.addInitHook('addHandler', 'cursor', L.CursorHandler);
	leaf = c.initialize("map", {
		"zoomPos": 'topright',
		"clusterPie": false,
		"cursor": true,
		"tileOptions": tileOptions,
		"clusterOptions": clusterOptions,
		"stamp": "?_={stamp}", 'url': current_url, 'resourcePath': CONTEXT_PATH + '/uui/espresso/static',
		"legendPos": "bottomleft"
	})._map;
	c.setEdgeAttr(XYZ.ATTR.EDGE_AGGR_TEXT | XYZ.ATTR.EDGE_TEXT | XYZ.ATTR.EDGE_AGGR_POPUP);
	c.setMode(XYZ.MODE.STATIC);

	leaf.cursor.enable();

	L.control.scale({ position: "bottomleft" }).addTo(leaf);

	googleRoadMutant = L.gridLayer.googleMutant({ maxZoom: 24, type: 'roadmap' });
	googleTerrainMutant = L.gridLayer.googleMutant({ maxZoom: 24, type: 'terrain' });
	googleRoadMutant.addTo(leaf);
	leaf.on('moveend', function () {
		let text = $('#attributionSpan').text();
		text = text.slice(0, 12) + leaf.getZoom() + " " + text.slice(14, text.length);
		$('#attributionSpan').text(text);
		enableMapZoom();
	});

	function hideDropdown() {
		$(".multiselect-native-select").children().removeClass("open");
	}

	L.DivIcon.SVGIcon.include({
		initialize: function (options) {
			options = L.Util.setOptions(this, options)

			//iconSize needs to be converted to a Point object if it is not passed as one
			options.iconSize = L.point(options.iconSize)

			//in addition to setting option dependant defaults, Point-based options are converted to Point objects
			if (!options.circleAnchor) {
				options.circleAnchor = L.point(Number(options.iconSize.x) / 2, Number(options.iconSize.x) / 2)
			}
			else {
				options.circleAnchor = L.point(options.circleAnchor)
			}
			if (!options.circleColor) {
				options.circleColor = options.color
			}
			if (!options.circleFillOpacity) {
				options.circleFillOpacity = options.opacity
			}
			if (!options.circleOpacity) {
				options.circleOpacity = options.opacity
			}
			if (!options.circleWeight) {
				options.circleWeight = options.weight
			}
			if (!options.fillColor) {
				options.fillColor = options.color
			}
			if (!options.fontSize) {
				options.fontSize = Number(options.iconSize.x / 4)
			}
			if (!options.iconAnchor) {
				options.iconAnchor = L.point(Number(options.iconSize.x) / 2, Number(options.iconSize.y) / 2)
			}
			else {
				options.iconAnchor = L.point(options.iconAnchor)
			}
			if (!options.popupAnchor) {
				options.popupAnchor = L.point(0, 0)
			}
			else {
				options.popupAnchor = L.point(options.popupAnchor)
			}

			var path = this._createPath()
			var circle = this._createCircle()

			options.html = this._createSVG()
		},
		_createSVG: function () {
			var path = this._createPath();
			var circle = this._createCircle();
			var text = this._createText();
			var img = this._createImage();
			var className = this.options.className + "-svg";

			var style = "width:" + this.options.iconSize.x + "; height:" + this.options.iconSize.y + ";";

			var svg = '<svg xmlns="http://www.w3.org/2000/svg" version="1.1" class="' + className + '" style="' + style + '">' + path + circle + text + img + '</svg>';

			return svg;
		},
		_createPath: function () {
			var pathDescription = this._createPathDescription();
			var strokeWidth = this.options.weight
			var stroke = this.options.color
			var strokeOpacity = this.options.Opacity
			var fill = this.options.fillColor
			var fillOpacity = this.options.fillOpacity
			var className = this.options.className + "-path"
			var height = Number(this.options.iconSize.y)
			var width = Number(this.options.iconSize.x)
			var r = (width - strokeWidth - 8) / 2;
			var h = width - strokeWidth - 8;
			var hr = (width - 2) / 2;
			var hh = width - 2;
			var path = "";
			if (this.options.definedPath) {
				path = this.options.definedPath
					.split("{stroke}").join(stroke)
					.split("{fill}").join(fill);
			}
			else if (this.options.shape === "rectangle") {
				if (this.options.highlight) path += '<rect class="rect-highlight" x="' + ((width / 2) - hr) + '" y="' + ((height / 2) - hr) + '" width="' + hh + '" height="' + hh + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1"/>';
				path += '<rect class="' + className + '" x="' + ((width / 2) - r) + '" y="' + ((height / 2) - r) + '" width="' + h + '" height="' + h + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '"/>';
			}
			else if (this.options.shape === "rhombus") {
				if (this.options.highlight) path += '<rect class="rect-highlight" x="8.5" y="-8.5" width="' + (hh - 5) + '" height="' + (hh - 5) + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1" transform="rotate(45)"/>';
				path += '<rect class="' + className + '" x="' + (this.options.iconSize.x === 24 ? 11 : 9) + '" y="' + (this.options.iconSize.y === 24 ? -6 : -5) + '" width="' + (h - 2) + '" height="' + (h - 2) + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '" transform="rotate(45)"/>';
			}
			else if (this.options.shape === "inverted_triangle") {
				if (this.options.highlight) path += '<polygon points="' + '2,2 ' + (width - 2) + ',2 ' + (width / 2) + ',' + (height - 2) + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1" />';
				path += '<polygon points="' + (this.options.iconSize.x === 24 ? 7 : 5) + ',' + (this.options.iconSize.y === 24 ? 7 : 5) + ' ' + (this.options.iconSize.x === 24 ? width - 6 : width - 5) + ',' + (this.options.iconSize.y === 24 ? 7 : 5) + ' ' + (width / 2) + ',' + (height - 5) + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '" />';
			}
			else if (this.options.shape === "triangle") {
				if (this.options.highlight) path += '<polygon points="' + (width / 2) + ',2 ' + (width - 2) + ',' + (height - 2) + ' 2,' + (height - 2) + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1" />';
				path += '<polygon points="' + (width / 2) + ',' + (this.options.iconSize.y === 24 ? 7 : 5) + ' ' + (this.options.iconSize.y === 24 ? width - 6 : width - 5) + ',' + (height - 5) + ' ' + (this.options.iconSize.y === 24 ? 7 : 5) + ',' + (height - 5) + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '" />';
			}
			else if (this.options.shape === "trapezoid") {
				if (this.options.highlight) path += '<polygon points="6,2 ' + (width - 6) + ',2 ' + (width - 2) + ',' + (height - 2) + ' 2,' + (height - 2) + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1" />';
				path += '<polygon points="8,5 ' + (width - 8) + ',5 ' + (width - 5) + ',' + (height - 5) + ' 5,' + (height - 5) + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '" />';
			}
			else if (this.options.shape === "pentagon") {
				if (this.options.highlight) path += '<polygon points="2,' + (height / 2) + ' ' + (width / 2) + ',2 ' + (width - 2) + ',' + (height / 2) + ' ' + (width - 5) + ',' + (height - 2) + ' 5,' + (height - 2) + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1" />';
				path += '<polygon points="4,' + ((height / 2) - 1) + ' ' + (width / 2) + ',4 ' + (width - 4) + ',' + ((height / 2) - 1) + ' ' + (width - 7) + ',' + (height - 4) + ' 7,' + (height - 4) + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '" />';
			}
			else if (this.options.shape === "hexagon") {
				if (this.options.highlight) path += '<polygon points="2,' + (height / 2) + ' 6,2 ' + (width - 6) + ',2 ' + (width - 2) + ',' + (height / 2) + ' ' + (width - 6) + ',' + (height - 2) + ' 6,' + (height - 2) + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1" />';
				path += '<polygon points="5,' + ((height / 2) - 3) + ' ' + (width / 2) + ',4 ' + (width - 5) + ',' + ((height / 2) - 3) + ' ' + (width - 5) + ',' + ((height / 2) + 3) + ' ' + (width / 2) + ',' + (height - 4) + ' 5,' + ((height / 2) + 3) + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '" />';
			}
			else if (this.options.shape === "circle") {
				if (this.options.highlight) path += '<circle class="circle-highlight" cx="' + (width / 2) + '" cy="' + (height / 2) + '" r="' + hr + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1"/>';
				path += '<circle class="' + className + '" cx="' + (width / 2) + '" cy="' + (height / 2) + '" r="' + r + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '"/>';
			}
			else if (this.options.shape === "diamond") {
				if (this.options.highlight) path += '<rect class="rect-highlight" x="8.5" y="-8.5" width="' + (hh - 5) + '" height="' + (hh - 5) + '" stroke-width="1" stroke="#000000" stroke-opacity="1" fill="#ffffff" fill-opacity="1" transform="rotate(45)"/>';
				path += '<rect class="' + className + '" x="' + (this.options.iconSize.x === 24 ? 11 : 9) + '" y="' + (this.options.iconSize.y === 24 ? -6 : -5) + '" width="' + (h - 2) + '" height="' + (h - 2) + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '" transform="rotate(45)"/>';
			}
			else {
				path += '<path class="' + className + '" d="' + pathDescription + '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity + '" fill="' + fill + '" fill-opacity="' + fillOpacity + '"/>';
			}
			return path;
		},
		_createCircle: function () {
			var cx = Number(this.options.circleAnchor.x)
			var cy = Number(this.options.circleAnchor.y)
			var radius = (this.options.iconSize.x - 8) / 2 * Number(this.options.circleRatio)
			var fill = this.options.circleFillColor
			var fillOpacity = this.options.circleFillOpacity
			var stroke = this.options.circleColor
			var strokeOpacity = this.options.circleOpacity
			var strokeWidth = this.options.circleWeight
			var className = this.options.className + "-circle"

			var circle = '<circle class="' + className + '" cx="' + cx + '" cy="' + cy + '" r="' + radius +
				'" fill="' + fill + '" fill-opacity="' + fillOpacity +
				'" stroke="' + stroke + '" stroke-opacity=' + strokeOpacity + '" stroke-width="' + strokeWidth + '"/>'

			return circle
		},
		_createImage: function () {
			if (!this.options.img) return "";
			var x = this.options.img.x;
			var y = this.options.img.y;
			var height = this.options.img.height + "px";
			var width = this.options.img.width + "px";
			var url = this.options.img.url;

			var text = "<image xlink:href='" + url + "' x='" + x + "' y='" + y + "' width='" + width + "' height='" + height + "' />";

			return text;
		},
		_createText: function () {
			var fontSize = this.options.fontSize + "px"
			var lineHeight = Number(this.options.fontSize)

			var x = Number(this.options.iconSize.x) / 2
			var y = x + (lineHeight * 0.35) //35% was found experimentally 
			var circleText = this.options.circleText;
			if (!circleText) return "";
			var textColor = this.options.fontColor.replace("rgb(", "rgba(").replace(")", "," + this.options.fontOpacity + ")")

			var text = '<text text-anchor="middle" x="' + x + '" y="' + y + '" style="font-size: ' + fontSize + '" fill="' + textColor + '">' + circleText + '</text>'

			return text;
		}
	});

	for (var j in stype_map) {
		for (const i in site_fuze_site_id_status) {
			c.addIcon("svg_site_mpt_" + j + "_" + i, L.divIcon.svgIcon({
				circleRatio: 0,
				circleFillColor: "#ffffff",
				fillOpacity: 1,
				opacity: 1,
				shape: stype_map[j].name,
				iconSize: [22, 22],
				color: "#000000",
				fillColor: site_fuze_site_id_status[i],
				popupAnchor: [0, -15],
				weight: 1
			}));
		}
	}
	
	viewType = "CoverageView";
	tileLayersInitialized = false;
	leafCompare = leaf;
	$("#map .leaflet-control-container").append("<div id='layersIcon' class='button-container layerlist leaflet-bar leaflet-control' style='background-color: white;cursor: pointer;float: right;margin-top: 80px;margin-right: 9px;'><a onclick='openPopup(this)' class='leaflet-control-dropdown-layer fas fa-layer-group'></a></div>");
	$("#layerWindowLeft").hide();
	initiateJStree();

    var selectedCandidates = candidateSelectionResponse.CandidateSelectionData.length;
    for(let i=0; i<selectedCandidates;i++){
        var markerOptions = {
            "LATITUDE": candidateSelectionResponse.CandidateSelectionData[i].latitude,
            "LONGITUDE": candidateSelectionResponse.CandidateSelectionData[i].longitude,
            "VZ_SITE_INFO_ID": candidateSelectionResponse.CandidateSelectionData[i].fuze_site_id,
            "VZ_SITE_NAME": candidateSelectionResponse.CandidateSelectionData[i].site_name,
            "NAME": candidateSelectionResponse.CandidateSelectionData[i].hub_location,
        };
        var flag = "with-fuze-site-id";
        var icon = "svg_site_mpt_" + "MACRO" + "_" + flag;
        var circleMarker = //L.circle([Number(markerOptions.LATITUDE), Number(markerOptions.LONGITUDE)], {radius: 200, circleOptions: markerOptions}).addTo(leaf)
            L.marker([Number(markerOptions.LATITUDE), Number(markerOptions.LONGITUDE)], {
                icon: XYZ._icon_map[icon],
                markerOptions: markerOptions
            });
            plottedMarker.push(circleMarker)
        leaf.addLayer(plottedMarker[i]);
    }
	featureSectorGroup = L.featureGroup().addTo(leaf);
	rloplLayerGroup = L.featureGroup().addTo(leaf);
	leaf.on('dragend', function (e) {
		$('<style id="vpisectorstyle">div.vpi-sector-icon {pointer-events: none !important;}</style>').appendTo("head");
	});

	leaf.on("zoomstart", function () {
		oldzoom = leaf.getZoom();
	});	 
	coverageLayerGroup  = L.featureGroup().addTo(leaf);
	sectorLayerGroup = L.featureGroup().addTo(leaf);
}


function bindSitePopupFromSite(e) {
    var siteName = e.NAME;
    var n = c.hasNode(e.SITE_ID);
    // enodebs = enodebs? enodebs : [];
    // $.unique(enodebs); 
    var dispaly_tech_arr = []; 
    var cellDiv = ``;
    var nonCellDiv = ``; 
    // var  tech_non_3g = data.TECHNOLOGYTYPE_NON_3G;
    // var tech_3g = data.TECHNOLOGYTYPE_3G;
    // if(tech_non_3g != null && tech_non_3g !=''){
    //     dispaly_tech_arr.push(tech_non_3g);
    //     nonCellDiv = `<div>
    //     <div class="halfdiv"><h5>eNodeB Group</h5></div>
    //     <div class="halfdiv">${data.ENODEBS}</div>
    // </div>`;
    // }
    
    // if(tech_3g != null && tech_3g !=''){
    //     dispaly_tech_arr.push(tech_3g);
    //     cellDiv=`<div>
    //     <div class="halfdiv"><h5>Cell No.</h5></div>
    //     <div class="halfdiv">${data.CELL}</div>
    // </div>`;
    // }

    var final_tech_type = dispaly_tech_arr.join("\n");

    // var popup = "<div style='background:white;'>"
    //     + "<h4>" + siteName + "</h4>"
    //     + "<div class='popup-inner' style='border:1px solid #d7d7d7;background: #f7f7f7; margin-bottom:10px; padding:0 5px;'>"
    //     + "<div><div class='halfdiv'><h5>Fuze Site Id</h5></div><div class='halfdiv'><a href='" + sitemanagementUrl + "/sites.jsp?siteId=" + fuzeSiteId + "' target='_blank' class='projectLink'>" + fuzeSiteId + "</a></div></div>"
    //     +nonCellDiv
    //     +cellDiv
    //     + "<div><div class='halfdiv'><h5>Technology Type</h5></div><div class='halfdiv'>" + final_tech_type + "</div></div>"
    //     + "<div><div class='halfdiv'><h5>Site Type</h5></div><div class='halfdiv'>" + siteType + "</div></div></div>"
    //     + "</div>";
    var popup = "<div style='background:white;'>"
    + "<h4>" + siteName + "</h4>"
    + "<div class='popup-inner' style='border:1px solid #d7d7d7;background: #f7f7f7; margin-bottom:10px; padding:0 5px;'>"
    + "</div>";
    // c.marker.unbindPopup();
    n.marker.bindPopup(popup);
    // c.marker.openPopup();
}

$("#edit_span_peer").click(function () {
    $("#edit_peer").click();
});


$('#edit_peer').click(function (event) {
    window.open(CONTEXT_PATH + '/uui/eapp/atoll_pg/designReview?parent_solution_id='
     + parseInt(getUrlVars().parent_solution_id) + '&&candidate_id=' + parseInt(selectedRows.closest("tr").find('td:eq(1)').text()), '_blank');
});

function removeNearerSites(){
    var data = plottedMarkerOfNearerSites;
	for(let i=0; i< data.length; i++){
		
		leaf.removeLayer(data[i]);
        }
}

function removeSelectedCandidateSite(){
    var data = plottedMarker;
	for(let i=0; i< data.length; i++){
		
		leaf.removeLayer(data[i]);
        }
}

var result;
function drawCoverageOnMap(){
	var candidateIds = '';
	if(candidateSelectionResponse.CandidateSelectionData && candidateSelectionResponse.CandidateSelectionData.length > 0){
		for (var i = 0; i < candidateSelectionResponse.CandidateSelectionData.length; i++) {
			//if(unchangeArray.indexOf(candidateSelectionResponse[i].tx_id) == -1){					
			  candidateIds = candidateIds +candidateSelectionResponse.CandidateSelectionData[i].candidate_id + ',';
			//}
		}	
	}
	
    var reqObj= {
    	"PARENT_SOLUTION_ID": parseInt($("#parentSolutionId").text()),
		"PROJECT_ID": parseInt($("#projectId").text()),
		"CANDIDATE_ID": candidateIds
	}
	
	$.ajax({
		type: "POST",
		url: CONTEXT_PATH + '/uui/eapp/atoll_pg/getCandidateCoverage',
		contentType: 'application/json',
		data: JSON.stringify(reqObj),
		success: function (data) {			
			$('#loading').hide();
			var sectorData = [];
			removeAllLayers();
        	removeAllSectorLayers();
			result = getUnique(data);
			createCoverageonMap();			
		},
		error: function (response) {
			$('#loading').hide();
			return null;
		}
	});	
}
function createCoverageonMap(){
	removeAllLayers();
	removeAllSectorLayers();
	for(var x in result){
		//var geoData = processdata[x];
		sectorData = [];
		for(var i=0; i<result[x].length;i++){
			var geoData1 =  result[x][i].geom_data;
			if(result[x][i].selected){
				if(geoData1 && geoData1 != "null"){
					var geoJson = {};
					var covgFeature= {};
					covgFeature.features = [];
					geoJson.geometry = JSON.parse(geoData1); 
					geoJson.type = "Feature";
					geoJson.properties = {};
					geoJson.properties.tx_id = result[x][i].transmitter_tx_id; 
					covgFeature.features.push(geoJson);
					covgFeature.type = "FeatureCollection";							
				    showPlotsOnMap(covgFeature, result[x][i].transmitter_tx_id);
				}
				 var transmitterData = JSON.parse(result[x][i].transmitter_data)
				 sectorData.push({
						"ABS_X": getLatLong(result[x][i].candidate_id).longitude,
						"ABS_Y": getLatLong(result[x][i].candidate_id).latitude,
						"FBAND": transmitterData.CELL_INFO[0].XC_CARRIER.split("_")[0],
						"VZ_SECTOR": transmitterData.SECTORID,
						"SITE_NAME":transmitterData.SI_NAME,
						"VZ_LTE_MAX_POWER": transmitterData.CONFIGURED_MAX_POWER,
						"AZIMUT": transmitterData.XT_AZIMUT,
						"TX_ID": transmitterData.tx_id,
						"CANDIDATE_ID": result[x][i].candidate_id,
						"TILT": transmitterData.AN_ELECTRICAL_TILT
			    });		
			}
	   }
		if(sectorData.length > 0){
			drawTransmitter(sectorData)
		}
	}
}
//var output =[];
function getUnique(array){
	var flags = [], output = [], l = array.length, i, temp = [];
	for( i=0; i<l; i++) {
		array[i].selected = true;
	    if( flags[array[i].site_revision_id]){	    	
	    	temp.push(array[i]);
	    	continue;
	    }
	    flags[array[i].site_revision_id] = true;
	    temp =[];
	    temp.push(array[i]);
	    output.push(temp);
	}
	
	return output;
}

function removeAllLayers(){
	if(coverageLayerGroup){
		coverageLayerGroup.eachLayer(function (layer) {
			if (leaf.hasLayer(layer)) {
				coverageLayerGroup.removeLayer(layer);
				leaf.removeLayer(layer);			
			}
		});
	}
}
function removeAllSectorLayers(){
	if(sectorLayerGroup){
		sectorLayerGroup.eachLayer(function (layer) {
			if (leaf.hasLayer(layer)) {
				sectorLayerGroup.removeLayer(layer);
				leaf.removeLayer(layer);			
			}
		});
	}
}

function getLatLong(id){
	var res;
	for(var i=0; i<candidateSelectionResponse.CandidateSelectionData.length;i++){
		if(candidateSelectionResponse.CandidateSelectionData[i].candidate_id == id){
			res = candidateSelectionResponse.CandidateSelectionData[i];
			break;
		}
	}
	
	return res;
}
function showPlotsOnMap(plotResponse, tx_id) {
	var psdPlotLayer = L.geoJSON(plotResponse, {
		style: function (feature) {
			if (feature.properties && !feature.properties.color) {
				feature.properties.color = getRandomColor();
			}
			return { color: feature.properties.color, opacity: 0.7, weight: 1 };
		}
	}
	);
	psdPlotLayer.id = tx_id;
	coverageLayerGroup.addLayer(psdPlotLayer);
	leaf.fitBounds(coverageLayerGroup.getBounds());
	/*if(selectedCard.transmitters && selectedCard.transmitters.length > 0){
	for (var i = 0; i < selectedCard.transmitters.length; i++) {
		if (selectedCard.transmitters[i].tx_id == tx_id) {
			selectedCard.transmitters[i].layerJSON = psdPlotLayer.toGeoJSON();
			break;
		}
	}
}*/
	
	plotLayersArr.set(tx_id, psdPlotLayer);
	return psdPlotLayer;
}

function getRandomColor() {
	var letters = '0123456789ABCDEF';
	var color = '#';
	for (var i = 0; i < 6; i++) {
		color += letters[Math.floor(Math.random() * 16)];
	}
	return color;
}

function drawTransmitter(data) {
	console.log(data);
	//data = data && data: [];
	var elist = [];
	// var n = siteIdList["node_" + name];
	// markerClusters.removeLayer(n);
	// //bindSiteNodePopup(n.options.markerOptions.NAME, n.options.markerOptions.VZ_SITE_NAME, n.options.markerOptions.VZ_SITE_INFO_ID, n.options.markerOptions.LATITUDE, n.options.markerOptions.LONGITUDE, n);
	// var nLat = n.options.markerOptions.LATITUDE;
	// var nLon = n.options.markerOptions.LONGITUDE;
	// var nZoom = leaf.getZoom() + 1;

	// if (!n) return;
	
	if (leaf.getZoom() <= 6) {
		multiplier = .6;
	} else if (leaf.getZoom() <= 10) {
		multiplier = .75;
	} else if (leaf.getZoom() <= 15) {
		multiplier = 1;
	} else {
		multiplier = 1.25
	}
	var count = 0.0;
	var sectorsData = {};

	$.each(data, function (i, v) {
		var sitename = v.SITE_NAME;
		if (!sectorsData[v.VZ_SECTOR]) {
			sectorsData[v.VZ_SECTOR] = {};
			sectorsData[v.VZ_SECTOR].ABS_X = v.ABS_X;
			sectorsData[v.VZ_SECTOR].ABS_Y = v.ABS_Y;
			sectorsData[v.VZ_SECTOR].BANDStr = v.FBAND;
			sectorsData[v.VZ_SECTOR].SECTOR = v.VZ_SECTOR;
			sectorsData[v.VZ_SECTOR].VZ_LTE_MAX_POWER = v.VZ_LTE_MAX_POWER;
			sectorsData[v.VZ_SECTOR].AZIMUT = v.AZIMUT;
			sectorsData[v.VZ_SECTOR].TX_ID = v.TX_ID;
			sectorsData[v.VZ_SECTOR].CANDIDATE_ID = v.CANDIDATE_ID;
			sectorsData[v.VZ_SECTOR].TILT = v.TILT;
			sectorsData[v.VZ_SECTOR].SITE_NAME = v.SITE_NAME;
			sectorsData[v.VZ_SECTOR].band = [];
			count++;
		}
		sectorsData[v.VZ_SECTOR].BANDStr += sectorsData[v.VZ_SECTOR].BANDStr == "" ? v.FBAND : ";" + v.FBAND;
		sectorsData[v.VZ_SECTOR].band.push(v);
	});
	/* $.each(data, function (i, v) {
		 if (!sectorsData[i]) {
			  sectorsData[i] = {};
			  sectorsData[i].ABS_X = v.ABS_X;
			  sectorsData[i].ABS_Y = v.ABS_Y;
			  sectorsData[i].BANDStr = v.FBAND;
			  sectorsData[i].SECTOR = v.VZ_SECTOR;
			  sectorsData[i].VZ_LTE_MAX_POWER = v.VZ_LTE_MAX_POWER;
			  sectorsData[i].AZIMUT = v.AZIMUT;
			  sectorsData[i].TX_ID = v.TX_ID;
			  sectorsData[i].TILT = v.TILT;
			  sectorsData[i].band = [];
			  count++;
		 }
	  //sectorsData[v.VZ_SECTOR].BANDStr += sectorsData[v.VZ_SECTOR].BANDStr == "" ? v.FBAND : ";" + v.FBAND;
	  sectorsData[i].band.push(v);
	 });*/
	var degree = 180 / count;
	if (360 === degree || 0 === degree) {
		degree = 359.9
	}
	// var azimuth = 0;
	for (var i in sectorsData) {
		var uid = sectorsData[i].SITE_NAME + ":" + i;
		//verisonTxMap[name] = verisonTxMap[name] ? verisonTxMap[name] : [];
		//console.log

		var azlist = [];
		//if (!transmitterNodeList["sect_" + uid]) {
		var sector = '<svg viewBox="0 0 160 160" height="100%" width="100%" className="vpi-sector-container" style="pointer-events: none;">';
		var color = "#00ac3e";
		$.each(sectorsData[i].band, function (j, v1) {
			var radius = 10 + ((69 / (sectorsData[i].band.length)) * (sectorsData[i].band.length - j));
			//if (verisonTxMap[name].indexOf(uid) < 0) {
			//   verisonTxMap[name].push("sect_" + uid);
			//}

			var azimuth = v1.AZIMUT;

			if (azlist.indexOf(azimuth) < 0) azlist.push(azimuth);
			var bd = v1.FBAND;
			var txid = v1.TX_ID;

			var sect = v1.VZ_SECTOR;
			//transmitterIdBandMap[name] = transmitterIdBandMap[name] ? transmitterIdBandMap[name] : {};
			//transmitterIdBandMap[name][sect] = transmitterIdBandMap[name][sect] ? transmitterIdBandMap[name][sect] : {};
			//transmitterIdBandMap[name][sect][bd] = v1;


			const x0 = 80, y0 = 80;
			const th0 = (azimuth - 90) * (Math.PI / 180);
			const half_width = (degree / 2) * (Math.PI / 180);
			const thA = th0 + half_width, thB = th0 - half_width;
			const xA = x0 + radius * Math.cos(thA), yA = y0 + radius * Math.sin(thA);
			const xB = x0 + radius * Math.cos(thB), yB = y0 + radius * Math.sin(thB);
			var r2 = 10 + ((69 / (sectorsData[i].band.length)) * (sectorsData[i].band.length - j - 1));
			const xAi = x0 + r2 * Math.cos(thA), yAi = y0 + r2 * Math.sin(thA);
			const xBi = x0 + r2 * Math.cos(thB), yBi = y0 + r2 * Math.sin(thB);
			var txr = (radius + r2) * 0.5;
			var txa = (thA + (thB < thA ? thB : thB + Math.PI * 2)) * 0.5;
			var txx = x0 + Math.cos(txa) * txr;
			var txy = y0 + Math.sin(txa) * txr;
			var opac = current_url === satellite_url ? 0.9 : 0.6;
			sector += '<g style="pointer-events: auto;"><path '
				+ 'class=""'
				+ 'd="M ' + xA + ' ' + yA + ' A ' + radius + ' ' + radius + ' ' + th0 + ' ' + (180 < degree ? 1 : 0) + ' 0 ' + xB + ' ' + yB + ' L ' + xBi + ' ' + yBi + ' A ' + r2 + ' ' + r2 + ' ' + th0 + ' ' + (180 <= degree ? 1 : 0) + ' 1 ' + xAi + ' ' + yAi + ' L ' + xA + ' ' + yA + '"' + 'stroke="' + '#00ff00' + '" '
				+ 'stroke-width="2" '
				+ 'fill="' + color + '" fill-opacity="0.65" '
				+ 'className="antenna-sector" '
				+ '><title>Transmitter Id: ' + txid + '| Sector: ' + i + ' | Band:' + bd + '</title></path>'
				+ '<text x="' + txx + '" y="' + txy + '" >' + bd + '</text></g>';
		});
		sector += '</svg>';
		azlist.sort();
		var markerOptions = {
			isSector: true,
			isVpi: true,
		};
		var sn = XYZ.node("sect_" + uid, Number(sectorsData[i].ABS_X), Number(sectorsData[i].ABS_Y), {
			icon: "svg_site_mpt_MACRO",
			markerOptions: markerOptions,
			tooltip: {
				options: {
					direction: "bottom",
					className: "nitro-tooltip",
					sticky: true,
					permanent: false
				}
			},
			popup: {
				html: ""
			}
		});
		//transmitterNodeList["sect_" + uid] = sn;
		try {
			sn.marker.setIcon(new L.divIcon({
				iconSize: [100 * multiplier, 100 * multiplier],
				popupAnchor: [0, 0],
				className: "transparent-background vpi-sector-icon",
				html: sector
			}));

			
			transmitterMap.set(sectorsData[i].CANDIDATE_ID, sn.marker);
			sectorLayerGroup.addLayer(sn.marker);
			// disable the dragging for the sector pie
			sn.marker.dragging.disable();
		} catch (err) {

		}


		// leaf.addLayer(sn.marker);
		// bindSectorPopup("sect_" + uid, sectorsData[i].TX_ID, name, sectorsData[i].ABS_X, sectorsData[i].ABS_Y, sectorsData[i]);
		//}
	}
}

function addSelectedCandidateSite(){
    var data = plottedMarker;
    for(let i=0; i< data.length; i++){
        leaf.addLayer(data[i]);
        }
}