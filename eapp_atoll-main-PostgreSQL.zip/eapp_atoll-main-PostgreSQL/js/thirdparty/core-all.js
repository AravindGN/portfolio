/**
 * JSTS. See https://github.com/bjornharrtell/jsts
 * https://github.com/bjornharrtell/jsts/blob/master/LICENSE_EDLv1.txt
 * https://github.com/bjornharrtell/jsts/blob/master/LICENSE_EPLv1.txt
 * https://github.com/bjornharrtell/jsts/blob/master/LICENSE_LICENSE_ES6_COLLECTIONS.txt
 * @license
 */
 !function(t,e){"object"==typeof exports&&"undefined"!=typeof module?e(exports):"function"==typeof define&&define.amd?define(["exports"],e):e(t.jsts={})}(this,function(t){"use strict";function e(t,e){for(var n in e)e.hasOwnProperty(n)&&(t[n]=e[n])}function n(){}function i(){}function r(t,e){this.low=0|e,this.high=0|t}function s(){}var o,a,u,l,h,c,f;function g(){}function d(){}function _(){}function p(){}function m(t){this.name="RuntimeException",this.message=t,this.stack=(new Error).stack,Error.call(this,t)}function v(t,e){t.prototype=Object.create(e.prototype),t.prototype.constructor=t}function y(){if(0===arguments.length)m.call(this);else if(1===arguments.length){var t=arguments[0];m.call(this,t)}}function x(){}function E(){if(this.x=null,this.y=null,this.z=null,0===arguments.length)E.call(this,0,0);else if(1===arguments.length){var t=arguments[0];E.call(this,t.x,t.y,t.z)}else if(2===arguments.length){var e=arguments[0],n=arguments[1];E.call(this,e,n,E.NULL_ORDINATE)}else if(3===arguments.length){var i=arguments[0],r=arguments[1],s=arguments[2];this.x=i,this.y=r,this.z=s}}function I(){if(this._dimensionsToTest=2,0===arguments.length)I.call(this,2);else if(1===arguments.length){var t=arguments[0];if(2!==t&&3!==t)throw new i("only 2 or 3 dimensions may be specified");this._dimensionsToTest=t}}function N(t,e){return t.interfaces_&&t.interfaces_().indexOf(e)>-1}function C(){}function S(){}function L(t){this.message=t||""}function w(){}function R(t){this.message=t||""}function T(t){this.message=t||""}function P(){this.array_=[],arguments[0]instanceof S&&this.addAll(arguments[0])}"fill"in Array.prototype||Object.defineProperty(Array.prototype,"fill",{configurable:!0,value:function(t){if(void 0===this||null===this)throw new TypeError(this+" is not an object");var e=Object(this),n=Math.max(Math.min(e.length,9007199254740991),0)||0,i=1 in arguments&&parseInt(Number(arguments[1]),10)||0;i=i<0?Math.max(n+i,0):Math.min(i,n);var r=2 in arguments&&void 0!==arguments[2]?parseInt(Number(arguments[2]),10)||0:n;for(r=r<0?Math.max(n+arguments[2],0):Math.min(r,n);i<r;)e[i]=t,++i;return e},writable:!0}),Number.isFinite=Number.isFinite||function(t){return"number"==typeof t&&isFinite(t)},Number.isInteger=Number.isInteger||function(t){return"number"==typeof t&&isFinite(t)&&Math.floor(t)===t},Number.parseFloat=Number.parseFloat||parseFloat,Number.isNaN=Number.isNaN||function(t){return t!=t},Math.trunc=Math.trunc||function(t){return t<0?Math.ceil(t):Math.floor(t)},e(n.prototype,{interfaces_:function(){return[]},getClass:function(){return n}}),n.equalsWithTolerance=function(t,e,n){return Math.abs(t-e)<=n},r.toBinaryString=function(t){for(var e="",n=2147483648;n>0;n>>>=1)e+=(t.high&n)===n?"1":"0";for(n=2147483648;n>0;n>>>=1)e+=(t.low&n)===n?"1":"0";return e},s.isNaN=function(t){return Number.isNaN(t)},s.isInfinite=function(t){return!Number.isFinite(t)},s.MAX_VALUE=Number.MAX_VALUE,"function"==typeof Float64Array&&"function"==typeof Int32Array?(h=2146435072,c=new Float64Array(1),f=new Int32Array(c.buffer),s.doubleToLongBits=function(t){c[0]=t;var e=0|f[0],n=0|f[1];return(n&h)===h&&0!=(1048575&n)&&0!==e&&(e=0,n=2146959360),new r(n,e)},s.longBitsToDouble=function(t){return f[0]=t.low,f[1]=t.high,c[0]}):(o=Math.log2,a=Math.floor,u=Math.pow,l=function(){for(var t=53;t>0;t--){var e=u(2,t)-1;if(a(o(e))+1===t)return e}return 0}(),s.doubleToLongBits=function(t){var e,n,i,s,h,c,f,g,d;if(t<0||1/t===Number.NEGATIVE_INFINITY?(c=1<<31,t=-t):c=0,0===t)return new r(g=c,d=0);if(t===1/0)return new r(g=2146435072|c,d=0);if(t!=t)return new r(g=2146959360,d=0);if(s=0,d=0,(e=a(t))>1)if(e<=l)(s=a(o(e)))<=20?(d=0,g=e<<20-s&1048575):(d=e%(n=u(2,i=s-20))<<32-i,g=e/n&1048575);else for(i=e,d=0;0!==(i=a(n=i/2));)s++,d>>>=1,d|=(1&g)<<31,g>>>=1,n!==i&&(g|=524288);if(f=s+1023,h=0===e,e=t-e,s<52&&0!==e)for(i=0;;){if((n=2*e)>=1?(e=n-1,h?(f--,h=!1):(i<<=1,i|=1,s++)):(e=n,h?0==--f&&(s++,h=!1):(i<<=1,s++)),20===s)g|=i,i=0;else if(52===s){d|=i;break}if(1===n){s<20?g|=i<<20-s:s<52&&(d|=i<<52-s);break}}return g|=f<<20,new r(g|=c,d)},s.longBitsToDouble=function(t){var e,n,i,r,s=t.high,o=t.low;n=s&1<<31?-1:1,i=((2146435072&s)>>20)-1023,r=0,e=1<<19;for(var a=1;a<=20;a++)s&e&&(r+=u(2,-a)),e>>>=1;for(e=1<<31,a=21;a<=52;a++)o&e&&(r+=u(2,-a)),e>>>=1;if(-1023===i){if(0===r)return 0*n;i=-1022}else{if(1024===i)return 0===r?n/0:NaN;r+=1}return n*r*u(2,i)}),m.prototype=Object.create(Error.prototype),m.prototype.constructor=Error,v(y,m),e(y.prototype,{interfaces_:function(){return[]},getClass:function(){return y}}),e(x.prototype,{interfaces_:function(){return[]},getClass:function(){return x}}),x.shouldNeverReachHere=function(){if(0===arguments.length)x.shouldNeverReachHere(null);else if(1===arguments.length){var t=arguments[0];throw new y("Should never reach here"+(null!==t?": "+t:""))}},x.isTrue=function(){if(1===arguments.length){var t=arguments[0];x.isTrue(t,null)}else if(2===arguments.length){var e=arguments[0],n=arguments[1];if(!e)throw null===n?new y:new y(n)}},x.equals=function(){if(2===arguments.length){var t=arguments[0],e=arguments[1];x.equals(t,e,null)}else if(3===arguments.length){var n=arguments[0],i=arguments[1],r=arguments[2];if(!i.equals(n))throw new y("Expected "+n+" but encountered "+i+(null!==r?": "+r:""))}},e(E.prototype,{setOrdinate:function(t,e){switch(t){case E.X:this.x=e;break;case E.Y:this.y=e;break;case E.Z:this.z=e;break;default:throw new i("Invalid ordinate index: "+t)}},equals2D:function(){if(1===arguments.length){var t=arguments[0];return this.x===t.x&&this.y===t.y}if(2===arguments.length){var e=arguments[0],i=arguments[1];return!!n.equalsWithTolerance(this.x,e.x,i)&&!!n.equalsWithTolerance(this.y,e.y,i)}},getOrdinate:function(t){switch(t){case E.X:return this.x;case E.Y:return this.y;case E.Z:return this.z}throw new i("Invalid ordinate index: "+t)},equals3D:function(t){return this.x===t.x&&this.y===t.y&&(this.z===t.z||s.isNaN(this.z)&&s.isNaN(t.z))},equals:function(t){return t instanceof E&&this.equals2D(t)},equalInZ:function(t,e){return n.equalsWithTolerance(this.z,t.z,e)},compareTo:function(t){var e=t;return this.x<e.x?-1:this.x>e.x?1:this.y<e.y?-1:this.y>e.y?1:0},clone:function(){try{return null}catch(t){if(t instanceof CloneNotSupportedException)return x.shouldNeverReachHere("this shouldn't happen because this class is Cloneable"),null;throw t}},copy:function(){return new E(this)},toString:function(){return"("+this.x+", "+this.y+", "+this.z+")"},distance3D:function(t){var e=this.x-t.x,n=this.y-t.y,i=this.z-t.z;return Math.sqrt(e*e+n*n+i*i)},distance:function(t){var e=this.x-t.x,n=this.y-t.y;return Math.sqrt(e*e+n*n)},hashCode:function(){var t=17;return t=37*(t=37*t+E.hashCode(this.x))+E.hashCode(this.y)},setCoordinate:function(t){this.x=t.x,this.y=t.y,this.z=t.z},interfaces_:function(){return[g,d,p]},getClass:function(){return E}}),E.hashCode=function(){if(1===arguments.length&&"number"==typeof arguments[0]){var t=arguments[0],e=s.doubleToLongBits(t);return Math.trunc(e^e>>>32)}},e(I.prototype,{compare:function(t,e){var n=t,i=e,r=I.compare(n.x,i.x);if(0!==r)return r;var s=I.compare(n.y,i.y);return 0!==s?s:this._dimensionsToTest<=2?0:I.compare(n.z,i.z)},interfaces_:function(){return[_]},getClass:function(){return I}}),I.compare=function(t,e){return t<e?-1:t>e?1:s.isNaN(t)?s.isNaN(e)?0:-1:s.isNaN(e)?1:0},E.DimensionalComparator=I,E.serialVersionUID=0x5cbf2c235c7e5800,E.NULL_ORDINATE=s.NaN,E.X=0,E.Y=1,E.Z=2,C.prototype.hasNext=function(){},C.prototype.next=function(){},C.prototype.remove=function(){},S.prototype.add=function(){},S.prototype.addAll=function(){},S.prototype.isEmpty=function(){},S.prototype.iterator=function(){},S.prototype.size=function(){},S.prototype.toArray=function(){},S.prototype.remove=function(){},L.prototype=new Error,L.prototype.name="IndexOutOfBoundsException",w.prototype=Object.create(S.prototype),w.prototype.constructor=w,w.prototype.get=function(){},w.prototype.set=function(){},w.prototype.isEmpty=function(){},R.prototype=new Error,R.prototype.name="NoSuchElementException",T.prototype=new Error,T.prototype.name="OperationNotSupported",P.prototype=Object.create(w.prototype),P.prototype.constructor=P,P.prototype.ensureCapacity=function(){},P.prototype.interfaces_=function(){return[w,S]},P.prototype.add=function(t){return 1===arguments.length?this.array_.push(t):this.array_.splice(arguments[0],0,arguments[1]),!0},P.prototype.clear=function(){this.array_=[]},P.prototype.addAll=function(t){for(var e=t.iterator();e.hasNext();)this.add(e.next());return!0},P.prototype.set=function(t,e){var n=this.array_[t];return this.array_[t]=e,n},P.prototype.iterator=function(){return new O(this)},P.prototype.get=function(t){if(t<0||t>=this.size())throw new L;return this.array_[t]},P.prototype.isEmpty=function(){return 0===this.array_.length},P.prototype.size=function(){return this.array_.length},P.prototype.toArray=function(){for(var t=[],e=0,n=this.array_.length;e<n;e++)t.push(this.array_[e]);return t},P.prototype.remove=function(t){for(var e=!1,n=0,i=this.array_.length;n<i;n++)if(this.array_[n]===t){this.array_.splice(n,1),e=!0;break}return e};var O=function(t){this.arrayList_=t,this.position_=0};function b(){if(P.apply(this),0===arguments.length);else if(1===arguments.length){var t=arguments[0];this.ensureCapacity(t.length),this.add(t,!0)}else if(2===arguments.length){var e=arguments[0],n=arguments[1];this.ensureCapacity(e.length),this.add(e,n)}}function M(){if(this._minx=null,this._maxx=null,this._miny=null,this._maxy=null,0===arguments.length)this.init();else if(1===arguments.length){if(arguments[0]instanceof E){var t=arguments[0];this.init(t.x,t.x,t.y,t.y)}else if(arguments[0]instanceof M){var e=arguments[0];this.init(e)}}else if(2===arguments.length){var n=arguments[0],i=arguments[1];this.init(n.x,i.x,n.y,i.y)}else if(4===arguments.length){var r=arguments[0],s=arguments[1],o=arguments[2],a=arguments[3];this.init(r,s,o,a)}}function D(){}function A(){D.call(this,"Projective point not representable on the Cartesian plane.")}function F(t){this.str=t}function G(t){this.value=t}function q(){}function B(){if(this._hi=0,this._lo=0,0===arguments.length)this.init(0);else if(1===arguments.length){if("number"==typeof arguments[0]){var t=arguments[0];this.init(t)}else if(arguments[0]instanceof B){var e=arguments[0];this.init(e)}else if("string"==typeof arguments[0]){var n=arguments[0];B.call(this,B.parse(n))}}else if(2===arguments.length){var i=arguments[0],r=arguments[1];this.init(i,r)}}function V(){}function z(){}function Y(){}function k(){if(this.x=null,this.y=null,this.w=null,0===arguments.length)this.x=0,this.y=0,this.w=1;else if(1===arguments.length){var t=arguments[0];this.x=t.x,this.y=t.y,this.w=1}else if(2===arguments.length){if("number"==typeof arguments[0]&&"number"==typeof arguments[1]){var e=arguments[0],n=arguments[1];this.x=e,this.y=n,this.w=1}else if(arguments[0]instanceof k&&arguments[1]instanceof k){var i=arguments[0],r=arguments[1];this.x=i.y*r.w-r.y*i.w,this.y=r.x*i.w-i.x*r.w,this.w=i.x*r.y-r.x*i.y}else if(arguments[0]instanceof E&&arguments[1]instanceof E){var s=arguments[0],o=arguments[1];this.x=s.y-o.y,this.y=o.x-s.x,this.w=s.x*o.y-o.x*s.y}}else if(3===arguments.length){var a=arguments[0],u=arguments[1],l=arguments[2];this.x=a,this.y=u,this.w=l}else if(4===arguments.length){var h=arguments[0],c=arguments[1],f=arguments[2],g=arguments[3],d=h.y-c.y,_=c.x-h.x,p=h.x*c.y-c.x*h.y,m=f.y-g.y,v=g.x-f.x,y=f.x*g.y-g.x*f.y;this.x=_*y-v*p,this.y=m*p-d*y,this.w=d*v-m*_}}function U(){}function X(){}function H(){}function W(){}function j(){}function K(){this._envelope=null,this._factory=null,this._SRID=null,this._userData=null;var t=arguments[0];this._factory=t,this._SRID=t.getSRID()}function Z(){}function Q(){}function J(){}function $(){}function tt(){}function et(){}function nt(){}function it(){}function rt(){}function st(){}function ot(){}function at(){}function ut(){this.array_=[],arguments[0]instanceof S&&this.addAll(arguments[0])}O.prototype.next=function(){if(this.position_===this.arrayList_.size())throw new R;return this.arrayList_.get(this.position_++)},O.prototype.hasNext=function(){return this.position_<this.arrayList_.size()},O.prototype.set=function(t){return this.arrayList_.set(this.position_-1,t)},O.prototype.remove=function(){this.arrayList_.remove(this.arrayList_.get(this.position_))},v(b,P),e(b.prototype,{getCoordinate:function(t){return this.get(t)},addAll:function(){if(2===arguments.length&&"boolean"==typeof arguments[1]&&N(arguments[0],S)){for(var t=arguments[0],e=arguments[1],n=!1,i=t.iterator();i.hasNext();)this.add(i.next(),e),n=!0;return n}return P.prototype.addAll.apply(this,arguments)},clone:function(){for(var t=P.prototype.clone.call(this),e=0;e<this.size();e++)t.add(e,this.get(e).clone());return t},toCoordinateArray:function(){return this.toArray(b.coordArrayType)},add:function(){if(1===arguments.length){var t=arguments[0];P.prototype.add.call(this,t)}else if(2===arguments.length){if(arguments[0]instanceof Array&&"boolean"==typeof arguments[1]){var e=arguments[0],n=arguments[1];return this.add(e,n,!0),!0}if(arguments[0]instanceof E&&"boolean"==typeof arguments[1]){var i=arguments[0];if(!arguments[1])if(this.size()>=1)if(this.get(this.size()-1).equals2D(i))return null;P.prototype.add.call(this,i)}else if(arguments[0]instanceof Object&&"boolean"==typeof arguments[1]){var r=arguments[0],s=arguments[1];return this.add(r,s),!0}}else if(3===arguments.length){if("boolean"==typeof arguments[2]&&arguments[0]instanceof Array&&"boolean"==typeof arguments[1]){var o=arguments[0],a=arguments[1];if(arguments[2])for(var u=0;u<o.length;u++)this.add(o[u],a);else for(u=o.length-1;u>=0;u--)this.add(o[u],a);return!0}if("boolean"==typeof arguments[2]&&Number.isInteger(arguments[0])&&arguments[1]instanceof E){var l=arguments[0],h=arguments[1];if(!arguments[2]){var c=this.size();if(c>0){if(l>0)if(this.get(l-1).equals2D(h))return null;if(l<c)if(this.get(l).equals2D(h))return null}}P.prototype.add.call(this,l,h)}}else if(4===arguments.length){var f=arguments[0],g=arguments[1],d=arguments[2],_=arguments[3],p=1;d>_&&(p=-1);for(u=d;u!==_;u+=p)this.add(f[u],g);return!0}},closeRing:function(){this.size()>0&&this.add(new E(this.get(0)),!1)},interfaces_:function(){return[]},getClass:function(){return b}}),b.coordArrayType=new Array(0).fill(null),e(M.prototype,{getArea:function(){return this.getWidth()*this.getHeight()},equals:function(t){if(!(t instanceof M))return!1;var e=t;return this.isNull()?e.isNull():this._maxx===e.getMaxX()&&this._maxy===e.getMaxY()&&this._minx===e.getMinX()&&this._miny===e.getMinY()},intersection:function(t){if(this.isNull()||t.isNull()||!this.intersects(t))return new M;var e=this._minx>t._minx?this._minx:t._minx,n=this._miny>t._miny?this._miny:t._miny;return new M(e,this._maxx<t._maxx?this._maxx:t._maxx,n,this._maxy<t._maxy?this._maxy:t._maxy)},isNull:function(){return this._maxx<this._minx},getMaxX:function(){return this._maxx},covers:function(){if(1===arguments.length){if(arguments[0]instanceof E){var t=arguments[0];return this.covers(t.x,t.y)}if(arguments[0]instanceof M){var e=arguments[0];return!this.isNull()&&!e.isNull()&&(e.getMinX()>=this._minx&&e.getMaxX()<=this._maxx&&e.getMinY()>=this._miny&&e.getMaxY()<=this._maxy)}}else if(2===arguments.length){var n=arguments[0],i=arguments[1];return!this.isNull()&&(n>=this._minx&&n<=this._maxx&&i>=this._miny&&i<=this._maxy)}},intersects:function(){if(1===arguments.length){if(arguments[0]instanceof M){var t=arguments[0];return!this.isNull()&&!t.isNull()&&!(t._minx>this._maxx||t._maxx<this._minx||t._miny>this._maxy||t._maxy<this._miny)}if(arguments[0]instanceof E){var e=arguments[0];return this.intersects(e.x,e.y)}}else if(2===arguments.length){if(arguments[0]instanceof E&&arguments[1]instanceof E){var n=arguments[0],i=arguments[1];return!this.isNull()&&(!((n.x<i.x?n.x:i.x)>this._maxx)&&(!((n.x>i.x?n.x:i.x)<this._minx)&&(!((n.y<i.y?n.y:i.y)>this._maxy)&&!((n.y>i.y?n.y:i.y)<this._miny))))}if("number"==typeof arguments[0]&&"number"==typeof arguments[1]){var r=arguments[0],s=arguments[1];return!this.isNull()&&!(r>this._maxx||r<this._minx||s>this._maxy||s<this._miny)}}},getMinY:function(){return this._miny},getMinX:function(){return this._minx},expandToInclude:function(){if(1===arguments.length){if(arguments[0]instanceof E){var t=arguments[0];this.expandToInclude(t.x,t.y)}else if(arguments[0]instanceof M){var e=arguments[0];if(e.isNull())return null;this.isNull()?(this._minx=e.getMinX(),this._maxx=e.getMaxX(),this._miny=e.getMinY(),this._maxy=e.getMaxY()):(e._minx<this._minx&&(this._minx=e._minx),e._maxx>this._maxx&&(this._maxx=e._maxx),e._miny<this._miny&&(this._miny=e._miny),e._maxy>this._maxy&&(this._maxy=e._maxy))}}else if(2===arguments.length){var n=arguments[0],i=arguments[1];this.isNull()?(this._minx=n,this._maxx=n,this._miny=i,this._maxy=i):(n<this._minx&&(this._minx=n),n>this._maxx&&(this._maxx=n),i<this._miny&&(this._miny=i),i>this._maxy&&(this._maxy=i))}},minExtent:function(){if(this.isNull())return 0;var t=this.getWidth(),e=this.getHeight();return t<e?t:e},getWidth:function(){return this.isNull()?0:this._maxx-this._minx},compareTo:function(t){var e=t;return this.isNull()?e.isNull()?0:-1:e.isNull()?1:this._minx<e._minx?-1:this._minx>e._minx?1:this._miny<e._miny?-1:this._miny>e._miny?1:this._maxx<e._maxx?-1:this._maxx>e._maxx?1:this._maxy<e._maxy?-1:this._maxy>e._maxy?1:0},translate:function(t,e){if(this.isNull())return null;this.init(this.getMinX()+t,this.getMaxX()+t,this.getMinY()+e,this.getMaxY()+e)},toString:function(){return"Env["+this._minx+" : "+this._maxx+", "+this._miny+" : "+this._maxy+"]"},setToNull:function(){this._minx=0,this._maxx=-1,this._miny=0,this._maxy=-1},getHeight:function(){return this.isNull()?0:this._maxy-this._miny},maxExtent:function(){if(this.isNull())return 0;var t=this.getWidth(),e=this.getHeight();return t>e?t:e},expandBy:function(){if(1===arguments.length){var t=arguments[0];this.expandBy(t,t)}else if(2===arguments.length){var e=arguments[0],n=arguments[1];if(this.isNull())return null;this._minx-=e,this._maxx+=e,this._miny-=n,this._maxy+=n,(this._minx>this._maxx||this._miny>this._maxy)&&this.setToNull()}},contains:function(){if(1===arguments.length){if(arguments[0]instanceof M){var t=arguments[0];return this.covers(t)}if(arguments[0]instanceof E){var e=arguments[0];return this.covers(e)}}else if(2===arguments.length){var n=arguments[0],i=arguments[1];return this.covers(n,i)}},centre:function(){return this.isNull()?null:new E((this.getMinX()+this.getMaxX())/2,(this.getMinY()+this.getMaxY())/2)},init:function(){if(0===arguments.length)this.setToNull();else if(1===arguments.length){if(arguments[0]instanceof E){var t=arguments[0];this.init(t.x,t.x,t.y,t.y)}else if(arguments[0]instanceof M){var e=arguments[0];this._minx=e._minx,this._maxx=e._maxx,this._miny=e._miny,this._maxy=e._maxy}}else if(2===arguments.length){var n=arguments[0],i=arguments[1];this.init(n.x,i.x,n.y,i.y)}else if(4===arguments.length){var r=arguments[0],s=arguments[1],o=arguments[2],a=arguments[3];r<s?(this._minx=r,this._maxx=s):(this._minx=s,this._maxx=r),o<a?(this._miny=o,this._maxy=a):(this._miny=a,this._maxy=o)}},getMaxY:function(){return this._maxy},distance:function(t){if(this.intersects(t))return 0;var e=0;this._maxx<t._minx?e=t._minx-this._maxx:this._minx>t._maxx&&(e=this._minx-t._maxx);var n=0;return this._maxy<t._miny?n=t._miny-this._maxy:this._miny>t._maxy&&(n=this._miny-t._maxy),0===e?n:0===n?e:Math.sqrt(e*e+n*n)},hashCode:function(){var t=17;return t=37*(t=37*(t=37*(t=37*t+E.hashCode(this._minx))+E.hashCode(this._maxx))+E.hashCode(this._miny))+E.hashCode(this._maxy)},interfaces_:function(){return[g,p]},getClass:function(){return M}}),M.intersects=function(){if(3===arguments.length){var t=arguments[0],e=arguments[1],n=arguments[2];return n.x>=(t.x<e.x?t.x:e.x)&&n.x<=(t.x>e.x?t.x:e.x)&&n.y>=(t.y<e.y?t.y:e.y)&&n.y<=(t.y>e.y?t.y:e.y)}if(4===arguments.length){var i=arguments[0],r=arguments[1],s=arguments[2],o=arguments[3],a=Math.min(s.x,o.x),u=Math.max(s.x,o.x),l=Math.min(i.x,r.x),h=Math.max(i.x,r.x);return!(l>u)&&(!(h<a)&&(a=Math.min(s.y,o.y),u=Math.max(s.y,o.y),l=Math.min(i.y,r.y),h=Math.max(i.y,r.y),!(l>u)&&!(h<a)))}},M.serialVersionUID=0x51845cd552189800,v(A,D),e(A.prototype,{interfaces_:function(){return[]},getClass:function(){return A}}),F.prototype.append=function(t){this.str+=t},F.prototype.setCharAt=function(t,e){this.str=this.str.substr(0,t)+e+this.str.substr(t+1)},F.prototype.toString=function(t){return this.str},G.prototype.intValue=function(){return this.value},G.prototype.compareTo=function(t){return this.value<t?-1:this.value>t?1:0},G.isNaN=function(t){return Number.isNaN(t)},q.isWhitespace=function(t){return t<=32&&t>=0||127==t},q.toUpperCase=function(t){return t.toUpperCase()},e(B.prototype,{le:function(t){return this._hi<t._hi||this._hi===t._hi&&this._lo<=t._lo},extractSignificantDigits:function(t,e){var n=this.abs(),i=B.magnitude(n._hi),r=B.TEN.pow(i);(n=n.divide(r)).gt(B.TEN)?(n=n.divide(B.TEN),i+=1):n.lt(B.ONE)&&(n=n.multiply(B.TEN),i-=1);for(var s=i+1,o=new F,a=B.MAX_PRINT_DIGITS-1,u=0;u<=a;u++){t&&u===s&&o.append(".");var l=Math.trunc(n._hi);if(l<0)break;var h=!1,c=0;l>9?(h=!0,c="9"):c="0"+l,o.append(c),n=n.subtract(B.valueOf(l)).multiply(B.TEN),h&&n.selfAdd(B.TEN);var f=!0,g=B.magnitude(n._hi);if(g<0&&Math.abs(g)>=a-u&&(f=!1),!f)break}return e[0]=i,o.toString()},sqr:function(){return this.multiply(this)},doubleValue:function(){return this._hi+this._lo},subtract:function(){if(arguments[0]instanceof B){var t=arguments[0];return this.add(t.negate())}if("number"==typeof arguments[0]){var e=arguments[0];return this.add(-e)}},equals:function(){if(1===arguments.length&&arguments[0]instanceof B){var t=arguments[0];return this._hi===t._hi&&this._lo===t._lo}},isZero:function(){return 0===this._hi&&0===this._lo},selfSubtract:function(){if(arguments[0]instanceof B){var t=arguments[0];return this.isNaN()?this:this.selfAdd(-t._hi,-t._lo)}if("number"==typeof arguments[0]){var e=arguments[0];return this.isNaN()?this:this.selfAdd(-e,0)}},getSpecialNumberString:function(){return this.isZero()?"0.0":this.isNaN()?"NaN ":null},min:function(t){return this.le(t)?this:t},selfDivide:function(){if(1===arguments.length){if(arguments[0]instanceof B){var t=arguments[0];return this.selfDivide(t._hi,t._lo)}if("number"==typeof arguments[0]){var e=arguments[0];return this.selfDivide(e,0)}}else if(2===arguments.length){var n,i,r,s,o=arguments[0],a=arguments[1],u=null,l=null,h=null,c=null;return r=this._hi/o,c=(u=(h=B.SPLIT*r)-(u=h-r))*(l=(c=B.SPLIT*o)-(l=c-o))-(s=r*o)+u*(i=o-l)+(n=r-u)*l+n*i,c=r+(h=(this._hi-s-c+this._lo-r*a)/o),this._hi=c,this._lo=r-c+h,this}},dump:function(){return"DD<"+this._hi+", "+this._lo+">"},divide:function(){if(arguments[0]instanceof B){var t,e,n,i,r=arguments[0],o=null,a=null,u=null,l=null;return n=this._hi/r._hi,o=(u=B.SPLIT*n)-n,l=B.SPLIT*r._hi,t=n-(o=u-o),a=l-r._hi,i=n*r._hi,l=o*(a=l-a)-i+o*(e=r._hi-a)+t*a+t*e,new B(l=n+(u=(this._hi-i-l+this._lo-n*r._lo)/r._hi),n-l+u)}if("number"==typeof arguments[0]){var h=arguments[0];return s.isNaN(h)?B.createNaN():B.copy(this).selfDivide(h,0)}},ge:function(t){return this._hi>t._hi||this._hi===t._hi&&this._lo>=t._lo},pow:function(t){if(0===t)return B.valueOf(1);var e=new B(this),n=B.valueOf(1),i=Math.abs(t);if(i>1)for(;i>0;)i%2==1&&n.selfMultiply(e),(i/=2)>0&&(e=e.sqr());else n=e;return t<0?n.reciprocal():n},ceil:function(){if(this.isNaN())return B.NaN;var t=Math.ceil(this._hi),e=0;return t===this._hi&&(e=Math.ceil(this._lo)),new B(t,e)},compareTo:function(t){var e=t;return this._hi<e._hi?-1:this._hi>e._hi?1:this._lo<e._lo?-1:this._lo>e._lo?1:0},rint:function(){return this.isNaN()?this:this.add(.5).floor()},setValue:function(){if(arguments[0]instanceof B){var t=arguments[0];return this.init(t),this}if("number"==typeof arguments[0]){var e=arguments[0];return this.init(e),this}},max:function(t){return this.ge(t)?this:t},sqrt:function(){if(this.isZero())return B.valueOf(0);if(this.isNegative())return B.NaN;var t=1/Math.sqrt(this._hi),e=this._hi*t,n=B.valueOf(e),i=this.subtract(n.sqr())._hi*(.5*t);return n.add(i)},selfAdd:function(){if(1===arguments.length){if(arguments[0]instanceof B){var t=arguments[0];return this.selfAdd(t._hi,t._lo)}if("number"==typeof arguments[0]){var e=arguments[0],n=null,i=null,r=null,s=null,o=null,a=null;return s=(r=this._hi+e)-(o=r-this._hi),i=(a=(s=e-o+(this._hi-s))+this._lo)+(r-(n=r+a)),this._hi=n+i,this._lo=i+(n-this._hi),this}}else if(2===arguments.length){var u,l=arguments[0],h=arguments[1],c=(n=null,i=null,null);r=null,s=null,o=null,a=null;r=this._hi+l,u=this._lo+h,s=r-(o=r-this._hi),c=u-(a=u-this._lo),s=l-o+(this._hi-s),c=h-a+(this._lo-c);var f=(n=r+(o=s+u))+(o=c+(i=o+(r-n))),g=o+(n-f);return this._hi=f,this._lo=g,this}},selfMultiply:function(){if(1===arguments.length){if(arguments[0]instanceof B){var t=arguments[0];return this.selfMultiply(t._hi,t._lo)}if("number"==typeof arguments[0]){var e=arguments[0];return this.selfMultiply(e,0)}}else if(2===arguments.length){var n,i,r=arguments[0],s=arguments[1],o=null,a=null,u=null,l=null;o=(u=B.SPLIT*this._hi)-this._hi,l=B.SPLIT*r,o=u-o,n=this._hi-o,a=l-r;var h=(u=this._hi*r)+(l=o*(a=l-a)-u+o*(i=r-a)+n*a+n*i+(this._hi*s+this._lo*r)),c=l+(o=u-h);return this._hi=h,this._lo=c,this}},selfSqr:function(){return this.selfMultiply(this)},floor:function(){if(this.isNaN())return B.NaN;var t=Math.floor(this._hi),e=0;return t===this._hi&&(e=Math.floor(this._lo)),new B(t,e)},negate:function(){return this.isNaN()?this:new B(-this._hi,-this._lo)},clone:function(){try{return null}catch(t){if(t instanceof CloneNotSupportedException)return null;throw t}},multiply:function(){if(arguments[0]instanceof B){var t=arguments[0];return t.isNaN()?B.createNaN():B.copy(this).selfMultiply(t)}if("number"==typeof arguments[0]){var e=arguments[0];return s.isNaN(e)?B.createNaN():B.copy(this).selfMultiply(e,0)}},isNaN:function(){return s.isNaN(this._hi)},intValue:function(){return Math.trunc(this._hi)},toString:function(){var t=B.magnitude(this._hi);return t>=-3&&t<=20?this.toStandardNotation():this.toSciNotation()},toStandardNotation:function(){var t=this.getSpecialNumberString();if(null!==t)return t;var e=new Array(1).fill(null),n=this.extractSignificantDigits(!0,e),i=e[0]+1,r=n;if("."===n.charAt(0))r="0"+n;else if(i<0)r="0."+B.stringOfChar("0",-i)+n;else if(-1===n.indexOf(".")){var s=i-n.length;r=n+B.stringOfChar("0",s)+".0"}return this.isNegative()?"-"+r:r},reciprocal:function(){var t,e,n,i,r=null,s=null,o=null,a=null;n=1/this._hi,r=(o=B.SPLIT*n)-n,a=B.SPLIT*this._hi,t=n-(r=o-r),s=a-this._hi;var u=n+(o=(1-(i=n*this._hi)-(a=r*(s=a-s)-i+r*(e=this._hi-s)+t*s+t*e)-n*this._lo)/this._hi);return new B(u,n-u+o)},toSciNotation:function(){if(this.isZero())return B.SCI_NOT_ZERO;var t=this.getSpecialNumberString();if(null!==t)return t;var e=new Array(1).fill(null),n=this.extractSignificantDigits(!1,e),i=B.SCI_NOT_EXPONENT_CHAR+e[0];if("0"===n.charAt(0))throw new IllegalStateException("Found leading zero: "+n);var r="";n.length>1&&(r=n.substring(1));var s=n.charAt(0)+"."+r;return this.isNegative()?"-"+s+i:s+i},abs:function(){return this.isNaN()?B.NaN:this.isNegative()?this.negate():new B(this)},isPositive:function(){return this._hi>0||0===this._hi&&this._lo>0},lt:function(t){return this._hi<t._hi||this._hi===t._hi&&this._lo<t._lo},add:function(){if(arguments[0]instanceof B){var t=arguments[0];return B.copy(this).selfAdd(t)}if("number"==typeof arguments[0]){var e=arguments[0];return B.copy(this).selfAdd(e)}},init:function(){if(1===arguments.length){if("number"==typeof arguments[0]){var t=arguments[0];this._hi=t,this._lo=0}else if(arguments[0]instanceof B){var e=arguments[0];this._hi=e._hi,this._lo=e._lo}}else if(2===arguments.length){var n=arguments[0],i=arguments[1];this._hi=n,this._lo=i}},gt:function(t){return this._hi>t._hi||this._hi===t._hi&&this._lo>t._lo},isNegative:function(){return this._hi<0||0===this._hi&&this._lo<0},trunc:function(){return this.isNaN()?B.NaN:this.isPositive()?this.floor():this.ceil()},signum:function(){return this._hi>0?1:this._hi<0?-1:this._lo>0?1:this._lo<0?-1:0},interfaces_:function(){return[p,g,d]},getClass:function(){return B}}),B.sqr=function(t){return B.valueOf(t).selfMultiply(t)},B.valueOf=function(){if("string"==typeof arguments[0]){var t=arguments[0];return B.parse(t)}if("number"==typeof arguments[0])return new B(arguments[0])},B.sqrt=function(t){return B.valueOf(t).sqrt()},B.parse=function(t){for(var e=0,n=t.length;q.isWhitespace(t.charAt(e));)e++;var i=!1;if(e<n){var r=t.charAt(e);"-"!==r&&"+"!==r||(e++,"-"===r&&(i=!0))}for(var s=new B,o=0,a=0,u=0;!(e>=n);){var l=t.charAt(e);if(e++,q.isDigit(l)){var h=l-"0";s.selfMultiply(B.TEN),s.selfAdd(h),o++}else{if("."!==l){if("e"===l||"E"===l){var c=t.substring(e);try{u=G.parseInt(c)}catch(e){throw e instanceof NumberFormatException?new NumberFormatException("Invalid exponent "+c+" in string "+t):e}break}throw new NumberFormatException("Unexpected character '"+l+"' at position "+e+" in string "+t)}a=o}}var f=s,g=o-a-u;if(0===g)f=s;else if(g>0){var d=B.TEN.pow(g);f=s.divide(d)}else if(g<0){d=B.TEN.pow(-g);f=s.multiply(d)}return i?f.negate():f},B.createNaN=function(){return new B(s.NaN,s.NaN)},B.copy=function(t){return new B(t)},B.magnitude=function(t){var e=Math.abs(t),n=Math.log(e)/Math.log(10),i=Math.trunc(Math.floor(n));return 10*Math.pow(10,i)<=e&&(i+=1),i},B.stringOfChar=function(t,e){for(var n=new F,i=0;i<e;i++)n.append(t);return n.toString()},B.PI=new B(3.141592653589793,1.2246467991473532e-16),B.TWO_PI=new B(6.283185307179586,2.4492935982947064e-16),B.PI_2=new B(1.5707963267948966,6.123233995736766e-17),B.E=new B(2.718281828459045,1.4456468917292502e-16),B.NaN=new B(s.NaN,s.NaN),B.EPS=1.23259516440783e-32,B.SPLIT=134217729,B.MAX_PRINT_DIGITS=32,B.TEN=B.valueOf(10),B.ONE=B.valueOf(1),B.SCI_NOT_EXPONENT_CHAR="E",B.SCI_NOT_ZERO="0.0E0",e(V.prototype,{interfaces_:function(){return[]},getClass:function(){return V}}),V.orientationIndex=function(t,e,n){var i=V.orientationIndexFilter(t,e,n);if(i<=1)return i;var r=B.valueOf(e.x).selfAdd(-t.x),s=B.valueOf(e.y).selfAdd(-t.y),o=B.valueOf(n.x).selfAdd(-e.x),a=B.valueOf(n.y).selfAdd(-e.y);return r.selfMultiply(a).selfSubtract(s.selfMultiply(o)).signum()},V.signOfDet2x2=function(){if(arguments[0]instanceof B){var t=arguments[0],e=arguments[1],n=arguments[2],i=arguments[3];return t.multiply(i).selfSubtract(e.multiply(n)).signum()}if("number"==typeof arguments[0]){var r=arguments[0],s=arguments[1],o=arguments[2],a=arguments[3],u=B.valueOf(r),l=B.valueOf(s),h=B.valueOf(o),c=B.valueOf(a);return u.multiply(c).selfSubtract(l.multiply(h)).signum()}},V.intersection=function(t,e,n,i){var r=B.valueOf(i.y).selfSubtract(n.y).selfMultiply(B.valueOf(e.x).selfSubtract(t.x)),s=B.valueOf(i.x).selfSubtract(n.x).selfMultiply(B.valueOf(e.y).selfSubtract(t.y)),o=r.subtract(s),a=B.valueOf(i.x).selfSubtract(n.x).selfMultiply(B.valueOf(t.y).selfSubtract(n.y)),u=B.valueOf(i.y).selfSubtract(n.y).selfMultiply(B.valueOf(t.x).selfSubtract(n.x)),l=a.subtract(u).selfDivide(o).doubleValue(),h=B.valueOf(t.x).selfAdd(B.valueOf(e.x).selfSubtract(t.x).selfMultiply(l)).doubleValue(),c=B.valueOf(e.x).selfSubtract(t.x).selfMultiply(B.valueOf(t.y).selfSubtract(n.y)),f=B.valueOf(e.y).selfSubtract(t.y).selfMultiply(B.valueOf(t.x).selfSubtract(n.x)),g=c.subtract(f).selfDivide(o).doubleValue();return new E(h,B.valueOf(n.y).selfAdd(B.valueOf(i.y).selfSubtract(n.y).selfMultiply(g)).doubleValue())},V.orientationIndexFilter=function(t,e,n){var i=null,r=(t.x-n.x)*(e.y-n.y),s=(t.y-n.y)*(e.x-n.x),o=r-s;if(r>0){if(s<=0)return V.signum(o);i=r+s}else{if(!(r<0))return V.signum(o);if(s>=0)return V.signum(o);i=-r-s}var a=V.DP_SAFE_EPSILON*i;return o>=a||-o>=a?V.signum(o):2},V.signum=function(t){return t>0?1:t<0?-1:0},V.DP_SAFE_EPSILON=1e-15,e(z.prototype,{interfaces_:function(){return[]},getClass:function(){return z}}),z.index=function(t,e,n){return V.orientationIndex(t,e,n)},z.isCCW=function(t){var e=t.length-1;if(e<3)throw new i("Ring has fewer than 4 points, so orientation cannot be determined");for(var n=t[0],r=0,s=1;s<=e;s++){var o=t[s];o.y>n.y&&(n=o,r=s)}var a=r;do{(a-=1)<0&&(a=e)}while(t[a].equals2D(n)&&a!==r);var u=r;do{u=(u+1)%e}while(t[u].equals2D(n)&&u!==r);var l=t[a],h=t[u];if(l.equals2D(n)||h.equals2D(n)||l.equals2D(h))return!1;var c=z.index(l,n,h);return 0===c?l.x>h.x:c>0},z.CLOCKWISE=-1,z.RIGHT=z.CLOCKWISE,z.COUNTERCLOCKWISE=1,z.LEFT=z.COUNTERCLOCKWISE,z.COLLINEAR=0,z.STRAIGHT=z.COLLINEAR,Y.arraycopy=function(t,e,n,i,r){for(var s=0,o=e;o<e+r;o++)n[i+s]=t[o],s++},Y.getProperty=function(t){return{"line.separator":"\n"}[t]},e(k.prototype,{getY:function(){var t=this.y/this.w;if(s.isNaN(t)||s.isInfinite(t))throw new A;return t},getX:function(){var t=this.x/this.w;if(s.isNaN(t)||s.isInfinite(t))throw new A;return t},getCoordinate:function(){var t=new E;return t.x=this.getX(),t.y=this.getY(),t},interfaces_:function(){return[]},getClass:function(){return k}}),k.intersection=function(t,e,n,i){var r=t.y-e.y,o=e.x-t.x,a=t.x*e.y-e.x*t.y,u=n.y-i.y,l=i.x-n.x,h=n.x*i.y-i.x*n.y,c=r*l-u*o,f=(o*h-l*a)/c,g=(u*a-r*h)/c;if(s.isNaN(f)||s.isInfinite(f)||s.isNaN(g)||s.isInfinite(g))throw new A;return new E(f,g)},e(U.prototype,{interfaces_:function(){return[]},getClass:function(){return U}}),U.log10=function(t){var e=Math.log(t);return s.isInfinite(e)?e:s.isNaN(e)?e:e/U.LOG_10},U.min=function(t,e,n,i){var r=t;return e<r&&(r=e),n<r&&(r=n),i<r&&(r=i),r},U.clamp=function(){if("number"==typeof arguments[2]&&"number"==typeof arguments[0]&&"number"==typeof arguments[1]){var t=arguments[0],e=arguments[1],n=arguments[2];return t<e?e:t>n?n:t}if(Number.isInteger(arguments[2])&&Number.isInteger(arguments[0])&&Number.isInteger(arguments[1])){var i=arguments[0],r=arguments[1],s=arguments[2];return i<r?r:i>s?s:i}},U.wrap=function(t,e){return t<0?e- -t%e:t%e},U.max=function(){if(3===arguments.length){var t=arguments[0],e=arguments[1],n=arguments[2];return e>(i=t)&&(i=e),n>i&&(i=n),i}if(4===arguments.length){var i,r=arguments[0],s=arguments[1],o=arguments[2],a=arguments[3];return s>(i=r)&&(i=s),o>i&&(i=o),a>i&&(i=a),i}},U.average=function(t,e){return(t+e)/2},U.LOG_10=Math.log(10),e(X.prototype,{interfaces_:function(){return[]},getClass:function(){return X}}),X.segmentToSegment=function(t,e,n,i){if(t.equals(e))return X.pointToSegment(t,n,i);if(n.equals(i))return X.pointToSegment(i,t,e);var r=!1;if(M.intersects(t,e,n,i)){var s=(e.x-t.x)*(i.y-n.y)-(e.y-t.y)*(i.x-n.x);if(0===s)r=!0;else{var o=(t.y-n.y)*(i.x-n.x)-(t.x-n.x)*(i.y-n.y),a=((t.y-n.y)*(e.x-t.x)-(t.x-n.x)*(e.y-t.y))/s,u=o/s;(u<0||u>1||a<0||a>1)&&(r=!0)}}else r=!0;return r?U.min(X.pointToSegment(t,n,i),X.pointToSegment(e,n,i),X.pointToSegment(n,t,e),X.pointToSegment(i,t,e)):0},X.pointToSegment=function(t,e,n){if(e.x===n.x&&e.y===n.y)return t.distance(e);var i=(n.x-e.x)*(n.x-e.x)+(n.y-e.y)*(n.y-e.y),r=((t.x-e.x)*(n.x-e.x)+(t.y-e.y)*(n.y-e.y))/i;if(r<=0)return t.distance(e);if(r>=1)return t.distance(n);var s=((e.y-t.y)*(n.x-e.x)-(e.x-t.x)*(n.y-e.y))/i;return Math.abs(s)*Math.sqrt(i)},X.pointToLinePerpendicular=function(t,e,n){var i=(n.x-e.x)*(n.x-e.x)+(n.y-e.y)*(n.y-e.y),r=((e.y-t.y)*(n.x-e.x)-(e.x-t.x)*(n.y-e.y))/i;return Math.abs(r)*Math.sqrt(i)},X.pointToSegmentString=function(t,e){if(0===e.length)throw new i("Line array must contain at least one vertex");for(var n=t.distance(e[0]),r=0;r<e.length-1;r++){var s=X.pointToSegment(t,e[r],e[r+1]);s<n&&(n=s)}return n},e(H.prototype,{setOrdinate:function(t,e,n){},size:function(){},getOrdinate:function(t,e){},getCoordinate:function(){},getCoordinateCopy:function(t){},getDimension:function(){},getX:function(t){},expandEnvelope:function(t){},copy:function(){},getY:function(t){},toCoordinateArray:function(){},interfaces_:function(){return[d]},getClass:function(){return H}}),H.X=0,H.Y=1,H.Z=2,H.M=3,e(W.prototype,{create:function(){1===arguments.length?arguments[0]instanceof Array||N(arguments[0],H):arguments.length},interfaces_:function(){return[]},getClass:function(){return W}}),e(j.prototype,{filter:function(t){},interfaces_:function(){return[]},getClass:function(){return j}}),e(K.prototype,{isGeometryCollection:function(){return this.getTypeCode()===K.TYPECODE_GEOMETRYCOLLECTION},getFactory:function(){return this._factory},getGeometryN:function(t){return this},getArea:function(){return 0},isRectangle:function(){return!1},equals:function(){if(arguments[0]instanceof K){var t=arguments[0];return null!==t&&this.equalsTopo(t)}if(arguments[0]instanceof Object){var e=arguments[0];if(!(e instanceof K))return!1;var n=e;return this.equalsExact(n)}},equalsExact:function(t){return this===t||this.equalsExact(t,0)},geometryChanged:function(){this.apply(K.geometryChangedFilter)},geometryChangedAction:function(){this._envelope=null},equalsNorm:function(t){return null!==t&&this.norm().equalsExact(t.norm())},getLength:function(){return 0},getNumGeometries:function(){return 1},compareTo:function(){if(1===arguments.length){var t=arguments[0],e=t;return this.getTypeCode()!==e.getTypeCode()?this.getTypeCode()-e.getTypeCode():this.isEmpty()&&e.isEmpty()?0:this.isEmpty()?-1:e.isEmpty()?1:this.compareToSameClass(t)}if(2===arguments.length){var n=arguments[0],i=arguments[1];e=n;return this.getTypeCode()!==e.getTypeCode()?this.getTypeCode()-e.getTypeCode():this.isEmpty()&&e.isEmpty()?0:this.isEmpty()?-1:e.isEmpty()?1:this.compareToSameClass(n,i)}},getUserData:function(){return this._userData},getSRID:function(){return this._SRID},getEnvelope:function(){return this.getFactory().toGeometry(this.getEnvelopeInternal())},checkNotGeometryCollection:function(t){if(t.getTypeCode()===K.TYPECODE_GEOMETRYCOLLECTION)throw new i("This method does not support GeometryCollection arguments")},equal:function(t,e,n){return 0===n?t.equals(e):t.distance(e)<=n},norm:function(){var t=this.copy();return t.normalize(),t},getPrecisionModel:function(){return this._factory.getPrecisionModel()},getEnvelopeInternal:function(){return null===this._envelope&&(this._envelope=this.computeEnvelopeInternal()),new M(this._envelope)},setSRID:function(t){this._SRID=t},setUserData:function(t){this._userData=t},compare:function(t,e){for(var n=t.iterator(),i=e.iterator();n.hasNext()&&i.hasNext();){var r=n.next(),s=i.next(),o=r.compareTo(s);if(0!==o)return o}return n.hasNext()?1:i.hasNext()?-1:0},hashCode:function(){return this.getEnvelopeInternal().hashCode()},isGeometryCollectionOrDerived:function(){return this.getTypeCode()===K.TYPECODE_GEOMETRYCOLLECTION||this.getTypeCode()===K.TYPECODE_MULTIPOINT||this.getTypeCode()===K.TYPECODE_MULTILINESTRING||this.getTypeCode()===K.TYPECODE_MULTIPOLYGON},interfaces_:function(){return[d,g,p]},getClass:function(){return K}}),K.hasNonEmptyElements=function(t){for(var e=0;e<t.length;e++)if(!t[e].isEmpty())return!0;return!1},K.hasNullElements=function(t){for(var e=0;e<t.length;e++)if(null===t[e])return!0;return!1},K.serialVersionUID=0x799ea46522854c00,K.TYPECODE_POINT=0,K.TYPECODE_MULTIPOINT=1,K.TYPECODE_LINESTRING=2,K.TYPECODE_LINEARRING=3,K.TYPECODE_MULTILINESTRING=4,K.TYPECODE_POLYGON=5,K.TYPECODE_MULTIPOLYGON=6,K.TYPECODE_GEOMETRYCOLLECTION=7,K.TYPENAME_POINT="Point",K.TYPENAME_MULTIPOINT="MultiPoint",K.TYPENAME_LINESTRING="LineString",K.TYPENAME_LINEARRING="LinearRing",K.TYPENAME_MULTILINESTRING="MultiLineString",K.TYPENAME_POLYGON="Polygon",K.TYPENAME_MULTIPOLYGON="MultiPolygon",K.TYPENAME_GEOMETRYCOLLECTION="GeometryCollection",K.geometryChangedFilter={interfaces_:function(){return[j]},filter:function(t){t.geometryChangedAction()}},e(Z.prototype,{filter:function(t){},interfaces_:function(){return[]},getClass:function(){return Z}}),e(Q.prototype,{isInBoundary:function(t){},interfaces_:function(){return[]},getClass:function(){return Q}}),e(J.prototype,{isInBoundary:function(t){return t%2==1},interfaces_:function(){return[Q]},getClass:function(){return J}}),e($.prototype,{isInBoundary:function(t){return t>0},interfaces_:function(){return[Q]},getClass:function(){return $}}),e(tt.prototype,{isInBoundary:function(t){return t>1},interfaces_:function(){return[Q]},getClass:function(){return tt}}),e(et.prototype,{isInBoundary:function(t){return 1===t},interfaces_:function(){return[Q]},getClass:function(){return et}}),Q.Mod2BoundaryNodeRule=J,Q.EndPointBoundaryNodeRule=$,Q.MultiValentEndPointBoundaryNodeRule=tt,Q.MonoValentEndPointBoundaryNodeRule=et,Q.MOD2_BOUNDARY_RULE=new J,Q.ENDPOINT_BOUNDARY_RULE=new $,Q.MULTIVALENT_ENDPOINT_BOUNDARY_RULE=new tt,Q.MONOVALENT_ENDPOINT_BOUNDARY_RULE=new et,Q.OGC_SFS_BOUNDARY_RULE=Q.MOD2_BOUNDARY_RULE,e(nt.prototype,{interfaces_:function(){return[]},getClass:function(){return nt}}),nt.isRing=function(t){return!(t.length<4)&&!!t[0].equals2D(t[t.length-1])},nt.ptNotInList=function(t,e){for(var n=0;n<t.length;n++){var i=t[n];if(nt.indexOf(i,e)<0)return i}return null},nt.scroll=function(t,e){var n=nt.indexOf(e,t);if(n<0)return null;var i=new Array(t.length).fill(null);Y.arraycopy(t,n,i,0,t.length-n),Y.arraycopy(t,0,i,t.length-n,n),Y.arraycopy(i,0,t,0,t.length)},nt.equals=function(){if(2===arguments.length){var t=arguments[0],e=arguments[1];if(t===e)return!0;if(null===t||null===e)return!1;if(t.length!==e.length)return!1;for(var n=0;n<t.length;n++)if(!t[n].equals(e[n]))return!1;return!0}if(3===arguments.length){var i=arguments[0],r=arguments[1],s=arguments[2];if(i===r)return!0;if(null===i||null===r)return!1;if(i.length!==r.length)return!1;for(n=0;n<i.length;n++)if(0!==s.compare(i[n],r[n]))return!1;return!0}},nt.intersection=function(t,e){for(var n=new b,i=0;i<t.length;i++)e.intersects(t[i])&&n.add(t[i],!0);return n.toCoordinateArray()},nt.hasRepeatedPoints=function(t){for(var e=1;e<t.length;e++)if(t[e-1].equals(t[e]))return!0;return!1},nt.removeRepeatedPoints=function(t){return nt.hasRepeatedPoints(t)?new b(t,!1).toCoordinateArray():t},nt.reverse=function(t){for(var e=t.length-1,n=Math.trunc(e/2),i=0;i<=n;i++){var r=t[i];t[i]=t[e-i],t[e-i]=r}},nt.removeNull=function(t){for(var e=0,n=0;n<t.length;n++)null!==t[n]&&e++;var i=new Array(e).fill(null);if(0===e)return i;var r=0;for(n=0;n<t.length;n++)null!==t[n]&&(i[r++]=t[n]);return i},nt.copyDeep=function(){if(1===arguments.length){for(var t=arguments[0],e=new Array(t.length).fill(null),n=0;n<t.length;n++)e[n]=new E(t[n]);return e}if(5===arguments.length){var i=arguments[0],r=arguments[1],s=arguments[2],o=arguments[3],a=arguments[4];for(n=0;n<a;n++)s[o+n]=new E(i[r+n])}},nt.isEqualReversed=function(t,e){for(var n=0;n<t.length;n++){var i=t[n],r=e[t.length-n-1];if(0!==i.compareTo(r))return!1}return!0},nt.envelope=function(t){for(var e=new M,n=0;n<t.length;n++)e.expandToInclude(t[n]);return e},nt.toCoordinateArray=function(t){return t.toArray(nt.coordArrayType)},nt.atLeastNCoordinatesOrNothing=function(t,e){return e.length>=t?e:[]},nt.indexOf=function(t,e){for(var n=0;n<e.length;n++)if(t.equals(e[n]))return n;return-1},nt.increasingDirection=function(t){for(var e=0;e<Math.trunc(t.length/2);e++){var n=t.length-1-e,i=t[e].compareTo(t[n]);if(0!==i)return i}return 1},nt.compare=function(t,e){for(var n=0;n<t.length&&n<e.length;){var i=t[n].compareTo(e[n]);if(0!==i)return i;n++}return n<e.length?-1:n<t.length?1:0},nt.minCoordinate=function(t){for(var e=null,n=0;n<t.length;n++)(null===e||e.compareTo(t[n])>0)&&(e=t[n]);return e},nt.extract=function(t,e,n){e=U.clamp(e,0,t.length);var i=(n=U.clamp(n,-1,t.length))-e+1;n<0&&(i=0),e>=t.length&&(i=0),n<e&&(i=0);var r=new Array(i).fill(null);if(0===i)return r;for(var s=0,o=e;o<=n;o++)r[s++]=t[o];return r},e(it.prototype,{compare:function(t,e){var n=t,i=e;return nt.compare(n,i)},interfaces_:function(){return[_]},getClass:function(){return it}}),e(rt.prototype,{compare:function(t,e){var n=t,i=e;if(n.length<i.length)return-1;if(n.length>i.length)return 1;if(0===n.length)return 0;var r=nt.compare(n,i);return nt.isEqualReversed(n,i)?0:r},OLDcompare:function(t,e){var n=t,i=e;if(n.length<i.length)return-1;if(n.length>i.length)return 1;if(0===n.length)return 0;for(var r=nt.increasingDirection(n),s=nt.increasingDirection(i),o=r>0?0:n.length-1,a=s>0?0:n.length-1,u=0;u<n.length;u++){var l=n[o].compareTo(i[a]);if(0!==l)return l;o+=r,a+=s}return 0},interfaces_:function(){return[_]},getClass:function(){return rt}}),nt.ForwardComparator=it,nt.BidirectionalComparator=rt,nt.coordArrayType=new Array(0).fill(null),st.prototype.get=function(){},st.prototype.put=function(){},st.prototype.size=function(){},st.prototype.values=function(){},st.prototype.entrySet=function(){},ot.prototype=new st,at.prototype=new S,at.prototype.contains=function(){},ut.prototype=new at,ut.prototype.contains=function(t){for(var e=0,n=this.array_.length;e<n;e++){if(this.array_[e]===t)return!0}return!1},ut.prototype.add=function(t){return!this.contains(t)&&(this.array_.push(t),!0)},ut.prototype.addAll=function(t){for(var e=t.iterator();e.hasNext();)this.add(e.next());return!0},ut.prototype.remove=function(t){throw new javascript.util.OperationNotSupported},ut.prototype.size=function(){return this.array_.length},ut.prototype.isEmpty=function(){return 0===this.array_.length},ut.prototype.toArray=function(){for(var t=[],e=0,n=this.array_.length;e<n;e++)t.push(this.array_[e]);return t},ut.prototype.iterator=function(){return new lt(this)};var lt=function(t){this.hashSet_=t,this.position_=0};lt.prototype.next=function(){if(this.position_===this.hashSet_.size())throw new R;return this.hashSet_.array_[this.position_++]},lt.prototype.hasNext=function(){return this.position_<this.hashSet_.size()},lt.prototype.remove=function(){throw new T};var ht=0;function ct(t){return null==t?ht:t.color}function ft(t){return null==t?null:t.parent}function gt(t,e){null!==t&&(t.color=e)}function dt(t){return null==t?null:t.left}function _t(t){return null==t?null:t.right}function pt(){this.root_=null,this.size_=0}function mt(){}function vt(){}function yt(){this.array_=[],arguments[0]instanceof S&&this.addAll(arguments[0])}pt.prototype=new ot,pt.prototype.get=function(t){for(var e=this.root_;null!==e;){var n=t.compareTo(e.key);if(n<0)e=e.left;else{if(!(n>0))return e.value;e=e.right}}return null},pt.prototype.put=function(t,e){if(null===this.root_)return this.root_={key:t,value:e,left:null,right:null,parent:null,color:ht,getValue:function(){return this.value},getKey:function(){return this.key}},this.size_=1,null;var n,i,r=this.root_;do{if(n=r,(i=t.compareTo(r.key))<0)r=r.left;else{if(!(i>0)){var s=r.value;return r.value=e,s}r=r.right}}while(null!==r);var o={key:t,left:null,right:null,value:e,parent:n,color:ht,getValue:function(){return this.value},getKey:function(){return this.key}};return i<0?n.left=o:n.right=o,this.fixAfterInsertion(o),this.size_++,null},pt.prototype.fixAfterInsertion=function(t){for(t.color=1;null!=t&&t!=this.root_&&1==t.parent.color;){var e;if(ft(t)==dt(ft(ft(t))))1==ct(e=_t(ft(ft(t))))?(gt(ft(t),ht),gt(e,ht),gt(ft(ft(t)),1),t=ft(ft(t))):(t==_t(ft(t))&&(t=ft(t),this.rotateLeft(t)),gt(ft(t),ht),gt(ft(ft(t)),1),this.rotateRight(ft(ft(t))));else 1==ct(e=dt(ft(ft(t))))?(gt(ft(t),ht),gt(e,ht),gt(ft(ft(t)),1),t=ft(ft(t))):(t==dt(ft(t))&&(t=ft(t),this.rotateRight(t)),gt(ft(t),ht),gt(ft(ft(t)),1),this.rotateLeft(ft(ft(t))))}this.root_.color=ht},pt.prototype.values=function(){var t=new P,e=this.getFirstEntry();if(null!==e)for(t.add(e.value);null!==(e=pt.successor(e));)t.add(e.value);return t},pt.prototype.entrySet=function(){var t=new ut,e=this.getFirstEntry();if(null!==e)for(t.add(e);null!==(e=pt.successor(e));)t.add(e);return t},pt.prototype.rotateLeft=function(t){if(null!=t){var e=t.right;t.right=e.left,null!=e.left&&(e.left.parent=t),e.parent=t.parent,null==t.parent?this.root_=e:t.parent.left==t?t.parent.left=e:t.parent.right=e,e.left=t,t.parent=e}},pt.prototype.rotateRight=function(t){if(null!=t){var e=t.left;t.left=e.right,null!=e.right&&(e.right.parent=t),e.parent=t.parent,null==t.parent?this.root_=e:t.parent.right==t?t.parent.right=e:t.parent.left=e,e.right=t,t.parent=e}},pt.prototype.getFirstEntry=function(){var t=this.root_;if(null!=t)for(;null!=t.left;)t=t.left;return t},pt.successor=function(t){if(null===t)return null;if(null!==t.right){for(var e=t.right;null!==e.left;)e=e.left;return e}e=t.parent;for(var n=t;null!==e&&n===e.right;)n=e,e=e.parent;return e},pt.prototype.size=function(){return this.size_},e(mt.prototype,{interfaces_:function(){return[]},getClass:function(){return mt}}),vt.prototype=new at,yt.prototype=new vt,yt.prototype.contains=function(t){for(var e=0,n=this.array_.length;e<n;e++){if(0===this.array_[e].compareTo(t))return!0}return!1},yt.prototype.add=function(t){if(this.contains(t))return!1;for(var e=0,n=this.array_.length;e<n;e++){if(1===this.array_[e].compareTo(t))return this.array_.splice(e,0,t),!0}return this.array_.push(t),!0},yt.prototype.addAll=function(t){for(var e=t.iterator();e.hasNext();)this.add(e.next());return!0},yt.prototype.remove=function(t){throw new T},yt.prototype.size=function(){return this.array_.length},yt.prototype.isEmpty=function(){return 0===this.array_.length},yt.prototype.toArray=function(){for(var t=[],e=0,n=this.array_.length;e<n;e++)t.push(this.array_[e]);return t},yt.prototype.iterator=function(){return new Et(this)};var xt,Et=function(t){this.treeSet_=t,this.position_=0};function It(){}function Nt(){}function Ct(){}function St(){}function Lt(){this._geometries=null;var t=arguments[0],e=arguments[1];if(K.call(this,e),null===t&&(t=[]),K.hasNullElements(t))throw new i("geometries must not contain null elements");this._geometries=t}function wt(){var t=arguments[0],e=arguments[1];Lt.call(this,t,e)}function Rt(){if(this._geom=null,this._geomFact=null,this._bnRule=null,this._endpointMap=null,1===arguments.length){var t=arguments[0];Rt.call(this,t,Q.MOD2_BOUNDARY_RULE)}else if(2===arguments.length){var e=arguments[0],n=arguments[1];this._geom=e,this._geomFact=e.getFactory(),this._bnRule=n}}function Tt(){this.count=null}function Pt(){}function Ot(){}function bt(){}function Mt(t){this.str=t}function Dt(){}function At(){this._points=null;var t=arguments[0],e=arguments[1];K.call(this,e),this.init(t)}function Ft(){}function Gt(){this._coordinates=null;var t=arguments[0],e=arguments[1];K.call(this,e),this.init(t)}function qt(){}function Bt(){}function Vt(){this._shell=null,this._holes=null;var t=arguments[0],e=arguments[1],n=arguments[2];if(K.call(this,n),null===t&&(t=this.getFactory().createLinearRing()),null===e&&(e=[]),K.hasNullElements(e))throw new i("holes must not contain null elements");if(t.isEmpty()&&K.hasNonEmptyElements(e))throw new i("shell is empty but holes are not");this._shell=t,this._holes=e}function zt(){var t=arguments[0],e=arguments[1];Lt.call(this,t,e)}function Yt(){if(arguments[0]instanceof Array&&arguments[1]instanceof se){var t=arguments[0],e=arguments[1];Yt.call(this,e.getCoordinateSequenceFactory().create(t),e)}else if(N(arguments[0],H)&&arguments[1]instanceof se){var n=arguments[0],i=arguments[1];At.call(this,n,i),this.validateConstruction()}}function kt(){var t=arguments[0],e=arguments[1];Lt.call(this,t,e)}function Ut(){if(this._factory=null,this._isUserDataCopied=!1,0===arguments.length);else if(1===arguments.length){var t=arguments[0];this._factory=t}}function Xt(){}function Ht(){}function Wt(){}function jt(){}function Kt(){if(this._dimension=3,this._coordinates=null,1===arguments.length){if(arguments[0]instanceof Array){var t=arguments[0];Kt.call(this,t,3)}else if(Number.isInteger(arguments[0])){var e=arguments[0];this._coordinates=new Array(e).fill(null);for(var n=0;n<e;n++)this._coordinates[n]=new E}else if(N(arguments[0],H)){var i=arguments[0];if(null===i)return this._coordinates=new Array(0).fill(null),null;this._dimension=i.getDimension(),this._coordinates=new Array(i.size()).fill(null);for(n=0;n<this._coordinates.length;n++)this._coordinates[n]=i.getCoordinateCopy(n)}}else if(2===arguments.length)if(arguments[0]instanceof Array&&Number.isInteger(arguments[1])){var r=arguments[0],s=arguments[1];this._coordinates=r,this._dimension=s,null===r&&(this._coordinates=new Array(0).fill(null))}else if(Number.isInteger(arguments[0])&&Number.isInteger(arguments[1])){var o=arguments[0],a=arguments[1];this._coordinates=new Array(o).fill(null),this._dimension=a;for(n=0;n<o;n++)this._coordinates[n]=new E}}function Zt(){}Et.prototype.next=function(){if(this.position_===this.treeSet_.size())throw new R;return this.treeSet_.array_[this.position_++]},Et.prototype.hasNext=function(){return this.position_<this.treeSet_.size()},Et.prototype.remove=function(){throw new T},It.sort=function(){var t,e,n,i,r=arguments[0];if(1===arguments.length)return i=function(t,e){return t.compareTo(e)},void r.sort(i);if(2===arguments.length)n=arguments[1],i=function(t,e){return n.compare(t,e)},r.sort(i);else{if(3===arguments.length){(e=r.slice(arguments[1],arguments[2])).sort();var s=r.slice(0,arguments[1]).concat(e,r.slice(arguments[2],r.length));for(r.splice(0,r.length),t=0;t<s.length;t++)r.push(s[t]);return}if(4===arguments.length){for(e=r.slice(arguments[1],arguments[2]),n=arguments[3],i=function(t,e){return n.compare(t,e)},e.sort(i),s=r.slice(0,arguments[1]).concat(e,r.slice(arguments[2],r.length)),r.splice(0,r.length),t=0;t<s.length;t++)r.push(s[t]);return}}},It.asList=function(t){for(var e=new P,n=0,i=t.length;n<i;n++)e.add(t[n]);return e},e(Nt.prototype,{interfaces_:function(){return[]},getClass:function(){return Nt}}),Nt.toDimensionSymbol=function(t){switch(t){case Nt.FALSE:return Nt.SYM_FALSE;case Nt.TRUE:return Nt.SYM_TRUE;case Nt.DONTCARE:return Nt.SYM_DONTCARE;case Nt.P:return Nt.SYM_P;case Nt.L:return Nt.SYM_L;case Nt.A:return Nt.SYM_A}throw new i("Unknown dimension value: "+t)},Nt.toDimensionValue=function(t){switch(q.toUpperCase(t)){case Nt.SYM_FALSE:return Nt.FALSE;case Nt.SYM_TRUE:return Nt.TRUE;case Nt.SYM_DONTCARE:return Nt.DONTCARE;case Nt.SYM_P:return Nt.P;case Nt.SYM_L:return Nt.L;case Nt.SYM_A:return Nt.A}throw new i("Unknown dimension symbol: "+t)},Nt.P=0,Nt.L=1,Nt.A=2,Nt.FALSE=-1,Nt.TRUE=-2,Nt.DONTCARE=-3,Nt.SYM_FALSE="F",Nt.SYM_TRUE="T",Nt.SYM_DONTCARE="*",Nt.SYM_P="0",Nt.SYM_L="1",Nt.SYM_A="2",e(Ct.prototype,{filter:function(t){},interfaces_:function(){return[]},getClass:function(){return Ct}}),e(St.prototype,{filter:function(t,e){},isDone:function(){},isGeometryChanged:function(){},interfaces_:function(){return[]},getClass:function(){return St}}),v(Lt,K),e(Lt.prototype,{computeEnvelopeInternal:function(){for(var t=new M,e=0;e<this._geometries.length;e++)t.expandToInclude(this._geometries[e].getEnvelopeInternal());return t},getGeometryN:function(t){return this._geometries[t]},getCoordinates:function(){for(var t=new Array(this.getNumPoints()).fill(null),e=-1,n=0;n<this._geometries.length;n++)for(var i=this._geometries[n].getCoordinates(),r=0;r<i.length;r++)t[++e]=i[r];return t},getArea:function(){for(var t=0,e=0;e<this._geometries.length;e++)t+=this._geometries[e].getArea();return t},equalsExact:function(){if(2===arguments.length&&"number"==typeof arguments[1]&&arguments[0]instanceof K){var t=arguments[0],e=arguments[1];if(!this.isEquivalentClass(t))return!1;var n=t;if(this._geometries.length!==n._geometries.length)return!1;for(var i=0;i<this._geometries.length;i++)if(!this._geometries[i].equalsExact(n._geometries[i],e))return!1;return!0}return K.prototype.equalsExact.apply(this,arguments)},normalize:function(){for(var t=0;t<this._geometries.length;t++)this._geometries[t].normalize();It.sort(this._geometries)},getCoordinate:function(){return this.isEmpty()?null:this._geometries[0].getCoordinate()},getBoundaryDimension:function(){for(var t=Nt.FALSE,e=0;e<this._geometries.length;e++)t=Math.max(t,this._geometries[e].getBoundaryDimension());return t},getTypeCode:function(){return K.TYPECODE_GEOMETRYCOLLECTION},getDimension:function(){for(var t=Nt.FALSE,e=0;e<this._geometries.length;e++)t=Math.max(t,this._geometries[e].getDimension());return t},getLength:function(){for(var t=0,e=0;e<this._geometries.length;e++)t+=this._geometries[e].getLength();return t},getNumPoints:function(){for(var t=0,e=0;e<this._geometries.length;e++)t+=this._geometries[e].getNumPoints();return t},getNumGeometries:function(){return this._geometries.length},reverse:function(){for(var t=this._geometries.length,e=new Array(t).fill(null),n=0;n<this._geometries.length;n++)e[n]=this._geometries[n].reverse();return this.getFactory().createGeometryCollection(e)},compareToSameClass:function(){if(1===arguments.length){var t=arguments[0],e=new yt(It.asList(this._geometries)),n=new yt(It.asList(t._geometries));return this.compare(e,n)}if(2===arguments.length){for(var i=arguments[0],r=arguments[1],s=i,o=this.getNumGeometries(),a=s.getNumGeometries(),u=0;u<o&&u<a;){var l=this.getGeometryN(u),h=s.getGeometryN(u),c=l.compareToSameClass(h,r);if(0!==c)return c;u++}return u<o?1:u<a?-1:0}},apply:function(){if(N(arguments[0],Z))for(var t=arguments[0],e=0;e<this._geometries.length;e++)this._geometries[e].apply(t);else if(N(arguments[0],St)){var n=arguments[0];if(0===this._geometries.length)return null;for(e=0;e<this._geometries.length&&(this._geometries[e].apply(n),!n.isDone());e++);n.isGeometryChanged()&&this.geometryChanged()}else if(N(arguments[0],Ct)){var i=arguments[0];i.filter(this);for(e=0;e<this._geometries.length;e++)this._geometries[e].apply(i)}else if(N(arguments[0],j)){var r=arguments[0];r.filter(this);for(e=0;e<this._geometries.length;e++)this._geometries[e].apply(r)}},getBoundary:function(){return this.checkNotGeometryCollection(this),x.shouldNeverReachHere(),null},getGeometryType:function(){return K.TYPENAME_GEOMETRYCOLLECTION},copy:function(){for(var t=new Array(this._geometries.length).fill(null),e=0;e<t.length;e++)t[e]=this._geometries[e].copy();return new Lt(t,this._factory)},isEmpty:function(){for(var t=0;t<this._geometries.length;t++)if(!this._geometries[t].isEmpty())return!1;return!0},interfaces_:function(){return[]},getClass:function(){return Lt}}),Lt.serialVersionUID=-0x4f07bcb1f857d800,v(wt,Lt),e(wt.prototype,{equalsExact:function(){if(2===arguments.length&&"number"==typeof arguments[1]&&arguments[0]instanceof K){var t=arguments[0],e=arguments[1];return!!this.isEquivalentClass(t)&&Lt.prototype.equalsExact.call(this,t,e)}return Lt.prototype.equalsExact.apply(this,arguments)},getBoundaryDimension:function(){return this.isClosed()?Nt.FALSE:0},isClosed:function(){if(this.isEmpty())return!1;for(var t=0;t<this._geometries.length;t++)if(!this._geometries[t].isClosed())return!1;return!0},getTypeCode:function(){return K.TYPECODE_MULTILINESTRING},getDimension:function(){return 1},reverse:function(){for(var t=this._geometries.length,e=new Array(t).fill(null),n=0;n<this._geometries.length;n++)e[t-1-n]=this._geometries[n].reverse();return this.getFactory().createMultiLineString(e)},getBoundary:function(){return new Rt(this).getBoundary()},getGeometryType:function(){return K.TYPENAME_MULTILINESTRING},copy:function(){for(var t=new Array(this._geometries.length).fill(null),e=0;e<t.length;e++)t[e]=this._geometries[e].copy();return new wt(t,this._factory)},interfaces_:function(){return[mt]},getClass:function(){return wt}}),wt.serialVersionUID=0x7155d2ab4afa8000,e(Rt.prototype,{boundaryMultiLineString:function(t){if(this._geom.isEmpty())return this.getEmptyMultiPoint();var e=this.computeBoundaryCoordinates(t);return 1===e.length?this._geomFact.createPoint(e[0]):this._geomFact.createMultiPointFromCoords(e)},getBoundary:function(){return this._geom instanceof At?this.boundaryLineString(this._geom):this._geom instanceof wt?this.boundaryMultiLineString(this._geom):this._geom.getBoundary()},boundaryLineString:function(t){return this._geom.isEmpty()?this.getEmptyMultiPoint():t.isClosed()?this._bnRule.isInBoundary(2)?t.getStartPoint():this._geomFact.createMultiPoint():this._geomFact.createMultiPoint([t.getStartPoint(),t.getEndPoint()])},getEmptyMultiPoint:function(){return this._geomFact.createMultiPoint()},computeBoundaryCoordinates:function(t){var e=new P;this._endpointMap=new pt;for(var n=0;n<t.getNumGeometries();n++){var i=t.getGeometryN(n);0!==i.getNumPoints()&&(this.addEndpoint(i.getCoordinateN(0)),this.addEndpoint(i.getCoordinateN(i.getNumPoints()-1)))}for(var r=this._endpointMap.entrySet().iterator();r.hasNext();){var s=r.next(),o=s.getValue().count;this._bnRule.isInBoundary(o)&&e.add(s.getKey())}return nt.toCoordinateArray(e)},addEndpoint:function(t){var e=this._endpointMap.get(t);null===e&&(e=new Tt,this._endpointMap.put(t,e)),e.count++},interfaces_:function(){return[]},getClass:function(){return Rt}}),Rt.getBoundary=function(){return 1===arguments.length?new Rt(arguments[0]).getBoundary():2===arguments.length?new Rt(arguments[0],arguments[1]).getBoundary():void 0},e(Tt.prototype,{interfaces_:function(){return[]},getClass:function(){return Tt}}),e(Pt.prototype,{interfaces_:function(){return[]},getClass:function(){return Pt}}),Pt.ofLine=function(t){var e=t.size();if(e<=1)return 0;var n=0,i=new E;t.getCoordinate(0,i);for(var r=i.x,s=i.y,o=1;o<e;o++){t.getCoordinate(o,i);var a=i.x,u=i.y,l=a-r,h=u-s;n+=Math.sqrt(l*l+h*h),r=a,s=u}return n},e(bt.prototype,{interfaces_:function(){return[]},getClass:function(){return bt}}),bt.chars=function(t,e){for(var n=new Array(e).fill(null),i=0;i<e;i++)n[i]=t;return new String(n)},bt.getStackTrace=function(){if(1===arguments.length){var t=arguments[0],e=new function(){},n=new function(){}(e);return t.printStackTrace(n),e.toString()}if(2===arguments.length){for(var i=arguments[0],r=arguments[1],s="",o=new function(){}(new function(){}(bt.getStackTrace(i))),a=0;a<r;a++)try{s+=o.readLine()+bt.NEWLINE}catch(t){if(!(t instanceof Ot))throw t;x.shouldNeverReachHere()}return s}},bt.split=function(t,e){for(var n=e.length,i=new P,r=""+t,s=r.indexOf(e);s>=0;){var o=r.substring(0,s);i.add(o),s=(r=r.substring(s+n)).indexOf(e)}r.length>0&&i.add(r);for(var a=new Array(i.size()).fill(null),u=0;u<a.length;u++)a[u]=i.get(u);return a},bt.toString=function(){if(1===arguments.length&&"number"==typeof arguments[0]){var t=arguments[0];return bt.SIMPLE_ORDINATE_FORMAT.format(t)}},bt.spaces=function(t){return bt.chars(" ",t)},bt.NEWLINE=Y.getProperty("line.separator"),bt.SIMPLE_ORDINATE_FORMAT=new function(){}("0.#"),Mt.prototype.append=function(t){this.str+=t},Mt.prototype.setCharAt=function(t,e){this.str=this.str.substr(0,t)+e+this.str.substr(t+1)},Mt.prototype.toString=function(t){return this.str},e(Dt.prototype,{interfaces_:function(){return[]},getClass:function(){return Dt}}),Dt.copyCoord=function(t,e,n,i){for(var r=Math.min(t.getDimension(),n.getDimension()),s=0;s<r;s++)n.setOrdinate(i,s,t.getOrdinate(e,s))},Dt.isRing=function(t){var e=t.size();return 0===e||!(e<=3)&&(t.getOrdinate(0,H.X)===t.getOrdinate(e-1,H.X)&&t.getOrdinate(0,H.Y)===t.getOrdinate(e-1,H.Y))},Dt.isEqual=function(t,e){var n=t.size();if(n!==e.size())return!1;for(var i=Math.min(t.getDimension(),e.getDimension()),r=0;r<n;r++)for(var o=0;o<i;o++){var a=t.getOrdinate(r,o),u=e.getOrdinate(r,o);if(t.getOrdinate(r,o)!==e.getOrdinate(r,o)&&(!s.isNaN(a)||!s.isNaN(u)))return!1}return!0},Dt.extend=function(t,e,n){var i=t.create(n,e.getDimension()),r=e.size();if(Dt.copy(e,0,i,0,r),r>0)for(var s=r;s<n;s++)Dt.copy(e,r-1,i,s,1);return i},Dt.reverse=function(t){for(var e=t.size()-1,n=Math.trunc(e/2),i=0;i<=n;i++)Dt.swap(t,i,e-i)},Dt.swap=function(t,e,n){if(e===n)return null;for(var i=0;i<t.getDimension();i++){var r=t.getOrdinate(e,i);t.setOrdinate(e,i,t.getOrdinate(n,i)),t.setOrdinate(n,i,r)}},Dt.copy=function(t,e,n,i,r){for(var s=0;s<r;s++)Dt.copyCoord(t,e+s,n,i+s)},Dt.toString=function(){if(1===arguments.length&&N(arguments[0],H)){var t=arguments[0],e=t.size();if(0===e)return"()";var n=t.getDimension(),i=new Mt;i.append("(");for(var r=0;r<e;r++){r>0&&i.append(" ");for(var s=0;s<n;s++)s>0&&i.append(","),i.append(bt.toString(t.getOrdinate(r,s)))}return i.append(")"),i.toString()}},Dt.ensureValidRing=function(t,e){var n=e.size();return 0===n?e:n<=3?Dt.createClosedRing(t,e,4):e.getOrdinate(0,H.X)===e.getOrdinate(n-1,H.X)&&e.getOrdinate(0,H.Y)===e.getOrdinate(n-1,H.Y)?e:Dt.createClosedRing(t,e,n+1)},Dt.createClosedRing=function(t,e,n){var i=t.create(n,e.getDimension()),r=e.size();Dt.copy(e,0,i,0,r);for(var s=r;s<n;s++)Dt.copy(e,0,i,s,1);return i},v(At,K),e(At.prototype,{computeEnvelopeInternal:function(){return this.isEmpty()?new M:this._points.expandEnvelope(new M)},isRing:function(){return this.isClosed()&&this.isSimple()},getCoordinates:function(){return this._points.toCoordinateArray()},equalsExact:function(){if(2===arguments.length&&"number"==typeof arguments[1]&&arguments[0]instanceof K){var t=arguments[0],e=arguments[1];if(!this.isEquivalentClass(t))return!1;var n=t;if(this._points.size()!==n._points.size())return!1;for(var i=0;i<this._points.size();i++)if(!this.equal(this._points.getCoordinate(i),n._points.getCoordinate(i),e))return!1;return!0}return K.prototype.equalsExact.apply(this,arguments)},normalize:function(){for(var t=0;t<Math.trunc(this._points.size()/2);t++){var e=this._points.size()-1-t;if(!this._points.getCoordinate(t).equals(this._points.getCoordinate(e))){if(this._points.getCoordinate(t).compareTo(this._points.getCoordinate(e))>0){var n=this._points.copy();Dt.reverse(n),this._points=n}return null}}},getCoordinate:function(){return this.isEmpty()?null:this._points.getCoordinate(0)},getBoundaryDimension:function(){return this.isClosed()?Nt.FALSE:0},isClosed:function(){return!this.isEmpty()&&this.getCoordinateN(0).equals2D(this.getCoordinateN(this.getNumPoints()-1))},getEndPoint:function(){return this.isEmpty()?null:this.getPointN(this.getNumPoints()-1)},getTypeCode:function(){return K.TYPECODE_LINESTRING},getDimension:function(){return 1},getLength:function(){return Pt.ofLine(this._points)},getNumPoints:function(){return this._points.size()},reverse:function(){var t=this._points.copy();return Dt.reverse(t),this.getFactory().createLineString(t)},compareToSameClass:function(){if(1===arguments.length){for(var t=arguments[0],e=0,n=0;e<this._points.size()&&n<t._points.size();){var i=this._points.getCoordinate(e).compareTo(t._points.getCoordinate(n));if(0!==i)return i;e++,n++}return e<this._points.size()?1:n<t._points.size()?-1:0}if(2===arguments.length){t=arguments[0];return arguments[1].compare(this._points,t._points)}},apply:function(){if(N(arguments[0],Z))for(var t=arguments[0],e=0;e<this._points.size();e++)t.filter(this._points.getCoordinate(e));else if(N(arguments[0],St)){var n=arguments[0];if(0===this._points.size())return null;for(e=0;e<this._points.size()&&(n.filter(this._points,e),!n.isDone());e++);n.isGeometryChanged()&&this.geometryChanged()}else if(N(arguments[0],Ct)){arguments[0].filter(this)}else if(N(arguments[0],j)){arguments[0].filter(this)}},getBoundary:function(){return new Rt(this).getBoundary()},isEquivalentClass:function(t){return t instanceof At},getCoordinateN:function(t){return this._points.getCoordinate(t)},getGeometryType:function(){return K.TYPENAME_LINESTRING},copy:function(){return new At(this._points.copy(),this._factory)},getCoordinateSequence:function(){return this._points},isEmpty:function(){return 0===this._points.size()},init:function(t){if(null===t&&(t=this.getFactory().getCoordinateSequenceFactory().create([])),1===t.size())throw new i("Invalid number of points in LineString (found "+t.size()+" - must be 0 or >= 2)");this._points=t},isCoordinate:function(t){for(var e=0;e<this._points.size();e++)if(this._points.getCoordinate(e).equals(t))return!0;return!1},getStartPoint:function(){return this.isEmpty()?null:this.getPointN(0)},getPointN:function(t){return this.getFactory().createPoint(this._points.getCoordinate(t))},interfaces_:function(){return[mt]},getClass:function(){return At}}),At.serialVersionUID=0x2b2b51ba435c8e00,e(Ft.prototype,{interfaces_:function(){return[]},getClass:function(){return Ft}}),v(Gt,K),e(Gt.prototype,{computeEnvelopeInternal:function(){if(this.isEmpty())return new M;var t=new M;return t.expandToInclude(this._coordinates.getX(0),this._coordinates.getY(0)),t},getCoordinates:function(){return this.isEmpty()?[]:[this.getCoordinate()]},equalsExact:function(){if(2===arguments.length&&"number"==typeof arguments[1]&&arguments[0]instanceof K){var t=arguments[0],e=arguments[1];return!!this.isEquivalentClass(t)&&(!(!this.isEmpty()||!t.isEmpty())||this.isEmpty()===t.isEmpty()&&this.equal(t.getCoordinate(),this.getCoordinate(),e))}return K.prototype.equalsExact.apply(this,arguments)},normalize:function(){},getCoordinate:function(){return 0!==this._coordinates.size()?this._coordinates.getCoordinate(0):null},getBoundaryDimension:function(){return Nt.FALSE},getTypeCode:function(){return K.TYPECODE_POINT},getDimension:function(){return 0},getNumPoints:function(){return this.isEmpty()?0:1},reverse:function(){return this.copy()},getX:function(){if(null===this.getCoordinate())throw new IllegalStateException("getX called on empty Point");return this.getCoordinate().x},compareToSameClass:function(){if(1===arguments.length){var t=arguments[0];return this.getCoordinate().compareTo(t.getCoordinate())}if(2===arguments.length){t=arguments[0];return arguments[1].compare(this._coordinates,t._coordinates)}},apply:function(){if(N(arguments[0],Z)){var t=arguments[0];if(this.isEmpty())return null;t.filter(this.getCoordinate())}else if(N(arguments[0],St)){var e=arguments[0];if(this.isEmpty())return null;e.filter(this._coordinates,0),e.isGeometryChanged()&&this.geometryChanged()}else if(N(arguments[0],Ct)){arguments[0].filter(this)}else if(N(arguments[0],j)){arguments[0].filter(this)}},getBoundary:function(){return this.getFactory().createGeometryCollection()},getGeometryType:function(){return K.TYPENAME_POINT},copy:function(){return new Gt(this._coordinates.copy(),this._factory)},getCoordinateSequence:function(){return this._coordinates},getY:function(){if(null===this.getCoordinate())throw new IllegalStateException("getY called on empty Point");return this.getCoordinate().y},isEmpty:function(){return 0===this._coordinates.size()},init:function(t){null===t&&(t=this.getFactory().getCoordinateSequenceFactory().create([])),x.isTrue(t.size()<=1),this._coordinates=t},isSimple:function(){return!0},interfaces_:function(){return[Ft]},getClass:function(){return Gt}}),Gt.serialVersionUID=0x44077bad161cbc00,e(qt.prototype,{interfaces_:function(){return[]},getClass:function(){return qt}}),qt.ofRing=function(){if(arguments[0]instanceof Array){var t=arguments[0];return Math.abs(qt.ofRingSigned(t))}if(N(arguments[0],H)){var e=arguments[0];return Math.abs(qt.ofRingSigned(e))}},qt.ofRingSigned=function(){if(arguments[0]instanceof Array){var t=arguments[0];if(t.length<3)return 0;for(var e=0,n=t[0].x,i=1;i<t.length-1;i++){var r=t[i].x-n,s=t[i+1].y;e+=r*(t[i-1].y-s)}return e/2}if(N(arguments[0],H)){var o=arguments[0],a=o.size();if(a<3)return 0;var u=new E,l=new E,h=new E;o.getCoordinate(0,l),o.getCoordinate(1,h);n=l.x;h.x-=n;for(e=0,i=1;i<a-1;i++)u.y=l.y,l.x=h.x,l.y=h.y,o.getCoordinate(i+1,h),h.x-=n,e+=l.x*(u.y-h.y);return e/2}},e(Bt.prototype,{interfaces_:function(){return[]},getClass:function(){return Bt}}),v(Vt,K),e(Vt.prototype,{computeEnvelopeInternal:function(){return this._shell.getEnvelopeInternal()},getCoordinates:function(){if(this.isEmpty())return[];for(var t=new Array(this.getNumPoints()).fill(null),e=-1,n=this._shell.getCoordinates(),i=0;i<n.length;i++)t[++e]=n[i];for(var r=0;r<this._holes.length;r++)for(var s=this._holes[r].getCoordinates(),o=0;o<s.length;o++)t[++e]=s[o];return t},getArea:function(){var t=0;t+=qt.ofRing(this._shell.getCoordinateSequence());for(var e=0;e<this._holes.length;e++)t-=qt.ofRing(this._holes[e].getCoordinateSequence());return t},isRectangle:function(){if(0!==this.getNumInteriorRing())return!1;if(null===this._shell)return!1;if(5!==this._shell.getNumPoints())return!1;for(var t=this._shell.getCoordinateSequence(),e=this.getEnvelopeInternal(),n=0;n<5;n++){if((s=t.getX(n))!==e.getMinX()&&s!==e.getMaxX())return!1;if((o=t.getY(n))!==e.getMinY()&&o!==e.getMaxY())return!1}var i=t.getX(0),r=t.getY(0);for(n=1;n<=4;n++){var s,o;if((s=t.getX(n))!==i===((o=t.getY(n))!==r))return!1;i=s,r=o}return!0},equalsExact:function(){if(2===arguments.length&&"number"==typeof arguments[1]&&arguments[0]instanceof K){var t=arguments[0],e=arguments[1];if(!this.isEquivalentClass(t))return!1;var n=t,i=this._shell,r=n._shell;if(!i.equalsExact(r,e))return!1;if(this._holes.length!==n._holes.length)return!1;for(var s=0;s<this._holes.length;s++)if(!this._holes[s].equalsExact(n._holes[s],e))return!1;return!0}return K.prototype.equalsExact.apply(this,arguments)},normalize:function(){if(0===arguments.length){this.normalize(this._shell,!0);for(var t=0;t<this._holes.length;t++)this.normalize(this._holes[t],!1);It.sort(this._holes)}else if(2===arguments.length){var e=arguments[0],n=arguments[1];if(e.isEmpty())return null;var i=new Array(e.getCoordinates().length-1).fill(null);Y.arraycopy(e.getCoordinates(),0,i,0,i.length);var r=nt.minCoordinate(e.getCoordinates());nt.scroll(i,r),Y.arraycopy(i,0,e.getCoordinates(),0,i.length),e.getCoordinates()[i.length]=i[0],z.isCCW(e.getCoordinates())===n&&nt.reverse(e.getCoordinates())}},getCoordinate:function(){return this._shell.getCoordinate()},getNumInteriorRing:function(){return this._holes.length},getBoundaryDimension:function(){return 1},getTypeCode:function(){return K.TYPECODE_POLYGON},getDimension:function(){return 2},getLength:function(){var t=0;t+=this._shell.getLength();for(var e=0;e<this._holes.length;e++)t+=this._holes[e].getLength();return t},getNumPoints:function(){for(var t=this._shell.getNumPoints(),e=0;e<this._holes.length;e++)t+=this._holes[e].getNumPoints();return t},reverse:function(){var t=this.copy();t._shell=this._shell.copy().reverse(),t._holes=new Array(this._holes.length).fill(null);for(var e=0;e<this._holes.length;e++)t._holes[e]=this._holes[e].copy().reverse();return t},convexHull:function(){return this.getExteriorRing().convexHull()},compareToSameClass:function(){if(1===arguments.length){var t=arguments[0],e=this._shell,n=t._shell;return e.compareToSameClass(n)}if(2===arguments.length){var i=arguments[0],r=arguments[1],s=i,o=(e=this._shell,n=s._shell,e.compareToSameClass(n,r));if(0!==o)return o;for(var a=this.getNumInteriorRing(),u=s.getNumInteriorRing(),l=0;l<a&&l<u;){var h=this.getInteriorRingN(l),c=s.getInteriorRingN(l),f=h.compareToSameClass(c,r);if(0!==f)return f;l++}return l<a?1:l<u?-1:0}},apply:function(){if(N(arguments[0],Z)){var t=arguments[0];this._shell.apply(t);for(var e=0;e<this._holes.length;e++)this._holes[e].apply(t)}else if(N(arguments[0],St)){var n=arguments[0];if(this._shell.apply(n),!n.isDone())for(e=0;e<this._holes.length&&(this._holes[e].apply(n),!n.isDone());e++);n.isGeometryChanged()&&this.geometryChanged()}else if(N(arguments[0],Ct)){arguments[0].filter(this)}else if(N(arguments[0],j)){var i=arguments[0];i.filter(this),this._shell.apply(i);for(e=0;e<this._holes.length;e++)this._holes[e].apply(i)}},getBoundary:function(){if(this.isEmpty())return this.getFactory().createMultiLineString();var t=new Array(this._holes.length+1).fill(null);t[0]=this._shell;for(var e=0;e<this._holes.length;e++)t[e+1]=this._holes[e];return t.length<=1?this.getFactory().createLinearRing(t[0].getCoordinateSequence()):this.getFactory().createMultiLineString(t)},getGeometryType:function(){return K.TYPENAME_POLYGON},copy:function(){for(var t=this._shell.copy(),e=new Array(this._holes.length).fill(null),n=0;n<this._holes.length;n++)e[n]=this._holes[n].copy();return new Vt(t,e,this._factory)},getExteriorRing:function(){return this._shell},isEmpty:function(){return this._shell.isEmpty()},getInteriorRingN:function(t){return this._holes[t]},interfaces_:function(){return[Bt]},getClass:function(){return Vt}}),Vt.serialVersionUID=-0x307ffefd8dc97200,v(zt,Lt),e(zt.prototype,{isValid:function(){return!0},equalsExact:function(){if(2===arguments.length&&"number"==typeof arguments[1]&&arguments[0]instanceof K){var t=arguments[0],e=arguments[1];return!!this.isEquivalentClass(t)&&Lt.prototype.equalsExact.call(this,t,e)}return Lt.prototype.equalsExact.apply(this,arguments)},getCoordinate:function(){if(1===arguments.length&&Number.isInteger(arguments[0])){var t=arguments[0];return this._geometries[t].getCoordinate()}return Lt.prototype.getCoordinate.apply(this,arguments)},getBoundaryDimension:function(){return Nt.FALSE},getTypeCode:function(){return K.TYPECODE_MULTIPOINT},getDimension:function(){return 0},getBoundary:function(){return this.getFactory().createGeometryCollection()},getGeometryType:function(){return K.TYPENAME_MULTIPOINT},copy:function(){for(var t=new Array(this._geometries.length).fill(null),e=0;e<t.length;e++)t[e]=this._geometries[e].copy();return new zt(t,this._factory)},interfaces_:function(){return[Ft]},getClass:function(){return zt}}),zt.serialVersionUID=-0x6fb1ed4162e0fc00,v(Yt,At),e(Yt.prototype,{getBoundaryDimension:function(){return Nt.FALSE},isClosed:function(){return!!this.isEmpty()||At.prototype.isClosed.call(this)},getTypeCode:function(){return K.TYPECODE_LINEARRING},reverse:function(){var t=this._points.copy();return Dt.reverse(t),this.getFactory().createLinearRing(t)},validateConstruction:function(){if(!this.isEmpty()&&!At.prototype.isClosed.call(this))throw new i("Points of LinearRing do not form a closed linestring");if(this.getCoordinateSequence().size()>=1&&this.getCoordinateSequence().size()<Yt.MINIMUM_VALID_SIZE)throw new i("Invalid number of points in LinearRing (found "+this.getCoordinateSequence().size()+" - must be 0 or >= 4)")},getGeometryType:function(){return K.TYPENAME_LINEARRING},copy:function(){return new Yt(this._points.copy(),this._factory)},interfaces_:function(){return[]},getClass:function(){return Yt}}),Yt.MINIMUM_VALID_SIZE=4,Yt.serialVersionUID=-0x3b229e262367a600,v(kt,Lt),e(kt.prototype,{equalsExact:function(){if(2===arguments.length&&"number"==typeof arguments[1]&&arguments[0]instanceof K){var t=arguments[0],e=arguments[1];return!!this.isEquivalentClass(t)&&Lt.prototype.equalsExact.call(this,t,e)}return Lt.prototype.equalsExact.apply(this,arguments)},getBoundaryDimension:function(){return 1},getTypeCode:function(){return K.TYPECODE_MULTIPOLYGON},getDimension:function(){return 2},reverse:function(){for(var t=this._geometries.length,e=new Array(t).fill(null),n=0;n<this._geometries.length;n++)e[n]=this._geometries[n].reverse();return this.getFactory().createMultiPolygon(e)},getBoundary:function(){if(this.isEmpty())return this.getFactory().createMultiLineString();for(var t=new P,e=0;e<this._geometries.length;e++)for(var n=this._geometries[e].getBoundary(),i=0;i<n.getNumGeometries();i++)t.add(n.getGeometryN(i));var r=new Array(t.size()).fill(null);return this.getFactory().createMultiLineString(t.toArray(r))},getGeometryType:function(){return K.TYPENAME_MULTIPOLYGON},copy:function(){for(var t=new Array(this._geometries.length).fill(null),e=0;e<t.length;e++)t[e]=this._geometries[e].copy();return new kt(t,this._factory)},interfaces_:function(){return[Bt]},getClass:function(){return kt}}),kt.serialVersionUID=-0x7a5aa1369171980,e(Ut.prototype,{setCopyUserData:function(t){this._isUserDataCopied=t},edit:function(t,e){if(null===t)return null;var n=this.editInternal(t,e);return this._isUserDataCopied&&n.setUserData(t.getUserData()),n},editInternal:function(t,e){return null===this._factory&&(this._factory=t.getFactory()),t instanceof Lt?this.editGeometryCollection(t,e):t instanceof Vt?this.editPolygon(t,e):t instanceof Gt?e.edit(t,this._factory):t instanceof At?e.edit(t,this._factory):(x.shouldNeverReachHere("Unsupported Geometry class: "+t.getClass().getName()),null)},editGeometryCollection:function(t,e){for(var n=e.edit(t,this._factory),i=new P,r=0;r<n.getNumGeometries();r++){var s=this.edit(n.getGeometryN(r),e);null===s||s.isEmpty()||i.add(s)}return n.getClass()===zt?this._factory.createMultiPoint(i.toArray([])):n.getClass()===wt?this._factory.createMultiLineString(i.toArray([])):n.getClass()===kt?this._factory.createMultiPolygon(i.toArray([])):this._factory.createGeometryCollection(i.toArray([]))},editPolygon:function(t,e){var n=e.edit(t,this._factory);if(null===n&&(n=this._factory.createPolygon()),n.isEmpty())return n;var i=this.edit(n.getExteriorRing(),e);if(null===i||i.isEmpty())return this._factory.createPolygon();for(var r=new P,s=0;s<n.getNumInteriorRing();s++){var o=this.edit(n.getInteriorRingN(s),e);null===o||o.isEmpty()||r.add(o)}return this._factory.createPolygon(i,r.toArray([]))},interfaces_:function(){return[]},getClass:function(){return Ut}}),Ut.GeometryEditorOperation=Xt,e(Ht.prototype,{edit:function(t,e){return t},interfaces_:function(){return[Xt]},getClass:function(){return Ht}}),e(Wt.prototype,{edit:function(t,e){var n=this.edit(t.getCoordinates(),t);return t instanceof Yt?null===n?e.createLinearRing():e.createLinearRing(n):t instanceof At?null===n?e.createLineString():e.createLineString(n):t instanceof Gt?null===n||0===n.length?e.createPoint():e.createPoint(n[0]):t},interfaces_:function(){return[Xt]},getClass:function(){return Wt}}),e(jt.prototype,{edit:function(t,e){return t instanceof Yt?e.createLinearRing(this.edit(t.getCoordinateSequence(),t)):t instanceof At?e.createLineString(this.edit(t.getCoordinateSequence(),t)):t instanceof Gt?e.createPoint(this.edit(t.getCoordinateSequence(),t)):t},interfaces_:function(){return[Xt]},getClass:function(){return jt}}),Ut.NoOpGeometryOperation=Ht,Ut.CoordinateOperation=Wt,Ut.CoordinateSequenceOperation=jt,e(Kt.prototype,{setOrdinate:function(t,e,n){switch(e){case H.X:this._coordinates[t].x=n;break;case H.Y:this._coordinates[t].y=n;break;case H.Z:this._coordinates[t].z=n;break;default:throw new i("invalid ordinateIndex")}},size:function(){return this._coordinates.length},getOrdinate:function(t,e){switch(e){case H.X:return this._coordinates[t].x;case H.Y:return this._coordinates[t].y;case H.Z:return this._coordinates[t].z}return s.NaN},getCoordinate:function(){if(1===arguments.length){var t=arguments[0];return this._coordinates[t]}if(2===arguments.length){var e=arguments[0],n=arguments[1];n.x=this._coordinates[e].x,n.y=this._coordinates[e].y,n.z=this._coordinates[e].z}},getCoordinateCopy:function(t){return new E(this._coordinates[t])},getDimension:function(){return this._dimension},getX:function(t){return this._coordinates[t].x},expandEnvelope:function(t){for(var e=0;e<this._coordinates.length;e++)t.expandToInclude(this._coordinates[e]);return t},copy:function(){for(var t=new Array(this.size()).fill(null),e=0;e<this._coordinates.length;e++)t[e]=this._coordinates[e].copy();return new Kt(t,this._dimension)},toString:function(){if(this._coordinates.length>0){var t=new Mt(17*this._coordinates.length);t.append("("),t.append(this._coordinates[0]);for(var e=1;e<this._coordinates.length;e++)t.append(", "),t.append(this._coordinates[e]);return t.append(")"),t.toString()}return"()"},getY:function(t){return this._coordinates[t].y},toCoordinateArray:function(){return this._coordinates},interfaces_:function(){return[H,p]},getClass:function(){return Kt}}),Kt.serialVersionUID=-0xcb44a778db18e00,e(Zt.prototype,{readResolve:function(){return Zt.instance()},create:function(){if(1===arguments.length){if(arguments[0]instanceof Array)return new Kt(arguments[0]);if(N(arguments[0],H))return new Kt(arguments[0])}else if(2===arguments.length){var t=arguments[0],e=arguments[1];return e>3&&(e=3),e<2?new Kt(t):new Kt(t,e)}},interfaces_:function(){return[W,p]},getClass:function(){return Zt}}),Zt.instance=function(){return Zt.instanceObject},Zt.serialVersionUID=-0x38e49fa6cf6f2e00,Zt.instanceObject=new Zt;var Qt=Object.defineProperty;var Jt=function(t,e){function n(t){if(!this||this.constructor!==n)return new n(t);this._keys=[],this._values=[],this._itp=[],this.objectOnly=e,t&&function(t){this.add?t.forEach(this.add,this):t.forEach(function(t){this.set(t[0],t[1])},this)}.call(this,t)}e||Qt(t,"size",{get:te});return t.constructor=n,n.prototype=t,n}({delete:function(t){this.has(t)&&(this._keys.splice(xt,1),this._values.splice(xt,1),this._itp.forEach(function(t){xt<t[0]&&t[0]--}));return xt>-1},has:function(t){return function(t,e){if(this.objectOnly&&e!==Object(e))throw new TypeError("Invalid value used as weak collection key");if(e!=e||0===e)for(xt=t.length;xt--&&(n=t[xt],i=e,n!==i&&(n==n||i==i)););else xt=t.indexOf(e);var n,i;return xt>-1}.call(this,this._keys,t)},get:function(t){return this.has(t)?this._values[xt]:void 0},set:function(t,e){return this.has(t)?this._values[xt]=e:this._values[this._keys.push(t)-1]=e,this},keys:function(){return $t(this._itp,this._keys)},values:function(){return $t(this._itp,this._values)},entries:function(){return $t(this._itp,this._keys,this._values)},forEach:function(t,e){for(var n=this.entries();;){var i=n.next();if(i.done)break;t.call(e,i.value[1],i.value[0],this)}},clear:function(){(this._keys||0).length=this._values.length=0}});function $t(t,e,n){var i=[0],r=!1;return t.push(i),{next:function(){var s,o=i[0];return!r&&o<e.length?(s=n?[e[o],n[o]]:e[o],i[0]++):(r=!0,t.splice(t.indexOf(i),1)),{done:r,value:s}}}}function te(){return this._values.length}var ee="undefined"!=typeof Map&&Map.prototype.values?Map:Jt;function ne(){this.map_=new ee}function ie(){if(this._modelType=null,this._scale=null,0===arguments.length)this._modelType=ie.FLOATING;else if(1===arguments.length)if(arguments[0]instanceof re){var t=arguments[0];this._modelType=t,t===ie.FIXED&&this.setScale(1)}else if("number"==typeof arguments[0]){var e=arguments[0];this._modelType=ie.FIXED,this.setScale(e)}else if(arguments[0]instanceof ie){var n=arguments[0];this._modelType=n._modelType,this._scale=n._scale}}function re(){this._name=null;var t=arguments[0];this._name=t,re.nameToTypeMap.put(t,this)}function se(){if(this._precisionModel=null,this._coordinateSequenceFactory=null,this._SRID=null,0===arguments.length)se.call(this,new ie,0);else if(1===arguments.length){if(N(arguments[0],W)){var t=arguments[0];se.call(this,new ie,0,t)}else if(arguments[0]instanceof ie){var e=arguments[0];se.call(this,e,0,se.getDefaultCoordinateSequenceFactory())}}else if(2===arguments.length){var n=arguments[0],i=arguments[1];se.call(this,n,i,se.getDefaultCoordinateSequenceFactory())}else if(3===arguments.length){var r=arguments[0],s=arguments[1],o=arguments[2];this._precisionModel=r,this._coordinateSequenceFactory=o,this._SRID=s}}ne.prototype=new st,ne.prototype.get=function(t){return this.map_.get(t)||null},ne.prototype.put=function(t,e){return this.map_.set(t,e),e},ne.prototype.values=function(){for(var t=new P,e=this.map_.values(),n=e.next();!n.done;)t.add(n.value),n=e.next();return t},ne.prototype.entrySet=function(){var t=new ut;return this.map_.entries().forEach(function(e){return t.add(e)}),t},ne.prototype.size=function(){return this.map_.size()},e(ie.prototype,{equals:function(t){if(!(t instanceof ie))return!1;var e=t;return this._modelType===e._modelType&&this._scale===e._scale},compareTo:function(t){var e=t,n=this.getMaximumSignificantDigits(),i=e.getMaximumSignificantDigits();return new G(n).compareTo(new G(i))},getScale:function(){return this._scale},isFloating:function(){return this._modelType===ie.FLOATING||this._modelType===ie.FLOATING_SINGLE},getType:function(){return this._modelType},toString:function(){var t="UNKNOWN";return this._modelType===ie.FLOATING?t="Floating":this._modelType===ie.FLOATING_SINGLE?t="Floating-Single":this._modelType===ie.FIXED&&(t="Fixed (Scale="+this.getScale()+")"),t},makePrecise:function(){if("number"==typeof arguments[0]){var t=arguments[0];return s.isNaN(t)?t:this._modelType===ie.FLOATING_SINGLE?t:this._modelType===ie.FIXED?Math.round(t*this._scale)/this._scale:t}if(arguments[0]instanceof E){var e=arguments[0];if(this._modelType===ie.FLOATING)return null;e.x=this.makePrecise(e.x),e.y=this.makePrecise(e.y)}},getMaximumSignificantDigits:function(){var t=16;return this._modelType===ie.FLOATING?t=16:this._modelType===ie.FLOATING_SINGLE?t=6:this._modelType===ie.FIXED&&(t=1+Math.trunc(Math.ceil(Math.log(this.getScale())/Math.log(10)))),t},setScale:function(t){this._scale=Math.abs(t)},interfaces_:function(){return[p,g]},getClass:function(){return ie}}),ie.mostPrecise=function(t,e){return t.compareTo(e)>=0?t:e},e(re.prototype,{readResolve:function(){return re.nameToTypeMap.get(this._name)},toString:function(){return this._name},interfaces_:function(){return[p]},getClass:function(){return re}}),re.serialVersionUID=-552860263173159e4,re.nameToTypeMap=new ne,ie.Type=re,ie.serialVersionUID=0x6bee6404e9a25c00,ie.FIXED=new re("FIXED"),ie.FLOATING=new re("FLOATING"),ie.FLOATING_SINGLE=new re("FLOATING SINGLE"),ie.maximumPreciseValue=9007199254740992,e(se.prototype,{toGeometry:function(t){return t.isNull()?this.createPoint():t.getMinX()===t.getMaxX()&&t.getMinY()===t.getMaxY()?this.createPoint(new E(t.getMinX(),t.getMinY())):t.getMinX()===t.getMaxX()||t.getMinY()===t.getMaxY()?this.createLineString([new E(t.getMinX(),t.getMinY()),new E(t.getMaxX(),t.getMaxY())]):this.createPolygon(this.createLinearRing([new E(t.getMinX(),t.getMinY()),new E(t.getMinX(),t.getMaxY()),new E(t.getMaxX(),t.getMaxY()),new E(t.getMaxX(),t.getMinY()),new E(t.getMinX(),t.getMinY())]),null)},createLineString:function(){if(0===arguments.length)return this.createLineString(this.getCoordinateSequenceFactory().create([]));if(1===arguments.length){if(arguments[0]instanceof Array){var t=arguments[0];return this.createLineString(null!==t?this.getCoordinateSequenceFactory().create(t):null)}if(N(arguments[0],H))return new At(arguments[0],this)}},createMultiLineString:function(){return 0===arguments.length?new wt(null,this):1===arguments.length?new wt(arguments[0],this):void 0},buildGeometry:function(t){for(var e=null,n=!1,i=!1,r=t.iterator();r.hasNext();){var s=r.next(),o=s.getClass();null===e&&(e=o),o!==e&&(n=!0),s instanceof Lt&&(i=!0)}if(null===e)return this.createGeometryCollection();if(n||i)return this.createGeometryCollection(se.toGeometryArray(t));var a=t.iterator().next();if(t.size()>1){if(a instanceof Vt)return this.createMultiPolygon(se.toPolygonArray(t));if(a instanceof At)return this.createMultiLineString(se.toLineStringArray(t));if(a instanceof Gt)return this.createMultiPoint(se.toPointArray(t));x.shouldNeverReachHere("Unhandled class: "+a.getClass().getName())}return a},createMultiPointFromCoords:function(t){return this.createMultiPoint(null!==t?this.getCoordinateSequenceFactory().create(t):null)},createPoint:function(){if(0===arguments.length)return this.createPoint(this.getCoordinateSequenceFactory().create([]));if(1===arguments.length){if(arguments[0]instanceof E){var t=arguments[0];return this.createPoint(null!==t?this.getCoordinateSequenceFactory().create([t]):null)}if(N(arguments[0],H))return new Gt(arguments[0],this)}},getCoordinateSequenceFactory:function(){return this._coordinateSequenceFactory},createPolygon:function(){if(0===arguments.length)return this.createPolygon(null,null);if(1===arguments.length){if(N(arguments[0],H)){var t=arguments[0];return this.createPolygon(this.createLinearRing(t))}if(arguments[0]instanceof Array){var e=arguments[0];return this.createPolygon(this.createLinearRing(e))}if(arguments[0]instanceof Yt){var n=arguments[0];return this.createPolygon(n,null)}}else if(2===arguments.length){return new Vt(arguments[0],arguments[1],this)}},getSRID:function(){return this._SRID},createGeometryCollection:function(){return 0===arguments.length?new Lt(null,this):1===arguments.length?new Lt(arguments[0],this):void 0},createGeometry:function(t){return new Ut(this).edit(t,{edit:function(){if(2===arguments.length&&arguments[1]instanceof K&&N(arguments[0],H)){var t=arguments[0];return this._coordinateSequenceFactory.create(t)}}})},getPrecisionModel:function(){return this._precisionModel},createLinearRing:function(){if(0===arguments.length)return this.createLinearRing(this.getCoordinateSequenceFactory().create([]));if(1===arguments.length){if(arguments[0]instanceof Array){var t=arguments[0];return this.createLinearRing(null!==t?this.getCoordinateSequenceFactory().create(t):null)}if(N(arguments[0],H))return new Yt(arguments[0],this)}},createMultiPolygon:function(){return 0===arguments.length?new kt(null,this):1===arguments.length?new kt(arguments[0],this):void 0},createMultiPoint:function(){if(0===arguments.length)return new zt(null,this);if(1===arguments.length){if(arguments[0]instanceof Array)return new zt(arguments[0],this);if(N(arguments[0],H)){var t=arguments[0];if(null===t)return this.createMultiPoint(new Array(0).fill(null));for(var e=new Array(t.size()).fill(null),n=0;n<t.size();n++){var i=this.getCoordinateSequenceFactory().create(1,t.getDimension());Dt.copy(t,n,i,0,1),e[n]=this.createPoint(i)}return this.createMultiPoint(e)}}},interfaces_:function(){return[p]},getClass:function(){return se}}),se.toMultiPolygonArray=function(t){var e=new Array(t.size()).fill(null);return t.toArray(e)},se.toGeometryArray=function(t){if(null===t)return null;var e=new Array(t.size()).fill(null);return t.toArray(e)},se.getDefaultCoordinateSequenceFactory=function(){return Zt.instance()},se.toMultiLineStringArray=function(t){var e=new Array(t.size()).fill(null);return t.toArray(e)},se.toLineStringArray=function(t){var e=new Array(t.size()).fill(null);return t.toArray(e)},se.toMultiPointArray=function(t){var e=new Array(t.size()).fill(null);return t.toArray(e)},se.toLinearRingArray=function(t){var e=new Array(t.size()).fill(null);return t.toArray(e)},se.toPointArray=function(t){var e=new Array(t.size()).fill(null);return t.toArray(e)},se.toPolygonArray=function(t){var e=new Array(t.size()).fill(null);return t.toArray(e)},se.createPointFromInternalCoord=function(t,e){return e.getPrecisionModel().makePrecise(t),e.getFactory().createPoint(t)},se.serialVersionUID=-0x5ea75f2051eeb400;var oe={typeStr:/^\s*(\w+)\s*\(\s*(.*)\s*\)\s*$/,emptyTypeStr:/^\s*(\w+)\s*EMPTY\s*$/,spaces:/\s+/,parenComma:/\)\s*,\s*\(/,doubleParenComma:/\)\s*\)\s*,\s*\(\s*\(/,trimParens:/^\s*\(?(.*?)\)?\s*$/};function ae(t){this.geometryFactory=t||new se,this.precisionModel=this.geometryFactory.getPrecisionModel()}e(ae.prototype,{read:function(t){var e,n,i;t=t.replace(/[\n\r]/g," ");var r=oe.typeStr.exec(t);if(-1!==t.search("EMPTY")&&((r=oe.emptyTypeStr.exec(t))[2]=void 0),r&&(n=r[1].toLowerCase(),i=r[2],le[n]&&(e=le[n].call(this,i))),void 0===e)throw new Error("Could not parse WKT "+t);return e},write:function(t){return this.extractGeometry(t)},extractGeometry:function(t){var e=t.getGeometryType().toLowerCase();if(!ue[e])return null;var n=e.toUpperCase();return t.isEmpty()?n+" EMPTY":n+"("+ue[e].call(this,t)+")"}});var ue={coordinate:function(t){return t.x+" "+t.y},point:function(t){return ue.coordinate.call(this,t._coordinates._coordinates[0])},multipoint:function(t){for(var e=[],n=0,i=t._geometries.length;n<i;++n)e.push("("+ue.point.call(this,t._geometries[n])+")");return e.join(",")},linestring:function(t){for(var e=[],n=0,i=t._points._coordinates.length;n<i;++n)e.push(ue.coordinate.call(this,t._points._coordinates[n]));return e.join(",")},linearring:function(t){for(var e=[],n=0,i=t._points._coordinates.length;n<i;++n)e.push(ue.coordinate.call(this,t._points._coordinates[n]));return e.join(",")},multilinestring:function(t){for(var e=[],n=0,i=t._geometries.length;n<i;++n)e.push("("+ue.linestring.call(this,t._geometries[n])+")");return e.join(",")},polygon:function(t){var e=[];e.push("("+ue.linestring.call(this,t._shell)+")");for(var n=0,i=t._holes.length;n<i;++n)e.push("("+ue.linestring.call(this,t._holes[n])+")");return e.join(",")},multipolygon:function(t){for(var e=[],n=0,i=t._geometries.length;n<i;++n)e.push("("+ue.polygon.call(this,t._geometries[n])+")");return e.join(",")},geometrycollection:function(t){for(var e=[],n=0,i=t._geometries.length;n<i;++n)e.push(this.extractGeometry(t._geometries[n]));return e.join(",")}},le={coord:function(t){var e=t.trim().split(oe.spaces),n=new E(Number.parseFloat(e[0]),Number.parseFloat(e[1]));return this.precisionModel.makePrecise(n),n},point:function(t){return void 0===t?this.geometryFactory.createPoint():this.geometryFactory.createPoint(le.coord.call(this,t))},multipoint:function(t){if(void 0===t)return this.geometryFactory.createMultiPoint();for(var e,n=t.trim().split(","),i=[],r=0,s=n.length;r<s;++r)e=n[r].replace(oe.trimParens,"$1"),i.push(le.point.call(this,e));return this.geometryFactory.createMultiPoint(i)},linestring:function(t){if(void 0===t)return this.geometryFactory.createLineString();for(var e=t.trim().split(","),n=[],i=0,r=e.length;i<r;++i)n.push(le.coord.call(this,e[i]));return this.geometryFactory.createLineString(n)},linearring:function(t){if(void 0===t)return this.geometryFactory.createLinearRing();for(var e=t.trim().split(","),n=[],i=0,r=e.length;i<r;++i)n.push(le.coord.call(this,e[i]));return this.geometryFactory.createLinearRing(n)},multilinestring:function(t){if(void 0===t)return this.geometryFactory.createMultiLineString();for(var e,n=t.trim().split(oe.parenComma),i=[],r=0,s=n.length;r<s;++r)e=n[r].replace(oe.trimParens,"$1"),i.push(le.linestring.call(this,e));return this.geometryFactory.createMultiLineString(i)},polygon:function(t){if(void 0===t)return this.geometryFactory.createPolygon();for(var e,n,i,r,s=t.trim().split(oe.parenComma),o=[],a=0,u=s.length;a<u;++a)e=s[a].replace(oe.trimParens,"$1"),n=le.linestring.call(this,e),i=this.geometryFactory.createLinearRing(n._points),0===a?r=i:o.push(i);return this.geometryFactory.createPolygon(r,o)},multipolygon:function(t){if(void 0===t)return this.geometryFactory.createMultiPolygon();for(var e,n=t.trim().split(oe.doubleParenComma),i=[],r=0,s=n.length;r<s;++r)e=n[r].replace(oe.trimParens,"$1"),i.push(le.polygon.call(this,e));return this.geometryFactory.createMultiPolygon(i)},geometrycollection:function(t){if(void 0===t)return this.geometryFactory.createGeometryCollection();for(var e=(t=t.replace(/,\s*([A-Za-z])/g,"|$1")).trim().split("|"),n=[],i=0,r=e.length;i<r;++i)n.push(this.read(e[i]));return this.geometryFactory.createGeometryCollection(n)}};function he(t){this.parser=new ae(t)}function ce(){this._result=null,this._inputLines=Array(2).fill().map(function(){return Array(2)}),this._intPt=new Array(2).fill(null),this._intLineIndex=null,this._isProper=null,this._pa=null,this._pb=null,this._precisionModel=null,this._intPt[0]=new E,this._intPt[1]=new E,this._pa=this._intPt[0],this._pb=this._intPt[1],this._result=0}function fe(){ce.apply(this)}function ge(){if(this.p0=null,this.p1=null,0===arguments.length)ge.call(this,new E,new E);else if(1===arguments.length){var t=arguments[0];ge.call(this,t.p0,t.p1)}else if(2===arguments.length){var e=arguments[0],n=arguments[1];this.p0=e,this.p1=n}else if(4===arguments.length){var i=arguments[0],r=arguments[1],s=arguments[2],o=arguments[3];ge.call(this,new E(i,r),new E(s,o))}}function de(){}function _e(){if(this._matrix=null,0===arguments.length)this._matrix=Array(3).fill().map(function(){return Array(3)}),this.setAll(Nt.FALSE);else if(1===arguments.length)if("string"==typeof arguments[0]){var t=arguments[0];_e.call(this),this.set(t)}else if(arguments[0]instanceof _e){var e=arguments[0];_e.call(this),this._matrix[de.INTERIOR][de.INTERIOR]=e._matrix[de.INTERIOR][de.INTERIOR],this._matrix[de.INTERIOR][de.BOUNDARY]=e._matrix[de.INTERIOR][de.BOUNDARY],this._matrix[de.INTERIOR][de.EXTERIOR]=e._matrix[de.INTERIOR][de.EXTERIOR],this._matrix[de.BOUNDARY][de.INTERIOR]=e._matrix[de.BOUNDARY][de.INTERIOR],this._matrix[de.BOUNDARY][de.BOUNDARY]=e._matrix[de.BOUNDARY][de.BOUNDARY],this._matrix[de.BOUNDARY][de.EXTERIOR]=e._matrix[de.BOUNDARY][de.EXTERIOR],this._matrix[de.EXTERIOR][de.INTERIOR]=e._matrix[de.EXTERIOR][de.INTERIOR],this._matrix[de.EXTERIOR][de.BOUNDARY]=e._matrix[de.EXTERIOR][de.BOUNDARY],this._matrix[de.EXTERIOR][de.EXTERIOR]=e._matrix[de.EXTERIOR][de.EXTERIOR]}}function pe(){}function me(){this.p0=null,this.p1=null,this.p2=null;var t=arguments[0],e=arguments[1],n=arguments[2];this.p0=t,this.p1=e,this.p2=n}e(he.prototype,{write:function(t){return this.parser.write(t)}}),e(he,{toLineString:function(t,e){if(2!==arguments.length)throw new Error("Not implemented");return"LINESTRING ( "+t.x+" "+t.y+", "+e.x+" "+e.y+" )"}}),e(ce.prototype,{getIndexAlongSegment:function(t,e){return this.computeIntLineIndex(),this._intLineIndex[t][e]},getTopologySummary:function(){var t=new Mt;return this.isEndPoint()&&t.append(" endpoint"),this._isProper&&t.append(" proper"),this.isCollinear()&&t.append(" collinear"),t.toString()},computeIntersection:function(t,e,n,i){this._inputLines[0][0]=t,this._inputLines[0][1]=e,this._inputLines[1][0]=n,this._inputLines[1][1]=i,this._result=this.computeIntersect(t,e,n,i)},getIntersectionNum:function(){return this._result},computeIntLineIndex:function(){if(0===arguments.length)null===this._intLineIndex&&(this._intLineIndex=Array(2).fill().map(function(){return Array(2)}),this.computeIntLineIndex(0),this.computeIntLineIndex(1));else if(1===arguments.length){var t=arguments[0];this.getEdgeDistance(t,0)>this.getEdgeDistance(t,1)?(this._intLineIndex[t][0]=0,this._intLineIndex[t][1]=1):(this._intLineIndex[t][0]=1,this._intLineIndex[t][1]=0)}},isProper:function(){return this.hasIntersection()&&this._isProper},setPrecisionModel:function(t){this._precisionModel=t},isInteriorIntersection:function(){if(0===arguments.length)return!!this.isInteriorIntersection(0)||!!this.isInteriorIntersection(1);if(1===arguments.length){for(var t=arguments[0],e=0;e<this._result;e++)if(!this._intPt[e].equals2D(this._inputLines[t][0])&&!this._intPt[e].equals2D(this._inputLines[t][1]))return!0;return!1}},getIntersection:function(t){return this._intPt[t]},isEndPoint:function(){return this.hasIntersection()&&!this._isProper},hasIntersection:function(){return this._result!==ce.NO_INTERSECTION},getEdgeDistance:function(t,e){return ce.computeEdgeDistance(this._intPt[e],this._inputLines[t][0],this._inputLines[t][1])},isCollinear:function(){return this._result===ce.COLLINEAR_INTERSECTION},toString:function(){return he.toLineString(this._inputLines[0][0],this._inputLines[0][1])+" - "+he.toLineString(this._inputLines[1][0],this._inputLines[1][1])+this.getTopologySummary()},getEndpoint:function(t,e){return this._inputLines[t][e]},isIntersection:function(t){for(var e=0;e<this._result;e++)if(this._intPt[e].equals2D(t))return!0;return!1},getIntersectionAlongSegment:function(t,e){return this.computeIntLineIndex(),this._intPt[this._intLineIndex[t][e]]},interfaces_:function(){return[]},getClass:function(){return ce}}),ce.computeEdgeDistance=function(t,e,n){var i=Math.abs(n.x-e.x),r=Math.abs(n.y-e.y),s=-1;if(t.equals(e))s=0;else if(t.equals(n))s=i>r?i:r;else{var o=Math.abs(t.x-e.x),a=Math.abs(t.y-e.y);0!==(s=i>r?o:a)||t.equals(e)||(s=Math.max(o,a))}return x.isTrue(!(0===s&&!t.equals(e)),"Bad distance calculation"),s},ce.nonRobustComputeEdgeDistance=function(t,e,n){var i=t.x-e.x,r=t.y-e.y,s=Math.sqrt(i*i+r*r);return x.isTrue(!(0===s&&!t.equals(e)),"Invalid distance calculation"),s},ce.DONT_INTERSECT=0,ce.DO_INTERSECT=1,ce.COLLINEAR=2,ce.NO_INTERSECTION=0,ce.POINT_INTERSECTION=1,ce.COLLINEAR_INTERSECTION=2,v(fe,ce),e(fe.prototype,{isInSegmentEnvelopes:function(t){var e=new M(this._inputLines[0][0],this._inputLines[0][1]),n=new M(this._inputLines[1][0],this._inputLines[1][1]);return e.contains(t)&&n.contains(t)},computeIntersection:function(){if(3!==arguments.length)return ce.prototype.computeIntersection.apply(this,arguments);var t=arguments[0],e=arguments[1],n=arguments[2];if(this._isProper=!1,M.intersects(e,n,t)&&0===z.index(e,n,t)&&0===z.index(n,e,t))return this._isProper=!0,(t.equals(e)||t.equals(n))&&(this._isProper=!1),this._result=ce.POINT_INTERSECTION,null;this._result=ce.NO_INTERSECTION},normalizeToMinimum:function(t,e,n,i,r){r.x=this.smallestInAbsValue(t.x,e.x,n.x,i.x),r.y=this.smallestInAbsValue(t.y,e.y,n.y,i.y),t.x-=r.x,t.y-=r.y,e.x-=r.x,e.y-=r.y,n.x-=r.x,n.y-=r.y,i.x-=r.x,i.y-=r.y},safeHCoordinateIntersection:function(t,e,n,i){var r=null;try{r=k.intersection(t,e,n,i)}catch(s){if(!(s instanceof A))throw s;r=fe.nearestEndpoint(t,e,n,i)}return r},intersection:function(t,e,n,i){var r=this.intersectionWithNormalization(t,e,n,i);return this.isInSegmentEnvelopes(r)||(r=new E(fe.nearestEndpoint(t,e,n,i))),null!==this._precisionModel&&this._precisionModel.makePrecise(r),r},smallestInAbsValue:function(t,e,n,i){var r=t,s=Math.abs(r);return Math.abs(e)<s&&(r=e,s=Math.abs(e)),Math.abs(n)<s&&(r=n,s=Math.abs(n)),Math.abs(i)<s&&(r=i),r},checkDD:function(t,e,n,i,r){var s=V.intersection(t,e,n,i),o=this.isInSegmentEnvelopes(s);Y.out.println("DD in env = "+o+"  --------------------- "+s),r.distance(s)>1e-4&&Y.out.println("Distance = "+r.distance(s))},intersectionWithNormalization:function(t,e,n,i){var r=new E(t),s=new E(e),o=new E(n),a=new E(i),u=new E;this.normalizeToEnvCentre(r,s,o,a,u);var l=this.safeHCoordinateIntersection(r,s,o,a);return l.x+=u.x,l.y+=u.y,l},computeCollinearIntersection:function(t,e,n,i){var r=M.intersects(t,e,n),s=M.intersects(t,e,i),o=M.intersects(n,i,t),a=M.intersects(n,i,e);return r&&s?(this._intPt[0]=n,this._intPt[1]=i,ce.COLLINEAR_INTERSECTION):o&&a?(this._intPt[0]=t,this._intPt[1]=e,ce.COLLINEAR_INTERSECTION):r&&o?(this._intPt[0]=n,this._intPt[1]=t,!n.equals(t)||s||a?ce.COLLINEAR_INTERSECTION:ce.POINT_INTERSECTION):r&&a?(this._intPt[0]=n,this._intPt[1]=e,!n.equals(e)||s||o?ce.COLLINEAR_INTERSECTION:ce.POINT_INTERSECTION):s&&o?(this._intPt[0]=i,this._intPt[1]=t,!i.equals(t)||r||a?ce.COLLINEAR_INTERSECTION:ce.POINT_INTERSECTION):s&&a?(this._intPt[0]=i,this._intPt[1]=e,!i.equals(e)||r||o?ce.COLLINEAR_INTERSECTION:ce.POINT_INTERSECTION):ce.NO_INTERSECTION},normalizeToEnvCentre:function(t,e,n,i,r){var s=t.x<e.x?t.x:e.x,o=t.y<e.y?t.y:e.y,a=t.x>e.x?t.x:e.x,u=t.y>e.y?t.y:e.y,l=n.x<i.x?n.x:i.x,h=n.y<i.y?n.y:i.y,c=n.x>i.x?n.x:i.x,f=n.y>i.y?n.y:i.y,g=((s>l?s:l)+(a<c?a:c))/2,d=((o>h?o:h)+(u<f?u:f))/2;r.x=g,r.y=d,t.x-=r.x,t.y-=r.y,e.x-=r.x,e.y-=r.y,n.x-=r.x,n.y-=r.y,i.x-=r.x,i.y-=r.y},computeIntersect:function(t,e,n,i){if(this._isProper=!1,!M.intersects(t,e,n,i))return ce.NO_INTERSECTION;var r=z.index(t,e,n),s=z.index(t,e,i);if(r>0&&s>0||r<0&&s<0)return ce.NO_INTERSECTION;var o=z.index(n,i,t),a=z.index(n,i,e);return o>0&&a>0||o<0&&a<0?ce.NO_INTERSECTION:0===r&&0===s&&0===o&&0===a?this.computeCollinearIntersection(t,e,n,i):(0===r||0===s||0===o||0===a?(this._isProper=!1,t.equals2D(n)||t.equals2D(i)?this._intPt[0]=t:e.equals2D(n)||e.equals2D(i)?this._intPt[0]=e:0===r?this._intPt[0]=new E(n):0===s?this._intPt[0]=new E(i):0===o?this._intPt[0]=new E(t):0===a&&(this._intPt[0]=new E(e))):(this._isProper=!0,this._intPt[0]=this.intersection(t,e,n,i)),ce.POINT_INTERSECTION)},interfaces_:function(){return[]},getClass:function(){return fe}}),fe.nearestEndpoint=function(t,e,n,i){var r=t,s=X.pointToSegment(t,n,i),o=X.pointToSegment(e,n,i);return o<s&&(s=o,r=e),(o=X.pointToSegment(n,t,e))<s&&(s=o,r=n),(o=X.pointToSegment(i,t,e))<s&&(s=o,r=i),r},e(ge.prototype,{minX:function(){return Math.min(this.p0.x,this.p1.x)},orientationIndex:function(){if(arguments[0]instanceof ge){var t=arguments[0],e=z.index(this.p0,this.p1,t.p0),n=z.index(this.p0,this.p1,t.p1);return e>=0&&n>=0?Math.max(e,n):e<=0&&n<=0?Math.max(e,n):0}if(arguments[0]instanceof E){var i=arguments[0];return z.index(this.p0,this.p1,i)}},toGeometry:function(t){return t.createLineString([this.p0,this.p1])},isVertical:function(){return this.p0.x===this.p1.x},equals:function(t){if(!(t instanceof ge))return!1;var e=t;return this.p0.equals(e.p0)&&this.p1.equals(e.p1)},intersection:function(t){var e=new fe;return e.computeIntersection(this.p0,this.p1,t.p0,t.p1),e.hasIntersection()?e.getIntersection(0):null},project:function(){if(arguments[0]instanceof E){var t=arguments[0];if(t.equals(this.p0)||t.equals(this.p1))return new E(t);var e=this.projectionFactor(t),n=new E;return n.x=this.p0.x+e*(this.p1.x-this.p0.x),n.y=this.p0.y+e*(this.p1.y-this.p0.y),n}if(arguments[0]instanceof ge){var i=arguments[0],r=this.projectionFactor(i.p0),s=this.projectionFactor(i.p1);if(r>=1&&s>=1)return null;if(r<=0&&s<=0)return null;var o=this.project(i.p0);r<0&&(o=this.p0),r>1&&(o=this.p1);var a=this.project(i.p1);return s<0&&(a=this.p0),s>1&&(a=this.p1),new ge(o,a)}},normalize:function(){this.p1.compareTo(this.p0)<0&&this.reverse()},angle:function(){return Math.atan2(this.p1.y-this.p0.y,this.p1.x-this.p0.x)},getCoordinate:function(t){return 0===t?this.p0:this.p1},distancePerpendicular:function(t){return X.pointToLinePerpendicular(t,this.p0,this.p1)},minY:function(){return Math.min(this.p0.y,this.p1.y)},midPoint:function(){return ge.midPoint(this.p0,this.p1)},projectionFactor:function(t){if(t.equals(this.p0))return 0;if(t.equals(this.p1))return 1;var e=this.p1.x-this.p0.x,n=this.p1.y-this.p0.y,i=e*e+n*n;return i<=0?s.NaN:((t.x-this.p0.x)*e+(t.y-this.p0.y)*n)/i},closestPoints:function(t){var e=this.intersection(t);if(null!==e)return[e,e];var n=new Array(2).fill(null),i=s.MAX_VALUE,r=null,o=this.closestPoint(t.p0);i=o.distance(t.p0),n[0]=o,n[1]=t.p0;var a=this.closestPoint(t.p1);(r=a.distance(t.p1))<i&&(i=r,n[0]=a,n[1]=t.p1);var u=t.closestPoint(this.p0);(r=u.distance(this.p0))<i&&(i=r,n[0]=this.p0,n[1]=u);var l=t.closestPoint(this.p1);return(r=l.distance(this.p1))<i&&(i=r,n[0]=this.p1,n[1]=l),n},closestPoint:function(t){var e=this.projectionFactor(t);return e>0&&e<1?this.project(t):this.p0.distance(t)<this.p1.distance(t)?this.p0:this.p1},maxX:function(){return Math.max(this.p0.x,this.p1.x)},getLength:function(){return this.p0.distance(this.p1)},compareTo:function(t){var e=t,n=this.p0.compareTo(e.p0);return 0!==n?n:this.p1.compareTo(e.p1)},reverse:function(){var t=this.p0;this.p0=this.p1,this.p1=t},equalsTopo:function(t){return this.p0.equals(t.p0)&&this.p1.equals(t.p1)||this.p0.equals(t.p1)&&this.p1.equals(t.p0)},lineIntersection:function(t){try{return k.intersection(this.p0,this.p1,t.p0,t.p1)}catch(t){if(!(t instanceof A))throw t}return null},maxY:function(){return Math.max(this.p0.y,this.p1.y)},pointAlongOffset:function(t,e){var n=this.p0.x+t*(this.p1.x-this.p0.x),i=this.p0.y+t*(this.p1.y-this.p0.y),r=this.p1.x-this.p0.x,s=this.p1.y-this.p0.y,o=Math.sqrt(r*r+s*s),a=0,u=0;if(0!==e){if(o<=0)throw new IllegalStateException("Cannot compute offset from zero-length line segment");a=e*r/o,u=e*s/o}return new E(n-u,i+a)},setCoordinates:function(){if(1===arguments.length){var t=arguments[0];this.setCoordinates(t.p0,t.p1)}else if(2===arguments.length){var e=arguments[0],n=arguments[1];this.p0.x=e.x,this.p0.y=e.y,this.p1.x=n.x,this.p1.y=n.y}},segmentFraction:function(t){var e=this.projectionFactor(t);return e<0?e=0:(e>1||s.isNaN(e))&&(e=1),e},toString:function(){return"LINESTRING( "+this.p0.x+" "+this.p0.y+", "+this.p1.x+" "+this.p1.y+")"},isHorizontal:function(){return this.p0.y===this.p1.y},distance:function(){if(arguments[0]instanceof ge){var t=arguments[0];return X.segmentToSegment(this.p0,this.p1,t.p0,t.p1)}if(arguments[0]instanceof E){var e=arguments[0];return X.pointToSegment(e,this.p0,this.p1)}},pointAlong:function(t){var e=new E;return e.x=this.p0.x+t*(this.p1.x-this.p0.x),e.y=this.p0.y+t*(this.p1.y-this.p0.y),e},hashCode:function(){var t=java.lang.Double.doubleToLongBits(this.p0.x);t^=31*java.lang.Double.doubleToLongBits(this.p0.y);var e=Math.trunc(t)^Math.trunc(t>>32),n=java.lang.Double.doubleToLongBits(this.p1.x);return n^=31*java.lang.Double.doubleToLongBits(this.p1.y),e^(Math.trunc(n)^Math.trunc(n>>32))},interfaces_:function(){return[g,p]},getClass:function(){return ge}}),ge.midPoint=function(t,e){return new E((t.x+e.x)/2,(t.y+e.y)/2)},ge.serialVersionUID=0x2d2172135f411c00,e(de.prototype,{interfaces_:function(){return[]},getClass:function(){return de}}),de.toLocationSymbol=function(t){switch(t){case de.EXTERIOR:return"e";case de.BOUNDARY:return"b";case de.INTERIOR:return"i";case de.NONE:return"-"}throw new i("Unknown location value: "+t)},de.INTERIOR=0,de.BOUNDARY=1,de.EXTERIOR=2,de.NONE=-1,e(_e.prototype,{isIntersects:function(){return!this.isDisjoint()},isCovers:function(){return(_e.isTrue(this._matrix[de.INTERIOR][de.INTERIOR])||_e.isTrue(this._matrix[de.INTERIOR][de.BOUNDARY])||_e.isTrue(this._matrix[de.BOUNDARY][de.INTERIOR])||_e.isTrue(this._matrix[de.BOUNDARY][de.BOUNDARY]))&&this._matrix[de.EXTERIOR][de.INTERIOR]===Nt.FALSE&&this._matrix[de.EXTERIOR][de.BOUNDARY]===Nt.FALSE},isCoveredBy:function(){return(_e.isTrue(this._matrix[de.INTERIOR][de.INTERIOR])||_e.isTrue(this._matrix[de.INTERIOR][de.BOUNDARY])||_e.isTrue(this._matrix[de.BOUNDARY][de.INTERIOR])||_e.isTrue(this._matrix[de.BOUNDARY][de.BOUNDARY]))&&this._matrix[de.INTERIOR][de.EXTERIOR]===Nt.FALSE&&this._matrix[de.BOUNDARY][de.EXTERIOR]===Nt.FALSE},set:function(){if(1===arguments.length)for(var t=arguments[0],e=0;e<t.length;e++){var n=Math.trunc(e/3),i=e%3;this._matrix[n][i]=Nt.toDimensionValue(t.charAt(e))}else if(3===arguments.length){var r=arguments[0],s=arguments[1],o=arguments[2];this._matrix[r][s]=o}},isContains:function(){return _e.isTrue(this._matrix[de.INTERIOR][de.INTERIOR])&&this._matrix[de.EXTERIOR][de.INTERIOR]===Nt.FALSE&&this._matrix[de.EXTERIOR][de.BOUNDARY]===Nt.FALSE},setAtLeast:function(){if(1===arguments.length)for(var t=arguments[0],e=0;e<t.length;e++){var n=Math.trunc(e/3),i=e%3;this.setAtLeast(n,i,Nt.toDimensionValue(t.charAt(e)))}else if(3===arguments.length){var r=arguments[0],s=arguments[1],o=arguments[2];this._matrix[r][s]<o&&(this._matrix[r][s]=o)}},setAtLeastIfValid:function(t,e,n){t>=0&&e>=0&&this.setAtLeast(t,e,n)},isWithin:function(){return _e.isTrue(this._matrix[de.INTERIOR][de.INTERIOR])&&this._matrix[de.INTERIOR][de.EXTERIOR]===Nt.FALSE&&this._matrix[de.BOUNDARY][de.EXTERIOR]===Nt.FALSE},isTouches:function(t,e){return t>e?this.isTouches(e,t):(t===Nt.A&&e===Nt.A||t===Nt.L&&e===Nt.L||t===Nt.L&&e===Nt.A||t===Nt.P&&e===Nt.A||t===Nt.P&&e===Nt.L)&&(this._matrix[de.INTERIOR][de.INTERIOR]===Nt.FALSE&&(_e.isTrue(this._matrix[de.INTERIOR][de.BOUNDARY])||_e.isTrue(this._matrix[de.BOUNDARY][de.INTERIOR])||_e.isTrue(this._matrix[de.BOUNDARY][de.BOUNDARY])))},isOverlaps:function(t,e){return t===Nt.P&&e===Nt.P||t===Nt.A&&e===Nt.A?_e.isTrue(this._matrix[de.INTERIOR][de.INTERIOR])&&_e.isTrue(this._matrix[de.INTERIOR][de.EXTERIOR])&&_e.isTrue(this._matrix[de.EXTERIOR][de.INTERIOR]):t===Nt.L&&e===Nt.L&&(1===this._matrix[de.INTERIOR][de.INTERIOR]&&_e.isTrue(this._matrix[de.INTERIOR][de.EXTERIOR])&&_e.isTrue(this._matrix[de.EXTERIOR][de.INTERIOR]))},isEquals:function(t,e){return t===e&&(_e.isTrue(this._matrix[de.INTERIOR][de.INTERIOR])&&this._matrix[de.INTERIOR][de.EXTERIOR]===Nt.FALSE&&this._matrix[de.BOUNDARY][de.EXTERIOR]===Nt.FALSE&&this._matrix[de.EXTERIOR][de.INTERIOR]===Nt.FALSE&&this._matrix[de.EXTERIOR][de.BOUNDARY]===Nt.FALSE)},toString:function(){for(var t=new Mt("123456789"),e=0;e<3;e++)for(var n=0;n<3;n++)t.setCharAt(3*e+n,Nt.toDimensionSymbol(this._matrix[e][n]));return t.toString()},setAll:function(t){for(var e=0;e<3;e++)for(var n=0;n<3;n++)this._matrix[e][n]=t},get:function(t,e){return this._matrix[t][e]},transpose:function(){var t=this._matrix[1][0];return this._matrix[1][0]=this._matrix[0][1],this._matrix[0][1]=t,t=this._matrix[2][0],this._matrix[2][0]=this._matrix[0][2],this._matrix[0][2]=t,t=this._matrix[2][1],this._matrix[2][1]=this._matrix[1][2],this._matrix[1][2]=t,this},matches:function(t){if(9!==t.length)throw new i("Should be length 9: "+t);for(var e=0;e<3;e++)for(var n=0;n<3;n++)if(!_e.matches(this._matrix[e][n],t.charAt(3*e+n)))return!1;return!0},add:function(t){for(var e=0;e<3;e++)for(var n=0;n<3;n++)this.setAtLeast(e,n,t.get(e,n))},isDisjoint:function(){return this._matrix[de.INTERIOR][de.INTERIOR]===Nt.FALSE&&this._matrix[de.INTERIOR][de.BOUNDARY]===Nt.FALSE&&this._matrix[de.BOUNDARY][de.INTERIOR]===Nt.FALSE&&this._matrix[de.BOUNDARY][de.BOUNDARY]===Nt.FALSE},isCrosses:function(t,e){return t===Nt.P&&e===Nt.L||t===Nt.P&&e===Nt.A||t===Nt.L&&e===Nt.A?_e.isTrue(this._matrix[de.INTERIOR][de.INTERIOR])&&_e.isTrue(this._matrix[de.INTERIOR][de.EXTERIOR]):t===Nt.L&&e===Nt.P||t===Nt.A&&e===Nt.P||t===Nt.A&&e===Nt.L?_e.isTrue(this._matrix[de.INTERIOR][de.INTERIOR])&&_e.isTrue(this._matrix[de.EXTERIOR][de.INTERIOR]):t===Nt.L&&e===Nt.L&&0===this._matrix[de.INTERIOR][de.INTERIOR]},interfaces_:function(){return[d]},getClass:function(){return _e}}),_e.matches=function(){if(Number.isInteger(arguments[0])&&"string"==typeof arguments[1]){var t=arguments[0],e=arguments[1];return e===Nt.SYM_DONTCARE||(e===Nt.SYM_TRUE&&(t>=0||t===Nt.TRUE)||(e===Nt.SYM_FALSE&&t===Nt.FALSE||(e===Nt.SYM_P&&t===Nt.P||(e===Nt.SYM_L&&t===Nt.L||e===Nt.SYM_A&&t===Nt.A))))}if("string"==typeof arguments[0]&&"string"==typeof arguments[1]){var n=arguments[0],i=arguments[1];return new _e(n).matches(i)}},_e.isTrue=function(t){return t>=0||t===Nt.TRUE},e(pe.prototype,{interfaces_:function(){return[]},getClass:function(){return pe}}),pe.toDegrees=function(t){return 180*t/Math.PI},pe.normalize=function(t){for(;t>Math.PI;)t-=pe.PI_TIMES_2;for(;t<=-Math.PI;)t+=pe.PI_TIMES_2;return t},pe.angle=function(){if(1===arguments.length){var t=arguments[0];return Math.atan2(t.y,t.x)}if(2===arguments.length){var e=arguments[0],n=arguments[1],i=n.x-e.x,r=n.y-e.y;return Math.atan2(r,i)}},pe.isAcute=function(t,e,n){var i=t.x-e.x,r=t.y-e.y;return i*(n.x-e.x)+r*(n.y-e.y)>0},pe.isObtuse=function(t,e,n){var i=t.x-e.x,r=t.y-e.y;return i*(n.x-e.x)+r*(n.y-e.y)<0},pe.interiorAngle=function(t,e,n){var i=pe.angle(e,t),r=pe.angle(e,n);return Math.abs(r-i)},pe.normalizePositive=function(t){if(t<0){for(;t<0;)t+=pe.PI_TIMES_2;t>=pe.PI_TIMES_2&&(t=0)}else{for(;t>=pe.PI_TIMES_2;)t-=pe.PI_TIMES_2;t<0&&(t=0)}return t},pe.angleBetween=function(t,e,n){var i=pe.angle(e,t),r=pe.angle(e,n);return pe.diff(i,r)},pe.diff=function(t,e){var n=null;return(n=t<e?e-t:t-e)>Math.PI&&(n=2*Math.PI-n),n},pe.toRadians=function(t){return t*Math.PI/180},pe.getTurn=function(t,e){var n=Math.sin(e-t);return n>0?pe.COUNTERCLOCKWISE:n<0?pe.CLOCKWISE:pe.NONE},pe.angleBetweenOriented=function(t,e,n){var i=pe.angle(e,t),r=pe.angle(e,n)-i;return r<=-Math.PI?r+pe.PI_TIMES_2:r>Math.PI?r-pe.PI_TIMES_2:r},pe.PI_TIMES_2=2*Math.PI,pe.PI_OVER_2=Math.PI/2,pe.PI_OVER_4=Math.PI/4,pe.COUNTERCLOCKWISE=z.COUNTERCLOCKWISE,pe.CLOCKWISE=z.CLOCKWISE,pe.NONE=z.COLLINEAR,e(me.prototype,{area:function(){return me.area(this.p0,this.p1,this.p2)},signedArea:function(){return me.signedArea(this.p0,this.p1,this.p2)},interpolateZ:function(t){if(null===t)throw new i("Supplied point is null.");return me.interpolateZ(t,this.p0,this.p1,this.p2)},longestSideLength:function(){return me.longestSideLength(this.p0,this.p1,this.p2)},isAcute:function(){return me.isAcute(this.p0,this.p1,this.p2)},circumcentre:function(){return me.circumcentre(this.p0,this.p1,this.p2)},area3D:function(){return me.area3D(this.p0,this.p1,this.p2)},centroid:function(){return me.centroid(this.p0,this.p1,this.p2)},inCentre:function(){return me.inCentre(this.p0,this.p1,this.p2)},interfaces_:function(){return[]},getClass:function(){return me}}),me.area=function(t,e,n){return Math.abs(((n.x-t.x)*(e.y-t.y)-(e.x-t.x)*(n.y-t.y))/2)},me.signedArea=function(t,e,n){return((n.x-t.x)*(e.y-t.y)-(e.x-t.x)*(n.y-t.y))/2},me.det=function(t,e,n,i){return t*i-e*n},me.interpolateZ=function(t,e,n,i){var r=e.x,s=e.y,o=n.x-r,a=i.x-r,u=n.y-s,l=i.y-s,h=o*l-a*u,c=t.x-r,f=t.y-s,g=(l*c-a*f)/h,d=(-u*c+o*f)/h;return e.z+g*(n.z-e.z)+d*(i.z-e.z)},me.longestSideLength=function(t,e,n){var i=t.distance(e),r=e.distance(n),s=n.distance(t),o=i;return r>o&&(o=r),s>o&&(o=s),o},me.isAcute=function(t,e,n){return!!pe.isAcute(t,e,n)&&(!!pe.isAcute(e,n,t)&&!!pe.isAcute(n,t,e))},me.circumcentre=function(t,e,n){var i=n.x,r=n.y,s=t.x-i,o=t.y-r,a=e.x-i,u=e.y-r,l=2*me.det(s,o,a,u);return new E(i-me.det(o,s*s+o*o,u,a*a+u*u)/l,r+me.det(s,s*s+o*o,a,a*a+u*u)/l)},me.perpendicularBisector=function(t,e){var n=e.x-t.x,i=e.y-t.y;return new k(new k(t.x+n/2,t.y+i/2,1),new k(t.x-i+n/2,t.y+n+i/2,1))},me.angleBisector=function(t,e,n){var i=e.distance(t),r=i/(i+e.distance(n)),s=n.x-t.x,o=n.y-t.y;return new E(t.x+r*s,t.y+r*o)},me.area3D=function(t,e,n){var i=e.x-t.x,r=e.y-t.y,s=e.z-t.z,o=n.x-t.x,a=n.y-t.y,u=n.z-t.z,l=r*u-s*a,h=s*o-i*u,c=i*a-r*o,f=l*l+h*h+c*c;return Math.sqrt(f)/2},me.centroid=function(t,e,n){return new E((t.x+e.x+n.x)/3,(t.y+e.y+n.y)/3)},me.inCentre=function(t,e,n){var i=e.distance(n),r=t.distance(n),s=t.distance(e),o=i+r+s;return new E((i*t.x+r*e.x+s*n.x)/o,(i*t.y+r*e.y+s*n.y)/o)};var ve=Object.freeze({Coordinate:E,CoordinateList:b,Envelope:M,LineSegment:ge,GeometryFactory:se,Geometry:K,Point:Gt,LineString:At,LinearRing:Yt,Polygon:Vt,GeometryCollection:Lt,MultiPoint:zt,MultiLineString:wt,MultiPolygon:kt,Dimension:Nt,IntersectionMatrix:_e,PrecisionModel:ie,Location:de,Triangle:me});function ye(){this._pt=[new E,new E],this._distance=s.NaN,this._isNull=!0}function xe(){}function Ee(){this._g0=null,this._g1=null,this._ptDist=new ye,this._densifyFrac=0;var t=arguments[0],e=arguments[1];this._g0=t,this._g1=e}function Ie(){this._maxPtDist=new ye,this._minPtDist=new ye,this._euclideanDist=new xe,this._geom=null;var t=arguments[0];this._geom=t}function Ne(){this._maxPtDist=new ye,this._minPtDist=new ye,this._geom=null,this._numSubSegs=0;var t=arguments[0],e=arguments[1];this._geom=t,this._numSubSegs=Math.trunc(Math.round(1/e))}function Ce(){}function Se(){}function Le(){this._min=s.POSITIVE_INFINITY,this._max=s.NEGATIVE_INFINITY}function we(){}function Re(){Le.apply(this),this._item=null;var t=arguments[0],e=arguments[1],n=arguments[2];this._min=t,this._max=e,this._item=n}e(ye.prototype,{getCoordinates:function(){return this._pt},getCoordinate:function(t){return this._pt[t]},setMinimum:function(){if(1===arguments.length){var t=arguments[0];this.setMinimum(t._pt[0],t._pt[1])}else if(2===arguments.length){var e=arguments[0],n=arguments[1];if(this._isNull)return this.initialize(e,n),null;var i=e.distance(n);i<this._distance&&this.initialize(e,n,i)}},initialize:function(){if(0===arguments.length)this._isNull=!0;else if(2===arguments.length){var t=arguments[0],e=arguments[1];this._pt[0].setCoordinate(t),this._pt[1].setCoordinate(e),this._distance=t.distance(e),this._isNull=!1}else if(3===arguments.length){var n=arguments[0],i=arguments[1],r=arguments[2];this._pt[0].setCoordinate(n),this._pt[1].setCoordinate(i),this._distance=r,this._isNull=!1}},toString:function(){return he.toLineString(this._pt[0],this._pt[1])},getDistance:function(){return this._distance},setMaximum:function(){if(1===arguments.length){var t=arguments[0];this.setMaximum(t._pt[0],t._pt[1])}else if(2===arguments.length){var e=arguments[0],n=arguments[1];if(this._isNull)return this.initialize(e,n),null;var i=e.distance(n);i>this._distance&&this.initialize(e,n,i)}},interfaces_:function(){return[]},getClass:function(){return ye}}),e(xe.prototype,{interfaces_:function(){return[]},getClass:function(){return xe}}),xe.computeDistance=function(){if(arguments[2]instanceof ye&&arguments[0]instanceof At&&arguments[1]instanceof E)for(var t=arguments[0],e=arguments[1],n=arguments[2],i=new ge,r=t.getCoordinates(),s=0;s<r.length-1;s++){i.setCoordinates(r[s],r[s+1]);var o=i.closestPoint(e);n.setMinimum(o,e)}else if(arguments[2]instanceof ye&&arguments[0]instanceof Vt&&arguments[1]instanceof E){var a=arguments[0],u=arguments[1],l=arguments[2];xe.computeDistance(a.getExteriorRing(),u,l);for(s=0;s<a.getNumInteriorRing();s++)xe.computeDistance(a.getInteriorRingN(s),u,l)}else if(arguments[2]instanceof ye&&arguments[0]instanceof K&&arguments[1]instanceof E){var h=arguments[0],c=arguments[1],f=arguments[2];if(h instanceof At)xe.computeDistance(h,c,f);else if(h instanceof Vt)xe.computeDistance(h,c,f);else if(h instanceof Lt){var g=h;for(s=0;s<g.getNumGeometries();s++){var d=g.getGeometryN(s);xe.computeDistance(d,c,f)}}else f.setMinimum(h.getCoordinate(),c)}else if(arguments[2]instanceof ye&&arguments[0]instanceof ge&&arguments[1]instanceof E){var _=arguments[0],p=arguments[1],m=arguments[2];o=_.closestPoint(p);m.setMinimum(o,p)}},e(Ee.prototype,{getCoordinates:function(){return this._ptDist.getCoordinates()},setDensifyFraction:function(t){if(t>1||t<=0)throw new i("Fraction is not in range (0.0 - 1.0]");this._densifyFrac=t},compute:function(t,e){this.computeOrientedDistance(t,e,this._ptDist),this.computeOrientedDistance(e,t,this._ptDist)},distance:function(){return this.compute(this._g0,this._g1),this._ptDist.getDistance()},computeOrientedDistance:function(t,e,n){var i=new Ie(e);if(t.apply(i),n.setMaximum(i.getMaxPointDistance()),this._densifyFrac>0){var r=new Ne(e,this._densifyFrac);t.apply(r),n.setMaximum(r.getMaxPointDistance())}},orientedDistance:function(){return this.computeOrientedDistance(this._g0,this._g1,this._ptDist),this._ptDist.getDistance()},interfaces_:function(){return[]},getClass:function(){return Ee}}),Ee.distance=function(){if(2===arguments.length)return(t=new Ee(arguments[0],arguments[1])).distance();if(3===arguments.length){var t,e=arguments[0],n=arguments[1],i=arguments[2];return(t=new Ee(e,n)).setDensifyFraction(i),t.distance()}},e(Ie.prototype,{filter:function(t){this._minPtDist.initialize(),xe.computeDistance(this._geom,t,this._minPtDist),this._maxPtDist.setMaximum(this._minPtDist)},getMaxPointDistance:function(){return this._maxPtDist},interfaces_:function(){return[Z]},getClass:function(){return Ie}}),e(Ne.prototype,{filter:function(t,e){if(0===e)return null;for(var n=t.getCoordinate(e-1),i=t.getCoordinate(e),r=(i.x-n.x)/this._numSubSegs,s=(i.y-n.y)/this._numSubSegs,o=0;o<this._numSubSegs;o++){var a=new E(n.x+o*r,n.y+o*s);this._minPtDist.initialize(),xe.computeDistance(this._geom,a,this._minPtDist),this._maxPtDist.setMaximum(this._minPtDist)}},isDone:function(){return!1},isGeometryChanged:function(){return!1},getMaxPointDistance:function(){return this._maxPtDist},interfaces_:function(){return[St]},getClass:function(){return Ne}}),Ee.MaxPointDistanceFilter=Ie,Ee.MaxDensifiedByFractionDistanceFilter=Ne,e(Ce.prototype,{visitItem:function(t){},interfaces_:function(){return[]},getClass:function(){return Ce}}),e(Se.prototype,{locate:function(t){},interfaces_:function(){return[]},getClass:function(){return Se}}),e(Le.prototype,{getMin:function(){return this._min},intersects:function(t,e){return!(this._min>e||this._max<t)},getMax:function(){return this._max},toString:function(){return he.toLineString(new E(this._min,0),new E(this._max,0))},interfaces_:function(){return[]},getClass:function(){return Le}}),e(we.prototype,{compare:function(t,e){var n=t,i=e,r=(n._min+n._max)/2,s=(i._min+i._max)/2;return r<s?-1:r>s?1:0},interfaces_:function(){return[_]},getClass:function(){return we}}),Le.NodeComparator=we,v(Re,Le),e(Re.prototype,{query:function(t,e,n){if(!this.intersects(t,e))return null;n.visitItem(this._item)},interfaces_:function(){return[]},getClass:function(){return Re}});var Te={reverseOrder:function(){return{compare:function(t,e){return e.compareTo(t)}}},min:function(t){return Te.sort(t),t.get(0)},sort:function(t,e){var n=t.toArray();e?It.sort(n,e):It.sort(n);for(var i=t.iterator(),r=0,s=n.length;r<s;r++)i.next(),i.set(n[r])},singletonList:function(t){var e=new P;return e.add(t),e}};function Pe(){Le.apply(this),this._node1=null,this._node2=null;var t=arguments[0],e=arguments[1];this._node1=t,this._node2=e,this.buildExtent(this._node1,this._node2)}function Oe(){this._leaves=new P,this._root=null,this._level=0}function be(){if(this._lines=null,this._isForcedToLineString=!1,1===arguments.length){var t=arguments[0];this._lines=t}else if(2===arguments.length){var e=arguments[0],n=arguments[1];this._lines=e,this._isForcedToLineString=n}}function Me(){this._items=new P}function De(){this._p=null,this._crossingCount=0,this._isPointOnSegment=!1;var t=arguments[0];this._p=t}function Ae(){this._index=null;var t=arguments[0];if(!(N(t,Bt)||t instanceof Yt))throw new i("Argument must be Polygonal or LinearRing");this._index=new Ge(t)}function Fe(){this._counter=null;var t=arguments[0];this._counter=t}function Ge(){this._index=new Oe;var t=arguments[0];this.init(t)}function qe(){}function Be(){this._parent=null,this._atStart=null,this._max=null,this._index=null,this._subcollectionIterator=null;var t=arguments[0];this._parent=t,this._atStart=!0,this._index=0,this._max=t.getNumGeometries()}function Ve(){this._geom=null;var t=arguments[0];this._geom=t}function ze(){}function Ye(){}function ke(){}function Ue(){}function Xe(){this._areaBasePt=null,this._triangleCent3=new E,this._areasum2=0,this._cg3=new E,this._lineCentSum=new E,this._totalLength=0,this._ptCount=0,this._ptCentSum=new E;var t=arguments[0];this._areaBasePt=null,this.add(t)}function He(){}function We(t){this.message=t||""}function je(){this.array_=[]}function Ke(){this.treeSet=new yt,this.list=new P}function Ze(){if(this._geomFactory=null,this._inputPts=null,1===arguments.length){var t=arguments[0];Ze.call(this,Ze.extractCoordinates(t),t.getFactory())}else if(2===arguments.length){var e=arguments[0],n=arguments[1];this._inputPts=Ke.filterCoordinates(e),this._geomFactory=n}}function Qe(){this._origin=null;var t=arguments[0];this._origin=t}function Je(){this._factory=null,this._interiorPoint=null,this._maxWidth=0;var t=arguments[0];this._factory=t.getFactory(),this.add(t)}function $e(){this._poly=null,this._centreY=null,this._hiY=s.MAX_VALUE,this._loY=-s.MAX_VALUE;var t=arguments[0];this._poly=t,this._hiY=t.getEnvelopeInternal().getMaxY(),this._loY=t.getEnvelopeInternal().getMinY(),this._centreY=Je.avg(this._loY,this._hiY)}function tn(){this._centroid=null,this._minDistance=s.MAX_VALUE,this._interiorPoint=null;var t=arguments[0];this._centroid=t.getCentroid().getCoordinate(),this.addInterior(t),null===this._interiorPoint&&this.addEndpoints(t)}function en(){this._centroid=null,this._minDistance=s.MAX_VALUE,this._interiorPoint=null;var t=arguments[0];this._centroid=t.getCentroid().getCoordinate(),this.add(t)}function nn(){this.selectedSegment=new ge}function rn(){this._items=new P,this._subnode=new Array(2).fill(null)}function sn(){if(this.min=null,this.max=null,0===arguments.length)this.min=0,this.max=0;else if(1===arguments.length){var t=arguments[0];this.init(t.min,t.max)}else if(2===arguments.length){var e=arguments[0],n=arguments[1];this.init(e,n)}}function on(){}function an(){this._pt=0,this._level=0,this._interval=null;var t=arguments[0];this.computeKey(t)}function un(){rn.apply(this),this._interval=null,this._centre=null,this._level=null;var t=arguments[0],e=arguments[1];this._interval=t,this._level=e,this._centre=(t.getMin()+t.getMax())/2}function ln(){}function hn(){rn.apply(this)}function cn(){this._root=null,this._minExtent=1,this._root=new hn}function fn(){this._pts=null,this._start=null,this._end=null,this._env=null,this._context=null,this._id=null;var t=arguments[0],e=arguments[1],n=arguments[2],i=arguments[3];this._pts=t,this._start=e,this._end=n,this._context=i}function gn(){}function dn(){}function _n(){}function pn(){}function mn(){this._ring=null,this._tree=null,this._crossings=0,this._interval=new sn;var t=arguments[0];this._ring=t,this.buildIndex()}function vn(){nn.apply(this),this.mcp=null,this.p=null;var t=arguments[0],e=arguments[1];this.mcp=t,this.p=e}function yn(){this._input=null,this._extremalPts=null,this._centre=null,this._radius=0;var t=arguments[0];this._input=t}function xn(){if(this._inputGeom=null,this._isConvex=null,this._convexHullPts=null,this._minBaseSeg=new ge,this._minWidthPt=null,this._minPtIndex=null,this._minWidth=0,1===arguments.length){var t=arguments[0];xn.call(this,t,!1)}else if(2===arguments.length){var e=arguments[0],n=arguments[1];this._inputGeom=e,this._isConvex=n}}v(Pe,Le),e(Pe.prototype,{buildExtent:function(t,e){this._min=Math.min(t._min,e._min),this._max=Math.max(t._max,e._max)},query:function(t,e,n){if(!this.intersects(t,e))return null;null!==this._node1&&this._node1.query(t,e,n),null!==this._node2&&this._node2.query(t,e,n)},interfaces_:function(){return[]},getClass:function(){return Pe}}),e(Oe.prototype,{buildTree:function(){Te.sort(this._leaves,new Le.NodeComparator);for(var t=this._leaves,e=null,n=new P;;){if(this.buildLevel(t,n),1===n.size())return n.get(0);e=t,t=n,n=e}},insert:function(t,e,n){if(null!==this._root)throw new IllegalStateException("Index cannot be added to once it has been queried");this._leaves.add(new Re(t,e,n))},query:function(t,e,n){this.init(),this._root.query(t,e,n)},buildRoot:function(){if(null!==this._root)return null;this._root=this.buildTree()},printNode:function(t){Y.out.println(he.toLineString(new E(t._min,this._level),new E(t._max,this._level)))},init:function(){if(null!==this._root)return null;this.buildRoot()},buildLevel:function(t,e){this._level++,e.clear();for(var n=0;n<t.size();n+=2){var i=t.get(n);if(null===(n+1<t.size()?t.get(n):null))e.add(i);else{var r=new Pe(t.get(n),t.get(n+1));e.add(r)}}},interfaces_:function(){return[]},getClass:function(){return Oe}}),e(be.prototype,{filter:function(t){if(this._isForcedToLineString&&t instanceof Yt){var e=t.getFactory().createLineString(t.getCoordinateSequence());return this._lines.add(e),null}t instanceof At&&this._lines.add(t)},setForceToLineString:function(t){this._isForcedToLineString=t},interfaces_:function(){return[j]},getClass:function(){return be}}),be.getGeometry=function(){if(1===arguments.length){var t=arguments[0];return t.getFactory().buildGeometry(be.getLines(t))}if(2===arguments.length){var e=arguments[0],n=arguments[1];return e.getFactory().buildGeometry(be.getLines(e,n))}},be.getLines=function(){if(1===arguments.length){var t=arguments[0];return be.getLines(t,!1)}if(2===arguments.length){if(N(arguments[0],S)&&N(arguments[1],S)){for(var e=arguments[0],n=arguments[1],i=e.iterator();i.hasNext();){var r=i.next();be.getLines(r,n)}return n}if(arguments[0]instanceof K&&"boolean"==typeof arguments[1]){var s=arguments[0],o=arguments[1],a=new P;return s.apply(new be(a,o)),a}if(arguments[0]instanceof K&&N(arguments[1],S)){var u=arguments[0],l=arguments[1];return u instanceof At?l.add(u):u.apply(new be(l)),l}}else if(3===arguments.length){if("boolean"==typeof arguments[2]&&N(arguments[0],S)&&N(arguments[1],S)){var h=arguments[0],c=arguments[1],f=arguments[2];for(i=h.iterator();i.hasNext();){r=i.next();be.getLines(r,c,f)}return c}if("boolean"==typeof arguments[2]&&arguments[0]instanceof K&&N(arguments[1],S)){var g=arguments[0],d=arguments[1],_=arguments[2];return g.apply(new be(d,_)),d}}},e(Me.prototype,{visitItem:function(t){this._items.add(t)},getItems:function(){return this._items},interfaces_:function(){return[Ce]},getClass:function(){return Me}}),e(De.prototype,{countSegment:function(t,e){if(t.x<this._p.x&&e.x<this._p.x)return null;if(this._p.x===e.x&&this._p.y===e.y)return this._isPointOnSegment=!0,null;if(t.y===this._p.y&&e.y===this._p.y){var n=t.x,i=e.x;return n>i&&(n=e.x,i=t.x),this._p.x>=n&&this._p.x<=i&&(this._isPointOnSegment=!0),null}if(t.y>this._p.y&&e.y<=this._p.y||e.y>this._p.y&&t.y<=this._p.y){var r=z.index(t,e,this._p);if(r===z.COLLINEAR)return this._isPointOnSegment=!0,null;e.y<t.y&&(r=-r),r===z.LEFT&&this._crossingCount++}},isPointInPolygon:function(){return this.getLocation()!==de.EXTERIOR},getLocation:function(){return this._isPointOnSegment?de.BOUNDARY:this._crossingCount%2==1?de.INTERIOR:de.EXTERIOR},isOnSegment:function(){return this._isPointOnSegment},interfaces_:function(){return[]},getClass:function(){return De}}),De.locatePointInRing=function(){if(arguments[0]instanceof E&&N(arguments[1],H)){for(var t=arguments[0],e=arguments[1],n=new De(t),i=new E,r=new E,s=1;s<e.size();s++)if(e.getCoordinate(s,i),e.getCoordinate(s-1,r),n.countSegment(i,r),n.isOnSegment())return n.getLocation();return n.getLocation()}if(arguments[0]instanceof E&&arguments[1]instanceof Array){var o=arguments[0],a=arguments[1];for(n=new De(o),s=1;s<a.length;s++){i=a[s],r=a[s-1];if(n.countSegment(i,r),n.isOnSegment())return n.getLocation()}return n.getLocation()}},e(Ae.prototype,{locate:function(t){var e=new De(t),n=new Fe(e);return this._index.query(t.y,t.y,n),e.getLocation()},interfaces_:function(){return[Se]},getClass:function(){return Ae}}),e(Fe.prototype,{visitItem:function(t){var e=t;this._counter.countSegment(e.getCoordinate(0),e.getCoordinate(1))},interfaces_:function(){return[Ce]},getClass:function(){return Fe}}),e(Ge.prototype,{init:function(t){for(var e=be.getLines(t).iterator();e.hasNext();){var n=e.next().getCoordinates();this.addLine(n)}},addLine:function(t){for(var e=1;e<t.length;e++){var n=new ge(t[e-1],t[e]),i=Math.min(n.p0.y,n.p1.y),r=Math.max(n.p0.y,n.p1.y);this._index.insert(i,r,n)}},query:function(){if(2===arguments.length){var t=arguments[0],e=arguments[1],n=new Me;return this._index.query(t,e,n),n.getItems()}if(3===arguments.length){var i=arguments[0],r=arguments[1],s=arguments[2];this._index.query(i,r,s)}},interfaces_:function(){return[]},getClass:function(){return Ge}}),Ae.SegmentVisitor=Fe,Ae.IntervalIndexedGeometry=Ge,e(qe.prototype,{interfaces_:function(){return[]},getClass:function(){return qe}}),qe.isOnLine=function(){if(arguments[0]instanceof E&&N(arguments[1],H)){for(var t=arguments[0],e=arguments[1],n=new fe,i=new E,r=new E,s=e.size(),o=1;o<s;o++)if(e.getCoordinate(o-1,i),e.getCoordinate(o,r),n.computeIntersection(t,i,r),n.hasIntersection())return!0;return!1}if(arguments[0]instanceof E&&arguments[1]instanceof Array){var a=arguments[0],u=arguments[1];for(n=new fe,o=1;o<u.length;o++){i=u[o-1],r=u[o];if(n.computeIntersection(a,i,r),n.hasIntersection())return!0}return!1}},qe.locateInRing=function(t,e){return De.locatePointInRing(t,e)},qe.isInRing=function(t,e){return qe.locateInRing(t,e)!==de.EXTERIOR},e(Be.prototype,{next:function(){if(this._atStart)return this._atStart=!1,Be.isAtomic(this._parent)&&this._index++,this._parent;if(null!==this._subcollectionIterator){if(this._subcollectionIterator.hasNext())return this._subcollectionIterator.next();this._subcollectionIterator=null}if(this._index>=this._max)throw new R;var t=this._parent.getGeometryN(this._index++);return t instanceof Lt?(this._subcollectionIterator=new Be(t),this._subcollectionIterator.next()):t},remove:function(){throw new UnsupportedOperationException(this.getClass().getName())},hasNext:function(){if(this._atStart)return!0;if(null!==this._subcollectionIterator){if(this._subcollectionIterator.hasNext())return!0;this._subcollectionIterator=null}return!(this._index>=this._max)},interfaces_:function(){return[C]},getClass:function(){return Be}}),Be.isAtomic=function(t){return!(t instanceof Lt)},e(Ve.prototype,{locate:function(t){return Ve.locate(t,this._geom)},interfaces_:function(){return[Se]},getClass:function(){return Ve}}),Ve.locatePointInPolygon=function(t,e){if(e.isEmpty())return de.EXTERIOR;var n=e.getExteriorRing(),i=Ve.locatePointInRing(t,n);if(i!==de.INTERIOR)return i;for(var r=0;r<e.getNumInteriorRing();r++){var s=e.getInteriorRingN(r),o=Ve.locatePointInRing(t,s);if(o===de.BOUNDARY)return de.BOUNDARY;if(o===de.INTERIOR)return de.EXTERIOR}return de.INTERIOR},Ve.locatePointInRing=function(t,e){return e.getEnvelopeInternal().intersects(t)?qe.locateInRing(t,e.getCoordinates()):de.EXTERIOR},Ve.containsPointInPolygon=function(t,e){return de.EXTERIOR!==Ve.locatePointInPolygon(t,e)},Ve.locateInGeometry=function(t,e){if(e instanceof Vt)return Ve.locatePointInPolygon(t,e);if(e instanceof Lt)for(var n=new Be(e);n.hasNext();){var i=n.next();if(i!==e){var r=Ve.locateInGeometry(t,i);if(r!==de.EXTERIOR)return r}}return de.EXTERIOR},Ve.locate=function(t,e){return e.isEmpty()?de.EXTERIOR:Ve.locateInGeometry(t,e)},e(ze.prototype,{measure:function(t,e){},interfaces_:function(){return[]},getClass:function(){return ze}}),e(Ye.prototype,{measure:function(t,e){return t.intersection(e).getArea()/t.union(e).getArea()},interfaces_:function(){return[ze]},getClass:function(){return Ye}}),e(ke.prototype,{measure:function(t,e){var n=Ee.distance(t,e,ke.DENSIFY_FRACTION),i=new M(t.getEnvelopeInternal());i.expandToInclude(e.getEnvelopeInternal());var r=1-n/ke.diagonalSize(i);return r},interfaces_:function(){return[ze]},getClass:function(){return ke}}),ke.diagonalSize=function(t){if(t.isNull())return 0;var e=t.getWidth(),n=t.getHeight();return Math.sqrt(e*e+n*n)},ke.DENSIFY_FRACTION=.25,e(Ue.prototype,{interfaces_:function(){return[]},getClass:function(){return Ue}}),Ue.combine=function(t,e){return Math.min(t,e)},e(Xe.prototype,{setAreaBasePoint:function(t){this._areaBasePt=t},addPoint:function(t){this._ptCount+=1,this._ptCentSum.x+=t.x,this._ptCentSum.y+=t.y},addLineSegments:function(t){for(var e=0,n=0;n<t.length-1;n++){var i=t[n].distance(t[n+1]);if(0!==i){e+=i;var r=(t[n].x+t[n+1].x)/2;this._lineCentSum.x+=i*r;var s=(t[n].y+t[n+1].y)/2;this._lineCentSum.y+=i*s}}this._totalLength+=e,0===e&&t.length>0&&this.addPoint(t[0])},addHole:function(t){for(var e=z.isCCW(t),n=0;n<t.length-1;n++)this.addTriangle(this._areaBasePt,t[n],t[n+1],e);this.addLineSegments(t)},getCentroid:function(){var t=new E;if(Math.abs(this._areasum2)>0)t.x=this._cg3.x/3/this._areasum2,t.y=this._cg3.y/3/this._areasum2;else if(this._totalLength>0)t.x=this._lineCentSum.x/this._totalLength,t.y=this._lineCentSum.y/this._totalLength;else{if(!(this._ptCount>0))return null;t.x=this._ptCentSum.x/this._ptCount,t.y=this._ptCentSum.y/this._ptCount}return t},addShell:function(t){t.length>0&&this.setAreaBasePoint(t[0]);for(var e=!z.isCCW(t),n=0;n<t.length-1;n++)this.addTriangle(this._areaBasePt,t[n],t[n+1],e);this.addLineSegments(t)},addTriangle:function(t,e,n,i){var r=i?1:-1;Xe.centroid3(t,e,n,this._triangleCent3);var s=Xe.area2(t,e,n);this._cg3.x+=r*s*this._triangleCent3.x,this._cg3.y+=r*s*this._triangleCent3.y,this._areasum2+=r*s},add:function(){if(arguments[0]instanceof Vt){var t=arguments[0];this.addShell(t.getExteriorRing().getCoordinates());for(var e=0;e<t.getNumInteriorRing();e++)this.addHole(t.getInteriorRingN(e).getCoordinates())}else if(arguments[0]instanceof K){var n=arguments[0];if(n.isEmpty())return null;if(n instanceof Gt)this.addPoint(n.getCoordinate());else if(n instanceof At)this.addLineSegments(n.getCoordinates());else if(n instanceof Vt){var i=n;this.add(i)}else if(n instanceof Lt){var r=n;for(e=0;e<r.getNumGeometries();e++)this.add(r.getGeometryN(e))}}},interfaces_:function(){return[]},getClass:function(){return Xe}}),Xe.area2=function(t,e,n){return(e.x-t.x)*(n.y-t.y)-(n.x-t.x)*(e.y-t.y)},Xe.centroid3=function(t,e,n,i){return i.x=t.x+e.x+n.x,i.y=t.y+e.y+n.y,null},Xe.getCentroid=function(t){return new Xe(t).getCentroid()},e(He.prototype,{interfaces_:function(){return[]},getClass:function(){return He}}),He.orientationIndex=function(t,e,n){return V.orientationIndex(t,e,n)},He.signedArea=function(){if(arguments[0]instanceof Array){var t=arguments[0];if(t.length<3)return 0;for(var e=0,n=t[0].x,i=1;i<t.length-1;i++){var r=t[i].x-n,s=t[i+1].y;e+=r*(t[i-1].y-s)}return e/2}if(N(arguments[0],H)){var o=arguments[0],a=o.size();if(a<3)return 0;var u=new E,l=new E,h=new E;o.getCoordinate(0,l),o.getCoordinate(1,h);n=l.x;h.x-=n;for(e=0,i=1;i<a-1;i++)u.y=l.y,l.x=h.x,l.y=h.y,o.getCoordinate(i+1,h),h.x-=n,e+=l.x*(u.y-h.y);return e/2}},He.distanceLineLine=function(t,e,n,i){if(t.equals(e))return He.distancePointLine(t,n,i);if(n.equals(i))return He.distancePointLine(i,t,e);var r=!1;if(M.intersects(t,e,n,i)){var s=(e.x-t.x)*(i.y-n.y)-(e.y-t.y)*(i.x-n.x);if(0===s)r=!0;else{var o=(t.y-n.y)*(i.x-n.x)-(t.x-n.x)*(i.y-n.y),a=((t.y-n.y)*(e.x-t.x)-(t.x-n.x)*(e.y-t.y))/s,u=o/s;(u<0||u>1||a<0||a>1)&&(r=!0)}}else r=!0;return r?U.min(He.distancePointLine(t,n,i),He.distancePointLine(e,n,i),He.distancePointLine(n,t,e),He.distancePointLine(i,t,e)):0},He.isPointInRing=function(t,e){return He.locatePointInRing(t,e)!==de.EXTERIOR},He.computeLength=function(t){var e=t.size();if(e<=1)return 0;var n=0,i=new E;t.getCoordinate(0,i);for(var r=i.x,s=i.y,o=1;o<e;o++){t.getCoordinate(o,i);var a=i.x,u=i.y,l=a-r,h=u-s;n+=Math.sqrt(l*l+h*h),r=a,s=u}return n},He.isCCW=function(t){var e=t.length-1;if(e<3)throw new i("Ring has fewer than 4 points, so orientation cannot be determined");for(var n=t[0],r=0,s=1;s<=e;s++){var o=t[s];o.y>n.y&&(n=o,r=s)}var a=r;do{(a-=1)<0&&(a=e)}while(t[a].equals2D(n)&&a!==r);var u=r;do{u=(u+1)%e}while(t[u].equals2D(n)&&u!==r);var l=t[a],h=t[u];if(l.equals2D(n)||h.equals2D(n)||l.equals2D(h))return!1;var c=He.computeOrientation(l,n,h);return 0===c?l.x>h.x:c>0},He.locatePointInRing=function(t,e){return De.locatePointInRing(t,e)},He.distancePointLinePerpendicular=function(t,e,n){var i=(n.x-e.x)*(n.x-e.x)+(n.y-e.y)*(n.y-e.y),r=((e.y-t.y)*(n.x-e.x)-(e.x-t.x)*(n.y-e.y))/i;return Math.abs(r)*Math.sqrt(i)},He.computeOrientation=function(t,e,n){return He.orientationIndex(t,e,n)},He.distancePointLine=function(){if(2===arguments.length){var t=arguments[0],e=arguments[1];if(0===e.length)throw new i("Line array must contain at least one vertex");for(var n=t.distance(e[0]),r=0;r<e.length-1;r++){var s=He.distancePointLine(t,e[r],e[r+1]);s<n&&(n=s)}return n}if(3===arguments.length){var o=arguments[0],a=arguments[1],u=arguments[2];if(a.x===u.x&&a.y===u.y)return o.distance(a);var l=(u.x-a.x)*(u.x-a.x)+(u.y-a.y)*(u.y-a.y),h=((o.x-a.x)*(u.x-a.x)+(o.y-a.y)*(u.y-a.y))/l;if(h<=0)return o.distance(a);if(h>=1)return o.distance(u);var c=((a.y-o.y)*(u.x-a.x)-(a.x-o.x)*(u.y-a.y))/l;return Math.abs(c)*Math.sqrt(l)}},He.isOnLine=function(t,e){for(var n=new fe,i=1;i<e.length;i++){var r=e[i-1],s=e[i];if(n.computeIntersection(t,r,s),n.hasIntersection())return!0}return!1},He.CLOCKWISE=-1,He.RIGHT=He.CLOCKWISE,He.COUNTERCLOCKWISE=1,He.LEFT=He.COUNTERCLOCKWISE,He.COLLINEAR=0,He.STRAIGHT=He.COLLINEAR,We.prototype=new Error,We.prototype.name="EmptyStackException",je.prototype=new w,je.prototype.add=function(t){return this.array_.push(t),!0},je.prototype.get=function(t){if(t<0||t>=this.size())throw new IndexOutOfBoundsException;return this.array_[t]},je.prototype.push=function(t){return this.array_.push(t),t},je.prototype.pop=function(t){if(0===this.array_.length)throw new We;return this.array_.pop()},je.prototype.peek=function(){if(0===this.array_.length)throw new We;return this.array_[this.array_.length-1]},je.prototype.empty=function(){return 0===this.array_.length},je.prototype.isEmpty=function(){return this.empty()},je.prototype.search=function(t){return this.array_.indexOf(t)},je.prototype.size=function(){return this.array_.length},je.prototype.toArray=function(){for(var t=[],e=0,n=this.array_.length;e<n;e++)t.push(this.array_[e]);return t},e(Ke.prototype,{filter:function(t){this.treeSet.contains(t)||(this.list.add(t),this.treeSet.add(t))},getCoordinates:function(){var t=new Array(this.list.size()).fill(null);return this.list.toArray(t)},interfaces_:function(){return[Z]},getClass:function(){return Ke}}),Ke.filterCoordinates=function(t){for(var e=new Ke,n=0;n<t.length;n++)e.filter(t[n]);return e.getCoordinates()},e(Ze.prototype,{preSort:function(t){for(var e=null,n=1;n<t.length;n++)(t[n].y<t[0].y||t[n].y===t[0].y&&t[n].x<t[0].x)&&(e=t[0],t[0]=t[n],t[n]=e);return It.sort(t,1,t.length,new Qe(t[0])),t},computeOctRing:function(t){var e=this.computeOctPts(t),n=new b;return n.add(e,!1),n.size()<3?null:(n.closeRing(),n.toCoordinateArray())},lineOrPolygon:function(t){if(3===(t=this.cleanRing(t)).length)return this._geomFactory.createLineString([t[0],t[1]]);var e=this._geomFactory.createLinearRing(t);return this._geomFactory.createPolygon(e)},cleanRing:function(t){x.equals(t[0],t[t.length-1]);for(var e=new P,n=null,i=0;i<=t.length-2;i++){var r=t[i],s=t[i+1];r.equals(s)||(null!==n&&this.isBetween(n,r,s)||(e.add(r),n=r))}e.add(t[t.length-1]);var o=new Array(e.size()).fill(null);return e.toArray(o)},isBetween:function(t,e,n){if(0!==z.index(t,e,n))return!1;if(t.x!==n.x){if(t.x<=e.x&&e.x<=n.x)return!0;if(n.x<=e.x&&e.x<=t.x)return!0}if(t.y!==n.y){if(t.y<=e.y&&e.y<=n.y)return!0;if(n.y<=e.y&&e.y<=t.y)return!0}return!1},reduce:function(t){var e=this.computeOctRing(t);if(null===e)return t;for(var n=new yt,i=0;i<e.length;i++)n.add(e[i]);for(i=0;i<t.length;i++)qe.isInRing(t[i],e)||n.add(t[i]);var r=nt.toCoordinateArray(n);return r.length<3?this.padArray3(r):r},getConvexHull:function(){if(0===this._inputPts.length)return this._geomFactory.createGeometryCollection();if(1===this._inputPts.length)return this._geomFactory.createPoint(this._inputPts[0]);if(2===this._inputPts.length)return this._geomFactory.createLineString(this._inputPts);var t=this._inputPts;this._inputPts.length>50&&(t=this.reduce(this._inputPts));var e=this.preSort(t),n=this.grahamScan(e),i=this.toCoordinateArray(n);return this.lineOrPolygon(i)},padArray3:function(t){for(var e=new Array(3).fill(null),n=0;n<e.length;n++)n<t.length?e[n]=t[n]:e[n]=t[0];return e},computeOctPts:function(t){for(var e=new Array(8).fill(null),n=0;n<e.length;n++)e[n]=t[0];for(var i=1;i<t.length;i++)t[i].x<e[0].x&&(e[0]=t[i]),t[i].x-t[i].y<e[1].x-e[1].y&&(e[1]=t[i]),t[i].y>e[2].y&&(e[2]=t[i]),t[i].x+t[i].y>e[3].x+e[3].y&&(e[3]=t[i]),t[i].x>e[4].x&&(e[4]=t[i]),t[i].x-t[i].y>e[5].x-e[5].y&&(e[5]=t[i]),t[i].y<e[6].y&&(e[6]=t[i]),t[i].x+t[i].y<e[7].x+e[7].y&&(e[7]=t[i]);return e},toCoordinateArray:function(t){for(var e=new Array(t.size()).fill(null),n=0;n<t.size();n++){var i=t.get(n);e[n]=i}return e},grahamScan:function(t){var e=null,n=new je;n.push(t[0]),n.push(t[1]),n.push(t[2]);for(var i=3;i<t.length;i++){for(e=n.pop();!n.empty()&&z.index(n.peek(),e,t[i])>0;)e=n.pop();n.push(e),n.push(t[i])}return n.push(t[0]),n},interfaces_:function(){return[]},getClass:function(){return Ze}}),Ze.extractCoordinates=function(t){var e=new Ke;return t.apply(e),e.getCoordinates()},e(Qe.prototype,{compare:function(t,e){var n=t,i=e;return Qe.polarCompare(this._origin,n,i)},interfaces_:function(){return[_]},getClass:function(){return Qe}}),Qe.polarCompare=function(t,e,n){var i=e.x-t.x,r=e.y-t.y,s=n.x-t.x,o=n.y-t.y,a=z.index(t,e,n);if(a===z.COUNTERCLOCKWISE)return 1;if(a===z.CLOCKWISE)return-1;var u=i*i+r*r,l=s*s+o*o;return u<l?-1:u>l?1:0},Ze.RadialComparator=Qe,e(Je.prototype,{addPolygon:function(t){if(t.isEmpty())return null;var e=null,n=null,i=this.horizontalBisector(t);if(0===i.getLength())n=0,e=i.getCoordinate();else{var r=i.intersection(t),s=this.widestGeometry(r);n=s.getEnvelopeInternal().getWidth(),e=Je.centre(s.getEnvelopeInternal())}(null===this._interiorPoint||n>this._maxWidth)&&(this._interiorPoint=e,this._maxWidth=n)},getInteriorPoint:function(){return this._interiorPoint},widestGeometry:function(){if(arguments[0]instanceof Lt){var t=arguments[0];if(t.isEmpty())return t;for(var e=t.getGeometryN(0),n=1;n<t.getNumGeometries();n++)t.getGeometryN(n).getEnvelopeInternal().getWidth()>e.getEnvelopeInternal().getWidth()&&(e=t.getGeometryN(n));return e}if(arguments[0]instanceof K){var i=arguments[0];return i instanceof Lt?this.widestGeometry(i):i}},horizontalBisector:function(t){var e=t.getEnvelopeInternal(),n=$e.getBisectorY(t);return this._factory.createLineString([new E(e.getMinX(),n),new E(e.getMaxX(),n)])},add:function(t){if(t instanceof Vt)this.addPolygon(t);else if(t instanceof Lt)for(var e=t,n=0;n<e.getNumGeometries();n++)this.add(e.getGeometryN(n))},interfaces_:function(){return[]},getClass:function(){return Je}}),Je.centre=function(t){return new E(Je.avg(t.getMinX(),t.getMaxX()),Je.avg(t.getMinY(),t.getMaxY()))},Je.avg=function(t,e){return(t+e)/2},e($e.prototype,{updateInterval:function(t){t<=this._centreY?t>this._loY&&(this._loY=t):t>this._centreY&&t<this._hiY&&(this._hiY=t)},getBisectorY:function(){this.process(this._poly.getExteriorRing());for(var t=0;t<this._poly.getNumInteriorRing();t++)this.process(this._poly.getInteriorRingN(t));return Je.avg(this._hiY,this._loY)},process:function(t){for(var e=t.getCoordinateSequence(),n=0;n<e.size();n++){var i=e.getY(n);this.updateInterval(i)}},interfaces_:function(){return[]},getClass:function(){return $e}}),$e.getBisectorY=function(t){return new $e(t).getBisectorY()},Je.SafeBisectorFinder=$e,e(tn.prototype,{addEndpoints:function(){if(arguments[0]instanceof K){var t=arguments[0];if(t instanceof At)this.addEndpoints(t.getCoordinates());else if(t instanceof Lt)for(var e=t,n=0;n<e.getNumGeometries();n++)this.addEndpoints(e.getGeometryN(n))}else if(arguments[0]instanceof Array){var i=arguments[0];this.add(i[0]),this.add(i[i.length-1])}},getInteriorPoint:function(){return this._interiorPoint},addInterior:function(){if(arguments[0]instanceof K){var t=arguments[0];if(t instanceof At)this.addInterior(t.getCoordinates());else if(t instanceof Lt)for(var e=t,n=0;n<e.getNumGeometries();n++)this.addInterior(e.getGeometryN(n))}else if(arguments[0]instanceof Array){var i=arguments[0];for(n=1;n<i.length-1;n++)this.add(i[n])}},add:function(t){var e=t.distance(this._centroid);e<this._minDistance&&(this._interiorPoint=new E(t),this._minDistance=e)},interfaces_:function(){return[]},getClass:function(){return tn}}),e(en.prototype,{getInteriorPoint:function(){return this._interiorPoint},add:function(){if(arguments[0]instanceof K){var t=arguments[0];if(t instanceof Gt)this.add(t.getCoordinate());else if(t instanceof Lt)for(var e=t,n=0;n<e.getNumGeometries();n++)this.add(e.getGeometryN(n))}else if(arguments[0]instanceof E){var i=arguments[0],r=i.distance(this._centroid);r<this._minDistance&&(this._interiorPoint=new E(i),this._minDistance=r)}},interfaces_:function(){return[]},getClass:function(){return en}}),e(nn.prototype,{select:function(){if(1===arguments.length);else if(2===arguments.length){var t=arguments[0],e=arguments[1];t.getLineSegment(e,this.selectedSegment),this.select(this.selectedSegment)}},interfaces_:function(){return[]},getClass:function(){return nn}}),e(rn.prototype,{hasChildren:function(){for(var t=0;t<2;t++)if(null!==this._subnode[t])return!0;return!1},isPrunable:function(){return!(this.hasChildren()||this.hasItems())},addAllItems:function(t){t.addAll(this._items);for(var e=0;e<2;e++)null!==this._subnode[e]&&this._subnode[e].addAllItems(t);return t},size:function(){for(var t=0,e=0;e<2;e++)null!==this._subnode[e]&&(t+=this._subnode[e].size());return t+this._items.size()},addAllItemsFromOverlapping:function(t,e){if(null!==t&&!this.isSearchMatch(t))return null;e.addAll(this._items),null!==this._subnode[0]&&this._subnode[0].addAllItemsFromOverlapping(t,e),null!==this._subnode[1]&&this._subnode[1].addAllItemsFromOverlapping(t,e)},hasItems:function(){return!this._items.isEmpty()},remove:function(t,e){if(!this.isSearchMatch(t))return!1;for(var n=!1,i=0;i<2;i++)if(null!==this._subnode[i]&&(n=this._subnode[i].remove(t,e))){this._subnode[i].isPrunable()&&(this._subnode[i]=null);break}return n||(n=this._items.remove(e))},getItems:function(){return this._items},depth:function(){for(var t=0,e=0;e<2;e++)if(null!==this._subnode[e]){var n=this._subnode[e].depth();n>t&&(t=n)}return t+1},nodeSize:function(){for(var t=0,e=0;e<2;e++)null!==this._subnode[e]&&(t+=this._subnode[e].nodeSize());return t+1},add:function(t){this._items.add(t)},interfaces_:function(){return[]},getClass:function(){return rn}}),rn.getSubnodeIndex=function(t,e){var n=-1;return t.min>=e&&(n=1),t.max<=e&&(n=0),n},e(sn.prototype,{expandToInclude:function(t){t.max>this.max&&(this.max=t.max),t.min<this.min&&(this.min=t.min)},getWidth:function(){return this.max-this.min},overlaps:function(){if(1===arguments.length){var t=arguments[0];return this.overlaps(t.min,t.max)}if(2===arguments.length){var e=arguments[0],n=arguments[1];return!(this.min>n||this.max<e)}},getMin:function(){return this.min},toString:function(){return"["+this.min+", "+this.max+"]"},contains:function(){if(1===arguments.length){if(arguments[0]instanceof sn){var t=arguments[0];return this.contains(t.min,t.max)}if("number"==typeof arguments[0]){var e=arguments[0];return e>=this.min&&e<=this.max}}else if(2===arguments.length){var n=arguments[0],i=arguments[1];return n>=this.min&&i<=this.max}},init:function(t,e){this.min=t,this.max=e,t>e&&(this.min=e,this.max=t)},getMax:function(){return this.max},interfaces_:function(){return[]},getClass:function(){return sn}}),on.exponent=function(t){return function(t,e){var n,i,r,s,o={32:8,64:11}[t];s||(n=e<0||1/e<0,isFinite(e)||(s={32:{d:127,c:128,b:0,a:0},64:{d:32752,c:0,b:0,a:0}}[t],n&&(s.d+=1<<t/4-1),i=Math.pow(2,o)-1,r=0));if(!s){for(i={32:127,64:1023}[t],r=Math.abs(e);r>=2;)i++,r/=2;for(;r<1&&i>0;)i--,r*=2;i<=0&&(r/=2),32===t&&i>254&&(s={d:n?255:127,c:128,b:0,a:0},i=Math.pow(2,o)-1,r=0)}return i}(64,t)-1023},on.powerOf2=function(t){return Math.pow(2,t)},e(an.prototype,{getInterval:function(){return this._interval},getLevel:function(){return this._level},computeKey:function(t){for(this._level=an.computeLevel(t),this._interval=new sn,this.computeInterval(this._level,t);!this._interval.contains(t);)this._level+=1,this.computeInterval(this._level,t)},computeInterval:function(t,e){var n=on.powerOf2(t);this._pt=Math.floor(e.getMin()/n)*n,this._interval.init(this._pt,this._pt+n)},getPoint:function(){return this._pt},interfaces_:function(){return[]},getClass:function(){return an}}),an.computeLevel=function(t){var e=t.getWidth();return on.exponent(e)+1},v(un,rn),e(un.prototype,{getInterval:function(){return this._interval},find:function(t){var e=rn.getSubnodeIndex(t,this._centre);return-1===e?this:null!==this._subnode[e]?this._subnode[e].find(t):this},insert:function(t){x.isTrue(null===this._interval||this._interval.contains(t._interval));var e=rn.getSubnodeIndex(t._interval,this._centre);if(t._level===this._level-1)this._subnode[e]=t;else{var n=this.createSubnode(e);n.insert(t),this._subnode[e]=n}},isSearchMatch:function(t){return t.overlaps(this._interval)},getSubnode:function(t){return null===this._subnode[t]&&(this._subnode[t]=this.createSubnode(t)),this._subnode[t]},getNode:function(t){var e=rn.getSubnodeIndex(t,this._centre);return-1!==e?this.getSubnode(e).getNode(t):this},createSubnode:function(t){var e=0,n=0;switch(t){case 0:e=this._interval.getMin(),n=this._centre;break;case 1:e=this._centre,n=this._interval.getMax()}return new un(new sn(e,n),this._level-1)},interfaces_:function(){return[]},getClass:function(){return un}}),un.createNode=function(t){var e=new an(t);return new un(e.getInterval(),e.getLevel())},un.createExpanded=function(t,e){var n=new sn(e);null!==t&&n.expandToInclude(t._interval);var i=un.createNode(n);return null!==t&&i.insert(t),i},e(ln.prototype,{interfaces_:function(){return[]},getClass:function(){return ln}}),ln.isZeroWidth=function(t,e){var n=e-t;if(0===n)return!0;var i=n/Math.max(Math.abs(t),Math.abs(e));return on.exponent(i)<=ln.MIN_BINARY_EXPONENT},ln.MIN_BINARY_EXPONENT=-50,v(hn,rn),e(hn.prototype,{insert:function(t,e){var n=rn.getSubnodeIndex(t,hn.origin);if(-1===n)return this.add(e),null;var i=this._subnode[n];if(null===i||!i.getInterval().contains(t)){var r=un.createExpanded(i,t);this._subnode[n]=r}this.insertContained(this._subnode[n],t,e)},isSearchMatch:function(t){return!0},insertContained:function(t,e,n){x.isTrue(t.getInterval().contains(e));(ln.isZeroWidth(e.getMin(),e.getMax())?t.find(e):t.getNode(e)).add(n)},interfaces_:function(){return[]},getClass:function(){return hn}}),hn.origin=0,e(cn.prototype,{size:function(){return null!==this._root?this._root.size():0},insert:function(t,e){this.collectStats(t);var n=cn.ensureExtent(t,this._minExtent);this._root.insert(n,e)},query:function(){if(1===arguments.length){if("number"==typeof arguments[0]){var t=arguments[0];return this.query(new sn(t,t))}if(arguments[0]instanceof sn){var e=arguments[0],n=new P;return this.query(e,n),n}}else if(2===arguments.length){var i=arguments[0],r=arguments[1];this._root.addAllItemsFromOverlapping(i,r)}},iterator:function(){var t=new P;return this._root.addAllItems(t),t.iterator()},remove:function(t,e){var n=cn.ensureExtent(t,this._minExtent);return this._root.remove(n,e)},collectStats:function(t){var e=t.getWidth();e<this._minExtent&&e>0&&(this._minExtent=e)},depth:function(){return null!==this._root?this._root.depth():0},nodeSize:function(){return null!==this._root?this._root.nodeSize():0},interfaces_:function(){return[]},getClass:function(){return cn}}),cn.ensureExtent=function(t,e){var n=t.getMin(),i=t.getMax();return n!==i?t:(n===i&&(i=(n-=e/2)+e/2),new sn(n,i))},e(fn.prototype,{getLineSegment:function(t,e){e.p0=this._pts[t],e.p1=this._pts[t+1]},computeSelect:function(t,e,n,i){var r=this._pts[e],s=this._pts[n];if(n-e==1)return i.select(this,e),null;if(!t.intersects(r,s))return null;var o=Math.trunc((e+n)/2);e<o&&this.computeSelect(t,e,o,i),o<n&&this.computeSelect(t,o,n,i)},getCoordinates:function(){for(var t=new Array(this._end-this._start+1).fill(null),e=0,n=this._start;n<=this._end;n++)t[e++]=this._pts[n];return t},computeOverlaps:function(){if(2===arguments.length){var t=arguments[0],e=arguments[1];this.computeOverlaps(this._start,this._end,t,t._start,t._end,e)}else if(6===arguments.length){var n=arguments[0],i=arguments[1],r=arguments[2],s=arguments[3],o=arguments[4],a=arguments[5];if(i-n==1&&o-s==1)return a.overlap(this,n,r,s),null;if(!this.overlaps(n,i,r,s,o))return null;var u=Math.trunc((n+i)/2),l=Math.trunc((s+o)/2);n<u&&(s<l&&this.computeOverlaps(n,u,r,s,l,a),l<o&&this.computeOverlaps(n,u,r,l,o,a)),u<i&&(s<l&&this.computeOverlaps(u,i,r,s,l,a),l<o&&this.computeOverlaps(u,i,r,l,o,a))}},setId:function(t){this._id=t},select:function(t,e){this.computeSelect(t,this._start,this._end,e)},getEnvelope:function(){if(null===this._env){var t=this._pts[this._start],e=this._pts[this._end];this._env=new M(t,e)}return this._env},overlaps:function(t,e,n,i,r){return M.intersects(this._pts[t],this._pts[e],n._pts[i],n._pts[r])},getEndIndex:function(){return this._end},getStartIndex:function(){return this._start},getContext:function(){return this._context},getId:function(){return this._id},interfaces_:function(){return[]},getClass:function(){return fn}}),e(gn.prototype,{interfaces_:function(){return[]},getClass:function(){return gn}}),gn.isNorthern=function(t){return t===gn.NE||t===gn.NW},gn.isOpposite=function(t,e){return t!==e&&2===(t-e+4)%4},gn.commonHalfPlane=function(t,e){if(t===e)return t;if(2===(t-e+4)%4)return-1;var n=t<e?t:e;return 0===n&&3===(t>e?t:e)?3:n},gn.isInHalfPlane=function(t,e){return e===gn.SE?t===gn.SE||t===gn.SW:t===e||t===e+1},gn.quadrant=function(){if("number"==typeof arguments[0]&&"number"==typeof arguments[1]){var t=arguments[0],e=arguments[1];if(0===t&&0===e)throw new i("Cannot compute the quadrant for point ( "+t+", "+e+" )");return t>=0?e>=0?gn.NE:gn.SE:e>=0?gn.NW:gn.SW}if(arguments[0]instanceof E&&arguments[1]instanceof E){var n=arguments[0],r=arguments[1];if(r.x===n.x&&r.y===n.y)throw new i("Cannot compute the quadrant for two identical points "+n);return r.x>=n.x?r.y>=n.y?gn.NE:gn.SE:r.y>=n.y?gn.NW:gn.SW}},gn.NE=0,gn.NW=1,gn.SW=2,gn.SE=3,e(dn.prototype,{interfaces_:function(){return[]},getClass:function(){return dn}}),dn.getChainStartIndices=function(t){var e=0,n=new P;n.add(new G(e));do{var i=dn.findChainEnd(t,e);n.add(new G(i)),e=i}while(e<t.length-1);return dn.toIntArray(n)},dn.findChainEnd=function(t,e){for(var n=e;n<t.length-1&&t[n].equals2D(t[n+1]);)n++;if(n>=t.length-1)return t.length-1;for(var i=gn.quadrant(t[n],t[n+1]),r=e+1;r<t.length;){if(!t[r-1].equals2D(t[r]))if(gn.quadrant(t[r-1],t[r])!==i)break;r++}return r-1},dn.getChains=function(){if(1===arguments.length){var t=arguments[0];return dn.getChains(t,null)}if(2===arguments.length){for(var e=arguments[0],n=arguments[1],i=new P,r=dn.getChainStartIndices(e),s=0;s<r.length-1;s++){var o=new fn(e,r[s],r[s+1],n);i.add(o)}return i}},dn.toIntArray=function(t){for(var e=new Array(t.size()).fill(null),n=0;n<e.length;n++)e[n]=t.get(n).intValue();return e},e(_n.prototype,{interfaces_:function(){return[]},getClass:function(){return _n}}),_n.orientationIndex=function(t,e,n){var i=e.x-t.x,r=e.y-t.y,s=n.x-e.x,o=n.y-e.y;return _n.signOfDet2x2(i,r,s,o)},_n.signOfDet2x2=function(t,e,n,i){var r=null,s=null,o=null;if(r=1,0===t||0===i)return 0===e||0===n?0:e>0?n>0?-r:r:n>0?r:-r;if(0===e||0===n)return i>0?t>0?r:-r:t>0?-r:r;if(0<e?0<i?e<=i||(r=-r,s=t,t=n,n=s,s=e,e=i,i=s):e<=-i?(r=-r,n=-n,i=-i):(s=t,t=-n,n=s,s=e,e=-i,i=s):0<i?-e<=i?(r=-r,t=-t,e=-e):(s=-t,t=n,n=s,s=-e,e=i,i=s):e>=i?(t=-t,e=-e,n=-n,i=-i):(r=-r,s=-t,t=-n,n=s,s=-e,e=-i,i=s),0<t){if(!(0<n))return r;if(!(t<=n))return r}else{if(0<n)return-r;if(!(t>=n))return-r;r=-r,t=-t,n=-n}for(;;){if(n-=(o=Math.floor(n/t))*t,(i-=o*e)<0)return-r;if(i>e)return r;if(t>n+n){if(e<i+i)return r}else{if(e>i+i)return-r;n=t-n,i=e-i,r=-r}if(0===i)return 0===n?0:-r;if(0===n)return r;if(t-=(o=Math.floor(t/n))*n,(e-=o*i)<0)return r;if(e>i)return-r;if(n>t+t){if(i<e+e)return-r}else{if(i>e+e)return r;t=n-t,e=i-e,r=-r}if(0===e)return 0===t?0:r;if(0===t)return-r}},e(pn.prototype,{isInside:function(t){},interfaces_:function(){return[]},getClass:function(){return pn}}),e(mn.prototype,{testLineSegment:function(t,e){var n,i,r,s,o=e.p0,a=e.p1;n=o.x-t.x,i=o.y-t.y,r=a.x-t.x,s=a.y-t.y,(i>0&&s<=0||s>0&&i<=0)&&0<_n.signOfDet2x2(n,i,r,s)/(s-i)&&this._crossings++},buildIndex:function(){this._tree=new cn;for(var t=nt.removeRepeatedPoints(this._ring.getCoordinates()),e=dn.getChains(t),n=0;n<e.size();n++){var i=e.get(n),r=i.getEnvelope();this._interval.min=r.getMinY(),this._interval.max=r.getMaxY(),this._tree.insert(this._interval,i)}},testMonotoneChain:function(t,e,n){n.select(t,e)},isInside:function(t){this._crossings=0;var e=new M(s.NEGATIVE_INFINITY,s.POSITIVE_INFINITY,t.y,t.y);this._interval.min=t.y,this._interval.max=t.y;for(var n=this._tree.query(this._interval),i=new vn(this,t),r=n.iterator();r.hasNext();){var o=r.next();this.testMonotoneChain(e,i,o)}return this._crossings%2==1},interfaces_:function(){return[pn]},getClass:function(){return mn}}),v(vn,nn),e(vn.prototype,{select:function(){if(1!==arguments.length)return nn.prototype.select.apply(this,arguments);var t=arguments[0];this.mcp.testLineSegment(this.p,t)},interfaces_:function(){return[]},getClass:function(){return vn}}),mn.MCSelecter=vn,e(yn.prototype,{getRadius:function(){return this.compute(),this._radius},getDiameter:function(){switch(this.compute(),this._extremalPts.length){case 0:return this._input.getFactory().createLineString();case 1:return this._input.getFactory().createPoint(this._centre)}var t=this._extremalPts[0],e=this._extremalPts[1];return this._input.getFactory().createLineString([t,e])},getExtremalPoints:function(){return this.compute(),this._extremalPts},computeCirclePoints:function(){if(this._input.isEmpty())return this._extremalPts=new Array(0).fill(null),null;if(1===this._input.getNumPoints()){var t=this._input.getCoordinates();return this._extremalPts=[new E(t[0])],null}var e=this._input.convexHull().getCoordinates();t=e;if(e[0].equals2D(e[e.length-1])&&(t=new Array(e.length-1).fill(null),nt.copyDeep(e,0,t,0,e.length-1)),t.length<=2)return this._extremalPts=nt.copyDeep(t),null;for(var n=yn.lowestPoint(t),i=yn.pointWitMinAngleWithX(t,n),r=0;r<t.length;r++){var s=yn.pointWithMinAngleWithSegment(t,n,i);if(pe.isObtuse(n,s,i))return this._extremalPts=[new E(n),new E(i)],null;if(pe.isObtuse(s,n,i))n=s;else{if(!pe.isObtuse(s,i,n))return this._extremalPts=[new E(n),new E(i),new E(s)],null;i=s}}x.shouldNeverReachHere("Logic failure in Minimum Bounding Circle algorithm!")},compute:function(){if(null!==this._extremalPts)return null;this.computeCirclePoints(),this.computeCentre(),null!==this._centre&&(this._radius=this._centre.distance(this._extremalPts[0]))},getFarthestPoints:function(){switch(this.compute(),this._extremalPts.length){case 0:return this._input.getFactory().createLineString();case 1:return this._input.getFactory().createPoint(this._centre)}var t=this._extremalPts[0],e=this._extremalPts[this._extremalPts.length-1];return this._input.getFactory().createLineString([t,e])},getCircle:function(){if(this.compute(),null===this._centre)return this._input.getFactory().createPolygon();var t=this._input.getFactory().createPoint(this._centre);return 0===this._radius?t:t.buffer(this._radius)},getCentre:function(){return this.compute(),this._centre},computeCentre:function(){switch(this._extremalPts.length){case 0:this._centre=null;break;case 1:this._centre=this._extremalPts[0];break;case 2:this._centre=new E((this._extremalPts[0].x+this._extremalPts[1].x)/2,(this._extremalPts[0].y+this._extremalPts[1].y)/2);break;case 3:this._centre=me.circumcentre(this._extremalPts[0],this._extremalPts[1],this._extremalPts[2])}},interfaces_:function(){return[]},getClass:function(){return yn}}),yn.pointWitMinAngleWithX=function(t,e){for(var n=s.MAX_VALUE,i=null,r=0;r<t.length;r++){var o=t[r];if(o!==e){var a=o.x-e.x,u=o.y-e.y;u<0&&(u=-u);var l=u/Math.sqrt(a*a+u*u);l<n&&(n=l,i=o)}}return i},yn.lowestPoint=function(t){for(var e=t[0],n=1;n<t.length;n++)t[n].y<e.y&&(e=t[n]);return e},yn.pointWithMinAngleWithSegment=function(t,e,n){for(var i=s.MAX_VALUE,r=null,o=0;o<t.length;o++){var a=t[o];if(a!==e&&a!==n){var u=pe.angleBetween(e,a,n);u<i&&(i=u,r=a)}}return r},e(xn.prototype,{getWidthCoordinate:function(){return this.computeMinimumDiameter(),this._minWidthPt},getSupportingSegment:function(){return this.computeMinimumDiameter(),this._inputGeom.getFactory().createLineString([this._minBaseSeg.p0,this._minBaseSeg.p1])},getDiameter:function(){if(this.computeMinimumDiameter(),null===this._minWidthPt)return this._inputGeom.getFactory().createLineString();var t=this._minBaseSeg.project(this._minWidthPt);return this._inputGeom.getFactory().createLineString([t,this._minWidthPt])},computeWidthConvex:function(t){this._convexHullPts=t instanceof Vt?t.getExteriorRing().getCoordinates():t.getCoordinates(),0===this._convexHullPts.length?(this._minWidth=0,this._minWidthPt=null,this._minBaseSeg=null):1===this._convexHullPts.length?(this._minWidth=0,this._minWidthPt=this._convexHullPts[0],this._minBaseSeg.p0=this._convexHullPts[0],this._minBaseSeg.p1=this._convexHullPts[0]):2===this._convexHullPts.length||3===this._convexHullPts.length?(this._minWidth=0,this._minWidthPt=this._convexHullPts[0],this._minBaseSeg.p0=this._convexHullPts[0],this._minBaseSeg.p1=this._convexHullPts[1]):this.computeConvexRingMinDiameter(this._convexHullPts)},computeConvexRingMinDiameter:function(t){this._minWidth=s.MAX_VALUE;for(var e=1,n=new ge,i=0;i<t.length-1;i++)n.p0=t[i],n.p1=t[i+1],e=this.findMaxPerpDistance(t,n,e)},computeMinimumDiameter:function(){if(null!==this._minWidthPt)return null;if(this._isConvex)this.computeWidthConvex(this._inputGeom);else{var t=new Ze(this._inputGeom).getConvexHull();this.computeWidthConvex(t)}},getLength:function(){return this.computeMinimumDiameter(),this._minWidth},findMaxPerpDistance:function(t,e,n){for(var i=e.distancePerpendicular(t[n]),r=i,s=n,o=s;r>=i;)i=r,s=o,o=xn.nextIndex(t,s),r=e.distancePerpendicular(t[o]);return i<this._minWidth&&(this._minPtIndex=s,this._minWidth=i,this._minWidthPt=t[this._minPtIndex],this._minBaseSeg=new ge(e)),s},getMinimumRectangle:function(){if(this.computeMinimumDiameter(),0===this._minWidth)return this._minBaseSeg.p0.equals2D(this._minBaseSeg.p1)?this._inputGeom.getFactory().createPoint(this._minBaseSeg.p0):this._minBaseSeg.toGeometry(this._inputGeom.getFactory());for(var t=this._minBaseSeg.p1.x-this._minBaseSeg.p0.x,e=this._minBaseSeg.p1.y-this._minBaseSeg.p0.y,n=s.MAX_VALUE,i=-s.MAX_VALUE,r=s.MAX_VALUE,o=-s.MAX_VALUE,a=0;a<this._convexHullPts.length;a++){var u=xn.computeC(t,e,this._convexHullPts[a]);u>i&&(i=u),u<n&&(n=u);var l=xn.computeC(-e,t,this._convexHullPts[a]);l>o&&(o=l),l<r&&(r=l)}var h=xn.computeSegmentForLine(-t,-e,o),c=xn.computeSegmentForLine(-t,-e,r),f=xn.computeSegmentForLine(-e,t,i),g=xn.computeSegmentForLine(-e,t,n),d=f.lineIntersection(h),_=g.lineIntersection(h),p=g.lineIntersection(c),m=f.lineIntersection(c),v=this._inputGeom.getFactory().createLinearRing([d,_,p,m,d]);return this._inputGeom.getFactory().createPolygon(v)},interfaces_:function(){return[]},getClass:function(){return xn}}),xn.nextIndex=function(t,e){return++e>=t.length&&(e=0),e},xn.computeC=function(t,e,n){return t*n.y-e*n.x},xn.getMinimumDiameter=function(t){return new xn(t).getDiameter()},xn.getMinimumRectangle=function(t){return new xn(t).getMinimumRectangle()},xn.computeSegmentForLine=function(t,e,n){var i=null,r=null;return Math.abs(e)>Math.abs(t)?(i=new E(0,n/e),r=new E(1,n/e-t/e)):(i=new E(n/t,0),r=new E(n/t-e/t,1)),new ge(i,r)};var En=Object.freeze({Angle:pe,Centroid:Xe,CGAlgorithms:He,ConvexHull:Ze,Distance:X,InteriorPointArea:Je,InteriorPointLine:tn,InteriorPointPoint:en,RobustLineIntersector:fe,MCPointInRing:mn,MinimumBoundingCircle:yn,MinimumDiameter:xn});function In(){this._inputGeom=null,this._factory=null,this._pruneEmptyGeometry=!0,this._preserveGeometryCollectionType=!0,this._preserveCollections=!1,this._preserveType=!1}function Nn(){this._inputGeom=null,this._distanceTolerance=null;var t=arguments[0];this._inputGeom=t}function Cn(){In.apply(this),this.distanceTolerance=null;var t=arguments[0];this.distanceTolerance=t}e(In.prototype,{transformPoint:function(t,e){return this._factory.createPoint(this.transformCoordinates(t.getCoordinateSequence(),t))},transformPolygon:function(t,e){var n=!0,i=this.transformLinearRing(t.getExteriorRing(),t);null!==i&&i instanceof Yt&&!i.isEmpty()||(n=!1);for(var r=new P,s=0;s<t.getNumInteriorRing();s++){var o=this.transformLinearRing(t.getInteriorRingN(s),t);null===o||o.isEmpty()||(o instanceof Yt||(n=!1),r.add(o))}if(n)return this._factory.createPolygon(i,r.toArray([]));var a=new P;return null!==i&&a.add(i),a.addAll(r),this._factory.buildGeometry(a)},createCoordinateSequence:function(t){return this._factory.getCoordinateSequenceFactory().create(t)},getInputGeometry:function(){return this._inputGeom},transformMultiLineString:function(t,e){for(var n=new P,i=0;i<t.getNumGeometries();i++){var r=this.transformLineString(t.getGeometryN(i),t);null!==r&&(r.isEmpty()||n.add(r))}return this._factory.buildGeometry(n)},transformCoordinates:function(t,e){return this.copy(t)},transformLineString:function(t,e){return this._factory.createLineString(this.transformCoordinates(t.getCoordinateSequence(),t))},transformMultiPoint:function(t,e){for(var n=new P,i=0;i<t.getNumGeometries();i++){var r=this.transformPoint(t.getGeometryN(i),t);null!==r&&(r.isEmpty()||n.add(r))}return this._factory.buildGeometry(n)},transformMultiPolygon:function(t,e){for(var n=new P,i=0;i<t.getNumGeometries();i++){var r=this.transformPolygon(t.getGeometryN(i),t);null!==r&&(r.isEmpty()||n.add(r))}return this._factory.buildGeometry(n)},copy:function(t){return t.copy()},transformGeometryCollection:function(t,e){for(var n=new P,i=0;i<t.getNumGeometries();i++){var r=this.transform(t.getGeometryN(i));null!==r&&(this._pruneEmptyGeometry&&r.isEmpty()||n.add(r))}return this._preserveGeometryCollectionType?this._factory.createGeometryCollection(se.toGeometryArray(n)):this._factory.buildGeometry(n)},transform:function(t){if(this._inputGeom=t,this._factory=t.getFactory(),t instanceof Gt)return this.transformPoint(t,null);if(t instanceof zt)return this.transformMultiPoint(t,null);if(t instanceof Yt)return this.transformLinearRing(t,null);if(t instanceof At)return this.transformLineString(t,null);if(t instanceof wt)return this.transformMultiLineString(t,null);if(t instanceof Vt)return this.transformPolygon(t,null);if(t instanceof kt)return this.transformMultiPolygon(t,null);if(t instanceof Lt)return this.transformGeometryCollection(t,null);throw new i("Unknown Geometry subtype: "+t.getClass().getName())},transformLinearRing:function(t,e){var n=this.transformCoordinates(t.getCoordinateSequence(),t);if(null===n)return this._factory.createLinearRing(null);var i=n.size();return i>0&&i<4&&!this._preserveType?this._factory.createLineString(n):this._factory.createLinearRing(n)},interfaces_:function(){return[]},getClass:function(){return In}}),e(Nn.prototype,{getResultGeometry:function(){return new Cn(this._distanceTolerance).transform(this._inputGeom)},setDistanceTolerance:function(t){if(t<=0)throw new i("Tolerance must be positive");this._distanceTolerance=t},interfaces_:function(){return[]},getClass:function(){return Nn}}),Nn.densifyPoints=function(t,e,n){for(var i=new ge,r=new b,s=0;s<t.length-1;s++){i.p0=t[s],i.p1=t[s+1],r.add(i.p0,!1);var o=i.getLength(),a=Math.trunc(o/e)+1;if(a>1)for(var u=o/a,l=1;l<a;l++){var h=l*u/o,c=i.pointAlong(h);n.makePrecise(c),r.add(c,!1)}}return r.add(t[t.length-1],!1),r.toCoordinateArray()},Nn.densify=function(t,e){var n=new Nn(t);return n.setDistanceTolerance(e),n.getResultGeometry()},v(Cn,In),e(Cn.prototype,{transformMultiPolygon:function(t,e){var n=In.prototype.transformMultiPolygon.call(this,t,e);return this.createValidArea(n)},transformPolygon:function(t,e){var n=In.prototype.transformPolygon.call(this,t,e);return e instanceof kt?n:this.createValidArea(n)},transformCoordinates:function(t,e){var n=t.toCoordinateArray(),i=Nn.densifyPoints(n,this.distanceTolerance,e.getPrecisionModel());return e instanceof At&&1===i.length&&(i=new Array(0).fill(null)),this._factory.getCoordinateSequenceFactory().create(i)},createValidArea:function(t){return t.buffer(0)},interfaces_:function(){return[]},getClass:function(){return Cn}}),Nn.DensifyTransformer=Cn;var Sn=Object.freeze({Densifier:Nn});function Ln(){this._orig=null,this._sym=null,this._next=null;var t=arguments[0];this._orig=t}function wn(){this._isMarked=!1;var t=arguments[0];Ln.call(this,t)}function Rn(){this._vertexMap=new ne}function Tn(){this._isStart=!1;var t=arguments[0];wn.call(this,t)}function Pn(){Rn.apply(this)}function On(){this._result=null,this._factory=null,this._graph=null,this._lines=new P,this._nodeEdgeStack=new je,this._ringStartEdge=null,this._graph=new Pn}e(Ln.prototype,{find:function(t){var e=this;do{if(null===e)return null;if(e.dest().equals2D(t))return e;e=e.oNext()}while(e!==this);return null},dest:function(){return this._sym._orig},oNext:function(){return this._sym._next},insert:function(t){if(this.oNext()===this)return this.insertAfter(t),null;var e=this.compareTo(t),n=this;do{var i=n.oNext();if(i.compareTo(t)!==e||i===this)return n.insertAfter(t),null;n=i}while(n!==this);x.shouldNeverReachHere()},insertAfter:function(t){x.equals(this._orig,t.orig());var e=this.oNext();this._sym.setNext(t),t.sym().setNext(e)},degree:function(){var t=0,e=this;do{t++,e=e.oNext()}while(e!==this);return t},equals:function(){if(2===arguments.length&&arguments[1]instanceof E&&arguments[0]instanceof E){var t=arguments[0],e=arguments[1];return this._orig.equals2D(t)&&this._sym._orig.equals(e)}},deltaY:function(){return this._sym._orig.y-this._orig.y},sym:function(){return this._sym},prev:function(){return this._sym.next()._sym},compareAngularDirection:function(t){var e=this.deltaX(),n=this.deltaY(),i=t.deltaX(),r=t.deltaY();if(e===i&&n===r)return 0;var s=gn.quadrant(e,n),o=gn.quadrant(i,r);return s>o?1:s<o?-1:z.index(t._orig,t.dest(),this.dest())},prevNode:function(){for(var t=this;2===t.degree();)if((t=t.prev())===this)return null;return t},compareTo:function(t){var e=t;return this.compareAngularDirection(e)},next:function(){return this._next},setSym:function(t){this._sym=t},orig:function(){return this._orig},toString:function(){return"HE("+this._orig.x+" "+this._orig.y+", "+this._sym._orig.x+" "+this._sym._orig.y+")"},setNext:function(t){this._next=t},init:function(t){this.setSym(t),t.setSym(this),this.setNext(t),t.setNext(this)},deltaX:function(){return this._sym._orig.x-this._orig.x},interfaces_:function(){return[]},getClass:function(){return Ln}}),Ln.init=function(t,e){if(null!==t._sym||null!==e._sym||null!==t._next||null!==e._next)throw new IllegalStateException("Edges are already initialized");return t.init(e),t},Ln.create=function(t,e){var n=new Ln(t),i=new Ln(e);return n.init(i),n},v(wn,Ln),e(wn.prototype,{mark:function(){this._isMarked=!0},setMark:function(t){this._isMarked=t},isMarked:function(){return this._isMarked},interfaces_:function(){return[]},getClass:function(){return wn}}),wn.setMarkBoth=function(t,e){t.setMark(e),t.sym().setMark(e)},wn.isMarked=function(t){return t.isMarked()},wn.setMark=function(t,e){t.setMark(e)},wn.markBoth=function(t){t.mark(),t.sym().mark()},wn.mark=function(t){t.mark()},e(Rn.prototype,{insert:function(t,e,n){var i=this.create(t,e);null!==n?n.insert(i):this._vertexMap.put(t,i);var r=this._vertexMap.get(e);return null!==r?r.insert(i.sym()):this._vertexMap.put(e,i.sym()),i},create:function(t,e){var n=this.createEdge(t),i=this.createEdge(e);return Ln.init(n,i),n},createEdge:function(t){return new Ln(t)},addEdge:function(t,e){if(!Rn.isValidEdge(t,e))return null;var n=this._vertexMap.get(t),i=null;return null!==n&&(i=n.find(e)),null!==i?i:this.insert(t,e,n)},getVertexEdges:function(){return this._vertexMap.values()},findEdge:function(t,e){var n=this._vertexMap.get(t);return null===n?null:n.find(e)},interfaces_:function(){return[]},getClass:function(){return Rn}}),Rn.isValidEdge=function(t,e){return 0!==e.compareTo(t)},v(Tn,wn),e(Tn.prototype,{setStart:function(){this._isStart=!0},isStart:function(){return this._isStart},interfaces_:function(){return[]},getClass:function(){return Tn}}),v(Pn,Rn),e(Pn.prototype,{createEdge:function(t){return new Tn(t)},interfaces_:function(){return[]},getClass:function(){return Pn}}),e(On.prototype,{addLine:function(t){this._lines.add(this._factory.createLineString(t.toCoordinateArray()))},updateRingStartEdge:function(t){return t.isStart()||(t=t.sym()).isStart()?null===this._ringStartEdge?(this._ringStartEdge=t,null):void(t.orig().compareTo(this._ringStartEdge.orig())<0&&(this._ringStartEdge=t)):null},getResult:function(){return null===this._result&&this.computeResult(),this._result},process:function(t){var e=t.prevNode();null===e&&(e=t),this.stackEdges(e),this.buildLines()},buildRing:function(t){var e=new b,n=t;for(e.add(n.orig().copy(),!1);2===n.sym().degree();){var i=n.next();if(i===t)break;e.add(i.orig().copy(),!1),n=i}e.add(n.dest().copy(),!1),this.addLine(e)},buildLine:function(t){var e=new b,n=t;for(this._ringStartEdge=null,wn.markBoth(n),e.add(n.orig().copy(),!1);2===n.sym().degree();){this.updateRingStartEdge(n);var i=n.next();if(i===t)return this.buildRing(this._ringStartEdge),null;e.add(i.orig().copy(),!1),n=i,wn.markBoth(n)}e.add(n.dest().clone(),!1),this.stackEdges(n.sym()),this.addLine(e)},stackEdges:function(t){var e=t;do{wn.isMarked(e)||this._nodeEdgeStack.add(e),e=e.oNext()}while(e!==t)},computeResult:function(){for(var t=this._graph.getVertexEdges().iterator();t.hasNext();){var e=t.next();wn.isMarked(e)||this.process(e)}this._result=this._factory.buildGeometry(this._lines)},buildLines:function(){for(;!this._nodeEdgeStack.empty();){var t=this._nodeEdgeStack.pop();wn.isMarked(t)||this.buildLine(t)}},add:function(){if(arguments[0]instanceof K)arguments[0].apply({interfaces_:function(){return[j]},filter:function(t){t instanceof At&&this.add(t)}});else if(N(arguments[0],S))for(var t=arguments[0].iterator();t.hasNext();){var e=t.next();this.add(e)}else if(arguments[0]instanceof At){var n=arguments[0];null===this._factory&&(this._factory=n.getFactory());var i=n.getCoordinateSequence(),r=!1;for(t=1;t<i.size();t++){var s=this._graph.addEdge(i.getCoordinate(t-1),i.getCoordinate(t));null!==s&&(r||(s.setStart(),r=!0))}}},interfaces_:function(){return[]},getClass:function(){return On}}),On.dissolve=function(t){var e=new On;return e.add(t),e.getResult()};var bn=Object.freeze({LineDissolver:On});function Mn(){if(this._boundaryRule=Q.OGC_SFS_BOUNDARY_RULE,this._isIn=null,this._numBoundaries=null,0===arguments.length);else if(1===arguments.length){var t=arguments[0];if(null===t)throw new i("Rule must be non-null");this._boundaryRule=t}}function Dn(){}function An(){this.mce=null,this.chainIndex=null;var t=arguments[0],e=arguments[1];this.mce=t,this.chainIndex=e}function Fn(){if(this._label=null,this._xValue=null,this._eventType=null,this._insertEvent=null,this._deleteEventIndex=null,this._obj=null,2===arguments.length){var t=arguments[0],e=arguments[1];this._eventType=Fn.DELETE,this._xValue=t,this._insertEvent=e}else if(3===arguments.length){var n=arguments[0],i=arguments[1],r=arguments[2];this._eventType=Fn.INSERT,this._label=n,this._xValue=i,this._obj=r}}function Gn(){}function qn(){this._hasIntersection=!1,this._hasProper=!1,this._hasProperInterior=!1,this._properIntersectionPoint=null,this._li=null,this._includeProper=null,this._recordIsolated=null,this._isSelfIntersection=null,this._numIntersections=0,this.numTests=0,this._bdyNodes=null,this._isDone=!1,this._isDoneWhenProperInt=!1;var t=arguments[0],e=arguments[1],n=arguments[2];this._li=t,this._includeProper=e,this._recordIsolated=n}function Bn(){Gn.apply(this),this.events=new P,this.nOverlaps=null}function Vn(){if(this.location=null,1===arguments.length){if(arguments[0]instanceof Array){var t=arguments[0];this.init(t.length)}else if(Number.isInteger(arguments[0])){var e=arguments[0];this.init(1),this.location[Dn.ON]=e}else if(arguments[0]instanceof Vn){var n=arguments[0];if(this.init(n.location.length),null!==n)for(var i=0;i<this.location.length;i++)this.location[i]=n.location[i]}}else if(3===arguments.length){var r=arguments[0],s=arguments[1],o=arguments[2];this.init(3),this.location[Dn.ON]=r,this.location[Dn.LEFT]=s,this.location[Dn.RIGHT]=o}}function zn(){if(this.elt=new Array(2).fill(null),1===arguments.length){if(Number.isInteger(arguments[0])){var t=arguments[0];this.elt[0]=new Vn(t),this.elt[1]=new Vn(t)}else if(arguments[0]instanceof zn){var e=arguments[0];this.elt[0]=new Vn(e.elt[0]),this.elt[1]=new Vn(e.elt[1])}}else if(2===arguments.length){var n=arguments[0],i=arguments[1];this.elt[0]=new Vn(de.NONE),this.elt[1]=new Vn(de.NONE),this.elt[n].setLocation(i)}else if(3===arguments.length){var r=arguments[0],s=arguments[1],o=arguments[2];this.elt[0]=new Vn(r,s,o),this.elt[1]=new Vn(r,s,o)}else if(4===arguments.length){var a=arguments[0],u=arguments[1],l=arguments[2],h=arguments[3];this.elt[0]=new Vn(de.NONE,de.NONE,de.NONE),this.elt[1]=new Vn(de.NONE,de.NONE,de.NONE),this.elt[a].setLocations(u,l,h)}}function Yn(){this.coord=null,this.segmentIndex=null,this.dist=null;var t=arguments[0],e=arguments[1],n=arguments[2];this.coord=new E(t),this.segmentIndex=e,this.dist=n}function kn(){this._nodeMap=new pt,this.edge=null;var t=arguments[0];this.edge=t}function Un(){}function Xn(){this.e=null,this.pts=null,this.startIndex=null;var t=arguments[0];this.e=t,this.pts=t.getCoordinates();var e=new Un;this.startIndex=e.getChainStartIndices(this.pts)}function Hn(){this._depth=Array(2).fill().map(function(){return Array(3)});for(var t=0;t<2;t++)for(var e=0;e<3;e++)this._depth[t][e]=Hn.NULL_VALUE}function Wn(){if(this._label=null,this._isInResult=!1,this._isCovered=!1,this._isCoveredSet=!1,this._isVisited=!1,0===arguments.length);else if(1===arguments.length){var t=arguments[0];this._label=t}}function jn(){if(Wn.apply(this),this.pts=null,this._env=null,this.eiList=new kn(this),this._name=null,this._mce=null,this._isIsolated=!0,this._depth=new Hn,this._depthDelta=0,1===arguments.length){var t=arguments[0];jn.call(this,t,null)}else if(2===arguments.length){var e=arguments[0],n=arguments[1];this.pts=e,this._label=n}}function Kn(){Wn.apply(this),this._coord=null,this._edges=null;var t=arguments[0],e=arguments[1];this._coord=t,this._edges=e,this._label=new zn(0,de.NONE)}function Zn(){this.nodeMap=new pt,this.nodeFact=null;var t=arguments[0];this.nodeFact=t}function Qn(){if(this._edge=null,this._label=null,this._node=null,this._p0=null,this._p1=null,this._dx=null,this._dy=null,this._quadrant=null,1===arguments.length){var t=arguments[0];this._edge=t}else if(3===arguments.length){var e=arguments[0],n=arguments[1],i=arguments[2];Qn.call(this,e,n,i,null)}else if(4===arguments.length){var r=arguments[0],s=arguments[1],o=arguments[2],a=arguments[3];Qn.call(this,r),this.init(s,o),this._label=a}}function Jn(){if(this.pt=null,1===arguments.length){var t=arguments[0];m.call(this,t)}else if(2===arguments.length){var e=arguments[0],n=arguments[1];m.call(this,Jn.msgWithCoord(e,n)),this.name="TopologyException",this.pt=new E(n)}}function $n(){this._isForward=null,this._isInResult=!1,this._isVisited=!1,this._sym=null,this._next=null,this._nextMin=null,this._edgeRing=null,this._minEdgeRing=null,this._depth=[0,-999,-999];var t=arguments[0],e=arguments[1];if(Qn.call(this,t),this._isForward=e,e)this.init(t.getCoordinate(0),t.getCoordinate(1));else{var n=t.getNumPoints()-1;this.init(t.getCoordinate(n),t.getCoordinate(n-1))}this.computeDirectedLabel()}function ti(){}function ei(){if(this._edges=new P,this._nodes=null,this._edgeEndList=new P,0===arguments.length)this._nodes=new Zn(new ti);else if(1===arguments.length){var t=arguments[0];this._nodes=new Zn(t)}}function ni(){if(ei.apply(this),this._parentGeom=null,this._lineEdgeMap=new ne,this._boundaryNodeRule=null,this._useBoundaryDeterminationRule=!0,this._argIndex=null,this._boundaryNodes=null,this._hasTooFewPoints=!1,this._invalidPoint=null,this._areaPtLocator=null,this._ptLocator=new Mn,2===arguments.length){var t=arguments[0],e=arguments[1];ni.call(this,t,e,Q.OGC_SFS_BOUNDARY_RULE)}else if(3===arguments.length){var n=arguments[0],i=arguments[1],r=arguments[2];this._argIndex=n,this._parentGeom=i,this._boundaryNodeRule=r,null!==i&&this.add(i)}}e(Mn.prototype,{locateInPolygonRing:function(t,e){return e.getEnvelopeInternal().intersects(t)?qe.locateInRing(t,e.getCoordinates()):de.EXTERIOR},intersects:function(t,e){return this.locate(t,e)!==de.EXTERIOR},updateLocationInfo:function(t){t===de.INTERIOR&&(this._isIn=!0),t===de.BOUNDARY&&this._numBoundaries++},computeLocation:function(t,e){if(e instanceof Gt&&this.updateLocationInfo(this.locateOnPoint(t,e)),e instanceof At)this.updateLocationInfo(this.locateOnLineString(t,e));else if(e instanceof Vt)this.updateLocationInfo(this.locateInPolygon(t,e));else if(e instanceof wt)for(var n=e,i=0;i<n.getNumGeometries();i++){var r=n.getGeometryN(i);this.updateLocationInfo(this.locateOnLineString(t,r))}else if(e instanceof kt){var s=e;for(i=0;i<s.getNumGeometries();i++){var o=s.getGeometryN(i);this.updateLocationInfo(this.locateInPolygon(t,o))}}else if(e instanceof Lt)for(var a=new Be(e);a.hasNext();){var u=a.next();u!==e&&this.computeLocation(t,u)}},locateOnPoint:function(t,e){return e.getCoordinate().equals2D(t)?de.INTERIOR:de.EXTERIOR},locateOnLineString:function(t,e){if(!e.getEnvelopeInternal().intersects(t))return de.EXTERIOR;var n=e.getCoordinateSequence();return e.isClosed()||!t.equals(n.getCoordinate(0))&&!t.equals(n.getCoordinate(n.size()-1))?qe.isOnLine(t,n)?de.INTERIOR:de.EXTERIOR:de.BOUNDARY},locateInPolygon:function(t,e){if(e.isEmpty())return de.EXTERIOR;var n=e.getExteriorRing(),i=this.locateInPolygonRing(t,n);if(i===de.EXTERIOR)return de.EXTERIOR;if(i===de.BOUNDARY)return de.BOUNDARY;for(var r=0;r<e.getNumInteriorRing();r++){var s=e.getInteriorRingN(r),o=this.locateInPolygonRing(t,s);if(o===de.INTERIOR)return de.EXTERIOR;if(o===de.BOUNDARY)return de.BOUNDARY}return de.INTERIOR},locate:function(t,e){return e.isEmpty()?de.EXTERIOR:e instanceof At?this.locateOnLineString(t,e):e instanceof Vt?this.locateInPolygon(t,e):(this._isIn=!1,this._numBoundaries=0,this.computeLocation(t,e),this._boundaryRule.isInBoundary(this._numBoundaries)?de.BOUNDARY:this._numBoundaries>0||this._isIn?de.INTERIOR:de.EXTERIOR)},interfaces_:function(){return[]},getClass:function(){return Mn}}),e(Dn.prototype,{interfaces_:function(){return[]},getClass:function(){return Dn}}),Dn.opposite=function(t){return t===Dn.LEFT?Dn.RIGHT:t===Dn.RIGHT?Dn.LEFT:t},Dn.ON=0,Dn.LEFT=1,Dn.RIGHT=2,e(An.prototype,{computeIntersections:function(t,e){this.mce.computeIntersectsForChain(this.chainIndex,t.mce,t.chainIndex,e)},interfaces_:function(){return[]},getClass:function(){return An}}),e(Fn.prototype,{isDelete:function(){return this._eventType===Fn.DELETE},setDeleteEventIndex:function(t){this._deleteEventIndex=t},getObject:function(){return this._obj},compareTo:function(t){var e=t;return this._xValue<e._xValue?-1:this._xValue>e._xValue?1:this._eventType<e._eventType?-1:this._eventType>e._eventType?1:0},getInsertEvent:function(){return this._insertEvent},isInsert:function(){return this._eventType===Fn.INSERT},isSameLabel:function(t){return null!==this._label&&this._label===t._label},getDeleteEventIndex:function(){return this._deleteEventIndex},interfaces_:function(){return[g]},getClass:function(){return Fn}}),Fn.INSERT=1,Fn.DELETE=2,e(Gn.prototype,{interfaces_:function(){return[]},getClass:function(){return Gn}}),e(qn.prototype,{isTrivialIntersection:function(t,e,n,i){if(t===n&&1===this._li.getIntersectionNum()){if(qn.isAdjacentSegments(e,i))return!0;if(t.isClosed()){var r=t.getNumPoints()-1;if(0===e&&i===r||0===i&&e===r)return!0}}return!1},getProperIntersectionPoint:function(){return this._properIntersectionPoint},setIsDoneIfProperInt:function(t){this._isDoneWhenProperInt=t},hasProperInteriorIntersection:function(){return this._hasProperInterior},isBoundaryPointInternal:function(t,e){for(var n=e.iterator();n.hasNext();){var i=n.next().getCoordinate();if(t.isIntersection(i))return!0}return!1},hasProperIntersection:function(){return this._hasProper},hasIntersection:function(){return this._hasIntersection},isDone:function(){return this._isDone},isBoundaryPoint:function(t,e){return null!==e&&(!!this.isBoundaryPointInternal(t,e[0])||!!this.isBoundaryPointInternal(t,e[1]))},setBoundaryNodes:function(t,e){this._bdyNodes=new Array(2).fill(null),this._bdyNodes[0]=t,this._bdyNodes[1]=e},addIntersections:function(t,e,n,i){if(t===n&&e===i)return null;this.numTests++;var r=t.getCoordinates()[e],s=t.getCoordinates()[e+1],o=n.getCoordinates()[i],a=n.getCoordinates()[i+1];this._li.computeIntersection(r,s,o,a),this._li.hasIntersection()&&(this._recordIsolated&&(t.setIsolated(!1),n.setIsolated(!1)),this._numIntersections++,this.isTrivialIntersection(t,e,n,i)||(this._hasIntersection=!0,!this._includeProper&&this._li.isProper()||(t.addIntersections(this._li,e,0),n.addIntersections(this._li,i,1)),this._li.isProper()&&(this._properIntersectionPoint=this._li.getIntersection(0).copy(),this._hasProper=!0,this._isDoneWhenProperInt&&(this._isDone=!0),this.isBoundaryPoint(this._li,this._bdyNodes)||(this._hasProperInterior=!0))))},interfaces_:function(){return[]},getClass:function(){return qn}}),qn.isAdjacentSegments=function(t,e){return 1===Math.abs(t-e)},v(Bn,Gn),e(Bn.prototype,{prepareEvents:function(){Te.sort(this.events);for(var t=0;t<this.events.size();t++){var e=this.events.get(t);e.isDelete()&&e.getInsertEvent().setDeleteEventIndex(t)}},computeIntersections:function(){if(1===arguments.length){var t=arguments[0];this.nOverlaps=0,this.prepareEvents();for(var e=0;e<this.events.size();e++){var n=this.events.get(e);if(n.isInsert()&&this.processOverlaps(e,n.getDeleteEventIndex(),n,t),t.isDone())break}}else if(3===arguments.length)if(arguments[2]instanceof qn&&N(arguments[0],w)&&N(arguments[1],w)){var i=arguments[0],r=arguments[1],s=arguments[2];this.addEdges(i,i),this.addEdges(r,r),this.computeIntersections(s)}else if("boolean"==typeof arguments[2]&&N(arguments[0],w)&&arguments[1]instanceof qn){var o=arguments[0],a=arguments[1];arguments[2]?this.addEdges(o,null):this.addEdges(o),this.computeIntersections(a)}},addEdge:function(t,e){for(var n=t.getMonotoneChainEdge(),i=n.getStartIndexes(),r=0;r<i.length-1;r++){var s=new An(n,r),o=new Fn(e,n.getMinX(r),s);this.events.add(o),this.events.add(new Fn(n.getMaxX(r),o))}},processOverlaps:function(t,e,n,i){for(var r=n.getObject(),s=t;s<e;s++){var o=this.events.get(s);if(o.isInsert()){var a=o.getObject();n.isSameLabel(o)||(r.computeIntersections(a,i),this.nOverlaps++)}}},addEdges:function(){if(1===arguments.length)for(var t=arguments[0].iterator();t.hasNext();){var e=t.next();this.addEdge(e,e)}else if(2===arguments.length){var n=arguments[0],i=arguments[1];for(t=n.iterator();t.hasNext();){e=t.next();this.addEdge(e,i)}}},interfaces_:function(){return[]},getClass:function(){return Bn}}),e(Vn.prototype,{setAllLocations:function(t){for(var e=0;e<this.location.length;e++)this.location[e]=t},isNull:function(){for(var t=0;t<this.location.length;t++)if(this.location[t]!==de.NONE)return!1;return!0},setAllLocationsIfNull:function(t){for(var e=0;e<this.location.length;e++)this.location[e]===de.NONE&&(this.location[e]=t)},isLine:function(){return 1===this.location.length},merge:function(t){if(t.location.length>this.location.length){var e=new Array(3).fill(null);e[Dn.ON]=this.location[Dn.ON],e[Dn.LEFT]=de.NONE,e[Dn.RIGHT]=de.NONE,this.location=e}for(var n=0;n<this.location.length;n++)this.location[n]===de.NONE&&n<t.location.length&&(this.location[n]=t.location[n])},getLocations:function(){return this.location},flip:function(){if(this.location.length<=1)return null;var t=this.location[Dn.LEFT];this.location[Dn.LEFT]=this.location[Dn.RIGHT],this.location[Dn.RIGHT]=t},toString:function(){var t=new F;return this.location.length>1&&t.append(de.toLocationSymbol(this.location[Dn.LEFT])),t.append(de.toLocationSymbol(this.location[Dn.ON])),this.location.length>1&&t.append(de.toLocationSymbol(this.location[Dn.RIGHT])),t.toString()},setLocations:function(t,e,n){this.location[Dn.ON]=t,this.location[Dn.LEFT]=e,this.location[Dn.RIGHT]=n},get:function(t){return t<this.location.length?this.location[t]:de.NONE},isArea:function(){return this.location.length>1},isAnyNull:function(){for(var t=0;t<this.location.length;t++)if(this.location[t]===de.NONE)return!0;return!1},setLocation:function(){if(1===arguments.length){var t=arguments[0];this.setLocation(Dn.ON,t)}else if(2===arguments.length){var e=arguments[0],n=arguments[1];this.location[e]=n}},init:function(t){this.location=new Array(t).fill(null),this.setAllLocations(de.NONE)},isEqualOnSide:function(t,e){return this.location[e]===t.location[e]},allPositionsEqual:function(t){for(var e=0;e<this.location.length;e++)if(this.location[e]!==t)return!1;return!0},interfaces_:function(){return[]},getClass:function(){return Vn}}),e(zn.prototype,{getGeometryCount:function(){var t=0;return this.elt[0].isNull()||t++,this.elt[1].isNull()||t++,t},setAllLocations:function(t,e){this.elt[t].setAllLocations(e)},isNull:function(t){return this.elt[t].isNull()},setAllLocationsIfNull:function(){if(1===arguments.length){var t=arguments[0];this.setAllLocationsIfNull(0,t),this.setAllLocationsIfNull(1,t)}else if(2===arguments.length){var e=arguments[0],n=arguments[1];this.elt[e].setAllLocationsIfNull(n)}},isLine:function(t){return this.elt[t].isLine()},merge:function(t){for(var e=0;e<2;e++)null===this.elt[e]&&null!==t.elt[e]?this.elt[e]=new Vn(t.elt[e]):this.elt[e].merge(t.elt[e])},flip:function(){this.elt[0].flip(),this.elt[1].flip()},getLocation:function(){if(1===arguments.length){var t=arguments[0];return this.elt[t].get(Dn.ON)}if(2===arguments.length){var e=arguments[0],n=arguments[1];return this.elt[e].get(n)}},toString:function(){var t=new F;return null!==this.elt[0]&&(t.append("A:"),t.append(this.elt[0].toString())),null!==this.elt[1]&&(t.append(" B:"),t.append(this.elt[1].toString())),t.toString()},isArea:function(){if(0===arguments.length)return this.elt[0].isArea()||this.elt[1].isArea();if(1===arguments.length){var t=arguments[0];return this.elt[t].isArea()}},isAnyNull:function(t){return this.elt[t].isAnyNull()},setLocation:function(){if(2===arguments.length){var t=arguments[0],e=arguments[1];this.elt[t].setLocation(Dn.ON,e)}else if(3===arguments.length){var n=arguments[0],i=arguments[1],r=arguments[2];this.elt[n].setLocation(i,r)}},isEqualOnSide:function(t,e){return this.elt[0].isEqualOnSide(t.elt[0],e)&&this.elt[1].isEqualOnSide(t.elt[1],e)},allPositionsEqual:function(t,e){return this.elt[t].allPositionsEqual(e)},toLine:function(t){this.elt[t].isArea()&&(this.elt[t]=new Vn(this.elt[t].location[0]))},interfaces_:function(){return[]},getClass:function(){return zn}}),zn.toLineLabel=function(t){for(var e=new zn(de.NONE),n=0;n<2;n++)e.setLocation(n,t.getLocation(n));return e},e(Yn.prototype,{getSegmentIndex:function(){return this.segmentIndex},getCoordinate:function(){return this.coord},print:function(t){t.print(this.coord),t.print(" seg # = "+this.segmentIndex),t.println(" dist = "+this.dist)},compareTo:function(t){var e=t;return this.compare(e.segmentIndex,e.dist)},isEndPoint:function(t){return 0===this.segmentIndex&&0===this.dist||this.segmentIndex===t},toString:function(){return this.coord+" seg # = "+this.segmentIndex+" dist = "+this.dist},getDistance:function(){return this.dist},compare:function(t,e){return this.segmentIndex<t?-1:this.segmentIndex>t?1:this.dist<e?-1:this.dist>e?1:0},interfaces_:function(){return[g]},getClass:function(){return Yn}}),e(kn.prototype,{print:function(t){t.println("Intersections:");for(var e=this.iterator();e.hasNext();){e.next().print(t)}},iterator:function(){return this._nodeMap.values().iterator()},addSplitEdges:function(t){this.addEndpoints();for(var e=this.iterator(),n=e.next();e.hasNext();){var i=e.next(),r=this.createSplitEdge(n,i);t.add(r),n=i}},addEndpoints:function(){var t=this.edge.pts.length-1;this.add(this.edge.pts[0],0,0),this.add(this.edge.pts[t],t,0)},createSplitEdge:function(t,e){var n=e.segmentIndex-t.segmentIndex+2,i=this.edge.pts[e.segmentIndex],r=e.dist>0||!e.coord.equals2D(i);r||n--;var s=new Array(n).fill(null),o=0;s[o++]=new E(t.coord);for(var a=t.segmentIndex+1;a<=e.segmentIndex;a++)s[o++]=this.edge.pts[a];return r&&(s[o]=e.coord),new jn(s,new zn(this.edge._label))},add:function(t,e,n){var i=new Yn(t,e,n),r=this._nodeMap.get(i);return null!==r?r:(this._nodeMap.put(i,i),i)},isIntersection:function(t){for(var e=this.iterator();e.hasNext();){if(e.next().coord.equals(t))return!0}return!1},interfaces_:function(){return[]},getClass:function(){return kn}}),e(Un.prototype,{getChainStartIndices:function(t){var e=0,n=new P;n.add(new G(e));do{var i=this.findChainEnd(t,e);n.add(new G(i)),e=i}while(e<t.length-1);return Un.toIntArray(n)},findChainEnd:function(t,e){for(var n=gn.quadrant(t[e],t[e+1]),i=e+1;i<t.length;){if(gn.quadrant(t[i-1],t[i])!==n)break;i++}return i-1},interfaces_:function(){return[]},getClass:function(){return Un}}),Un.toIntArray=function(t){for(var e=new Array(t.size()).fill(null),n=0;n<e.length;n++)e[n]=t.get(n).intValue();return e},e(Xn.prototype,{getCoordinates:function(){return this.pts},getMaxX:function(t){var e=this.pts[this.startIndex[t]].x,n=this.pts[this.startIndex[t+1]].x;return e>n?e:n},getMinX:function(t){var e=this.pts[this.startIndex[t]].x,n=this.pts[this.startIndex[t+1]].x;return e<n?e:n},computeIntersectsForChain:function(){if(4===arguments.length){var t=arguments[0],e=arguments[1],n=arguments[2],i=arguments[3];this.computeIntersectsForChain(this.startIndex[t],this.startIndex[t+1],e,e.startIndex[n],e.startIndex[n+1],i)}else if(6===arguments.length){var r=arguments[0],s=arguments[1],o=arguments[2],a=arguments[3],u=arguments[4],l=arguments[5];if(s-r==1&&u-a==1)return l.addIntersections(this.e,r,o.e,a),null;if(!this.overlaps(r,s,o,a,u))return null;var h=Math.trunc((r+s)/2),c=Math.trunc((a+u)/2);r<h&&(a<c&&this.computeIntersectsForChain(r,h,o,a,c,l),c<u&&this.computeIntersectsForChain(r,h,o,c,u,l)),h<s&&(a<c&&this.computeIntersectsForChain(h,s,o,a,c,l),c<u&&this.computeIntersectsForChain(h,s,o,c,u,l))}},overlaps:function(t,e,n,i,r){return M.intersects(this.pts[t],this.pts[e],n.pts[i],n.pts[r])},getStartIndexes:function(){return this.startIndex},computeIntersects:function(t,e){for(var n=0;n<this.startIndex.length-1;n++)for(var i=0;i<t.startIndex.length-1;i++)this.computeIntersectsForChain(n,t,i,e)},interfaces_:function(){return[]},getClass:function(){return Xn}}),e(Hn.prototype,{getDepth:function(t,e){return this._depth[t][e]},setDepth:function(t,e,n){this._depth[t][e]=n},isNull:function(){if(0===arguments.length){for(var t=0;t<2;t++)for(var e=0;e<3;e++)if(this._depth[t][e]!==Hn.NULL_VALUE)return!1;return!0}if(1===arguments.length){var n=arguments[0];return this._depth[n][1]===Hn.NULL_VALUE}if(2===arguments.length){var i=arguments[0],r=arguments[1];return this._depth[i][r]===Hn.NULL_VALUE}},normalize:function(){for(var t=0;t<2;t++)if(!this.isNull(t)){var e=this._depth[t][1];this._depth[t][2]<e&&(e=this._depth[t][2]),e<0&&(e=0);for(var n=1;n<3;n++){var i=0;this._depth[t][n]>e&&(i=1),this._depth[t][n]=i}}},getDelta:function(t){return this._depth[t][Dn.RIGHT]-this._depth[t][Dn.LEFT]},getLocation:function(t,e){return this._depth[t][e]<=0?de.EXTERIOR:de.INTERIOR},toString:function(){return"A: "+this._depth[0][1]+","+this._depth[0][2]+" B: "+this._depth[1][1]+","+this._depth[1][2]},add:function(){if(1===arguments.length)for(var t=arguments[0],e=0;e<2;e++)for(var n=1;n<3;n++){var i=t.getLocation(e,n);i!==de.EXTERIOR&&i!==de.INTERIOR||(this.isNull(e,n)?this._depth[e][n]=Hn.depthAtLocation(i):this._depth[e][n]+=Hn.depthAtLocation(i))}else if(3===arguments.length){var r=arguments[0],s=arguments[1];arguments[2]===de.INTERIOR&&this._depth[r][s]++}},interfaces_:function(){return[]},getClass:function(){return Hn}}),Hn.depthAtLocation=function(t){return t===de.EXTERIOR?0:t===de.INTERIOR?1:Hn.NULL_VALUE},Hn.NULL_VALUE=-1,e(Wn.prototype,{setVisited:function(t){this._isVisited=t},setInResult:function(t){this._isInResult=t},isCovered:function(){return this._isCovered},isCoveredSet:function(){return this._isCoveredSet},setLabel:function(t){this._label=t},getLabel:function(){return this._label},setCovered:function(t){this._isCovered=t,this._isCoveredSet=!0},updateIM:function(t){x.isTrue(this._label.getGeometryCount()>=2,"found partial label"),this.computeIM(t)},isInResult:function(){return this._isInResult},isVisited:function(){return this._isVisited},interfaces_:function(){return[]},getClass:function(){return Wn}}),v(jn,Wn),e(jn.prototype,{getDepth:function(){return this._depth},getCollapsedEdge:function(){var t=new Array(2).fill(null);return t[0]=this.pts[0],t[1]=this.pts[1],new jn(t,zn.toLineLabel(this._label))},isIsolated:function(){return this._isIsolated},getCoordinates:function(){return this.pts},setIsolated:function(t){this._isIsolated=t},setName:function(t){this._name=t},equals:function(t){if(!(t instanceof jn))return!1;var e=t;if(this.pts.length!==e.pts.length)return!1;for(var n=!0,i=!0,r=this.pts.length,s=0;s<this.pts.length;s++)if(this.pts[s].equals2D(e.pts[s])||(n=!1),this.pts[s].equals2D(e.pts[--r])||(i=!1),!n&&!i)return!1;return!0},getCoordinate:function(){if(0===arguments.length)return this.pts.length>0?this.pts[0]:null;if(1===arguments.length){var t=arguments[0];return this.pts[t]}},print:function(t){t.print("edge "+this._name+": "),t.print("LINESTRING (");for(var e=0;e<this.pts.length;e++)e>0&&t.print(","),t.print(this.pts[e].x+" "+this.pts[e].y);t.print(")  "+this._label+" "+this._depthDelta)},computeIM:function(t){jn.updateIM(this._label,t)},isCollapsed:function(){return!!this._label.isArea()&&(3===this.pts.length&&!!this.pts[0].equals(this.pts[2]))},isClosed:function(){return this.pts[0].equals(this.pts[this.pts.length-1])},getMaximumSegmentIndex:function(){return this.pts.length-1},getDepthDelta:function(){return this._depthDelta},getNumPoints:function(){return this.pts.length},printReverse:function(t){t.print("edge "+this._name+": ");for(var e=this.pts.length-1;e>=0;e--)t.print(this.pts[e]+" ");t.println("")},getMonotoneChainEdge:function(){return null===this._mce&&(this._mce=new Xn(this)),this._mce},getEnvelope:function(){if(null===this._env){this._env=new M;for(var t=0;t<this.pts.length;t++)this._env.expandToInclude(this.pts[t])}return this._env},addIntersection:function(t,e,n,i){var r=new E(t.getIntersection(i)),s=e,o=t.getEdgeDistance(n,i),a=s+1;if(a<this.pts.length){var u=this.pts[a];r.equals2D(u)&&(s=a,o=0)}this.eiList.add(r,s,o)},toString:function(){var t=new Mt;t.append("edge "+this._name+": "),t.append("LINESTRING (");for(var e=0;e<this.pts.length;e++)e>0&&t.append(","),t.append(this.pts[e].x+" "+this.pts[e].y);return t.append(")  "+this._label+" "+this._depthDelta),t.toString()},isPointwiseEqual:function(t){if(this.pts.length!==t.pts.length)return!1;for(var e=0;e<this.pts.length;e++)if(!this.pts[e].equals2D(t.pts[e]))return!1;return!0},setDepthDelta:function(t){this._depthDelta=t},getEdgeIntersectionList:function(){return this.eiList},addIntersections:function(t,e,n){for(var i=0;i<t.getIntersectionNum();i++)this.addIntersection(t,e,n,i)},interfaces_:function(){return[]},getClass:function(){return jn}}),jn.updateIM=function(){if(!(2===arguments.length&&arguments[1]instanceof _e&&arguments[0]instanceof zn))return Wn.prototype.updateIM.apply(this,arguments);var t=arguments[0],e=arguments[1];e.setAtLeastIfValid(t.getLocation(0,Dn.ON),t.getLocation(1,Dn.ON),1),t.isArea()&&(e.setAtLeastIfValid(t.getLocation(0,Dn.LEFT),t.getLocation(1,Dn.LEFT),2),e.setAtLeastIfValid(t.getLocation(0,Dn.RIGHT),t.getLocation(1,Dn.RIGHT),2))},v(Kn,Wn),e(Kn.prototype,{isIncidentEdgeInResult:function(){for(var t=this.getEdges().getEdges().iterator();t.hasNext();){if(t.next().getEdge().isInResult())return!0}return!1},isIsolated:function(){return 1===this._label.getGeometryCount()},getCoordinate:function(){return this._coord},print:function(t){t.println("node "+this._coord+" lbl: "+this._label)},computeIM:function(t){},computeMergedLocation:function(t,e){var n=de.NONE;if(n=this._label.getLocation(e),!t.isNull(e)){var i=t.getLocation(e);n!==de.BOUNDARY&&(n=i)}return n},setLabel:function(){if(2!==arguments.length||!Number.isInteger(arguments[1])||!Number.isInteger(arguments[0]))return Wn.prototype.setLabel.apply(this,arguments);var t=arguments[0],e=arguments[1];null===this._label?this._label=new zn(t,e):this._label.setLocation(t,e)},getEdges:function(){return this._edges},mergeLabel:function(){if(arguments[0]instanceof Kn){var t=arguments[0];this.mergeLabel(t._label)}else if(arguments[0]instanceof zn)for(var e=arguments[0],n=0;n<2;n++){var i=this.computeMergedLocation(e,n);this._label.getLocation(n)===de.NONE&&this._label.setLocation(n,i)}},add:function(t){this._edges.insert(t),t.setNode(this)},setLabelBoundary:function(t){if(null===this._label)return null;var e=de.NONE;null!==this._label&&(e=this._label.getLocation(t));var n=null;switch(e){case de.BOUNDARY:n=de.INTERIOR;break;case de.INTERIOR:default:n=de.BOUNDARY}this._label.setLocation(t,n)},interfaces_:function(){return[]},getClass:function(){return Kn}}),e(Zn.prototype,{find:function(t){return this.nodeMap.get(t)},addNode:function(){if(arguments[0]instanceof E){var t=arguments[0];return null===(e=this.nodeMap.get(t))&&(e=this.nodeFact.createNode(t),this.nodeMap.put(t,e)),e}if(arguments[0]instanceof Kn){var e,n=arguments[0];return null===(e=this.nodeMap.get(n.getCoordinate()))?(this.nodeMap.put(n.getCoordinate(),n),n):(e.mergeLabel(n),e)}},print:function(t){for(var e=this.iterator();e.hasNext();){e.next().print(t)}},iterator:function(){return this.nodeMap.values().iterator()},values:function(){return this.nodeMap.values()},getBoundaryNodes:function(t){for(var e=new P,n=this.iterator();n.hasNext();){var i=n.next();i.getLabel().getLocation(t)===de.BOUNDARY&&e.add(i)}return e},add:function(t){var e=t.getCoordinate();this.addNode(e).add(t)},interfaces_:function(){return[]},getClass:function(){return Zn}}),e(Qn.prototype,{compareDirection:function(t){return this._dx===t._dx&&this._dy===t._dy?0:this._quadrant>t._quadrant?1:this._quadrant<t._quadrant?-1:z.index(t._p0,t._p1,this._p1)},getDy:function(){return this._dy},getCoordinate:function(){return this._p0},setNode:function(t){this._node=t},print:function(t){var e=Math.atan2(this._dy,this._dx),n=this.getClass().getName(),i=n.lastIndexOf("."),r=n.substring(i+1);t.print("  "+r+": "+this._p0+" - "+this._p1+" "+this._quadrant+":"+e+"   "+this._label)},compareTo:function(t){var e=t;return this.compareDirection(e)},getDirectedCoordinate:function(){return this._p1},getDx:function(){return this._dx},getLabel:function(){return this._label},getEdge:function(){return this._edge},getQuadrant:function(){return this._quadrant},getNode:function(){return this._node},toString:function(){var t=Math.atan2(this._dy,this._dx),e=this.getClass().getName(),n=e.lastIndexOf(".");return"  "+e.substring(n+1)+": "+this._p0+" - "+this._p1+" "+this._quadrant+":"+t+"   "+this._label},computeLabel:function(t){},init:function(t,e){this._p0=t,this._p1=e,this._dx=e.x-t.x,this._dy=e.y-t.y,this._quadrant=gn.quadrant(this._dx,this._dy),x.isTrue(!(0===this._dx&&0===this._dy),"EdgeEnd with identical endpoints found")},interfaces_:function(){return[g]},getClass:function(){return Qn}}),v(Jn,m),e(Jn.prototype,{getCoordinate:function(){return this.pt},interfaces_:function(){return[]},getClass:function(){return Jn}}),Jn.msgWithCoord=function(t,e){return null!==e?t+" [ "+e+" ]":t},v($n,Qn),e($n.prototype,{getNextMin:function(){return this._nextMin},getDepth:function(t){return this._depth[t]},setVisited:function(t){this._isVisited=t},computeDirectedLabel:function(){this._label=new zn(this._edge.getLabel()),this._isForward||this._label.flip()},getNext:function(){return this._next},setDepth:function(t,e){if(-999!==this._depth[t]&&this._depth[t]!==e)throw new Jn("assigned depths do not match",this.getCoordinate());this._depth[t]=e},isInteriorAreaEdge:function(){for(var t=!0,e=0;e<2;e++)this._label.isArea(e)&&this._label.getLocation(e,Dn.LEFT)===de.INTERIOR&&this._label.getLocation(e,Dn.RIGHT)===de.INTERIOR||(t=!1);return t},setNextMin:function(t){this._nextMin=t},print:function(t){Qn.prototype.print.call(this,t),t.print(" "+this._depth[Dn.LEFT]+"/"+this._depth[Dn.RIGHT]),t.print(" ("+this.getDepthDelta()+")"),this._isInResult&&t.print(" inResult")},setMinEdgeRing:function(t){this._minEdgeRing=t},isLineEdge:function(){var t=this._label.isLine(0)||this._label.isLine(1),e=!this._label.isArea(0)||this._label.allPositionsEqual(0,de.EXTERIOR),n=!this._label.isArea(1)||this._label.allPositionsEqual(1,de.EXTERIOR);return t&&e&&n},setEdgeRing:function(t){this._edgeRing=t},getMinEdgeRing:function(){return this._minEdgeRing},getDepthDelta:function(){var t=this._edge.getDepthDelta();return this._isForward||(t=-t),t},setInResult:function(t){this._isInResult=t},getSym:function(){return this._sym},isForward:function(){return this._isForward},getEdge:function(){return this._edge},printEdge:function(t){this.print(t),t.print(" "),this._isForward?this._edge.print(t):this._edge.printReverse(t)},setSym:function(t){this._sym=t},setVisitedEdge:function(t){this.setVisited(t),this._sym.setVisited(t)},setEdgeDepths:function(t,e){var n=this.getEdge().getDepthDelta();this._isForward||(n=-n);var i=1;t===Dn.LEFT&&(i=-1);var r=Dn.opposite(t),s=e+n*i;this.setDepth(t,e),this.setDepth(r,s)},getEdgeRing:function(){return this._edgeRing},isInResult:function(){return this._isInResult},setNext:function(t){this._next=t},isVisited:function(){return this._isVisited},interfaces_:function(){return[]},getClass:function(){return $n}}),$n.depthFactor=function(t,e){return t===de.EXTERIOR&&e===de.INTERIOR?1:t===de.INTERIOR&&e===de.EXTERIOR?-1:0},e(ti.prototype,{createNode:function(t){return new Kn(t,null)},interfaces_:function(){return[]},getClass:function(){return ti}}),e(ei.prototype,{printEdges:function(t){t.println("Edges:");for(var e=0;e<this._edges.size();e++){t.println("edge "+e+":");var n=this._edges.get(e);n.print(t),n.eiList.print(t)}},find:function(t){return this._nodes.find(t)},addNode:function(){if(arguments[0]instanceof Kn){var t=arguments[0];return this._nodes.addNode(t)}if(arguments[0]instanceof E){var e=arguments[0];return this._nodes.addNode(e)}},getNodeIterator:function(){return this._nodes.iterator()},linkResultDirectedEdges:function(){for(var t=this._nodes.iterator();t.hasNext();){t.next().getEdges().linkResultDirectedEdges()}},debugPrintln:function(t){Y.out.println(t)},isBoundaryNode:function(t,e){var n=this._nodes.find(e);if(null===n)return!1;var i=n.getLabel();return null!==i&&i.getLocation(t)===de.BOUNDARY},linkAllDirectedEdges:function(){for(var t=this._nodes.iterator();t.hasNext();){t.next().getEdges().linkAllDirectedEdges()}},matchInSameDirection:function(t,e,n,i){return!!t.equals(n)&&(z.index(t,e,i)===z.COLLINEAR&&gn.quadrant(t,e)===gn.quadrant(n,i))},getEdgeEnds:function(){return this._edgeEndList},debugPrint:function(t){Y.out.print(t)},getEdgeIterator:function(){return this._edges.iterator()},findEdgeInSameDirection:function(t,e){for(var n=0;n<this._edges.size();n++){var i=this._edges.get(n),r=i.getCoordinates();if(this.matchInSameDirection(t,e,r[0],r[1]))return i;if(this.matchInSameDirection(t,e,r[r.length-1],r[r.length-2]))return i}return null},insertEdge:function(t){this._edges.add(t)},findEdgeEnd:function(t){for(var e=this.getEdgeEnds().iterator();e.hasNext();){var n=e.next();if(n.getEdge()===t)return n}return null},addEdges:function(t){for(var e=t.iterator();e.hasNext();){var n=e.next();this._edges.add(n);var i=new $n(n,!0),r=new $n(n,!1);i.setSym(r),r.setSym(i),this.add(i),this.add(r)}},add:function(t){this._nodes.add(t),this._edgeEndList.add(t)},getNodes:function(){return this._nodes.values()},findEdge:function(t,e){for(var n=0;n<this._edges.size();n++){var i=this._edges.get(n),r=i.getCoordinates();if(t.equals(r[0])&&e.equals(r[1]))return i}return null},interfaces_:function(){return[]},getClass:function(){return ei}}),ei.linkResultDirectedEdges=function(t){for(var e=t.iterator();e.hasNext();){e.next().getEdges().linkResultDirectedEdges()}},v(ni,ei),e(ni.prototype,{insertBoundaryPoint:function(t,e){var n=this._nodes.addNode(e).getLabel(),i=1;de.NONE;n.getLocation(t,Dn.ON)===de.BOUNDARY&&i++;var r=ni.determineBoundary(this._boundaryNodeRule,i);n.setLocation(t,r)},computeSelfNodes:function(){if(2===arguments.length){var t=arguments[0],e=arguments[1];return this.computeSelfNodes(t,e,!1)}if(3===arguments.length){var n=arguments[0],i=arguments[1],r=arguments[2],s=new qn(n,!0,!1);s.setIsDoneIfProperInt(r);var o=this.createEdgeSetIntersector(),a=this._parentGeom instanceof Yt||this._parentGeom instanceof Vt||this._parentGeom instanceof kt,u=i||!a;return o.computeIntersections(this._edges,s,u),this.addSelfIntersectionNodes(this._argIndex),s}},computeSplitEdges:function(t){for(var e=this._edges.iterator();e.hasNext();){e.next().eiList.addSplitEdges(t)}},computeEdgeIntersections:function(t,e,n){var i=new qn(e,n,!0);return i.setBoundaryNodes(this.getBoundaryNodes(),t.getBoundaryNodes()),this.createEdgeSetIntersector().computeIntersections(this._edges,t._edges,i),i},getGeometry:function(){return this._parentGeom},getBoundaryNodeRule:function(){return this._boundaryNodeRule},hasTooFewPoints:function(){return this._hasTooFewPoints},addPoint:function(){if(arguments[0]instanceof Gt){var t=arguments[0].getCoordinate();this.insertPoint(this._argIndex,t,de.INTERIOR)}else if(arguments[0]instanceof E){var e=arguments[0];this.insertPoint(this._argIndex,e,de.INTERIOR)}},addPolygon:function(t){this.addPolygonRing(t.getExteriorRing(),de.EXTERIOR,de.INTERIOR);for(var e=0;e<t.getNumInteriorRing();e++){var n=t.getInteriorRingN(e);this.addPolygonRing(n,de.INTERIOR,de.EXTERIOR)}},addEdge:function(t){this.insertEdge(t);var e=t.getCoordinates();this.insertPoint(this._argIndex,e[0],de.BOUNDARY),this.insertPoint(this._argIndex,e[e.length-1],de.BOUNDARY)},addLineString:function(t){var e=nt.removeRepeatedPoints(t.getCoordinates());if(e.length<2)return this._hasTooFewPoints=!0,this._invalidPoint=e[0],null;var n=new jn(e,new zn(this._argIndex,de.INTERIOR));this._lineEdgeMap.put(t,n),this.insertEdge(n),x.isTrue(e.length>=2,"found LineString with single point"),this.insertBoundaryPoint(this._argIndex,e[0]),this.insertBoundaryPoint(this._argIndex,e[e.length-1])},getInvalidPoint:function(){return this._invalidPoint},getBoundaryPoints:function(){for(var t=this.getBoundaryNodes(),e=new Array(t.size()).fill(null),n=0,i=t.iterator();i.hasNext();){var r=i.next();e[n++]=r.getCoordinate().copy()}return e},getBoundaryNodes:function(){return null===this._boundaryNodes&&(this._boundaryNodes=this._nodes.getBoundaryNodes(this._argIndex)),this._boundaryNodes},addSelfIntersectionNode:function(t,e,n){if(this.isBoundaryNode(t,e))return null;n===de.BOUNDARY&&this._useBoundaryDeterminationRule?this.insertBoundaryPoint(t,e):this.insertPoint(t,e,n)},addPolygonRing:function(t,e,n){if(t.isEmpty())return null;var i=nt.removeRepeatedPoints(t.getCoordinates());if(i.length<4)return this._hasTooFewPoints=!0,this._invalidPoint=i[0],null;var r=e,s=n;z.isCCW(i)&&(r=n,s=e);var o=new jn(i,new zn(this._argIndex,de.BOUNDARY,r,s));this._lineEdgeMap.put(t,o),this.insertEdge(o),this.insertPoint(this._argIndex,i[0],de.BOUNDARY)},insertPoint:function(t,e,n){var i=this._nodes.addNode(e),r=i.getLabel();null===r?i._label=new zn(t,n):r.setLocation(t,n)},createEdgeSetIntersector:function(){return new Bn},addSelfIntersectionNodes:function(t){for(var e=this._edges.iterator();e.hasNext();)for(var n=e.next(),i=n.getLabel().getLocation(t),r=n.eiList.iterator();r.hasNext();){var s=r.next();this.addSelfIntersectionNode(t,s.coord,i)}},add:function(){if(!(1===arguments.length&&arguments[0]instanceof K))return ei.prototype.add.apply(this,arguments);var t=arguments[0];if(t.isEmpty())return null;if(t instanceof kt&&(this._useBoundaryDeterminationRule=!1),t instanceof Vt)this.addPolygon(t);else if(t instanceof At)this.addLineString(t);else if(t instanceof Gt)this.addPoint(t);else if(t instanceof zt)this.addCollection(t);else if(t instanceof wt)this.addCollection(t);else if(t instanceof kt)this.addCollection(t);else{if(!(t instanceof Lt))throw new UnsupportedOperationException(t.getClass().getName());this.addCollection(t)}},addCollection:function(t){for(var e=0;e<t.getNumGeometries();e++){var n=t.getGeometryN(e);this.add(n)}},locate:function(t){return N(this._parentGeom,Bt)&&this._parentGeom.getNumGeometries()>50?(null===this._areaPtLocator&&(this._areaPtLocator=new Ae(this._parentGeom)),this._areaPtLocator.locate(t)):this._ptLocator.locate(t,this._parentGeom)},findEdge:function(){if(1===arguments.length&&arguments[0]instanceof At){var t=arguments[0];return this._lineEdgeMap.get(t)}return ei.prototype.findEdge.apply(this,arguments)},interfaces_:function(){return[]},getClass:function(){return ni}}),ni.determineBoundary=function(t,e){return t.isInBoundary(e)?de.BOUNDARY:de.INTERIOR};var ii=Object.freeze({GeometryGraph:ni});function ri(){}function si(){if(this._p=null,this._data=null,this._left=null,this._right=null,this._count=null,2===arguments.length){var t=arguments[0],e=arguments[1];this._p=new E(t),this._left=null,this._right=null,this._count=1,this._data=e}else if(3===arguments.length){var n=arguments[0],i=arguments[1],r=arguments[2];this._p=new E(n,i),this._left=null,this._right=null,this._count=1,this._data=r}}function oi(){if(this._root=null,this._numberOfNodes=null,this._tolerance=null,0===arguments.length)oi.call(this,0);else if(1===arguments.length){var t=arguments[0];this._tolerance=t}}function ai(){this._tolerance=null,this._matchNode=null,this._matchDist=0,this._p=null;var t=arguments[0],e=arguments[1];this._p=t,this._tolerance=e}e(ri.prototype,{visit:function(t){},interfaces_:function(){return[]},getClass:function(){return ri}}),e(si.prototype,{isRepeated:function(){return this._count>1},getRight:function(){return this._right},getCoordinate:function(){return this._p},setLeft:function(t){this._left=t},getX:function(){return this._p.x},getData:function(){return this._data},getCount:function(){return this._count},getLeft:function(){return this._left},getY:function(){return this._p.y},increment:function(){this._count=this._count+1},setRight:function(t){this._right=t},interfaces_:function(){return[]},getClass:function(){return si}}),e(oi.prototype,{insert:function(){if(1===arguments.length){var t=arguments[0];return this.insert(t,null)}if(2===arguments.length){var e=arguments[0],n=arguments[1];if(null===this._root)return this._root=new si(e,n),this._root;if(this._tolerance>0){var i=this.findBestMatchNode(e);if(null!==i)return i.increment(),i}return this.insertExact(e,n)}},query:function(){if(1===arguments.length){var t=arguments[0],e=new P;return this.query(t,e),e}if(2===arguments.length)if(arguments[0]instanceof M&&N(arguments[1],w)){var n=arguments[0],i=arguments[1];this.queryNode(this._root,n,!0,{interfaces_:function(){return[ri]},visit:function(t){i.add(t)}})}else if(arguments[0]instanceof M&&N(arguments[1],ri)){var r=arguments[0],s=arguments[1];this.queryNode(this._root,r,!0,s)}},queryNode:function(t,e,n,i){if(null===t)return null;var r=null,s=null,o=null;n?(r=e.getMinX(),s=e.getMaxX(),o=t.getX()):(r=e.getMinY(),s=e.getMaxY(),o=t.getY());var a=o<=s;r<o&&this.queryNode(t.getLeft(),e,!n,i),e.contains(t.getCoordinate())&&i.visit(t),a&&this.queryNode(t.getRight(),e,!n,i)},findBestMatchNode:function(t){var e=new ai(t,this._tolerance);return this.query(e.queryEnvelope(),e),e.getNode()},isEmpty:function(){return null===this._root},insertExact:function(t,e){for(var n=this._root,i=this._root,r=!0,s=!0;null!==n;){if(null!==n)if(t.distance(n.getCoordinate())<=this._tolerance)return n.increment(),n;i=n,n=(s=r?t.x<n.getX():t.y<n.getY())?n.getLeft():n.getRight(),r=!r}this._numberOfNodes=this._numberOfNodes+1;var o=new si(t,e);return s?i.setLeft(o):i.setRight(o),o},interfaces_:function(){return[]},getClass:function(){return oi}}),oi.toCoordinates=function(){if(1===arguments.length){var t=arguments[0];return oi.toCoordinates(t,!1)}if(2===arguments.length){for(var e=arguments[0],n=arguments[1],i=new b,r=e.iterator();r.hasNext();)for(var s=r.next(),o=n?s.getCount():1,a=0;a<o;a++)i.add(s.getCoordinate(),!0);return i.toCoordinateArray()}},e(ai.prototype,{visit:function(t){var e=this._p.distance(t.getCoordinate());if(!(e<=this._tolerance))return null;var n=!1;(null===this._matchNode||e<this._matchDist||null!==this._matchNode&&e===this._matchDist&&t.getCoordinate().compareTo(this._matchNode.getCoordinate())<1)&&(n=!0),n&&(this._matchNode=t,this._matchDist=e)},queryEnvelope:function(){var t=new M(this._p);return t.expandBy(this._tolerance),t},getNode:function(){return this._matchNode},interfaces_:function(){return[ri]},getClass:function(){return ai}}),oi.BestMatchVisitor=ai;var ui=Object.freeze({KdTree:oi});function li(){this._items=new P,this._subnode=new Array(4).fill(null)}function hi(){this._pt=new E,this._level=0,this._env=null;var t=arguments[0];this.computeKey(t)}function ci(){li.apply(this),this._env=null,this._centrex=null,this._centrey=null,this._level=null;var t=arguments[0],e=arguments[1];this._env=t,this._level=e,this._centrex=(t.getMinX()+t.getMaxX())/2,this._centrey=(t.getMinY()+t.getMaxY())/2}function fi(){li.apply(this)}function gi(){}function di(){this._root=null,this._minExtent=1,this._root=new fi}e(li.prototype,{hasChildren:function(){for(var t=0;t<4;t++)if(null!==this._subnode[t])return!0;return!1},isPrunable:function(){return!(this.hasChildren()||this.hasItems())},addAllItems:function(t){t.addAll(this._items);for(var e=0;e<4;e++)null!==this._subnode[e]&&this._subnode[e].addAllItems(t);return t},getNodeCount:function(){for(var t=0,e=0;e<4;e++)null!==this._subnode[e]&&(t+=this._subnode[e].size());return t+1},size:function(){for(var t=0,e=0;e<4;e++)null!==this._subnode[e]&&(t+=this._subnode[e].size());return t+this._items.size()},addAllItemsFromOverlapping:function(t,e){if(!this.isSearchMatch(t))return null;e.addAll(this._items);for(var n=0;n<4;n++)null!==this._subnode[n]&&this._subnode[n].addAllItemsFromOverlapping(t,e)},visitItems:function(t,e){for(var n=this._items.iterator();n.hasNext();)e.visitItem(n.next())},hasItems:function(){return!this._items.isEmpty()},remove:function(t,e){if(!this.isSearchMatch(t))return!1;for(var n=!1,i=0;i<4;i++)if(null!==this._subnode[i]&&(n=this._subnode[i].remove(t,e))){this._subnode[i].isPrunable()&&(this._subnode[i]=null);break}return n||(n=this._items.remove(e))},visit:function(t,e){if(!this.isSearchMatch(t))return null;this.visitItems(t,e);for(var n=0;n<4;n++)null!==this._subnode[n]&&this._subnode[n].visit(t,e)},getItems:function(){return this._items},depth:function(){for(var t=0,e=0;e<4;e++)if(null!==this._subnode[e]){var n=this._subnode[e].depth();n>t&&(t=n)}return t+1},isEmpty:function(){var t=!0;if(this._items.isEmpty()){for(var e=0;e<4;e++)if(null!==this._subnode[e]&&!this._subnode[e].isEmpty()){t=!1;break}}else t=!1;return t},add:function(t){this._items.add(t)},interfaces_:function(){return[p]},getClass:function(){return li}}),li.getSubnodeIndex=function(t,e,n){var i=-1;return t.getMinX()>=e&&(t.getMinY()>=n&&(i=3),t.getMaxY()<=n&&(i=1)),t.getMaxX()<=e&&(t.getMinY()>=n&&(i=2),t.getMaxY()<=n&&(i=0)),i},e(hi.prototype,{getLevel:function(){return this._level},computeKey:function(){if(1===arguments.length){var t=arguments[0];for(this._level=hi.computeQuadLevel(t),this._env=new M,this.computeKey(this._level,t);!this._env.contains(t);)this._level+=1,this.computeKey(this._level,t)}else if(2===arguments.length){var e=arguments[0],n=arguments[1],i=on.powerOf2(e);this._pt.x=Math.floor(n.getMinX()/i)*i,this._pt.y=Math.floor(n.getMinY()/i)*i,this._env.init(this._pt.x,this._pt.x+i,this._pt.y,this._pt.y+i)}},getEnvelope:function(){return this._env},getCentre:function(){return new E((this._env.getMinX()+this._env.getMaxX())/2,(this._env.getMinY()+this._env.getMaxY())/2)},getPoint:function(){return this._pt},interfaces_:function(){return[]},getClass:function(){return hi}}),hi.computeQuadLevel=function(t){var e=t.getWidth(),n=t.getHeight(),i=e>n?e:n;return on.exponent(i)+1},v(ci,li),e(ci.prototype,{find:function(t){var e=li.getSubnodeIndex(t,this._centrex,this._centrey);return-1===e?this:null!==this._subnode[e]?this._subnode[e].find(t):this},isSearchMatch:function(t){return null!==t&&this._env.intersects(t)},getSubnode:function(t){return null===this._subnode[t]&&(this._subnode[t]=this.createSubnode(t)),this._subnode[t]},getEnvelope:function(){return this._env},getNode:function(t){var e=li.getSubnodeIndex(t,this._centrex,this._centrey);return-1!==e?this.getSubnode(e).getNode(t):this},createSubnode:function(t){var e=0,n=0,i=0,r=0;switch(t){case 0:e=this._env.getMinX(),n=this._centrex,i=this._env.getMinY(),r=this._centrey;break;case 1:e=this._centrex,n=this._env.getMaxX(),i=this._env.getMinY(),r=this._centrey;break;case 2:e=this._env.getMinX(),n=this._centrex,i=this._centrey,r=this._env.getMaxY();break;case 3:e=this._centrex,n=this._env.getMaxX(),i=this._centrey,r=this._env.getMaxY()}return new ci(new M(e,n,i,r),this._level-1)},insertNode:function(t){x.isTrue(null===this._env||this._env.contains(t._env));var e=li.getSubnodeIndex(t._env,this._centrex,this._centrey);if(t._level===this._level-1)this._subnode[e]=t;else{var n=this.createSubnode(e);n.insertNode(t),this._subnode[e]=n}},interfaces_:function(){return[]},getClass:function(){return ci}}),ci.createNode=function(t){var e=new hi(t);return new ci(e.getEnvelope(),e.getLevel())},ci.createExpanded=function(t,e){var n=new M(e);null!==t&&n.expandToInclude(t._env);var i=ci.createNode(n);return null!==t&&i.insertNode(t),i},v(fi,li),e(fi.prototype,{insert:function(t,e){var n=li.getSubnodeIndex(t,fi.origin.x,fi.origin.y);if(-1===n)return this.add(e),null;var i=this._subnode[n];if(null===i||!i.getEnvelope().contains(t)){var r=ci.createExpanded(i,t);this._subnode[n]=r}this.insertContained(this._subnode[n],t,e)},isSearchMatch:function(t){return!0},insertContained:function(t,e,n){x.isTrue(t.getEnvelope().contains(e));var i=ln.isZeroWidth(e.getMinX(),e.getMaxX()),r=ln.isZeroWidth(e.getMinY(),e.getMaxY());(i||r?t.find(e):t.getNode(e)).add(n)},interfaces_:function(){return[]},getClass:function(){return fi}}),fi.origin=new E(0,0),e(gi.prototype,{insert:function(t,e){},remove:function(t,e){},query:function(){},interfaces_:function(){return[]},getClass:function(){return gi}}),e(di.prototype,{size:function(){return null!==this._root?this._root.size():0},insert:function(t,e){this.collectStats(t);var n=di.ensureExtent(t,this._minExtent);this._root.insert(n,e)},query:function(){if(1===arguments.length){var t=arguments[0],e=new Me;return this.query(t,e),e.getItems()}if(2===arguments.length){var n=arguments[0],i=arguments[1];this._root.visit(n,i)}},queryAll:function(){var t=new P;return this._root.addAllItems(t),t},remove:function(t,e){var n=di.ensureExtent(t,this._minExtent);return this._root.remove(n,e)},collectStats:function(t){var e=t.getWidth();e<this._minExtent&&e>0&&(this._minExtent=e);var n=t.getHeight();n<this._minExtent&&n>0&&(this._minExtent=n)},depth:function(){return null!==this._root?this._root.depth():0},isEmpty:function(){return null===this._root||this._root.isEmpty()},interfaces_:function(){return[gi,p]},getClass:function(){return di}}),di.ensureExtent=function(t,e){var n=t.getMinX(),i=t.getMaxX(),r=t.getMinY(),s=t.getMaxY();return n!==i&&r!==s?t:(n===i&&(i=(n-=e/2)+e/2),r===s&&(s=(r-=e/2)+e/2),new M(n,i,r,s))},di.serialVersionUID=-0x678b60c967a25400;var _i=Object.freeze({Quadtree:di});function pi(){}function mi(){this._bounds=null,this._item=null;var t=arguments[0],e=arguments[1];this._bounds=t,this._item=e}function vi(){this._size=null,this._items=null,this._size=0,this._items=new P,this._items.add(null)}function yi(){this.normalOrder=null;var t=arguments[0];this.normalOrder=t}function xi(){if(this._childBoundables=new P,this._bounds=null,this._level=null,0===arguments.length);else if(1===arguments.length){var t=arguments[0];this._level=t}}function Ei(){this._boundable1=null,this._boundable2=null,this._distance=null,this._itemDistance=null;var t=arguments[0],e=arguments[1],n=arguments[2];this._boundable1=t,this._boundable2=e,this._itemDistance=n,this._distance=this.distance()}function Ii(){if(this._root=null,this._built=!1,this._itemBoundables=new P,this._nodeCapacity=null,0===arguments.length)Ii.call(this,Ii.DEFAULT_NODE_CAPACITY);else if(1===arguments.length){var t=arguments[0];x.isTrue(t>1,"Node capacity must be greater than 1"),this._nodeCapacity=t}}function Ni(){}function Ci(){if(0===arguments.length)Ci.call(this,Ci.DEFAULT_NODE_CAPACITY);else if(1===arguments.length){var t=arguments[0];Ii.call(this,t)}}function Si(){var t=arguments[0];xi.call(this,t)}e(pi.prototype,{getBounds:function(){},interfaces_:function(){return[]},getClass:function(){return pi}}),e(mi.prototype,{getItem:function(){return this._item},getBounds:function(){return this._bounds},interfaces_:function(){return[pi,p]},getClass:function(){return mi}}),e(vi.prototype,{poll:function(){if(this.isEmpty())return null;var t=this._items.get(1);return this._items.set(1,this._items.get(this._size)),this._size-=1,this.reorder(1),t},size:function(){return this._size},reorder:function(t){for(var e=null,n=this._items.get(t);2*t<=this._size&&((e=2*t)!==this._size&&this._items.get(e+1).compareTo(this._items.get(e))<0&&e++,this._items.get(e).compareTo(n)<0);t=e)this._items.set(t,this._items.get(e));this._items.set(t,n)},clear:function(){this._size=0,this._items.clear()},isEmpty:function(){return 0===this._size},add:function(t){this._items.add(null),this._size+=1;var e=this._size;for(this._items.set(0,t);t.compareTo(this._items.get(Math.trunc(e/2)))<0;e/=2)this._items.set(e,this._items.get(Math.trunc(e/2)));this._items.set(e,t)},interfaces_:function(){return[]},getClass:function(){return vi}}),e(yi.prototype,{compare:function(t,e){var n=t.getDistance(),i=e.getDistance();return this.normalOrder?n>i?1:n===i?0:-1:n>i?-1:n===i?0:1},interfaces_:function(){return[_,p]},getClass:function(){return yi}}),e(xi.prototype,{getLevel:function(){return this._level},size:function(){return this._childBoundables.size()},getChildBoundables:function(){return this._childBoundables},addChildBoundable:function(t){x.isTrue(null===this._bounds),this._childBoundables.add(t)},isEmpty:function(){return this._childBoundables.isEmpty()},getBounds:function(){return null===this._bounds&&(this._bounds=this.computeBounds()),this._bounds},interfaces_:function(){return[pi,p]},getClass:function(){return xi}}),xi.serialVersionUID=0x5a1e55ec41369800,e(Ei.prototype,{expandToQueue:function(t,e){var n=Ei.isComposite(this._boundable1),r=Ei.isComposite(this._boundable2);if(n&&r)return Ei.area(this._boundable1)>Ei.area(this._boundable2)?(this.expand(this._boundable1,this._boundable2,t,e),null):(this.expand(this._boundable2,this._boundable1,t,e),null);if(n)return this.expand(this._boundable1,this._boundable2,t,e),null;if(r)return this.expand(this._boundable2,this._boundable1,t,e),null;throw new i("neither boundable is composite")},isLeaves:function(){return!(Ei.isComposite(this._boundable1)||Ei.isComposite(this._boundable2))},compareTo:function(t){var e=t;return this._distance<e._distance?-1:this._distance>e._distance?1:0},expand:function(t,e,n,i){for(var r=t.getChildBoundables().iterator();r.hasNext();){var s=new Ei(r.next(),e,this._itemDistance);s.getDistance()<i&&n.add(s)}},getBoundable:function(t){return 0===t?this._boundable1:this._boundable2},getDistance:function(){return this._distance},distance:function(){return this.isLeaves()?this._itemDistance.distance(this._boundable1,this._boundable2):this._boundable1.getBounds().distance(this._boundable2.getBounds())},interfaces_:function(){return[g]},getClass:function(){return Ei}}),Ei.area=function(t){return t.getBounds().getArea()},Ei.isComposite=function(t){return t instanceof xi},e(Ii.prototype,{queryInternal:function(){if(N(arguments[2],Ce)&&arguments[0]instanceof Object&&arguments[1]instanceof xi)for(var t=arguments[0],e=arguments[1],n=arguments[2],i=e.getChildBoundables(),r=0;r<i.size();r++){var s=i.get(r);this.getIntersectsOp().intersects(s.getBounds(),t)&&(s instanceof xi?this.queryInternal(t,s,n):s instanceof mi?n.visitItem(s.getItem()):x.shouldNeverReachHere())}else if(N(arguments[2],w)&&arguments[0]instanceof Object&&arguments[1]instanceof xi){var o=arguments[0],a=arguments[1],u=arguments[2];for(i=a.getChildBoundables(),r=0;r<i.size();r++){s=i.get(r);this.getIntersectsOp().intersects(s.getBounds(),o)&&(s instanceof xi?this.queryInternal(o,s,u):s instanceof mi?u.add(s.getItem()):x.shouldNeverReachHere())}}},getNodeCapacity:function(){return this._nodeCapacity},lastNode:function(t){return t.get(t.size()-1)},size:function(){if(0===arguments.length)return this.isEmpty()?0:(this.build(),this.size(this._root));if(1===arguments.length){for(var t=0,e=arguments[0].getChildBoundables().iterator();e.hasNext();){var n=e.next();n instanceof xi?t+=this.size(n):n instanceof mi&&(t+=1)}return t}},removeItem:function(t,e){for(var n=null,i=t.getChildBoundables().iterator();i.hasNext();){var r=i.next();r instanceof mi&&r.getItem()===e&&(n=r)}return null!==n&&(t.getChildBoundables().remove(n),!0)},itemsTree:function(){if(0===arguments.length){this.build();var t=this.itemsTree(this._root);return null===t?new P:t}if(1===arguments.length){for(var e=arguments[0],n=new P,i=e.getChildBoundables().iterator();i.hasNext();){var r=i.next();if(r instanceof xi){var s=this.itemsTree(r);null!==s&&n.add(s)}else r instanceof mi?n.add(r.getItem()):x.shouldNeverReachHere()}return n.size()<=0?null:n}},insert:function(t,e){x.isTrue(!this._built,"Cannot insert items into an STR packed R-tree after it has been built."),this._itemBoundables.add(new mi(t,e))},boundablesAtLevel:function(){if(1===arguments.length){var t=arguments[0],e=new P;return this.boundablesAtLevel(t,this._root,e),e}if(3===arguments.length){var n=arguments[0],i=arguments[1],r=arguments[2];if(x.isTrue(n>-2),i.getLevel()===n)return r.add(i),null;for(var s=i.getChildBoundables().iterator();s.hasNext();){var o=s.next();o instanceof xi?this.boundablesAtLevel(n,o,r):(x.isTrue(o instanceof mi),-1===n&&r.add(o))}return null}},query:function(){if(1===arguments.length){var t=arguments[0];this.build();var e=new P;return this.isEmpty()?e:(this.getIntersectsOp().intersects(this._root.getBounds(),t)&&this.queryInternal(t,this._root,e),e)}if(2===arguments.length){var n=arguments[0],i=arguments[1];if(this.build(),this.isEmpty())return null;this.getIntersectsOp().intersects(this._root.getBounds(),n)&&this.queryInternal(n,this._root,i)}},build:function(){if(this._built)return null;this._root=this._itemBoundables.isEmpty()?this.createNode(0):this.createHigherLevels(this._itemBoundables,-1),this._itemBoundables=null,this._built=!0},getRoot:function(){return this.build(),this._root},remove:function(){if(2===arguments.length){var t=arguments[0],e=arguments[1];return this.build(),!!this.getIntersectsOp().intersects(this._root.getBounds(),t)&&this.remove(t,this._root,e)}if(3===arguments.length){var n=arguments[0],i=arguments[1],r=arguments[2],s=this.removeItem(i,r);if(s)return!0;for(var o=null,a=i.getChildBoundables().iterator();a.hasNext();){var u=a.next();if(this.getIntersectsOp().intersects(u.getBounds(),n)&&(u instanceof xi&&(s=this.remove(n,u,r)))){o=u;break}}return null!==o&&o.getChildBoundables().isEmpty()&&i.getChildBoundables().remove(o),s}},createHigherLevels:function(t,e){x.isTrue(!t.isEmpty());var n=this.createParentBoundables(t,e+1);return 1===n.size()?n.get(0):this.createHigherLevels(n,e+1)},depth:function(){if(0===arguments.length)return this.isEmpty()?0:(this.build(),this.depth(this._root));if(1===arguments.length){for(var t=0,e=arguments[0].getChildBoundables().iterator();e.hasNext();){var n=e.next();if(n instanceof xi){var i=this.depth(n);i>t&&(t=i)}}return t+1}},createParentBoundables:function(t,e){x.isTrue(!t.isEmpty());var n=new P;n.add(this.createNode(e));var i=new P(t);Te.sort(i,this.getComparator());for(var r=i.iterator();r.hasNext();){var s=r.next();this.lastNode(n).getChildBoundables().size()===this.getNodeCapacity()&&n.add(this.createNode(e)),this.lastNode(n).addChildBoundable(s)}return n},isEmpty:function(){return this._built?this._root.isEmpty():this._itemBoundables.isEmpty()},interfaces_:function(){return[p]},getClass:function(){return Ii}}),Ii.compareDoubles=function(t,e){return t>e?1:t<e?-1:0},Ii.IntersectsOp=function(){},Ii.serialVersionUID=-0x35ef64c82d4c5400,Ii.DEFAULT_NODE_CAPACITY=10,e(Ni.prototype,{distance:function(t,e){},interfaces_:function(){return[]},getClass:function(){return Ni}}),v(Ci,Ii),e(Ci.prototype,{createParentBoundablesFromVerticalSlices:function(t,e){x.isTrue(t.length>0);for(var n=new P,i=0;i<t.length;i++)n.addAll(this.createParentBoundablesFromVerticalSlice(t[i],e));return n},createNode:function(t){return new Si(t)},size:function(){return 0===arguments.length?Ii.prototype.size.call(this):Ii.prototype.size.apply(this,arguments)},insert:function(){if(!(2===arguments.length&&arguments[1]instanceof Object&&arguments[0]instanceof M))return Ii.prototype.insert.apply(this,arguments);var t=arguments[0],e=arguments[1];if(t.isNull())return null;Ii.prototype.insert.call(this,t,e)},getIntersectsOp:function(){return Ci.intersectsOp},verticalSlices:function(t,e){for(var n=Math.trunc(Math.ceil(t.size()/e)),i=new Array(e).fill(null),r=t.iterator(),s=0;s<e;s++){i[s]=new P;for(var o=0;r.hasNext()&&o<n;){var a=r.next();i[s].add(a),o++}}return i},query:function(){if(1===arguments.length){var t=arguments[0];return Ii.prototype.query.call(this,t)}if(2===arguments.length){var e=arguments[0],n=arguments[1];Ii.prototype.query.call(this,e,n)}},getComparator:function(){return Ci.yComparator},createParentBoundablesFromVerticalSlice:function(t,e){return Ii.prototype.createParentBoundables.call(this,t,e)},remove:function(){if(2===arguments.length&&arguments[1]instanceof Object&&arguments[0]instanceof M){var t=arguments[0],e=arguments[1];return Ii.prototype.remove.call(this,t,e)}return Ii.prototype.remove.apply(this,arguments)},depth:function(){return 0===arguments.length?Ii.prototype.depth.call(this):Ii.prototype.depth.apply(this,arguments)},createParentBoundables:function(t,e){x.isTrue(!t.isEmpty());var n=Math.trunc(Math.ceil(t.size()/this.getNodeCapacity())),i=new P(t);Te.sort(i,Ci.xComparator);var r=this.verticalSlices(i,Math.trunc(Math.ceil(Math.sqrt(n))));return this.createParentBoundablesFromVerticalSlices(r,e)},nearestNeighbour:function(){if(1===arguments.length){if(N(arguments[0],Ni)){var t=arguments[0],e=new Ei(this.getRoot(),this.getRoot(),t);return this.nearestNeighbour(e)}if(arguments[0]instanceof Ei){var n=arguments[0];return this.nearestNeighbour(n,s.POSITIVE_INFINITY)}}else if(2===arguments.length){if(arguments[0]instanceof Ci&&N(arguments[1],Ni)){var i=arguments[0],r=arguments[1];e=new Ei(this.getRoot(),i.getRoot(),r);return this.nearestNeighbour(e)}if(arguments[0]instanceof Ei&&"number"==typeof arguments[1]){var o=arguments[0],a=arguments[1],u=null;for((_=new vi).add(o);!_.isEmpty()&&a>0;){if((E=(x=_.poll()).getDistance())>=a)break;x.isLeaves()?(a=E,u=x):x.expandToQueue(_,a)}return[u.getBoundable(0).getItem(),u.getBoundable(1).getItem()]}if(arguments[0]instanceof Ei&&Number.isInteger(arguments[1])){var l=arguments[0],h=arguments[1];return this.nearestNeighbour(l,s.POSITIVE_INFINITY,h)}}else if(3===arguments.length){if(N(arguments[2],Ni)&&arguments[0]instanceof M&&arguments[1]instanceof Object){var c=arguments[0],f=arguments[1],g=arguments[2],d=new mi(c,f);e=new Ei(this.getRoot(),d,g);return this.nearestNeighbour(e)[0]}if(Number.isInteger(arguments[2])&&arguments[0]instanceof Ei&&"number"==typeof arguments[1]){var _,p=arguments[0],m=arguments[1],v=arguments[2];a=m;(_=new vi).add(p);for(var y=new java.util.PriorityQueue<Ei>new yi(!1);!_.isEmpty()&&a>=0;){var x,E;if((E=(x=_.poll()).getDistance())>=a)break;x.isLeaves()?y.size()<v?y.add(x):(y.peek().getDistance()>E&&(y.poll(),y.add(x)),a=y.peek().getDistance()):x.expandToQueue(_,a)}return Ci.getItems(y)}}else if(4===arguments.length){var I=arguments[0],C=arguments[1],S=arguments[2],L=arguments[3];d=new mi(I,C),e=new Ei(this.getRoot(),d,S);return this.nearestNeighbour(e,L)}},interfaces_:function(){return[gi,p]},getClass:function(){return Ci}}),Ci.centreX=function(t){return Ci.avg(t.getMinX(),t.getMaxX())},Ci.avg=function(t,e){return(t+e)/2},Ci.getItems=function(t){for(var e=new Array(t.size()).fill(null),n=t.iterator(),i=0;n.hasNext();)e[i]=n.next().getBoundable(0).getItem(),i++;return e},Ci.centreY=function(t){return Ci.avg(t.getMinY(),t.getMaxY())},v(Si,xi),e(Si.prototype,{computeBounds:function(){for(var t=null,e=this.getChildBoundables().iterator();e.hasNext();){var n=e.next();null===t?t=new M(n.getBounds()):t.expandToInclude(n.getBounds())}return t},interfaces_:function(){return[]},getClass:function(){return Si}}),Ci.STRtreeNode=Si,Ci.serialVersionUID=0x39920f7d5f261e0,Ci.xComparator={interfaces_:function(){return[_]},compare:function(t,e){return Ii.compareDoubles(Ci.centreX(t.getBounds()),Ci.centreX(e.getBounds()))}},Ci.yComparator={interfaces_:function(){return[_]},compare:function(t,e){return Ii.compareDoubles(Ci.centreY(t.getBounds()),Ci.centreY(e.getBounds()))}},Ci.intersectsOp={interfaces_:function(){return[IntersectsOp]},intersects:function(t,e){return t.intersects(e)}},Ci.DEFAULT_NODE_CAPACITY=10;var Li=Object.freeze({STRtree:Ci}),wi=Object.freeze({kdtree:ui,quadtree:_i,strtree:Li}),Ri=["Point","MultiPoint","LineString","MultiLineString","Polygon","MultiPolygon"];function Ti(t){this.geometryFactory=t||new se}e(Ti.prototype,{read:function(t){var e=void 0,n=(e="string"==typeof t?JSON.parse(t):t).type;if(!Pi[n])throw new Error("Unknown GeoJSON type: "+e.type);return-1!==Ri.indexOf(n)?Pi[n].call(this,e.coordinates):"GeometryCollection"===n?Pi[n].call(this,e.geometries):Pi[n].call(this,e)},write:function(t){var e=t.getGeometryType();if(!Oi[e])throw new Error("Geometry is not supported");return Oi[e].call(this,t)}});var Pi={Feature:function(t){var e={};for(var n in t)e[n]=t[n];if(t.geometry){var i=t.geometry.type;if(!Pi[i])throw new Error("Unknown GeoJSON type: "+t.type);e.geometry=this.read(t.geometry)}return t.bbox&&(e.bbox=Pi.bbox.call(this,t.bbox)),e},FeatureCollection:function(t){var e={};if(t.features){e.features=[];for(var n=0;n<t.features.length;++n)e.features.push(this.read(t.features[n]))}return t.bbox&&(e.bbox=this.parse.bbox.call(this,t.bbox)),e},coordinates:function(t){for(var e=[],n=0;n<t.length;++n){var i=t[n];e.push(new E(i[0],i[1]))}return e},bbox:function(t){return this.geometryFactory.createLinearRing([new E(t[0],t[1]),new E(t[2],t[1]),new E(t[2],t[3]),new E(t[0],t[3]),new E(t[0],t[1])])},Point:function(t){var e=new E(t[0],t[1]);return this.geometryFactory.createPoint(e)},MultiPoint:function(t){for(var e=[],n=0;n<t.length;++n)e.push(Pi.Point.call(this,t[n]));return this.geometryFactory.createMultiPoint(e)},LineString:function(t){var e=Pi.coordinates.call(this,t);return this.geometryFactory.createLineString(e)},MultiLineString:function(t){for(var e=[],n=0;n<t.length;++n)e.push(Pi.LineString.call(this,t[n]));return this.geometryFactory.createMultiLineString(e)},Polygon:function(t){for(var e=Pi.coordinates.call(this,t[0]),n=this.geometryFactory.createLinearRing(e),i=[],r=1;r<t.length;++r){var s=t[r],o=Pi.coordinates.call(this,s),a=this.geometryFactory.createLinearRing(o);i.push(a)}return this.geometryFactory.createPolygon(n,i)},MultiPolygon:function(t){for(var e=[],n=0;n<t.length;++n){var i=t[n];e.push(Pi.Polygon.call(this,i))}return this.geometryFactory.createMultiPolygon(e)},GeometryCollection:function(t){for(var e=[],n=0;n<t.length;++n){var i=t[n];e.push(this.read(i))}return this.geometryFactory.createGeometryCollection(e)}},Oi={coordinate:function(t){return[t.x,t.y]},Point:function(t){return{type:"Point",coordinates:Oi.coordinate.call(this,t.getCoordinate())}},MultiPoint:function(t){for(var e=[],n=0;n<t._geometries.length;++n){var i=t._geometries[n],r=Oi.Point.call(this,i);e.push(r.coordinates)}return{type:"MultiPoint",coordinates:e}},LineString:function(t){for(var e=[],n=t.getCoordinates(),i=0;i<n.length;++i){var r=n[i];e.push(Oi.coordinate.call(this,r))}return{type:"LineString",coordinates:e}},MultiLineString:function(t){for(var e=[],n=0;n<t._geometries.length;++n){var i=t._geometries[n],r=Oi.LineString.call(this,i);e.push(r.coordinates)}return{type:"MultiLineString",coordinates:e}},Polygon:function(t){var e=[],n=Oi.LineString.call(this,t._shell);e.push(n.coordinates);for(var i=0;i<t._holes.length;++i){var r=t._holes[i],s=Oi.LineString.call(this,r);e.push(s.coordinates)}return{type:"Polygon",coordinates:e}},MultiPolygon:function(t){for(var e=[],n=0;n<t._geometries.length;++n){var i=t._geometries[n],r=Oi.Polygon.call(this,i);e.push(r.coordinates)}return{type:"MultiPolygon",coordinates:e}},GeometryCollection:function(t){for(var e=[],n=0;n<t._geometries.length;++n){var i=t._geometries[n],r=i.getGeometryType();e.push(Oi[r].call(this,i))}return{type:"GeometryCollection",geometries:e}}};function bi(t){this.parser=new Ti(t||new se)}function Mi(){this.parser=new Ti(this.geometryFactory)}function Di(t){this.parser=new ae(t||new se)}function Ai(t){return[t.x,t.y]}function Fi(t,e){this.geometryFactory=t||new se,this.ol=e||"undefined"!=typeof ol&&ol}e(bi.prototype,{read:function(t){return this.parser.read(t)}}),e(Mi.prototype,{write:function(t){return this.parser.write(t)}}),e(Di.prototype,{read:function(t){return this.parser.read(t)}}),e(Fi.prototype,{inject:function(t,e,n,i,r,s,o,a){this.ol={geom:{Point:t,LineString:e,LinearRing:n,Polygon:i,MultiPoint:r,MultiLineString:s,MultiPolygon:o,GeometryCollection:a}}},read:function(t){var e=this.ol;return t instanceof e.geom.Point?this.convertFromPoint(t):t instanceof e.geom.LineString?this.convertFromLineString(t):t instanceof e.geom.LinearRing?this.convertFromLinearRing(t):t instanceof e.geom.Polygon?this.convertFromPolygon(t):t instanceof e.geom.MultiPoint?this.convertFromMultiPoint(t):t instanceof e.geom.MultiLineString?this.convertFromMultiLineString(t):t instanceof e.geom.MultiPolygon?this.convertFromMultiPolygon(t):t instanceof e.geom.GeometryCollection?this.convertFromCollection(t):void 0},convertFromPoint:function(t){var e=t.getCoordinates();return this.geometryFactory.createPoint(new E(e[0],e[1]))},convertFromLineString:function(t){return this.geometryFactory.createLineString(t.getCoordinates().map(function(t){return new E(t[0],t[1])}))},convertFromLinearRing:function(t){return this.geometryFactory.createLinearRing(t.getCoordinates().map(function(t){return new E(t[0],t[1])}))},convertFromPolygon:function(t){for(var e=t.getLinearRings(),n=null,i=[],r=0;r<e.length;r++){var s=this.convertFromLinearRing(e[r]);0===r?n=s:i.push(s)}return this.geometryFactory.createPolygon(n,i)},convertFromMultiPoint:function(t){var e=t.getPoints().map(function(t){return this.convertFromPoint(t)},this);return this.geometryFactory.createMultiPoint(e)},convertFromMultiLineString:function(t){var e=t.getLineStrings().map(function(t){return this.convertFromLineString(t)},this);return this.geometryFactory.createMultiLineString(e)},convertFromMultiPolygon:function(t){var e=t.getPolygons().map(function(t){return this.convertFromPolygon(t)},this);return this.geometryFactory.createMultiPolygon(e)},convertFromCollection:function(t){var e=t.getGeometries().map(function(t){return this.read(t)},this);return this.geometryFactory.createGeometryCollection(e)},write:function(t){return"Point"===t.getGeometryType()?this.convertToPoint(t.getCoordinate()):"LineString"===t.getGeometryType()?this.convertToLineString(t):"LinearRing"===t.getGeometryType()?this.convertToLinearRing(t):"Polygon"===t.getGeometryType()?this.convertToPolygon(t):"MultiPoint"===t.getGeometryType()?this.convertToMultiPoint(t):"MultiLineString"===t.getGeometryType()?this.convertToMultiLineString(t):"MultiPolygon"===t.getGeometryType()?this.convertToMultiPolygon(t):"GeometryCollection"===t.getGeometryType()?this.convertToCollection(t):void 0},convertToPoint:function(t){return new this.ol.geom.Point([t.x,t.y])},convertToLineString:function(t){var e=t._points._coordinates.map(Ai);return new this.ol.geom.LineString(e)},convertToLinearRing:function(t){var e=t._points._coordinates.map(Ai);return new this.ol.geom.LinearRing(e)},convertToPolygon:function(t){for(var e=[t._shell._points._coordinates.map(Ai)],n=0;n<t._holes.length;n++)e.push(t._holes[n]._points._coordinates.map(Ai));return new this.ol.geom.Polygon(e)},convertToMultiPoint:function(t){return new this.ol.geom.MultiPoint(t.getCoordinates().map(Ai))},convertToMultiLineString:function(t){for(var e=[],n=0;n<t._geometries.length;n++)e.push(this.convertToLineString(t._geometries[n]).getCoordinates());return new this.ol.geom.MultiLineString(e)},convertToMultiPolygon:function(t){for(var e=[],n=0;n<t._geometries.length;n++)e.push(this.convertToPolygon(t._geometries[n]).getCoordinates());return new this.ol.geom.MultiPolygon(e)},convertToCollection:function(t){for(var e=[],n=0;n<t._geometries.length;n++){var i=t._geometries[n];e.push(this.write(i))}return new this.ol.geom.GeometryCollection(e)}});var Gi=Object.freeze({GeoJSONReader:bi,GeoJSONWriter:Mi,OL3Parser:Fi,WKTReader:Di,WKTWriter:he});function qi(){}function Bi(){this._segString=null,this.coord=null,this.segmentIndex=null,this._segmentOctant=null,this._isInterior=null;var t=arguments[0],e=arguments[1],n=arguments[2],i=arguments[3];this._segString=t,this.coord=new E(e),this.segmentIndex=n,this._segmentOctant=i,this._isInterior=!e.equals2D(t.getCoordinate(n))}function Vi(){this._nodeMap=new pt,this._edge=null;var t=arguments[0];this._edge=t}function zi(){this._nodeList=null,this._edge=null,this._nodeIt=null,this._currNode=null,this._nextNode=null,this._currSegIndex=0;var t=arguments[0];this._nodeList=t,this._edge=t.getEdge(),this._nodeIt=t.iterator(),this.readNextNode()}function Yi(){}function ki(){}function Ui(){}function Xi(){this._nodeList=new Vi(this),this._pts=null,this._data=null;var t=arguments[0],e=arguments[1];this._pts=t,this._data=e}function Hi(){this._overlapSeg1=new ge,this._overlapSeg2=new ge}function Wi(){}function ji(){if(this._segInt=null,0===arguments.length);else if(1===arguments.length){var t=arguments[0];this.setSegmentIntersector(t)}}function Ki(){if(this._monoChains=new P,this._index=new Ci,this._idCounter=0,this._nodedSegStrings=null,this._nOverlaps=0,0===arguments.length);else if(1===arguments.length){var t=arguments[0];ji.call(this,t)}}function Zi(){Hi.apply(this),this._si=null;var t=arguments[0];this._si=t}function Qi(){if(this._noder=null,this._scaleFactor=null,this._offsetX=null,this._offsetY=null,this._isScaled=!1,2===arguments.length){var t=arguments[0],e=arguments[1];Qi.call(this,t,e,0,0)}else if(4===arguments.length){var n=arguments[0],i=arguments[1];this._noder=n,this._scaleFactor=i,this._isScaled=!this.isIntegerPrecision()}}e(qi.prototype,{interfaces_:function(){return[]},getClass:function(){return qi}}),qi.relativeSign=function(t,e){return t<e?-1:t>e?1:0},qi.compare=function(t,e,n){if(e.equals2D(n))return 0;var i=qi.relativeSign(e.x,n.x),r=qi.relativeSign(e.y,n.y);switch(t){case 0:return qi.compareValue(i,r);case 1:return qi.compareValue(r,i);case 2:return qi.compareValue(r,-i);case 3:return qi.compareValue(-i,r);case 4:return qi.compareValue(-i,-r);case 5:return qi.compareValue(-r,-i);case 6:return qi.compareValue(-r,i);case 7:return qi.compareValue(i,-r)}return x.shouldNeverReachHere("invalid octant value"),0},qi.compareValue=function(t,e){return t<0?-1:t>0?1:e<0?-1:e>0?1:0},e(Bi.prototype,{getCoordinate:function(){return this.coord},print:function(t){t.print(this.coord),t.print(" seg # = "+this.segmentIndex)},compareTo:function(t){var e=t;return this.segmentIndex<e.segmentIndex?-1:this.segmentIndex>e.segmentIndex?1:this.coord.equals2D(e.coord)?0:qi.compare(this._segmentOctant,this.coord,e.coord)},isEndPoint:function(t){return 0===this.segmentIndex&&!this._isInterior||this.segmentIndex===t},isInterior:function(){return this._isInterior},interfaces_:function(){return[g]},getClass:function(){return Bi}}),e(Vi.prototype,{getSplitCoordinates:function(){var t=new b;this.addEndpoints();for(var e=this.iterator(),n=e.next();e.hasNext();){var i=e.next();this.addEdgeCoordinates(n,i,t),n=i}return t.toCoordinateArray()},addCollapsedNodes:function(){var t=new P;this.findCollapsesFromInsertedNodes(t),this.findCollapsesFromExistingVertices(t);for(var e=t.iterator();e.hasNext();){var n=e.next().intValue();this.add(this._edge.getCoordinate(n),n)}},print:function(t){t.println("Intersections:");for(var e=this.iterator();e.hasNext();){e.next().print(t)}},findCollapsesFromExistingVertices:function(t){for(var e=0;e<this._edge.size()-2;e++){var n=this._edge.getCoordinate(e),i=(this._edge.getCoordinate(e+1),this._edge.getCoordinate(e+2));n.equals2D(i)&&t.add(new G(e+1))}},addEdgeCoordinates:function(t,e,n){e.segmentIndex,t.segmentIndex;var i=this._edge.getCoordinate(e.segmentIndex),r=e.isInterior()||!e.coord.equals2D(i);n.add(new E(t.coord),!1);for(var s=t.segmentIndex+1;s<=e.segmentIndex;s++)n.add(this._edge.getCoordinate(s));r&&n.add(new E(e.coord))},iterator:function(){return this._nodeMap.values().iterator()},addSplitEdges:function(t){this.addEndpoints(),this.addCollapsedNodes();for(var e=this.iterator(),n=e.next();e.hasNext();){var i=e.next(),r=this.createSplitEdge(n,i);t.add(r),n=i}},findCollapseIndex:function(t,e,n){if(!t.coord.equals2D(e.coord))return!1;var i=e.segmentIndex-t.segmentIndex;return e.isInterior()||i--,1===i&&(n[0]=t.segmentIndex+1,!0)},findCollapsesFromInsertedNodes:function(t){for(var e=new Array(1).fill(null),n=this.iterator(),i=n.next();n.hasNext();){var r=n.next();this.findCollapseIndex(i,r,e)&&t.add(new G(e[0])),i=r}},getEdge:function(){return this._edge},addEndpoints:function(){var t=this._edge.size()-1;this.add(this._edge.getCoordinate(0),0),this.add(this._edge.getCoordinate(t),t)},createSplitEdge:function(t,e){var n=e.segmentIndex-t.segmentIndex+2,i=this._edge.getCoordinate(e.segmentIndex),r=e.isInterior()||!e.coord.equals2D(i);r||n--;var s=new Array(n).fill(null),o=0;s[o++]=new E(t.coord);for(var a=t.segmentIndex+1;a<=e.segmentIndex;a++)s[o++]=this._edge.getCoordinate(a);return r&&(s[o]=new E(e.coord)),new Xi(s,this._edge.getData())},add:function(t,e){var n=new Bi(this._edge,t,e,this._edge.getSegmentOctant(e)),i=this._nodeMap.get(n);return null!==i?(x.isTrue(i.coord.equals2D(t),"Found equal nodes with different coordinates"),i):(this._nodeMap.put(n,n),n)},checkSplitEdgesCorrectness:function(t){var e=this._edge.getCoordinates(),n=t.get(0).getCoordinate(0);if(!n.equals2D(e[0]))throw new m("bad split edge start point at "+n);var i=t.get(t.size()-1).getCoordinates(),r=i[i.length-1];if(!r.equals2D(e[e.length-1]))throw new m("bad split edge end point at "+r)},interfaces_:function(){return[]},getClass:function(){return Vi}}),e(zi.prototype,{next:function(){return null===this._currNode?(this._currNode=this._nextNode,this._currSegIndex=this._currNode.segmentIndex,this.readNextNode(),this._currNode):null===this._nextNode?null:this._nextNode.segmentIndex===this._currNode.segmentIndex?(this._currNode=this._nextNode,this._currSegIndex=this._currNode.segmentIndex,this.readNextNode(),this._currNode):(this._nextNode.segmentIndex,this._currNode.segmentIndex,null)},remove:function(){throw new UnsupportedOperationException(this.getClass().getName())},hasNext:function(){return null!==this._nextNode},readNextNode:function(){this._nodeIt.hasNext()?this._nextNode=this._nodeIt.next():this._nextNode=null},interfaces_:function(){return[C]},getClass:function(){return zi}}),e(Yi.prototype,{interfaces_:function(){return[]},getClass:function(){return Yi}}),Yi.octant=function(){if("number"==typeof arguments[0]&&"number"==typeof arguments[1]){var t=arguments[0],e=arguments[1];if(0===t&&0===e)throw new i("Cannot compute the octant for point ( "+t+", "+e+" )");var n=Math.abs(t),r=Math.abs(e);return t>=0?e>=0?n>=r?0:1:n>=r?7:6:e>=0?n>=r?3:2:n>=r?4:5}if(arguments[0]instanceof E&&arguments[1]instanceof E){var s=arguments[0],o=arguments[1],a=o.x-s.x,u=o.y-s.y;if(0===a&&0===u)throw new i("Cannot compute the octant for two identical points "+s);return Yi.octant(a,u)}},e(ki.prototype,{getCoordinates:function(){},size:function(){},getCoordinate:function(t){},isClosed:function(){},setData:function(t){},getData:function(){},interfaces_:function(){return[]},getClass:function(){return ki}}),e(Ui.prototype,{addIntersection:function(t,e){},interfaces_:function(){return[ki]},getClass:function(){return Ui}}),e(Xi.prototype,{getCoordinates:function(){return this._pts},size:function(){return this._pts.length},getCoordinate:function(t){return this._pts[t]},isClosed:function(){return this._pts[0].equals(this._pts[this._pts.length-1])},getSegmentOctant:function(t){return t===this._pts.length-1?-1:this.safeOctant(this.getCoordinate(t),this.getCoordinate(t+1))},setData:function(t){this._data=t},safeOctant:function(t,e){return t.equals2D(e)?0:Yi.octant(t,e)},getData:function(){return this._data},addIntersection:function(){if(2===arguments.length){var t=arguments[0],e=arguments[1];this.addIntersectionNode(t,e)}else if(4===arguments.length){var n=arguments[0],i=arguments[1],r=(arguments[2],arguments[3]),s=new E(n.getIntersection(r));this.addIntersection(s,i)}},toString:function(){return he.toLineString(new Kt(this._pts))},getNodeList:function(){return this._nodeList},addIntersectionNode:function(t,e){var n=e,i=n+1;if(i<this._pts.length){var r=this._pts[i];t.equals2D(r)&&(n=i)}return this._nodeList.add(t,n)},addIntersections:function(t,e,n){for(var i=0;i<t.getIntersectionNum();i++)this.addIntersection(t,e,n,i)},interfaces_:function(){return[Ui]},getClass:function(){return Xi}}),Xi.getNodedSubstrings=function(){if(1===arguments.length){var t=arguments[0],e=new P;return Xi.getNodedSubstrings(t,e),e}if(2===arguments.length)for(var n=arguments[0],i=arguments[1],r=n.iterator();r.hasNext();){r.next().getNodeList().addSplitEdges(i)}},e(Hi.prototype,{overlap:function(){if(2===arguments.length);else if(4===arguments.length){var t=arguments[0],e=arguments[1],n=arguments[2],i=arguments[3];t.getLineSegment(e,this._overlapSeg1),n.getLineSegment(i,this._overlapSeg2),this.overlap(this._overlapSeg1,this._overlapSeg2)}},interfaces_:function(){return[]},getClass:function(){return Hi}}),e(Wi.prototype,{computeNodes:function(t){},getNodedSubstrings:function(){},interfaces_:function(){return[]},getClass:function(){return Wi}}),e(ji.prototype,{setSegmentIntersector:function(t){this._segInt=t},interfaces_:function(){return[Wi]},getClass:function(){return ji}}),v(Ki,ji),e(Ki.prototype,{getMonotoneChains:function(){return this._monoChains},getNodedSubstrings:function(){return Xi.getNodedSubstrings(this._nodedSegStrings)},getIndex:function(){return this._index},add:function(t){for(var e=dn.getChains(t.getCoordinates(),t).iterator();e.hasNext();){var n=e.next();n.setId(this._idCounter++),this._index.insert(n.getEnvelope(),n),this._monoChains.add(n)}},computeNodes:function(t){this._nodedSegStrings=t;for(var e=t.iterator();e.hasNext();)this.add(e.next());this.intersectChains()},intersectChains:function(){for(var t=new Zi(this._segInt),e=this._monoChains.iterator();e.hasNext();)for(var n=e.next(),i=this._index.query(n.getEnvelope()).iterator();i.hasNext();){var r=i.next();if(r.getId()>n.getId()&&(n.computeOverlaps(r,t),this._nOverlaps++),this._segInt.isDone())return null}},interfaces_:function(){return[]},getClass:function(){return Ki}}),v(Zi,Hi),e(Zi.prototype,{overlap:function(){if(4!==arguments.length)return Hi.prototype.overlap.apply(this,arguments);var t=arguments[0],e=arguments[1],n=arguments[2],i=arguments[3],r=t.getContext(),s=n.getContext();this._si.processIntersections(r,e,s,i)},interfaces_:function(){return[]},getClass:function(){return Zi}}),Ki.SegmentOverlapAction=Zi,e(Qi.prototype,{rescale:function(){if(N(arguments[0],S))for(var t=arguments[0].iterator();t.hasNext();){var e=t.next();this.rescale(e.getCoordinates())}else if(arguments[0]instanceof Array){var n=arguments[0];2===n.length&&(new E(n[0]),new E(n[1]));for(t=0;t<n.length;t++)n[t].x=n[t].x/this._scaleFactor+this._offsetX,n[t].y=n[t].y/this._scaleFactor+this._offsetY;2===n.length&&n[0].equals2D(n[1])&&Y.out.println(n)}},scale:function(){if(N(arguments[0],S)){for(var t=arguments[0],e=new P(t.size()),n=t.iterator();n.hasNext();){var i=n.next();e.add(new Xi(this.scale(i.getCoordinates()),i.getData()))}return e}if(arguments[0]instanceof Array){var r=arguments[0],s=new Array(r.length).fill(null);for(n=0;n<r.length;n++)s[n]=new E(Math.round((r[n].x-this._offsetX)*this._scaleFactor),Math.round((r[n].y-this._offsetY)*this._scaleFactor),r[n].z);return nt.removeRepeatedPoints(s)}},isIntegerPrecision:function(){return 1===this._scaleFactor},getNodedSubstrings:function(){var t=this._noder.getNodedSubstrings();return this._isScaled&&this.rescale(t),t},computeNodes:function(t){var e=t;this._isScaled&&(e=this.scale(t)),this._noder.computeNodes(e)},interfaces_:function(){return[Wi]},getClass:function(){return Qi}});var Ji=Object.freeze({MCIndexNoder:Ki,ScaledNoder:Qi,SegmentString:ki});function $i(){if(this._inputGeom=null,this._isClosedEndpointsInInterior=!0,this._nonSimpleLocation=null,1===arguments.length){var t=arguments[0];this._inputGeom=t}else if(2===arguments.length){var e=arguments[0],n=arguments[1];this._inputGeom=e,this._isClosedEndpointsInInterior=!n.isInBoundary(2)}}function tr(){this.pt=null,this.isClosed=null,this.degree=null;var t=arguments[0];this.pt=t,this.isClosed=!1,this.degree=0}function er(){if(this._quadrantSegments=er.DEFAULT_QUADRANT_SEGMENTS,this._endCapStyle=er.CAP_ROUND,this._joinStyle=er.JOIN_ROUND,this._mitreLimit=er.DEFAULT_MITRE_LIMIT,this._isSingleSided=!1,this._simplifyFactor=er.DEFAULT_SIMPLIFY_FACTOR,0===arguments.length);else if(1===arguments.length){var t=arguments[0];this.setQuadrantSegments(t)}else if(2===arguments.length){var e=arguments[0],n=arguments[1];this.setQuadrantSegments(e),this.setEndCapStyle(n)}else if(4===arguments.length){var i=arguments[0],r=arguments[1],s=arguments[2],o=arguments[3];this.setQuadrantSegments(i),this.setEndCapStyle(r),this.setJoinStyle(s),this.setMitreLimit(o)}}function nr(){this._minIndex=-1,this._minCoord=null,this._minDe=null,this._orientedDe=null}function ir(){this.array_=[]}function rr(){this._finder=null,this._dirEdgeList=new P,this._nodes=new P,this._rightMostCoord=null,this._env=null,this._finder=new nr}function sr(){this._startDe=null,this._maxNodeDegree=-1,this._edges=new P,this._pts=new P,this._label=new zn(de.NONE),this._ring=null,this._isHole=null,this._shell=null,this._holes=new P,this._geometryFactory=null;var t=arguments[0],e=arguments[1];this._geometryFactory=e,this.computePoints(t),this.computeRing()}function or(){var t=arguments[0],e=arguments[1];sr.call(this,t,e)}function ar(){var t=arguments[0],e=arguments[1];sr.call(this,t,e)}function ur(){this._geometryFactory=null,this._shellList=new P;var t=arguments[0];this._geometryFactory=t}function lr(){this._inputLine=null,this._distanceTol=null,this._isDeleted=null,this._angleOrientation=z.COUNTERCLOCKWISE;var t=arguments[0];this._inputLine=t}function hr(){this._ptList=null,this._precisionModel=null,this._minimimVertexDistance=0,this._ptList=new P}function cr(){this._maxCurveSegmentError=0,this._filletAngleQuantum=null,this._closingSegLengthFactor=1,this._segList=null,this._distance=0,this._precisionModel=null,this._bufParams=null,this._li=null,this._s0=null,this._s1=null,this._s2=null,this._seg0=new ge,this._seg1=new ge,this._offset0=new ge,this._offset1=new ge,this._side=0,this._hasNarrowConcaveAngle=!1;var t=arguments[0],e=arguments[1],n=arguments[2];this._precisionModel=t,this._bufParams=e,this._li=new fe,this._filletAngleQuantum=Math.PI/2/e.getQuadrantSegments(),e.getQuadrantSegments()>=8&&e.getJoinStyle()===er.JOIN_ROUND&&(this._closingSegLengthFactor=cr.MAX_CLOSING_SEG_LEN_FACTOR),this.init(n)}function fr(){this._distance=0,this._precisionModel=null,this._bufParams=null;var t=arguments[0],e=arguments[1];this._precisionModel=t,this._bufParams=e}function gr(){this._subgraphs=null,this._seg=new ge;var t=arguments[0];this._subgraphs=t}function dr(){this._upwardSeg=null,this._leftDepth=null;var t=arguments[0],e=arguments[1];this._upwardSeg=new ge(t),this._leftDepth=e}function _r(){this._inputGeom=null,this._distance=null,this._curveBuilder=null,this._curveList=new P;var t=arguments[0],e=arguments[1],n=arguments[2];this._inputGeom=t,this._distance=e,this._curveBuilder=n}function pr(){this._edgeMap=new pt,this._edgeList=null,this._ptInAreaLocation=[de.NONE,de.NONE]}function mr(){pr.apply(this),this._resultAreaEdgeList=null,this._label=null,this._SCANNING_FOR_INCOMING=1,this._LINKING_TO_OUTGOING=2}function vr(){ti.apply(this)}function yr(){this._pts=null,this._orientation=null;var t=arguments[0];this._pts=t,this._orientation=yr.orientation(t)}function xr(){this._edges=new P,this._ocaMap=new pt}function Er(){}function Ir(){this._hasIntersection=!1,this._hasProper=!1,this._hasProperInterior=!1,this._hasInterior=!1,this._properIntersectionPoint=null,this._li=null,this._isSelfIntersection=null,this.numIntersections=0,this.numInteriorIntersections=0,this.numProperIntersections=0,this.numTests=0;var t=arguments[0];this._li=t}function Nr(){this._bufParams=null,this._workingPrecisionModel=null,this._workingNoder=null,this._geomFact=null,this._graph=null,this._edgeList=new xr;var t=arguments[0];this._bufParams=t}function Cr(){this._li=new fe,this._segStrings=null;var t=arguments[0];this._segStrings=t}function Sr(){this._li=null,this._pt=null,this._originalPt=null,this._ptScaled=null,this._p0Scaled=null,this._p1Scaled=null,this._scaleFactor=null,this._minx=null,this._maxx=null,this._miny=null,this._maxy=null,this._corner=new Array(4).fill(null),this._safeEnv=null;var t=arguments[0],e=arguments[1],n=arguments[2];if(this._originalPt=t,this._pt=t,this._scaleFactor=e,this._li=n,e<=0)throw new i("Scale factor must be non-zero");1!==e&&(this._pt=new E(this.scale(t.x),this.scale(t.y)),this._p0Scaled=new E,this._p1Scaled=new E),this.initCorners(this._pt)}function Lr(){this._index=null;var t=arguments[0];this._index=t}function wr(){nn.apply(this),this._hotPixel=null,this._parentEdge=null,this._hotPixelVertexIndex=null,this._isNodeAdded=!1;var t=arguments[0],e=arguments[1],n=arguments[2];this._hotPixel=t,this._parentEdge=e,this._hotPixelVertexIndex=n}function Rr(){this._li=null,this._interiorIntersections=null;var t=arguments[0];this._li=t,this._interiorIntersections=new P}function Tr(){this._pm=null,this._li=null,this._scaleFactor=null,this._noder=null,this._pointSnapper=null,this._nodedSegStrings=null;var t=arguments[0];this._pm=t,this._li=new fe,this._li.setPrecisionModel(t),this._scaleFactor=t.getScale()}function Pr(){if(this._argGeom=null,this._distance=null,this._bufParams=new er,this._resultGeometry=null,this._saveException=null,1===arguments.length){var t=arguments[0];this._argGeom=t}else if(2===arguments.length){var e=arguments[0],n=arguments[1];this._argGeom=e,this._bufParams=n}}e($i.prototype,{isSimpleMultiPoint:function(t){if(t.isEmpty())return!0;for(var e=new yt,n=0;n<t.getNumGeometries();n++){var i=t.getGeometryN(n).getCoordinate();if(e.contains(i))return this._nonSimpleLocation=i,!1;e.add(i)}return!0},isSimplePolygonal:function(t){for(var e=be.getLines(t).iterator();e.hasNext();){var n=e.next();if(!this.isSimpleLinearGeometry(n))return!1}return!0},hasClosedEndpointIntersection:function(t){for(var e=new pt,n=t.getEdgeIterator();n.hasNext();){var i=n.next(),r=(i.getMaximumSegmentIndex(),i.isClosed()),s=i.getCoordinate(0);this.addEndpoint(e,s,r);var o=i.getCoordinate(i.getNumPoints()-1);this.addEndpoint(e,o,r)}for(n=e.values().iterator();n.hasNext();){var a=n.next();if(a.isClosed&&2!==a.degree)return this._nonSimpleLocation=a.getCoordinate(),!0}return!1},getNonSimpleLocation:function(){return this._nonSimpleLocation},isSimpleLinearGeometry:function(t){if(t.isEmpty())return!0;var e=new ni(0,t),n=new fe,i=e.computeSelfNodes(n,!0);return!i.hasIntersection()||(i.hasProperIntersection()?(this._nonSimpleLocation=i.getProperIntersectionPoint(),!1):!this.hasNonEndpointIntersection(e)&&(!this._isClosedEndpointsInInterior||!this.hasClosedEndpointIntersection(e)))},hasNonEndpointIntersection:function(t){for(var e=t.getEdgeIterator();e.hasNext();)for(var n=e.next(),i=n.getMaximumSegmentIndex(),r=n.getEdgeIntersectionList().iterator();r.hasNext();){var s=r.next();if(!s.isEndPoint(i))return this._nonSimpleLocation=s.getCoordinate(),!0}return!1},addEndpoint:function(t,e,n){var i=t.get(e);null===i&&(i=new tr(e),t.put(e,i)),i.addEndpoint(n)},computeSimple:function(t){return this._nonSimpleLocation=null,!!t.isEmpty()||(t instanceof At?this.isSimpleLinearGeometry(t):t instanceof wt?this.isSimpleLinearGeometry(t):t instanceof zt?this.isSimpleMultiPoint(t):N(t,Bt)?this.isSimplePolygonal(t):!(t instanceof Lt)||this.isSimpleGeometryCollection(t))},isSimple:function(){return this._nonSimpleLocation=null,this.computeSimple(this._inputGeom)},isSimpleGeometryCollection:function(t){for(var e=0;e<t.getNumGeometries();e++){var n=t.getGeometryN(e);if(!this.computeSimple(n))return!1}return!0},interfaces_:function(){return[]},getClass:function(){return $i}}),$i.isSimple=function(){return 1===arguments.length?new $i(arguments[0]).isSimple():2===arguments.length?new $i(arguments[0],arguments[1]).isSimple():void 0},e(tr.prototype,{addEndpoint:function(t){this.degree++,this.isClosed|=t},getCoordinate:function(){return this.pt},interfaces_:function(){return[]},getClass:function(){return tr}}),$i.EndpointInfo=tr,e(er.prototype,{getEndCapStyle:function(){return this._endCapStyle},isSingleSided:function(){return this._isSingleSided},setQuadrantSegments:function(t){this._quadrantSegments=t,0===this._quadrantSegments&&(this._joinStyle=er.JOIN_BEVEL),this._quadrantSegments<0&&(this._joinStyle=er.JOIN_MITRE,this._mitreLimit=Math.abs(this._quadrantSegments)),t<=0&&(this._quadrantSegments=1),this._joinStyle!==er.JOIN_ROUND&&(this._quadrantSegments=er.DEFAULT_QUADRANT_SEGMENTS)},getJoinStyle:function(){return this._joinStyle},setJoinStyle:function(t){this._joinStyle=t},setSimplifyFactor:function(t){this._simplifyFactor=t<0?0:t},getSimplifyFactor:function(){return this._simplifyFactor},getQuadrantSegments:function(){return this._quadrantSegments},setEndCapStyle:function(t){this._endCapStyle=t},getMitreLimit:function(){return this._mitreLimit},setMitreLimit:function(t){this._mitreLimit=t},setSingleSided:function(t){this._isSingleSided=t},interfaces_:function(){return[]},getClass:function(){return er}}),er.bufferDistanceError=function(t){var e=Math.PI/2/t;return 1-Math.cos(e/2)},er.CAP_ROUND=1,er.CAP_FLAT=2,er.CAP_SQUARE=3,er.JOIN_ROUND=1,er.JOIN_MITRE=2,er.JOIN_BEVEL=3,er.DEFAULT_QUADRANT_SEGMENTS=8,er.DEFAULT_MITRE_LIMIT=5,er.DEFAULT_SIMPLIFY_FACTOR=.01,e(nr.prototype,{getCoordinate:function(){return this._minCoord},getRightmostSide:function(t,e){var n=this.getRightmostSideOfSegment(t,e);return n<0&&(n=this.getRightmostSideOfSegment(t,e-1)),n<0&&(this._minCoord=null,this.checkForRightmostCoordinate(t)),n},findRightmostEdgeAtVertex:function(){var t=this._minDe.getEdge().getCoordinates();x.isTrue(this._minIndex>0&&this._minIndex<t.length,"rightmost point expected to be interior vertex of edge");var e=t[this._minIndex-1],n=t[this._minIndex+1],i=z.index(this._minCoord,n,e),r=!1;e.y<this._minCoord.y&&n.y<this._minCoord.y&&i===z.COUNTERCLOCKWISE?r=!0:e.y>this._minCoord.y&&n.y>this._minCoord.y&&i===z.CLOCKWISE&&(r=!0),r&&(this._minIndex=this._minIndex-1)},getRightmostSideOfSegment:function(t,e){var n=t.getEdge().getCoordinates();if(e<0||e+1>=n.length)return-1;if(n[e].y===n[e+1].y)return-1;var i=Dn.LEFT;return n[e].y<n[e+1].y&&(i=Dn.RIGHT),i},getEdge:function(){return this._orientedDe},checkForRightmostCoordinate:function(t){for(var e=t.getEdge().getCoordinates(),n=0;n<e.length-1;n++)(null===this._minCoord||e[n].x>this._minCoord.x)&&(this._minDe=t,this._minIndex=n,this._minCoord=e[n])},findRightmostEdgeAtNode:function(){var t=this._minDe.getNode().getEdges();this._minDe=t.getRightmostEdge(),this._minDe.isForward()||(this._minDe=this._minDe.getSym(),this._minIndex=this._minDe.getEdge().getCoordinates().length-1)},findEdge:function(t){for(var e=t.iterator();e.hasNext();){var n=e.next();n.isForward()&&this.checkForRightmostCoordinate(n)}x.isTrue(0!==this._minIndex||this._minCoord.equals(this._minDe.getCoordinate()),"inconsistency in rightmost processing"),0===this._minIndex?this.findRightmostEdgeAtNode():this.findRightmostEdgeAtVertex(),this._orientedDe=this._minDe,this.getRightmostSide(this._minDe,this._minIndex)===Dn.LEFT&&(this._orientedDe=this._minDe.getSym())},interfaces_:function(){return[]},getClass:function(){return nr}}),ir.prototype.addLast=function(t){this.array_.push(t)},ir.prototype.removeFirst=function(){return this.array_.shift()},ir.prototype.isEmpty=function(){return 0===this.array_.length},e(rr.prototype,{clearVisitedEdges:function(){for(var t=this._dirEdgeList.iterator();t.hasNext();){t.next().setVisited(!1)}},getRightmostCoordinate:function(){return this._rightMostCoord},computeNodeDepth:function(t){for(var e=null,n=t.getEdges().iterator();n.hasNext();){if((i=n.next()).isVisited()||i.getSym().isVisited()){e=i;break}}if(null===e)throw new Jn("unable to find edge to compute depths at "+t.getCoordinate());t.getEdges().computeDepths(e);for(n=t.getEdges().iterator();n.hasNext();){var i;(i=n.next()).setVisited(!0),this.copySymDepths(i)}},computeDepth:function(t){this.clearVisitedEdges();var e=this._finder.getEdge();e.getNode(),e.getLabel();e.setEdgeDepths(Dn.RIGHT,t),this.copySymDepths(e),this.computeDepths(e)},create:function(t){this.addReachable(t),this._finder.findEdge(this._dirEdgeList),this._rightMostCoord=this._finder.getCoordinate()},findResultEdges:function(){for(var t=this._dirEdgeList.iterator();t.hasNext();){var e=t.next();e.getDepth(Dn.RIGHT)>=1&&e.getDepth(Dn.LEFT)<=0&&!e.isInteriorAreaEdge()&&e.setInResult(!0)}},computeDepths:function(t){var e=new ut,n=new ir,i=t.getNode();for(n.addLast(i),e.add(i),t.setVisited(!0);!n.isEmpty();){var r=n.removeFirst();e.add(r),this.computeNodeDepth(r);for(var s=r.getEdges().iterator();s.hasNext();){var o=s.next().getSym();if(!o.isVisited()){var a=o.getNode();e.contains(a)||(n.addLast(a),e.add(a))}}}},compareTo:function(t){var e=t;return this._rightMostCoord.x<e._rightMostCoord.x?-1:this._rightMostCoord.x>e._rightMostCoord.x?1:0},getEnvelope:function(){if(null===this._env){for(var t=new M,e=this._dirEdgeList.iterator();e.hasNext();)for(var n=e.next().getEdge().getCoordinates(),i=0;i<n.length-1;i++)t.expandToInclude(n[i]);this._env=t}return this._env},addReachable:function(t){var e=new je;for(e.add(t);!e.empty();){var n=e.pop();this.add(n,e)}},copySymDepths:function(t){var e=t.getSym();e.setDepth(Dn.LEFT,t.getDepth(Dn.RIGHT)),e.setDepth(Dn.RIGHT,t.getDepth(Dn.LEFT))},add:function(t,e){t.setVisited(!0),this._nodes.add(t);for(var n=t.getEdges().iterator();n.hasNext();){var i=n.next();this._dirEdgeList.add(i);var r=i.getSym().getNode();r.isVisited()||e.push(r)}},getNodes:function(){return this._nodes},getDirectedEdges:function(){return this._dirEdgeList},interfaces_:function(){return[g]},getClass:function(){return rr}}),e(sr.prototype,{computeRing:function(){if(null!==this._ring)return null;for(var t=new Array(this._pts.size()).fill(null),e=0;e<this._pts.size();e++)t[e]=this._pts.get(e);this._ring=this._geometryFactory.createLinearRing(t),this._isHole=z.isCCW(this._ring.getCoordinates())},isIsolated:function(){return 1===this._label.getGeometryCount()},computePoints:function(t){this._startDe=t;var e=t,n=!0;do{if(null===e)throw new Jn("Found null DirectedEdge");if(e.getEdgeRing()===this)throw new Jn("Directed Edge visited twice during ring-building at "+e.getCoordinate());this._edges.add(e);var i=e.getLabel();x.isTrue(i.isArea()),this.mergeLabel(i),this.addPoints(e.getEdge(),e.isForward(),n),n=!1,this.setEdgeRing(e,this),e=this.getNext(e)}while(e!==this._startDe)},getLinearRing:function(){return this._ring},getCoordinate:function(t){return this._pts.get(t)},computeMaxNodeDegree:function(){this._maxNodeDegree=0;var t=this._startDe;do{var e=t.getNode().getEdges().getOutgoingDegree(this);e>this._maxNodeDegree&&(this._maxNodeDegree=e),t=this.getNext(t)}while(t!==this._startDe);this._maxNodeDegree*=2},addPoints:function(t,e,n){var i=t.getCoordinates();if(e){var r=1;n&&(r=0);for(var s=r;s<i.length;s++)this._pts.add(i[s])}else{r=i.length-2;n&&(r=i.length-1);for(s=r;s>=0;s--)this._pts.add(i[s])}},isHole:function(){return this._isHole},setInResult:function(){var t=this._startDe;do{t.getEdge().setInResult(!0),t=t.getNext()}while(t!==this._startDe)},containsPoint:function(t){var e=this.getLinearRing();if(!e.getEnvelopeInternal().contains(t))return!1;if(!qe.isInRing(t,e.getCoordinates()))return!1;for(var n=this._holes.iterator();n.hasNext();){if(n.next().containsPoint(t))return!1}return!0},addHole:function(t){this._holes.add(t)},isShell:function(){return null===this._shell},getLabel:function(){return this._label},getEdges:function(){return this._edges},getMaxNodeDegree:function(){return this._maxNodeDegree<0&&this.computeMaxNodeDegree(),this._maxNodeDegree},getShell:function(){return this._shell},mergeLabel:function(){if(1===arguments.length){var t=arguments[0];this.mergeLabel(t,0),this.mergeLabel(t,1)}else if(2===arguments.length){var e=arguments[0],n=arguments[1],i=e.getLocation(n,Dn.RIGHT);if(i===de.NONE)return null;if(this._label.getLocation(n)===de.NONE)return this._label.setLocation(n,i),null}},setShell:function(t){this._shell=t,null!==t&&t.addHole(this)},toPolygon:function(t){for(var e=new Array(this._holes.size()).fill(null),n=0;n<this._holes.size();n++)e[n]=this._holes.get(n).getLinearRing();return t.createPolygon(this.getLinearRing(),e)},interfaces_:function(){return[]},getClass:function(){return sr}}),v(or,sr),e(or.prototype,{setEdgeRing:function(t,e){t.setMinEdgeRing(e)},getNext:function(t){return t.getNextMin()},interfaces_:function(){return[]},getClass:function(){return or}}),v(ar,sr),e(ar.prototype,{buildMinimalRings:function(){var t=new P,e=this._startDe;do{if(null===e.getMinEdgeRing()){var n=new or(e,this._geometryFactory);t.add(n)}e=e.getNext()}while(e!==this._startDe);return t},setEdgeRing:function(t,e){t.setEdgeRing(e)},linkDirectedEdgesForMinimalEdgeRings:function(){var t=this._startDe;do{t.getNode().getEdges().linkMinimalDirectedEdges(this),t=t.getNext()}while(t!==this._startDe)},getNext:function(t){return t.getNext()},interfaces_:function(){return[]},getClass:function(){return ar}}),e(ur.prototype,{sortShellsAndHoles:function(t,e,n){for(var i=t.iterator();i.hasNext();){var r=i.next();r.isHole()?n.add(r):e.add(r)}},computePolygons:function(t){for(var e=new P,n=t.iterator();n.hasNext();){var i=n.next().toPolygon(this._geometryFactory);e.add(i)}return e},placeFreeHoles:function(t,e){for(var n=e.iterator();n.hasNext();){var i=n.next();if(null===i.getShell()){var r=this.findEdgeRingContaining(i,t);if(null===r)throw new Jn("unable to assign hole to a shell",i.getCoordinate(0));i.setShell(r)}}},buildMinimalEdgeRings:function(t,e,n){for(var i=new P,r=t.iterator();r.hasNext();){var s=r.next();if(s.getMaxNodeDegree()>2){s.linkDirectedEdgesForMinimalEdgeRings();var o=s.buildMinimalRings(),a=this.findShell(o);null!==a?(this.placePolygonHoles(a,o),e.add(a)):n.addAll(o)}else i.add(s)}return i},containsPoint:function(t){for(var e=this._shellList.iterator();e.hasNext();){if(e.next().containsPoint(t))return!0}return!1},buildMaximalEdgeRings:function(t){for(var e=new P,n=t.iterator();n.hasNext();){var i=n.next();if(i.isInResult()&&i.getLabel().isArea()&&null===i.getEdgeRing()){var r=new ar(i,this._geometryFactory);e.add(r),r.setInResult()}}return e},placePolygonHoles:function(t,e){for(var n=e.iterator();n.hasNext();){var i=n.next();i.isHole()&&i.setShell(t)}},getPolygons:function(){return this.computePolygons(this._shellList)},findEdgeRingContaining:function(t,e){for(var n=t.getLinearRing(),i=n.getEnvelopeInternal(),r=n.getCoordinateN(0),s=null,o=null,a=e.iterator();a.hasNext();){var u=a.next(),l=u.getLinearRing(),h=l.getEnvelopeInternal();null!==s&&(o=s.getLinearRing().getEnvelopeInternal());var c=!1;h.contains(i)&&qe.isInRing(r,l.getCoordinates())&&(c=!0),c&&(null===s||o.contains(h))&&(s=u)}return s},findShell:function(t){for(var e=0,n=null,i=t.iterator();i.hasNext();){var r=i.next();r.isHole()||(n=r,e++)}return x.isTrue(e<=1,"found two shells in MinimalEdgeRing list"),n},add:function(){if(1===arguments.length){var t=arguments[0];this.add(t.getEdgeEnds(),t.getNodes())}else if(2===arguments.length){var e=arguments[0],n=arguments[1];ei.linkResultDirectedEdges(n);var i=this.buildMaximalEdgeRings(e),r=new P,s=this.buildMinimalEdgeRings(i,this._shellList,r);this.sortShellsAndHoles(s,this._shellList,r),this.placeFreeHoles(this._shellList,r)}},interfaces_:function(){return[]},getClass:function(){return ur}}),e(lr.prototype,{isDeletable:function(t,e,n,i){var r=this._inputLine[t],s=this._inputLine[e],o=this._inputLine[n];return!!this.isConcave(r,s,o)&&(!!this.isShallow(r,s,o,i)&&this.isShallowSampled(r,s,t,n,i))},deleteShallowConcavities:function(){for(var t=1,e=(this._inputLine.length,this.findNextNonDeletedIndex(t)),n=this.findNextNonDeletedIndex(e),i=!1;n<this._inputLine.length;){var r=!1;this.isDeletable(t,e,n,this._distanceTol)&&(this._isDeleted[e]=lr.DELETE,r=!0,i=!0),t=r?n:e,e=this.findNextNonDeletedIndex(t),n=this.findNextNonDeletedIndex(e)}return i},isShallowConcavity:function(t,e,n,i){return z.index(t,e,n)===this._angleOrientation&&X.pointToSegment(e,t,n)<i},isShallowSampled:function(t,e,n,i,r){var s=Math.trunc((i-n)/lr.NUM_PTS_TO_CHECK);s<=0&&(s=1);for(var o=n;o<i;o+=s)if(!this.isShallow(t,e,this._inputLine[o],r))return!1;return!0},isConcave:function(t,e,n){var i=z.index(t,e,n)===this._angleOrientation;return i},simplify:function(t){this._distanceTol=Math.abs(t),t<0&&(this._angleOrientation=z.CLOCKWISE),this._isDeleted=new Array(this._inputLine.length).fill(null);var e=!1;do{e=this.deleteShallowConcavities()}while(e);return this.collapseLine()},findNextNonDeletedIndex:function(t){for(var e=t+1;e<this._inputLine.length&&this._isDeleted[e]===lr.DELETE;)e++;return e},isShallow:function(t,e,n,i){return X.pointToSegment(e,t,n)<i},collapseLine:function(){for(var t=new b,e=0;e<this._inputLine.length;e++)this._isDeleted[e]!==lr.DELETE&&t.add(this._inputLine[e]);return t.toCoordinateArray()},interfaces_:function(){return[]},getClass:function(){return lr}}),lr.simplify=function(t,e){return new lr(t).simplify(e)},lr.INIT=0,lr.DELETE=1,lr.KEEP=1,lr.NUM_PTS_TO_CHECK=10,e(hr.prototype,{getCoordinates:function(){return this._ptList.toArray(hr.COORDINATE_ARRAY_TYPE)},setPrecisionModel:function(t){this._precisionModel=t},addPt:function(t){var e=new E(t);if(this._precisionModel.makePrecise(e),this.isRedundant(e))return null;this._ptList.add(e)},reverse:function(){},addPts:function(t,e){if(e)for(var n=0;n<t.length;n++)this.addPt(t[n]);else for(n=t.length-1;n>=0;n--)this.addPt(t[n])},isRedundant:function(t){if(this._ptList.size()<1)return!1;var e=this._ptList.get(this._ptList.size()-1);return t.distance(e)<this._minimimVertexDistance},toString:function(){return(new se).createLineString(this.getCoordinates()).toString()},closeRing:function(){if(this._ptList.size()<1)return null;var t=new E(this._ptList.get(0)),e=this._ptList.get(this._ptList.size()-1);if(this._ptList.size()>=2&&this._ptList.get(this._ptList.size()-2),t.equals(e))return null;this._ptList.add(t)},setMinimumVertexDistance:function(t){this._minimimVertexDistance=t},interfaces_:function(){return[]},getClass:function(){return hr}}),hr.COORDINATE_ARRAY_TYPE=new Array(0).fill(null),e(cr.prototype,{addNextSegment:function(t,e){if(this._s0=this._s1,this._s1=this._s2,this._s2=t,this._seg0.setCoordinates(this._s0,this._s1),this.computeOffsetSegment(this._seg0,this._side,this._distance,this._offset0),this._seg1.setCoordinates(this._s1,this._s2),this.computeOffsetSegment(this._seg1,this._side,this._distance,this._offset1),this._s1.equals(this._s2))return null;var n=z.index(this._s0,this._s1,this._s2),i=n===z.CLOCKWISE&&this._side===Dn.LEFT||n===z.COUNTERCLOCKWISE&&this._side===Dn.RIGHT;0===n?this.addCollinear(e):i?this.addOutsideTurn(n,e):this.addInsideTurn(n,e)},addLineEndCap:function(t,e){var n=new ge(t,e),i=new ge;this.computeOffsetSegment(n,Dn.LEFT,this._distance,i);var r=new ge;this.computeOffsetSegment(n,Dn.RIGHT,this._distance,r);var s=e.x-t.x,o=e.y-t.y,a=Math.atan2(o,s);switch(this._bufParams.getEndCapStyle()){case er.CAP_ROUND:this._segList.addPt(i.p1),this.addDirectedFillet(e,a+Math.PI/2,a-Math.PI/2,z.CLOCKWISE,this._distance),this._segList.addPt(r.p1);break;case er.CAP_FLAT:this._segList.addPt(i.p1),this._segList.addPt(r.p1);break;case er.CAP_SQUARE:var u=new E;u.x=Math.abs(this._distance)*Math.cos(a),u.y=Math.abs(this._distance)*Math.sin(a);var l=new E(i.p1.x+u.x,i.p1.y+u.y),h=new E(r.p1.x+u.x,r.p1.y+u.y);this._segList.addPt(l),this._segList.addPt(h)}},getCoordinates:function(){return this._segList.getCoordinates()},addMitreJoin:function(t,e,n,i){var r=!0,s=null;try{s=k.intersection(e.p0,e.p1,n.p0,n.p1),(i<=0?1:s.distance(t)/Math.abs(i))>this._bufParams.getMitreLimit()&&(r=!1)}catch(t){if(!(t instanceof A))throw t;s=new E(0,0),r=!1}r?this._segList.addPt(s):this.addLimitedMitreJoin(e,n,i,this._bufParams.getMitreLimit())},addOutsideTurn:function(t,e){if(this._offset0.p1.distance(this._offset1.p0)<this._distance*cr.OFFSET_SEGMENT_SEPARATION_FACTOR)return this._segList.addPt(this._offset0.p1),null;this._bufParams.getJoinStyle()===er.JOIN_MITRE?this.addMitreJoin(this._s1,this._offset0,this._offset1,this._distance):this._bufParams.getJoinStyle()===er.JOIN_BEVEL?this.addBevelJoin(this._offset0,this._offset1):(e&&this._segList.addPt(this._offset0.p1),this.addCornerFillet(this._s1,this._offset0.p1,this._offset1.p0,t,this._distance),this._segList.addPt(this._offset1.p0))},createSquare:function(t){this._segList.addPt(new E(t.x+this._distance,t.y+this._distance)),this._segList.addPt(new E(t.x+this._distance,t.y-this._distance)),this._segList.addPt(new E(t.x-this._distance,t.y-this._distance)),this._segList.addPt(new E(t.x-this._distance,t.y+this._distance)),this._segList.closeRing()},addSegments:function(t,e){this._segList.addPts(t,e)},addFirstSegment:function(){this._segList.addPt(this._offset1.p0)},addCornerFillet:function(t,e,n,i,r){var s=e.x-t.x,o=e.y-t.y,a=Math.atan2(o,s),u=n.x-t.x,l=n.y-t.y,h=Math.atan2(l,u);i===z.CLOCKWISE?a<=h&&(a+=2*Math.PI):a>=h&&(a-=2*Math.PI),this._segList.addPt(e),this.addDirectedFillet(t,a,h,i,r),this._segList.addPt(n)},addLastSegment:function(){this._segList.addPt(this._offset1.p1)},initSideSegments:function(t,e,n){this._s1=t,this._s2=e,this._side=n,this._seg1.setCoordinates(t,e),this.computeOffsetSegment(this._seg1,n,this._distance,this._offset1)},addLimitedMitreJoin:function(t,e,n,i){var r=this._seg0.p1,s=pe.angle(r,this._seg0.p0),o=(pe.angle(r,this._seg1.p1),pe.angleBetweenOriented(this._seg0.p0,r,this._seg1.p1)/2),a=pe.normalize(s+o),u=pe.normalize(a+Math.PI),l=i*n,h=n-l*Math.abs(Math.sin(o)),c=new ge(r,new E(r.x+l*Math.cos(u),r.y+l*Math.sin(u))),f=c.pointAlongOffset(1,h),g=c.pointAlongOffset(1,-h);this._side===Dn.LEFT?(this._segList.addPt(f),this._segList.addPt(g)):(this._segList.addPt(g),this._segList.addPt(f))},addDirectedFillet:function(t,e,n,i,r){var s=i===z.CLOCKWISE?-1:1,o=Math.abs(e-n),a=Math.trunc(o/this._filletAngleQuantum+.5);if(a<1)return null;var u;u=o/a;for(var l=0,h=new E;l<o;){var c=e+s*l;h.x=t.x+r*Math.cos(c),h.y=t.y+r*Math.sin(c),this._segList.addPt(h),l+=u}},computeOffsetSegment:function(t,e,n,i){var r=e===Dn.LEFT?1:-1,s=t.p1.x-t.p0.x,o=t.p1.y-t.p0.y,a=Math.sqrt(s*s+o*o),u=r*n*s/a,l=r*n*o/a;i.p0.x=t.p0.x-l,i.p0.y=t.p0.y+u,i.p1.x=t.p1.x-l,i.p1.y=t.p1.y+u},addInsideTurn:function(t,e){if(this._li.computeIntersection(this._offset0.p0,this._offset0.p1,this._offset1.p0,this._offset1.p1),this._li.hasIntersection())this._segList.addPt(this._li.getIntersection(0));else if(this._hasNarrowConcaveAngle=!0,this._offset0.p1.distance(this._offset1.p0)<this._distance*cr.INSIDE_TURN_VERTEX_SNAP_DISTANCE_FACTOR)this._segList.addPt(this._offset0.p1);else{if(this._segList.addPt(this._offset0.p1),this._closingSegLengthFactor>0){var n=new E((this._closingSegLengthFactor*this._offset0.p1.x+this._s1.x)/(this._closingSegLengthFactor+1),(this._closingSegLengthFactor*this._offset0.p1.y+this._s1.y)/(this._closingSegLengthFactor+1));this._segList.addPt(n);var i=new E((this._closingSegLengthFactor*this._offset1.p0.x+this._s1.x)/(this._closingSegLengthFactor+1),(this._closingSegLengthFactor*this._offset1.p0.y+this._s1.y)/(this._closingSegLengthFactor+1));this._segList.addPt(i)}else this._segList.addPt(this._s1);this._segList.addPt(this._offset1.p0)}},createCircle:function(t){var e=new E(t.x+this._distance,t.y);this._segList.addPt(e),this.addDirectedFillet(t,0,2*Math.PI,-1,this._distance),this._segList.closeRing()},addBevelJoin:function(t,e){this._segList.addPt(t.p1),this._segList.addPt(e.p0)},init:function(t){this._distance=t,this._maxCurveSegmentError=t*(1-Math.cos(this._filletAngleQuantum/2)),this._segList=new hr,this._segList.setPrecisionModel(this._precisionModel),this._segList.setMinimumVertexDistance(t*cr.CURVE_VERTEX_SNAP_DISTANCE_FACTOR)},addCollinear:function(t){this._li.computeIntersection(this._s0,this._s1,this._s1,this._s2),this._li.getIntersectionNum()>=2&&(this._bufParams.getJoinStyle()===er.JOIN_BEVEL||this._bufParams.getJoinStyle()===er.JOIN_MITRE?(t&&this._segList.addPt(this._offset0.p1),this._segList.addPt(this._offset1.p0)):this.addCornerFillet(this._s1,this._offset0.p1,this._offset1.p0,z.CLOCKWISE,this._distance))},closeRing:function(){this._segList.closeRing()},hasNarrowConcaveAngle:function(){return this._hasNarrowConcaveAngle},interfaces_:function(){return[]},getClass:function(){return cr}}),cr.OFFSET_SEGMENT_SEPARATION_FACTOR=.001,cr.INSIDE_TURN_VERTEX_SNAP_DISTANCE_FACTOR=.001,cr.CURVE_VERTEX_SNAP_DISTANCE_FACTOR=1e-6,cr.MAX_CLOSING_SEG_LEN_FACTOR=80,e(fr.prototype,{getOffsetCurve:function(t,e){if(this._distance=e,0===e)return null;var n=e<0,i=Math.abs(e),r=this.getSegGen(i);t.length<=1?this.computePointCurve(t[0],r):this.computeOffsetCurve(t,n,r);var s=r.getCoordinates();return n&&nt.reverse(s),s},computeSingleSidedBufferCurve:function(t,e,n){var i=this.simplifyTolerance(this._distance);if(e){n.addSegments(t,!0);var r=lr.simplify(t,-i),s=r.length-1;n.initSideSegments(r[s],r[s-1],Dn.LEFT),n.addFirstSegment();for(var o=s-2;o>=0;o--)n.addNextSegment(r[o],!0)}else{n.addSegments(t,!1);var a=lr.simplify(t,i),u=a.length-1;n.initSideSegments(a[0],a[1],Dn.LEFT),n.addFirstSegment();for(o=2;o<=u;o++)n.addNextSegment(a[o],!0)}n.addLastSegment(),n.closeRing()},computeRingBufferCurve:function(t,e,n){var i=this.simplifyTolerance(this._distance);e===Dn.RIGHT&&(i=-i);var r=lr.simplify(t,i),s=r.length-1;n.initSideSegments(r[s-1],r[0],e);for(var o=1;o<=s;o++){var a=1!==o;n.addNextSegment(r[o],a)}n.closeRing()},computeLineBufferCurve:function(t,e){var n=this.simplifyTolerance(this._distance),i=lr.simplify(t,n),r=i.length-1;e.initSideSegments(i[0],i[1],Dn.LEFT);for(var s=2;s<=r;s++)e.addNextSegment(i[s],!0);e.addLastSegment(),e.addLineEndCap(i[r-1],i[r]);var o=lr.simplify(t,-n),a=o.length-1;e.initSideSegments(o[a],o[a-1],Dn.LEFT);for(s=a-2;s>=0;s--)e.addNextSegment(o[s],!0);e.addLastSegment(),e.addLineEndCap(o[1],o[0]),e.closeRing()},computePointCurve:function(t,e){switch(this._bufParams.getEndCapStyle()){case er.CAP_ROUND:e.createCircle(t);break;case er.CAP_SQUARE:e.createSquare(t)}},getLineCurve:function(t,e){if(this._distance=e,e<0&&!this._bufParams.isSingleSided())return null;if(0===e)return null;var n=Math.abs(e),i=this.getSegGen(n);if(t.length<=1)this.computePointCurve(t[0],i);else if(this._bufParams.isSingleSided()){var r=e<0;this.computeSingleSidedBufferCurve(t,r,i)}else this.computeLineBufferCurve(t,i);return i.getCoordinates()},getBufferParameters:function(){return this._bufParams},simplifyTolerance:function(t){return t*this._bufParams.getSimplifyFactor()},getRingCurve:function(t,e,n){if(this._distance=n,t.length<=2)return this.getLineCurve(t,n);if(0===n)return fr.copyCoordinates(t);var i=this.getSegGen(n);return this.computeRingBufferCurve(t,e,i),i.getCoordinates()},computeOffsetCurve:function(t,e,n){var i=this.simplifyTolerance(this._distance);if(e){var r=lr.simplify(t,-i),s=r.length-1;n.initSideSegments(r[s],r[s-1],Dn.LEFT),n.addFirstSegment();for(var o=s-2;o>=0;o--)n.addNextSegment(r[o],!0)}else{var a=lr.simplify(t,i),u=a.length-1;n.initSideSegments(a[0],a[1],Dn.LEFT),n.addFirstSegment();for(o=2;o<=u;o++)n.addNextSegment(a[o],!0)}n.addLastSegment()},getSegGen:function(t){return new cr(this._precisionModel,this._bufParams,t)},interfaces_:function(){return[]},getClass:function(){return fr}}),fr.copyCoordinates=function(t){for(var e=new Array(t.length).fill(null),n=0;n<e.length;n++)e[n]=new E(t[n]);return e},e(gr.prototype,{findStabbedSegments:function(){if(1===arguments.length){for(var t=arguments[0],e=new P,n=this._subgraphs.iterator();n.hasNext();){var i=n.next(),r=i.getEnvelope();t.y<r.getMinY()||t.y>r.getMaxY()||this.findStabbedSegments(t,i.getDirectedEdges(),e)}return e}if(3===arguments.length)if(N(arguments[2],w)&&arguments[0]instanceof E&&arguments[1]instanceof $n){var s=arguments[0],o=arguments[1],a=arguments[2],u=o.getEdge().getCoordinates();for(n=0;n<u.length-1;n++){if(this._seg.p0=u[n],this._seg.p1=u[n+1],this._seg.p0.y>this._seg.p1.y&&this._seg.reverse(),!(Math.max(this._seg.p0.x,this._seg.p1.x)<s.x||this._seg.isHorizontal()||s.y<this._seg.p0.y||s.y>this._seg.p1.y||z.index(this._seg.p0,this._seg.p1,s)===z.RIGHT)){var l=o.getDepth(Dn.LEFT);this._seg.p0.equals(u[n])||(l=o.getDepth(Dn.RIGHT));var h=new dr(this._seg,l);a.add(h)}}}else if(N(arguments[2],w)&&arguments[0]instanceof E&&N(arguments[1],w)){var c=arguments[0],f=arguments[1],g=arguments[2];for(n=f.iterator();n.hasNext();){var d=n.next();d.isForward()&&this.findStabbedSegments(c,d,g)}}},getDepth:function(t){var e=this.findStabbedSegments(t);return 0===e.size()?0:Te.min(e)._leftDepth},interfaces_:function(){return[]},getClass:function(){return gr}}),e(dr.prototype,{compareTo:function(t){var e=t;if(this._upwardSeg.minX()>=e._upwardSeg.maxX())return 1;if(this._upwardSeg.maxX()<=e._upwardSeg.minX())return-1;var n=this._upwardSeg.orientationIndex(e._upwardSeg);return 0!==n?n:0!==(n=-1*e._upwardSeg.orientationIndex(this._upwardSeg))?n:this._upwardSeg.compareTo(e._upwardSeg)},compareX:function(t,e){var n=t.p0.compareTo(e.p0);return 0!==n?n:t.p1.compareTo(e.p1)},toString:function(){return this._upwardSeg.toString()},interfaces_:function(){return[g]},getClass:function(){return dr}}),gr.DepthSegment=dr,e(_r.prototype,{addPoint:function(t){if(this._distance<=0)return null;var e=t.getCoordinates(),n=this._curveBuilder.getLineCurve(e,this._distance);this.addCurve(n,de.EXTERIOR,de.INTERIOR)},addPolygon:function(t){var e=this._distance,n=Dn.LEFT;this._distance<0&&(e=-this._distance,n=Dn.RIGHT);var i=t.getExteriorRing(),r=nt.removeRepeatedPoints(i.getCoordinates());if(this._distance<0&&this.isErodedCompletely(i,this._distance))return null;if(this._distance<=0&&r.length<3)return null;this.addPolygonRing(r,e,n,de.EXTERIOR,de.INTERIOR);for(var s=0;s<t.getNumInteriorRing();s++){var o=t.getInteriorRingN(s),a=nt.removeRepeatedPoints(o.getCoordinates());this._distance>0&&this.isErodedCompletely(o,-this._distance)||this.addPolygonRing(a,e,Dn.opposite(n),de.INTERIOR,de.EXTERIOR)}},isTriangleErodedCompletely:function(t,e){var n=new me(t[0],t[1],t[2]),i=n.inCentre();return X.pointToSegment(i,n.p0,n.p1)<Math.abs(e)},addLineString:function(t){if(this._distance<=0&&!this._curveBuilder.getBufferParameters().isSingleSided())return null;var e=nt.removeRepeatedPoints(t.getCoordinates()),n=this._curveBuilder.getLineCurve(e,this._distance);this.addCurve(n,de.EXTERIOR,de.INTERIOR)},addCurve:function(t,e,n){if(null===t||t.length<2)return null;var i=new Xi(t,new zn(0,de.BOUNDARY,e,n));this._curveList.add(i)},getCurves:function(){return this.add(this._inputGeom),this._curveList},addPolygonRing:function(t,e,n,i,r){if(0===e&&t.length<Yt.MINIMUM_VALID_SIZE)return null;var s=i,o=r;t.length>=Yt.MINIMUM_VALID_SIZE&&z.isCCW(t)&&(s=r,o=i,n=Dn.opposite(n));var a=this._curveBuilder.getRingCurve(t,n,e);this.addCurve(a,s,o)},add:function(t){if(t.isEmpty())return null;if(t instanceof Vt)this.addPolygon(t);else if(t instanceof At)this.addLineString(t);else if(t instanceof Gt)this.addPoint(t);else if(t instanceof zt)this.addCollection(t);else if(t instanceof wt)this.addCollection(t);else if(t instanceof kt)this.addCollection(t);else{if(!(t instanceof Lt))throw new UnsupportedOperationException(t.getClass().getName());this.addCollection(t)}},isErodedCompletely:function(t,e){var n=t.getCoordinates();if(n.length<4)return e<0;if(4===n.length)return this.isTriangleErodedCompletely(n,e);var i=t.getEnvelopeInternal(),r=Math.min(i.getHeight(),i.getWidth());return e<0&&2*Math.abs(e)>r},addCollection:function(t){for(var e=0;e<t.getNumGeometries();e++){var n=t.getGeometryN(e);this.add(n)}},interfaces_:function(){return[]},getClass:function(){return _r}}),e(pr.prototype,{getNextCW:function(t){this.getEdges();var e=this._edgeList.indexOf(t),n=e-1;return 0===e&&(n=this._edgeList.size()-1),this._edgeList.get(n)},propagateSideLabels:function(t){for(var e=de.NONE,n=this.iterator();n.hasNext();){(s=(r=n.next()).getLabel()).isArea(t)&&s.getLocation(t,Dn.LEFT)!==de.NONE&&(e=s.getLocation(t,Dn.LEFT))}if(e===de.NONE)return null;var i=e;for(n=this.iterator();n.hasNext();){var r,s;if((s=(r=n.next()).getLabel()).getLocation(t,Dn.ON)===de.NONE&&s.setLocation(t,Dn.ON,i),s.isArea(t)){var o=s.getLocation(t,Dn.LEFT),a=s.getLocation(t,Dn.RIGHT);if(a!==de.NONE){if(a!==i)throw new Jn("side location conflict",r.getCoordinate());o===de.NONE&&x.shouldNeverReachHere("found single null side (at "+r.getCoordinate()+")"),i=o}else x.isTrue(s.getLocation(t,Dn.LEFT)===de.NONE,"found single null side"),s.setLocation(t,Dn.RIGHT,i),s.setLocation(t,Dn.LEFT,i)}}},getCoordinate:function(){var t=this.iterator();return t.hasNext()?t.next().getCoordinate():null},print:function(t){Y.out.println("EdgeEndStar:   "+this.getCoordinate());for(var e=this.iterator();e.hasNext();){e.next().print(t)}},isAreaLabelsConsistent:function(t){return this.computeEdgeEndLabels(t.getBoundaryNodeRule()),this.checkAreaLabelsConsistent(0)},checkAreaLabelsConsistent:function(t){var e=this.getEdges();if(e.size()<=0)return!0;var n=e.size()-1,i=e.get(n).getLabel().getLocation(t,Dn.LEFT);x.isTrue(i!==de.NONE,"Found unlabelled area edge");for(var r=i,s=this.iterator();s.hasNext();){var o=s.next().getLabel();x.isTrue(o.isArea(t),"Found non-area edge");var a=o.getLocation(t,Dn.LEFT),u=o.getLocation(t,Dn.RIGHT);if(a===u)return!1;if(u!==r)return!1;r=a}return!0},findIndex:function(t){this.iterator();for(var e=0;e<this._edgeList.size();e++){if(this._edgeList.get(e)===t)return e}return-1},iterator:function(){return this.getEdges().iterator()},getEdges:function(){return null===this._edgeList&&(this._edgeList=new P(this._edgeMap.values())),this._edgeList},getLocation:function(t,e,n){return this._ptInAreaLocation[t]===de.NONE&&(this._ptInAreaLocation[t]=Ve.locate(e,n[t].getGeometry())),this._ptInAreaLocation[t]},toString:function(){var t=new F;t.append("EdgeEndStar:   "+this.getCoordinate()),t.append("\n");for(var e=this.iterator();e.hasNext();){var n=e.next();t.append(n),t.append("\n")}return t.toString()},computeEdgeEndLabels:function(t){for(var e=this.iterator();e.hasNext();){e.next().computeLabel(t)}},computeLabelling:function(t){this.computeEdgeEndLabels(t[0].getBoundaryNodeRule()),this.propagateSideLabels(0),this.propagateSideLabels(1);for(var e=[!1,!1],n=this.iterator();n.hasNext();)for(var i=(s=n.next()).getLabel(),r=0;r<2;r++)i.isLine(r)&&i.getLocation(r)===de.BOUNDARY&&(e[r]=!0);for(n=this.iterator();n.hasNext();){var s;for(i=(s=n.next()).getLabel(),r=0;r<2;r++)if(i.isAnyNull(r)){var o=de.NONE;if(e[r])o=de.EXTERIOR;else{var a=s.getCoordinate();o=this.getLocation(r,a,t)}i.setAllLocationsIfNull(r,o)}}},getDegree:function(){return this._edgeMap.size()},insertEdgeEnd:function(t,e){this._edgeMap.put(t,e),this._edgeList=null},interfaces_:function(){return[]},getClass:function(){return pr}}),v(mr,pr),e(mr.prototype,{linkResultDirectedEdges:function(){this.getResultAreaEdges();for(var t=null,e=null,n=this._SCANNING_FOR_INCOMING,i=0;i<this._resultAreaEdgeList.size();i++){var r=this._resultAreaEdgeList.get(i),s=r.getSym();if(r.getLabel().isArea())switch(null===t&&r.isInResult()&&(t=r),n){case this._SCANNING_FOR_INCOMING:if(!s.isInResult())continue;e=s,n=this._LINKING_TO_OUTGOING;break;case this._LINKING_TO_OUTGOING:if(!r.isInResult())continue;e.setNext(r),n=this._SCANNING_FOR_INCOMING}}if(n===this._LINKING_TO_OUTGOING){if(null===t)throw new Jn("no outgoing dirEdge found",this.getCoordinate());x.isTrue(t.isInResult(),"unable to link last incoming dirEdge"),e.setNext(t)}},insert:function(t){var e=t;this.insertEdgeEnd(e,e)},getRightmostEdge:function(){var t=this.getEdges(),e=t.size();if(e<1)return null;var n=t.get(0);if(1===e)return n;var i=t.get(e-1),r=n.getQuadrant(),s=i.getQuadrant();return gn.isNorthern(r)&&gn.isNorthern(s)?n:gn.isNorthern(r)||gn.isNorthern(s)?0!==n.getDy()?n:0!==i.getDy()?i:(x.shouldNeverReachHere("found two horizontal edges incident on node"),null):i},print:function(t){Y.out.println("DirectedEdgeStar: "+this.getCoordinate());for(var e=this.iterator();e.hasNext();){var n=e.next();t.print("out "),n.print(t),t.println(),t.print("in "),n.getSym().print(t),t.println()}},getResultAreaEdges:function(){if(null!==this._resultAreaEdgeList)return this._resultAreaEdgeList;this._resultAreaEdgeList=new P;for(var t=this.iterator();t.hasNext();){var e=t.next();(e.isInResult()||e.getSym().isInResult())&&this._resultAreaEdgeList.add(e)}return this._resultAreaEdgeList},updateLabelling:function(t){for(var e=this.iterator();e.hasNext();){var n=e.next().getLabel();n.setAllLocationsIfNull(0,t.getLocation(0)),n.setAllLocationsIfNull(1,t.getLocation(1))}},linkAllDirectedEdges:function(){this.getEdges();for(var t=null,e=null,n=this._edgeList.size()-1;n>=0;n--){var i=this._edgeList.get(n),r=i.getSym();null===e&&(e=r),null!==t&&r.setNext(t),t=i}e.setNext(t)},computeDepths:function(){if(1===arguments.length){var t=arguments[0],e=this.findIndex(t),n=(t.getLabel(),t.getDepth(Dn.LEFT)),i=t.getDepth(Dn.RIGHT),r=this.computeDepths(e+1,this._edgeList.size(),n);if(this.computeDepths(0,e,r)!==i)throw new Jn("depth mismatch at "+t.getCoordinate())}else if(3===arguments.length){for(var s=arguments[0],o=arguments[1],a=arguments[2],u=s;u<o;u++){var l=this._edgeList.get(u);l.getLabel();l.setEdgeDepths(Dn.RIGHT,a),a=l.getDepth(Dn.LEFT)}return a}},mergeSymLabels:function(){for(var t=this.iterator();t.hasNext();){var e=t.next();e.getLabel().merge(e.getSym().getLabel())}},linkMinimalDirectedEdges:function(t){for(var e=null,n=null,i=this._SCANNING_FOR_INCOMING,r=this._resultAreaEdgeList.size()-1;r>=0;r--){var s=this._resultAreaEdgeList.get(r),o=s.getSym();switch(null===e&&s.getEdgeRing()===t&&(e=s),i){case this._SCANNING_FOR_INCOMING:if(o.getEdgeRing()!==t)continue;n=o,i=this._LINKING_TO_OUTGOING;break;case this._LINKING_TO_OUTGOING:if(s.getEdgeRing()!==t)continue;n.setNextMin(s),i=this._SCANNING_FOR_INCOMING}}i===this._LINKING_TO_OUTGOING&&(x.isTrue(null!==e,"found null for first outgoing dirEdge"),x.isTrue(e.getEdgeRing()===t,"unable to link last incoming dirEdge"),n.setNextMin(e))},getOutgoingDegree:function(){if(0===arguments.length){for(var t=0,e=this.iterator();e.hasNext();){e.next().isInResult()&&t++}return t}if(1===arguments.length){var n=arguments[0];for(t=0,e=this.iterator();e.hasNext();){e.next().getEdgeRing()===n&&t++}return t}},getLabel:function(){return this._label},findCoveredLineEdges:function(){for(var t=de.NONE,e=this.iterator();e.hasNext();){var n=(r=e.next()).getSym();if(!r.isLineEdge()){if(r.isInResult()){t=de.INTERIOR;break}if(n.isInResult()){t=de.EXTERIOR;break}}}if(t===de.NONE)return null;var i=t;for(e=this.iterator();e.hasNext();){var r;n=(r=e.next()).getSym();r.isLineEdge()?r.getEdge().setCovered(i===de.INTERIOR):(r.isInResult()&&(i=de.EXTERIOR),n.isInResult()&&(i=de.INTERIOR))}},computeLabelling:function(t){pr.prototype.computeLabelling.call(this,t),this._label=new zn(de.NONE);for(var e=this.iterator();e.hasNext();)for(var n=e.next().getEdge().getLabel(),i=0;i<2;i++){var r=n.getLocation(i);r!==de.INTERIOR&&r!==de.BOUNDARY||this._label.setLocation(i,de.INTERIOR)}},interfaces_:function(){return[]},getClass:function(){return mr}}),v(vr,ti),e(vr.prototype,{createNode:function(t){return new Kn(t,new mr)},interfaces_:function(){return[]},getClass:function(){return vr}}),e(yr.prototype,{compareTo:function(t){var e=t;return yr.compareOriented(this._pts,this._orientation,e._pts,e._orientation)},interfaces_:function(){return[g]},getClass:function(){return yr}}),yr.orientation=function(t){return 1===nt.increasingDirection(t)},yr.compareOriented=function(t,e,n,i){for(var r=e?1:-1,s=i?1:-1,o=e?t.length:-1,a=i?n.length:-1,u=e?0:t.length-1,l=i?0:n.length-1;;){var h=t[u].compareTo(n[l]);if(0!==h)return h;var c=(u+=r)===o,f=(l+=s)===a;if(c&&!f)return-1;if(!c&&f)return 1;if(c&&f)return 0}},e(xr.prototype,{print:function(t){t.print("MULTILINESTRING ( ");for(var e=0;e<this._edges.size();e++){var n=this._edges.get(e);e>0&&t.print(","),t.print("(");for(var i=n.getCoordinates(),r=0;r<i.length;r++)r>0&&t.print(","),t.print(i[r].x+" "+i[r].y);t.println(")")}t.print(")  ")},addAll:function(t){for(var e=t.iterator();e.hasNext();)this.add(e.next())},findEdgeIndex:function(t){for(var e=0;e<this._edges.size();e++)if(this._edges.get(e).equals(t))return e;return-1},iterator:function(){return this._edges.iterator()},getEdges:function(){return this._edges},get:function(t){return this._edges.get(t)},findEqualEdge:function(t){var e=new yr(t.getCoordinates());return this._ocaMap.get(e)},add:function(t){this._edges.add(t);var e=new yr(t.getCoordinates());this._ocaMap.put(e,t)},interfaces_:function(){return[]},getClass:function(){return xr}}),e(Er.prototype,{processIntersections:function(t,e,n,i){},isDone:function(){},interfaces_:function(){return[]},getClass:function(){return Er}}),e(Ir.prototype,{isTrivialIntersection:function(t,e,n,i){if(t===n&&1===this._li.getIntersectionNum()){if(Ir.isAdjacentSegments(e,i))return!0;if(t.isClosed()){var r=t.size()-1;if(0===e&&i===r||0===i&&e===r)return!0}}return!1},getProperIntersectionPoint:function(){return this._properIntersectionPoint},hasProperInteriorIntersection:function(){return this._hasProperInterior},getLineIntersector:function(){return this._li},hasProperIntersection:function(){return this._hasProper},processIntersections:function(t,e,n,i){if(t===n&&e===i)return null;this.numTests++;var r=t.getCoordinates()[e],s=t.getCoordinates()[e+1],o=n.getCoordinates()[i],a=n.getCoordinates()[i+1];this._li.computeIntersection(r,s,o,a),this._li.hasIntersection()&&(this.numIntersections++,this._li.isInteriorIntersection()&&(this.numInteriorIntersections++,this._hasInterior=!0),this.isTrivialIntersection(t,e,n,i)||(this._hasIntersection=!0,t.addIntersections(this._li,e,0),n.addIntersections(this._li,i,1),this._li.isProper()&&(this.numProperIntersections++,this._hasProper=!0,this._hasProperInterior=!0)))},hasIntersection:function(){return this._hasIntersection},isDone:function(){return!1},hasInteriorIntersection:function(){return this._hasInterior},interfaces_:function(){return[Er]},getClass:function(){return Ir}}),Ir.isAdjacentSegments=function(t,e){return 1===Math.abs(t-e)},e(Nr.prototype,{setWorkingPrecisionModel:function(t){this._workingPrecisionModel=t},insertUniqueEdge:function(t){var e=this._edgeList.findEqualEdge(t);if(null!==e){var n=e.getLabel(),i=t.getLabel();e.isPointwiseEqual(t)||(i=new zn(t.getLabel())).flip(),n.merge(i);var r=Nr.depthDelta(i),s=e.getDepthDelta()+r;e.setDepthDelta(s)}else this._edgeList.add(t),t.setDepthDelta(Nr.depthDelta(t.getLabel()))},buildSubgraphs:function(t,e){for(var n=new P,i=t.iterator();i.hasNext();){var r=i.next(),s=r.getRightmostCoordinate(),o=new gr(n).getDepth(s);r.computeDepth(o),r.findResultEdges(),n.add(r),e.add(r.getDirectedEdges(),r.getNodes())}},createSubgraphs:function(t){for(var e=new P,n=t.getNodes().iterator();n.hasNext();){var i=n.next();if(!i.isVisited()){var r=new rr;r.create(i),e.add(r)}}return Te.sort(e,Te.reverseOrder()),e},createEmptyResultGeometry:function(){return this._geomFact.createPolygon()},getNoder:function(t){if(null!==this._workingNoder)return this._workingNoder;var e=new Ki,n=new fe;return n.setPrecisionModel(t),e.setSegmentIntersector(new Ir(n)),e},buffer:function(t,e){var n=this._workingPrecisionModel;null===n&&(n=t.getPrecisionModel()),this._geomFact=t.getFactory();var i=new _r(t,e,new fr(n,this._bufParams)).getCurves();if(i.size()<=0)return this.createEmptyResultGeometry();this.computeNodedEdges(i,n),this._graph=new ei(new vr),this._graph.addEdges(this._edgeList.getEdges());var r=this.createSubgraphs(this._graph),s=new ur(this._geomFact);this.buildSubgraphs(r,s);var o=s.getPolygons();return o.size()<=0?this.createEmptyResultGeometry():this._geomFact.buildGeometry(o)},computeNodedEdges:function(t,e){var n=this.getNoder(e);n.computeNodes(t);for(var i=n.getNodedSubstrings().iterator();i.hasNext();){var r=i.next(),s=r.getCoordinates();if(2!==s.length||!s[0].equals2D(s[1])){var o=r.getData(),a=new jn(r.getCoordinates(),new zn(o));this.insertUniqueEdge(a)}}},setNoder:function(t){this._workingNoder=t},interfaces_:function(){return[]},getClass:function(){return Nr}}),Nr.depthDelta=function(t){var e=t.getLocation(0,Dn.LEFT),n=t.getLocation(0,Dn.RIGHT);return e===de.INTERIOR&&n===de.EXTERIOR?1:e===de.EXTERIOR&&n===de.INTERIOR?-1:0},Nr.convertSegStrings=function(t){for(var e=new se,n=new P;t.hasNext();){var i=t.next(),r=e.createLineString(i.getCoordinates());n.add(r)}return e.buildGeometry(n)},e(Cr.prototype,{checkEndPtVertexIntersections:function(){if(0===arguments.length)for(var t=this._segStrings.iterator();t.hasNext();){var e=t.next().getCoordinates();this.checkEndPtVertexIntersections(e[0],this._segStrings),this.checkEndPtVertexIntersections(e[e.length-1],this._segStrings)}else if(2===arguments.length){var n=arguments[0];for(t=arguments[1].iterator();t.hasNext();){e=t.next().getCoordinates();for(var i=1;i<e.length-1;i++)if(e[i].equals(n))throw new m("found endpt/interior pt intersection at index "+i+" :pt "+n)}}},checkInteriorIntersections:function(){if(0===arguments.length)for(var t=this._segStrings.iterator();t.hasNext();)for(var e=t.next(),n=this._segStrings.iterator();n.hasNext();){var i=n.next();this.checkInteriorIntersections(e,i)}else if(2===arguments.length)for(var r=arguments[0],s=arguments[1],o=r.getCoordinates(),a=s.getCoordinates(),u=0;u<o.length-1;u++)for(var l=0;l<a.length-1;l++)this.checkInteriorIntersections(r,u,s,l);else if(4===arguments.length){var h=arguments[0],c=arguments[1],f=arguments[2],g=arguments[3];if(h===f&&c===g)return null;var d=h.getCoordinates()[c],_=h.getCoordinates()[c+1],p=f.getCoordinates()[g],v=f.getCoordinates()[g+1];if(this._li.computeIntersection(d,_,p,v),this._li.hasIntersection()&&(this._li.isProper()||this.hasInteriorIntersection(this._li,d,_)||this.hasInteriorIntersection(this._li,p,v)))throw new m("found non-noded intersection at "+d+"-"+_+" and "+p+"-"+v)}},checkValid:function(){this.checkEndPtVertexIntersections(),this.checkInteriorIntersections(),this.checkCollapses()},checkCollapses:function(){if(0===arguments.length)for(var t=this._segStrings.iterator();t.hasNext();){var e=t.next();this.checkCollapses(e)}else if(1===arguments.length){var n=arguments[0].getCoordinates();for(t=0;t<n.length-2;t++)this.checkCollapse(n[t],n[t+1],n[t+2])}},hasInteriorIntersection:function(t,e,n){for(var i=0;i<t.getIntersectionNum();i++){var r=t.getIntersection(i);if(!r.equals(e)&&!r.equals(n))return!0}return!1},checkCollapse:function(t,e,n){if(t.equals(n))throw new m("found non-noded collapse at "+Cr.fact.createLineString([t,e,n]))},interfaces_:function(){return[]},getClass:function(){return Cr}}),Cr.fact=new se,e(Sr.prototype,{intersectsScaled:function(t,e){var n=Math.min(t.x,e.x),i=Math.max(t.x,e.x),r=Math.min(t.y,e.y),s=Math.max(t.y,e.y),o=this._maxx<n||this._minx>i||this._maxy<r||this._miny>s;if(o)return!1;var a=this.intersectsToleranceSquare(t,e);return x.isTrue(!(o&&a),"Found bad envelope test"),a},initCorners:function(t){this._minx=t.x-.5,this._maxx=t.x+.5,this._miny=t.y-.5,this._maxy=t.y+.5,this._corner[0]=new E(this._maxx,this._maxy),this._corner[1]=new E(this._minx,this._maxy),this._corner[2]=new E(this._minx,this._miny),this._corner[3]=new E(this._maxx,this._miny)},intersects:function(t,e){return 1===this._scaleFactor?this.intersectsScaled(t,e):(this.copyScaled(t,this._p0Scaled),this.copyScaled(e,this._p1Scaled),this.intersectsScaled(this._p0Scaled,this._p1Scaled))},scale:function(t){return Math.round(t*this._scaleFactor)},getCoordinate:function(){return this._originalPt},copyScaled:function(t,e){e.x=this.scale(t.x),e.y=this.scale(t.y)},getSafeEnvelope:function(){if(null===this._safeEnv){var t=Sr.SAFE_ENV_EXPANSION_FACTOR/this._scaleFactor;this._safeEnv=new M(this._originalPt.x-t,this._originalPt.x+t,this._originalPt.y-t,this._originalPt.y+t)}return this._safeEnv},intersectsPixelClosure:function(t,e){return this._li.computeIntersection(t,e,this._corner[0],this._corner[1]),!!this._li.hasIntersection()||(this._li.computeIntersection(t,e,this._corner[1],this._corner[2]),!!this._li.hasIntersection()||(this._li.computeIntersection(t,e,this._corner[2],this._corner[3]),!!this._li.hasIntersection()||(this._li.computeIntersection(t,e,this._corner[3],this._corner[0]),!!this._li.hasIntersection())))},intersectsToleranceSquare:function(t,e){var n=!1,i=!1;return this._li.computeIntersection(t,e,this._corner[0],this._corner[1]),!!this._li.isProper()||(this._li.computeIntersection(t,e,this._corner[1],this._corner[2]),!!this._li.isProper()||(this._li.hasIntersection()&&(n=!0),this._li.computeIntersection(t,e,this._corner[2],this._corner[3]),!!this._li.isProper()||(this._li.hasIntersection()&&(i=!0),this._li.computeIntersection(t,e,this._corner[3],this._corner[0]),!!this._li.isProper()||(!(!n||!i)||(!!t.equals(this._pt)||!!e.equals(this._pt))))))},addSnappedNode:function(t,e){var n=t.getCoordinate(e),i=t.getCoordinate(e+1);return!!this.intersects(n,i)&&(t.addIntersection(this.getCoordinate(),e),!0)},interfaces_:function(){return[]},getClass:function(){return Sr}}),Sr.SAFE_ENV_EXPANSION_FACTOR=.75,e(Lr.prototype,{snap:function(){if(1===arguments.length){var t=arguments[0];return this.snap(t,null,-1)}if(3===arguments.length){var e=arguments[0],n=arguments[1],i=arguments[2],r=e.getSafeEnvelope(),s=new wr(e,n,i);return this._index.query(r,{interfaces_:function(){return[Ce]},visitItem:function(t){t.select(r,s)}}),s.isNodeAdded()}},interfaces_:function(){return[]},getClass:function(){return Lr}}),v(wr,nn),e(wr.prototype,{isNodeAdded:function(){return this._isNodeAdded},select:function(){if(!(2===arguments.length&&Number.isInteger(arguments[1])&&arguments[0]instanceof fn))return nn.prototype.select.apply(this,arguments);var t=arguments[0],e=arguments[1],n=t.getContext();if(null!==this._parentEdge&&n===this._parentEdge&&e===this._hotPixelVertexIndex)return null;this._isNodeAdded=this._hotPixel.addSnappedNode(n,e)},interfaces_:function(){return[]},getClass:function(){return wr}}),Lr.HotPixelSnapAction=wr,e(Rr.prototype,{processIntersections:function(t,e,n,i){if(t===n&&e===i)return null;var r=t.getCoordinates()[e],s=t.getCoordinates()[e+1],o=n.getCoordinates()[i],a=n.getCoordinates()[i+1];if(this._li.computeIntersection(r,s,o,a),this._li.hasIntersection()&&this._li.isInteriorIntersection()){for(var u=0;u<this._li.getIntersectionNum();u++)this._interiorIntersections.add(this._li.getIntersection(u));t.addIntersections(this._li,e,0),n.addIntersections(this._li,i,1)}},isDone:function(){return!1},getInteriorIntersections:function(){return this._interiorIntersections},interfaces_:function(){return[Er]},getClass:function(){return Rr}}),e(Tr.prototype,{checkCorrectness:function(t){var e=new Cr(Xi.getNodedSubstrings(t));try{e.checkValid()}catch(t){if(!(t instanceof D))throw t;t.printStackTrace()}},getNodedSubstrings:function(){return Xi.getNodedSubstrings(this._nodedSegStrings)},snapRound:function(t,e){var n=this.findInteriorIntersections(t,e);this.computeIntersectionSnaps(n),this.computeVertexSnaps(t)},findInteriorIntersections:function(t,e){var n=new Rr(e);return this._noder.setSegmentIntersector(n),this._noder.computeNodes(t),n.getInteriorIntersections()},computeVertexSnaps:function(){if(N(arguments[0],S))for(var t=arguments[0].iterator();t.hasNext();){var e=t.next();this.computeVertexSnaps(e)}else if(arguments[0]instanceof Xi)for(var n=arguments[0],i=n.getCoordinates(),r=0;r<i.length;r++){var s=new Sr(i[r],this._scaleFactor,this._li);this._pointSnapper.snap(s,n,r)&&n.addIntersection(i[r],r)}},computeNodes:function(t){this._nodedSegStrings=t,this._noder=new Ki,this._pointSnapper=new Lr(this._noder.getIndex()),this.snapRound(t,this._li)},computeIntersectionSnaps:function(t){for(var e=t.iterator();e.hasNext();){var n=new Sr(e.next(),this._scaleFactor,this._li);this._pointSnapper.snap(n)}},interfaces_:function(){return[Wi]},getClass:function(){return Tr}}),e(Pr.prototype,{bufferFixedPrecision:function(t){var e=new Qi(new Tr(new ie(1)),t.getScale()),n=new Nr(this._bufParams);n.setWorkingPrecisionModel(t),n.setNoder(e),this._resultGeometry=n.buffer(this._argGeom,this._distance)},bufferReducedPrecision:function(){if(0===arguments.length){for(var t=Pr.MAX_PRECISION_DIGITS;t>=0;t--){try{this.bufferReducedPrecision(t)}catch(t){if(!(t instanceof Jn))throw t;this._saveException=t}if(null!==this._resultGeometry)return null}throw this._saveException}if(1===arguments.length){var e=arguments[0],n=new ie(Pr.precisionScaleFactor(this._argGeom,this._distance,e));this.bufferFixedPrecision(n)}},computeGeometry:function(){if(this.bufferOriginalPrecision(),null!==this._resultGeometry)return null;var t=this._argGeom.getFactory().getPrecisionModel();t.getType()===ie.FIXED?this.bufferFixedPrecision(t):this.bufferReducedPrecision()},setQuadrantSegments:function(t){this._bufParams.setQuadrantSegments(t)},bufferOriginalPrecision:function(){try{var t=new Nr(this._bufParams);this._resultGeometry=t.buffer(this._argGeom,this._distance)}catch(t){if(!(t instanceof m))throw t;this._saveException=t}},getResultGeometry:function(t){return this._distance=t,this.computeGeometry(),this._resultGeometry},setEndCapStyle:function(t){this._bufParams.setEndCapStyle(t)},interfaces_:function(){return[]},getClass:function(){return Pr}}),Pr.bufferOp=function(){if(2===arguments.length){var t=arguments[0],e=arguments[1];return new Pr(t).getResultGeometry(e)}if(3===arguments.length){if(Number.isInteger(arguments[2])&&arguments[0]instanceof K&&"number"==typeof arguments[1]){var n=arguments[0],i=arguments[1],r=arguments[2];return(a=new Pr(n)).setQuadrantSegments(r),a.getResultGeometry(i)}if(arguments[2]instanceof er&&arguments[0]instanceof K&&"number"==typeof arguments[1]){var s=arguments[0],o=arguments[1];return(a=new Pr(s,arguments[2])).getResultGeometry(o)}}else if(4===arguments.length){var a,u=arguments[0],l=arguments[1],h=arguments[2],c=arguments[3];return(a=new Pr(u)).setQuadrantSegments(h),a.setEndCapStyle(c),a.getResultGeometry(l)}},Pr.precisionScaleFactor=function(t,e,n){var i=t.getEnvelopeInternal(),r=U.max(Math.abs(i.getMaxX()),Math.abs(i.getMaxY()),Math.abs(i.getMinX()),Math.abs(i.getMinY()))+2*(e>0?e:0),s=n-Math.trunc(Math.log(r)/Math.log(10)+1);return Math.pow(10,s)},Pr.CAP_ROUND=er.CAP_ROUND,Pr.CAP_BUTT=er.CAP_FLAT,Pr.CAP_FLAT=er.CAP_FLAT,Pr.CAP_SQUARE=er.CAP_SQUARE,Pr.MAX_PRECISION_DIGITS=12;var Or=Object.freeze({BufferOp:Pr,BufferParameters:er});function br(){this._comps=null;var t=arguments[0];this._comps=t}function Mr(){if(this._component=null,this._segIndex=null,this._pt=null,2===arguments.length){var t=arguments[0],e=arguments[1];Mr.call(this,t,Mr.INSIDE_AREA,e)}else if(3===arguments.length){var n=arguments[0],i=arguments[1],r=arguments[2];this._component=n,this._segIndex=i,this._pt=r}}function Dr(){this._pts=null;var t=arguments[0];this._pts=t}function Ar(){this._locations=null;var t=arguments[0];this._locations=t}function Fr(){if(this._geom=null,this._terminateDistance=0,this._ptLocator=new Mn,this._minDistanceLocation=null,this._minDistance=s.MAX_VALUE,2===arguments.length){var t=arguments[0],e=arguments[1];Fr.call(this,t,e,0)}else if(3===arguments.length){var n=arguments[0],i=arguments[1],r=arguments[2];this._geom=new Array(2).fill(null),this._geom[0]=n,this._geom[1]=i,this._terminateDistance=r}}e(br.prototype,{filter:function(t){t instanceof Vt&&this._comps.add(t)},interfaces_:function(){return[Ct]},getClass:function(){return br}}),br.getPolygons=function(){if(1===arguments.length){var t=arguments[0];return br.getPolygons(t,new P)}if(2===arguments.length){var e=arguments[0],n=arguments[1];return e instanceof Vt?n.add(e):e instanceof Lt&&e.apply(new br(n)),n}},e(Mr.prototype,{isInsideArea:function(){return this._segIndex===Mr.INSIDE_AREA},getCoordinate:function(){return this._pt},getGeometryComponent:function(){return this._component},getSegmentIndex:function(){return this._segIndex},interfaces_:function(){return[]},getClass:function(){return Mr}}),Mr.INSIDE_AREA=-1,e(Dr.prototype,{filter:function(t){t instanceof Gt&&this._pts.add(t)},interfaces_:function(){return[Ct]},getClass:function(){return Dr}}),Dr.getPoints=function(){if(1===arguments.length){var t=arguments[0];return t instanceof Gt?Te.singletonList(t):Dr.getPoints(t,new P)}if(2===arguments.length){var e=arguments[0],n=arguments[1];return e instanceof Gt?n.add(e):e instanceof Lt&&e.apply(new Dr(n)),n}},e(Ar.prototype,{filter:function(t){(t instanceof Gt||t instanceof At||t instanceof Vt)&&this._locations.add(new Mr(t,0,t.getCoordinate()))},interfaces_:function(){return[Ct]},getClass:function(){return Ar}}),Ar.getLocations=function(t){var e=new P;return t.apply(new Ar(e)),e},e(Fr.prototype,{computeContainmentDistance:function(){if(0===arguments.length){var t=new Array(2).fill(null);if(this.computeContainmentDistance(0,t),this._minDistance<=this._terminateDistance)return null;this.computeContainmentDistance(1,t)}else if(2===arguments.length){var e=arguments[0],n=arguments[1],i=this._geom[e];if(i.getDimension()<2)return null;var r=1-e,s=br.getPolygons(i);if(s.size()>0){var o=Ar.getLocations(this._geom[r]);if(this.computeContainmentDistance(o,s,n),this._minDistance<=this._terminateDistance)return this._minDistanceLocation[r]=n[0],this._minDistanceLocation[e]=n[1],null}}else if(3===arguments.length)if(arguments[2]instanceof Array&&N(arguments[0],w)&&N(arguments[1],w)){for(var a=arguments[0],u=arguments[1],l=arguments[2],h=0;h<a.size();h++)for(var c=a.get(h),f=0;f<u.size();f++)if(this.computeContainmentDistance(c,u.get(f),l),this._minDistance<=this._terminateDistance)return null}else if(arguments[2]instanceof Array&&arguments[0]instanceof Mr&&arguments[1]instanceof Vt){var g=arguments[0],d=arguments[1],_=arguments[2],p=g.getCoordinate();if(de.EXTERIOR!==this._ptLocator.locate(p,d))return this._minDistance=0,_[0]=g,_[1]=new Mr(d,p),null}},computeMinDistanceLinesPoints:function(t,e,n){for(var i=0;i<t.size();i++)for(var r=t.get(i),s=0;s<e.size();s++){var o=e.get(s);if(this.computeMinDistance(r,o,n),this._minDistance<=this._terminateDistance)return null}},computeFacetDistance:function(){var t=new Array(2).fill(null),e=be.getLines(this._geom[0]),n=be.getLines(this._geom[1]),i=Dr.getPoints(this._geom[0]),r=Dr.getPoints(this._geom[1]);return this.computeMinDistanceLines(e,n,t),this.updateMinDistance(t,!1),this._minDistance<=this._terminateDistance?null:(t[0]=null,t[1]=null,this.computeMinDistanceLinesPoints(e,r,t),this.updateMinDistance(t,!1),this._minDistance<=this._terminateDistance?null:(t[0]=null,t[1]=null,this.computeMinDistanceLinesPoints(n,i,t),this.updateMinDistance(t,!0),this._minDistance<=this._terminateDistance?null:(t[0]=null,t[1]=null,this.computeMinDistancePoints(i,r,t),void this.updateMinDistance(t,!1))))},nearestLocations:function(){return this.computeMinDistance(),this._minDistanceLocation},updateMinDistance:function(t,e){if(null===t[0])return null;e?(this._minDistanceLocation[0]=t[1],this._minDistanceLocation[1]=t[0]):(this._minDistanceLocation[0]=t[0],this._minDistanceLocation[1]=t[1])},nearestPoints:function(){return this.computeMinDistance(),[this._minDistanceLocation[0].getCoordinate(),this._minDistanceLocation[1].getCoordinate()]},computeMinDistance:function(){if(0===arguments.length){if(null!==this._minDistanceLocation)return null;if(this._minDistanceLocation=new Array(2).fill(null),this.computeContainmentDistance(),this._minDistance<=this._terminateDistance)return null;this.computeFacetDistance()}else if(3===arguments.length)if(arguments[2]instanceof Array&&arguments[0]instanceof At&&arguments[1]instanceof Gt){var t=arguments[0],e=arguments[1],n=arguments[2];if(t.getEnvelopeInternal().distance(e.getEnvelopeInternal())>this._minDistance)return null;for(var i=t.getCoordinates(),r=e.getCoordinate(),s=0;s<i.length-1;s++){if((f=X.pointToSegment(r,i[s],i[s+1]))<this._minDistance){this._minDistance=f;var o=new ge(i[s],i[s+1]).closestPoint(r);n[0]=new Mr(t,s,o),n[1]=new Mr(e,0,r)}if(this._minDistance<=this._terminateDistance)return null}}else if(arguments[2]instanceof Array&&arguments[0]instanceof At&&arguments[1]instanceof At){var a=arguments[0],u=arguments[1],l=arguments[2];if(a.getEnvelopeInternal().distance(u.getEnvelopeInternal())>this._minDistance)return null;i=a.getCoordinates();var h=u.getCoordinates();for(s=0;s<i.length-1;s++)for(var c=0;c<h.length-1;c++){var f;if((f=X.segmentToSegment(i[s],i[s+1],h[c],h[c+1]))<this._minDistance){this._minDistance=f;var g=new ge(i[s],i[s+1]),d=new ge(h[c],h[c+1]),_=g.closestPoints(d);l[0]=new Mr(a,s,_[0]),l[1]=new Mr(u,c,_[1])}if(this._minDistance<=this._terminateDistance)return null}}},computeMinDistancePoints:function(t,e,n){for(var i=0;i<t.size();i++)for(var r=t.get(i),s=0;s<e.size();s++){var o=e.get(s),a=r.getCoordinate().distance(o.getCoordinate());if(a<this._minDistance&&(this._minDistance=a,n[0]=new Mr(r,0,r.getCoordinate()),n[1]=new Mr(o,0,o.getCoordinate())),this._minDistance<=this._terminateDistance)return null}},distance:function(){if(null===this._geom[0]||null===this._geom[1])throw new i("null geometries are not supported");return this._geom[0].isEmpty()||this._geom[1].isEmpty()?0:(this.computeMinDistance(),this._minDistance)},computeMinDistanceLines:function(t,e,n){for(var i=0;i<t.size();i++)for(var r=t.get(i),s=0;s<e.size();s++){var o=e.get(s);if(this.computeMinDistance(r,o,n),this._minDistance<=this._terminateDistance)return null}},interfaces_:function(){return[]},getClass:function(){return Fr}}),Fr.distance=function(t,e){return new Fr(t,e).distance()},Fr.isWithinDistance=function(t,e,n){return!(t.getEnvelopeInternal().distance(e.getEnvelopeInternal())>n)&&new Fr(t,e,n).distance()<=n},Fr.nearestPoints=function(t,e){return new Fr(t,e).nearestPoints()};var Gr=Object.freeze({DistanceOp:Fr});function qr(){this._factory=null,this._directedEdges=new P,this._coordinates=null;var t=arguments[0];this._factory=t}function Br(){this._isMarked=!1,this._isVisited=!1,this._data=null}function Vr(){Br.apply(this),this._parentEdge=null,this._from=null,this._to=null,this._p0=null,this._p1=null,this._sym=null,this._edgeDirection=null,this._quadrant=null,this._angle=null;var t=arguments[0],e=arguments[1],n=arguments[2],i=arguments[3];this._from=t,this._to=e,this._edgeDirection=i,this._p0=t.getCoordinate(),this._p1=n;var r=this._p1.x-this._p0.x,s=this._p1.y-this._p0.y;this._quadrant=gn.quadrant(r,s),this._angle=Math.atan2(s,r)}function zr(){var t=arguments[0],e=arguments[1],n=arguments[2],i=arguments[3];Vr.call(this,t,e,n,i)}function Yr(){if(Br.apply(this),this._dirEdge=null,0===arguments.length);else if(2===arguments.length){var t=arguments[0],e=arguments[1];this.setDirectedEdges(t,e)}}function kr(){this._outEdges=new P,this._sorted=!1}function Ur(){if(Br.apply(this),this._pt=null,this._deStar=null,1===arguments.length){var t=arguments[0];Ur.call(this,t,new kr)}else if(2===arguments.length){var e=arguments[0],n=arguments[1];this._pt=e,this._deStar=n}}function Xr(){Yr.apply(this),this._line=null;var t=arguments[0];this._line=t}function Hr(){this._nodeMap=new pt}function Wr(){this._edges=new ut,this._dirEdges=new ut,this._nodeMap=new Hr}function jr(){Wr.apply(this)}function Kr(){this._graph=new jr,this._mergedLineStrings=null,this._factory=null,this._edgeStrings=null}e(qr.prototype,{getCoordinates:function(){if(null===this._coordinates){for(var t=0,e=0,n=new b,i=this._directedEdges.iterator();i.hasNext();){var r=i.next();r.getEdgeDirection()?t++:e++,n.add(r.getEdge().getLine().getCoordinates(),!1,r.getEdgeDirection())}this._coordinates=n.toCoordinateArray(),e>t&&nt.reverse(this._coordinates)}return this._coordinates},toLineString:function(){return this._factory.createLineString(this.getCoordinates())},add:function(t){this._directedEdges.add(t)},interfaces_:function(){return[]},getClass:function(){return qr}}),e(Br.prototype,{setVisited:function(t){this._isVisited=t},isMarked:function(){return this._isMarked},setData:function(t){this._data=t},getData:function(){return this._data},setMarked:function(t){this._isMarked=t},getContext:function(){return this._data},isVisited:function(){return this._isVisited},setContext:function(t){this._data=t},interfaces_:function(){return[]},getClass:function(){return Br}}),Br.getComponentWithVisitedState=function(t,e){for(;t.hasNext();){var n=t.next();if(n.isVisited()===e)return n}return null},Br.setVisited=function(t,e){for(;t.hasNext();){t.next().setVisited(e)}},Br.setMarked=function(t,e){for(;t.hasNext();){t.next().setMarked(e)}},v(Vr,Br),e(Vr.prototype,{isRemoved:function(){return null===this._parentEdge},compareDirection:function(t){return this._quadrant>t._quadrant?1:this._quadrant<t._quadrant?-1:z.index(t._p0,t._p1,this._p1)},getCoordinate:function(){return this._from.getCoordinate()},print:function(t){var e=this.getClass().getName(),n=e.lastIndexOf("."),i=e.substring(n+1);t.print("  "+i+": "+this._p0+" - "+this._p1+" "+this._quadrant+":"+this._angle)},getDirectionPt:function(){return this._p1},getAngle:function(){return this._angle},compareTo:function(t){var e=t;return this.compareDirection(e)},getFromNode:function(){return this._from},getSym:function(){return this._sym},setEdge:function(t){this._parentEdge=t},remove:function(){this._sym=null,this._parentEdge=null},getEdge:function(){return this._parentEdge},getQuadrant:function(){return this._quadrant},setSym:function(t){this._sym=t},getToNode:function(){return this._to},getEdgeDirection:function(){return this._edgeDirection},interfaces_:function(){return[g]},getClass:function(){return Vr}}),Vr.toEdges=function(t){for(var e=new P,n=t.iterator();n.hasNext();)e.add(n.next()._parentEdge);return e},v(zr,Vr),e(zr.prototype,{getNext:function(){return 2!==this.getToNode().getDegree()?null:this.getToNode().getOutEdges().getEdges().get(0)===this.getSym()?this.getToNode().getOutEdges().getEdges().get(1):(x.isTrue(this.getToNode().getOutEdges().getEdges().get(1)===this.getSym()),this.getToNode().getOutEdges().getEdges().get(0))},interfaces_:function(){return[]},getClass:function(){return zr}}),v(Yr,Br),e(Yr.prototype,{isRemoved:function(){return null===this._dirEdge},setDirectedEdges:function(t,e){this._dirEdge=[t,e],t.setEdge(this),e.setEdge(this),t.setSym(e),e.setSym(t),t.getFromNode().addOutEdge(t),e.getFromNode().addOutEdge(e)},getDirEdge:function(){if(Number.isInteger(arguments[0])){var t=arguments[0];return this._dirEdge[t]}if(arguments[0]instanceof Ur){var e=arguments[0];return this._dirEdge[0].getFromNode()===e?this._dirEdge[0]:this._dirEdge[1].getFromNode()===e?this._dirEdge[1]:null}},remove:function(){this._dirEdge=null},getOppositeNode:function(t){return this._dirEdge[0].getFromNode()===t?this._dirEdge[0].getToNode():this._dirEdge[1].getFromNode()===t?this._dirEdge[1].getToNode():null},interfaces_:function(){return[]},getClass:function(){return Yr}}),e(kr.prototype,{getNextEdge:function(t){var e=this.getIndex(t);return this._outEdges.get(this.getIndex(e+1))},getCoordinate:function(){var t=this.iterator();return t.hasNext()?t.next().getCoordinate():null},iterator:function(){return this.sortEdges(),this._outEdges.iterator()},sortEdges:function(){this._sorted||(Te.sort(this._outEdges),this._sorted=!0)},remove:function(t){this._outEdges.remove(t)},getEdges:function(){return this.sortEdges(),this._outEdges},getNextCWEdge:function(t){var e=this.getIndex(t);return this._outEdges.get(this.getIndex(e-1))},getIndex:function(){if(arguments[0]instanceof Yr){var t=arguments[0];this.sortEdges();for(var e=0;e<this._outEdges.size();e++){if(this._outEdges.get(e).getEdge()===t)return e}return-1}if(arguments[0]instanceof Vr){var n=arguments[0];this.sortEdges();for(e=0;e<this._outEdges.size();e++){if(this._outEdges.get(e)===n)return e}return-1}if(Number.isInteger(arguments[0])){var i=arguments[0]%this._outEdges.size();return i<0&&(i+=this._outEdges.size()),i}},add:function(t){this._outEdges.add(t),this._sorted=!1},getDegree:function(){return this._outEdges.size()},interfaces_:function(){return[]},getClass:function(){return kr}}),v(Ur,Br),e(Ur.prototype,{isRemoved:function(){return null===this._pt},addOutEdge:function(t){this._deStar.add(t)},getCoordinate:function(){return this._pt},getOutEdges:function(){return this._deStar},remove:function(){if(0===arguments.length)this._pt=null;else if(1===arguments.length){var t=arguments[0];this._deStar.remove(t)}},getIndex:function(t){return this._deStar.getIndex(t)},getDegree:function(){return this._deStar.getDegree()},interfaces_:function(){return[]},getClass:function(){return Ur}}),Ur.getEdgesBetween=function(t,e){var n=new ut(Vr.toEdges(t.getOutEdges().getEdges())),i=Vr.toEdges(e.getOutEdges().getEdges());return n.retainAll(i),n},v(Xr,Yr),e(Xr.prototype,{getLine:function(){return this._line},interfaces_:function(){return[]},getClass:function(){return Xr}}),e(Hr.prototype,{find:function(t){return this._nodeMap.get(t)},iterator:function(){return this._nodeMap.values().iterator()},remove:function(t){return this._nodeMap.remove(t)},values:function(){return this._nodeMap.values()},add:function(t){return this._nodeMap.put(t.getCoordinate(),t),t},interfaces_:function(){return[]},getClass:function(){return Hr}}),e(Wr.prototype,{findNodesOfDegree:function(t){for(var e=new P,n=this.nodeIterator();n.hasNext();){var i=n.next();i.getDegree()===t&&e.add(i)}return e},dirEdgeIterator:function(){return this._dirEdges.iterator()},edgeIterator:function(){return this._edges.iterator()},remove:function(){if(arguments[0]instanceof Yr){var t=arguments[0];this.remove(t.getDirEdge(0)),this.remove(t.getDirEdge(1)),this._edges.remove(t),t.remove()}else if(arguments[0]instanceof Vr){var e=arguments[0];null!==(r=e.getSym())&&r.setSym(null),e.getFromNode().remove(e),e.remove(),this._dirEdges.remove(e)}else if(arguments[0]instanceof Ur){for(var n=arguments[0],i=n.getOutEdges().getEdges().iterator();i.hasNext();){var r,s=i.next();null!==(r=s.getSym())&&this.remove(r),this._dirEdges.remove(s);var o=s.getEdge();null!==o&&this._edges.remove(o)}this._nodeMap.remove(n.getCoordinate()),n.remove()}},findNode:function(t){return this._nodeMap.find(t)},getEdges:function(){return this._edges},nodeIterator:function(){return this._nodeMap.iterator()},contains:function(){if(arguments[0]instanceof Yr){var t=arguments[0];return this._edges.contains(t)}if(arguments[0]instanceof Vr){var e=arguments[0];return this._dirEdges.contains(e)}},add:function(){if(arguments[0]instanceof Ur){var t=arguments[0];this._nodeMap.add(t)}else if(arguments[0]instanceof Yr){var e=arguments[0];this._edges.add(e),this.add(e.getDirEdge(0)),this.add(e.getDirEdge(1))}else if(arguments[0]instanceof Vr){var n=arguments[0];this._dirEdges.add(n)}},getNodes:function(){return this._nodeMap.values()},interfaces_:function(){return[]},getClass:function(){return Wr}}),v(jr,Wr),e(jr.prototype,{addEdge:function(t){if(t.isEmpty())return null;var e=nt.removeRepeatedPoints(t.getCoordinates());if(e.length<=1)return null;var n=e[0],i=e[e.length-1],r=this.getNode(n),s=this.getNode(i),o=new zr(r,s,e[1],!0),a=new zr(s,r,e[e.length-2],!1),u=new Xr(t);u.setDirectedEdges(o,a),this.add(u)},getNode:function(t){var e=this.findNode(t);return null===e&&(e=new Ur(t),this.add(e)),e},interfaces_:function(){return[]},getClass:function(){return jr}}),e(Kr.prototype,{buildEdgeStringsForUnprocessedNodes:function(){for(var t=this._graph.getNodes().iterator();t.hasNext();){var e=t.next();e.isMarked()||(x.isTrue(2===e.getDegree()),this.buildEdgeStringsStartingAt(e),e.setMarked(!0))}},buildEdgeStringsForNonDegree2Nodes:function(){for(var t=this._graph.getNodes().iterator();t.hasNext();){var e=t.next();2!==e.getDegree()&&(this.buildEdgeStringsStartingAt(e),e.setMarked(!0))}},buildEdgeStringsForObviousStartNodes:function(){this.buildEdgeStringsForNonDegree2Nodes()},getMergedLineStrings:function(){return this.merge(),this._mergedLineStrings},buildEdgeStringsStartingAt:function(t){for(var e=t.getOutEdges().iterator();e.hasNext();){var n=e.next();n.getEdge().isMarked()||this._edgeStrings.add(this.buildEdgeStringStartingWith(n))}},merge:function(){if(null!==this._mergedLineStrings)return null;Br.setMarked(this._graph.nodeIterator(),!1),Br.setMarked(this._graph.edgeIterator(),!1),this._edgeStrings=new P,this.buildEdgeStringsForObviousStartNodes(),this.buildEdgeStringsForIsolatedLoops(),this._mergedLineStrings=new P;for(var t=this._edgeStrings.iterator();t.hasNext();){var e=t.next();this._mergedLineStrings.add(e.toLineString())}},buildEdgeStringStartingWith:function(t){var e=new qr(this._factory),n=t;do{e.add(n),n.getEdge().setMarked(!0),n=n.getNext()}while(null!==n&&n!==t);return e},add:function(){if(arguments[0]instanceof K)arguments[0].apply({interfaces_:function(){return[j]},filter:function(t){t instanceof At&&this.add(t)}});else if(N(arguments[0],S)){var t=arguments[0];this._mergedLineStrings=null;for(var e=t.iterator();e.hasNext();){var n=e.next();this.add(n)}}else if(arguments[0]instanceof At){var i=arguments[0];null===this._factory&&(this._factory=i.getFactory()),this._graph.addEdge(i)}},buildEdgeStringsForIsolatedLoops:function(){this.buildEdgeStringsForUnprocessedNodes()},interfaces_:function(){return[]},getClass:function(){return Kr}});var Zr=Object.freeze({LineMerger:Kr});function Qr(){this._pts=null,this._data=null;var t=arguments[0],e=arguments[1];this._pts=t,this._data=e}function Jr(){this._findAllIntersections=!1,this._isCheckEndSegmentsOnly=!1,this._li=null,this._interiorIntersection=null,this._intSegments=null,this._intersections=new P,this._intersectionCount=0,this._keepIntersections=!0;var t=arguments[0];this._li=t,this._interiorIntersection=null}function $r(){this._li=new fe,this._segStrings=null,this._findAllIntersections=!1,this._segInt=null,this._isValid=!0;var t=arguments[0];this._segStrings=t}function ts(){this._nv=null;var t=arguments[0];this._nv=new $r(ts.toSegmentStrings(t))}function es(){this._mapOp=null;var t=arguments[0];this._mapOp=t}function ns(){this._op=null,this._geometryFactory=null,this._ptLocator=null,this._lineEdgesList=new P,this._resultLineList=new P;var t=arguments[0],e=arguments[1],n=arguments[2];this._op=t,this._geometryFactory=e,this._ptLocator=n}function is(){this._op=null,this._geometryFactory=null,this._resultPointList=new P;var t=arguments[0],e=arguments[1];this._op=t,this._geometryFactory=e}function rs(){if(this._snapTolerance=0,this._srcPts=null,this._seg=new ge,this._allowSnappingToSourceVertices=!1,this._isClosed=!1,arguments[0]instanceof At&&"number"==typeof arguments[1]){var t=arguments[0],e=arguments[1];rs.call(this,t.getCoordinates(),e)}else if(arguments[0]instanceof Array&&"number"==typeof arguments[1]){var n=arguments[0],i=arguments[1];this._srcPts=n,this._isClosed=rs.isClosed(n),this._snapTolerance=i}}function ss(){this._srcGeom=null;var t=arguments[0];this._srcGeom=t}function os(){if(In.apply(this),this._snapTolerance=null,this._snapPts=null,this._isSelfSnap=!1,2===arguments.length){var t=arguments[0],e=arguments[1];this._snapTolerance=t,this._snapPts=e}else if(3===arguments.length){var n=arguments[0],i=arguments[1],r=arguments[2];this._snapTolerance=n,this._snapPts=i,this._isSelfSnap=r}}function as(){this._isFirst=!0,this._commonMantissaBitsCount=53,this._commonBits=new r,this._commonSignExp=null}function us(){this._commonCoord=null,this._ccFilter=new ls}function ls(){this._commonBitsX=new as,this._commonBitsY=new as}function hs(){this.trans=null;var t=arguments[0];this.trans=t}function cs(){this._geom=new Array(2).fill(null),this._snapTolerance=null,this._cbr=null;var t=arguments[0],e=arguments[1];this._geom[0]=t,this._geom[1]=e,this.computeSnapTolerance()}function fs(){this._geom=new Array(2).fill(null);var t=arguments[0],e=arguments[1];this._geom[0]=t,this._geom[1]=e}function gs(){if(this._li=new fe,this._resultPrecisionModel=null,this._arg=null,1===arguments.length){var t=arguments[0];this.setComputationPrecision(t.getPrecisionModel()),this._arg=new Array(1).fill(null),this._arg[0]=new ni(0,t)}else if(2===arguments.length){var e=arguments[0],n=arguments[1];gs.call(this,e,n,Q.OGC_SFS_BOUNDARY_RULE)}else if(3===arguments.length){var i=arguments[0],r=arguments[1],s=arguments[2];i.getPrecisionModel().compareTo(r.getPrecisionModel())>=0?this.setComputationPrecision(i.getPrecisionModel()):this.setComputationPrecision(r.getPrecisionModel()),this._arg=new Array(2).fill(null),this._arg[0]=new ni(0,i,s),this._arg[1]=new ni(1,r,s)}}function ds(){this._ptLocator=new Mn,this._geomFact=null,this._resultGeom=null,this._graph=null,this._edgeList=new xr,this._resultPolyList=new P,this._resultLineList=new P,this._resultPointList=new P;var t=arguments[0],e=arguments[1];gs.call(this,t,e),this._graph=new ei(new vr),this._geomFact=t.getFactory()}e(Qr.prototype,{getCoordinates:function(){return this._pts},size:function(){return this._pts.length},getCoordinate:function(t){return this._pts[t]},isClosed:function(){return this._pts[0].equals(this._pts[this._pts.length-1])},getSegmentOctant:function(t){return t===this._pts.length-1?-1:Yi.octant(this.getCoordinate(t),this.getCoordinate(t+1))},setData:function(t){this._data=t},getData:function(){return this._data},toString:function(){return he.toLineString(new Kt(this._pts))},interfaces_:function(){return[ki]},getClass:function(){return Qr}}),e(Jr.prototype,{getInteriorIntersection:function(){return this._interiorIntersection},setCheckEndSegmentsOnly:function(t){this._isCheckEndSegmentsOnly=t},getIntersectionSegments:function(){return this._intSegments},count:function(){return this._intersectionCount},getIntersections:function(){return this._intersections},setFindAllIntersections:function(t){this._findAllIntersections=t},setKeepIntersections:function(t){this._keepIntersections=t},processIntersections:function(t,e,n,i){if(!this._findAllIntersections&&this.hasIntersection())return null;if(t===n&&e===i)return null;if(this._isCheckEndSegmentsOnly&&!(this.isEndSegment(t,e)||this.isEndSegment(n,i)))return null;var r=t.getCoordinates()[e],s=t.getCoordinates()[e+1],o=n.getCoordinates()[i],a=n.getCoordinates()[i+1];this._li.computeIntersection(r,s,o,a),this._li.hasIntersection()&&this._li.isInteriorIntersection()&&(this._intSegments=new Array(4).fill(null),this._intSegments[0]=r,this._intSegments[1]=s,this._intSegments[2]=o,this._intSegments[3]=a,this._interiorIntersection=this._li.getIntersection(0),this._keepIntersections&&this._intersections.add(this._interiorIntersection),this._intersectionCount++)},isEndSegment:function(t,e){return 0===e||e>=t.size()-2},hasIntersection:function(){return null!==this._interiorIntersection},isDone:function(){return!this._findAllIntersections&&null!==this._interiorIntersection},interfaces_:function(){return[Er]},getClass:function(){return Jr}}),Jr.createAllIntersectionsFinder=function(t){var e=new Jr(t);return e.setFindAllIntersections(!0),e},Jr.createAnyIntersectionFinder=function(t){return new Jr(t)},Jr.createIntersectionCounter=function(t){var e=new Jr(t);return e.setFindAllIntersections(!0),e.setKeepIntersections(!1),e},e($r.prototype,{execute:function(){if(null!==this._segInt)return null;this.checkInteriorIntersections()},getIntersections:function(){return this._segInt.getIntersections()},isValid:function(){return this.execute(),this._isValid},setFindAllIntersections:function(t){this._findAllIntersections=t},checkInteriorIntersections:function(){this._isValid=!0,this._segInt=new Jr(this._li),this._segInt.setFindAllIntersections(this._findAllIntersections);var t=new Ki;if(t.setSegmentIntersector(this._segInt),t.computeNodes(this._segStrings),this._segInt.hasIntersection())return this._isValid=!1,null},checkValid:function(){if(this.execute(),!this._isValid)throw new Jn(this.getErrorMessage(),this._segInt.getInteriorIntersection())},getErrorMessage:function(){if(this._isValid)return"no intersections found";var t=this._segInt.getIntersectionSegments();return"found non-noded intersection between "+he.toLineString(t[0],t[1])+" and "+he.toLineString(t[2],t[3])},interfaces_:function(){return[]},getClass:function(){return $r}}),$r.computeIntersections=function(t){var e=new $r(t);return e.setFindAllIntersections(!0),e.isValid(),e.getIntersections()},e(ts.prototype,{checkValid:function(){this._nv.checkValid()},interfaces_:function(){return[]},getClass:function(){return ts}}),ts.toSegmentStrings=function(t){for(var e=new P,n=t.iterator();n.hasNext();){var i=n.next();e.add(new Qr(i.getCoordinates(),i))}return e},ts.checkValid=function(t){new ts(t).checkValid()},e(es.prototype,{map:function(t){for(var e=new P,n=0;n<t.getNumGeometries();n++){var i=this._mapOp.map(t.getGeometryN(n));i.isEmpty()||e.add(i)}return t.getFactory().createGeometryCollection(se.toGeometryArray(e))},interfaces_:function(){return[]},getClass:function(){return es}}),es.map=function(t,e){return new es(e).map(t)},e(ns.prototype,{collectLines:function(t){for(var e=this._op.getGraph().getEdgeEnds().iterator();e.hasNext();){var n=e.next();this.collectLineEdge(n,t,this._lineEdgesList),this.collectBoundaryTouchEdge(n,t,this._lineEdgesList)}},labelIsolatedLine:function(t,e){var n=this._ptLocator.locate(t.getCoordinate(),this._op.getArgGeometry(e));t.getLabel().setLocation(e,n)},build:function(t){return this.findCoveredLineEdges(),this.collectLines(t),this.buildLines(t),this._resultLineList},collectLineEdge:function(t,e,n){var i=t.getLabel(),r=t.getEdge();t.isLineEdge()&&(t.isVisited()||!ds.isResultOfOp(i,e)||r.isCovered()||(n.add(r),t.setVisitedEdge(!0)))},findCoveredLineEdges:function(){for(var t=this._op.getGraph().getNodes().iterator();t.hasNext();){t.next().getEdges().findCoveredLineEdges()}for(var e=this._op.getGraph().getEdgeEnds().iterator();e.hasNext();){var n=e.next(),i=n.getEdge();if(n.isLineEdge()&&!i.isCoveredSet()){var r=this._op.isCoveredByA(n.getCoordinate());i.setCovered(r)}}},labelIsolatedLines:function(t){for(var e=t.iterator();e.hasNext();){var n=e.next(),i=n.getLabel();n.isIsolated()&&(i.isNull(0)?this.labelIsolatedLine(n,0):this.labelIsolatedLine(n,1))}},buildLines:function(t){for(var e=this._lineEdgesList.iterator();e.hasNext();){var n=e.next(),i=(n.getLabel(),this._geometryFactory.createLineString(n.getCoordinates()));this._resultLineList.add(i),n.setInResult(!0)}},collectBoundaryTouchEdge:function(t,e,n){var i=t.getLabel();return t.isLineEdge()?null:t.isVisited()?null:t.isInteriorAreaEdge()?null:t.getEdge().isInResult()?null:(x.isTrue(!(t.isInResult()||t.getSym().isInResult())||!t.getEdge().isInResult()),void(ds.isResultOfOp(i,e)&&e===ds.INTERSECTION&&(n.add(t.getEdge()),t.setVisitedEdge(!0))))},interfaces_:function(){return[]},getClass:function(){return ns}}),e(is.prototype,{filterCoveredNodeToPoint:function(t){var e=t.getCoordinate();if(!this._op.isCoveredByLA(e)){var n=this._geometryFactory.createPoint(e);this._resultPointList.add(n)}},extractNonCoveredResultNodes:function(t){for(var e=this._op.getGraph().getNodes().iterator();e.hasNext();){var n=e.next();if(!n.isInResult()&&(!n.isIncidentEdgeInResult()&&(0===n.getEdges().getDegree()||t===ds.INTERSECTION))){var i=n.getLabel();ds.isResultOfOp(i,t)&&this.filterCoveredNodeToPoint(n)}}},build:function(t){return this.extractNonCoveredResultNodes(t),this._resultPointList},interfaces_:function(){return[]},getClass:function(){return is}}),e(rs.prototype,{snapVertices:function(t,e){for(var n=this._isClosed?t.size()-1:t.size(),i=0;i<n;i++){var r=t.get(i),s=this.findSnapForVertex(r,e);null!==s&&(t.set(i,new E(s)),0===i&&this._isClosed&&t.set(t.size()-1,new E(s)))}},findSnapForVertex:function(t,e){for(var n=0;n<e.length;n++){if(t.equals2D(e[n]))return null;if(t.distance(e[n])<this._snapTolerance)return e[n]}return null},snapTo:function(t){var e=new b(this._srcPts);return this.snapVertices(e,t),this.snapSegments(e,t),e.toCoordinateArray()},snapSegments:function(t,e){if(0===e.length)return null;var n=e.length;e[0].equals2D(e[e.length-1])&&(n=e.length-1);for(var i=0;i<n;i++){var r=e[i],s=this.findSegmentIndexToSnap(r,t);s>=0&&t.add(s+1,new E(r),!1)}},findSegmentIndexToSnap:function(t,e){for(var n=s.MAX_VALUE,i=-1,r=0;r<e.size()-1;r++){if(this._seg.p0=e.get(r),this._seg.p1=e.get(r+1),this._seg.p0.equals2D(t)||this._seg.p1.equals2D(t)){if(this._allowSnappingToSourceVertices)continue;return-1}var o=this._seg.distance(t);o<this._snapTolerance&&o<n&&(n=o,i=r)}return i},setAllowSnappingToSourceVertices:function(t){this._allowSnappingToSourceVertices=t},interfaces_:function(){return[]},getClass:function(){return rs}}),rs.isClosed=function(t){return!(t.length<=1)&&t[0].equals2D(t[t.length-1])},e(ss.prototype,{snapTo:function(t,e){return new os(e,this.extractTargetCoordinates(t)).transform(this._srcGeom)},snapToSelf:function(t,e){var n=new os(t,this.extractTargetCoordinates(this._srcGeom),!0).transform(this._srcGeom),i=n;return e&&N(i,Bt)&&(i=n.buffer(0)),i},computeSnapTolerance:function(t){return this.computeMinimumSegmentLength(t)/10},extractTargetCoordinates:function(t){for(var e=new yt,n=t.getCoordinates(),i=0;i<n.length;i++)e.add(n[i]);return e.toArray(new Array(0).fill(null))},computeMinimumSegmentLength:function(t){for(var e=s.MAX_VALUE,n=0;n<t.length-1;n++){var i=t[n].distance(t[n+1]);i<e&&(e=i)}return e},interfaces_:function(){return[]},getClass:function(){return ss}}),ss.snap=function(t,e,n){var i=new Array(2).fill(null),r=new ss(t);i[0]=r.snapTo(e,n);var s=new ss(e);return i[1]=s.snapTo(i[0],n),i},ss.computeOverlaySnapTolerance=function(){if(1===arguments.length){var t=arguments[0],e=ss.computeSizeBasedSnapTolerance(t),n=t.getPrecisionModel();if(n.getType()===ie.FIXED){var i=1/n.getScale()*2/1.415;i>e&&(e=i)}return e}if(2===arguments.length){var r=arguments[0],s=arguments[1];return Math.min(ss.computeOverlaySnapTolerance(r),ss.computeOverlaySnapTolerance(s))}},ss.computeSizeBasedSnapTolerance=function(t){var e=t.getEnvelopeInternal();return Math.min(e.getHeight(),e.getWidth())*ss.SNAP_PRECISION_FACTOR},ss.snapToSelf=function(t,e,n){return new ss(t).snapToSelf(e,n)},ss.SNAP_PRECISION_FACTOR=1e-9,v(os,In),e(os.prototype,{snapLine:function(t,e){var n=new rs(t,this._snapTolerance);return n.setAllowSnappingToSourceVertices(this._isSelfSnap),n.snapTo(e)},transformCoordinates:function(t,e){var n=t.toCoordinateArray(),i=this.snapLine(n,this._snapPts);return this._factory.getCoordinateSequenceFactory().create(i)},interfaces_:function(){return[]},getClass:function(){return os}}),e(as.prototype,{getCommon:function(){return s.longBitsToDouble(this._commonBits)},add:function(t){var e=s.doubleToLongBits(t);return this._isFirst?(this._commonBits=e,this._commonSignExp=as.signExpBits(this._commonBits),this._isFirst=!1,null):as.signExpBits(e)!==this._commonSignExp?(this._commonBits.high=0,this._commonBits.low=0,null):(this._commonMantissaBitsCount=as.numCommonMostSigMantissaBits(this._commonBits,e),void(this._commonBits=as.zeroLowerBits(this._commonBits,64-(12+this._commonMantissaBitsCount))))},toString:function(){if(1===arguments.length){var t=arguments[0],e=s.longBitsToDouble(t),n="0000000000000000000000000000000000000000000000000000000000000000"+r.toBinaryString(t),i=n.substring(n.length-64);return i.substring(0,1)+"  "+i.substring(1,12)+"(exp) "+i.substring(12)+" [ "+e+" ]"}},interfaces_:function(){return[]},getClass:function(){return as}}),as.getBit=function(t,e){var n=1<<e%32;return e<32?0!=(t.low&n)?1:0:0!=(t.high&n)?1:0},as.signExpBits=function(t){return t.high>>>20},as.zeroLowerBits=function(t,e){var n="low";if(e>32&&(t.low=0,e%=32,n="high"),e>0){var i=e<32?~((1<<e)-1):0;t[n]&=i}return t},as.numCommonMostSigMantissaBits=function(t,e){for(var n=0,i=52;i>=0;i--){if(as.getBit(t,i)!==as.getBit(e,i))return n;n++}return 52},e(us.prototype,{addCommonBits:function(t){var e=new hs(this._commonCoord);t.apply(e),t.geometryChanged()},removeCommonBits:function(t){if(0===this._commonCoord.x&&0===this._commonCoord.y)return t;var e=new E(this._commonCoord);e.x=-e.x,e.y=-e.y;var n=new hs(e);return t.apply(n),t.geometryChanged(),t},getCommonCoordinate:function(){return this._commonCoord},add:function(t){t.apply(this._ccFilter),this._commonCoord=this._ccFilter.getCommonCoordinate()},interfaces_:function(){return[]},getClass:function(){return us}}),e(ls.prototype,{filter:function(t){this._commonBitsX.add(t.x),this._commonBitsY.add(t.y)},getCommonCoordinate:function(){return new E(this._commonBitsX.getCommon(),this._commonBitsY.getCommon())},interfaces_:function(){return[Z]},getClass:function(){return ls}}),e(hs.prototype,{filter:function(t,e){var n=t.getOrdinate(e,0)+this.trans.x,i=t.getOrdinate(e,1)+this.trans.y;t.setOrdinate(e,0,n),t.setOrdinate(e,1,i)},isDone:function(){return!1},isGeometryChanged:function(){return!0},interfaces_:function(){return[St]},getClass:function(){return hs}}),us.CommonCoordinateFilter=ls,us.Translater=hs,e(cs.prototype,{selfSnap:function(t){return new ss(t).snapTo(t,this._snapTolerance)},removeCommonBits:function(t){this._cbr=new us,this._cbr.add(t[0]),this._cbr.add(t[1]);var e=new Array(2).fill(null);return e[0]=this._cbr.removeCommonBits(t[0].copy()),e[1]=this._cbr.removeCommonBits(t[1].copy()),e},prepareResult:function(t){return this._cbr.addCommonBits(t),t},getResultGeometry:function(t){var e=this.snap(this._geom),n=ds.overlayOp(e[0],e[1],t);return this.prepareResult(n)},checkValid:function(t){t.isValid()||Y.out.println("Snapped geometry is invalid")},computeSnapTolerance:function(){this._snapTolerance=ss.computeOverlaySnapTolerance(this._geom[0],this._geom[1])},snap:function(t){var e=this.removeCommonBits(t);return ss.snap(e[0],e[1],this._snapTolerance)},interfaces_:function(){return[]},getClass:function(){return cs}}),cs.overlayOp=function(t,e,n){return new cs(t,e).getResultGeometry(n)},cs.union=function(t,e){return cs.overlayOp(t,e,ds.UNION)},cs.intersection=function(t,e){return cs.overlayOp(t,e,ds.INTERSECTION)},cs.symDifference=function(t,e){return cs.overlayOp(t,e,ds.SYMDIFFERENCE)},cs.difference=function(t,e){return cs.overlayOp(t,e,ds.DIFFERENCE)},e(fs.prototype,{getResultGeometry:function(t){var e=null,n=!1,i=null;try{e=ds.overlayOp(this._geom[0],this._geom[1],t);n=!0}catch(t){if(!(t instanceof m))throw t;i=t}if(!n)try{e=cs.overlayOp(this._geom[0],this._geom[1],t)}catch(t){throw t instanceof m?i:t}return e},interfaces_:function(){return[]},getClass:function(){return fs}}),fs.overlayOp=function(t,e,n){return new fs(t,e).getResultGeometry(n)},fs.union=function(t,e){return fs.overlayOp(t,e,ds.UNION)},fs.intersection=function(t,e){return fs.overlayOp(t,e,ds.INTERSECTION)},fs.symDifference=function(t,e){return fs.overlayOp(t,e,ds.SYMDIFFERENCE)},fs.difference=function(t,e){return fs.overlayOp(t,e,ds.DIFFERENCE)},e(gs.prototype,{getArgGeometry:function(t){return this._arg[t].getGeometry()},setComputationPrecision:function(t){this._resultPrecisionModel=t,this._li.setPrecisionModel(this._resultPrecisionModel)},interfaces_:function(){return[]},getClass:function(){return gs}}),v(ds,gs),e(ds.prototype,{insertUniqueEdge:function(t){var e=this._edgeList.findEqualEdge(t);if(null!==e){var n=e.getLabel(),i=t.getLabel();e.isPointwiseEqual(t)||(i=new zn(t.getLabel())).flip();var r=e.getDepth();r.isNull()&&r.add(n),r.add(i),n.merge(i)}else this._edgeList.add(t)},getGraph:function(){return this._graph},cancelDuplicateResultEdges:function(){for(var t=this._graph.getEdgeEnds().iterator();t.hasNext();){var e=t.next(),n=e.getSym();e.isInResult()&&n.isInResult()&&(e.setInResult(!1),n.setInResult(!1))}},isCoveredByLA:function(t){return!!this.isCovered(t,this._resultLineList)||!!this.isCovered(t,this._resultPolyList)},computeGeometry:function(t,e,n,i){var r=new P;return r.addAll(t),r.addAll(e),r.addAll(n),r.isEmpty()?ds.createEmptyResult(i,this._arg[0].getGeometry(),this._arg[1].getGeometry(),this._geomFact):this._geomFact.buildGeometry(r)},mergeSymLabels:function(){for(var t=this._graph.getNodes().iterator();t.hasNext();){t.next().getEdges().mergeSymLabels()}},isCovered:function(t,e){for(var n=e.iterator();n.hasNext();){var i=n.next();if(this._ptLocator.locate(t,i)!==de.EXTERIOR)return!0}return!1},replaceCollapsedEdges:function(){for(var t=new P,e=this._edgeList.iterator();e.hasNext();){var n=e.next();n.isCollapsed()&&(e.remove(),t.add(n.getCollapsedEdge()))}this._edgeList.addAll(t)},updateNodeLabelling:function(){for(var t=this._graph.getNodes().iterator();t.hasNext();){var e=t.next(),n=e.getEdges().getLabel();e.getLabel().merge(n)}},getResultGeometry:function(t){return this.computeOverlay(t),this._resultGeom},insertUniqueEdges:function(t){for(var e=t.iterator();e.hasNext();){var n=e.next();this.insertUniqueEdge(n)}},computeOverlay:function(t){this.copyPoints(0),this.copyPoints(1),this._arg[0].computeSelfNodes(this._li,!1),this._arg[1].computeSelfNodes(this._li,!1),this._arg[0].computeEdgeIntersections(this._arg[1],this._li,!0);var e=new P;this._arg[0].computeSplitEdges(e),this._arg[1].computeSplitEdges(e),this.insertUniqueEdges(e),this.computeLabelsFromDepths(),this.replaceCollapsedEdges(),ts.checkValid(this._edgeList.getEdges()),this._graph.addEdges(this._edgeList.getEdges()),this.computeLabelling(),this.labelIncompleteNodes(),this.findResultAreaEdges(t),this.cancelDuplicateResultEdges();var n=new ur(this._geomFact);n.add(this._graph),this._resultPolyList=n.getPolygons();var i=new ns(this,this._geomFact,this._ptLocator);this._resultLineList=i.build(t);var r=new is(this,this._geomFact,this._ptLocator);this._resultPointList=r.build(t),this._resultGeom=this.computeGeometry(this._resultPointList,this._resultLineList,this._resultPolyList,t)},labelIncompleteNode:function(t,e){var n=this._ptLocator.locate(t.getCoordinate(),this._arg[e].getGeometry());t.getLabel().setLocation(e,n)},copyPoints:function(t){for(var e=this._arg[t].getNodeIterator();e.hasNext();){var n=e.next();this._graph.addNode(n.getCoordinate()).setLabel(t,n.getLabel().getLocation(t))}},findResultAreaEdges:function(t){for(var e=this._graph.getEdgeEnds().iterator();e.hasNext();){var n=e.next(),i=n.getLabel();i.isArea()&&!n.isInteriorAreaEdge()&&ds.isResultOfOp(i.getLocation(0,Dn.RIGHT),i.getLocation(1,Dn.RIGHT),t)&&n.setInResult(!0)}},computeLabelsFromDepths:function(){for(var t=this._edgeList.iterator();t.hasNext();){var e=t.next(),n=e.getLabel(),i=e.getDepth();if(!i.isNull()){i.normalize();for(var r=0;r<2;r++)n.isNull(r)||!n.isArea()||i.isNull(r)||(0===i.getDelta(r)?n.toLine(r):(x.isTrue(!i.isNull(r,Dn.LEFT),"depth of LEFT side has not been initialized"),n.setLocation(r,Dn.LEFT,i.getLocation(r,Dn.LEFT)),x.isTrue(!i.isNull(r,Dn.RIGHT),"depth of RIGHT side has not been initialized"),n.setLocation(r,Dn.RIGHT,i.getLocation(r,Dn.RIGHT))))}}},computeLabelling:function(){for(var t=this._graph.getNodes().iterator();t.hasNext();){t.next().getEdges().computeLabelling(this._arg)}this.mergeSymLabels(),this.updateNodeLabelling()},labelIncompleteNodes:function(){for(var t=this._graph.getNodes().iterator();t.hasNext();){var e=t.next(),n=e.getLabel();e.isIsolated()&&(n.isNull(0)?this.labelIncompleteNode(e,0):this.labelIncompleteNode(e,1)),e.getEdges().updateLabelling(n)}},isCoveredByA:function(t){return!!this.isCovered(t,this._resultPolyList)},interfaces_:function(){return[]},getClass:function(){return ds}}),ds.overlayOp=function(t,e,n){return new ds(t,e).getResultGeometry(n)},ds.union=function(t,e){if(t.isEmpty()||e.isEmpty()){if(t.isEmpty()&&e.isEmpty())return ds.createEmptyResult(ds.UNION,t,e,t.getFactory());if(t.isEmpty())return e.copy();if(e.isEmpty())return t.copy()}if(t.isGeometryCollection()||e.isGeometryCollection())throw new i("This method does not support GeometryCollection arguments");return fs.overlayOp(t,e,ds.UNION)},ds.intersection=function(t,e){if(t.isEmpty()||e.isEmpty())return ds.createEmptyResult(ds.INTERSECTION,t,e,t.getFactory());if(t.isGeometryCollection()){var n=e;return es.map(t,{interfaces_:function(){return[MapOp]},map:function(t){return t.intersection(n)}})}if(t.isGeometryCollection()||e.isGeometryCollection())throw new i("This method does not support GeometryCollection arguments");return fs.overlayOp(t,e,ds.INTERSECTION)},ds.symDifference=function(t,e){if(t.isEmpty()||e.isEmpty()){if(t.isEmpty()&&e.isEmpty())return ds.createEmptyResult(ds.SYMDIFFERENCE,t,e,t.getFactory());if(t.isEmpty())return e.copy();if(e.isEmpty())return t.copy()}if(t.isGeometryCollection()||e.isGeometryCollection())throw new i("This method does not support GeometryCollection arguments");return fs.overlayOp(t,e,ds.SYMDIFFERENCE)},ds.resultDimension=function(t,e,n){var i=e.getDimension(),r=n.getDimension(),s=-1;switch(t){case ds.INTERSECTION:s=Math.min(i,r);break;case ds.UNION:s=Math.max(i,r);break;case ds.DIFFERENCE:s=i;break;case ds.SYMDIFFERENCE:s=Math.max(i,r)}return s},ds.createEmptyResult=function(t,e,n,i){var r=null;switch(ds.resultDimension(t,e,n)){case-1:r=i.createGeometryCollection();break;case 0:r=i.createPoint();break;case 1:r=i.createLineString();break;case 2:r=i.createPolygon()}return r},ds.difference=function(t,e){if(t.isEmpty())return ds.createEmptyResult(ds.DIFFERENCE,t,e,t.getFactory());if(e.isEmpty())return t.copy();if(t.isGeometryCollection()||e.isGeometryCollection())throw new i("This method does not support GeometryCollection arguments");return fs.overlayOp(t,e,ds.DIFFERENCE)},ds.isResultOfOp=function(){if(2===arguments.length){var t=arguments[0],e=arguments[1],n=t.getLocation(0),i=t.getLocation(1);return ds.isResultOfOp(n,i,e)}if(3===arguments.length){var r=arguments[0],s=arguments[1],o=arguments[2];switch(r===de.BOUNDARY&&(r=de.INTERIOR),s===de.BOUNDARY&&(s=de.INTERIOR),o){case ds.INTERSECTION:return r===de.INTERIOR&&s===de.INTERIOR;case ds.UNION:return r===de.INTERIOR||s===de.INTERIOR;case ds.DIFFERENCE:return r===de.INTERIOR&&s!==de.INTERIOR;case ds.SYMDIFFERENCE:return r===de.INTERIOR&&s!==de.INTERIOR||r!==de.INTERIOR&&s===de.INTERIOR}return!1}},ds.INTERSECTION=1,ds.UNION=2,ds.DIFFERENCE=3,ds.SYMDIFFERENCE=4;var _s=Object.freeze({OverlayOp:ds});function ps(){this._edgeRing=null,this._next=null,this._label=-1;var t=arguments[0],e=arguments[1],n=arguments[2],i=arguments[3];Vr.call(this,t,e,n,i)}function ms(){Yr.apply(this),this._line=null;var t=arguments[0];this._line=t}function vs(){this._factory=null,this._deList=new P,this._lowestEdge=null,this._ring=null,this._ringPts=null,this._holes=null,this._shell=null,this._isHole=null,this._isProcessed=!1,this._isIncludedSet=!1,this._isIncluded=!1;var t=arguments[0];this._factory=t}function ys(){}function xs(){Wr.apply(this),this._factory=null;var t=arguments[0];this._factory=t}function Es(){if(this._lineStringAdder=new Is(this),this._graph=null,this._dangles=new P,this._cutEdges=new P,this._invalidRingLines=new P,this._holeList=null,this._shellList=null,this._polyList=null,this._isCheckingRingsValid=!0,this._extractOnlyPolygonal=null,this._geomFactory=null,0===arguments.length)Es.call(this,!1);else if(1===arguments.length){var t=arguments[0];this._extractOnlyPolygonal=t}}function Is(){this.p=null;var t=arguments[0];this.p=t}v(ps,Vr),e(ps.prototype,{getNext:function(){return this._next},isInRing:function(){return null!==this._edgeRing},setRing:function(t){this._edgeRing=t},setLabel:function(t){this._label=t},getLabel:function(){return this._label},setNext:function(t){this._next=t},getRing:function(){return this._edgeRing},interfaces_:function(){return[]},getClass:function(){return ps}}),v(ms,Yr),e(ms.prototype,{getLine:function(){return this._line},interfaces_:function(){return[]},getClass:function(){return ms}}),e(vs.prototype,{isIncluded:function(){return this._isIncluded},getCoordinates:function(){if(null===this._ringPts){for(var t=new b,e=this._deList.iterator();e.hasNext();){var n=e.next(),i=n.getEdge();vs.addEdge(i.getLine().getCoordinates(),n.getEdgeDirection(),t)}this._ringPts=t.toCoordinateArray()}return this._ringPts},isIncludedSet:function(){return this._isIncludedSet},isValid:function(){return this.getCoordinates(),!(this._ringPts.length<=3)&&(this.getRing(),this._ring.isValid())},build:function(t){var e=t;do{this.add(e),e.setRing(this),e=e.getNext(),x.isTrue(null!==e,"found null DE in ring"),x.isTrue(e===t||!e.isInRing(),"found DE already in ring")}while(e!==t)},isOuterHole:function(){return!!this._isHole&&!this.hasShell()},getPolygon:function(){var t=null;if(null!==this._holes){t=new Array(this._holes.size()).fill(null);for(var e=0;e<this._holes.size();e++)t[e]=this._holes.get(e)}return this._factory.createPolygon(this._ring,t)},isHole:function(){return this._isHole},isProcessed:function(){return this._isProcessed},addHole:function(){if(arguments[0]instanceof Yt){var t=arguments[0];null===this._holes&&(this._holes=new P),this._holes.add(t)}else if(arguments[0]instanceof vs){var e=arguments[0];e.setShell(this);var n=e.getRing();null===this._holes&&(this._holes=new P),this._holes.add(n)}},setIncluded:function(t){this._isIncluded=t,this._isIncludedSet=!0},getOuterHole:function(){if(this.isHole())return null;for(var t=0;t<this._deList.size();t++){var e=this._deList.get(t).getSym().getRing();if(e.isOuterHole())return e}return null},computeHole:function(){var t=this.getRing();this._isHole=z.isCCW(t.getCoordinates())},hasShell:function(){return null!==this._shell},isOuterShell:function(){return null!==this.getOuterHole()},getLineString:function(){return this.getCoordinates(),this._factory.createLineString(this._ringPts)},toString:function(){return he.toLineString(new Kt(this.getCoordinates()))},getShell:function(){return this.isHole()?this._shell:this},add:function(t){this._deList.add(t)},getRing:function(){if(null!==this._ring)return this._ring;this.getCoordinates(),this._ringPts.length<3&&Y.out.println(this._ringPts);try{this._ring=this._factory.createLinearRing(this._ringPts)}catch(t){if(!(t instanceof D))throw t;Y.out.println(this._ringPts)}return this._ring},updateIncluded:function(){if(this.isHole())return null;for(var t=0;t<this._deList.size();t++){var e=this._deList.get(t).getSym().getRing().getShell();if(null!==e&&e.isIncludedSet())return this.setIncluded(!e.isIncluded()),null}},setShell:function(t){this._shell=t},setProcessed:function(t){this._isProcessed=t},interfaces_:function(){return[]},getClass:function(){return vs}}),vs.findDirEdgesInRing=function(t){var e=t,n=new P;do{n.add(e),e=e.getNext(),x.isTrue(null!==e,"found null DE in ring"),x.isTrue(e===t||!e.isInRing(),"found DE already in ring")}while(e!==t);return n},vs.addEdge=function(t,e,n){if(e)for(var i=0;i<t.length;i++)n.add(t[i],!1);else for(i=t.length-1;i>=0;i--)n.add(t[i],!1)},vs.findEdgeRingContaining=function(t,e){for(var n=t.getRing(),i=n.getEnvelopeInternal(),r=n.getCoordinateN(0),s=null,o=null,a=e.iterator();a.hasNext();){var u=a.next(),l=u.getRing(),h=l.getEnvelopeInternal();if(!h.equals(i)&&h.contains(i)){r=nt.ptNotInList(n.getCoordinates(),l.getCoordinates());var c=!1;qe.isInRing(r,l.getCoordinates())&&(c=!0),c&&(null===s||o.contains(h))&&(o=(s=u).getRing().getEnvelopeInternal())}}return s},e(ys.prototype,{compare:function(t,e){var n=e;return t.getRing().getEnvelope().compareTo(n.getRing().getEnvelope())},interfaces_:function(){return[_]},getClass:function(){return ys}}),vs.EnvelopeComparator=ys,v(xs,Wr),e(xs.prototype,{findEdgeRing:function(t){var e=new vs(this._factory);return e.build(t),e},computeDepthParity:function(){if(0===arguments.length)for(;;){return null}else arguments.length},computeNextCWEdges:function(){for(var t=this.nodeIterator();t.hasNext();){var e=t.next();xs.computeNextCWEdges(e)}},addEdge:function(t){if(t.isEmpty())return null;var e=nt.removeRepeatedPoints(t.getCoordinates());if(e.length<2)return null;var n=e[0],i=e[e.length-1],r=this.getNode(n),s=this.getNode(i),o=new ps(r,s,e[1],!0),a=new ps(s,r,e[e.length-2],!1),u=new ms(t);u.setDirectedEdges(o,a),this.add(u)},deleteCutEdges:function(){this.computeNextCWEdges(),xs.findLabeledEdgeRings(this._dirEdges);for(var t=new P,e=this._dirEdges.iterator();e.hasNext();){var n=e.next();if(!n.isMarked()){var i=n.getSym();if(n.getLabel()===i.getLabel()){n.setMarked(!0),i.setMarked(!0);var r=n.getEdge();t.add(r.getLine())}}}return t},getEdgeRings:function(){this.computeNextCWEdges(),xs.label(this._dirEdges,-1);var t=xs.findLabeledEdgeRings(this._dirEdges);this.convertMaximalToMinimalEdgeRings(t);for(var e=new P,n=this._dirEdges.iterator();n.hasNext();){var i=n.next();if(!i.isMarked()&&!i.isInRing()){var r=this.findEdgeRing(i);e.add(r)}}return e},getNode:function(t){var e=this.findNode(t);return null===e&&(e=new Ur(t),this.add(e)),e},convertMaximalToMinimalEdgeRings:function(t){for(var e=t.iterator();e.hasNext();){var n=e.next(),i=n.getLabel(),r=xs.findIntersectionNodes(n,i);if(null!==r)for(var s=r.iterator();s.hasNext();){var o=s.next();xs.computeNextCCWEdges(o,i)}}},deleteDangles:function(){for(var t=this.findNodesOfDegree(1),e=new ut,n=new je,i=t.iterator();i.hasNext();)n.push(i.next());for(;!n.isEmpty();){var r=n.pop();xs.deleteAllEdges(r);for(i=r.getOutEdges().getEdges().iterator();i.hasNext();){var s=i.next();s.setMarked(!0);var o=s.getSym();null!==o&&o.setMarked(!0);var a=s.getEdge();e.add(a.getLine());var u=s.getToNode();1===xs.getDegreeNonDeleted(u)&&n.push(u)}}return e},interfaces_:function(){return[]},getClass:function(){return xs}}),xs.findLabeledEdgeRings=function(t){for(var e=new P,n=1,i=t.iterator();i.hasNext();){var r=i.next();if(!r.isMarked()&&!(r.getLabel()>=0)){e.add(r);var s=vs.findDirEdgesInRing(r);xs.label(s,n),n++}}return e},xs.getDegreeNonDeleted=function(t){for(var e=0,n=t.getOutEdges().getEdges().iterator();n.hasNext();){n.next().isMarked()||e++}return e},xs.deleteAllEdges=function(t){for(var e=t.getOutEdges().getEdges().iterator();e.hasNext();){var n=e.next();n.setMarked(!0);var i=n.getSym();null!==i&&i.setMarked(!0)}},xs.label=function(t,e){for(var n=t.iterator();n.hasNext();){n.next().setLabel(e)}},xs.computeNextCWEdges=function(t){for(var e=null,n=null,i=t.getOutEdges().getEdges().iterator();i.hasNext();){var r=i.next();if(!r.isMarked()){if(null===e&&(e=r),null!==n)n.getSym().setNext(r);n=r}}null!==n&&n.getSym().setNext(e)},xs.computeNextCCWEdges=function(t,e){for(var n=null,i=null,r=t.getOutEdges().getEdges(),s=r.size()-1;s>=0;s--){var o=r.get(s),a=o.getSym(),u=null;o.getLabel()===e&&(u=o);var l=null;a.getLabel()===e&&(l=a),null===u&&null===l||(null!==l&&(i=l),null!==u&&(null!==i&&(i.setNext(u),i=null),null===n&&(n=u)))}null!==i&&(x.isTrue(null!==n),i.setNext(n))},xs.getDegree=function(t,e){for(var n=0,i=t.getOutEdges().getEdges().iterator();i.hasNext();){i.next().getLabel()===e&&n++}return n},xs.findIntersectionNodes=function(t,e){var n=t,i=null;do{var r=n.getFromNode();xs.getDegree(r,e)>1&&(null===i&&(i=new P),i.add(r)),n=n.getNext(),x.isTrue(null!==n,"found null DE in ring"),x.isTrue(n===t||!n.isInRing(),"found DE already in ring")}while(n!==t);return i},e(Es.prototype,{getGeometry:function(){return null===this._geomFactory&&(this._geomFactory=new se),this.polygonize(),this._extractOnlyPolygonal?this._geomFactory.buildGeometry(this._polyList):this._geomFactory.createGeometryCollection(se.toGeometryArray(this._polyList))},getInvalidRingLines:function(){return this.polygonize(),this._invalidRingLines},findValidRings:function(t,e,n){for(var i=t.iterator();i.hasNext();){var r=i.next();r.isValid()?e.add(r):n.add(r.getLineString())}},polygonize:function(){if(null!==this._polyList)return null;if(this._polyList=new P,null===this._graph)return null;this._dangles=this._graph.deleteDangles(),this._cutEdges=this._graph.deleteCutEdges();var t=this._graph.getEdgeRings(),e=new P;this._invalidRingLines=new P,this._isCheckingRingsValid?this.findValidRings(t,e,this._invalidRingLines):e=t,this.findShellsAndHoles(e),Es.assignHolesToShells(this._holeList,this._shellList),Te.sort(this._shellList,new vs.EnvelopeComparator);var n=!0;this._extractOnlyPolygonal&&(Es.findDisjointShells(this._shellList),n=!1),this._polyList=Es.extractPolygons(this._shellList,n)},getDangles:function(){return this.polygonize(),this._dangles},getCutEdges:function(){return this.polygonize(),this._cutEdges},getPolygons:function(){return this.polygonize(),this._polyList},add:function(){if(N(arguments[0],S))for(var t=arguments[0].iterator();t.hasNext();){var e=t.next();this.add(e)}else if(arguments[0]instanceof At){var n=arguments[0];this._geomFactory=n.getFactory(),null===this._graph&&(this._graph=new xs(this._geomFactory)),this._graph.addEdge(n)}else if(arguments[0]instanceof K){arguments[0].apply(this._lineStringAdder)}},setCheckRingsValid:function(t){this._isCheckingRingsValid=t},findShellsAndHoles:function(t){this._holeList=new P,this._shellList=new P;for(var e=t.iterator();e.hasNext();){var n=e.next();n.computeHole(),n.isHole()?this._holeList.add(n):this._shellList.add(n)}},interfaces_:function(){return[]},getClass:function(){return Es}}),Es.findOuterShells=function(t){for(var e=t.iterator();e.hasNext();){var n=e.next(),i=n.getOuterHole();null===i||i.isProcessed()||(n.setIncluded(!0),i.setProcessed(!0))}},Es.extractPolygons=function(t,e){for(var n=new P,i=t.iterator();i.hasNext();){var r=i.next();(e||r.isIncluded())&&n.add(r.getPolygon())}return n},Es.assignHolesToShells=function(t,e){for(var n=t.iterator();n.hasNext();){var i=n.next();Es.assignHoleToShell(i,e)}},Es.assignHoleToShell=function(t,e){var n=vs.findEdgeRingContaining(t,e);null!==n&&n.addHole(t)},Es.findDisjointShells=function(t){Es.findOuterShells(t);var e=null;do{e=!1;for(var n=t.iterator();n.hasNext();){var i=n.next();i.isIncludedSet()||(i.updateIncluded(),i.isIncludedSet()||(e=!0))}}while(e)},e(Is.prototype,{filter:function(t){t instanceof At&&this.p.add(t)},interfaces_:function(){return[j]},getClass:function(){return Is}}),Es.LineStringAdder=Is;var Ns=Object.freeze({Polygonizer:Es});function Cs(){}function Ss(){if(this._edgeEnds=new P,1===arguments.length){var t=arguments[0];Ss.call(this,null,t)}else if(2===arguments.length){arguments[0];var e=arguments[1];Qn.call(this,e.getEdge(),e.getCoordinate(),e.getDirectedCoordinate(),new zn(e.getLabel())),this.insert(e)}}function Ls(){pr.apply(this)}function ws(){var t=arguments[0],e=arguments[1];Kn.call(this,t,e)}function Rs(){ti.apply(this)}function Ts(){this._li=new fe,this._ptLocator=new Mn,this._arg=null,this._nodes=new Zn(new Rs),this._im=null,this._isolatedEdges=new P,this._invalidPoint=null;var t=arguments[0];this._arg=t}function Ps(){this._rectEnv=null;var t=arguments[0];this._rectEnv=t.getEnvelopeInternal()}function Os(){this._li=new fe,this._rectEnv=null,this._diagUp0=null,this._diagUp1=null,this._diagDown0=null,this._diagDown1=null;var t=arguments[0];this._rectEnv=t,this._diagUp0=new E(t.getMinX(),t.getMinY()),this._diagUp1=new E(t.getMaxX(),t.getMaxY()),this._diagDown0=new E(t.getMinX(),t.getMaxY()),this._diagDown1=new E(t.getMaxX(),t.getMinY())}function bs(){this._isDone=!1}function Ms(){this._rectangle=null,this._rectEnv=null;var t=arguments[0];this._rectangle=t,this._rectEnv=t.getEnvelopeInternal()}function Ds(){bs.apply(this),this._rectEnv=null,this._intersects=!1;var t=arguments[0];this._rectEnv=t}function As(){bs.apply(this),this._rectSeq=null,this._rectEnv=null,this._containsPoint=!1;var t=arguments[0];this._rectSeq=t.getExteriorRing().getCoordinateSequence(),this._rectEnv=t.getEnvelopeInternal()}function Fs(){bs.apply(this),this._rectEnv=null,this._rectIntersector=null,this._hasIntersection=!1,this._p0=new E,this._p1=new E;var t=arguments[0];this._rectEnv=t.getEnvelopeInternal(),this._rectIntersector=new Os(this._rectEnv)}function Gs(){if(this._relate=null,2===arguments.length){var t=arguments[0],e=arguments[1];gs.call(this,t,e),this._relate=new Ts(this._arg)}else if(3===arguments.length){var n=arguments[0],i=arguments[1],r=arguments[2];gs.call(this,n,i,r),this._relate=new Ts(this._arg)}}e(Cs.prototype,{createEdgeEndForNext:function(t,e,n,i){var r=n.segmentIndex+1;if(r>=t.getNumPoints()&&null===i)return null;var s=t.getCoordinate(r);null!==i&&i.segmentIndex===n.segmentIndex&&(s=i.coord);var o=new Qn(t,n.coord,s,new zn(t.getLabel()));e.add(o)},createEdgeEndForPrev:function(t,e,n,i){var r=n.segmentIndex;if(0===n.dist){if(0===r)return null;r--}var s=t.getCoordinate(r);null!==i&&i.segmentIndex>=r&&(s=i.coord);var o=new zn(t.getLabel());o.flip();var a=new Qn(t,n.coord,s,o);e.add(a)},computeEdgeEnds:function(){if(1===arguments.length){for(var t=arguments[0],e=new P,n=t;n.hasNext();){var i=n.next();this.computeEdgeEnds(i,e)}return e}if(2===arguments.length){var r=arguments[0],s=arguments[1],o=r.getEdgeIntersectionList();o.addEndpoints();var a=o.iterator(),u=null,l=null;if(!a.hasNext())return null;var h=a.next();do{u=l,l=h,h=null,a.hasNext()&&(h=a.next()),null!==l&&(this.createEdgeEndForPrev(r,s,l,u),this.createEdgeEndForNext(r,s,l,h))}while(null!==l)}},interfaces_:function(){return[]},getClass:function(){return Cs}}),v(Ss,Qn),e(Ss.prototype,{insert:function(t){this._edgeEnds.add(t)},print:function(t){t.println("EdgeEndBundle--\x3e Label: "+this._label);for(var e=this.iterator();e.hasNext();){e.next().print(t),t.println()}},iterator:function(){return this._edgeEnds.iterator()},getEdgeEnds:function(){return this._edgeEnds},computeLabelOn:function(t,e){for(var n=0,i=!1,r=this.iterator();r.hasNext();){(s=r.next().getLabel().getLocation(t))===de.BOUNDARY&&n++,s===de.INTERIOR&&(i=!0)}var s=de.NONE;i&&(s=de.INTERIOR),n>0&&(s=ni.determineBoundary(e,n)),this._label.setLocation(t,s)},computeLabelSide:function(t,e){for(var n=this.iterator();n.hasNext();){var i=n.next();if(i.getLabel().isArea()){var r=i.getLabel().getLocation(t,e);if(r===de.INTERIOR)return this._label.setLocation(t,e,de.INTERIOR),null;r===de.EXTERIOR&&this._label.setLocation(t,e,de.EXTERIOR)}}},getLabel:function(){return this._label},computeLabelSides:function(t){this.computeLabelSide(t,Dn.LEFT),this.computeLabelSide(t,Dn.RIGHT)},updateIM:function(t){jn.updateIM(this._label,t)},computeLabel:function(t){for(var e=!1,n=this.iterator();n.hasNext();){n.next().getLabel().isArea()&&(e=!0)}this._label=e?new zn(de.NONE,de.NONE,de.NONE):new zn(de.NONE);for(var i=0;i<2;i++)this.computeLabelOn(i,t),e&&this.computeLabelSides(i)},interfaces_:function(){return[]},getClass:function(){return Ss}}),v(Ls,pr),e(Ls.prototype,{updateIM:function(t){for(var e=this.iterator();e.hasNext();){e.next().updateIM(t)}},insert:function(t){var e=this._edgeMap.get(t);null===e?(e=new Ss(t),this.insertEdgeEnd(t,e)):e.insert(t)},interfaces_:function(){return[]},getClass:function(){return Ls}}),v(ws,Kn),e(ws.prototype,{updateIMFromEdges:function(t){this._edges.updateIM(t)},computeIM:function(t){t.setAtLeastIfValid(this._label.getLocation(0),this._label.getLocation(1),0)},interfaces_:function(){return[]},getClass:function(){return ws}}),v(Rs,ti),e(Rs.prototype,{createNode:function(t){return new ws(t,new Ls)},interfaces_:function(){return[]},getClass:function(){return Rs}}),e(Ts.prototype,{insertEdgeEnds:function(t){for(var e=t.iterator();e.hasNext();){var n=e.next();this._nodes.add(n)}},computeProperIntersectionIM:function(t,e){var n=this._arg[0].getGeometry().getDimension(),i=this._arg[1].getGeometry().getDimension(),r=t.hasProperIntersection(),s=t.hasProperInteriorIntersection();2===n&&2===i?r&&e.setAtLeast("212101212"):2===n&&1===i?(r&&e.setAtLeast("FFF0FFFF2"),s&&e.setAtLeast("1FFFFF1FF")):1===n&&2===i?(r&&e.setAtLeast("F0FFFFFF2"),s&&e.setAtLeast("1F1FFFFFF")):1===n&&1===i&&s&&e.setAtLeast("0FFFFFFFF")},labelIsolatedEdges:function(t,e){for(var n=this._arg[t].getEdgeIterator();n.hasNext();){var i=n.next();i.isIsolated()&&(this.labelIsolatedEdge(i,e,this._arg[e].getGeometry()),this._isolatedEdges.add(i))}},labelIsolatedEdge:function(t,e,n){if(n.getDimension()>0){var i=this._ptLocator.locate(t.getCoordinate(),n);t.getLabel().setAllLocations(e,i)}else t.getLabel().setAllLocations(e,de.EXTERIOR)},computeIM:function(){var t=new _e;if(t.set(de.EXTERIOR,de.EXTERIOR,2),!this._arg[0].getGeometry().getEnvelopeInternal().intersects(this._arg[1].getGeometry().getEnvelopeInternal()))return this.computeDisjointIM(t),t;this._arg[0].computeSelfNodes(this._li,!1),this._arg[1].computeSelfNodes(this._li,!1);var e=this._arg[0].computeEdgeIntersections(this._arg[1],this._li,!1);this.computeIntersectionNodes(0),this.computeIntersectionNodes(1),this.copyNodesAndLabels(0),this.copyNodesAndLabels(1),this.labelIsolatedNodes(),this.computeProperIntersectionIM(e,t);var n=new Cs,i=n.computeEdgeEnds(this._arg[0].getEdgeIterator());this.insertEdgeEnds(i);var r=n.computeEdgeEnds(this._arg[1].getEdgeIterator());return this.insertEdgeEnds(r),this.labelNodeEdges(),this.labelIsolatedEdges(0,1),this.labelIsolatedEdges(1,0),this.updateIM(t),t},labelNodeEdges:function(){for(var t=this._nodes.iterator();t.hasNext();){t.next().getEdges().computeLabelling(this._arg)}},copyNodesAndLabels:function(t){for(var e=this._arg[t].getNodeIterator();e.hasNext();){var n=e.next();this._nodes.addNode(n.getCoordinate()).setLabel(t,n.getLabel().getLocation(t))}},labelIntersectionNodes:function(t){for(var e=this._arg[t].getEdgeIterator();e.hasNext();)for(var n=e.next(),i=n.getLabel().getLocation(t),r=n.getEdgeIntersectionList().iterator();r.hasNext();){var s=r.next(),o=this._nodes.find(s.coord);o.getLabel().isNull(t)&&(i===de.BOUNDARY?o.setLabelBoundary(t):o.setLabel(t,de.INTERIOR))}},labelIsolatedNode:function(t,e){var n=this._ptLocator.locate(t.getCoordinate(),this._arg[e].getGeometry());t.getLabel().setAllLocations(e,n)},computeIntersectionNodes:function(t){for(var e=this._arg[t].getEdgeIterator();e.hasNext();)for(var n=e.next(),i=n.getLabel().getLocation(t),r=n.getEdgeIntersectionList().iterator();r.hasNext();){var s=r.next(),o=this._nodes.addNode(s.coord);i===de.BOUNDARY?o.setLabelBoundary(t):o.getLabel().isNull(t)&&o.setLabel(t,de.INTERIOR)}},labelIsolatedNodes:function(){for(var t=this._nodes.iterator();t.hasNext();){var e=t.next(),n=e.getLabel();x.isTrue(n.getGeometryCount()>0,"node with empty label found"),e.isIsolated()&&(n.isNull(0)?this.labelIsolatedNode(e,0):this.labelIsolatedNode(e,1))}},updateIM:function(t){for(var e=this._isolatedEdges.iterator();e.hasNext();){e.next().updateIM(t)}for(var n=this._nodes.iterator();n.hasNext();){var i=n.next();i.updateIM(t),i.updateIMFromEdges(t)}},computeDisjointIM:function(t){var e=this._arg[0].getGeometry();e.isEmpty()||(t.set(de.INTERIOR,de.EXTERIOR,e.getDimension()),t.set(de.BOUNDARY,de.EXTERIOR,e.getBoundaryDimension()));var n=this._arg[1].getGeometry();n.isEmpty()||(t.set(de.EXTERIOR,de.INTERIOR,n.getDimension()),t.set(de.EXTERIOR,de.BOUNDARY,n.getBoundaryDimension()))},interfaces_:function(){return[]},getClass:function(){return Ts}}),e(Ps.prototype,{isContainedInBoundary:function(t){if(t instanceof Vt)return!1;if(t instanceof Gt)return this.isPointContainedInBoundary(t);if(t instanceof At)return this.isLineStringContainedInBoundary(t);for(var e=0;e<t.getNumGeometries();e++){var n=t.getGeometryN(e);if(!this.isContainedInBoundary(n))return!1}return!0},isLineSegmentContainedInBoundary:function(t,e){if(t.equals(e))return this.isPointContainedInBoundary(t);if(t.x===e.x){if(t.x===this._rectEnv.getMinX()||t.x===this._rectEnv.getMaxX())return!0}else if(t.y===e.y&&(t.y===this._rectEnv.getMinY()||t.y===this._rectEnv.getMaxY()))return!0;return!1},isLineStringContainedInBoundary:function(t){for(var e=t.getCoordinateSequence(),n=new E,i=new E,r=0;r<e.size()-1;r++)if(e.getCoordinate(r,n),e.getCoordinate(r+1,i),!this.isLineSegmentContainedInBoundary(n,i))return!1;return!0},isPointContainedInBoundary:function(){if(arguments[0]instanceof Gt){var t=arguments[0];return this.isPointContainedInBoundary(t.getCoordinate())}if(arguments[0]instanceof E){var e=arguments[0];return e.x===this._rectEnv.getMinX()||e.x===this._rectEnv.getMaxX()||e.y===this._rectEnv.getMinY()||e.y===this._rectEnv.getMaxY()}},contains:function(t){return!!this._rectEnv.contains(t.getEnvelopeInternal())&&!this.isContainedInBoundary(t)},interfaces_:function(){return[]},getClass:function(){return Ps}}),Ps.contains=function(t,e){return new Ps(t).contains(e)},e(Os.prototype,{intersects:function(t,e){var n=new M(t,e);if(!this._rectEnv.intersects(n))return!1;if(this._rectEnv.intersects(t))return!0;if(this._rectEnv.intersects(e))return!0;if(t.compareTo(e)>0){var i=t;t=e,e=i}var r=!1;return e.y>t.y&&(r=!0),r?this._li.computeIntersection(t,e,this._diagDown0,this._diagDown1):this._li.computeIntersection(t,e,this._diagUp0,this._diagUp1),!!this._li.hasIntersection()},interfaces_:function(){return[]},getClass:function(){return Os}}),e(bs.prototype,{applyTo:function(t){for(var e=0;e<t.getNumGeometries()&&!this._isDone;e++){var n=t.getGeometryN(e);if(n instanceof Lt)this.applyTo(n);else if(this.visit(n),this.isDone())return this._isDone=!0,null}},interfaces_:function(){return[]},getClass:function(){return bs}}),e(Ms.prototype,{intersects:function(t){if(!this._rectEnv.intersects(t.getEnvelopeInternal()))return!1;var e=new Ds(this._rectEnv);if(e.applyTo(t),e.intersects())return!0;var n=new As(this._rectangle);if(n.applyTo(t),n.containsPoint())return!0;var i=new Fs(this._rectangle);return i.applyTo(t),!!i.intersects()},interfaces_:function(){return[]},getClass:function(){return Ms}}),Ms.intersects=function(t,e){return new Ms(t).intersects(e)},v(Ds,bs),e(Ds.prototype,{isDone:function(){return!0===this._intersects},visit:function(t){var e=t.getEnvelopeInternal();return this._rectEnv.intersects(e)?this._rectEnv.contains(e)?(this._intersects=!0,null):e.getMinX()>=this._rectEnv.getMinX()&&e.getMaxX()<=this._rectEnv.getMaxX()?(this._intersects=!0,null):e.getMinY()>=this._rectEnv.getMinY()&&e.getMaxY()<=this._rectEnv.getMaxY()?(this._intersects=!0,null):void 0:null},intersects:function(){return this._intersects},interfaces_:function(){return[]},getClass:function(){return Ds}}),v(As,bs),e(As.prototype,{isDone:function(){return!0===this._containsPoint},visit:function(t){if(!(t instanceof Vt))return null;var e=t.getEnvelopeInternal();if(!this._rectEnv.intersects(e))return null;for(var n=new E,i=0;i<4;i++)if(this._rectSeq.getCoordinate(i,n),e.contains(n)&&Ve.containsPointInPolygon(n,t))return this._containsPoint=!0,null},containsPoint:function(){return this._containsPoint},interfaces_:function(){return[]},getClass:function(){return As}}),v(Fs,bs),e(Fs.prototype,{intersects:function(){return this._hasIntersection},isDone:function(){return!0===this._hasIntersection},visit:function(t){var e=t.getEnvelopeInternal();if(!this._rectEnv.intersects(e))return null;var n=be.getLines(t);this.checkIntersectionWithLineStrings(n)},checkIntersectionWithLineStrings:function(t){for(var e=t.iterator();e.hasNext();){var n=e.next();if(this.checkIntersectionWithSegments(n),this._hasIntersection)return null}},checkIntersectionWithSegments:function(t){for(var e=t.getCoordinateSequence(),n=1;n<e.size();n++)if(e.getCoordinate(n-1,this._p0),e.getCoordinate(n,this._p1),this._rectIntersector.intersects(this._p0,this._p1))return this._hasIntersection=!0,null},interfaces_:function(){return[]},getClass:function(){return Fs}}),v(Gs,gs),e(Gs.prototype,{getIntersectionMatrix:function(){return this._relate.computeIM()},interfaces_:function(){return[]},getClass:function(){return Gs}}),Gs.covers=function(t,e){return!(2===e.getDimension()&&t.getDimension()<2)&&(!(1===e.getDimension()&&t.getDimension()<1&&e.getLength()>0)&&(!!t.getEnvelopeInternal().covers(e.getEnvelopeInternal())&&(!!t.isRectangle()||new Gs(t,e).getIntersectionMatrix().isCovers())))},Gs.intersects=function(t,e){if(!t.getEnvelopeInternal().intersects(e.getEnvelopeInternal()))return!1;if(t.isRectangle())return Ms.intersects(t,e);if(e.isRectangle())return Ms.intersects(e,t);if(t.isGeometryCollection()||e.isGeometryCollection()){for(var n=0;n<t.getNumGeometries();n++)for(var i=0;i<e.getNumGeometries();i++)if(t.getGeometryN(n).intersects(e.getGeometryN(i)))return!0;return!1}return new Gs(t,e).getIntersectionMatrix().isIntersects()},Gs.touches=function(t,e){return!!t.getEnvelopeInternal().intersects(e.getEnvelopeInternal())&&new Gs(t,e).getIntersectionMatrix().isTouches(t.getDimension(),e.getDimension())},Gs.relate=function(){return 2===arguments.length?new Gs(arguments[0],arguments[1]).getIntersectionMatrix():3===arguments.length?new Gs(arguments[0],arguments[1],arguments[2]).getIntersectionMatrix():void 0},Gs.overlaps=function(t,e){return!!t.getEnvelopeInternal().intersects(e.getEnvelopeInternal())&&new Gs(t,e).getIntersectionMatrix().isOverlaps(t.getDimension(),e.getDimension())},Gs.crosses=function(t,e){return!!t.getEnvelopeInternal().intersects(e.getEnvelopeInternal())&&new Gs(t,e).getIntersectionMatrix().isCrosses(t.getDimension(),e.getDimension())},Gs.contains=function(t,e){return!(2===e.getDimension()&&t.getDimension()<2)&&(!(1===e.getDimension()&&t.getDimension()<1&&e.getLength()>0)&&(!!t.getEnvelopeInternal().contains(e.getEnvelopeInternal())&&(t.isRectangle()?Ps.contains(t,e):new Gs(t,e).getIntersectionMatrix().isContains())))};var qs=Object.freeze({RelateOp:Gs});function Bs(){this._geomFactory=null,this._skipEmpty=!1,this._inputGeoms=null;var t=arguments[0];this._geomFactory=Bs.extractFactory(t),this._inputGeoms=t}function Vs(){this._pointGeom=null,this._otherGeom=null,this._geomFact=null;var t=arguments[0],e=arguments[1];this._pointGeom=t,this._otherGeom=e,this._geomFact=e.getFactory()}function zs(){this._geometryType=null,this._comps=null;var t=arguments[0],e=arguments[1];this._geometryType=t,this._comps=e}function Ys(){this._inputPolys=null,this._geomFactory=null;var t=arguments[0];this._inputPolys=t,null===this._inputPolys&&(this._inputPolys=new P)}function ks(){if(this._polygons=new P,this._lines=new P,this._points=new P,this._geomFact=null,1===arguments.length){if(N(arguments[0],S)){var t=arguments[0];this.extract(t)}else if(arguments[0]instanceof K){var e=arguments[0];this.extract(e)}}else if(2===arguments.length){var n=arguments[0],i=arguments[1];this._geomFact=i,this.extract(n)}}e(Bs.prototype,{extractElements:function(t,e){if(null===t)return null;for(var n=0;n<t.getNumGeometries();n++){var i=t.getGeometryN(n);this._skipEmpty&&i.isEmpty()||e.add(i)}},combine:function(){for(var t=new P,e=this._inputGeoms.iterator();e.hasNext();){var n=e.next();this.extractElements(n,t)}return 0===t.size()?null!==this._geomFactory?this._geomFactory.createGeometryCollection():null:this._geomFactory.buildGeometry(t)},interfaces_:function(){return[]},getClass:function(){return Bs}}),Bs.combine=function(){if(1===arguments.length)return new Bs(arguments[0]).combine();if(2===arguments.length){var t=arguments[0],e=arguments[1];return new Bs(Bs.createList(t,e)).combine()}if(3===arguments.length){var n=arguments[0],i=arguments[1],r=arguments[2];return new Bs(Bs.createList(n,i,r)).combine()}},Bs.extractFactory=function(t){return t.isEmpty()?null:t.iterator().next().getFactory()},Bs.createList=function(){if(2===arguments.length){var t=arguments[0],e=arguments[1];return(n=new P).add(t),n.add(e),n}if(3===arguments.length){var n,i=arguments[0],r=arguments[1],s=arguments[2];return(n=new P).add(i),n.add(r),n.add(s),n}},e(Vs.prototype,{union:function(){for(var t=new Mn,e=new yt,n=0;n<this._pointGeom.getNumGeometries();n++){var i=this._pointGeom.getGeometryN(n).getCoordinate();t.locate(i,this._otherGeom)===de.EXTERIOR&&e.add(i)}if(0===e.size())return this._otherGeom;var r=null,s=nt.toCoordinateArray(e);return r=1===s.length?this._geomFact.createPoint(s[0]):this._geomFact.createMultiPointFromCoords(s),Bs.combine(r,this._otherGeom)},interfaces_:function(){return[]},getClass:function(){return Vs}}),Vs.union=function(t,e){return new Vs(t,e).union()},e(zs.prototype,{filter:function(t){(null===this._geometryType||zs.isOfType(t,this._geometryType))&&this._comps.add(t)},interfaces_:function(){return[Ct]},getClass:function(){return zs}}),zs.isOfType=function(t,e){return t.getGeometryType()===e||e===K.TYPENAME_LINESTRING&&t.getGeometryType()===K.TYPENAME_LINEARRING},zs.extract=function(){if(2===arguments.length){var t=arguments[0],e=arguments[1];return zs.extract(t,e,new P)}if(3===arguments.length){if(N(arguments[2],w)&&arguments[0]instanceof K&&"string"==typeof arguments[1]){var n=arguments[0],i=arguments[1],r=arguments[2];return n.getGeometryType()===i?r.add(n):n instanceof Lt&&n.apply(new zs(i,r)),r}if(N(arguments[2],w)&&arguments[0]instanceof K&&arguments[1]instanceof Class){var s=arguments[0],o=arguments[1],a=arguments[2];return zs.extract(s,zs.toGeometryType(o),a)}}},e(Ys.prototype,{reduceToGeometries:function(t){for(var e=new P,n=t.iterator();n.hasNext();){var i=n.next(),r=null;N(i,w)?r=this.unionTree(i):i instanceof K&&(r=i),e.add(r)}return e},extractByEnvelope:function(t,e,n){for(var i=new P,r=0;r<e.getNumGeometries();r++){var s=e.getGeometryN(r);s.getEnvelopeInternal().intersects(t)?i.add(s):n.add(s)}return this._geomFactory.buildGeometry(i)},unionOptimized:function(t,e){var n=t.getEnvelopeInternal(),i=e.getEnvelopeInternal();if(!n.intersects(i))return Bs.combine(t,e);if(t.getNumGeometries()<=1&&e.getNumGeometries()<=1)return this.unionActual(t,e);var r=n.intersection(i);return this.unionUsingEnvelopeIntersection(t,e,r)},union:function(){if(null===this._inputPolys)throw new IllegalStateException("union() method cannot be called twice");if(this._inputPolys.isEmpty())return null;this._geomFactory=this._inputPolys.iterator().next().getFactory();for(var t=new Ci(Ys.STRTREE_NODE_CAPACITY),e=this._inputPolys.iterator();e.hasNext();){var n=e.next();t.insert(n.getEnvelopeInternal(),n)}this._inputPolys=null;var i=t.itemsTree();return this.unionTree(i)},binaryUnion:function(){if(1===arguments.length){var t=arguments[0];return this.binaryUnion(t,0,t.size())}if(3===arguments.length){var e=arguments[0],n=arguments[1],i=arguments[2];if(i-n<=1){var r=Ys.getGeometry(e,n);return this.unionSafe(r,null)}if(i-n==2)return this.unionSafe(Ys.getGeometry(e,n),Ys.getGeometry(e,n+1));var s=Math.trunc((i+n)/2),o=(r=this.binaryUnion(e,n,s),this.binaryUnion(e,s,i));return this.unionSafe(r,o)}},repeatedUnion:function(t){for(var e=null,n=t.iterator();n.hasNext();){var i=n.next();e=null===e?i.copy():e.union(i)}return e},unionSafe:function(t,e){return null===t&&null===e?null:null===t?e.copy():null===e?t.copy():this.unionOptimized(t,e)},unionActual:function(t,e){return Ys.restrictToPolygons(t.union(e))},unionTree:function(t){var e=this.reduceToGeometries(t);return this.binaryUnion(e)},unionUsingEnvelopeIntersection:function(t,e,n){var i=new P,r=this.extractByEnvelope(n,t,i),s=this.extractByEnvelope(n,e,i),o=this.unionActual(r,s);return i.add(o),Bs.combine(i)},bufferUnion:function(){if(1===arguments.length){var t=arguments[0];return t.get(0).getFactory().buildGeometry(t).buffer(0)}if(2===arguments.length){var e=arguments[0],n=arguments[1];return e.getFactory().createGeometryCollection([e,n]).buffer(0)}},interfaces_:function(){return[]},getClass:function(){return Ys}}),Ys.restrictToPolygons=function(t){if(N(t,Bt))return t;var e=br.getPolygons(t);return 1===e.size()?e.get(0):t.getFactory().createMultiPolygon(se.toPolygonArray(e))},Ys.getGeometry=function(t,e){return e>=t.size()?null:t.get(e)},Ys.union=function(t){return new Ys(t).union()},Ys.STRTREE_NODE_CAPACITY=4,e(ks.prototype,{unionNoOpt:function(t){var e=this._geomFact.createPoint();return fs.overlayOp(t,e,ds.UNION)},unionWithNull:function(t,e){return null===t&&null===e?null:null===e?t:null===t?e:t.union(e)},extract:function(){if(N(arguments[0],S))for(var t=arguments[0].iterator();t.hasNext();){var e=t.next();this.extract(e)}else if(arguments[0]instanceof K){var n=arguments[0];null===this._geomFact&&(this._geomFact=n.getFactory()),zs.extract(n,K.TYPENAME_POLYGON,this._polygons),zs.extract(n,K.TYPENAME_LINESTRING,this._lines),zs.extract(n,K.TYPENAME_POINT,this._points)}},union:function(){if(null===this._geomFact)return null;var t=null;if(this._points.size()>0){var e=this._geomFact.buildGeometry(this._points);t=this.unionNoOpt(e)}var n=null;if(this._lines.size()>0){var i=this._geomFact.buildGeometry(this._lines);n=this.unionNoOpt(i)}var r=null;this._polygons.size()>0&&(r=Ys.union(this._polygons));var s=this.unionWithNull(n,r),o=null;return o=null===t?s:null===s?t:Vs.union(t,s),null===o?this._geomFact.createGeometryCollection():o},interfaces_:function(){return[]},getClass:function(){return ks}}),ks.union=function(){if(1===arguments.length){if(N(arguments[0],S))return new ks(arguments[0]).union();if(arguments[0]instanceof K)return new ks(arguments[0]).union()}else if(2===arguments.length){return new ks(arguments[0],arguments[1]).union()}};var Us=Object.freeze({UnaryUnionOp:ks});function Xs(){this._geometryFactory=new se,this._geomGraph=null,this._disconnectedRingcoord=null;var t=arguments[0];this._geomGraph=t}function Hs(){this._nodes=new Zn(new Rs)}function Ws(){this._li=new fe,this._geomGraph=null,this._nodeGraph=new Hs,this._invalidPoint=null;var t=arguments[0];this._geomGraph=t}function js(){this._graph=null,this._rings=new P,this._totalEnv=new M,this._index=null,this._nestedPt=null;var t=arguments[0];this._graph=t}function Ks(){if(this._errorType=null,this._pt=null,1===arguments.length){var t=arguments[0];Ks.call(this,t,null)}else if(2===arguments.length){var e=arguments[0],n=arguments[1];this._errorType=e,null!==n&&(this._pt=n.copy())}}function Zs(){this._parentGeometry=null,this._isSelfTouchingRingFormingHoleValid=!1,this._validErr=null;var t=arguments[0];this._parentGeometry=t}e(Xs.prototype,{visitInteriorRing:function(t,e){var n=t.getCoordinates(),i=n[0],r=Xs.findDifferentPoint(n,i),s=e.findEdgeInSameDirection(i,r),o=e.findEdgeEnd(s),a=null;o.getLabel().getLocation(0,Dn.RIGHT)===de.INTERIOR?a=o:o.getSym().getLabel().getLocation(0,Dn.RIGHT)===de.INTERIOR&&(a=o.getSym()),x.isTrue(null!==a,"unable to find dirEdge with Interior on RHS"),this.visitLinkedDirectedEdges(a)},visitShellInteriors:function(t,e){if(t instanceof Vt){var n=t;this.visitInteriorRing(n.getExteriorRing(),e)}if(t instanceof kt)for(var i=t,r=0;r<i.getNumGeometries();r++){n=i.getGeometryN(r);this.visitInteriorRing(n.getExteriorRing(),e)}},getCoordinate:function(){return this._disconnectedRingcoord},setInteriorEdgesInResult:function(t){for(var e=t.getEdgeEnds().iterator();e.hasNext();){var n=e.next();n.getLabel().getLocation(0,Dn.RIGHT)===de.INTERIOR&&n.setInResult(!0)}},visitLinkedDirectedEdges:function(t){var e=t,n=t;do{x.isTrue(null!==n,"found null Directed Edge"),n.setVisited(!0),n=n.getNext()}while(n!==e)},buildEdgeRings:function(t){for(var e=new P,n=t.iterator();n.hasNext();){var i=n.next();if(i.isInResult()&&null===i.getEdgeRing()){var r=new ar(i,this._geometryFactory);r.linkDirectedEdgesForMinimalEdgeRings();var s=r.buildMinimalRings();e.addAll(s)}}return e},hasUnvisitedShellEdge:function(t){for(var e=0;e<t.size();e++){var n=t.get(e);if(!n.isHole()){var i=n.getEdges(),r=i.get(0);if(r.getLabel().getLocation(0,Dn.RIGHT)===de.INTERIOR)for(var s=0;s<i.size();s++)if(!(r=i.get(s)).isVisited())return this._disconnectedRingcoord=r.getCoordinate(),!0}}return!1},isInteriorsConnected:function(){var t=new P;this._geomGraph.computeSplitEdges(t);var e=new ei(new vr);e.addEdges(t),this.setInteriorEdgesInResult(e),e.linkResultDirectedEdges();var n=this.buildEdgeRings(e.getEdgeEnds());return this.visitShellInteriors(this._geomGraph.getGeometry(),e),!this.hasUnvisitedShellEdge(n)},interfaces_:function(){return[]},getClass:function(){return Xs}}),Xs.findDifferentPoint=function(t,e){for(var n=0;n<t.length;n++)if(!t[n].equals(e))return t[n];return null},e(Hs.prototype,{insertEdgeEnds:function(t){for(var e=t.iterator();e.hasNext();){var n=e.next();this._nodes.add(n)}},getNodeIterator:function(){return this._nodes.iterator()},copyNodesAndLabels:function(t,e){for(var n=t.getNodeIterator();n.hasNext();){var i=n.next();this._nodes.addNode(i.getCoordinate()).setLabel(e,i.getLabel().getLocation(e))}},build:function(t){this.computeIntersectionNodes(t,0),this.copyNodesAndLabels(t,0);var e=(new Cs).computeEdgeEnds(t.getEdgeIterator());this.insertEdgeEnds(e)},computeIntersectionNodes:function(t,e){for(var n=t.getEdgeIterator();n.hasNext();)for(var i=n.next(),r=i.getLabel().getLocation(e),s=i.getEdgeIntersectionList().iterator();s.hasNext();){var o=s.next(),a=this._nodes.addNode(o.coord);r===de.BOUNDARY?a.setLabelBoundary(e):a.getLabel().isNull(e)&&a.setLabel(e,de.INTERIOR)}},interfaces_:function(){return[]},getClass:function(){return Hs}}),e(Ws.prototype,{isNodeEdgeAreaLabelsConsistent:function(){for(var t=this._nodeGraph.getNodeIterator();t.hasNext();){var e=t.next();if(!e.getEdges().isAreaLabelsConsistent(this._geomGraph))return this._invalidPoint=e.getCoordinate().copy(),!1}return!0},getInvalidPoint:function(){return this._invalidPoint},hasDuplicateRings:function(){for(var t=this._nodeGraph.getNodeIterator();t.hasNext();)for(var e=t.next().getEdges().iterator();e.hasNext();){var n=e.next();if(n.getEdgeEnds().size()>1)return this._invalidPoint=n.getEdge().getCoordinate(0),!0}return!1},isNodeConsistentArea:function(){var t=this._geomGraph.computeSelfNodes(this._li,!0,!0);return t.hasProperIntersection()?(this._invalidPoint=t.getProperIntersectionPoint(),!1):(this._nodeGraph.build(this._geomGraph),this.isNodeEdgeAreaLabelsConsistent())},interfaces_:function(){return[]},getClass:function(){return Ws}}),e(js.prototype,{buildIndex:function(){this._index=new Ci;for(var t=0;t<this._rings.size();t++){var e=this._rings.get(t),n=e.getEnvelopeInternal();this._index.insert(n,e)}},getNestedPoint:function(){return this._nestedPt},isNonNested:function(){this.buildIndex();for(var t=0;t<this._rings.size();t++)for(var e=this._rings.get(t),n=e.getCoordinates(),i=this._index.query(e.getEnvelopeInternal()),r=0;r<i.size();r++){var s=i.get(r),o=s.getCoordinates();if(e!==s&&e.getEnvelopeInternal().intersects(s.getEnvelopeInternal())){var a=Zs.findPtNotNode(n,s,this._graph);if(null!==a)if(qe.isInRing(a,o))return this._nestedPt=a,!1}}return!0},add:function(t){this._rings.add(t),this._totalEnv.expandToInclude(t.getEnvelopeInternal())},interfaces_:function(){return[]},getClass:function(){return js}}),e(Ks.prototype,{getErrorType:function(){return this._errorType},getMessage:function(){return Ks.errMsg[this._errorType]},getCoordinate:function(){return this._pt},toString:function(){var t="";return null!==this._pt&&(t=" at or near point "+this._pt),this.getMessage()+t},interfaces_:function(){return[]},getClass:function(){return Ks}}),Ks.ERROR=0,Ks.REPEATED_POINT=1,Ks.HOLE_OUTSIDE_SHELL=2,Ks.NESTED_HOLES=3,Ks.DISCONNECTED_INTERIOR=4,Ks.SELF_INTERSECTION=5,Ks.RING_SELF_INTERSECTION=6,Ks.NESTED_SHELLS=7,Ks.DUPLICATE_RINGS=8,Ks.TOO_FEW_POINTS=9,Ks.INVALID_COORDINATE=10,Ks.RING_NOT_CLOSED=11,Ks.errMsg=["Topology Validation Error","Repeated Point","Hole lies outside shell","Holes are nested","Interior is disconnected","Self-intersection","Ring Self-intersection","Nested shells","Duplicate Rings","Too few distinct points in geometry component","Invalid Coordinate","Ring is not closed"],e(Zs.prototype,{checkInvalidCoordinates:function(){if(arguments[0]instanceof Array){for(var t=arguments[0],e=0;e<t.length;e++)if(!Zs.isValid(t[e]))return this._validErr=new Ks(Ks.INVALID_COORDINATE,t[e]),null}else if(arguments[0]instanceof Vt){var n=arguments[0];if(this.checkInvalidCoordinates(n.getExteriorRing().getCoordinates()),null!==this._validErr)return null;for(e=0;e<n.getNumInteriorRing();e++)if(this.checkInvalidCoordinates(n.getInteriorRingN(e).getCoordinates()),null!==this._validErr)return null}},checkHolesNotNested:function(t,e){for(var n=new js(e),i=0;i<t.getNumInteriorRing();i++){var r=t.getInteriorRingN(i);n.add(r)}n.isNonNested()||(this._validErr=new Ks(Ks.NESTED_HOLES,n.getNestedPoint()))},checkConsistentArea:function(t){var e=new Ws(t);if(!e.isNodeConsistentArea())return this._validErr=new Ks(Ks.SELF_INTERSECTION,e.getInvalidPoint()),null;e.hasDuplicateRings()&&(this._validErr=new Ks(Ks.DUPLICATE_RINGS,e.getInvalidPoint()))},isValid:function(){return this.checkValid(this._parentGeometry),null===this._validErr},checkShellInsideHole:function(t,e,n){var i=t.getCoordinates(),r=e.getCoordinates(),s=Zs.findPtNotNode(i,e,n);if(null!==s&&!qe.isInRing(s,r))return s;var o=Zs.findPtNotNode(r,t,n);return null!==o?qe.isInRing(o,i)?o:null:(x.shouldNeverReachHere("points in shell and hole appear to be equal"),null)},checkNoSelfIntersectingRings:function(t){for(var e=t.getEdgeIterator();e.hasNext();){var n=e.next();if(this.checkNoSelfIntersectingRing(n.getEdgeIntersectionList()),null!==this._validErr)return null}},checkConnectedInteriors:function(t){var e=new Xs(t);e.isInteriorsConnected()||(this._validErr=new Ks(Ks.DISCONNECTED_INTERIOR,e.getCoordinate()))},checkNoSelfIntersectingRing:function(t){for(var e=new yt,n=!0,i=t.iterator();i.hasNext();){var r=i.next();if(n)n=!1;else{if(e.contains(r.coord))return this._validErr=new Ks(Ks.RING_SELF_INTERSECTION,r.coord),null;e.add(r.coord)}}},checkHolesInShell:function(t,e){for(var n=t.getExteriorRing(),i=new Ae(n),r=0;r<t.getNumInteriorRing();r++){var s=t.getInteriorRingN(r),o=Zs.findPtNotNode(s.getCoordinates(),n,e);if(null===o)return null;if(de.EXTERIOR===i.locate(o))return this._validErr=new Ks(Ks.HOLE_OUTSIDE_SHELL,o),null}},checkTooFewPoints:function(t){if(t.hasTooFewPoints())return this._validErr=new Ks(Ks.TOO_FEW_POINTS,t.getInvalidPoint()),null},getValidationError:function(){return this.checkValid(this._parentGeometry),this._validErr},checkValid:function(){if(arguments[0]instanceof Gt){var t=arguments[0];this.checkInvalidCoordinates(t.getCoordinates())}else if(arguments[0]instanceof zt){var e=arguments[0];this.checkInvalidCoordinates(e.getCoordinates())}else if(arguments[0]instanceof Yt){var n=arguments[0];if(this.checkInvalidCoordinates(n.getCoordinates()),null!==this._validErr)return null;if(this.checkClosedRing(n),null!==this._validErr)return null;var i=new ni(0,n);if(this.checkTooFewPoints(i),null!==this._validErr)return null;var r=new fe;i.computeSelfNodes(r,!0,!0),this.checkNoSelfIntersectingRings(i)}else if(arguments[0]instanceof At){var s=arguments[0];if(this.checkInvalidCoordinates(s.getCoordinates()),null!==this._validErr)return null;i=new ni(0,s);this.checkTooFewPoints(i)}else if(arguments[0]instanceof Vt){var o=arguments[0];if(this.checkInvalidCoordinates(o),null!==this._validErr)return null;if(this.checkClosedRings(o),null!==this._validErr)return null;i=new ni(0,o);if(this.checkTooFewPoints(i),null!==this._validErr)return null;if(this.checkConsistentArea(i),null!==this._validErr)return null;if(!this._isSelfTouchingRingFormingHoleValid&&(this.checkNoSelfIntersectingRings(i),null!==this._validErr))return null;if(this.checkHolesInShell(o,i),null!==this._validErr)return null;if(this.checkHolesNotNested(o,i),null!==this._validErr)return null;this.checkConnectedInteriors(i)}else if(arguments[0]instanceof kt){for(var a=arguments[0],u=0;u<a.getNumGeometries();u++){var l=a.getGeometryN(u);if(this.checkInvalidCoordinates(l),null!==this._validErr)return null;if(this.checkClosedRings(l),null!==this._validErr)return null}i=new ni(0,a);if(this.checkTooFewPoints(i),null!==this._validErr)return null;if(this.checkConsistentArea(i),null!==this._validErr)return null;if(!this._isSelfTouchingRingFormingHoleValid&&(this.checkNoSelfIntersectingRings(i),null!==this._validErr))return null;for(u=0;u<a.getNumGeometries();u++){l=a.getGeometryN(u);if(this.checkHolesInShell(l,i),null!==this._validErr)return null}for(u=0;u<a.getNumGeometries();u++){l=a.getGeometryN(u);if(this.checkHolesNotNested(l,i),null!==this._validErr)return null}if(this.checkShellsNotNested(a,i),null!==this._validErr)return null;this.checkConnectedInteriors(i)}else if(arguments[0]instanceof Lt){var h=arguments[0];for(u=0;u<h.getNumGeometries();u++){var c=h.getGeometryN(u);if(this.checkValid(c),null!==this._validErr)return null}}else if(arguments[0]instanceof K){var f=arguments[0];if(this._validErr=null,f.isEmpty())return null;if(f instanceof Gt)this.checkValid(f);else if(f instanceof zt)this.checkValid(f);else if(f instanceof Yt)this.checkValid(f);else if(f instanceof At)this.checkValid(f);else if(f instanceof Vt)this.checkValid(f);else if(f instanceof kt)this.checkValid(f);else{if(!(f instanceof Lt))throw new UnsupportedOperationException(f.getClass().getName());this.checkValid(f)}}},setSelfTouchingRingFormingHoleValid:function(t){this._isSelfTouchingRingFormingHoleValid=t},checkShellNotNested:function(t,e,n){var i=t.getCoordinates(),r=e.getExteriorRing(),s=r.getCoordinates(),o=Zs.findPtNotNode(i,r,n);if(null===o)return null;if(!qe.isInRing(o,s))return null;if(e.getNumInteriorRing()<=0)return this._validErr=new Ks(Ks.NESTED_SHELLS,o),null;for(var a=null,u=0;u<e.getNumInteriorRing();u++){var l=e.getInteriorRingN(u);if(null===(a=this.checkShellInsideHole(t,l,n)))return null}this._validErr=new Ks(Ks.NESTED_SHELLS,a)},checkClosedRings:function(t){if(this.checkClosedRing(t.getExteriorRing()),null!==this._validErr)return null;for(var e=0;e<t.getNumInteriorRing();e++)if(this.checkClosedRing(t.getInteriorRingN(e)),null!==this._validErr)return null},checkClosedRing:function(t){if(!t.isClosed()){var e=null;t.getNumPoints()>=1&&(e=t.getCoordinateN(0)),this._validErr=new Ks(Ks.RING_NOT_CLOSED,e)}},checkShellsNotNested:function(t,e){for(var n=0;n<t.getNumGeometries();n++)for(var i=t.getGeometryN(n).getExteriorRing(),r=0;r<t.getNumGeometries();r++)if(n!==r){var s=t.getGeometryN(r);if(this.checkShellNotNested(i,s,e),null!==this._validErr)return null}},interfaces_:function(){return[]},getClass:function(){return Zs}}),Zs.findPtNotNode=function(t,e,n){for(var i=n.findEdge(e).getEdgeIntersectionList(),r=0;r<t.length;r++){var s=t[r];if(!i.isIntersection(s))return s}return null},Zs.isValid=function(){if(arguments[0]instanceof K)return new Zs(arguments[0]).isValid();if(arguments[0]instanceof E){var t=arguments[0];return!s.isNaN(t.x)&&(!s.isInfinite(t.x)&&(!s.isNaN(t.y)&&!s.isInfinite(t.y)))}};var Qs=Object.freeze({IsValidOp:Zs,ConsistentAreaTester:Ws}),Js=Object.freeze({BoundaryOp:Rt,IsSimpleOp:$i,buffer:Or,distance:Gr,linemerge:Zr,overlay:_s,polygonize:Ns,relate:qs,union:Us,valid:Qs});function $s(){Ut.CoordinateOperation.apply(this),this._targetPM=null,this._removeCollapsed=!0;var t=arguments[0],e=arguments[1];this._targetPM=t,this._removeCollapsed=e}function to(){this._targetPM=null,this._removeCollapsed=!0,this._changePrecisionModel=!1,this._isPointwise=!1;var t=arguments[0];this._targetPM=t}v($s,Ut.CoordinateOperation),e($s.prototype,{edit:function(){if(2===arguments.length&&arguments[1]instanceof K&&arguments[0]instanceof Array){var t=arguments[0],e=arguments[1];if(0===t.length)return null;for(var n=new Array(t.length).fill(null),i=0;i<t.length;i++){var r=new E(t[i]);this._targetPM.makePrecise(r),n[i]=r}var s=new b(n,!1).toCoordinateArray(),o=0;e instanceof At&&(o=2),e instanceof Yt&&(o=4);var a=n;return this._removeCollapsed&&(a=null),s.length<o?a:s}return Ut.CoordinateOperation.prototype.edit.apply(this,arguments)},interfaces_:function(){return[]},getClass:function(){return $s}}),e(to.prototype,{fixPolygonalTopology:function(t){var e=t;this._changePrecisionModel||(e=this.changePM(t,this._targetPM));var n=Pr.bufferOp(e,0),i=n;return this._changePrecisionModel||(i=n.copy(),this.changePM(i,t.getPrecisionModel())),i},reducePointwise:function(t){var e=null;this._changePrecisionModel?e=new Ut(this.createFactory(t.getFactory(),this._targetPM)):e=new Ut;var n=this._removeCollapsed;return t.getDimension()>=2&&(n=!0),e.edit(t,new $s(this._targetPM,n))},changePM:function(t,e){return this.createEditor(t.getFactory(),e).edit(t,new Ut.NoOpGeometryOperation)},setRemoveCollapsedComponents:function(t){this._removeCollapsed=t},createFactory:function(t,e){return new se(e,t.getSRID(),t.getCoordinateSequenceFactory())},setChangePrecisionModel:function(t){this._changePrecisionModel=t},reduce:function(t){var e=this.reducePointwise(t);return this._isPointwise?e:N(e,Bt)?Zs.isValid(e)?e:this.fixPolygonalTopology(e):e},setPointwise:function(t){this._isPointwise=t},createEditor:function(t,e){return t.getPrecisionModel()===e?new Ut:new Ut(this.createFactory(t,e))},interfaces_:function(){return[]},getClass:function(){return to}}),to.reduce=function(t,e){return new to(e).reduce(t)},to.reducePointwise=function(t,e){var n=new to(e);return n.setPointwise(!0),n.reduce(t)};var eo=Object.freeze({GeometryPrecisionReducer:to});function no(){this._pts=null,this._usePt=null,this._distanceTolerance=null,this._seg=new ge;var t=arguments[0];this._pts=t}function io(){this._inputGeom=null,this._distanceTolerance=null,this._isEnsureValidTopology=!0;var t=arguments[0];this._inputGeom=t}function ro(){In.apply(this),this._isEnsureValidTopology=!0,this._distanceTolerance=null;var t=arguments[0],e=arguments[1];this._isEnsureValidTopology=t,this._distanceTolerance=e}function so(){if(this._parent=null,this._index=null,2===arguments.length){var t=arguments[0],e=arguments[1];so.call(this,t,e,null,-1)}else if(4===arguments.length){var n=arguments[0],i=arguments[1],r=arguments[2],s=arguments[3];ge.call(this,n,i),this._parent=r,this._index=s}}function oo(){if(this._parentLine=null,this._segs=null,this._resultSegs=new P,this._minimumSize=null,1===arguments.length){var t=arguments[0];oo.call(this,t,2)}else if(2===arguments.length){var e=arguments[0],n=arguments[1];this._parentLine=e,this._minimumSize=n,this.init()}}function ao(){this._index=new di}function uo(){this._querySeg=null,this._items=new P;var t=arguments[0];this._querySeg=t}function lo(){this._li=new fe,this._inputIndex=new ao,this._outputIndex=new ao,this._line=null,this._linePts=null,this._distanceTolerance=0;var t=arguments[0],e=arguments[1];this._inputIndex=t,this._outputIndex=e}function ho(){this._inputIndex=new ao,this._outputIndex=new ao,this._distanceTolerance=0}function co(){this._inputGeom=null,this._lineSimplifier=new ho,this._linestringMap=null;var t=arguments[0];this._inputGeom=t}function fo(){In.apply(this),this._linestringMap=null;var t=arguments[0];this._linestringMap=t}function go(){this.tps=null;var t=arguments[0];this.tps=t}e(no.prototype,{simplifySection:function(t,e){if(t+1===e)return null;this._seg.p0=this._pts[t],this._seg.p1=this._pts[e];for(var n=-1,i=t,r=t+1;r<e;r++){var s=this._seg.distance(this._pts[r]);s>n&&(n=s,i=r)}if(n<=this._distanceTolerance)for(r=t+1;r<e;r++)this._usePt[r]=!1;else this.simplifySection(t,i),this.simplifySection(i,e)},setDistanceTolerance:function(t){this._distanceTolerance=t},simplify:function(){this._usePt=new Array(this._pts.length).fill(null);for(var t=0;t<this._pts.length;t++)this._usePt[t]=!0;this.simplifySection(0,this._pts.length-1);var e=new b;for(t=0;t<this._pts.length;t++)this._usePt[t]&&e.add(new E(this._pts[t]));return e.toCoordinateArray()},interfaces_:function(){return[]},getClass:function(){return no}}),no.simplify=function(t,e){var n=new no(t);return n.setDistanceTolerance(e),n.simplify()},e(io.prototype,{setEnsureValid:function(t){this._isEnsureValidTopology=t},getResultGeometry:function(){return this._inputGeom.isEmpty()?this._inputGeom.copy():new ro(this._isEnsureValidTopology,this._distanceTolerance).transform(this._inputGeom)},setDistanceTolerance:function(t){if(t<0)throw new i("Tolerance must be non-negative");this._distanceTolerance=t},interfaces_:function(){return[]},getClass:function(){return io}}),io.simplify=function(t,e){var n=new io(t);return n.setDistanceTolerance(e),n.getResultGeometry()},v(ro,In),e(ro.prototype,{transformPolygon:function(t,e){if(t.isEmpty())return null;var n=In.prototype.transformPolygon.call(this,t,e);return e instanceof kt?n:this.createValidArea(n)},createValidArea:function(t){return this._isEnsureValidTopology?t.buffer(0):t},transformCoordinates:function(t,e){var n=t.toCoordinateArray(),i=null;return i=0===n.length?new Array(0).fill(null):no.simplify(n,this._distanceTolerance),this._factory.getCoordinateSequenceFactory().create(i)},transformMultiPolygon:function(t,e){var n=In.prototype.transformMultiPolygon.call(this,t,e);return this.createValidArea(n)},transformLinearRing:function(t,e){var n=e instanceof Vt,i=In.prototype.transformLinearRing.call(this,t,e);return!n||i instanceof Yt?i:null},interfaces_:function(){return[]},getClass:function(){return ro}}),io.DPTransformer=ro,v(so,ge),e(so.prototype,{getIndex:function(){return this._index},getParent:function(){return this._parent},interfaces_:function(){return[]},getClass:function(){return so}}),e(oo.prototype,{addToResult:function(t){this._resultSegs.add(t)},asLineString:function(){return this._parentLine.getFactory().createLineString(oo.extractCoordinates(this._resultSegs))},getResultSize:function(){var t=this._resultSegs.size();return 0===t?0:t+1},getParent:function(){return this._parentLine},getSegment:function(t){return this._segs[t]},getParentCoordinates:function(){return this._parentLine.getCoordinates()},getMinimumSize:function(){return this._minimumSize},asLinearRing:function(){return this._parentLine.getFactory().createLinearRing(oo.extractCoordinates(this._resultSegs))},getSegments:function(){return this._segs},init:function(){var t=this._parentLine.getCoordinates();this._segs=new Array(t.length-1).fill(null);for(var e=0;e<t.length-1;e++){var n=new so(t[e],t[e+1],this._parentLine,e);this._segs[e]=n}},getResultCoordinates:function(){return oo.extractCoordinates(this._resultSegs)},interfaces_:function(){return[]},getClass:function(){return oo}}),oo.extractCoordinates=function(t){for(var e=new Array(t.size()+1).fill(null),n=null,i=0;i<t.size();i++)n=t.get(i),e[i]=n.p0;return e[e.length-1]=n.p1,e},e(ao.prototype,{remove:function(t){this._index.remove(new M(t.p0,t.p1),t)},add:function(){if(arguments[0]instanceof oo)for(var t=arguments[0].getSegments(),e=0;e<t.length;e++){var n=t[e];this.add(n)}else if(arguments[0]instanceof ge){var i=arguments[0];this._index.insert(new M(i.p0,i.p1),i)}},query:function(t){var e=new M(t.p0,t.p1),n=new uo(t);return this._index.query(e,n),n.getItems()},interfaces_:function(){return[]},getClass:function(){return ao}}),e(uo.prototype,{visitItem:function(t){var e=t;M.intersects(e.p0,e.p1,this._querySeg.p0,this._querySeg.p1)&&this._items.add(t)},getItems:function(){return this._items},interfaces_:function(){return[Ce]},getClass:function(){return uo}}),e(lo.prototype,{flatten:function(t,e){var n=new ge(this._linePts[t],this._linePts[e]);return this.remove(this._line,t,e),this._outputIndex.add(n),n},hasBadIntersection:function(t,e,n){return!!this.hasBadOutputIntersection(n)||!!this.hasBadInputIntersection(t,e,n)},setDistanceTolerance:function(t){this._distanceTolerance=t},simplifySection:function(t,e,n){n+=1;var i=new Array(2).fill(null);if(t+1===e){var r=this._line.getSegment(t);return this._line.addToResult(r),null}var s=!0;this._line.getResultSize()<this._line.getMinimumSize()&&(n+1<this._line.getMinimumSize()&&(s=!1));var o=new Array(1).fill(null),a=this.findFurthestPoint(this._linePts,t,e,o);o[0]>this._distanceTolerance&&(s=!1);var u=new ge;if(u.p0=this._linePts[t],u.p1=this._linePts[e],i[0]=t,i[1]=e,this.hasBadIntersection(this._line,i,u)&&(s=!1),s){r=this.flatten(t,e);return this._line.addToResult(r),null}this.simplifySection(t,a,n),this.simplifySection(a,e,n)},hasBadOutputIntersection:function(t){for(var e=this._outputIndex.query(t).iterator();e.hasNext();){var n=e.next();if(this.hasInteriorIntersection(n,t))return!0}return!1},findFurthestPoint:function(t,e,n,i){var r=new ge;r.p0=t[e],r.p1=t[n];for(var s=-1,o=e,a=e+1;a<n;a++){var u=t[a],l=r.distance(u);l>s&&(s=l,o=a)}return i[0]=s,o},simplify:function(t){this._line=t,this._linePts=t.getParentCoordinates(),this.simplifySection(0,this._linePts.length-1,0)},remove:function(t,e,n){for(var i=e;i<n;i++){var r=t.getSegment(i);this._inputIndex.remove(r)}},hasInteriorIntersection:function(t,e){return this._li.computeIntersection(t.p0,t.p1,e.p0,e.p1),this._li.isInteriorIntersection()},hasBadInputIntersection:function(t,e,n){for(var i=this._inputIndex.query(n).iterator();i.hasNext();){var r=i.next();if(this.hasInteriorIntersection(r,n)){if(lo.isInLineSection(t,e,r))continue;return!0}}return!1},interfaces_:function(){return[]},getClass:function(){return lo}}),lo.isInLineSection=function(t,e,n){if(n.getParent()!==t.getParent())return!1;var i=n.getIndex();return i>=e[0]&&i<e[1]},e(ho.prototype,{setDistanceTolerance:function(t){this._distanceTolerance=t},simplify:function(t){for(var e=t.iterator();e.hasNext();)this._inputIndex.add(e.next());for(e=t.iterator();e.hasNext();){var n=new lo(this._inputIndex,this._outputIndex);n.setDistanceTolerance(this._distanceTolerance),n.simplify(e.next())}},interfaces_:function(){return[]},getClass:function(){return ho}}),e(co.prototype,{getResultGeometry:function(){return this._inputGeom.isEmpty()?this._inputGeom.copy():(this._linestringMap=new ne,this._inputGeom.apply(new go(this)),this._lineSimplifier.simplify(this._linestringMap.values()),new fo(this._linestringMap).transform(this._inputGeom))},setDistanceTolerance:function(t){if(t<0)throw new i("Tolerance must be non-negative");this._lineSimplifier.setDistanceTolerance(t)},interfaces_:function(){return[]},getClass:function(){return co}}),co.simplify=function(t,e){var n=new co(t);return n.setDistanceTolerance(e),n.getResultGeometry()},v(fo,In),e(fo.prototype,{transformCoordinates:function(t,e){if(0===t.size())return null;if(e instanceof At){var n=this._linestringMap.get(e);return this.createCoordinateSequence(n.getResultCoordinates())}return In.prototype.transformCoordinates.call(this,t,e)},interfaces_:function(){return[]},getClass:function(){return fo}}),e(go.prototype,{filter:function(t){if(t instanceof At){var e=t;if(e.isEmpty())return null;var n=new oo(e,e.isClosed()?4:2);this.tps._linestringMap.put(e,n)}},interfaces_:function(){return[j]},getClass:function(){return go}}),co.LineStringTransformer=fo,co.LineStringMapBuilderFilter=go;var _o=Object.freeze({DouglasPeuckerSimplifier:io,TopologyPreservingSimplifier:co});function po(){this._seg=null,this._segLen=null,this._splitPt=null,this._minimumLen=0;var t=arguments[0];this._seg=t,this._segLen=t.getLength()}function mo(){}function vo(){}function yo(){}function xo(){if(this._p=null,1===arguments.length){var t=arguments[0];this._p=new E(t)}else if(2===arguments.length){var e=arguments[0],n=arguments[1];this._p=new E(e,n)}else if(3===arguments.length){var i=arguments[0],r=arguments[1],s=arguments[2];this._p=new E(i,r,s)}}function Eo(){this._isOnConstraint=null,this._constraint=null;var t=arguments[0];xo.call(this,t)}function Io(){this._rot=null,this._vertex=null,this._next=null,this._data=null}function No(){this._subdiv=null,this._isUsingTolerance=!1;var t=arguments[0];this._subdiv=t,this._isUsingTolerance=t.getTolerance()>0}function Co(){}function So(){this._subdiv=null,this._lastEdge=null;var t=arguments[0];this._subdiv=t,this.init()}function Lo(){if(this._seg=null,1===arguments.length){if("string"==typeof arguments[0]){var t=arguments[0];m.call(this,t)}else if(arguments[0]instanceof ge){var e=arguments[0];m.call(this,"Locate failed to converge (at edge: "+e+").  Possible causes include invalid Subdivision topology or very close sites"),this._seg=new ge(e)}}else if(2===arguments.length){var n=arguments[0],i=arguments[1];m.call(this,Lo.msgWithSpatial(n,i)),this._seg=new ge(i)}}function wo(){}function Ro(){this._visitedKey=0,this._quadEdges=new P,this._startingEdge=null,this._tolerance=null,this._edgeCoincidenceTolerance=null,this._frameVertex=new Array(3).fill(null),this._frameEnv=null,this._locator=null,this._seg=new ge,this._triEdges=new Array(3).fill(null);var t=arguments[0],e=arguments[1];this._tolerance=e,this._edgeCoincidenceTolerance=e/Ro.EDGE_COINCIDENCE_TOL_FACTOR,this.createFrame(t),this._startingEdge=this.initSubdiv(),this._locator=new So(this)}function To(){}function Po(){this._triList=new P}function Oo(){this._triList=new P}function bo(){this._coordList=new b,this._triCoords=new P}function Mo(){if(this._ls=null,this._data=null,2===arguments.length){var t=arguments[0],e=arguments[1];this._ls=new ge(t,e)}else if(3===arguments.length){var n=arguments[0],i=arguments[1],r=arguments[2];this._ls=new ge(n,i),this._data=r}else if(6===arguments.length){var s=arguments[0],o=arguments[1],a=arguments[2],u=arguments[3],l=arguments[4],h=arguments[5];Mo.call(this,new E(s,o,a),new E(u,l,h))}else if(7===arguments.length){var c=arguments[0],f=arguments[1],g=arguments[2],d=arguments[3],_=arguments[4],p=arguments[5],m=arguments[6];Mo.call(this,new E(c,f,g),new E(d,_,p),m)}}function Do(){this._initialVertices=null,this._segVertices=null,this._segments=new P,this._subdiv=null,this._incDel=null,this._convexHull=null,this._splitFinder=new vo,this._kdt=null,this._vertexFactory=null,this._computeAreaEnv=null,this._splitPt=null,this._tolerance=null;var t=arguments[0],e=arguments[1];this._initialVertices=new P(t),this._tolerance=e,this._kdt=new oi(e)}function Ao(){this._siteCoords=null,this._tolerance=0,this._subdiv=null}function Fo(){this._siteCoords=null,this._constraintLines=null,this._tolerance=0,this._subdiv=null,this._constraintVertexMap=new pt}function Go(){this._siteCoords=null,this._tolerance=0,this._subdiv=null,this._clipEnv=null,this._diagramEnv=null}e(po.prototype,{splitAt:function(){if(1===arguments.length){var t=arguments[0],e=this._minimumLen/this._segLen;if(t.distance(this._seg.p0)<this._minimumLen)return this._splitPt=this._seg.pointAlong(e),null;if(t.distance(this._seg.p1)<this._minimumLen)return this._splitPt=po.pointAlongReverse(this._seg,e),null;this._splitPt=t}else if(2===arguments.length){var n=arguments[0],i=arguments[1],r=this.getConstrainedLength(n)/this._segLen;i.equals2D(this._seg.p0)?this._splitPt=this._seg.pointAlong(r):this._splitPt=po.pointAlongReverse(this._seg,r)}},setMinimumLength:function(t){this._minimumLen=t},getConstrainedLength:function(t){return t<this._minimumLen?this._minimumLen:t},getSplitPoint:function(){return this._splitPt},interfaces_:function(){return[]},getClass:function(){return po}}),po.pointAlongReverse=function(t,e){var n=new E;return n.x=t.p1.x-e*(t.p1.x-t.p0.x),n.y=t.p1.y-e*(t.p1.y-t.p0.y),n},e(mo.prototype,{findSplitPoint:function(t,e){},interfaces_:function(){return[]},getClass:function(){return mo}}),e(vo.prototype,{findSplitPoint:function(t,e){var n=t.getLineSegment(),i=n.getLength()/2,r=new po(n),s=vo.projectedSplitPoint(t,e),o=2*s.distance(e)*.8;return o>i&&(o=i),r.setMinimumLength(o),r.splitAt(s),r.getSplitPoint()},interfaces_:function(){return[mo]},getClass:function(){return vo}}),vo.projectedSplitPoint=function(t,e){return t.getLineSegment().project(e)},e(yo.prototype,{interfaces_:function(){return[]},getClass:function(){return yo}}),yo.triArea=function(t,e,n){return(e.x-t.x)*(n.y-t.y)-(e.y-t.y)*(n.x-t.x)},yo.isInCircleDDNormalized=function(t,e,n,i){var r=B.valueOf(t.x).selfSubtract(i.x),s=B.valueOf(t.y).selfSubtract(i.y),o=B.valueOf(e.x).selfSubtract(i.x),a=B.valueOf(e.y).selfSubtract(i.y),u=B.valueOf(n.x).selfSubtract(i.x),l=B.valueOf(n.y).selfSubtract(i.y),h=r.multiply(a).selfSubtract(o.multiply(s)),c=o.multiply(l).selfSubtract(u.multiply(a)),f=u.multiply(s).selfSubtract(r.multiply(l)),g=r.multiply(r).selfAdd(s.multiply(s)),d=o.multiply(o).selfAdd(a.multiply(a)),_=u.multiply(u).selfAdd(l.multiply(l));return g.selfMultiply(c).selfAdd(d.selfMultiply(f)).selfAdd(_.selfMultiply(h)).doubleValue()>0},yo.checkRobustInCircle=function(t,e,n,i){var r=yo.isInCircleNonRobust(t,e,n,i),s=yo.isInCircleDDSlow(t,e,n,i),o=yo.isInCircleCC(t,e,n,i),a=me.circumcentre(t,e,n);Y.out.println("p radius diff a = "+Math.abs(i.distance(a)-t.distance(a))/t.distance(a)),r===s&&r===o||(Y.out.println("inCircle robustness failure (double result = "+r+", DD result = "+s+", CC result = "+o+")"),Y.out.println(he.toLineString(new Kt([t,e,n,i]))),Y.out.println("Circumcentre = "+he.toPoint(a)+" radius = "+t.distance(a)),Y.out.println("p radius diff a = "+Math.abs(i.distance(a)/t.distance(a)-1)),Y.out.println("p radius diff b = "+Math.abs(i.distance(a)/e.distance(a)-1)),Y.out.println("p radius diff c = "+Math.abs(i.distance(a)/n.distance(a)-1)),Y.out.println())},yo.isInCircleDDFast=function(t,e,n,i){var r=B.sqr(t.x).selfAdd(B.sqr(t.y)).selfMultiply(yo.triAreaDDFast(e,n,i)),s=B.sqr(e.x).selfAdd(B.sqr(e.y)).selfMultiply(yo.triAreaDDFast(t,n,i)),o=B.sqr(n.x).selfAdd(B.sqr(n.y)).selfMultiply(yo.triAreaDDFast(t,e,i)),a=B.sqr(i.x).selfAdd(B.sqr(i.y)).selfMultiply(yo.triAreaDDFast(t,e,n));return r.selfSubtract(s).selfAdd(o).selfSubtract(a).doubleValue()>0},yo.isInCircleCC=function(t,e,n,i){var r=me.circumcentre(t,e,n),s=t.distance(r);return i.distance(r)-s<=0},yo.isInCircleNormalized=function(t,e,n,i){var r=t.x-i.x,s=t.y-i.y,o=e.x-i.x,a=e.y-i.y,u=n.x-i.x,l=n.y-i.y;return(r*r+s*s)*(o*l-u*a)+(o*o+a*a)*(u*s-r*l)+(u*u+l*l)*(r*a-o*s)>0},yo.isInCircleDDSlow=function(t,e,n,i){var r=B.valueOf(i.x),s=B.valueOf(i.y),o=B.valueOf(t.x),a=B.valueOf(t.y),u=B.valueOf(e.x),l=B.valueOf(e.y),h=B.valueOf(n.x),c=B.valueOf(n.y),f=o.multiply(o).add(a.multiply(a)).multiply(yo.triAreaDDSlow(u,l,h,c,r,s)),g=u.multiply(u).add(l.multiply(l)).multiply(yo.triAreaDDSlow(o,a,h,c,r,s)),d=h.multiply(h).add(c.multiply(c)).multiply(yo.triAreaDDSlow(o,a,u,l,r,s)),_=r.multiply(r).add(s.multiply(s)).multiply(yo.triAreaDDSlow(o,a,u,l,h,c));return f.subtract(g).add(d).subtract(_).doubleValue()>0},yo.isInCircleNonRobust=function(t,e,n,i){return(t.x*t.x+t.y*t.y)*yo.triArea(e,n,i)-(e.x*e.x+e.y*e.y)*yo.triArea(t,n,i)+(n.x*n.x+n.y*n.y)*yo.triArea(t,e,i)-(i.x*i.x+i.y*i.y)*yo.triArea(t,e,n)>0},yo.isInCircleRobust=function(t,e,n,i){return yo.isInCircleNormalized(t,e,n,i)},yo.triAreaDDSlow=function(t,e,n,i,r,s){return n.subtract(t).multiply(s.subtract(e)).subtract(i.subtract(e).multiply(r.subtract(t)))},yo.triAreaDDFast=function(t,e,n){var i=B.valueOf(e.x).selfSubtract(t.x).selfMultiply(B.valueOf(n.y).selfSubtract(t.y)),r=B.valueOf(e.y).selfSubtract(t.y).selfMultiply(B.valueOf(n.x).selfSubtract(t.x));return i.selfSubtract(r)},e(xo.prototype,{circleCenter:function(t,e){var n=new xo(this.getX(),this.getY()),i=new k(this.bisector(n,t),this.bisector(t,e)),r=null;try{r=new xo(i.getX(),i.getY())}catch(i){if(!(i instanceof A))throw i;Y.err.println("a: "+n+"  b: "+t+"  c: "+e),Y.err.println(i)}return r},dot:function(t){return this._p.x*t.getX()+this._p.y*t.getY()},magn:function(){return Math.sqrt(this._p.x*this._p.x+this._p.y*this._p.y)},getZ:function(){return this._p.z},bisector:function(t,e){var n=e.getX()-t.getX(),i=e.getY()-t.getY();return new k(new k(t.getX()+n/2,t.getY()+i/2,1),new k(t.getX()-i+n/2,t.getY()+n+i/2,1))},equals:function(){if(1===arguments.length){var t=arguments[0];return this._p.x===t.getX()&&this._p.y===t.getY()}if(2===arguments.length){var e=arguments[0],n=arguments[1];return this._p.distance(e.getCoordinate())<n}},getCoordinate:function(){return this._p},isInCircle:function(t,e,n){return yo.isInCircleRobust(t._p,e._p,n._p,this._p)},interpolateZValue:function(t,e,n){var i=t.getX(),r=t.getY(),s=e.getX()-i,o=n.getX()-i,a=e.getY()-r,u=n.getY()-r,l=s*u-o*a,h=this.getX()-i,c=this.getY()-r,f=(u*h-o*c)/l,g=(-a*h+s*c)/l;return t.getZ()+f*(e.getZ()-t.getZ())+g*(n.getZ()-t.getZ())},midPoint:function(t){return new xo((this._p.x+t.getX())/2,(this._p.y+t.getY())/2,(this._p.z+t.getZ())/2)},rightOf:function(t){return this.isCCW(t.dest(),t.orig())},isCCW:function(t,e){return(t._p.x-this._p.x)*(e._p.y-this._p.y)-(t._p.y-this._p.y)*(e._p.x-this._p.x)>0},getX:function(){return this._p.x},crossProduct:function(t){return this._p.x*t.getY()-this._p.y*t.getX()},setZ:function(t){this._p.z=t},times:function(t){return new xo(t*this._p.x,t*this._p.y)},cross:function(){return new xo(this._p.y,-this._p.x)},leftOf:function(t){return this.isCCW(t.orig(),t.dest())},toString:function(){return"POINT ("+this._p.x+" "+this._p.y+")"},sub:function(t){return new xo(this._p.x-t.getX(),this._p.y-t.getY())},getY:function(){return this._p.y},classify:function(t,e){var n=e.sub(t),i=this.sub(t),r=n.crossProduct(i);return r>0?xo.LEFT:r<0?xo.RIGHT:n.getX()*i.getX()<0||n.getY()*i.getY()<0?xo.BEHIND:n.magn()<i.magn()?xo.BEYOND:t.equals(this)?xo.ORIGIN:e.equals(this)?xo.DESTINATION:xo.BETWEEN},sum:function(t){return new xo(this._p.x+t.getX(),this._p.y+t.getY())},distance:function(t,e){return Math.sqrt(Math.pow(e.getX()-t.getX(),2)+Math.pow(e.getY()-t.getY(),2))},circumRadiusRatio:function(t,e){var n=this.circleCenter(t,e),i=this.distance(n,t),r=this.distance(this,t),s=this.distance(t,e);return s<r&&(r=s),(s=this.distance(e,this))<r&&(r=s),i/r},interfaces_:function(){return[]},getClass:function(){return xo}}),xo.interpolateZ=function(){if(3===arguments.length){var t=arguments[0],e=arguments[1],n=arguments[2],i=e.distance(n),r=t.distance(e),s=n.z-e.z;return e.z+s*(r/i)}if(4===arguments.length){var o=arguments[0],a=arguments[1],u=arguments[2],l=arguments[3],h=a.x,c=a.y,f=u.x-h,g=l.x-h,d=u.y-c,_=l.y-c,p=f*_-g*d,m=o.x-h,v=o.y-c,y=(_*m-g*v)/p,x=(-d*m+f*v)/p;return a.z+y*(u.z-a.z)+x*(l.z-a.z)}},xo.LEFT=0,xo.RIGHT=1,xo.BEYOND=2,xo.BEHIND=3,xo.BETWEEN=4,xo.ORIGIN=5,xo.DESTINATION=6,v(Eo,xo),e(Eo.prototype,{getConstraint:function(){return this._constraint},setOnConstraint:function(t){this._isOnConstraint=t},merge:function(t){t._isOnConstraint&&(this._isOnConstraint=!0,this._constraint=t._constraint)},isOnConstraint:function(){return this._isOnConstraint},setConstraint:function(t){this._isOnConstraint=!0,this._constraint=t},interfaces_:function(){return[]},getClass:function(){return Eo}}),e(Io.prototype,{equalsNonOriented:function(t){return!!this.equalsOriented(t)||!!this.equalsOriented(t.sym())},toLineSegment:function(){return new ge(this._vertex.getCoordinate(),this.dest().getCoordinate())},dest:function(){return this.sym().orig()},oNext:function(){return this._next},equalsOriented:function(t){return!(!this.orig().getCoordinate().equals2D(t.orig().getCoordinate())||!this.dest().getCoordinate().equals2D(t.dest().getCoordinate()))},dNext:function(){return this.sym().oNext().sym()},lPrev:function(){return this._next.sym()},rPrev:function(){return this.sym().oNext()},rot:function(){return this._rot},oPrev:function(){return this._rot._next._rot},sym:function(){return this._rot._rot},setOrig:function(t){this._vertex=t},lNext:function(){return this.invRot().oNext().rot()},getLength:function(){return this.orig().getCoordinate().distance(this.dest().getCoordinate())},invRot:function(){return this._rot.sym()},setDest:function(t){this.sym().setOrig(t)},setData:function(t){this._data=t},getData:function(){return this._data},delete:function(){this._rot=null},orig:function(){return this._vertex},rNext:function(){return this._rot._next.invRot()},toString:function(){var t=this._vertex.getCoordinate(),e=this.dest().getCoordinate();return he.toLineString(t,e)},isLive:function(){return null!==this._rot},getPrimary:function(){return this.orig().getCoordinate().compareTo(this.dest().getCoordinate())<=0?this:this.sym()},dPrev:function(){return this.invRot().oNext().invRot()},setNext:function(t){this._next=t},interfaces_:function(){return[]},getClass:function(){return Io}}),Io.makeEdge=function(t,e){var n=new Io,i=new Io,r=new Io,s=new Io;n._rot=i,i._rot=r,r._rot=s,s._rot=n,n.setNext(n),i.setNext(s),r.setNext(r),s.setNext(i);var o=n;return o.setOrig(t),o.setDest(e),o},Io.swap=function(t){var e=t.oPrev(),n=t.sym().oPrev();Io.splice(t,e),Io.splice(t.sym(),n),Io.splice(t,e.lNext()),Io.splice(t.sym(),n.lNext()),t.setOrig(e.dest()),t.setDest(n.dest())},Io.splice=function(t,e){var n=t.oNext().rot(),i=e.oNext().rot(),r=e.oNext(),s=t.oNext(),o=i.oNext(),a=n.oNext();t.setNext(r),e.setNext(s),n.setNext(o),i.setNext(a)},Io.connect=function(t,e){var n=Io.makeEdge(t.dest(),e.orig());return Io.splice(n,t.lNext()),Io.splice(n.sym(),e),n},e(No.prototype,{insertSite:function(t){var e=this._subdiv.locate(t);if(this._subdiv.isVertexOfEdge(e,t))return e;this._subdiv.isOnEdge(e,t.getCoordinate())&&(e=e.oPrev(),this._subdiv.delete(e.oNext()));var n=this._subdiv.makeEdge(e.orig(),t);Io.splice(n,e);var i=n;do{e=(n=this._subdiv.connect(e,n.sym())).oPrev()}while(e.lNext()!==i);for(;;){var r=e.oPrev();if(r.dest().rightOf(e)&&t.isInCircle(e.orig(),r.dest(),e.dest()))Io.swap(e),e=e.oPrev();else{if(e.oNext()===i)return n;e=e.oNext().lPrev()}}},insertSites:function(t){for(var e=t.iterator();e.hasNext();){var n=e.next();this.insertSite(n)}},interfaces_:function(){return[]},getClass:function(){return No}}),e(Co.prototype,{locate:function(t){},interfaces_:function(){return[]},getClass:function(){return Co}}),e(So.prototype,{init:function(){this._lastEdge=this.findEdge()},locate:function(t){this._lastEdge.isLive()||this.init();var e=this._subdiv.locateFromEdge(t,this._lastEdge);return this._lastEdge=e,e},findEdge:function(){return this._subdiv.getEdges().iterator().next()},interfaces_:function(){return[Co]},getClass:function(){return So}}),v(Lo,m),e(Lo.prototype,{getSegment:function(){return this._seg},interfaces_:function(){return[]},getClass:function(){return Lo}}),Lo.msgWithSpatial=function(t,e){return null!==e?t+" [ "+e+" ]":t},e(wo.prototype,{visit:function(t){},interfaces_:function(){return[]},getClass:function(){return wo}}),e(Ro.prototype,{getTriangleVertices:function(t){var e=new Oo;return this.visitTriangles(e,t),e.getTriangleVertices()},isFrameVertex:function(t){return!!t.equals(this._frameVertex[0])||(!!t.equals(this._frameVertex[1])||!!t.equals(this._frameVertex[2]))},isVertexOfEdge:function(t,e){return!(!e.equals(t.orig(),this._tolerance)&&!e.equals(t.dest(),this._tolerance))},connect:function(t,e){var n=Io.connect(t,e);return this._quadEdges.add(n),n},getVoronoiCellPolygon:function(t,e){var n=new P,i=t;do{var r=t.rot().orig().getCoordinate();n.add(r),t=t.oPrev()}while(t!==i);var s=new b;s.addAll(n,!1),s.closeRing(),s.size()<4&&(Y.out.println(s),s.add(s.get(s.size()-1),!0));var o=s.toCoordinateArray(),a=e.createPolygon(e.createLinearRing(o)),u=i.orig();return a.setUserData(u.getCoordinate()),a},setLocator:function(t){this._locator=t},initSubdiv:function(){var t=this.makeEdge(this._frameVertex[0],this._frameVertex[1]),e=this.makeEdge(this._frameVertex[1],this._frameVertex[2]);Io.splice(t.sym(),e);var n=this.makeEdge(this._frameVertex[2],this._frameVertex[0]);return Io.splice(e.sym(),n),Io.splice(n.sym(),t),t},isFrameBorderEdge:function(t){var e=new Array(3).fill(null);Ro.getTriangleEdges(t,e);var n=new Array(3).fill(null);Ro.getTriangleEdges(t.sym(),n);var i=t.lNext().dest();if(this.isFrameVertex(i))return!0;var r=t.sym().lNext().dest();return!!this.isFrameVertex(r)},makeEdge:function(t,e){var n=Io.makeEdge(t,e);return this._quadEdges.add(n),n},visitTriangles:function(t,e){this._visitedKey++;var n=new je;n.push(this._startingEdge);for(var i=new ut;!n.empty();){var r=n.pop();if(!i.contains(r)){var s=this.fetchTriangleToVisit(r,n,e,i);null!==s&&t.visit(s)}}},isFrameEdge:function(t){return!(!this.isFrameVertex(t.orig())&&!this.isFrameVertex(t.dest()))},isOnEdge:function(t,e){return this._seg.setCoordinates(t.orig().getCoordinate(),t.dest().getCoordinate()),this._seg.distance(e)<this._edgeCoincidenceTolerance},getEnvelope:function(){return new M(this._frameEnv)},createFrame:function(t){var e=t.getWidth(),n=t.getHeight(),i=0;i=e>n?10*e:10*n,this._frameVertex[0]=new xo((t.getMaxX()+t.getMinX())/2,t.getMaxY()+i),this._frameVertex[1]=new xo(t.getMinX()-i,t.getMinY()-i),this._frameVertex[2]=new xo(t.getMaxX()+i,t.getMinY()-i),this._frameEnv=new M(this._frameVertex[0].getCoordinate(),this._frameVertex[1].getCoordinate()),this._frameEnv.expandToInclude(this._frameVertex[2].getCoordinate())},getTriangleCoordinates:function(t){var e=new bo;return this.visitTriangles(e,t),e.getTriangles()},getVertices:function(t){for(var e=new ut,n=this._quadEdges.iterator();n.hasNext();){var i=n.next(),r=i.orig();!t&&this.isFrameVertex(r)||e.add(r);var s=i.dest();!t&&this.isFrameVertex(s)||e.add(s)}return e},fetchTriangleToVisit:function(t,e,n,i){var r=t,s=0,o=!1;do{this._triEdges[s]=r,this.isFrameEdge(r)&&(o=!0);var a=r.sym();i.contains(a)||e.push(a),i.add(r),s++,r=r.lNext()}while(r!==t);return o&&!n?null:this._triEdges},getEdges:function(){if(0===arguments.length)return this._quadEdges;if(1===arguments.length){for(var t=arguments[0],e=this.getPrimaryEdges(!1),n=new Array(e.size()).fill(null),i=0,r=e.iterator();r.hasNext();){var s=r.next();n[i++]=t.createLineString([s.orig().getCoordinate(),s.dest().getCoordinate()])}return t.createMultiLineString(n)}},getVertexUniqueEdges:function(t){for(var e=new P,n=new ut,i=this._quadEdges.iterator();i.hasNext();){var r=i.next(),s=r.orig();n.contains(s)||(n.add(s),!t&&this.isFrameVertex(s)||e.add(r));var o=r.sym(),a=o.orig();n.contains(a)||(n.add(a),!t&&this.isFrameVertex(a)||e.add(o))}return e},getTriangleEdges:function(t){var e=new Po;return this.visitTriangles(e,t),e.getTriangleEdges()},getPrimaryEdges:function(t){this._visitedKey++;var e=new P,n=new je;n.push(this._startingEdge);for(var i=new ut;!n.empty();){var r=n.pop();if(!i.contains(r)){var s=r.getPrimary();!t&&this.isFrameEdge(s)||e.add(s),n.push(r.oNext()),n.push(r.sym().oNext()),i.add(r),i.add(r.sym())}}return e},delete:function(t){Io.splice(t,t.oPrev()),Io.splice(t.sym(),t.sym().oPrev());var e=t.sym(),n=t.rot(),i=t.rot().sym();this._quadEdges.remove(t),this._quadEdges.remove(e),this._quadEdges.remove(n),this._quadEdges.remove(i),t.delete(),e.delete(),n.delete(),i.delete()},locateFromEdge:function(t,e){for(var n=0,i=this._quadEdges.size(),r=e;;){if(++n>i)throw new Lo(r.toLineSegment());if(t.equals(r.orig())||t.equals(r.dest()))break;if(t.rightOf(r))r=r.sym();else if(t.rightOf(r.oNext())){if(t.rightOf(r.dPrev()))break;r=r.dPrev()}else r=r.oNext()}return r},getTolerance:function(){return this._tolerance},getVoronoiCellPolygons:function(t){this.visitTriangles(new To,!0);for(var e=new P,n=this.getVertexUniqueEdges(!1).iterator();n.hasNext();){var i=n.next();e.add(this.getVoronoiCellPolygon(i,t))}return e},getVoronoiDiagram:function(t){var e=this.getVoronoiCellPolygons(t);return t.createGeometryCollection(se.toGeometryArray(e))},getTriangles:function(t){for(var e=this.getTriangleCoordinates(!1),n=new Array(e.size()).fill(null),i=0,r=e.iterator();r.hasNext();){var s=r.next();n[i++]=t.createPolygon(t.createLinearRing(s))}return t.createGeometryCollection(n)},insertSite:function(t){var e=this.locate(t);if(t.equals(e.orig(),this._tolerance)||t.equals(e.dest(),this._tolerance))return e;var n=this.makeEdge(e.orig(),t);Io.splice(n,e);var i=n;do{e=(n=this.connect(e,n.sym())).oPrev()}while(e.lNext()!==i);return i},locate:function(){if(1===arguments.length){if(arguments[0]instanceof xo){var t=arguments[0];return this._locator.locate(t)}if(arguments[0]instanceof E){var e=arguments[0];return this._locator.locate(new xo(e))}}else if(2===arguments.length){var n=arguments[0],i=arguments[1],r=this._locator.locate(new xo(n));if(null===r)return null;var s=r;r.dest().getCoordinate().equals2D(n)&&(s=r.sym());var o=s;do{if(o.dest().getCoordinate().equals2D(i))return o;o=o.oNext()}while(o!==s);return null}},interfaces_:function(){return[]},getClass:function(){return Ro}}),Ro.getTriangleEdges=function(t,e){if(e[0]=t,e[1]=e[0].lNext(),e[2]=e[1].lNext(),e[2].lNext()!==e[0])throw new i("Edges do not form a triangle")},e(To.prototype,{visit:function(t){for(var e=t[0].orig().getCoordinate(),n=t[1].orig().getCoordinate(),i=t[2].orig().getCoordinate(),r=new xo(me.circumcentre(e,n,i)),s=0;s<3;s++)t[s].rot().setOrig(r)},interfaces_:function(){return[wo]},getClass:function(){return To}}),e(Po.prototype,{getTriangleEdges:function(){return this._triList},visit:function(t){this._triList.add(t)},interfaces_:function(){return[wo]},getClass:function(){return Po}}),e(Oo.prototype,{visit:function(t){this._triList.add([t[0].orig(),t[1].orig(),t[2].orig()])},getTriangleVertices:function(){return this._triList},interfaces_:function(){return[wo]},getClass:function(){return Oo}}),e(bo.prototype,{checkTriangleSize:function(t){t.length>=2?he.toLineString(t[0],t[1]):t.length>=1&&he.toPoint(t[0])},visit:function(t){this._coordList.clear();for(var e=0;e<3;e++){var n=t[e].orig();this._coordList.add(n.getCoordinate())}if(this._coordList.size()>0){this._coordList.closeRing();var i=this._coordList.toCoordinateArray();if(4!==i.length)return null;this._triCoords.add(i)}},getTriangles:function(){return this._triCoords},interfaces_:function(){return[wo]},getClass:function(){return bo}}),Ro.TriangleCircumcentreVisitor=To,Ro.TriangleEdgesListVisitor=Po,Ro.TriangleVertexListVisitor=Oo,Ro.TriangleCoordinatesVisitor=bo,Ro.EDGE_COINCIDENCE_TOL_FACTOR=1e3,e(Mo.prototype,{getLineSegment:function(){return this._ls},getEndZ:function(){return this._ls.getCoordinate(1).z},getStartZ:function(){return this._ls.getCoordinate(0).z},intersection:function(t){return this._ls.intersection(t.getLineSegment())},getStart:function(){return this._ls.getCoordinate(0)},getEnd:function(){return this._ls.getCoordinate(1)},getEndY:function(){return this._ls.getCoordinate(1).y},getStartX:function(){return this._ls.getCoordinate(0).x},equalsTopo:function(t){return this._ls.equalsTopo(t.getLineSegment())},getStartY:function(){return this._ls.getCoordinate(0).y},setData:function(t){this._data=t},getData:function(){return this._data},getEndX:function(){return this._ls.getCoordinate(1).x},toString:function(){return this._ls.toString()},interfaces_:function(){return[]},getClass:function(){return Mo}}),e(Do.prototype,{getInitialVertices:function(){return this._initialVertices},getKDT:function(){return this._kdt},enforceConstraints:function(){this.addConstraintVertices();var t=0,e=0;do{e=this.enforceGabriel(this._segments),t++}while(e>0&&t<Do.MAX_SPLIT_ITER)},insertSites:function(t){for(var e=t.iterator();e.hasNext();){var n=e.next();this.insertSite(n)}},getVertexFactory:function(){return this._vertexFactory},getPointArray:function(){for(var t=new Array(this._initialVertices.size()+this._segVertices.size()).fill(null),e=0,n=this._initialVertices.iterator();n.hasNext();){var i=n.next();t[e++]=i.getCoordinate()}for(var r=this._segVertices.iterator();r.hasNext();){i=r.next();t[e++]=i.getCoordinate()}return t},setConstraints:function(t,e){this._segments=t,this._segVertices=e},computeConvexHull:function(){var t=new se,e=new Ze(this.getPointArray(),t);this._convexHull=e.getConvexHull()},addConstraintVertices:function(){this.computeConvexHull(),this.insertSites(this._segVertices)},findNonGabrielPoint:function(t){var e=t.getStart(),n=t.getEnd(),i=new E((e.x+n.x)/2,(e.y+n.y)/2),r=e.distance(i),o=new M(i);o.expandBy(r);for(var a=this._kdt.query(o),u=null,l=s.MAX_VALUE,h=a.iterator();h.hasNext();){var c=h.next().getCoordinate();if(!c.equals2D(e)&&!c.equals2D(n)){var f=i.distance(c);if(f<r){(null===u||f<l)&&(u=c,l=f)}}}return u},getConstraintSegments:function(){return this._segments},setSplitPointFinder:function(t){this._splitFinder=t},getConvexHull:function(){return this._convexHull},getTolerance:function(){return this._tolerance},enforceGabriel:function(t){for(var e=new P,n=0,i=new P,r=t.iterator();r.hasNext();){var s=r.next(),o=this.findNonGabrielPoint(s);if(null!==o){this._splitPt=this._splitFinder.findSplitPoint(s,o);var a=this.createVertex(this._splitPt,s);this.insertSite(a).getCoordinate().equals2D(this._splitPt);var u=new Mo(s.getStartX(),s.getStartY(),s.getStartZ(),a.getX(),a.getY(),a.getZ(),s.getData()),l=new Mo(a.getX(),a.getY(),a.getZ(),s.getEndX(),s.getEndY(),s.getEndZ(),s.getData());e.add(u),e.add(l),i.add(s),n+=1}}return t.removeAll(i),t.addAll(e),n},createVertex:function(){if(1===arguments.length){var t=arguments[0],e=null;return e=null!==this._vertexFactory?this._vertexFactory.createVertex(t,null):new Eo(t)}if(2===arguments.length){var n=arguments[0],i=arguments[1];e=null;return(e=null!==this._vertexFactory?this._vertexFactory.createVertex(n,i):new Eo(n)).setOnConstraint(!0),e}},getSubdivision:function(){return this._subdiv},computeBoundingBox:function(){var t=Do.computeVertexEnvelope(this._initialVertices),e=Do.computeVertexEnvelope(this._segVertices),n=new M(t);n.expandToInclude(e);var i=.2*n.getWidth(),r=.2*n.getHeight(),s=Math.max(i,r);this._computeAreaEnv=new M(n),this._computeAreaEnv.expandBy(s)},setVertexFactory:function(t){this._vertexFactory=t},formInitialDelaunay:function(){this.computeBoundingBox(),this._subdiv=new Ro(this._computeAreaEnv,this._tolerance),this._subdiv.setLocator(new So(this._subdiv)),this._incDel=new No(this._subdiv),this.insertSites(this._initialVertices)},insertSite:function(){if(arguments[0]instanceof Eo){var t=arguments[0],e=this._kdt.insert(t.getCoordinate(),t);if(e.isRepeated()){var n=e.getData();return n.merge(t),n}return this._incDel.insertSite(t),t}if(arguments[0]instanceof E){var i=arguments[0];this.insertSite(this.createVertex(i))}},interfaces_:function(){return[]},getClass:function(){return Do}}),Do.computeVertexEnvelope=function(t){for(var e=new M,n=t.iterator();n.hasNext();){var i=n.next();e.expandToInclude(i.getCoordinate())}return e},Do.MAX_SPLIT_ITER=99,e(Ao.prototype,{create:function(){if(null!==this._subdiv)return null;var t=Ao.envelope(this._siteCoords),e=Ao.toVertices(this._siteCoords);this._subdiv=new Ro(t,this._tolerance),new No(this._subdiv).insertSites(e)},setTolerance:function(t){this._tolerance=t},setSites:function(){if(arguments[0]instanceof K){var t=arguments[0];this._siteCoords=Ao.extractUniqueCoordinates(t)}else if(N(arguments[0],S)){var e=arguments[0];this._siteCoords=Ao.unique(nt.toCoordinateArray(e))}},getEdges:function(t){return this.create(),this._subdiv.getEdges(t)},getSubdivision:function(){return this.create(),this._subdiv},getTriangles:function(t){return this.create(),this._subdiv.getTriangles(t)},interfaces_:function(){return[]},getClass:function(){return Ao}}),Ao.extractUniqueCoordinates=function(t){if(null===t)return new b;var e=t.getCoordinates();return Ao.unique(e)},Ao.envelope=function(t){for(var e=new M,n=t.iterator();n.hasNext();){var i=n.next();e.expandToInclude(i)}return e},Ao.unique=function(t){var e=nt.copyDeep(t);return It.sort(e),new b(e,!1)},Ao.toVertices=function(t){for(var e=new P,n=t.iterator();n.hasNext();){var i=n.next();e.add(new xo(i))}return e},e(Fo.prototype,{createSiteVertices:function(t){for(var e=new P,n=t.iterator();n.hasNext();){var i=n.next();this._constraintVertexMap.containsKey(i)||e.add(new Eo(i))}return e},create:function(){if(null!==this._subdiv)return null;var t=Ao.envelope(this._siteCoords),e=new P;null!==this._constraintLines&&(t.expandToInclude(this._constraintLines.getEnvelopeInternal()),this.createVertices(this._constraintLines),e=Fo.createConstraintSegments(this._constraintLines));var n=new Do(this.createSiteVertices(this._siteCoords),this._tolerance);n.setConstraints(e,new P(this._constraintVertexMap.values())),n.formInitialDelaunay(),n.enforceConstraints(),this._subdiv=n.getSubdivision()},setTolerance:function(t){this._tolerance=t},setConstraints:function(t){this._constraintLines=t},setSites:function(t){this._siteCoords=Ao.extractUniqueCoordinates(t)},getEdges:function(t){return this.create(),this._subdiv.getEdges(t)},getSubdivision:function(){return this.create(),this._subdiv},getTriangles:function(t){return this.create(),this._subdiv.getTriangles(t)},createVertices:function(t){for(var e=t.getCoordinates(),n=0;n<e.length;n++){var i=new Eo(e[n]);this._constraintVertexMap.put(e[n],i)}},interfaces_:function(){return[]},getClass:function(){return Fo}}),Fo.createConstraintSegments=function(){if(1===arguments.length){for(var t=arguments[0],e=be.getLines(t),n=new P,i=e.iterator();i.hasNext();){var r=i.next();Fo.createConstraintSegments(r,n)}return n}if(2===arguments.length){var s=arguments[0],o=arguments[1],a=s.getCoordinates();for(i=1;i<a.length;i++)o.add(new Mo(a[i-1],a[i]))}},e(Go.prototype,{create:function(){if(null!==this._subdiv)return null;var t=Ao.envelope(this._siteCoords);this._diagramEnv=t;var e=Math.max(this._diagramEnv.getWidth(),this._diagramEnv.getHeight());this._diagramEnv.expandBy(e),null!==this._clipEnv&&this._diagramEnv.expandToInclude(this._clipEnv);var n=Ao.toVertices(this._siteCoords);this._subdiv=new Ro(t,this._tolerance),new No(this._subdiv).insertSites(n)},getDiagram:function(t){this.create();var e=this._subdiv.getVoronoiDiagram(t);return Go.clipGeometryCollection(e,this._diagramEnv)},setTolerance:function(t){this._tolerance=t},setSites:function(){if(arguments[0]instanceof K){var t=arguments[0];this._siteCoords=Ao.extractUniqueCoordinates(t)}else if(N(arguments[0],S)){var e=arguments[0];this._siteCoords=Ao.unique(nt.toCoordinateArray(e))}},setClipEnvelope:function(t){this._clipEnv=t},getSubdivision:function(){return this.create(),this._subdiv},interfaces_:function(){return[]},getClass:function(){return Go}}),Go.clipGeometryCollection=function(t,e){for(var n=t.getFactory().toGeometry(e),i=new P,r=0;r<t.getNumGeometries();r++){var s=t.getGeometryN(r),o=null;e.contains(s.getEnvelopeInternal())?o=s:e.intersects(s.getEnvelopeInternal())&&(o=n.intersection(s)).setUserData(s.getUserData()),null===o||o.isEmpty()||i.add(o)}return t.getFactory().createGeometryCollection(se.toGeometryArray(i))};var qo=Object.freeze({Vertex:xo}),Bo=Object.freeze({ConformingDelaunayTriangulationBuilder:Fo,DelaunayTriangulationBuilder:Ao,VoronoiDiagramBuilder:Go,quadedge:qo});function Vo(){if(this._componentIndex=0,this._segmentIndex=0,this._segmentFraction=0,0===arguments.length);else if(1===arguments.length){var t=arguments[0];this._componentIndex=t._componentIndex,this._segmentIndex=t._segmentIndex,this._segmentFraction=t._segmentFraction}else if(2===arguments.length){var e=arguments[0],n=arguments[1];Vo.call(this,0,e,n)}else if(3===arguments.length){var i=arguments[0],r=arguments[1],s=arguments[2];this._componentIndex=i,this._segmentIndex=r,this._segmentFraction=s,this.normalize()}else if(4===arguments.length){var o=arguments[0],a=arguments[1],u=arguments[2],l=arguments[3];this._componentIndex=o,this._segmentIndex=a,this._segmentFraction=u,l&&this.normalize()}}function zo(){if(this._linearGeom=null,this._numLines=null,this._currentLine=null,this._componentIndex=0,this._vertexIndex=0,1===arguments.length){var t=arguments[0];zo.call(this,t,0,0)}else if(2===arguments.length){var e=arguments[0],n=arguments[1];zo.call(this,e,n.getComponentIndex(),zo.segmentEndVertexIndex(n))}else if(3===arguments.length){var r=arguments[0],s=arguments[1],o=arguments[2];if(!N(r,mt))throw new i("Lineal geometry is required");this._linearGeom=r,this._numLines=r.getNumGeometries(),this._componentIndex=s,this._vertexIndex=o,this.loadCurrentLine()}}function Yo(){this._linearGeom=null;var t=arguments[0];this._linearGeom=t}function ko(){this._linearGeom=null;var t=arguments[0];this._linearGeom=t}function Uo(){this._geomFact=null,this._lines=new P,this._coordList=null,this._ignoreInvalidLines=!1,this._fixInvalidLines=!1,this._lastPt=null;var t=arguments[0];this._geomFact=t}function Xo(){this._line=null;var t=arguments[0];this._line=t}function Ho(){this._linearGeom=null;var t=arguments[0];this._linearGeom=t,this.checkGeometryType()}function Wo(){this._linearGeom=null;var t=arguments[0];this._linearGeom=t}function jo(){this._linearGeom=null;var t=arguments[0];this._linearGeom=t}function Ko(){this._linearGeom=null;var t=arguments[0];this._linearGeom=t}e(Vo.prototype,{getSegmentIndex:function(){return this._segmentIndex},getComponentIndex:function(){return this._componentIndex},isEndpoint:function(t){var e=t.getGeometryN(this._componentIndex).getNumPoints()-1;return this._segmentIndex>=e||this._segmentIndex===e&&this._segmentFraction>=1},isValid:function(t){if(this._componentIndex<0||this._componentIndex>=t.getNumGeometries())return!1;var e=t.getGeometryN(this._componentIndex);return!(this._segmentIndex<0||this._segmentIndex>e.getNumPoints())&&((this._segmentIndex!==e.getNumPoints()||0===this._segmentFraction)&&!(this._segmentFraction<0||this._segmentFraction>1))},normalize:function(){this._segmentFraction<0&&(this._segmentFraction=0),this._segmentFraction>1&&(this._segmentFraction=1),this._componentIndex<0&&(this._componentIndex=0,this._segmentIndex=0,this._segmentFraction=0),this._segmentIndex<0&&(this._segmentIndex=0,this._segmentFraction=0),1===this._segmentFraction&&(this._segmentFraction=0,this._segmentIndex+=1)},toLowest:function(t){var e=t.getGeometryN(this._componentIndex).getNumPoints()-1;return this._segmentIndex<e?this:new Vo(this._componentIndex,e,1,!1)},getCoordinate:function(t){var e=t.getGeometryN(this._componentIndex),n=e.getCoordinateN(this._segmentIndex);if(this._segmentIndex>=e.getNumPoints()-1)return n;var i=e.getCoordinateN(this._segmentIndex+1);return Vo.pointAlongSegmentByFraction(n,i,this._segmentFraction)},getSegmentFraction:function(){return this._segmentFraction},getSegment:function(t){var e=t.getGeometryN(this._componentIndex),n=e.getCoordinateN(this._segmentIndex);return this._segmentIndex>=e.getNumPoints()-1?new ge(e.getCoordinateN(e.getNumPoints()-2),n):new ge(n,e.getCoordinateN(this._segmentIndex+1))},clamp:function(t){if(this._componentIndex>=t.getNumGeometries())return this.setToEnd(t),null;if(this._segmentIndex>=t.getNumPoints()){var e=t.getGeometryN(this._componentIndex);this._segmentIndex=e.getNumPoints()-1,this._segmentFraction=1}},setToEnd:function(t){this._componentIndex=t.getNumGeometries()-1;var e=t.getGeometryN(this._componentIndex);this._segmentIndex=e.getNumPoints()-1,this._segmentFraction=1},compareTo:function(t){var e=t;return this._componentIndex<e._componentIndex?-1:this._componentIndex>e._componentIndex?1:this._segmentIndex<e._segmentIndex?-1:this._segmentIndex>e._segmentIndex?1:this._segmentFraction<e._segmentFraction?-1:this._segmentFraction>e._segmentFraction?1:0},copy:function(){return new Vo(this._componentIndex,this._segmentIndex,this._segmentFraction)},toString:function(){return"LinearLoc["+this._componentIndex+", "+this._segmentIndex+", "+this._segmentFraction+"]"},isOnSameSegment:function(t){return this._componentIndex===t._componentIndex&&(this._segmentIndex===t._segmentIndex||(t._segmentIndex-this._segmentIndex==1&&0===t._segmentFraction||this._segmentIndex-t._segmentIndex==1&&0===this._segmentFraction))},snapToVertex:function(t,e){if(this._segmentFraction<=0||this._segmentFraction>=1)return null;var n=this.getSegmentLength(t),i=this._segmentFraction*n,r=n-i;i<=r&&i<e?this._segmentFraction=0:r<=i&&r<e&&(this._segmentFraction=1)},compareLocationValues:function(t,e,n){return this._componentIndex<t?-1:this._componentIndex>t?1:this._segmentIndex<e?-1:this._segmentIndex>e?1:this._segmentFraction<n?-1:this._segmentFraction>n?1:0},getSegmentLength:function(t){var e=t.getGeometryN(this._componentIndex),n=this._segmentIndex;this._segmentIndex>=e.getNumPoints()-1&&(n=e.getNumPoints()-2);var i=e.getCoordinateN(n),r=e.getCoordinateN(n+1);return i.distance(r)},isVertex:function(){return this._segmentFraction<=0||this._segmentFraction>=1},interfaces_:function(){return[g]},getClass:function(){return Vo}}),Vo.getEndLocation=function(t){var e=new Vo;return e.setToEnd(t),e},Vo.pointAlongSegmentByFraction=function(t,e,n){return n<=0?t:n>=1?e:new E((e.x-t.x)*n+t.x,(e.y-t.y)*n+t.y,(e.z-t.z)*n+t.z)},Vo.compareLocationValues=function(t,e,n,i,r,s){return t<i?-1:t>i?1:e<r?-1:e>r?1:n<s?-1:n>s?1:0},e(zo.prototype,{getComponentIndex:function(){return this._componentIndex},getLine:function(){return this._currentLine},getVertexIndex:function(){return this._vertexIndex},getSegmentEnd:function(){return this._vertexIndex<this.getLine().getNumPoints()-1?this._currentLine.getCoordinateN(this._vertexIndex+1):null},next:function(){if(!this.hasNext())return null;this._vertexIndex++,this._vertexIndex>=this._currentLine.getNumPoints()&&(this._componentIndex++,this.loadCurrentLine(),this._vertexIndex=0)},loadCurrentLine:function(){if(this._componentIndex>=this._numLines)return this._currentLine=null,null;this._currentLine=this._linearGeom.getGeometryN(this._componentIndex)},getSegmentStart:function(){return this._currentLine.getCoordinateN(this._vertexIndex)},isEndOfLine:function(){return!(this._componentIndex>=this._numLines)&&!(this._vertexIndex<this._currentLine.getNumPoints()-1)},hasNext:function(){return!(this._componentIndex>=this._numLines)&&!(this._componentIndex===this._numLines-1&&this._vertexIndex>=this._currentLine.getNumPoints())},interfaces_:function(){return[]},getClass:function(){return zo}}),zo.segmentEndVertexIndex=function(t){return t.getSegmentFraction()>0?t.getSegmentIndex()+1:t.getSegmentIndex()},e(Yo.prototype,{indexOf:function(t){return this.indexOfFromStart(t,null)},indexOfFromStart:function(t,e){for(var n=s.MAX_VALUE,i=0,r=0,o=-1,a=new ge,u=new zo(this._linearGeom);u.hasNext();u.next())if(!u.isEndOfLine()){a.p0=u.getSegmentStart(),a.p1=u.getSegmentEnd();var l=a.distance(t),h=a.segmentFraction(t),c=u.getComponentIndex(),f=u.getVertexIndex();l<n&&(null===e||e.compareLocationValues(c,f,h)<0)&&(i=c,r=f,o=h,n=l)}return n===s.MAX_VALUE?new Vo(e):new Vo(i,r,o)},indexOfAfter:function(t,e){if(null===e)return this.indexOf(t);var n=Vo.getEndLocation(this._linearGeom);if(n.compareTo(e)<=0)return n;var i=this.indexOfFromStart(t,e);return x.isTrue(i.compareTo(e)>=0,"computed location is before specified minimum location"),i},interfaces_:function(){return[]},getClass:function(){return Yo}}),Yo.indexOf=function(t,e){return new Yo(t).indexOf(e)},Yo.indexOfAfter=function(t,e,n){return new Yo(t).indexOfAfter(e,n)},e(ko.prototype,{indicesOf:function(t){var e=t.getGeometryN(0).getCoordinateN(0),n=t.getGeometryN(t.getNumGeometries()-1),i=n.getCoordinateN(n.getNumPoints()-1),r=new Yo(this._linearGeom),s=new Array(2).fill(null);return s[0]=r.indexOf(e),0===t.getLength()?s[1]=s[0].copy():s[1]=r.indexOfAfter(i,s[0]),s},interfaces_:function(){return[]},getClass:function(){return ko}}),ko.indicesOf=function(t,e){return new ko(t).indicesOf(e)},e(Uo.prototype,{getGeometry:function(){return this.endLine(),this._geomFact.buildGeometry(this._lines)},getLastCoordinate:function(){return this._lastPt},endLine:function(){if(null===this._coordList)return null;if(this._ignoreInvalidLines&&this._coordList.size()<2)return this._coordList=null,null;var t=this._coordList.toCoordinateArray(),e=t;this._fixInvalidLines&&(e=this.validCoordinateSequence(t)),this._coordList=null;var n=null;try{n=this._geomFact.createLineString(e)}catch(t){if(!(t instanceof i))throw t;if(!this._ignoreInvalidLines)throw t}null!==n&&this._lines.add(n)},setFixInvalidLines:function(t){this._fixInvalidLines=t},add:function(){if(1===arguments.length){var t=arguments[0];this.add(t,!0)}else if(2===arguments.length){var e=arguments[0],n=arguments[1];null===this._coordList&&(this._coordList=new b),this._coordList.add(e,n),this._lastPt=e}},setIgnoreInvalidLines:function(t){this._ignoreInvalidLines=t},validCoordinateSequence:function(t){return t.length>=2?t:[t[0],t[0]]},interfaces_:function(){return[]},getClass:function(){return Uo}}),e(Xo.prototype,{computeLinear:function(t,e){var n=new Uo(this._line.getFactory());n.setFixInvalidLines(!0),t.isVertex()||n.add(t.getCoordinate(this._line));for(var i=new zo(this._line,t);i.hasNext()&&!(e.compareLocationValues(i.getComponentIndex(),i.getVertexIndex(),0)<0);i.next()){var r=i.getSegmentStart();n.add(r),i.isEndOfLine()&&n.endLine()}return e.isVertex()||n.add(e.getCoordinate(this._line)),n.getGeometry()},computeLine:function(t,e){var n=this._line.getCoordinates(),i=new b,r=t.getSegmentIndex();t.getSegmentFraction()>0&&(r+=1);var s=e.getSegmentIndex();1===e.getSegmentFraction()&&(s+=1),s>=n.length&&(s=n.length-1),t.isVertex()||i.add(t.getCoordinate(this._line));for(var o=r;o<=s;o++)i.add(n[o]);e.isVertex()||i.add(e.getCoordinate(this._line)),i.size()<=0&&i.add(t.getCoordinate(this._line));var a=i.toCoordinateArray();return a.length<=1&&(a=[a[0],a[0]]),this._line.getFactory().createLineString(a)},extract:function(t,e){return e.compareTo(t)<0?this.reverse(this.computeLinear(e,t)):this.computeLinear(t,e)},reverse:function(t){return t instanceof At?t.reverse():t instanceof wt?t.reverse():(x.shouldNeverReachHere("non-linear geometry encountered"),null)},interfaces_:function(){return[]},getClass:function(){return Xo}}),Xo.extract=function(t,e,n){return new Xo(t).extract(e,n)},e(Ho.prototype,{clampIndex:function(t){var e=t.copy();return e.clamp(this._linearGeom),e},project:function(t){return Yo.indexOf(this._linearGeom,t)},checkGeometryType:function(){if(!(this._linearGeom instanceof At||this._linearGeom instanceof wt))throw new i("Input geometry must be linear")},extractPoint:function(){if(1===arguments.length)return arguments[0].getCoordinate(this._linearGeom);if(2===arguments.length){var t=arguments[0],e=arguments[1],n=t.toLowest(this._linearGeom);return n.getSegment(this._linearGeom).pointAlongOffset(n.getSegmentFraction(),e)}},isValidIndex:function(t){return t.isValid(this._linearGeom)},getEndIndex:function(){return Vo.getEndLocation(this._linearGeom)},getStartIndex:function(){return new Vo},indexOfAfter:function(t,e){return Yo.indexOfAfter(this._linearGeom,t,e)},extractLine:function(t,e){return Xo.extract(this._linearGeom,t,e)},indexOf:function(t){return Yo.indexOf(this._linearGeom,t)},indicesOf:function(t){return ko.indicesOf(this._linearGeom,t)},interfaces_:function(){return[]},getClass:function(){return Ho}}),e(Wo.prototype,{indexOf:function(t){return this.indexOfFromStart(t,-1)},indexOfFromStart:function(t,e){for(var n=s.MAX_VALUE,i=e,r=0,o=new ge,a=new zo(this._linearGeom);a.hasNext();){if(!a.isEndOfLine()){o.p0=a.getSegmentStart(),o.p1=a.getSegmentEnd();var u=o.distance(t),l=this.segmentNearestMeasure(o,t,r);u<n&&l>e&&(i=l,n=u),r+=o.getLength()}a.next()}return i},indexOfAfter:function(t,e){if(e<0)return this.indexOf(t);var n=this._linearGeom.getLength();if(n<e)return n;var i=this.indexOfFromStart(t,e);return x.isTrue(i>=e,"computed index is before specified minimum index"),i},segmentNearestMeasure:function(t,e,n){var i=t.projectionFactor(e);return i<=0?n:i<=1?n+i*t.getLength():n+t.getLength()},interfaces_:function(){return[]},getClass:function(){return Wo}}),Wo.indexOf=function(t,e){return new Wo(t).indexOf(e)},Wo.indexOfAfter=function(t,e,n){return new Wo(t).indexOfAfter(e,n)},e(jo.prototype,{getLength:function(t){for(var e=0,n=new zo(this._linearGeom);n.hasNext();){if(!n.isEndOfLine()){var i=n.getSegmentStart(),r=n.getSegmentEnd().distance(i);if(t.getComponentIndex()===n.getComponentIndex()&&t.getSegmentIndex()===n.getVertexIndex())return e+r*t.getSegmentFraction();e+=r}n.next()}return e},resolveHigher:function(t){if(!t.isEndpoint(this._linearGeom))return t;var e=t.getComponentIndex();if(e>=this._linearGeom.getNumGeometries()-1)return t;do{e++}while(e<this._linearGeom.getNumGeometries()-1&&0===this._linearGeom.getGeometryN(e).getLength());return new Vo(e,0,0)},getLocation:function(){if(1===arguments.length){var t=arguments[0];return this.getLocation(t,!0)}if(2===arguments.length){var e=arguments[0],n=arguments[1],i=e;if(e<0)i=this._linearGeom.getLength()+e;var r=this.getLocationForward(i);return n?r:this.resolveHigher(r)}},getLocationForward:function(t){if(t<=0)return new Vo;for(var e=0,n=new zo(this._linearGeom);n.hasNext();){if(n.isEndOfLine()){if(e===t)return new Vo(n.getComponentIndex(),n.getVertexIndex(),0)}else{var i=n.getSegmentStart(),r=n.getSegmentEnd().distance(i);if(e+r>t){var s=(t-e)/r;return new Vo(n.getComponentIndex(),n.getVertexIndex(),s)}e+=r}n.next()}return Vo.getEndLocation(this._linearGeom)},interfaces_:function(){return[]},getClass:function(){return jo}}),jo.getLength=function(t,e){return new jo(t).getLength(e)},jo.getLocation=function(){if(2===arguments.length){var t=arguments[0],e=arguments[1];return new jo(t).getLocation(e)}if(3===arguments.length){var n=arguments[0],i=arguments[1],r=arguments[2];return new jo(n).getLocation(i,r)}},e(Ko.prototype,{clampIndex:function(t){var e=this.positiveIndex(t),n=this.getStartIndex();if(e<n)return n;var i=this.getEndIndex();return e>i?i:e},locationOf:function(){if(1===arguments.length){var t=arguments[0];return jo.getLocation(this._linearGeom,t)}if(2===arguments.length){var e=arguments[0],n=arguments[1];return jo.getLocation(this._linearGeom,e,n)}},project:function(t){return Wo.indexOf(this._linearGeom,t)},positiveIndex:function(t){return t>=0?t:this._linearGeom.getLength()+t},extractPoint:function(){if(1===arguments.length){var t=arguments[0];return jo.getLocation(this._linearGeom,t).getCoordinate(this._linearGeom)}if(2===arguments.length){var e=arguments[0],n=arguments[1],i=jo.getLocation(this._linearGeom,e).toLowest(this._linearGeom);return i.getSegment(this._linearGeom).pointAlongOffset(i.getSegmentFraction(),n)}},isValidIndex:function(t){return t>=this.getStartIndex()&&t<=this.getEndIndex()},getEndIndex:function(){return this._linearGeom.getLength()},getStartIndex:function(){return 0},indexOfAfter:function(t,e){return Wo.indexOfAfter(this._linearGeom,t,e)},extractLine:function(t,e){new Ho(this._linearGeom);var n=this.clampIndex(t),i=this.clampIndex(e),r=n===i,s=this.locationOf(n,r),o=this.locationOf(i);return Xo.extract(this._linearGeom,s,o)},indexOf:function(t){return Wo.indexOf(this._linearGeom,t)},indicesOf:function(t){var e=ko.indicesOf(this._linearGeom,t);return[jo.getLength(this._linearGeom,e[0]),jo.getLength(this._linearGeom,e[1])]},interfaces_:function(){return[]},getClass:function(){return Ko}});var Zo=Object.freeze({LengthIndexedLine:Ko,LengthLocationMap:jo,LinearGeometryBuilder:Uo,LinearIterator:zo,LinearLocation:Vo,LocationIndexedLine:Ho});function Qo(){}e(Qo.prototype,{interfaces_:function(){return[]},getClass:function(){return Qo}}),Qo.union=function(t,e){if(t.isEmpty()||e.isEmpty()){if(t.isEmpty()&&e.isEmpty())return ds.createEmptyResult(ds.UNION,t,e,t.getFactory());if(t.isEmpty())return e.copy();if(e.isEmpty())return t.copy()}return t.checkNotGeometryCollection(t),t.checkNotGeometryCollection(e),fs.overlayOp(t,e,ds.UNION)},e(K.prototype,{equalsTopo:function(t){return!!this.getEnvelopeInternal().equals(t.getEnvelopeInternal())&&Gs.relate(this,t).isEquals(this.getDimension(),t.getDimension())},union:function(){if(0===arguments.length)return ks.union(this);if(1===arguments.length){var t=arguments[0];return Qo.union(this,t)}},isValid:function(){return Zs.isValid(this)},intersection:function(t){if(this.isEmpty()||t.isEmpty())return ds.createEmptyResult(ds.INTERSECTION,this,t,this._factory);if(this.isGeometryCollection()){var e=t;return es.map(this,{interfaces_:function(){return[MapOp]},map:function(t){return t.intersection(e)}})}return this.checkNotGeometryCollection(this),this.checkNotGeometryCollection(t),fs.overlayOp(this,t,ds.INTERSECTION)},covers:function(t){return Gs.covers(this,t)},coveredBy:function(t){return Gs.covers(t,this)},touches:function(t){return Gs.touches(this,t)},intersects:function(t){return Gs.intersects(this,t)},within:function(t){return Gs.within(this,t)},overlaps:function(t){return Gs.overlaps(this,t)},disjoint:function(t){return Gs.disjoint(this,t)},crosses:function(t){return Gs.crosses(this,t)},buffer:function(){if(1===arguments.length){var t=arguments[0];return Pr.bufferOp(this,t)}if(2===arguments.length){var e=arguments[0],n=arguments[1];return Pr.bufferOp(this,e,n)}if(3===arguments.length){var i=arguments[0],r=arguments[1],s=arguments[2];return Pr.bufferOp(this,i,r,s)}},convexHull:function(){return new Ze(this).getConvexHull()},relate:function(){for(var t=arguments.length,e=Array(t),n=0;n<t;n++)e[n]=arguments[n];if(1===arguments.length){var i=arguments[0];return Gs.relate(this,i)}if(2===arguments.length){var r=arguments[0],s=arguments[1];return Gs.relate(this,r).matches(s)}},getCentroid:function(){if(this.isEmpty())return this._factory.createPoint();var t=Xe.getCentroid(this);return this.createPointFromInternalCoord(t,this)},getInteriorPoint:function(){if(this.isEmpty())return this._factory.createPoint();var t=null,e=this.getDimension();if(0===e)t=new en(this).getInteriorPoint();else if(1===e){t=new tn(this).getInteriorPoint()}else{t=new Je(this).getInteriorPoint()}return this.createPointFromInternalCoord(t,this)},symDifference:function(t){if(this.isEmpty()||t.isEmpty()){if(this.isEmpty()&&t.isEmpty())return ds.createEmptyResult(ds.SYMDIFFERENCE,this,t,this._factory);if(this.isEmpty())return t.copy();if(t.isEmpty())return this.copy()}return this.checkNotGeometryCollection(this),this.checkNotGeometryCollection(t),fs.overlayOp(this,t,ds.SYMDIFFERENCE)},createPointFromInternalCoord:function(t,e){return e.getPrecisionModel().makePrecise(t),e.getFactory().createPoint(t)},toText:function(){return(new he).write(this)},toString:function(){this.toText()},contains:function(t){return Gs.contains(this,t)},difference:function(t){return this.isEmpty()?ds.createEmptyResult(ds.DIFFERENCE,this,t,this._factory):t.isEmpty()?this.copy():(this.checkNotGeometryCollection(this),this.checkNotGeometryCollection(t),fs.overlayOp(this,t,ds.DIFFERENCE))},isSimple:function(){return new $i(this).isSimple()},isWithinDistance:function(t,e){return!(this.getEnvelopeInternal().distance(t.getEnvelopeInternal())>e)&&Fr.isWithinDistance(this,t,e)},distance:function(t){return Fr.distance(this,t)},isEquivalentClass:function(t){return this.getClass()===t.getClass()}});t.version="1.6.0 (ac4d0f6)",t.algorithm=En,t.densify=Sn,t.dissolve=bn,t.geom=ve,t.geomgraph=ii,t.index=wi,t.io=Gi,t.noding=Ji,t.operation=Js,t.precision=eo,t.simplify=_o,t.triangulate=Bo,t.linearref=Zo,Object.defineProperty(t,"__esModule",{value:!0})});
 //# sourceMappingURL=jsts.min.js.map
 /*
  * from cdn  https://npmcdn.com/leaflet@1.0.0-rc.3/dist/leaflet.js
  Leaflet 1.0.0-rc.3, a JS library for interactive maps. http://leafletjs.com
  (c) 2010-2015 Vladimir Agafonkin, (c) 2010-2011 CloudMade
 */
 !function(t,e,i){function n(){var e=t.L;o.noConflict=function(){return t.L=e,this},t.L=o}var o={version:"1.0.0-rc.3"};"object"==typeof module&&"object"==typeof module.exports?module.exports=o:"function"==typeof define&&define.amd&&define(o),"undefined"!=typeof t&&n(),o.Util={extend:function(t){var e,i,n,o;for(i=1,n=arguments.length;i<n;i++){o=arguments[i];for(e in o)t[e]=o[e]}return t},create:Object.create||function(){function t(){}return function(e){return t.prototype=e,new t}}(),bind:function(t,e){var i=Array.prototype.slice;if(t.bind)return t.bind.apply(t,i.call(arguments,1));var n=i.call(arguments,2);return function(){return t.apply(e,n.length?n.concat(i.call(arguments)):arguments)}},stamp:function(t){return t._leaflet_id=t._leaflet_id||++o.Util.lastId,t._leaflet_id},lastId:0,throttle:function(t,e,i){var n,o,s,r;return r=function(){n=!1,o&&(s.apply(i,o),o=!1)},s=function(){n?o=arguments:(t.apply(i,arguments),setTimeout(r,e),n=!0)}},wrapNum:function(t,e,i){var n=e[1],o=e[0],s=n-o;return t===n&&i?t:((t-o)%s+s)%s+o},falseFn:function(){return!1},formatNum:function(t,e){var i=Math.pow(10,e||5);return Math.round(t*i)/i},trim:function(t){return t.trim?t.trim():t.replace(/^\s+|\s+$/g,"")},splitWords:function(t){return o.Util.trim(t).split(/\s+/)},setOptions:function(t,e){t.hasOwnProperty("options")||(t.options=t.options?o.Util.create(t.options):{});for(var i in e)t.options[i]=e[i];return t.options},getParamString:function(t,e,i){var n=[];for(var o in t)n.push(encodeURIComponent(i?o.toUpperCase():o)+"="+encodeURIComponent(t[o]));return(e&&e.indexOf("?")!==-1?"&":"?")+n.join("&")},template:function(t,e){return t.replace(o.Util.templateRe,function(t,n){var o=e[n];if(o===i)throw new Error("No value provided for variable "+t);return"function"==typeof o&&(o=o(e)),o})},templateRe:/\{ *([\w_\-]+) *\}/g,isArray:Array.isArray||function(t){return"[object Array]"===Object.prototype.toString.call(t)},indexOf:function(t,e){for(var i=0;i<t.length;i++)if(t[i]===e)return i;return-1},emptyImageUrl:"data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs="},function(){function e(e){return t["webkit"+e]||t["moz"+e]||t["ms"+e]}function i(e){var i=+new Date,o=Math.max(0,16-(i-n));return n=i+o,t.setTimeout(e,o)}var n=0,s=t.requestAnimationFrame||e("RequestAnimationFrame")||i,r=t.cancelAnimationFrame||e("CancelAnimationFrame")||e("CancelRequestAnimationFrame")||function(e){t.clearTimeout(e)};o.Util.requestAnimFrame=function(e,n,r){return r&&s===i?void e.call(n):s.call(t,o.bind(e,n))},o.Util.cancelAnimFrame=function(e){e&&r.call(t,e)}}(),o.extend=o.Util.extend,o.bind=o.Util.bind,o.stamp=o.Util.stamp,o.setOptions=o.Util.setOptions,o.Class=function(){},o.Class.extend=function(t){var e=function(){this.initialize&&this.initialize.apply(this,arguments),this.callInitHooks()},i=e.__super__=this.prototype,n=o.Util.create(i);n.constructor=e,e.prototype=n;for(var s in this)this.hasOwnProperty(s)&&"prototype"!==s&&(e[s]=this[s]);return t.statics&&(o.extend(e,t.statics),delete t.statics),t.includes&&(o.Util.extend.apply(null,[n].concat(t.includes)),delete t.includes),n.options&&(t.options=o.Util.extend(o.Util.create(n.options),t.options)),o.extend(n,t),n._initHooks=[],n.callInitHooks=function(){if(!this._initHooksCalled){i.callInitHooks&&i.callInitHooks.call(this),this._initHooksCalled=!0;for(var t=0,e=n._initHooks.length;t<e;t++)n._initHooks[t].call(this)}},e},o.Class.include=function(t){return o.extend(this.prototype,t),this},o.Class.mergeOptions=function(t){return o.extend(this.prototype.options,t),this},o.Class.addInitHook=function(t){var e=Array.prototype.slice.call(arguments,1),i="function"==typeof t?t:function(){this[t].apply(this,e)};return this.prototype._initHooks=this.prototype._initHooks||[],this.prototype._initHooks.push(i),this},o.Evented=o.Class.extend({on:function(t,e,i){if("object"==typeof t)for(var n in t)this._on(n,t[n],e);else{t=o.Util.splitWords(t);for(var s=0,r=t.length;s<r;s++)this._on(t[s],e,i)}return this},off:function(t,e,i){if(t)if("object"==typeof t)for(var n in t)this._off(n,t[n],e);else{t=o.Util.splitWords(t);for(var s=0,r=t.length;s<r;s++)this._off(t[s],e,i)}else delete this._events;return this},_on:function(t,e,n){this._events=this._events||{};var o=this._events[t];o||(o={listeners:[],count:0},this._events[t]=o),n===this&&(n=i);for(var s={fn:e,ctx:n},r=o.listeners,a=0,h=r.length;a<h;a++)if(r[a].fn===e&&r[a].ctx===n)return;r.push(s),o.count++},_off:function(t,e,n){var s,r,a,h;if(this._events&&(s=this._events[t])){if(r=s.listeners,!e){for(a=0,h=r.length;a<h;a++)r[a].fn=o.Util.falseFn;return void delete this._events[t]}if(n===this&&(n=i),r)for(a=0,h=r.length;a<h;a++){var l=r[a];if(l.ctx===n&&l.fn===e)return l.fn=o.Util.falseFn,s.count--,this._isFiring&&(r=r.slice()),void r.splice(a,1)}}},fire:function(t,e,i){if(!this.listens(t,i))return this;var n=o.Util.extend({},e,{type:t,target:this});if(this._events){var s=this._events[t];if(s){this._isFiring=!0;for(var r=s.listeners,a=0,h=r.length;a<h;a++){var l=r[a];l.fn.call(l.ctx||this,n)}this._isFiring=!1}}return i&&this._propagateEvent(n),this},listens:function(t,e){var i=this._events&&this._events[t];if(i&&i.count)return!0;if(e)for(var n in this._eventParents)if(this._eventParents[n].listens(t,e))return!0;return!1},once:function(t,e,i){if("object"==typeof t){for(var n in t)this.once(n,t[n],e);return this}var s=o.bind(function(){this.off(t,e,i).off(t,s,i)},this);return this.on(t,e,i).on(t,s,i)},addEventParent:function(t){return this._eventParents=this._eventParents||{},this._eventParents[o.stamp(t)]=t,this},removeEventParent:function(t){return this._eventParents&&delete this._eventParents[o.stamp(t)],this},_propagateEvent:function(t){for(var e in this._eventParents)this._eventParents[e].fire(t.type,o.extend({layer:t.target},t),!0)}});var s=o.Evented.prototype;s.addEventListener=s.on,s.removeEventListener=s.clearAllEventListeners=s.off,s.addOneTimeEventListener=s.once,s.fireEvent=s.fire,s.hasEventListeners=s.listens,o.Mixin={Events:s},function(){var i=navigator.userAgent.toLowerCase(),n=e.documentElement,s="ActiveXObject"in t,r=i.indexOf("webkit")!==-1,a=i.indexOf("phantom")!==-1,h=i.search("android [23]")!==-1,l=i.indexOf("chrome")!==-1,u=i.indexOf("gecko")!==-1&&!r&&!t.opera&&!s,c=0===navigator.platform.indexOf("Win"),d="undefined"!=typeof orientation||i.indexOf("mobile")!==-1,_=!t.PointerEvent&&t.MSPointerEvent,m=t.PointerEvent||_,p=s&&"transition"in n.style,f="WebKitCSSMatrix"in t&&"m11"in new t.WebKitCSSMatrix&&!h,g="MozPerspective"in n.style,v="OTransition"in n.style,y=!t.L_NO_TOUCH&&(m||"ontouchstart"in t||t.DocumentTouch&&e instanceof t.DocumentTouch);o.Browser={ie:s,ielt9:s&&!e.addEventListener,edge:"msLaunchUri"in navigator&&!("documentMode"in e),webkit:r,gecko:u,android:i.indexOf("android")!==-1,android23:h,chrome:l,safari:!l&&i.indexOf("safari")!==-1,win:c,ie3d:p,webkit3d:f,gecko3d:g,opera12:v,any3d:!t.L_DISABLE_3D&&(p||f||g)&&!v&&!a,mobile:d,mobileWebkit:d&&r,mobileWebkit3d:d&&f,mobileOpera:d&&t.opera,mobileGecko:d&&u,touch:!!y,msPointer:!!_,pointer:!!m,retina:(t.devicePixelRatio||t.screen.deviceXDPI/t.screen.logicalXDPI)>1}}(),o.Point=function(t,e,i){this.x=i?Math.round(t):t,this.y=i?Math.round(e):e},o.Point.prototype={clone:function(){return new o.Point(this.x,this.y)},add:function(t){return this.clone()._add(o.point(t))},_add:function(t){return this.x+=t.x,this.y+=t.y,this},subtract:function(t){return this.clone()._subtract(o.point(t))},_subtract:function(t){return this.x-=t.x,this.y-=t.y,this},divideBy:function(t){return this.clone()._divideBy(t)},_divideBy:function(t){return this.x/=t,this.y/=t,this},multiplyBy:function(t){return this.clone()._multiplyBy(t)},_multiplyBy:function(t){return this.x*=t,this.y*=t,this},scaleBy:function(t){return new o.Point(this.x*t.x,this.y*t.y)},unscaleBy:function(t){return new o.Point(this.x/t.x,this.y/t.y)},round:function(){return this.clone()._round()},_round:function(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this},floor:function(){return this.clone()._floor()},_floor:function(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this},ceil:function(){return this.clone()._ceil()},_ceil:function(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this},distanceTo:function(t){t=o.point(t);var e=t.x-this.x,i=t.y-this.y;return Math.sqrt(e*e+i*i)},equals:function(t){return t=o.point(t),t.x===this.x&&t.y===this.y},contains:function(t){return t=o.point(t),Math.abs(t.x)<=Math.abs(this.x)&&Math.abs(t.y)<=Math.abs(this.y)},toString:function(){return"Point("+o.Util.formatNum(this.x)+", "+o.Util.formatNum(this.y)+")"}},o.point=function(t,e,n){return t instanceof o.Point?t:o.Util.isArray(t)?new o.Point(t[0],t[1]):t===i||null===t?t:"object"==typeof t&&"x"in t&&"y"in t?new o.Point(t.x,t.y):new o.Point(t,e,n)},o.Bounds=function(t,e){if(t)for(var i=e?[t,e]:t,n=0,o=i.length;n<o;n++)this.extend(i[n])},o.Bounds.prototype={extend:function(t){return t=o.point(t),this.min||this.max?(this.min.x=Math.min(t.x,this.min.x),this.max.x=Math.max(t.x,this.max.x),this.min.y=Math.min(t.y,this.min.y),this.max.y=Math.max(t.y,this.max.y)):(this.min=t.clone(),this.max=t.clone()),this},getCenter:function(t){return new o.Point((this.min.x+this.max.x)/2,(this.min.y+this.max.y)/2,t)},getBottomLeft:function(){return new o.Point(this.min.x,this.max.y)},getTopRight:function(){return new o.Point(this.max.x,this.min.y)},getSize:function(){return this.max.subtract(this.min)},contains:function(t){var e,i;return t="number"==typeof t[0]||t instanceof o.Point?o.point(t):o.bounds(t),t instanceof o.Bounds?(e=t.min,i=t.max):e=i=t,e.x>=this.min.x&&i.x<=this.max.x&&e.y>=this.min.y&&i.y<=this.max.y},intersects:function(t){t=o.bounds(t);var e=this.min,i=this.max,n=t.min,s=t.max,r=s.x>=e.x&&n.x<=i.x,a=s.y>=e.y&&n.y<=i.y;return r&&a},overlaps:function(t){t=o.bounds(t);var e=this.min,i=this.max,n=t.min,s=t.max,r=s.x>e.x&&n.x<i.x,a=s.y>e.y&&n.y<i.y;return r&&a},isValid:function(){return!(!this.min||!this.max)}},o.bounds=function(t,e){return!t||t instanceof o.Bounds?t:new o.Bounds(t,e)},o.Transformation=function(t,e,i,n){this._a=t,this._b=e,this._c=i,this._d=n},o.Transformation.prototype={transform:function(t,e){return this._transform(t.clone(),e)},_transform:function(t,e){return e=e||1,t.x=e*(this._a*t.x+this._b),t.y=e*(this._c*t.y+this._d),t},untransform:function(t,e){return e=e||1,new o.Point((t.x/e-this._b)/this._a,(t.y/e-this._d)/this._c)}},o.DomUtil={get:function(t){return"string"==typeof t?e.getElementById(t):t},getStyle:function(t,i){var n=t.style[i]||t.currentStyle&&t.currentStyle[i];if((!n||"auto"===n)&&e.defaultView){var o=e.defaultView.getComputedStyle(t,null);n=o?o[i]:null}return"auto"===n?null:n},create:function(t,i,n){var o=e.createElement(t);return o.className=i||"",n&&n.appendChild(o),o},remove:function(t){var e=t.parentNode;e&&e.removeChild(t)},empty:function(t){for(;t.firstChild;)t.removeChild(t.firstChild)},toFront:function(t){t.parentNode.appendChild(t)},toBack:function(t){var e=t.parentNode;e.insertBefore(t,e.firstChild)},hasClass:function(t,e){if(t.classList!==i)return t.classList.contains(e);var n=o.DomUtil.getClass(t);return n.length>0&&new RegExp("(^|\\s)"+e+"(\\s|$)").test(n)},addClass:function(t,e){if(t.classList!==i)for(var n=o.Util.splitWords(e),s=0,r=n.length;s<r;s++)t.classList.add(n[s]);else if(!o.DomUtil.hasClass(t,e)){var a=o.DomUtil.getClass(t);o.DomUtil.setClass(t,(a?a+" ":"")+e)}},removeClass:function(t,e){t.classList!==i?t.classList.remove(e):o.DomUtil.setClass(t,o.Util.trim((" "+o.DomUtil.getClass(t)+" ").replace(" "+e+" "," ")))},setClass:function(t,e){t.className.baseVal===i?t.className=e:t.className.baseVal=e},getClass:function(t){return t.className.baseVal===i?t.className:t.className.baseVal},setOpacity:function(t,e){"opacity"in t.style?t.style.opacity=e:"filter"in t.style&&o.DomUtil._setOpacityIE(t,e)},_setOpacityIE:function(t,e){var i=!1,n="DXImageTransform.Microsoft.Alpha";try{i=t.filters.item(n)}catch(o){if(1===e)return}e=Math.round(100*e),i?(i.Enabled=100!==e,i.Opacity=e):t.style.filter+=" progid:"+n+"(opacity="+e+")"},testProp:function(t){for(var i=e.documentElement.style,n=0;n<t.length;n++)if(t[n]in i)return t[n];return!1},setTransform:function(t,e,i){var n=e||new o.Point(0,0);t.style[o.DomUtil.TRANSFORM]=(o.Browser.ie3d?"translate("+n.x+"px,"+n.y+"px)":"translate3d("+n.x+"px,"+n.y+"px,0)")+(i?" scale("+i+")":"")},setPosition:function(t,e){t._leaflet_pos=e,o.Browser.any3d?o.DomUtil.setTransform(t,e):(t.style.left=e.x+"px",t.style.top=e.y+"px")},getPosition:function(t){return t._leaflet_pos||new o.Point(0,0)}},function(){o.DomUtil.TRANSFORM=o.DomUtil.testProp(["transform","WebkitTransform","OTransform","MozTransform","msTransform"]);var i=o.DomUtil.TRANSITION=o.DomUtil.testProp(["webkitTransition","transition","OTransition","MozTransition","msTransition"]);if(o.DomUtil.TRANSITION_END="webkitTransition"===i||"OTransition"===i?i+"End":"transitionend","onselectstart"in e)o.DomUtil.disableTextSelection=function(){o.DomEvent.on(t,"selectstart",o.DomEvent.preventDefault)},o.DomUtil.enableTextSelection=function(){o.DomEvent.off(t,"selectstart",o.DomEvent.preventDefault)};else{var n=o.DomUtil.testProp(["userSelect","WebkitUserSelect","OUserSelect","MozUserSelect","msUserSelect"]);o.DomUtil.disableTextSelection=function(){if(n){var t=e.documentElement.style;this._userSelect=t[n],t[n]="none"}},o.DomUtil.enableTextSelection=function(){n&&(e.documentElement.style[n]=this._userSelect,delete this._userSelect)}}o.DomUtil.disableImageDrag=function(){o.DomEvent.on(t,"dragstart",o.DomEvent.preventDefault)},o.DomUtil.enableImageDrag=function(){o.DomEvent.off(t,"dragstart",o.DomEvent.preventDefault)},o.DomUtil.preventOutline=function(e){for(;e.tabIndex===-1;)e=e.parentNode;e&&e.style&&(o.DomUtil.restoreOutline(),this._outlineElement=e,this._outlineStyle=e.style.outline,e.style.outline="none",o.DomEvent.on(t,"keydown",o.DomUtil.restoreOutline,this))},o.DomUtil.restoreOutline=function(){this._outlineElement&&(this._outlineElement.style.outline=this._outlineStyle,delete this._outlineElement,delete this._outlineStyle,o.DomEvent.off(t,"keydown",o.DomUtil.restoreOutline,this))}}(),o.LatLng=function(t,e,n){if(isNaN(t)||isNaN(e))throw new Error("Invalid LatLng object: ("+t+", "+e+")");this.lat=+t,this.lng=+e,n!==i&&(this.alt=+n)},o.LatLng.prototype={equals:function(t,e){if(!t)return!1;t=o.latLng(t);var n=Math.max(Math.abs(this.lat-t.lat),Math.abs(this.lng-t.lng));return n<=(e===i?1e-9:e)},toString:function(t){return"LatLng("+o.Util.formatNum(this.lat,t)+", "+o.Util.formatNum(this.lng,t)+")"},distanceTo:function(t){return o.CRS.Earth.distance(this,o.latLng(t))},wrap:function(){return o.CRS.Earth.wrapLatLng(this)},toBounds:function(t){var e=180*t/40075017,i=e/Math.cos(Math.PI/180*this.lat);return o.latLngBounds([this.lat-e,this.lng-i],[this.lat+e,this.lng+i])},clone:function(){return new o.LatLng(this.lat,this.lng,this.alt)}},o.latLng=function(t,e,n){return t instanceof o.LatLng?t:o.Util.isArray(t)&&"object"!=typeof t[0]?3===t.length?new o.LatLng(t[0],t[1],t[2]):2===t.length?new o.LatLng(t[0],t[1]):null:t===i||null===t?t:"object"==typeof t&&"lat"in t?new o.LatLng(t.lat,"lng"in t?t.lng:t.lon,t.alt):e===i?null:new o.LatLng(t,e,n)},o.LatLngBounds=function(t,e){if(t)for(var i=e?[t,e]:t,n=0,o=i.length;n<o;n++)this.extend(i[n])},o.LatLngBounds.prototype={extend:function(t){var e,i,n=this._southWest,s=this._northEast;if(t instanceof o.LatLng)e=t,i=t;else{if(!(t instanceof o.LatLngBounds))return t?this.extend(o.latLng(t)||o.latLngBounds(t)):this;if(e=t._southWest,i=t._northEast,!e||!i)return this}return n||s?(n.lat=Math.min(e.lat,n.lat),n.lng=Math.min(e.lng,n.lng),s.lat=Math.max(i.lat,s.lat),s.lng=Math.max(i.lng,s.lng)):(this._southWest=new o.LatLng(e.lat,e.lng),this._northEast=new o.LatLng(i.lat,i.lng)),this},pad:function(t){var e=this._southWest,i=this._northEast,n=Math.abs(e.lat-i.lat)*t,s=Math.abs(e.lng-i.lng)*t;return new o.LatLngBounds(new o.LatLng(e.lat-n,e.lng-s),new o.LatLng(i.lat+n,i.lng+s))},getCenter:function(){return new o.LatLng((this._southWest.lat+this._northEast.lat)/2,(this._southWest.lng+this._northEast.lng)/2)},getSouthWest:function(){return this._southWest},getNorthEast:function(){return this._northEast},getNorthWest:function(){return new o.LatLng(this.getNorth(),this.getWest())},getSouthEast:function(){return new o.LatLng(this.getSouth(),this.getEast())},getWest:function(){return this._southWest.lng},getSouth:function(){return this._southWest.lat},getEast:function(){return this._northEast.lng},getNorth:function(){return this._northEast.lat},contains:function(t){t="number"==typeof t[0]||t instanceof o.LatLng?o.latLng(t):o.latLngBounds(t);var e,i,n=this._southWest,s=this._northEast;return t instanceof o.LatLngBounds?(e=t.getSouthWest(),i=t.getNorthEast()):e=i=t,e.lat>=n.lat&&i.lat<=s.lat&&e.lng>=n.lng&&i.lng<=s.lng},intersects:function(t){t=o.latLngBounds(t);var e=this._southWest,i=this._northEast,n=t.getSouthWest(),s=t.getNorthEast(),r=s.lat>=e.lat&&n.lat<=i.lat,a=s.lng>=e.lng&&n.lng<=i.lng;return r&&a},overlaps:function(t){t=o.latLngBounds(t);var e=this._southWest,i=this._northEast,n=t.getSouthWest(),s=t.getNorthEast(),r=s.lat>e.lat&&n.lat<i.lat,a=s.lng>e.lng&&n.lng<i.lng;return r&&a},toBBoxString:function(){return[this.getWest(),this.getSouth(),this.getEast(),this.getNorth()].join(",")},equals:function(t){return!!t&&(t=o.latLngBounds(t),this._southWest.equals(t.getSouthWest())&&this._northEast.equals(t.getNorthEast()))},isValid:function(){return!(!this._southWest||!this._northEast)}},o.latLngBounds=function(t,e){return t instanceof o.LatLngBounds?t:new o.LatLngBounds(t,e)},o.Projection={},o.Projection.LonLat={project:function(t){return new o.Point(t.lng,t.lat)},unproject:function(t){return new o.LatLng(t.y,t.x)},bounds:o.bounds([-180,-90],[180,90])},o.Projection.SphericalMercator={R:6378137,MAX_LATITUDE:85.0511287798,project:function(t){var e=Math.PI/180,i=this.MAX_LATITUDE,n=Math.max(Math.min(i,t.lat),-i),s=Math.sin(n*e);return new o.Point(this.R*t.lng*e,this.R*Math.log((1+s)/(1-s))/2)},unproject:function(t){var e=180/Math.PI;return new o.LatLng((2*Math.atan(Math.exp(t.y/this.R))-Math.PI/2)*e,t.x*e/this.R)},bounds:function(){var t=6378137*Math.PI;return o.bounds([-t,-t],[t,t])}()},o.CRS={latLngToPoint:function(t,e){var i=this.projection.project(t),n=this.scale(e);return this.transformation._transform(i,n)},pointToLatLng:function(t,e){var i=this.scale(e),n=this.transformation.untransform(t,i);return this.projection.unproject(n)},project:function(t){return this.projection.project(t)},unproject:function(t){return this.projection.unproject(t)},scale:function(t){return 256*Math.pow(2,t)},zoom:function(t){return Math.log(t/256)/Math.LN2},getProjectedBounds:function(t){if(this.infinite)return null;var e=this.projection.bounds,i=this.scale(t),n=this.transformation.transform(e.min,i),s=this.transformation.transform(e.max,i);return o.bounds(n,s)},infinite:!1,wrapLatLng:function(t){var e=this.wrapLng?o.Util.wrapNum(t.lng,this.wrapLng,!0):t.lng,i=this.wrapLat?o.Util.wrapNum(t.lat,this.wrapLat,!0):t.lat,n=t.alt;return o.latLng(i,e,n)}},o.CRS.Simple=o.extend({},o.CRS,{projection:o.Projection.LonLat,transformation:new o.Transformation(1,0,(-1),0),scale:function(t){return Math.pow(2,t)},zoom:function(t){return Math.log(t)/Math.LN2},distance:function(t,e){var i=e.lng-t.lng,n=e.lat-t.lat;return Math.sqrt(i*i+n*n)},infinite:!0}),o.CRS.Earth=o.extend({},o.CRS,{wrapLng:[-180,180],R:6371e3,distance:function(t,e){var i=Math.PI/180,n=t.lat*i,o=e.lat*i,s=Math.sin(n)*Math.sin(o)+Math.cos(n)*Math.cos(o)*Math.cos((e.lng-t.lng)*i);return this.R*Math.acos(Math.min(s,1))}}),o.CRS.EPSG3857=o.extend({},o.CRS.Earth,{code:"EPSG:3857",projection:o.Projection.SphericalMercator,transformation:function(){var t=.5/(Math.PI*o.Projection.SphericalMercator.R);return new o.Transformation(t,.5,(-t),.5)}()}),o.CRS.EPSG900913=o.extend({},o.CRS.EPSG3857,{code:"EPSG:900913"}),o.CRS.EPSG4326=o.extend({},o.CRS.Earth,{code:"EPSG:4326",projection:o.Projection.LonLat,transformation:new o.Transformation(1/180,1,-1/180,.5)}),o.Map=o.Evented.extend({options:{crs:o.CRS.EPSG3857,center:i,zoom:i,minZoom:i,maxZoom:i,layers:[],maxBounds:i,renderer:i,fadeAnimation:!0,markerZoomAnimation:!0,transform3DLimit:8388608,zoomSnap:1,zoomDelta:1,trackResize:!0},initialize:function(t,e){e=o.setOptions(this,e),this._initContainer(t),this._initLayout(),this._onResize=o.bind(this._onResize,this),this._initEvents(),e.maxBounds&&this.setMaxBounds(e.maxBounds),e.zoom!==i&&(this._zoom=this._limitZoom(e.zoom)),e.center&&e.zoom!==i&&this.setView(o.latLng(e.center),e.zoom,{reset:!0}),this._handlers=[],this._layers={},this._zoomBoundLayers={},this._sizeChanged=!0,this.callInitHooks(),this._addLayers(this.options.layers)},setView:function(t,e){return e=e===i?this.getZoom():e,this._resetView(o.latLng(t),e),this},setZoom:function(t,e){return this._loaded?this.setView(this.getCenter(),t,{zoom:e}):(this._zoom=t,this)},zoomIn:function(t,e){return t=t||(o.Browser.any3d?this.options.zoomDelta:1),this.setZoom(this._zoom+t,e)},zoomOut:function(t,e){return t=t||(o.Browser.any3d?this.options.zoomDelta:1),this.setZoom(this._zoom-t,e)},setZoomAround:function(t,e,i){var n=this.getZoomScale(e),s=this.getSize().divideBy(2),r=t instanceof o.Point?t:this.latLngToContainerPoint(t),a=r.subtract(s).multiplyBy(1-1/n),h=this.containerPointToLatLng(s.add(a));return this.setView(h,e,{zoom:i})},_getBoundsCenterZoom:function(t,e){e=e||{},t=t.getBounds?t.getBounds():o.latLngBounds(t);var i=o.point(e.paddingTopLeft||e.padding||[0,0]),n=o.point(e.paddingBottomRight||e.padding||[0,0]),s=this.getBoundsZoom(t,!1,i.add(n));s="number"==typeof e.maxZoom?Math.min(e.maxZoom,s):s;var r=n.subtract(i).divideBy(2),a=this.project(t.getSouthWest(),s),h=this.project(t.getNorthEast(),s),l=this.unproject(a.add(h).divideBy(2).add(r),s);return{center:l,zoom:s}},fitBounds:function(t,e){if(t=o.latLngBounds(t),!t.isValid())throw new Error("Bounds are not valid.");var i=this._getBoundsCenterZoom(t,e);return this.setView(i.center,i.zoom,e)},fitWorld:function(t){return this.fitBounds([[-90,-180],[90,180]],t)},panTo:function(t,e){return this.setView(t,this._zoom,{pan:e})},panBy:function(t){return this.fire("movestart"),this._rawPanBy(o.point(t)),this.fire("move"),this.fire("moveend")},setMaxBounds:function(t){return t=o.latLngBounds(t),t.isValid()?(this.options.maxBounds&&this.off("moveend",this._panInsideMaxBounds),this.options.maxBounds=t,this._loaded&&this._panInsideMaxBounds(),this.on("moveend",this._panInsideMaxBounds)):(this.options.maxBounds=null,this.off("moveend",this._panInsideMaxBounds))},setMinZoom:function(t){return this.options.minZoom=t,this._loaded&&this.getZoom()<this.options.minZoom?this.setZoom(t):this},setMaxZoom:function(t){return this.options.maxZoom=t,this._loaded&&this.getZoom()>this.options.maxZoom?this.setZoom(t):this},panInsideBounds:function(t,e){this._enforcingBounds=!0;var i=this.getCenter(),n=this._limitCenter(i,this._zoom,o.latLngBounds(t));return i.equals(n)||this.panTo(n,e),this._enforcingBounds=!1,this},invalidateSize:function(t){if(!this._loaded)return this;t=o.extend({animate:!1,pan:!0},t===!0?{animate:!0}:t);var e=this.getSize();this._sizeChanged=!0,this._lastCenter=null;var i=this.getSize(),n=e.divideBy(2).round(),s=i.divideBy(2).round(),r=n.subtract(s);return r.x||r.y?(t.animate&&t.pan?this.panBy(r):(t.pan&&this._rawPanBy(r),this.fire("move"),t.debounceMoveend?(clearTimeout(this._sizeTimer),this._sizeTimer=setTimeout(o.bind(this.fire,this,"moveend"),200)):this.fire("moveend")),this.fire("resize",{oldSize:e,newSize:i})):this},stop:function(){return this.setZoom(this._limitZoom(this._zoom)),this.options.zoomSnap||this.fire("viewreset"),this._stop()},addHandler:function(t,e){if(!e)return this;var i=this[t]=new e(this);return this._handlers.push(i),this.options[t]&&i.enable(),this},remove:function(){this._initEvents(!0);try{delete this._container._leaflet}catch(t){this._container._leaflet=i}o.DomUtil.remove(this._mapPane),this._clearControlPos&&this._clearControlPos(),this._clearHandlers(),this._loaded&&this.fire("unload");for(var e in this._layers)this._layers[e].remove();return this},createPane:function(t,e){var i="leaflet-pane"+(t?" leaflet-"+t.replace("Pane","")+"-pane":""),n=o.DomUtil.create("div",i,e||this._mapPane);return t&&(this._panes[t]=n),n},getCenter:function(){return this._checkIfLoaded(),this._lastCenter&&!this._moved()?this._lastCenter:this.layerPointToLatLng(this._getCenterLayerPoint())},getZoom:function(){return this._zoom},getBounds:function(){var t=this.getPixelBounds(),e=this.unproject(t.getBottomLeft()),i=this.unproject(t.getTopRight());return new o.LatLngBounds(e,i)},getMinZoom:function(){return this.options.minZoom===i?this._layersMinZoom||0:this.options.minZoom},getMaxZoom:function(){return this.options.maxZoom===i?this._layersMaxZoom===i?1/0:this._layersMaxZoom:this.options.maxZoom},getBoundsZoom:function(t,e,i){t=o.latLngBounds(t),i=o.point(i||[0,0]);var n=this.getZoom()||0,s=this.getMinZoom(),r=this.getMaxZoom(),a=t.getNorthWest(),h=t.getSouthEast(),l=this.getSize().subtract(i),u=this.project(h,n).subtract(this.project(a,n)),c=o.Browser.any3d?this.options.zoomSnap:1,d=Math.min(l.x/u.x,l.y/u.y);return n=this.getScaleZoom(d,n),c&&(n=Math.round(n/(c/100))*(c/100),n=e?Math.ceil(n/c)*c:Math.floor(n/c)*c),Math.max(s,Math.min(r,n))},getSize:function(){return this._size&&!this._sizeChanged||(this._size=new o.Point(this._container.clientWidth,this._container.clientHeight),this._sizeChanged=!1),this._size.clone()},getPixelBounds:function(t,e){var i=this._getTopLeftPoint(t,e);return new o.Bounds(i,i.add(this.getSize()))},getPixelOrigin:function(){return this._checkIfLoaded(),this._pixelOrigin},getPixelWorldBounds:function(t){return this.options.crs.getProjectedBounds(t===i?this.getZoom():t)},getPane:function(t){return"string"==typeof t?this._panes[t]:t},getPanes:function(){return this._panes},getContainer:function(){return this._container},getZoomScale:function(t,e){var n=this.options.crs;return e=e===i?this._zoom:e,n.scale(t)/n.scale(e)},getScaleZoom:function(t,e){var n=this.options.crs;return e=e===i?this._zoom:e,n.zoom(t*n.scale(e))},project:function(t,e){return e=e===i?this._zoom:e,this.options.crs.latLngToPoint(o.latLng(t),e)},unproject:function(t,e){return e=e===i?this._zoom:e,this.options.crs.pointToLatLng(o.point(t),e)},layerPointToLatLng:function(t){var e=o.point(t).add(this.getPixelOrigin());return this.unproject(e)},latLngToLayerPoint:function(t){var e=this.project(o.latLng(t))._round();return e._subtract(this.getPixelOrigin())},wrapLatLng:function(t){return this.options.crs.wrapLatLng(o.latLng(t))},distance:function(t,e){return this.options.crs.distance(o.latLng(t),o.latLng(e))},containerPointToLayerPoint:function(t){return o.point(t).subtract(this._getMapPanePos())},layerPointToContainerPoint:function(t){return o.point(t).add(this._getMapPanePos())},containerPointToLatLng:function(t){var e=this.containerPointToLayerPoint(o.point(t));return this.layerPointToLatLng(e)},latLngToContainerPoint:function(t){return this.layerPointToContainerPoint(this.latLngToLayerPoint(o.latLng(t)))},mouseEventToContainerPoint:function(t){return o.DomEvent.getMousePosition(t,this._container)},mouseEventToLayerPoint:function(t){return this.containerPointToLayerPoint(this.mouseEventToContainerPoint(t))},mouseEventToLatLng:function(t){return this.layerPointToLatLng(this.mouseEventToLayerPoint(t))},_initContainer:function(t){var e=this._container=o.DomUtil.get(t);if(!e)throw new Error("Map container not found.");if(e._leaflet)throw new Error("Map container is already initialized.");o.DomEvent.addListener(e,"scroll",this._onScroll,this),e._leaflet=!0},_initLayout:function(){var t=this._container;this._fadeAnimated=this.options.fadeAnimation&&o.Browser.any3d,o.DomUtil.addClass(t,"leaflet-container"+(o.Browser.touch?" leaflet-touch":"")+(o.Browser.retina?" leaflet-retina":"")+(o.Browser.ielt9?" leaflet-oldie":"")+(o.Browser.safari?" leaflet-safari":"")+(this._fadeAnimated?" leaflet-fade-anim":""));var e=o.DomUtil.getStyle(t,"position");"absolute"!==e&&"relative"!==e&&"fixed"!==e&&(t.style.position="relative"),this._initPanes(),this._initControlPos&&this._initControlPos()},_initPanes:function(){var t=this._panes={};this._paneRenderers={},this._mapPane=this.createPane("mapPane",this._container),o.DomUtil.setPosition(this._mapPane,new o.Point(0,0)),this.createPane("tilePane"),this.createPane("shadowPane"),this.createPane("overlayPane"),this.createPane("markerPane"),this.createPane("tooltipPane"),this.createPane("popupPane"),this.options.markerZoomAnimation||(o.DomUtil.addClass(t.markerPane,"leaflet-zoom-hide"),o.DomUtil.addClass(t.shadowPane,"leaflet-zoom-hide"))},_resetView:function(t,e){o.DomUtil.setPosition(this._mapPane,new o.Point(0,0));var i=!this._loaded;this._loaded=!0,e=this._limitZoom(e),this.fire("viewprereset");var n=this._zoom!==e;this._moveStart(n)._move(t,e)._moveEnd(n),this.fire("viewreset"),i&&this.fire("load")},_moveStart:function(t){return t&&this.fire("zoomstart"),this.fire("movestart")},_move:function(t,e,n){e===i&&(e=this._zoom);var o=this._zoom!==e;return this._zoom=e,this._lastCenter=t,this._pixelOrigin=this._getNewPixelOrigin(t),(o||n&&n.pinch)&&this.fire("zoom",n),this.fire("move",n)},_moveEnd:function(t){return t&&this.fire("zoomend"),this.fire("moveend")},_stop:function(){return o.Util.cancelAnimFrame(this._flyToFrame),this._panAnim&&this._panAnim.stop(),this},_rawPanBy:function(t){o.DomUtil.setPosition(this._mapPane,this._getMapPanePos().subtract(t))},_getZoomSpan:function(){return this.getMaxZoom()-this.getMinZoom()},_panInsideMaxBounds:function(){this._enforcingBounds||this.panInsideBounds(this.options.maxBounds)},_checkIfLoaded:function(){if(!this._loaded)throw new Error("Set map center and zoom first.")},_initEvents:function(e){if(o.DomEvent){this._targets={},this._targets[o.stamp(this._container)]=this;var i=e?"off":"on";o.DomEvent[i](this._container,"click dblclick mousedown mouseup mouseover mouseout mousemove contextmenu keypress",this._handleDOMEvent,this),this.options.trackResize&&o.DomEvent[i](t,"resize",this._onResize,this),o.Browser.any3d&&this.options.transform3DLimit&&this[i]("moveend",this._onMoveEnd)}},_onResize:function(){o.Util.cancelAnimFrame(this._resizeRequest),this._resizeRequest=o.Util.requestAnimFrame(function(){this.invalidateSize({debounceMoveend:!0})},this)},_onScroll:function(){this._container.scrollTop=0,this._container.scrollLeft=0},_onMoveEnd:function(){var t=this._getMapPanePos();Math.max(Math.abs(t.x),Math.abs(t.y))>=this.options.transform3DLimit&&this._resetView(this.getCenter(),this.getZoom())},_findEventTargets:function(t,e){for(var i,n=[],s="mouseout"===e||"mouseover"===e,r=t.target||t.srcElement,a=!1;r;){if(i=this._targets[o.stamp(r)],i&&("click"===e||"preclick"===e)&&!t._simulated&&this._draggableMoved(i)){a=!0;break}if(i&&i.listens(e,!0)){if(s&&!o.DomEvent._isExternalTarget(r,t))break;if(n.push(i),s)break}if(r===this._container)break;r=r.parentNode}return n.length||a||s||!o.DomEvent._isExternalTarget(r,t)||(n=[this]),n},_handleDOMEvent:function(t){if(this._loaded&&!o.DomEvent._skipped(t)){var e="keypress"===t.type&&13===t.keyCode?"click":t.type;"mousedown"===e&&o.DomUtil.preventOutline(t.target||t.srcElement),this._fireDOMEvent(t,e)}},_fireDOMEvent:function(t,e,i){if("click"===t.type){var n=o.Util.extend({},t);n.type="preclick",this._fireDOMEvent(n,n.type,i)}if(!t._stopped&&(i=(i||[]).concat(this._findEventTargets(t,e)),i.length)){var s=i[0];"contextmenu"===e&&s.listens(e,!0)&&o.DomEvent.preventDefault(t);var r={originalEvent:t};if("keypress"!==t.type){var a=s instanceof o.Marker;r.containerPoint=a?this.latLngToContainerPoint(s.getLatLng()):this.mouseEventToContainerPoint(t),r.layerPoint=this.containerPointToLayerPoint(r.containerPoint),r.latlng=a?s.getLatLng():this.layerPointToLatLng(r.layerPoint)}for(var h=0;h<i.length;h++)if(i[h].fire(e,r,!0),r.originalEvent._stopped||i[h].options.nonBubblingEvents&&o.Util.indexOf(i[h].options.nonBubblingEvents,e)!==-1)return;
 }},_draggableMoved:function(t){return t=t.dragging&&t.dragging.enabled()?t:this,t.dragging&&t.dragging.moved()||this.boxZoom&&this.boxZoom.moved()},_clearHandlers:function(){for(var t=0,e=this._handlers.length;t<e;t++)this._handlers[t].disable()},whenReady:function(t,e){return this._loaded?t.call(e||this,{target:this}):this.on("load",t,e),this},_getMapPanePos:function(){return o.DomUtil.getPosition(this._mapPane)||new o.Point(0,0)},_moved:function(){var t=this._getMapPanePos();return t&&!t.equals([0,0])},_getTopLeftPoint:function(t,e){var n=t&&e!==i?this._getNewPixelOrigin(t,e):this.getPixelOrigin();return n.subtract(this._getMapPanePos())},_getNewPixelOrigin:function(t,e){var i=this.getSize()._divideBy(2);return this.project(t,e)._subtract(i)._add(this._getMapPanePos())._round()},_latLngToNewLayerPoint:function(t,e,i){var n=this._getNewPixelOrigin(i,e);return this.project(t,e)._subtract(n)},_getCenterLayerPoint:function(){return this.containerPointToLayerPoint(this.getSize()._divideBy(2))},_getCenterOffset:function(t){return this.latLngToLayerPoint(t).subtract(this._getCenterLayerPoint())},_limitCenter:function(t,e,i){if(!i)return t;var n=this.project(t,e),s=this.getSize().divideBy(2),r=new o.Bounds(n.subtract(s),n.add(s)),a=this._getBoundsOffset(r,i,e);return a.round().equals([0,0])?t:this.unproject(n.add(a),e)},_limitOffset:function(t,e){if(!e)return t;var i=this.getPixelBounds(),n=new o.Bounds(i.min.add(t),i.max.add(t));return t.add(this._getBoundsOffset(n,e))},_getBoundsOffset:function(t,e,i){var n=o.bounds(this.project(e.getNorthEast(),i),this.project(e.getSouthWest(),i)),s=n.min.subtract(t.min),r=n.max.subtract(t.max),a=this._rebound(s.x,-r.x),h=this._rebound(s.y,-r.y);return new o.Point(a,h)},_rebound:function(t,e){return t+e>0?Math.round(t-e)/2:Math.max(0,Math.ceil(t))-Math.max(0,Math.floor(e))},_limitZoom:function(t){var e=this.getMinZoom(),i=this.getMaxZoom(),n=o.Browser.any3d?this.options.zoomSnap:1;return n&&(t=Math.round(t/n)*n),Math.max(e,Math.min(i,t))}}),o.map=function(t,e){return new o.Map(t,e)},o.Layer=o.Evented.extend({options:{pane:"overlayPane",nonBubblingEvents:[]},addTo:function(t){return t.addLayer(this),this},remove:function(){return this.removeFrom(this._map||this._mapToAdd)},removeFrom:function(t){return t&&t.removeLayer(this),this},getPane:function(t){return this._map.getPane(t?this.options[t]||t:this.options.pane)},addInteractiveTarget:function(t){return this._map._targets[o.stamp(t)]=this,this},removeInteractiveTarget:function(t){return delete this._map._targets[o.stamp(t)],this},_layerAdd:function(t){var e=t.target;if(e.hasLayer(this)){if(this._map=e,this._zoomAnimated=e._zoomAnimated,this.getEvents){var i=this.getEvents();e.on(i,this),this.once("remove",function(){e.off(i,this)},this)}this.onAdd(e),this.getAttribution&&this._map.attributionControl&&this._map.attributionControl.addAttribution(this.getAttribution()),this.fire("add"),e.fire("layeradd",{layer:this})}}}),o.Map.include({addLayer:function(t){var e=o.stamp(t);return this._layers[e]?this:(this._layers[e]=t,t._mapToAdd=this,t.beforeAdd&&t.beforeAdd(this),this.whenReady(t._layerAdd,t),this)},removeLayer:function(t){var e=o.stamp(t);return this._layers[e]?(this._loaded&&t.onRemove(this),t.getAttribution&&this.attributionControl&&this.attributionControl.removeAttribution(t.getAttribution()),delete this._layers[e],this._loaded&&(this.fire("layerremove",{layer:t}),t.fire("remove")),t._map=t._mapToAdd=null,this):this},hasLayer:function(t){return!!t&&o.stamp(t)in this._layers},eachLayer:function(t,e){for(var i in this._layers)t.call(e,this._layers[i]);return this},_addLayers:function(t){t=t?o.Util.isArray(t)?t:[t]:[];for(var e=0,i=t.length;e<i;e++)this.addLayer(t[e])},_addZoomLimit:function(t){!isNaN(t.options.maxZoom)&&isNaN(t.options.minZoom)||(this._zoomBoundLayers[o.stamp(t)]=t,this._updateZoomLevels())},_removeZoomLimit:function(t){var e=o.stamp(t);this._zoomBoundLayers[e]&&(delete this._zoomBoundLayers[e],this._updateZoomLevels())},_updateZoomLevels:function(){var t=1/0,e=-(1/0),n=this._getZoomSpan();for(var o in this._zoomBoundLayers){var s=this._zoomBoundLayers[o].options;t=s.minZoom===i?t:Math.min(t,s.minZoom),e=s.maxZoom===i?e:Math.max(e,s.maxZoom)}this._layersMaxZoom=e===-(1/0)?i:e,this._layersMinZoom=t===1/0?i:t,n!==this._getZoomSpan()&&this.fire("zoomlevelschange")}}),o.Projection.Mercator={R:6378137,R_MINOR:6356752.314245179,bounds:o.bounds([-20037508.34279,-15496570.73972],[20037508.34279,18764656.23138]),project:function(t){var e=Math.PI/180,i=this.R,n=t.lat*e,s=this.R_MINOR/i,r=Math.sqrt(1-s*s),a=r*Math.sin(n),h=Math.tan(Math.PI/4-n/2)/Math.pow((1-a)/(1+a),r/2);return n=-i*Math.log(Math.max(h,1e-10)),new o.Point(t.lng*e*i,n)},unproject:function(t){for(var e,i=180/Math.PI,n=this.R,s=this.R_MINOR/n,r=Math.sqrt(1-s*s),a=Math.exp(-t.y/n),h=Math.PI/2-2*Math.atan(a),l=0,u=.1;l<15&&Math.abs(u)>1e-7;l++)e=r*Math.sin(h),e=Math.pow((1-e)/(1+e),r/2),u=Math.PI/2-2*Math.atan(a*e)-h,h+=u;return new o.LatLng(h*i,t.x*i/n)}},o.CRS.EPSG3395=o.extend({},o.CRS.Earth,{code:"EPSG:3395",projection:o.Projection.Mercator,transformation:function(){var t=.5/(Math.PI*o.Projection.Mercator.R);return new o.Transformation(t,.5,(-t),.5)}()}),o.GridLayer=o.Layer.extend({options:{tileSize:256,opacity:1,updateWhenIdle:o.Browser.mobile,updateWhenZooming:!0,updateInterval:200,attribution:null,zIndex:1,bounds:null,minZoom:0,maxZoom:i,noWrap:!1,pane:"tilePane",className:"",keepBuffer:2},initialize:function(t){t=o.setOptions(this,t)},onAdd:function(){this._initContainer(),this._levels={},this._tiles={},this._resetView(),this._update()},beforeAdd:function(t){t._addZoomLimit(this)},onRemove:function(t){this._removeAllTiles(),o.DomUtil.remove(this._container),t._removeZoomLimit(this),this._container=null,this._tileZoom=null},bringToFront:function(){return this._map&&(o.DomUtil.toFront(this._container),this._setAutoZIndex(Math.max)),this},bringToBack:function(){return this._map&&(o.DomUtil.toBack(this._container),this._setAutoZIndex(Math.min)),this},getAttribution:function(){return this.options.attribution},getContainer:function(){return this._container},setOpacity:function(t){return this.options.opacity=t,this._updateOpacity(),this},setZIndex:function(t){return this.options.zIndex=t,this._updateZIndex(),this},isLoading:function(){return this._loading},redraw:function(){return this._map&&(this._removeAllTiles(),this._update()),this},getEvents:function(){var t={viewprereset:this._invalidateAll,viewreset:this._resetView,zoom:this._resetView,moveend:this._onMoveEnd};return this.options.updateWhenIdle||(this._onMove||(this._onMove=o.Util.throttle(this._onMoveEnd,this.options.updateInterval,this)),t.move=this._onMove),this._zoomAnimated&&(t.zoomanim=this._animateZoom),t},createTile:function(){return e.createElement("div")},getTileSize:function(){var t=this.options.tileSize;return t instanceof o.Point?t:new o.Point(t,t)},_updateZIndex:function(){this._container&&this.options.zIndex!==i&&null!==this.options.zIndex&&(this._container.style.zIndex=this.options.zIndex)},_setAutoZIndex:function(t){for(var e,i=this.getPane().children,n=-t(-(1/0),1/0),o=0,s=i.length;o<s;o++)e=i[o].style.zIndex,i[o]!==this._container&&e&&(n=t(n,+e));isFinite(n)&&(this.options.zIndex=n+t(-1,1),this._updateZIndex())},_updateOpacity:function(){if(this._map&&!o.Browser.ielt9){o.DomUtil.setOpacity(this._container,this.options.opacity);var t=+new Date,e=!1,i=!1;for(var n in this._tiles){var s=this._tiles[n];if(s.current&&s.loaded){var r=Math.min(1,(t-s.loaded)/200);o.DomUtil.setOpacity(s.el,r),r<1?e=!0:(s.active&&(i=!0),s.active=!0)}}i&&!this._noPrune&&this._pruneTiles(),e&&(o.Util.cancelAnimFrame(this._fadeFrame),this._fadeFrame=o.Util.requestAnimFrame(this._updateOpacity,this))}},_initContainer:function(){this._container||(this._container=o.DomUtil.create("div","leaflet-layer "+(this.options.className||"")),this._updateZIndex(),this.options.opacity<1&&this._updateOpacity(),this.getPane().appendChild(this._container))},_updateLevels:function(){var t=this._tileZoom,e=this.options.maxZoom;if(t===i)return i;for(var n in this._levels)this._levels[n].el.children.length||n===t?this._levels[n].el.style.zIndex=e-Math.abs(t-n):(o.DomUtil.remove(this._levels[n].el),this._removeTilesAtZoom(n),delete this._levels[n]);var s=this._levels[t],r=this._map;return s||(s=this._levels[t]={},s.el=o.DomUtil.create("div","leaflet-tile-container leaflet-zoom-animated",this._container),s.el.style.zIndex=e,s.origin=r.project(r.unproject(r.getPixelOrigin()),t).round(),s.zoom=t,this._setZoomTransform(s,r.getCenter(),r.getZoom()),o.Util.falseFn(s.el.offsetWidth)),this._level=s,s},_pruneTiles:function(){if(this._map){var t,e,i=this._map.getZoom();if(i>this.options.maxZoom||i<this.options.minZoom)return void this._removeAllTiles();for(t in this._tiles)e=this._tiles[t],e.retain=e.current;for(t in this._tiles)if(e=this._tiles[t],e.current&&!e.active){var n=e.coords;this._retainParent(n.x,n.y,n.z,n.z-5)||this._retainChildren(n.x,n.y,n.z,n.z+2)}for(t in this._tiles)this._tiles[t].retain||this._removeTile(t)}},_removeTilesAtZoom:function(t){for(var e in this._tiles)this._tiles[e].coords.z===t&&this._removeTile(e)},_removeAllTiles:function(){for(var t in this._tiles)this._removeTile(t)},_invalidateAll:function(){for(var t in this._levels)o.DomUtil.remove(this._levels[t].el),delete this._levels[t];this._removeAllTiles(),this._tileZoom=null},_retainParent:function(t,e,i,n){var s=Math.floor(t/2),r=Math.floor(e/2),a=i-1,h=new o.Point((+s),(+r));h.z=+a;var l=this._tileCoordsToKey(h),u=this._tiles[l];return u&&u.active?(u.retain=!0,!0):(u&&u.loaded&&(u.retain=!0),a>n&&this._retainParent(s,r,a,n))},_retainChildren:function(t,e,i,n){for(var s=2*t;s<2*t+2;s++)for(var r=2*e;r<2*e+2;r++){var a=new o.Point(s,r);a.z=i+1;var h=this._tileCoordsToKey(a),l=this._tiles[h];l&&l.active?l.retain=!0:(l&&l.loaded&&(l.retain=!0),i+1<n&&this._retainChildren(s,r,i+1,n))}},_resetView:function(t){var e=t&&(t.pinch||t.flyTo);this._setView(this._map.getCenter(),this._map.getZoom(),e,e)},_animateZoom:function(t){this._setView(t.center,t.zoom,!0,t.noUpdate)},_setView:function(t,e,n,o){var s=Math.round(e);(this.options.maxZoom!==i&&s>this.options.maxZoom||this.options.minZoom!==i&&s<this.options.minZoom)&&(s=i);var r=this.options.updateWhenZooming&&s!==this._tileZoom;o&&!r||(this._tileZoom=s,this._abortLoading&&this._abortLoading(),this._updateLevels(),this._resetGrid(),s!==i&&this._update(t),n||this._pruneTiles(),this._noPrune=!!n),this._setZoomTransforms(t,e)},_setZoomTransforms:function(t,e){for(var i in this._levels)this._setZoomTransform(this._levels[i],t,e)},_setZoomTransform:function(t,e,i){var n=this._map.getZoomScale(i,t.zoom),s=t.origin.multiplyBy(n).subtract(this._map._getNewPixelOrigin(e,i)).round();o.Browser.any3d?o.DomUtil.setTransform(t.el,s,n):o.DomUtil.setPosition(t.el,s)},_resetGrid:function(){var t=this._map,e=t.options.crs,i=this._tileSize=this.getTileSize(),n=this._tileZoom,o=this._map.getPixelWorldBounds(this._tileZoom);o&&(this._globalTileRange=this._pxBoundsToTileRange(o)),this._wrapX=e.wrapLng&&!this.options.noWrap&&[Math.floor(t.project([0,e.wrapLng[0]],n).x/i.x),Math.ceil(t.project([0,e.wrapLng[1]],n).x/i.y)],this._wrapY=e.wrapLat&&!this.options.noWrap&&[Math.floor(t.project([e.wrapLat[0],0],n).y/i.x),Math.ceil(t.project([e.wrapLat[1],0],n).y/i.y)]},_onMoveEnd:function(){this._map&&!this._map._animatingZoom&&this._update()},_getTiledPixelBounds:function(t){var e=this._map,i=e._animatingZoom?Math.max(e._animateToZoom,e.getZoom()):e.getZoom(),n=e.getZoomScale(i,this._tileZoom),s=e.project(t,this._tileZoom).floor(),r=e.getSize().divideBy(2*n);return new o.Bounds(s.subtract(r),s.add(r))},_update:function(t){var n=this._map;if(n){var s=n.getZoom();if(t===i&&(t=n.getCenter()),this._tileZoom!==i){var r=this._getTiledPixelBounds(t),a=this._pxBoundsToTileRange(r),h=a.getCenter(),l=[],u=this.options.keepBuffer,c=new o.Bounds(a.getBottomLeft().subtract([u,-u]),a.getTopRight().add([u,-u]));for(var d in this._tiles){var _=this._tiles[d].coords;_.z===this._tileZoom&&c.contains(o.point(_.x,_.y))||(this._tiles[d].current=!1)}if(Math.abs(s-this._tileZoom)>1)return void this._setView(t,s);for(var m=a.min.y;m<=a.max.y;m++)for(var p=a.min.x;p<=a.max.x;p++){var f=new o.Point(p,m);if(f.z=this._tileZoom,this._isValidTile(f)){var g=this._tiles[this._tileCoordsToKey(f)];g?g.current=!0:l.push(f)}}if(l.sort(function(t,e){return t.distanceTo(h)-e.distanceTo(h)}),0!==l.length){this._loading||(this._loading=!0,this.fire("loading"));var v=e.createDocumentFragment();for(p=0;p<l.length;p++)this._addTile(l[p],v);this._level.el.appendChild(v)}}}},_isValidTile:function(t){var e=this._map.options.crs;if(!e.infinite){var i=this._globalTileRange;if(!e.wrapLng&&(t.x<i.min.x||t.x>i.max.x)||!e.wrapLat&&(t.y<i.min.y||t.y>i.max.y))return!1}if(!this.options.bounds)return!0;var n=this._tileCoordsToBounds(t);return o.latLngBounds(this.options.bounds).overlaps(n)},_keyToBounds:function(t){return this._tileCoordsToBounds(this._keyToTileCoords(t))},_tileCoordsToBounds:function(t){var e=this._map,i=this.getTileSize(),n=t.scaleBy(i),s=n.add(i),r=e.wrapLatLng(e.unproject(n,t.z)),a=e.wrapLatLng(e.unproject(s,t.z));return new o.LatLngBounds(r,a)},_tileCoordsToKey:function(t){return t.x+":"+t.y+":"+t.z},_keyToTileCoords:function(t){var e=t.split(":"),i=new o.Point((+e[0]),(+e[1]));return i.z=+e[2],i},_removeTile:function(t){var e=this._tiles[t];e&&(o.DomUtil.remove(e.el),delete this._tiles[t],this.fire("tileunload",{tile:e.el,coords:this._keyToTileCoords(t)}))},_initTile:function(t){o.DomUtil.addClass(t,"leaflet-tile");var e=this.getTileSize();t.style.width=e.x+"px",t.style.height=e.y+"px",t.onselectstart=o.Util.falseFn,t.onmousemove=o.Util.falseFn,o.Browser.ielt9&&this.options.opacity<1&&o.DomUtil.setOpacity(t,this.options.opacity),o.Browser.android&&!o.Browser.android23&&(t.style.WebkitBackfaceVisibility="hidden")},_addTile:function(t,e){var i=this._getTilePos(t),n=this._tileCoordsToKey(t),s=this.createTile(this._wrapCoords(t),o.bind(this._tileReady,this,t));this._initTile(s),this.createTile.length<2&&o.Util.requestAnimFrame(o.bind(this._tileReady,this,t,null,s)),o.DomUtil.setPosition(s,i),this._tiles[n]={el:s,coords:t,current:!0},e.appendChild(s),this.fire("tileloadstart",{tile:s,coords:t})},_tileReady:function(t,e,i){if(this._map){e&&this.fire("tileerror",{error:e,tile:i,coords:t});var n=this._tileCoordsToKey(t);i=this._tiles[n],i&&(i.loaded=+new Date,this._map._fadeAnimated?(o.DomUtil.setOpacity(i.el,0),o.Util.cancelAnimFrame(this._fadeFrame),this._fadeFrame=o.Util.requestAnimFrame(this._updateOpacity,this)):(i.active=!0,this._pruneTiles()),o.DomUtil.addClass(i.el,"leaflet-tile-loaded"),this.fire("tileload",{tile:i.el,coords:t}),this._noTilesToLoad()&&(this._loading=!1,this.fire("load"),o.Browser.ielt9||!this._map._fadeAnimated?o.Util.requestAnimFrame(this._pruneTiles,this):setTimeout(o.bind(this._pruneTiles,this),250)))}},_getTilePos:function(t){return t.scaleBy(this.getTileSize()).subtract(this._level.origin)},_wrapCoords:function(t){var e=new o.Point(this._wrapX?o.Util.wrapNum(t.x,this._wrapX):t.x,this._wrapY?o.Util.wrapNum(t.y,this._wrapY):t.y);return e.z=t.z,e},_pxBoundsToTileRange:function(t){var e=this.getTileSize();return new o.Bounds(t.min.unscaleBy(e).floor(),t.max.unscaleBy(e).ceil().subtract([1,1]))},_noTilesToLoad:function(){for(var t in this._tiles)if(!this._tiles[t].loaded)return!1;return!0}}),o.gridLayer=function(t){return new o.GridLayer(t)},o.TileLayer=o.GridLayer.extend({options:{minZoom:0,maxZoom:18,maxNativeZoom:null,subdomains:"abc",errorTileUrl:"",zoomOffset:0,tms:!1,zoomReverse:!1,detectRetina:!1,crossOrigin:!1},initialize:function(t,e){this._url=t,e=o.setOptions(this,e),e.detectRetina&&o.Browser.retina&&e.maxZoom>0&&(e.tileSize=Math.floor(e.tileSize/2),e.zoomReverse?(e.zoomOffset--,e.minZoom++):(e.zoomOffset++,e.maxZoom--),e.minZoom=Math.max(0,e.minZoom)),"string"==typeof e.subdomains&&(e.subdomains=e.subdomains.split("")),o.Browser.android||this.on("tileunload",this._onTileRemove)},setUrl:function(t,e){return this._url=t,e||this.redraw(),this},createTile:function(t,i){var n=e.createElement("img");return o.DomEvent.on(n,"load",o.bind(this._tileOnLoad,this,i,n)),o.DomEvent.on(n,"error",o.bind(this._tileOnError,this,i,n)),this.options.crossOrigin&&(n.crossOrigin=""),n.alt="",n.src=this.getTileUrl(t),n},getTileUrl:function(t){var e={r:o.Browser.retina?"@2x":"",s:this._getSubdomain(t),x:t.x,y:t.y,z:this._getZoomForUrl()};if(this._map&&!this._map.options.crs.infinite){var i=this._globalTileRange.max.y-t.y;this.options.tms&&(e.y=i),e["-y"]=i}return o.Util.template(this._url,o.extend(e,this.options))},_tileOnLoad:function(t,e){o.Browser.ielt9?setTimeout(o.bind(t,this,null,e),0):t(null,e)},_tileOnError:function(t,e,i){var n=this.options.errorTileUrl;n&&(e.src=n),t(i,e)},getTileSize:function(){var t=this._map,e=o.GridLayer.prototype.getTileSize.call(this),i=this._tileZoom+this.options.zoomOffset,n=this.options.maxNativeZoom;return null!==n&&i>n?e.divideBy(t.getZoomScale(n,i)).round():e},_onTileRemove:function(t){t.tile.onload=null},_getZoomForUrl:function(){var t=this.options,e=this._tileZoom;return t.zoomReverse&&(e=t.maxZoom-e),e+=t.zoomOffset,null!==t.maxNativeZoom?Math.min(e,t.maxNativeZoom):e},_getSubdomain:function(t){var e=Math.abs(t.x+t.y)%this.options.subdomains.length;return this.options.subdomains[e]},_abortLoading:function(){var t,e;for(t in this._tiles)this._tiles[t].coords.z!==this._tileZoom&&(e=this._tiles[t].el,e.onload=o.Util.falseFn,e.onerror=o.Util.falseFn,e.complete||(e.src=o.Util.emptyImageUrl,o.DomUtil.remove(e)))}}),o.tileLayer=function(t,e){return new o.TileLayer(t,e)},o.TileLayer.WMS=o.TileLayer.extend({defaultWmsParams:{service:"WMS",request:"GetMap",layers:"",styles:"",format:"image/jpeg",transparent:!1,version:"1.1.1"},options:{crs:null,uppercase:!1},initialize:function(t,e){this._url=t;var i=o.extend({},this.defaultWmsParams);for(var n in e)n in this.options||(i[n]=e[n]);e=o.setOptions(this,e),i.width=i.height=e.tileSize*(e.detectRetina&&o.Browser.retina?2:1),this.wmsParams=i},onAdd:function(t){this._crs=this.options.crs||t.options.crs,this._wmsVersion=parseFloat(this.wmsParams.version);var e=this._wmsVersion>=1.3?"crs":"srs";this.wmsParams[e]=this._crs.code,o.TileLayer.prototype.onAdd.call(this,t)},getTileUrl:function(t){var e=this._tileCoordsToBounds(t),i=this._crs.project(e.getNorthWest()),n=this._crs.project(e.getSouthEast()),s=(this._wmsVersion>=1.3&&this._crs===o.CRS.EPSG4326?[n.y,i.x,i.y,n.x]:[i.x,n.y,n.x,i.y]).join(","),r=o.TileLayer.prototype.getTileUrl.call(this,t);return r+o.Util.getParamString(this.wmsParams,r,this.options.uppercase)+(this.options.uppercase?"&BBOX=":"&bbox=")+s},setParams:function(t,e){return o.extend(this.wmsParams,t),e||this.redraw(),this}}),o.tileLayer.wms=function(t,e){return new o.TileLayer.WMS(t,e)},o.ImageOverlay=o.Layer.extend({options:{opacity:1,alt:"",interactive:!1,attribution:null,crossOrigin:!1},initialize:function(t,e,i){this._url=t,this._bounds=o.latLngBounds(e),o.setOptions(this,i)},onAdd:function(){this._image||(this._initImage(),this.options.opacity<1&&this._updateOpacity()),this.options.interactive&&(o.DomUtil.addClass(this._image,"leaflet-interactive"),this.addInteractiveTarget(this._image)),this.getPane().appendChild(this._image),this._reset()},onRemove:function(){o.DomUtil.remove(this._image),this.options.interactive&&this.removeInteractiveTarget(this._image)},setOpacity:function(t){return this.options.opacity=t,this._image&&this._updateOpacity(),this},setStyle:function(t){return t.opacity&&this.setOpacity(t.opacity),this},bringToFront:function(){return this._map&&o.DomUtil.toFront(this._image),this},bringToBack:function(){return this._map&&o.DomUtil.toBack(this._image),this},setUrl:function(t){return this._url=t,this._image&&(this._image.src=t),this},setBounds:function(t){return this._bounds=t,this._map&&this._reset(),this},getAttribution:function(){return this.options.attribution},getEvents:function(){var t={zoom:this._reset,viewreset:this._reset};return this._zoomAnimated&&(t.zoomanim=this._animateZoom),t},getBounds:function(){return this._bounds},getElement:function(){return this._image},_initImage:function(){var t=this._image=o.DomUtil.create("img","leaflet-image-layer "+(this._zoomAnimated?"leaflet-zoom-animated":""));t.onselectstart=o.Util.falseFn,t.onmousemove=o.Util.falseFn,t.onload=o.bind(this.fire,this,"load"),this.options.crossOrigin&&(t.crossOrigin=""),t.src=this._url,t.alt=this.options.alt},_animateZoom:function(t){var e=this._map.getZoomScale(t.zoom),i=this._map._latLngToNewLayerPoint(this._bounds.getNorthWest(),t.zoom,t.center);o.DomUtil.setTransform(this._image,i,e)},_reset:function(){var t=this._image,e=new o.Bounds(this._map.latLngToLayerPoint(this._bounds.getNorthWest()),this._map.latLngToLayerPoint(this._bounds.getSouthEast())),i=e.getSize();o.DomUtil.setPosition(t,e.min),t.style.width=i.x+"px",t.style.height=i.y+"px"},_updateOpacity:function(){o.DomUtil.setOpacity(this._image,this.options.opacity)}}),o.imageOverlay=function(t,e,i){return new o.ImageOverlay(t,e,i)},o.Icon=o.Class.extend({initialize:function(t){o.setOptions(this,t)},createIcon:function(t){return this._createIcon("icon",t)},createShadow:function(t){return this._createIcon("shadow",t)},_createIcon:function(t,e){var i=this._getIconUrl(t);if(!i){if("icon"===t)throw new Error("iconUrl not set in Icon options (see the docs).");return null}var n=this._createImg(i,e&&"IMG"===e.tagName?e:null);return this._setIconStyles(n,t),n},_setIconStyles:function(t,e){var i=this.options,n=i[e+"Size"];"number"==typeof n&&(n=[n,n]);var s=o.point(n),r=o.point("shadow"===e&&i.shadowAnchor||i.iconAnchor||s&&s.divideBy(2,!0));t.className="leaflet-marker-"+e+" "+(i.className||""),r&&(t.style.marginLeft=-r.x+"px",t.style.marginTop=-r.y+"px"),s&&(t.style.width=s.x+"px",t.style.height=s.y+"px")},_createImg:function(t,i){return i=i||e.createElement("img"),i.src=t,i},_getIconUrl:function(t){return o.Browser.retina&&this.options[t+"RetinaUrl"]||this.options[t+"Url"]}}),o.icon=function(t){return new o.Icon(t)},o.Icon.Default=o.Icon.extend({options:{iconSize:[25,41],iconAnchor:[12,41],popupAnchor:[1,-34],tooltipAnchor:[16,-28],shadowSize:[41,41]},_getIconUrl:function(t){var e=t+"Url";if(this.options[e])return this.options[e];var i=o.Icon.Default.imagePath;if(!i)throw new Error("Couldn't autodetect L.Icon.Default.imagePath, set it manually.");return i+"/marker-"+t+(o.Browser.retina&&"icon"===t?"-2x":"")+".png"}}),o.Icon.Default.imagePath=function(){var t,i,n,o,s=e.getElementsByTagName("script"),r=/[\/^]leaflet[\-\._]?([\w\-\._]*)\.js\??/;for(t=0,i=s.length;t<i;t++)if(n=s[t].src||"",n.match(r))return o=n.split(r)[0],(o?o+"/":"")+"images"}(),o.Marker=o.Layer.extend({options:{icon:new o.Icon.Default,interactive:!0,draggable:!1,keyboard:!0,title:"",alt:"",zIndexOffset:0,opacity:1,riseOnHover:!1,riseOffset:250,pane:"markerPane",nonBubblingEvents:["click","dblclick","mouseover","mouseout","contextmenu"]},initialize:function(t,e){o.setOptions(this,e),this._latlng=o.latLng(t)},onAdd:function(t){this._zoomAnimated=this._zoomAnimated&&t.options.markerZoomAnimation,this._zoomAnimated&&t.on("zoomanim",this._animateZoom,this),this._initIcon(),this.update()},onRemove:function(t){this.dragging&&this.dragging.enabled()&&(this.options.draggable=!0,this.dragging.removeHooks()),this._zoomAnimated&&t.off("zoomanim",this._animateZoom,this),this._removeIcon(),this._removeShadow()},getEvents:function(){return{zoom:this.update,viewreset:this.update}},getLatLng:function(){return this._latlng},setLatLng:function(t){var e=this._latlng;return this._latlng=o.latLng(t),this.update(),this.fire("move",{oldLatLng:e,latlng:this._latlng})},setZIndexOffset:function(t){return this.options.zIndexOffset=t,this.update()},setIcon:function(t){return this.options.icon=t,this._map&&(this._initIcon(),this.update()),this._popup&&this.bindPopup(this._popup,this._popup.options),this},getElement:function(){return this._icon},update:function(){if(this._icon){var t=this._map.latLngToLayerPoint(this._latlng).round();this._setPos(t)}return this},_initIcon:function(){var t=this.options,e="leaflet-zoom-"+(this._zoomAnimated?"animated":"hide"),i=t.icon.createIcon(this._icon),n=!1;i!==this._icon&&(this._icon&&this._removeIcon(),n=!0,t.title&&(i.title=t.title),t.alt&&(i.alt=t.alt)),o.DomUtil.addClass(i,e),t.keyboard&&(i.tabIndex="0"),this._icon=i,t.riseOnHover&&this.on({mouseover:this._bringToFront,mouseout:this._resetZIndex});var s=t.icon.createShadow(this._shadow),r=!1;s!==this._shadow&&(this._removeShadow(),r=!0),s&&o.DomUtil.addClass(s,e),this._shadow=s,t.opacity<1&&this._updateOpacity(),n&&this.getPane().appendChild(this._icon),this._initInteraction(),s&&r&&this.getPane("shadowPane").appendChild(this._shadow)},_removeIcon:function(){this.options.riseOnHover&&this.off({mouseover:this._bringToFront,mouseout:this._resetZIndex}),o.DomUtil.remove(this._icon),this.removeInteractiveTarget(this._icon),this._icon=null},_removeShadow:function(){this._shadow&&o.DomUtil.remove(this._shadow),this._shadow=null},_setPos:function(t){o.DomUtil.setPosition(this._icon,t),this._shadow&&o.DomUtil.setPosition(this._shadow,t),this._zIndex=t.y+this.options.zIndexOffset,this._resetZIndex()},_updateZIndex:function(t){this._icon.style.zIndex=this._zIndex+t},_animateZoom:function(t){var e=this._map._latLngToNewLayerPoint(this._latlng,t.zoom,t.center).round();this._setPos(e)},_initInteraction:function(){if(this.options.interactive&&(o.DomUtil.addClass(this._icon,"leaflet-interactive"),this.addInteractiveTarget(this._icon),o.Handler.MarkerDrag)){var t=this.options.draggable;this.dragging&&(t=this.dragging.enabled(),this.dragging.disable()),this.dragging=new o.Handler.MarkerDrag(this),t&&this.dragging.enable()}},setOpacity:function(t){return this.options.opacity=t,this._map&&this._updateOpacity(),this},_updateOpacity:function(){var t=this.options.opacity;o.DomUtil.setOpacity(this._icon,t),this._shadow&&o.DomUtil.setOpacity(this._shadow,t)},_bringToFront:function(){this._updateZIndex(this.options.riseOffset)},_resetZIndex:function(){this._updateZIndex(0)}}),o.marker=function(t,e){return new o.Marker(t,e)},o.DivIcon=o.Icon.extend({options:{iconSize:[12,12],html:!1,bgPos:null,className:"leaflet-div-icon"},createIcon:function(t){var i=t&&"DIV"===t.tagName?t:e.createElement("div"),n=this.options;if(i.innerHTML=n.html!==!1?n.html:"",n.bgPos){var s=o.point(n.bgPos);i.style.backgroundPosition=-s.x+"px "+-s.y+"px"}return this._setIconStyles(i,"icon"),i},createShadow:function(){return null}}),o.divIcon=function(t){return new o.DivIcon(t)},o.DivOverlay=o.Layer.extend({options:{offset:[0,7],zoomAnimation:!0,className:"",pane:"popupPane"},initialize:function(t,e){o.setOptions(this,t),this._source=e},onAdd:function(t){this._zoomAnimated=this._zoomAnimated&&this.options.zoomAnimation,this._container||this._initLayout(),t._fadeAnimated&&o.DomUtil.setOpacity(this._container,0),clearTimeout(this._removeTimeout),this.getPane().appendChild(this._container),this.update(),t._fadeAnimated&&o.DomUtil.setOpacity(this._container,1),this.bringToFront()},onRemove:function(t){t._fadeAnimated?(o.DomUtil.setOpacity(this._container,0),this._removeTimeout=setTimeout(o.bind(o.DomUtil.remove,o.DomUtil,this._container),200)):o.DomUtil.remove(this._container)},getLatLng:function(){return this._latlng},setLatLng:function(t){return this._latlng=o.latLng(t),this._map&&(this._updatePosition(),this._adjustPan()),this},getContent:function(){return this._content},setContent:function(t){return this._content=t,this.update(),this},getElement:function(){return this._container},update:function(){this._map&&(this._container.style.visibility="hidden",this._updateContent(),this._updateLayout(),this._updatePosition(),this._container.style.visibility="",this._adjustPan())},getEvents:function(){var t={zoom:this._updatePosition,viewreset:this._updatePosition};return this._zoomAnimated&&(t.zoomanim=this._animateZoom),t},isOpen:function(){return!!this._map&&this._map.hasLayer(this)},bringToFront:function(){return this._map&&o.DomUtil.toFront(this._container),this},bringToBack:function(){return this._map&&o.DomUtil.toBack(this._container),this},_updateContent:function(){if(this._content){var t=this._contentNode,e="function"==typeof this._content?this._content(this._source||this):this._content;if("string"==typeof e)t.innerHTML=e;else{for(;t.hasChildNodes();)t.removeChild(t.firstChild);t.appendChild(e)}this.fire("contentupdate")}},_updatePosition:function(){if(this._map){var t=this._map.latLngToLayerPoint(this._latlng),e=o.point(this.options.offset),i=this._getAnchor();this._zoomAnimated?o.DomUtil.setPosition(this._container,t.add(i)):e=e.add(t).add(i);var n=this._containerBottom=-e.y,s=this._containerLeft=-Math.round(this._containerWidth/2)+e.x;this._container.style.bottom=n+"px",this._container.style.left=s+"px"}},_getAnchor:function(){return[0,0]}}),o.Popup=o.DivOverlay.extend({options:{maxWidth:300,minWidth:50,maxHeight:null,autoPan:!0,autoPanPaddingTopLeft:null,autoPanPaddingBottomRight:null,autoPanPadding:[5,5],keepInView:!1,closeButton:!0,autoClose:!0},openOn:function(t){return t.openPopup(this),this},onAdd:function(t){o.DivOverlay.prototype.onAdd.call(this,t),t.fire("popupopen",{popup:this}),this._source&&(this._source.fire("popupopen",{popup:this},!0),this._source instanceof o.Path||this._source.on("preclick",o.DomEvent.stopPropagation))},onRemove:function(t){o.DivOverlay.prototype.onRemove.call(this,t),t.fire("popupclose",{popup:this}),this._source&&(this._source.fire("popupclose",{popup:this},!0),this._source instanceof o.Path||this._source.off("preclick",o.DomEvent.stopPropagation))},getEvents:function(){var t=o.DivOverlay.prototype.getEvents.call(this);return("closeOnClick"in this.options?this.options.closeOnClick:this._map.options.closePopupOnClick)&&(t.preclick=this._close),this.options.keepInView&&(t.moveend=this._adjustPan),t},_close:function(){this._map&&this._map.closePopup(this)},_initLayout:function(){var t="leaflet-popup",e=this._container=o.DomUtil.create("div",t+" "+(this.options.className||"")+" leaflet-zoom-"+(this._zoomAnimated?"animated":"hide"));if(this.options.closeButton){var i=this._closeButton=o.DomUtil.create("a",t+"-close-button",e);i.href="#close",i.innerHTML="&#215;",o.DomEvent.on(i,"click",this._onCloseButtonClick,this)}var n=this._wrapper=o.DomUtil.create("div",t+"-content-wrapper",e);this._contentNode=o.DomUtil.create("div",t+"-content",n),o.DomEvent.disableClickPropagation(n).disableScrollPropagation(this._contentNode).on(n,"contextmenu",o.DomEvent.stopPropagation),this._tipContainer=o.DomUtil.create("div",t+"-tip-container",e),this._tip=o.DomUtil.create("div",t+"-tip",this._tipContainer)},_updateLayout:function(){var t=this._contentNode,e=t.style;e.width="",e.whiteSpace="nowrap";var i=t.offsetWidth;i=Math.min(i,this.options.maxWidth),i=Math.max(i,this.options.minWidth),e.width=i+1+"px",e.whiteSpace="",e.height="";var n=t.offsetHeight,s=this.options.maxHeight,r="leaflet-popup-scrolled";s&&n>s?(e.height=s+"px",o.DomUtil.addClass(t,r)):o.DomUtil.removeClass(t,r),this._containerWidth=this._container.offsetWidth},_animateZoom:function(t){var e=this._map._latLngToNewLayerPoint(this._latlng,t.zoom,t.center),i=this._getAnchor();o.DomUtil.setPosition(this._container,e.add(i))},_adjustPan:function(){if(!(!this.options.autoPan||this._map._panAnim&&this._map._panAnim._inProgress)){var t=this._map,e=parseInt(o.DomUtil.getStyle(this._container,"marginBottom"),10)||0,i=this._container.offsetHeight+e,n=this._containerWidth,s=new o.Point(this._containerLeft,-i-this._containerBottom);this._zoomAnimated&&s._add(o.DomUtil.getPosition(this._container));var r=t.layerPointToContainerPoint(s),a=o.point(this.options.autoPanPadding),h=o.point(this.options.autoPanPaddingTopLeft||a),l=o.point(this.options.autoPanPaddingBottomRight||a),u=t.getSize(),c=0,d=0;r.x+n+l.x>u.x&&(c=r.x+n-u.x+l.x),r.x-c-h.x<0&&(c=r.x-h.x),r.y+i+l.y>u.y&&(d=r.y+i-u.y+l.y),
 r.y-d-h.y<0&&(d=r.y-h.y),(c||d)&&t.fire("autopanstart").panBy([c,d])}},_onCloseButtonClick:function(t){this._close(),o.DomEvent.stop(t)},_getAnchor:function(){return o.point(this._source&&this._source._getPopupAnchor?this._source._getPopupAnchor():[0,0])}}),o.popup=function(t,e){return new o.Popup(t,e)},o.Map.mergeOptions({closePopupOnClick:!0}),o.Map.include({openPopup:function(t,e,i){return t instanceof o.Popup||(t=new o.Popup(i).setContent(t)),e&&t.setLatLng(e),this.hasLayer(t)?this:(this._popup&&this._popup.options.autoClose&&this.closePopup(),this._popup=t,this.addLayer(t))},closePopup:function(t){return t&&t!==this._popup||(t=this._popup,this._popup=null),t&&this.removeLayer(t),this}}),o.Layer.include({bindPopup:function(t,e){return t instanceof o.Popup?(o.setOptions(t,e),this._popup=t,t._source=this):(this._popup&&!e||(this._popup=new o.Popup(e,this)),this._popup.setContent(t)),this._popupHandlersAdded||(this.on({click:this._openPopup,remove:this.closePopup,move:this._movePopup}),this._popupHandlersAdded=!0),this},unbindPopup:function(){return this._popup&&(this.off({click:this._openPopup,remove:this.closePopup,move:this._movePopup}),this._popupHandlersAdded=!1,this._popup=null),this},openPopup:function(t,e){if(t instanceof o.Layer||(e=t,t=this),t instanceof o.FeatureGroup)for(var i in this._layers){t=this._layers[i];break}return e||(e=t.getCenter?t.getCenter():t.getLatLng()),this._popup&&this._map&&(this._popup._source=t,this._popup.update(),this._map.openPopup(this._popup,e)),this},closePopup:function(){return this._popup&&this._popup._close(),this},togglePopup:function(t){return this._popup&&(this._popup._map?this.closePopup():this.openPopup(t)),this},isPopupOpen:function(){return this._popup.isOpen()},setPopupContent:function(t){return this._popup&&this._popup.setContent(t),this},getPopup:function(){return this._popup},_openPopup:function(t){var e=t.layer||t.target;if(this._popup&&this._map)return o.DomEvent.stop(t),e instanceof o.Path?void this.openPopup(t.layer||t.target,t.latlng):void(this._map.hasLayer(this._popup)&&this._popup._source===e?this.closePopup():this.openPopup(e,t.latlng))},_movePopup:function(t){this._popup.setLatLng(t.latlng)}}),o.Marker.include({_getPopupAnchor:function(){return this.options.icon.options.popupAnchor||[0,0]}}),o.Tooltip=o.DivOverlay.extend({options:{pane:"tooltipPane",offset:[0,0],direction:"auto",permanent:!1,sticky:!1,interactive:!1,opacity:.9},onAdd:function(t){o.DivOverlay.prototype.onAdd.call(this,t),this.setOpacity(this.options.opacity),t.fire("tooltipopen",{tooltip:this}),this._source&&this._source.fire("tooltipopen",{tooltip:this},!0)},onRemove:function(t){o.DivOverlay.prototype.onRemove.call(this,t),t.fire("tooltipclose",{tooltip:this}),this._source&&this._source.fire("tooltipclose",{tooltip:this},!0)},getEvents:function(){var t=o.DivOverlay.prototype.getEvents.call(this);return o.Browser.touch&&!this.options.permanent&&(t.preclick=this._close),t},_close:function(){this._map&&this._map.closeTooltip(this)},_initLayout:function(){var t="leaflet-tooltip",e=t+" "+(this.options.className||"")+" leaflet-zoom-"+(this._zoomAnimated?"animated":"hide");this._contentNode=this._container=o.DomUtil.create("div",e)},_updateLayout:function(){},_adjustPan:function(){},_setPosition:function(t){var e=this._map,i=this._container,n=e.latLngToContainerPoint(e.getCenter()),s=e.layerPointToContainerPoint(t),r=this.options.direction,a=i.offsetWidth,h=i.offsetHeight,l=o.point(this.options.offset),u=this._getAnchor();"top"===r?t=t.add(o.point(-a/2+l.x,-h+l.y+u.y)):"bottom"===r?t=t.subtract(o.point(a/2-l.x,-l.y)):"center"===r?t=t.subtract(o.point(a/2+l.x,h/2-u.y+l.y)):"right"===r||"auto"===r&&s.x<n.x?(r="right",t=t.add([l.x+u.x,u.y-h/2+l.y])):(r="left",t=t.subtract(o.point(a+u.x-l.x,h/2-u.y-l.y))),o.DomUtil.removeClass(i,"leaflet-tooltip-right"),o.DomUtil.removeClass(i,"leaflet-tooltip-left"),o.DomUtil.removeClass(i,"leaflet-tooltip-top"),o.DomUtil.removeClass(i,"leaflet-tooltip-bottom"),o.DomUtil.addClass(i,"leaflet-tooltip-"+r),o.DomUtil.setPosition(i,t)},_updatePosition:function(){var t=this._map.latLngToLayerPoint(this._latlng);this._setPosition(t)},setOpacity:function(t){this.options.opacity=t,this._container&&o.DomUtil.setOpacity(this._container,t)},_animateZoom:function(t){var e=this._map._latLngToNewLayerPoint(this._latlng,t.zoom,t.center);this._setPosition(e)},_getAnchor:function(){return o.point(this._source._getTooltipAnchor&&!this.options.sticky?this._source._getTooltipAnchor():[0,0])}}),o.tooltip=function(t,e){return new o.Tooltip(t,e)},o.Map.include({openTooltip:function(t,e,i){return t instanceof o.Tooltip||(t=new o.Tooltip(i).setContent(t)),e&&t.setLatLng(e),this.hasLayer(t)?this:this.addLayer(t)},closeTooltip:function(t){return t&&this.removeLayer(t),this}}),o.Layer.include({bindTooltip:function(t,e){return t instanceof o.Tooltip?(o.setOptions(t,e),this._tooltip=t,t._source=this):(this._tooltip&&!e||(this._tooltip=o.tooltip(e,this)),this._tooltip.setContent(t)),this._initTooltipInteractions(),this._tooltip.options.permanent&&this._map&&this._map.hasLayer(this)&&this.openTooltip(),this},unbindTooltip:function(){return this._tooltip&&(this._initTooltipInteractions(!0),this.closeTooltip(),this._tooltip=null),this},_initTooltipInteractions:function(t){if(t||!this._tooltipHandlersAdded){var e=t?"off":"on",i={remove:this.closeTooltip,move:this._moveTooltip};this._tooltip.options.permanent?i.add=this._openTooltip:(i.mouseover=this._openTooltip,i.mouseout=this.closeTooltip,this._tooltip.options.sticky&&(i.mousemove=this._moveTooltip),o.Browser.touch&&(i.click=this._openTooltip)),this[e](i),this._tooltipHandlersAdded=!t}},openTooltip:function(t,e){if(t instanceof o.Layer||(e=t,t=this),t instanceof o.FeatureGroup)for(var i in this._layers){t=this._layers[i];break}return e||(e=t.getCenter?t.getCenter():t.getLatLng()),this._tooltip&&this._map&&(this._tooltip._source=t,this._tooltip.update(),this._map.openTooltip(this._tooltip,e),this._tooltip.options.interactive&&this._tooltip._container&&(o.DomUtil.addClass(this._tooltip._container,"leaflet-clickable"),this.addInteractiveTarget(this._tooltip._container))),this},closeTooltip:function(){return this._tooltip&&(this._tooltip._close(),this._tooltip.options.interactive&&(o.DomUtil.removeClass(this._tooltip._container,"leaflet-clickable"),this.removeInteractiveTarget(this._tooltip._container))),this},toggleTooltip:function(t){return this._tooltip&&(this._tooltip._map?this.closeTooltip():this.openTooltip(t)),this},isTooltipOpen:function(){return this._tooltip.isOpen()},setTooltipContent:function(t){return this._tooltip&&this._tooltip.setContent(t),this},getTooltip:function(){return this._tooltip},_openTooltip:function(t){var e=t.layer||t.target;this._tooltip&&this._map&&this.openTooltip(e,this._tooltip.options.sticky?t.latlng:i)},_moveTooltip:function(t){var e,i,n=t.latlng;this._tooltip.options.sticky&&t.originalEvent&&(e=this._map.mouseEventToContainerPoint(t.originalEvent),i=this._map.containerPointToLayerPoint(e),n=this._map.layerPointToLatLng(i)),this._tooltip.setLatLng(n)}}),o.Marker.include({_getTooltipAnchor:function(){return this.options.icon.options.tooltipAnchor||[0,0]}}),o.LayerGroup=o.Layer.extend({initialize:function(t){this._layers={};var e,i;if(t)for(e=0,i=t.length;e<i;e++)this.addLayer(t[e])},addLayer:function(t){var e=this.getLayerId(t);return this._layers[e]=t,this._map&&this._map.addLayer(t),this},removeLayer:function(t){var e=t in this._layers?t:this.getLayerId(t);return this._map&&this._layers[e]&&this._map.removeLayer(this._layers[e]),delete this._layers[e],this},hasLayer:function(t){return!!t&&(t in this._layers||this.getLayerId(t)in this._layers)},clearLayers:function(){for(var t in this._layers)this.removeLayer(this._layers[t]);return this},invoke:function(t){var e,i,n=Array.prototype.slice.call(arguments,1);for(e in this._layers)i=this._layers[e],i[t]&&i[t].apply(i,n);return this},onAdd:function(t){for(var e in this._layers)t.addLayer(this._layers[e])},onRemove:function(t){for(var e in this._layers)t.removeLayer(this._layers[e])},eachLayer:function(t,e){for(var i in this._layers)t.call(e,this._layers[i]);return this},getLayer:function(t){return this._layers[t]},getLayers:function(){var t=[];for(var e in this._layers)t.push(this._layers[e]);return t},setZIndex:function(t){return this.invoke("setZIndex",t)},getLayerId:function(t){return o.stamp(t)}}),o.layerGroup=function(t){return new o.LayerGroup(t)},o.FeatureGroup=o.LayerGroup.extend({addLayer:function(t){return this.hasLayer(t)?this:(t.addEventParent(this),o.LayerGroup.prototype.addLayer.call(this,t),this.fire("layeradd",{layer:t}))},removeLayer:function(t){return this.hasLayer(t)?(t in this._layers&&(t=this._layers[t]),t.removeEventParent(this),o.LayerGroup.prototype.removeLayer.call(this,t),this.fire("layerremove",{layer:t})):this},setStyle:function(t){return this.invoke("setStyle",t)},bringToFront:function(){return this.invoke("bringToFront")},bringToBack:function(){return this.invoke("bringToBack")},getBounds:function(){var t=new o.LatLngBounds;for(var e in this._layers){var i=this._layers[e];t.extend(i.getBounds?i.getBounds():i.getLatLng())}return t}}),o.featureGroup=function(t){return new o.FeatureGroup(t)},o.Renderer=o.Layer.extend({options:{padding:.1},initialize:function(t){o.setOptions(this,t),o.stamp(this)},onAdd:function(){this._container||(this._initContainer(),this._zoomAnimated&&o.DomUtil.addClass(this._container,"leaflet-zoom-animated")),this.getPane().appendChild(this._container),this._update()},onRemove:function(){o.DomUtil.remove(this._container)},getEvents:function(){var t={viewreset:this._reset,zoom:this._onZoom,moveend:this._update};return this._zoomAnimated&&(t.zoomanim=this._onAnimZoom),t},_onAnimZoom:function(t){this._updateTransform(t.center,t.zoom)},_onZoom:function(){this._updateTransform(this._map.getCenter(),this._map.getZoom())},_updateTransform:function(t,e){var i=this._map.getZoomScale(e,this._zoom),n=o.DomUtil.getPosition(this._container),s=this._map.getSize().multiplyBy(.5+this.options.padding),r=this._map.project(this._center,e),a=this._map.project(t,e),h=a.subtract(r),l=s.multiplyBy(-i).add(n).add(s).subtract(h);o.Browser.any3d?o.DomUtil.setTransform(this._container,l,i):o.DomUtil.setPosition(this._container,l)},_reset:function(){this._update(),this._updateTransform(this._center,this._zoom)},_update:function(){var t=this.options.padding,e=this._map.getSize(),i=this._map.containerPointToLayerPoint(e.multiplyBy(-t)).round();this._bounds=new o.Bounds(i,i.add(e.multiplyBy(1+2*t)).round()),this._center=this._map.getCenter(),this._zoom=this._map.getZoom()}}),o.Map.include({getRenderer:function(t){var e=t.options.renderer||this._getPaneRenderer(t.options.pane)||this.options.renderer||this._renderer;return e||(e=this._renderer=this.options.preferCanvas&&o.canvas()||o.svg()),this.hasLayer(e)||this.addLayer(e),e},_getPaneRenderer:function(t){if("overlayPane"===t||t===i)return!1;var e=this._paneRenderers[t];return e===i&&(e=o.SVG&&o.svg({pane:t})||o.Canvas&&o.canvas({pane:t}),this._paneRenderers[t]=e),e}}),o.Path=o.Layer.extend({options:{stroke:!0,color:"#3388ff",weight:3,opacity:1,lineCap:"round",lineJoin:"round",dashArray:null,dashOffset:null,fill:!1,fillColor:null,fillOpacity:.2,fillRule:"evenodd",interactive:!0},beforeAdd:function(t){this._renderer=t.getRenderer(this)},onAdd:function(){this._renderer._initPath(this),this._reset(),this._renderer._addPath(this)},onRemove:function(){this._renderer._removePath(this)},getEvents:function(){return{zoomend:this._project,moveend:this._update,viewreset:this._reset}},redraw:function(){return this._map&&this._renderer._updatePath(this),this},setStyle:function(t){return o.setOptions(this,t),this._renderer&&this._renderer._updateStyle(this),this},bringToFront:function(){return this._renderer&&this._renderer._bringToFront(this),this},bringToBack:function(){return this._renderer&&this._renderer._bringToBack(this),this},getElement:function(){return this._path},_reset:function(){this._project(),this._update()},_clickTolerance:function(){return(this.options.stroke?this.options.weight/2:0)+(o.Browser.touch?10:0)}}),o.LineUtil={simplify:function(t,e){if(!e||!t.length)return t.slice();var i=e*e;return t=this._reducePoints(t,i),t=this._simplifyDP(t,i)},pointToSegmentDistance:function(t,e,i){return Math.sqrt(this._sqClosestPointOnSegment(t,e,i,!0))},closestPointOnSegment:function(t,e,i){return this._sqClosestPointOnSegment(t,e,i)},_simplifyDP:function(t,e){var n=t.length,o=typeof Uint8Array!=i+""?Uint8Array:Array,s=new o(n);s[0]=s[n-1]=1,this._simplifyDPStep(t,s,e,0,n-1);var r,a=[];for(r=0;r<n;r++)s[r]&&a.push(t[r]);return a},_simplifyDPStep:function(t,e,i,n,o){var s,r,a,h=0;for(r=n+1;r<=o-1;r++)a=this._sqClosestPointOnSegment(t[r],t[n],t[o],!0),a>h&&(s=r,h=a);h>i&&(e[s]=1,this._simplifyDPStep(t,e,i,n,s),this._simplifyDPStep(t,e,i,s,o))},_reducePoints:function(t,e){for(var i=[t[0]],n=1,o=0,s=t.length;n<s;n++)this._sqDist(t[n],t[o])>e&&(i.push(t[n]),o=n);return o<s-1&&i.push(t[s-1]),i},clipSegment:function(t,e,i,n,o){var s,r,a,h=n?this._lastCode:this._getBitCode(t,i),l=this._getBitCode(e,i);for(this._lastCode=l;;){if(!(h|l))return[t,e];if(h&l)return!1;s=h||l,r=this._getEdgeIntersection(t,e,s,i,o),a=this._getBitCode(r,i),s===h?(t=r,h=a):(e=r,l=a)}},_getEdgeIntersection:function(t,e,i,n,s){var r,a,h=e.x-t.x,l=e.y-t.y,u=n.min,c=n.max;return 8&i?(r=t.x+h*(c.y-t.y)/l,a=c.y):4&i?(r=t.x+h*(u.y-t.y)/l,a=u.y):2&i?(r=c.x,a=t.y+l*(c.x-t.x)/h):1&i&&(r=u.x,a=t.y+l*(u.x-t.x)/h),new o.Point(r,a,s)},_getBitCode:function(t,e){var i=0;return t.x<e.min.x?i|=1:t.x>e.max.x&&(i|=2),t.y<e.min.y?i|=4:t.y>e.max.y&&(i|=8),i},_sqDist:function(t,e){var i=e.x-t.x,n=e.y-t.y;return i*i+n*n},_sqClosestPointOnSegment:function(t,e,i,n){var s,r=e.x,a=e.y,h=i.x-r,l=i.y-a,u=h*h+l*l;return u>0&&(s=((t.x-r)*h+(t.y-a)*l)/u,s>1?(r=i.x,a=i.y):s>0&&(r+=h*s,a+=l*s)),h=t.x-r,l=t.y-a,n?h*h+l*l:new o.Point(r,a)}},o.Polyline=o.Path.extend({options:{smoothFactor:1,noClip:!1},initialize:function(t,e){o.setOptions(this,e),this._setLatLngs(t)},getLatLngs:function(){return this._latlngs},setLatLngs:function(t){return this._setLatLngs(t),this.redraw()},isEmpty:function(){return!this._latlngs.length},closestLayerPoint:function(t){for(var e,i,n=1/0,s=null,r=o.LineUtil._sqClosestPointOnSegment,a=0,h=this._parts.length;a<h;a++)for(var l=this._parts[a],u=1,c=l.length;u<c;u++){e=l[u-1],i=l[u];var d=r(t,e,i,!0);d<n&&(n=d,s=r(t,e,i))}return s&&(s.distance=Math.sqrt(n)),s},getCenter:function(){var t,e,i,n,o,s,r,a=this._rings[0],h=a.length;if(!h)return null;for(t=0,e=0;t<h-1;t++)e+=a[t].distanceTo(a[t+1])/2;if(0===e)return this._map.layerPointToLatLng(a[0]);for(t=0,n=0;t<h-1;t++)if(o=a[t],s=a[t+1],i=o.distanceTo(s),n+=i,n>e)return r=(n-e)/i,this._map.layerPointToLatLng([s.x-r*(s.x-o.x),s.y-r*(s.y-o.y)])},getBounds:function(){return this._bounds},addLatLng:function(t,e){return e=e||this._defaultShape(),t=o.latLng(t),e.push(t),this._bounds.extend(t),this.redraw()},_setLatLngs:function(t){this._bounds=new o.LatLngBounds,this._latlngs=this._convertLatLngs(t)},_defaultShape:function(){return o.Polyline._flat(this._latlngs)?this._latlngs:this._latlngs[0]},_convertLatLngs:function(t){for(var e=[],i=o.Polyline._flat(t),n=0,s=t.length;n<s;n++)i?(e[n]=o.latLng(t[n]),this._bounds.extend(e[n])):e[n]=this._convertLatLngs(t[n]);return e},_project:function(){var t=new o.Bounds;this._rings=[],this._projectLatlngs(this._latlngs,this._rings,t);var e=this._clickTolerance(),i=new o.Point(e,e);this._bounds.isValid()&&t.isValid()&&(t.min._subtract(i),t.max._add(i),this._pxBounds=t)},_projectLatlngs:function(t,e,i){var n,s,r=t[0]instanceof o.LatLng,a=t.length;if(r){for(s=[],n=0;n<a;n++)s[n]=this._map.latLngToLayerPoint(t[n]),i.extend(s[n]);e.push(s)}else for(n=0;n<a;n++)this._projectLatlngs(t[n],e,i)},_clipPoints:function(){var t=this._renderer._bounds;if(this._parts=[],this._pxBounds&&this._pxBounds.intersects(t)){if(this.options.noClip)return void(this._parts=this._rings);var e,i,n,s,r,a,h,l=this._parts;for(e=0,n=0,s=this._rings.length;e<s;e++)for(h=this._rings[e],i=0,r=h.length;i<r-1;i++)a=o.LineUtil.clipSegment(h[i],h[i+1],t,i,!0),a&&(l[n]=l[n]||[],l[n].push(a[0]),a[1]===h[i+1]&&i!==r-2||(l[n].push(a[1]),n++))}},_simplifyPoints:function(){for(var t=this._parts,e=this.options.smoothFactor,i=0,n=t.length;i<n;i++)t[i]=o.LineUtil.simplify(t[i],e)},_update:function(){this._map&&(this._clipPoints(),this._simplifyPoints(),this._updatePath())},_updatePath:function(){this._renderer._updatePoly(this)}}),o.polyline=function(t,e){return new o.Polyline(t,e)},o.Polyline._flat=function(t){return!o.Util.isArray(t[0])||"object"!=typeof t[0][0]&&"undefined"!=typeof t[0][0]},o.PolyUtil={},o.PolyUtil.clipPolygon=function(t,e,i){var n,s,r,a,h,l,u,c,d,_=[1,4,2,8],m=o.LineUtil;for(s=0,u=t.length;s<u;s++)t[s]._code=m._getBitCode(t[s],e);for(a=0;a<4;a++){for(c=_[a],n=[],s=0,u=t.length,r=u-1;s<u;r=s++)h=t[s],l=t[r],h._code&c?l._code&c||(d=m._getEdgeIntersection(l,h,c,e,i),d._code=m._getBitCode(d,e),n.push(d)):(l._code&c&&(d=m._getEdgeIntersection(l,h,c,e,i),d._code=m._getBitCode(d,e),n.push(d)),n.push(h));t=n}return t},o.Polygon=o.Polyline.extend({options:{fill:!0},isEmpty:function(){return!this._latlngs.length||!this._latlngs[0].length},getCenter:function(){var t,e,i,n,o,s,r,a,h,l=this._rings[0],u=l.length;if(!u)return null;for(s=r=a=0,t=0,e=u-1;t<u;e=t++)i=l[t],n=l[e],o=i.y*n.x-n.y*i.x,r+=(i.x+n.x)*o,a+=(i.y+n.y)*o,s+=3*o;return h=0===s?l[0]:[r/s,a/s],this._map.layerPointToLatLng(h)},_convertLatLngs:function(t){var e=o.Polyline.prototype._convertLatLngs.call(this,t),i=e.length;return i>=2&&e[0]instanceof o.LatLng&&e[0].equals(e[i-1])&&e.pop(),e},_setLatLngs:function(t){o.Polyline.prototype._setLatLngs.call(this,t),o.Polyline._flat(this._latlngs)&&(this._latlngs=[this._latlngs])},_defaultShape:function(){return o.Polyline._flat(this._latlngs[0])?this._latlngs[0]:this._latlngs[0][0]},_clipPoints:function(){var t=this._renderer._bounds,e=this.options.weight,i=new o.Point(e,e);if(t=new o.Bounds(t.min.subtract(i),t.max.add(i)),this._parts=[],this._pxBounds&&this._pxBounds.intersects(t)){if(this.options.noClip)return void(this._parts=this._rings);for(var n,s=0,r=this._rings.length;s<r;s++)n=o.PolyUtil.clipPolygon(this._rings[s],t,!0),n.length&&this._parts.push(n)}},_updatePath:function(){this._renderer._updatePoly(this,!0)}}),o.polygon=function(t,e){return new o.Polygon(t,e)},o.Rectangle=o.Polygon.extend({initialize:function(t,e){o.Polygon.prototype.initialize.call(this,this._boundsToLatLngs(t),e)},setBounds:function(t){return this.setLatLngs(this._boundsToLatLngs(t))},_boundsToLatLngs:function(t){return t=o.latLngBounds(t),[t.getSouthWest(),t.getNorthWest(),t.getNorthEast(),t.getSouthEast()]}}),o.rectangle=function(t,e){return new o.Rectangle(t,e)},o.CircleMarker=o.Path.extend({options:{fill:!0,radius:10},initialize:function(t,e){o.setOptions(this,e),this._latlng=o.latLng(t),this._radius=this.options.radius},setLatLng:function(t){return this._latlng=o.latLng(t),this.redraw(),this.fire("move",{latlng:this._latlng})},getLatLng:function(){return this._latlng},setRadius:function(t){return this.options.radius=this._radius=t,this.redraw()},getRadius:function(){return this._radius},setStyle:function(t){var e=t&&t.radius||this._radius;return o.Path.prototype.setStyle.call(this,t),this.setRadius(e),this},_project:function(){this._point=this._map.latLngToLayerPoint(this._latlng),this._updateBounds()},_updateBounds:function(){var t=this._radius,e=this._radiusY||t,i=this._clickTolerance(),n=[t+i,e+i];this._pxBounds=new o.Bounds(this._point.subtract(n),this._point.add(n))},_update:function(){this._map&&this._updatePath()},_updatePath:function(){this._renderer._updateCircle(this)},_empty:function(){return this._radius&&!this._renderer._bounds.intersects(this._pxBounds)}}),o.circleMarker=function(t,e){return new o.CircleMarker(t,e)},o.Circle=o.CircleMarker.extend({initialize:function(t,e,i){if("number"==typeof e&&(e=o.extend({},i,{radius:e})),o.setOptions(this,e),this._latlng=o.latLng(t),isNaN(this.options.radius))throw new Error("Circle radius cannot be NaN");this._mRadius=this.options.radius},setRadius:function(t){return this._mRadius=t,this.redraw()},getRadius:function(){return this._mRadius},getBounds:function(){var t=[this._radius,this._radiusY||this._radius];return new o.LatLngBounds(this._map.layerPointToLatLng(this._point.subtract(t)),this._map.layerPointToLatLng(this._point.add(t)))},setStyle:o.Path.prototype.setStyle,_project:function(){var t=this._latlng.lng,e=this._latlng.lat,i=this._map,n=i.options.crs;if(n.distance===o.CRS.Earth.distance){var s=Math.PI/180,r=this._mRadius/o.CRS.Earth.R/s,a=i.project([e+r,t]),h=i.project([e-r,t]),l=a.add(h).divideBy(2),u=i.unproject(l).lat,c=Math.acos((Math.cos(r*s)-Math.sin(e*s)*Math.sin(u*s))/(Math.cos(e*s)*Math.cos(u*s)))/s;(isNaN(c)||0===c)&&(c=r/Math.cos(Math.PI/180*e)),this._point=l.subtract(i.getPixelOrigin()),this._radius=isNaN(c)?0:Math.max(Math.round(l.x-i.project([u,t-c]).x),1),this._radiusY=Math.max(Math.round(l.y-a.y),1)}else{var d=n.unproject(n.project(this._latlng).subtract([this._mRadius,0]));this._point=i.latLngToLayerPoint(this._latlng),this._radius=this._point.x-i.latLngToLayerPoint(d).x}this._updateBounds()}}),o.circle=function(t,e,i){return new o.Circle(t,e,i)},o.SVG=o.Renderer.extend({getEvents:function(){var t=o.Renderer.prototype.getEvents.call(this);return t.zoomstart=this._onZoomStart,t},_initContainer:function(){this._container=o.SVG.create("svg"),this._container.setAttribute("pointer-events","none"),this._rootGroup=o.SVG.create("g"),this._container.appendChild(this._rootGroup)},_onZoomStart:function(){this._update()},_update:function(){if(!this._map._animatingZoom||!this._bounds){o.Renderer.prototype._update.call(this);var t=this._bounds,e=t.getSize(),i=this._container;this._svgSize&&this._svgSize.equals(e)||(this._svgSize=e,i.setAttribute("width",e.x),i.setAttribute("height",e.y)),o.DomUtil.setPosition(i,t.min),i.setAttribute("viewBox",[t.min.x,t.min.y,e.x,e.y].join(" "))}},_initPath:function(t){var e=t._path=o.SVG.create("path");t.options.className&&o.DomUtil.addClass(e,t.options.className),t.options.interactive&&o.DomUtil.addClass(e,"leaflet-interactive"),this._updateStyle(t)},_addPath:function(t){this._rootGroup.appendChild(t._path),t.addInteractiveTarget(t._path)},_removePath:function(t){o.DomUtil.remove(t._path),t.removeInteractiveTarget(t._path)},_updatePath:function(t){t._project(),t._update()},_updateStyle:function(t){var e=t._path,i=t.options;e&&(i.stroke?(e.setAttribute("stroke",i.color),e.setAttribute("stroke-opacity",i.opacity),e.setAttribute("stroke-width",i.weight),e.setAttribute("stroke-linecap",i.lineCap),e.setAttribute("stroke-linejoin",i.lineJoin),i.dashArray?e.setAttribute("stroke-dasharray",i.dashArray):e.removeAttribute("stroke-dasharray"),i.dashOffset?e.setAttribute("stroke-dashoffset",i.dashOffset):e.removeAttribute("stroke-dashoffset")):e.setAttribute("stroke","none"),i.fill?(e.setAttribute("fill",i.fillColor||i.color),e.setAttribute("fill-opacity",i.fillOpacity),e.setAttribute("fill-rule",i.fillRule||"evenodd")):e.setAttribute("fill","none"))},_updatePoly:function(t,e){this._setPath(t,o.SVG.pointsToPath(t._parts,e))},_updateCircle:function(t){var e=t._point,i=t._radius,n=t._radiusY||i,o="a"+i+","+n+" 0 1,0 ",s=t._empty()?"M0 0":"M"+(e.x-i)+","+e.y+o+2*i+",0 "+o+2*-i+",0 ";this._setPath(t,s)},_setPath:function(t,e){t._path.setAttribute("d",e)},_bringToFront:function(t){o.DomUtil.toFront(t._path)},_bringToBack:function(t){o.DomUtil.toBack(t._path)}}),o.extend(o.SVG,{create:function(t){return e.createElementNS("http://www.w3.org/2000/svg",t)},pointsToPath:function(t,e){var i,n,s,r,a,h,l="";for(i=0,s=t.length;i<s;i++){for(a=t[i],n=0,r=a.length;n<r;n++)h=a[n],l+=(n?"L":"M")+h.x+" "+h.y;l+=e?o.Browser.svg?"z":"x":""}return l||"M0 0"}}),o.Browser.svg=!(!e.createElementNS||!o.SVG.create("svg").createSVGRect),o.svg=function(t){return o.Browser.svg||o.Browser.vml?new o.SVG(t):null},o.Browser.vml=!o.Browser.svg&&function(){try{var t=e.createElement("div");t.innerHTML='<v:shape adj="1"/>';var i=t.firstChild;return i.style.behavior="url(#default#VML)",i&&"object"==typeof i.adj}catch(n){return!1}}(),o.SVG.include(o.Browser.vml?{_initContainer:function(){this._container=o.DomUtil.create("div","leaflet-vml-container")},_update:function(){this._map._animatingZoom||o.Renderer.prototype._update.call(this)},_initPath:function(t){var e=t._container=o.SVG.create("shape");o.DomUtil.addClass(e,"leaflet-vml-shape "+(this.options.className||"")),e.coordsize="1 1",t._path=o.SVG.create("path"),e.appendChild(t._path),this._updateStyle(t)},_addPath:function(t){var e=t._container;this._container.appendChild(e),t.options.interactive&&t.addInteractiveTarget(e)},_removePath:function(t){var e=t._container;o.DomUtil.remove(e),t.removeInteractiveTarget(e)},_updateStyle:function(t){var e=t._stroke,i=t._fill,n=t.options,s=t._container;s.stroked=!!n.stroke,s.filled=!!n.fill,n.stroke?(e||(e=t._stroke=o.SVG.create("stroke")),s.appendChild(e),e.weight=n.weight+"px",e.color=n.color,e.opacity=n.opacity,n.dashArray?e.dashStyle=o.Util.isArray(n.dashArray)?n.dashArray.join(" "):n.dashArray.replace(/( *, *)/g," "):e.dashStyle="",e.endcap=n.lineCap.replace("butt","flat"),e.joinstyle=n.lineJoin):e&&(s.removeChild(e),t._stroke=null),n.fill?(i||(i=t._fill=o.SVG.create("fill")),s.appendChild(i),i.color=n.fillColor||n.color,i.opacity=n.fillOpacity):i&&(s.removeChild(i),t._fill=null)},_updateCircle:function(t){var e=t._point.round(),i=Math.round(t._radius),n=Math.round(t._radiusY||i);this._setPath(t,t._empty()?"M0 0":"AL "+e.x+","+e.y+" "+i+","+n+" 0,23592600")},_setPath:function(t,e){t._path.v=e},_bringToFront:function(t){o.DomUtil.toFront(t._container)},_bringToBack:function(t){o.DomUtil.toBack(t._container)}}:{}),o.Browser.vml&&(o.SVG.create=function(){try{return e.namespaces.add("lvml","urn:schemas-microsoft-com:vml"),function(t){return e.createElement("<lvml:"+t+' class="lvml">')}}catch(t){return function(t){return e.createElement("<"+t+' xmlns="urn:schemas-microsoft.com:vml" class="lvml">')}}}()),o.Canvas=o.Renderer.extend({onAdd:function(){o.Renderer.prototype.onAdd.call(this),this._layers=this._layers||{},this._draw()},_initContainer:function(){var t=this._container=e.createElement("canvas");o.DomEvent.on(t,"mousemove",o.Util.throttle(this._onMouseMove,32,this),this).on(t,"click dblclick mousedown mouseup contextmenu",this._onClick,this).on(t,"mouseout",this._handleMouseOut,this),this._ctx=t.getContext("2d")},_update:function(){if(!this._map._animatingZoom||!this._bounds){this._drawnLayers={},o.Renderer.prototype._update.call(this);var t=this._bounds,e=this._container,i=t.getSize(),n=o.Browser.retina?2:1;o.DomUtil.setPosition(e,t.min),e.width=n*i.x,e.height=n*i.y,e.style.width=i.x+"px",e.style.height=i.y+"px",o.Browser.retina&&this._ctx.scale(2,2),this._ctx.translate(-t.min.x,-t.min.y)}},_initPath:function(t){this._updateDashArray(t),this._layers[o.stamp(t)]=t},_addPath:o.Util.falseFn,_removePath:function(t){t._removed=!0,this._requestRedraw(t)},_updatePath:function(t){this._redrawBounds=t._pxBounds,this._draw(!0),t._project(),t._update(),this._draw(),this._redrawBounds=null},_updateStyle:function(t){this._updateDashArray(t),this._requestRedraw(t)},_updateDashArray:function(t){if(t.options.dashArray){var e,i=t.options.dashArray.split(","),n=[];for(e=0;e<i.length;e++)n.push(Number(i[e]));t.options._dashArray=n}},_requestRedraw:function(t){if(this._map){var e=(t.options.weight||0)+1;this._redrawBounds=this._redrawBounds||new o.Bounds,this._redrawBounds.extend(t._pxBounds.min.subtract([e,e])),this._redrawBounds.extend(t._pxBounds.max.add([e,e])),this._redrawRequest=this._redrawRequest||o.Util.requestAnimFrame(this._redraw,this)}},_redraw:function(){this._redrawRequest=null,this._draw(!0),this._draw(),this._redrawBounds=null},_draw:function(t){this._clear=t;var e,i=this._redrawBounds;this._ctx.save(),i&&(this._ctx.beginPath(),this._ctx.rect(i.min.x,i.min.y,i.max.x-i.min.x,i.max.y-i.min.y),this._ctx.clip());for(var n in this._layers)e=this._layers[n],(!i||e._pxBounds&&e._pxBounds.intersects(i))&&e._updatePath(),t&&e._removed&&(delete e._removed,delete this._layers[n]);this._ctx.restore()},_updatePoly:function(t,e){var i,n,o,s,r=t._parts,a=r.length,h=this._ctx;if(a){for(this._drawnLayers[t._leaflet_id]=t,h.beginPath(),h.setLineDash&&h.setLineDash(t.options&&t.options._dashArray||[]),i=0;i<a;i++){for(n=0,o=r[i].length;n<o;n++)s=r[i][n],h[n?"lineTo":"moveTo"](s.x,s.y);e&&h.closePath()}this._fillStroke(h,t)}},_updateCircle:function(t){if(!t._empty()){var e=t._point,i=this._ctx,n=t._radius,o=(t._radiusY||n)/n;this._drawnLayers[t._leaflet_id]=t,1!==o&&(i.save(),i.scale(1,o)),i.beginPath(),i.arc(e.x,e.y/o,n,0,2*Math.PI,!1),1!==o&&i.restore(),this._fillStroke(i,t)}},_fillStroke:function(t,e){var i=this._clear,n=e.options;t.globalCompositeOperation=i?"destination-out":"source-over",n.fill&&(t.globalAlpha=i?1:n.fillOpacity,t.fillStyle=n.fillColor||n.color,t.fill(n.fillRule||"evenodd")),n.stroke&&0!==n.weight&&(t.globalAlpha=i?1:n.opacity,e._prevWeight=t.lineWidth=i?e._prevWeight+1:n.weight,t.strokeStyle=n.color,t.lineCap=n.lineCap,t.lineJoin=n.lineJoin,t.stroke())},_onClick:function(t){var e,i=this._map.mouseEventToLayerPoint(t),n=[];for(var s in this._layers)e=this._layers[s],e.options.interactive&&e._containsPoint(i)&&!this._map._draggableMoved(e)&&(o.DomEvent._fakeStop(t),n.push(e));n.length&&this._fireEvent(n,t)},_onMouseMove:function(t){if(this._map&&!this._map.dragging.moving()&&!this._map._animatingZoom){var e=this._map.mouseEventToLayerPoint(t);this._handleMouseOut(t,e),this._handleMouseHover(t,e)}},_handleMouseOut:function(t,e){var i=this._hoveredLayer;!i||"mouseout"!==t.type&&i._containsPoint(e)||(o.DomUtil.removeClass(this._container,"leaflet-interactive"),this._fireEvent([i],t,"mouseout"),this._hoveredLayer=null)},_handleMouseHover:function(t,e){var i,n;for(i in this._drawnLayers)n=this._drawnLayers[i],n.options.interactive&&n._containsPoint(e)&&(o.DomUtil.addClass(this._container,"leaflet-interactive"),this._fireEvent([n],t,"mouseover"),this._hoveredLayer=n);this._hoveredLayer&&this._fireEvent([this._hoveredLayer],t)},_fireEvent:function(t,e,i){this._map._fireDOMEvent(e,i||e.type,t)},_bringToFront:o.Util.falseFn,_bringToBack:o.Util.falseFn}),o.Browser.canvas=function(){return!!e.createElement("canvas").getContext}(),o.canvas=function(t){return o.Browser.canvas?new o.Canvas(t):null},o.Polyline.prototype._containsPoint=function(t,e){var i,n,s,r,a,h,l=this._clickTolerance();if(!this._pxBounds.contains(t))return!1;for(i=0,r=this._parts.length;i<r;i++)for(h=this._parts[i],n=0,a=h.length,s=a-1;n<a;s=n++)if((e||0!==n)&&o.LineUtil.pointToSegmentDistance(t,h[s],h[n])<=l)return!0;return!1},o.Polygon.prototype._containsPoint=function(t){var e,i,n,s,r,a,h,l,u=!1;if(!this._pxBounds.contains(t))return!1;for(s=0,h=this._parts.length;s<h;s++)for(e=this._parts[s],r=0,l=e.length,a=l-1;r<l;a=r++)i=e[r],n=e[a],i.y>t.y!=n.y>t.y&&t.x<(n.x-i.x)*(t.y-i.y)/(n.y-i.y)+i.x&&(u=!u);return u||o.Polyline.prototype._containsPoint.call(this,t,!0)},o.CircleMarker.prototype._containsPoint=function(t){return t.distanceTo(this._point)<=this._radius+this._clickTolerance()},o.GeoJSON=o.FeatureGroup.extend({initialize:function(t,e){o.setOptions(this,e),this._layers={},t&&this.addData(t)},addData:function(t){var e,i,n,s=o.Util.isArray(t)?t:t.features;if(s){for(e=0,i=s.length;e<i;e++)n=s[e],(n.geometries||n.geometry||n.features||n.coordinates)&&this.addData(n);return this}var r=this.options;if(r.filter&&!r.filter(t))return this;var a=o.GeoJSON.geometryToLayer(t,r);return a?(a.feature=o.GeoJSON.asFeature(t),a.defaultOptions=a.options,this.resetStyle(a),r.onEachFeature&&r.onEachFeature(t,a),this.addLayer(a)):this},resetStyle:function(t){return t.options=o.Util.extend({},t.defaultOptions),this._setLayerStyle(t,this.options.style),this},setStyle:function(t){return this.eachLayer(function(e){
 this._setLayerStyle(e,t)},this)},_setLayerStyle:function(t,e){"function"==typeof e&&(e=e(t.feature)),t.setStyle&&t.setStyle(e)}}),o.extend(o.GeoJSON,{geometryToLayer:function(t,e){var i,n,s,r,a="Feature"===t.type?t.geometry:t,h=a?a.coordinates:null,l=[],u=e&&e.pointToLayer,c=e&&e.coordsToLatLng||this.coordsToLatLng;if(!h&&!a)return null;switch(a.type){case"Point":return i=c(h),u?u(t,i):new o.Marker(i);case"MultiPoint":for(s=0,r=h.length;s<r;s++)i=c(h[s]),l.push(u?u(t,i):new o.Marker(i));return new o.FeatureGroup(l);case"LineString":case"MultiLineString":return n=this.coordsToLatLngs(h,"LineString"===a.type?0:1,c),new o.Polyline(n,e);case"Polygon":case"MultiPolygon":return n=this.coordsToLatLngs(h,"Polygon"===a.type?1:2,c),new o.Polygon(n,e);case"GeometryCollection":for(s=0,r=a.geometries.length;s<r;s++){var d=this.geometryToLayer({geometry:a.geometries[s],type:"Feature",properties:t.properties},e);d&&l.push(d)}return new o.FeatureGroup(l);default:throw new Error("Invalid GeoJSON object.")}},coordsToLatLng:function(t){return new o.LatLng(t[1],t[0],t[2])},coordsToLatLngs:function(t,e,i){for(var n,o=[],s=0,r=t.length;s<r;s++)n=e?this.coordsToLatLngs(t[s],e-1,i):(i||this.coordsToLatLng)(t[s]),o.push(n);return o},latLngToCoords:function(t){return t.alt!==i?[t.lng,t.lat,t.alt]:[t.lng,t.lat]},latLngsToCoords:function(t,e,i){for(var n=[],s=0,r=t.length;s<r;s++)n.push(e?o.GeoJSON.latLngsToCoords(t[s],e-1,i):o.GeoJSON.latLngToCoords(t[s]));return!e&&i&&n.push(n[0]),n},getFeature:function(t,e){return t.feature?o.extend({},t.feature,{geometry:e}):o.GeoJSON.asFeature(e)},asFeature:function(t){return"Feature"===t.type?t:{type:"Feature",properties:{},geometry:t}}});var r={toGeoJSON:function(){return o.GeoJSON.getFeature(this,{type:"Point",coordinates:o.GeoJSON.latLngToCoords(this.getLatLng())})}};o.Marker.include(r),o.Circle.include(r),o.CircleMarker.include(r),o.Polyline.prototype.toGeoJSON=function(){var t=!o.Polyline._flat(this._latlngs),e=o.GeoJSON.latLngsToCoords(this._latlngs,t?1:0);return o.GeoJSON.getFeature(this,{type:(t?"Multi":"")+"LineString",coordinates:e})},o.Polygon.prototype.toGeoJSON=function(){var t=!o.Polyline._flat(this._latlngs),e=t&&!o.Polyline._flat(this._latlngs[0]),i=o.GeoJSON.latLngsToCoords(this._latlngs,e?2:t?1:0,!0);return t||(i=[i]),o.GeoJSON.getFeature(this,{type:(e?"Multi":"")+"Polygon",coordinates:i})},o.LayerGroup.include({toMultiPoint:function(){var t=[];return this.eachLayer(function(e){t.push(e.toGeoJSON().geometry.coordinates)}),o.GeoJSON.getFeature(this,{type:"MultiPoint",coordinates:t})},toGeoJSON:function(){var t=this.feature&&this.feature.geometry&&this.feature.geometry.type;if("MultiPoint"===t)return this.toMultiPoint();var e="GeometryCollection"===t,i=[];return this.eachLayer(function(t){if(t.toGeoJSON){var n=t.toGeoJSON();i.push(e?n.geometry:o.GeoJSON.asFeature(n))}}),e?o.GeoJSON.getFeature(this,{geometries:i,type:"GeometryCollection"}):{type:"FeatureCollection",features:i}}}),o.geoJSON=function(t,e){return new o.GeoJSON(t,e)},o.geoJson=o.geoJSON;var a="_leaflet_events";o.DomEvent={on:function(t,e,i,n){if("object"==typeof e)for(var s in e)this._on(t,s,e[s],i);else{e=o.Util.splitWords(e);for(var r=0,a=e.length;r<a;r++)this._on(t,e[r],i,n)}return this},off:function(t,e,i,n){if("object"==typeof e)for(var s in e)this._off(t,s,e[s],i);else{e=o.Util.splitWords(e);for(var r=0,a=e.length;r<a;r++)this._off(t,e[r],i,n)}return this},_on:function(e,i,n,s){var r=i+o.stamp(n)+(s?"_"+o.stamp(s):"");if(e[a]&&e[a][r])return this;var h=function(i){return n.call(s||e,i||t.event)},l=h;return o.Browser.pointer&&0===i.indexOf("touch")?this.addPointerListener(e,i,h,r):o.Browser.touch&&"dblclick"===i&&this.addDoubleTapListener?this.addDoubleTapListener(e,h,r):"addEventListener"in e?"mousewheel"===i?e.addEventListener("onwheel"in e?"wheel":"mousewheel",h,!1):"mouseenter"===i||"mouseleave"===i?(h=function(i){i=i||t.event,o.DomEvent._isExternalTarget(e,i)&&l(i)},e.addEventListener("mouseenter"===i?"mouseover":"mouseout",h,!1)):("click"===i&&o.Browser.android&&(h=function(t){return o.DomEvent._filterClick(t,l)}),e.addEventListener(i,h,!1)):"attachEvent"in e&&e.attachEvent("on"+i,h),e[a]=e[a]||{},e[a][r]=h,this},_off:function(t,e,i,n){var s=e+o.stamp(i)+(n?"_"+o.stamp(n):""),r=t[a]&&t[a][s];return r?(o.Browser.pointer&&0===e.indexOf("touch")?this.removePointerListener(t,e,s):o.Browser.touch&&"dblclick"===e&&this.removeDoubleTapListener?this.removeDoubleTapListener(t,s):"removeEventListener"in t?"mousewheel"===e?t.removeEventListener("onwheel"in t?"wheel":"mousewheel",r,!1):t.removeEventListener("mouseenter"===e?"mouseover":"mouseleave"===e?"mouseout":e,r,!1):"detachEvent"in t&&t.detachEvent("on"+e,r),t[a][s]=null,this):this},stopPropagation:function(t){return t.stopPropagation?t.stopPropagation():t.originalEvent?t.originalEvent._stopped=!0:t.cancelBubble=!0,o.DomEvent._skipped(t),this},disableScrollPropagation:function(t){return o.DomEvent.on(t,"mousewheel",o.DomEvent.stopPropagation)},disableClickPropagation:function(t){var e=o.DomEvent.stopPropagation;return o.DomEvent.on(t,o.Draggable.START.join(" "),e),o.DomEvent.on(t,{click:o.DomEvent._fakeStop,dblclick:e})},preventDefault:function(t){return t.preventDefault?t.preventDefault():t.returnValue=!1,this},stop:function(t){return o.DomEvent.preventDefault(t).stopPropagation(t)},getMousePosition:function(t,e){if(!e)return new o.Point(t.clientX,t.clientY);var i=e.getBoundingClientRect();return new o.Point(t.clientX-i.left-e.clientLeft,t.clientY-i.top-e.clientTop)},_wheelPxFactor:o.Browser.win&&o.Browser.chrome?2:o.Browser.gecko?t.devicePixelRatio:1,getWheelDelta:function(t){return o.Browser.edge?t.wheelDeltaY/2:t.deltaY&&0===t.deltaMode?-t.deltaY/o.DomEvent._wheelPxFactor:t.deltaY&&1===t.deltaMode?20*-t.deltaY:t.deltaY&&2===t.deltaMode?60*-t.deltaY:t.deltaX||t.deltaZ?0:t.wheelDelta?(t.wheelDeltaY||t.wheelDelta)/2:t.detail&&Math.abs(t.detail)<32765?20*-t.detail:t.detail?t.detail/-32765*60:0},_skipEvents:{},_fakeStop:function(t){o.DomEvent._skipEvents[t.type]=!0},_skipped:function(t){var e=this._skipEvents[t.type];return this._skipEvents[t.type]=!1,e},_isExternalTarget:function(t,e){var i=e.relatedTarget;if(!i)return!0;try{for(;i&&i!==t;)i=i.parentNode}catch(n){return!1}return i!==t},_filterClick:function(t,e){var i=t.timeStamp||t.originalEvent&&t.originalEvent.timeStamp,n=o.DomEvent._lastClick&&i-o.DomEvent._lastClick;return n&&n>100&&n<500||t.target._simulatedClick&&!t._simulated?void o.DomEvent.stop(t):(o.DomEvent._lastClick=i,void e(t))}},o.DomEvent.addListener=o.DomEvent.on,o.DomEvent.removeListener=o.DomEvent.off,o.Draggable=o.Evented.extend({options:{clickTolerance:3},statics:{START:o.Browser.touch?["touchstart","mousedown"]:["mousedown"],END:{mousedown:"mouseup",touchstart:"touchend",pointerdown:"touchend",MSPointerDown:"touchend"},MOVE:{mousedown:"mousemove",touchstart:"touchmove",pointerdown:"touchmove",MSPointerDown:"touchmove"}},initialize:function(t,e,i){this._element=t,this._dragStartTarget=e||t,this._preventOutline=i},enable:function(){this._enabled||(o.DomEvent.on(this._dragStartTarget,o.Draggable.START.join(" "),this._onDown,this),this._enabled=!0)},disable:function(){this._enabled&&(o.DomEvent.off(this._dragStartTarget,o.Draggable.START.join(" "),this._onDown,this),this._enabled=!1,this._moved=!1)},_onDown:function(t){if(!t._simulated&&this._enabled&&(this._moved=!1,!o.DomUtil.hasClass(this._element,"leaflet-zoom-anim")&&!(o.Draggable._dragging||t.shiftKey||1!==t.which&&1!==t.button&&!t.touches)&&this._enabled&&(o.Draggable._dragging=!0,this._preventOutline&&o.DomUtil.preventOutline(this._element),o.DomUtil.disableImageDrag(),o.DomUtil.disableTextSelection(),!this._moving))){this.fire("down");var i=t.touches?t.touches[0]:t;this._startPoint=new o.Point(i.clientX,i.clientY),o.DomEvent.on(e,o.Draggable.MOVE[t.type],this._onMove,this).on(e,o.Draggable.END[t.type],this._onUp,this)}},_onMove:function(i){if(!i._simulated&&this._enabled){if(i.touches&&i.touches.length>1)return void(this._moved=!0);var n=i.touches&&1===i.touches.length?i.touches[0]:i,s=new o.Point(n.clientX,n.clientY),r=s.subtract(this._startPoint);(r.x||r.y)&&(Math.abs(r.x)+Math.abs(r.y)<this.options.clickTolerance||(o.DomEvent.preventDefault(i),this._moved||(this.fire("dragstart"),this._moved=!0,this._startPos=o.DomUtil.getPosition(this._element).subtract(r),o.DomUtil.addClass(e.body,"leaflet-dragging"),this._lastTarget=i.target||i.srcElement,t.SVGElementInstance&&this._lastTarget instanceof SVGElementInstance&&(this._lastTarget=this._lastTarget.correspondingUseElement),o.DomUtil.addClass(this._lastTarget,"leaflet-drag-target")),this._newPos=this._startPos.add(r),this._moving=!0,o.Util.cancelAnimFrame(this._animRequest),this._lastEvent=i,this._animRequest=o.Util.requestAnimFrame(this._updatePosition,this,!0)))}},_updatePosition:function(){var t={originalEvent:this._lastEvent};this.fire("predrag",t),o.DomUtil.setPosition(this._element,this._newPos),this.fire("drag",t)},_onUp:function(t){if(!t._simulated&&this._enabled){o.DomUtil.removeClass(e.body,"leaflet-dragging"),this._lastTarget&&(o.DomUtil.removeClass(this._lastTarget,"leaflet-drag-target"),this._lastTarget=null);for(var i in o.Draggable.MOVE)o.DomEvent.off(e,o.Draggable.MOVE[i],this._onMove,this).off(e,o.Draggable.END[i],this._onUp,this);o.DomUtil.enableImageDrag(),o.DomUtil.enableTextSelection(),this._moved&&this._moving&&(o.Util.cancelAnimFrame(this._animRequest),this.fire("dragend",{distance:this._newPos.distanceTo(this._startPos)})),this._moving=!1,o.Draggable._dragging=!1}}}),o.Handler=o.Class.extend({initialize:function(t){this._map=t},enable:function(){return this._enabled?this:(this._enabled=!0,this.addHooks(),this)},disable:function(){return this._enabled?(this._enabled=!1,this.removeHooks(),this):this},enabled:function(){return!!this._enabled}}),o.Map.mergeOptions({dragging:!0,inertia:!o.Browser.android23,inertiaDeceleration:3400,inertiaMaxSpeed:1/0,easeLinearity:.2,worldCopyJump:!1,maxBoundsViscosity:0}),o.Map.Drag=o.Handler.extend({addHooks:function(){if(!this._draggable){var t=this._map;this._draggable=new o.Draggable(t._mapPane,t._container),this._draggable.on({down:this._onDown,dragstart:this._onDragStart,drag:this._onDrag,dragend:this._onDragEnd},this),this._draggable.on("predrag",this._onPreDragLimit,this),t.options.worldCopyJump&&(this._draggable.on("predrag",this._onPreDragWrap,this),t.on("zoomend",this._onZoomEnd,this),t.whenReady(this._onZoomEnd,this))}o.DomUtil.addClass(this._map._container,"leaflet-grab leaflet-touch-drag"),this._draggable.enable(),this._positions=[],this._times=[]},removeHooks:function(){o.DomUtil.removeClass(this._map._container,"leaflet-grab"),o.DomUtil.removeClass(this._map._container,"leaflet-touch-drag"),this._draggable.disable()},moved:function(){return this._draggable&&this._draggable._moved},moving:function(){return this._draggable&&this._draggable._moving},_onDown:function(){this._map._stop()},_onDragStart:function(){var t=this._map;if(this._map.options.maxBounds&&this._map.options.maxBoundsViscosity){var e=o.latLngBounds(this._map.options.maxBounds);this._offsetLimit=o.bounds(this._map.latLngToContainerPoint(e.getNorthWest()).multiplyBy(-1),this._map.latLngToContainerPoint(e.getSouthEast()).multiplyBy(-1).add(this._map.getSize())),this._viscosity=Math.min(1,Math.max(0,this._map.options.maxBoundsViscosity))}else this._offsetLimit=null;t.fire("movestart").fire("dragstart"),t.options.inertia&&(this._positions=[],this._times=[])},_onDrag:function(t){if(this._map.options.inertia){var e=this._lastTime=+new Date,i=this._lastPos=this._draggable._absPos||this._draggable._newPos;this._positions.push(i),this._times.push(e),e-this._times[0]>50&&(this._positions.shift(),this._times.shift())}this._map.fire("move",t).fire("drag",t)},_onZoomEnd:function(){var t=this._map.getSize().divideBy(2),e=this._map.latLngToLayerPoint([0,0]);this._initialWorldOffset=e.subtract(t).x,this._worldWidth=this._map.getPixelWorldBounds().getSize().x},_viscousLimit:function(t,e){return t-(t-e)*this._viscosity},_onPreDragLimit:function(){if(this._viscosity&&this._offsetLimit){var t=this._draggable._newPos.subtract(this._draggable._startPos),e=this._offsetLimit;t.x<e.min.x&&(t.x=this._viscousLimit(t.x,e.min.x)),t.y<e.min.y&&(t.y=this._viscousLimit(t.y,e.min.y)),t.x>e.max.x&&(t.x=this._viscousLimit(t.x,e.max.x)),t.y>e.max.y&&(t.y=this._viscousLimit(t.y,e.max.y)),this._draggable._newPos=this._draggable._startPos.add(t)}},_onPreDragWrap:function(){var t=this._worldWidth,e=Math.round(t/2),i=this._initialWorldOffset,n=this._draggable._newPos.x,o=(n-e+i)%t+e-i,s=(n+e+i)%t-e-i,r=Math.abs(o+i)<Math.abs(s+i)?o:s;this._draggable._absPos=this._draggable._newPos.clone(),this._draggable._newPos.x=r},_onDragEnd:function(t){var e=this._map,i=e.options,n=!i.inertia||this._times.length<2;if(e.fire("dragend",t),n)e.fire("moveend");else{var s=this._lastPos.subtract(this._positions[0]),r=(this._lastTime-this._times[0])/1e3,a=i.easeLinearity,h=s.multiplyBy(a/r),l=h.distanceTo([0,0]),u=Math.min(i.inertiaMaxSpeed,l),c=h.multiplyBy(u/l),d=u/(i.inertiaDeceleration*a),_=c.multiplyBy(-d/2).round();_.x||_.y?(_=e._limitOffset(_,e.options.maxBounds),o.Util.requestAnimFrame(function(){e.panBy(_,{duration:d,easeLinearity:a,noMoveStart:!0,animate:!0})})):e.fire("moveend")}}}),o.Map.addInitHook("addHandler","dragging",o.Map.Drag),o.Map.mergeOptions({doubleClickZoom:!0}),o.Map.DoubleClickZoom=o.Handler.extend({addHooks:function(){this._map.on("dblclick",this._onDoubleClick,this)},removeHooks:function(){this._map.off("dblclick",this._onDoubleClick,this)},_onDoubleClick:function(t){var e=this._map,i=e.getZoom(),n=e.options.zoomDelta,o=t.originalEvent.shiftKey?i-n:i+n;"center"===e.options.doubleClickZoom?e.setZoom(o):e.setZoomAround(t.containerPoint,o)}}),o.Map.addInitHook("addHandler","doubleClickZoom",o.Map.DoubleClickZoom),o.Map.mergeOptions({scrollWheelZoom:!0,wheelDebounceTime:40,wheelPxPerZoomLevel:60}),o.Map.ScrollWheelZoom=o.Handler.extend({addHooks:function(){o.DomEvent.on(this._map._container,"mousewheel",this._onWheelScroll,this),this._delta=0},removeHooks:function(){o.DomEvent.off(this._map._container,"mousewheel",this._onWheelScroll,this)},_onWheelScroll:function(t){var e=o.DomEvent.getWheelDelta(t),i=this._map.options.wheelDebounceTime;this._delta+=e,this._lastMousePos=this._map.mouseEventToContainerPoint(t),this._startTime||(this._startTime=+new Date);var n=Math.max(i-(+new Date-this._startTime),0);clearTimeout(this._timer),this._timer=setTimeout(o.bind(this._performZoom,this),n),o.DomEvent.stop(t)},_performZoom:function(){var t=this._map,e=t.getZoom(),i=this._map.options.zoomSnap||0;t._stop();var n=this._delta/(4*this._map.options.wheelPxPerZoomLevel),o=4*Math.log(2/(1+Math.exp(-Math.abs(n))))/Math.LN2,s=i?Math.ceil(o/i)*i:o,r=t._limitZoom(e+(this._delta>0?s:-s))-e;this._delta=0,this._startTime=null,r&&("center"===t.options.scrollWheelZoom?t.setZoom(e+r):t.setZoomAround(this._lastMousePos,e+r))}}),o.Map.addInitHook("addHandler","scrollWheelZoom",o.Map.ScrollWheelZoom),o.extend(o.DomEvent,{_touchstart:o.Browser.msPointer?"MSPointerDown":o.Browser.pointer?"pointerdown":"touchstart",_touchend:o.Browser.msPointer?"MSPointerUp":o.Browser.pointer?"pointerup":"touchend",addDoubleTapListener:function(t,e,i){function n(t){var e;if(e=o.Browser.pointer?o.DomEvent._pointersCount:t.touches.length,!(e>1)){var i=Date.now(),n=i-(r||i);a=t.touches?t.touches[0]:t,h=n>0&&n<=l,r=i}}function s(){if(h&&!a.cancelBubble){if(o.Browser.pointer){var t,i,n={};for(i in a)t=a[i],n[i]=t&&t.bind?t.bind(a):t;a=n}a.type="dblclick",e(a),r=null}}var r,a,h=!1,l=250,u="_leaflet_",c=this._touchstart,d=this._touchend;return t[u+c+i]=n,t[u+d+i]=s,t[u+"dblclick"+i]=e,t.addEventListener(c,n,!1),t.addEventListener(d,s,!1),o.Browser.edge||t.addEventListener("dblclick",e,!1),this},removeDoubleTapListener:function(t,e){var i="_leaflet_",n=t[i+this._touchstart+e],s=t[i+this._touchend+e],r=t[i+"dblclick"+e];return t.removeEventListener(this._touchstart,n,!1),t.removeEventListener(this._touchend,s,!1),o.Browser.edge||t.removeEventListener("dblclick",r,!1),this}}),o.extend(o.DomEvent,{POINTER_DOWN:o.Browser.msPointer?"MSPointerDown":"pointerdown",POINTER_MOVE:o.Browser.msPointer?"MSPointerMove":"pointermove",POINTER_UP:o.Browser.msPointer?"MSPointerUp":"pointerup",POINTER_CANCEL:o.Browser.msPointer?"MSPointerCancel":"pointercancel",TAG_WHITE_LIST:["INPUT","SELECT","OPTION"],_pointers:{},_pointersCount:0,addPointerListener:function(t,e,i,n){return"touchstart"===e?this._addPointerStart(t,i,n):"touchmove"===e?this._addPointerMove(t,i,n):"touchend"===e&&this._addPointerEnd(t,i,n),this},removePointerListener:function(t,e,i){var n=t["_leaflet_"+e+i];return"touchstart"===e?t.removeEventListener(this.POINTER_DOWN,n,!1):"touchmove"===e?t.removeEventListener(this.POINTER_MOVE,n,!1):"touchend"===e&&(t.removeEventListener(this.POINTER_UP,n,!1),t.removeEventListener(this.POINTER_CANCEL,n,!1)),this},_addPointerStart:function(t,i,n){var s=o.bind(function(t){if("mouse"!==t.pointerType&&t.pointerType!==t.MSPOINTER_TYPE_MOUSE){if(!(this.TAG_WHITE_LIST.indexOf(t.target.tagName)<0))return;o.DomEvent.preventDefault(t)}this._handlePointer(t,i)},this);if(t["_leaflet_touchstart"+n]=s,t.addEventListener(this.POINTER_DOWN,s,!1),!this._pointerDocListener){var r=o.bind(this._globalPointerUp,this);e.documentElement.addEventListener(this.POINTER_DOWN,o.bind(this._globalPointerDown,this),!0),e.documentElement.addEventListener(this.POINTER_MOVE,o.bind(this._globalPointerMove,this),!0),e.documentElement.addEventListener(this.POINTER_UP,r,!0),e.documentElement.addEventListener(this.POINTER_CANCEL,r,!0),this._pointerDocListener=!0}},_globalPointerDown:function(t){this._pointers[t.pointerId]=t,this._pointersCount++},_globalPointerMove:function(t){this._pointers[t.pointerId]&&(this._pointers[t.pointerId]=t)},_globalPointerUp:function(t){delete this._pointers[t.pointerId],this._pointersCount--},_handlePointer:function(t,e){t.touches=[];for(var i in this._pointers)t.touches.push(this._pointers[i]);t.changedTouches=[t],e(t)},_addPointerMove:function(t,e,i){var n=o.bind(function(t){(t.pointerType!==t.MSPOINTER_TYPE_MOUSE&&"mouse"!==t.pointerType||0!==t.buttons)&&this._handlePointer(t,e)},this);t["_leaflet_touchmove"+i]=n,t.addEventListener(this.POINTER_MOVE,n,!1)},_addPointerEnd:function(t,e,i){var n=o.bind(function(t){this._handlePointer(t,e)},this);t["_leaflet_touchend"+i]=n,t.addEventListener(this.POINTER_UP,n,!1),t.addEventListener(this.POINTER_CANCEL,n,!1)}}),o.Map.mergeOptions({touchZoom:o.Browser.touch&&!o.Browser.android23,bounceAtZoomLimits:!0}),o.Map.TouchZoom=o.Handler.extend({addHooks:function(){o.DomUtil.addClass(this._map._container,"leaflet-touch-zoom"),o.DomEvent.on(this._map._container,"touchstart",this._onTouchStart,this)},removeHooks:function(){o.DomUtil.removeClass(this._map._container,"leaflet-touch-zoom"),o.DomEvent.off(this._map._container,"touchstart",this._onTouchStart,this)},_onTouchStart:function(t){var i=this._map;if(t.touches&&2===t.touches.length&&!i._animatingZoom&&!this._zooming){var n=i.mouseEventToContainerPoint(t.touches[0]),s=i.mouseEventToContainerPoint(t.touches[1]);this._centerPoint=i.getSize()._divideBy(2),this._startLatLng=i.containerPointToLatLng(this._centerPoint),"center"!==i.options.touchZoom&&(this._pinchStartLatLng=i.containerPointToLatLng(n.add(s)._divideBy(2))),this._startDist=n.distanceTo(s),this._startZoom=i.getZoom(),this._moved=!1,this._zooming=!0,i._stop(),o.DomEvent.on(e,"touchmove",this._onTouchMove,this).on(e,"touchend",this._onTouchEnd,this),o.DomEvent.preventDefault(t)}},_onTouchMove:function(t){if(t.touches&&2===t.touches.length&&this._zooming){var e=this._map,i=e.mouseEventToContainerPoint(t.touches[0]),n=e.mouseEventToContainerPoint(t.touches[1]),s=i.distanceTo(n)/this._startDist;if(this._zoom=e.getScaleZoom(s,this._startZoom),!e.options.bounceAtZoomLimits&&(this._zoom<e.getMinZoom()&&s<1||this._zoom>e.getMaxZoom()&&s>1)&&(this._zoom=e._limitZoom(this._zoom)),"center"===e.options.touchZoom){if(this._center=this._startLatLng,1===s)return}else{var r=i._add(n)._divideBy(2)._subtract(this._centerPoint);if(1===s&&0===r.x&&0===r.y)return;this._center=e.unproject(e.project(this._pinchStartLatLng,this._zoom).subtract(r),this._zoom)}this._moved||(e._moveStart(!0),this._moved=!0),o.Util.cancelAnimFrame(this._animRequest);var a=o.bind(e._move,e,this._center,this._zoom,{pinch:!0,round:!1});this._animRequest=o.Util.requestAnimFrame(a,this,!0),o.DomEvent.preventDefault(t)}},_onTouchEnd:function(){return this._moved&&this._zooming?(this._zooming=!1,o.Util.cancelAnimFrame(this._animRequest),o.DomEvent.off(e,"touchmove",this._onTouchMove).off(e,"touchend",this._onTouchEnd),void(this._map.options.zoomAnimation?this._map._animateZoom(this._center,this._map._limitZoom(this._zoom),!0,this._map.options.zoomSnap):this._map._resetView(this._center,this._map._limitZoom(this._zoom)))):void(this._zooming=!1)}}),o.Map.addInitHook("addHandler","touchZoom",o.Map.TouchZoom),o.Map.mergeOptions({tap:!0,tapTolerance:15}),o.Map.Tap=o.Handler.extend({addHooks:function(){o.DomEvent.on(this._map._container,"touchstart",this._onDown,this)},removeHooks:function(){o.DomEvent.off(this._map._container,"touchstart",this._onDown,this)},_onDown:function(t){if(t.touches){if(o.DomEvent.preventDefault(t),this._fireClick=!0,t.touches.length>1)return this._fireClick=!1,void clearTimeout(this._holdTimeout);var i=t.touches[0],n=i.target;this._startPos=this._newPos=new o.Point(i.clientX,i.clientY),n.tagName&&"a"===n.tagName.toLowerCase()&&o.DomUtil.addClass(n,"leaflet-active"),this._holdTimeout=setTimeout(o.bind(function(){this._isTapValid()&&(this._fireClick=!1,this._onUp(),this._simulateEvent("contextmenu",i))},this),1e3),this._simulateEvent("mousedown",i),o.DomEvent.on(e,{touchmove:this._onMove,touchend:this._onUp},this)}},_onUp:function(t){if(clearTimeout(this._holdTimeout),o.DomEvent.off(e,{touchmove:this._onMove,touchend:this._onUp},this),this._fireClick&&t&&t.changedTouches){var i=t.changedTouches[0],n=i.target;n&&n.tagName&&"a"===n.tagName.toLowerCase()&&o.DomUtil.removeClass(n,"leaflet-active"),this._simulateEvent("mouseup",i),this._isTapValid()&&this._simulateEvent("click",i)}},_isTapValid:function(){return this._newPos.distanceTo(this._startPos)<=this._map.options.tapTolerance},_onMove:function(t){var e=t.touches[0];this._newPos=new o.Point(e.clientX,e.clientY),this._simulateEvent("mousemove",e)},_simulateEvent:function(i,n){var o=e.createEvent("MouseEvents");o._simulated=!0,n.target._simulatedClick=!0,o.initMouseEvent(i,!0,!0,t,1,n.screenX,n.screenY,n.clientX,n.clientY,!1,!1,!1,!1,0,null),n.target.dispatchEvent(o)}}),o.Browser.touch&&!o.Browser.pointer&&o.Map.addInitHook("addHandler","tap",o.Map.Tap),o.Map.mergeOptions({boxZoom:!0}),o.Map.BoxZoom=o.Handler.extend({initialize:function(t){this._map=t,this._container=t._container,this._pane=t._panes.overlayPane},addHooks:function(){o.DomEvent.on(this._container,"mousedown",this._onMouseDown,this)},removeHooks:function(){o.DomEvent.off(this._container,"mousedown",this._onMouseDown,this)},moved:function(){return this._moved},_resetState:function(){this._moved=!1},_onMouseDown:function(t){return!(!t.shiftKey||1!==t.which&&1!==t.button)&&(this._resetState(),o.DomUtil.disableTextSelection(),o.DomUtil.disableImageDrag(),this._startPoint=this._map.mouseEventToContainerPoint(t),void o.DomEvent.on(e,{contextmenu:o.DomEvent.stop,mousemove:this._onMouseMove,mouseup:this._onMouseUp,keydown:this._onKeyDown},this))},_onMouseMove:function(t){this._moved||(this._moved=!0,this._box=o.DomUtil.create("div","leaflet-zoom-box",this._container),o.DomUtil.addClass(this._container,"leaflet-crosshair"),this._map.fire("boxzoomstart")),this._point=this._map.mouseEventToContainerPoint(t);var e=new o.Bounds(this._point,this._startPoint),i=e.getSize();o.DomUtil.setPosition(this._box,e.min),this._box.style.width=i.x+"px",this._box.style.height=i.y+"px"},_finish:function(){this._moved&&(o.DomUtil.remove(this._box),o.DomUtil.removeClass(this._container,"leaflet-crosshair")),o.DomUtil.enableTextSelection(),o.DomUtil.enableImageDrag(),o.DomEvent.off(e,{contextmenu:o.DomEvent.stop,mousemove:this._onMouseMove,mouseup:this._onMouseUp,keydown:this._onKeyDown},this)},_onMouseUp:function(t){if((1===t.which||1===t.button)&&(this._finish(),this._moved)){setTimeout(o.bind(this._resetState,this),0);var e=new o.LatLngBounds(this._map.containerPointToLatLng(this._startPoint),this._map.containerPointToLatLng(this._point));this._map.fitBounds(e).fire("boxzoomend",{boxZoomBounds:e})}},_onKeyDown:function(t){27===t.keyCode&&this._finish()}}),o.Map.addInitHook("addHandler","boxZoom",o.Map.BoxZoom),o.Map.mergeOptions({keyboard:!0,keyboardPanDelta:80}),o.Map.Keyboard=o.Handler.extend({keyCodes:{left:[37],right:[39],down:[40],up:[38],zoomIn:[187,107,61,171],zoomOut:[189,109,54,173]},initialize:function(t){this._map=t,this._setPanDelta(t.options.keyboardPanDelta),this._setZoomDelta(t.options.zoomDelta)},addHooks:function(){var t=this._map._container;t.tabIndex<=0&&(t.tabIndex="0"),o.DomEvent.on(t,{focus:this._onFocus,blur:this._onBlur,mousedown:this._onMouseDown},this),this._map.on({focus:this._addHooks,blur:this._removeHooks},this)},removeHooks:function(){this._removeHooks(),o.DomEvent.off(this._map._container,{focus:this._onFocus,blur:this._onBlur,mousedown:this._onMouseDown},this),this._map.off({focus:this._addHooks,blur:this._removeHooks},this)},_onMouseDown:function(){if(!this._focused){var i=e.body,n=e.documentElement,o=i.scrollTop||n.scrollTop,s=i.scrollLeft||n.scrollLeft;this._map._container.focus(),t.scrollTo(s,o)}},_onFocus:function(){this._focused=!0,this._map.fire("focus")},_onBlur:function(){this._focused=!1,this._map.fire("blur")},_setPanDelta:function(t){var e,i,n=this._panKeys={},o=this.keyCodes;for(e=0,i=o.left.length;e<i;e++)n[o.left[e]]=[-1*t,0];for(e=0,i=o.right.length;e<i;e++)n[o.right[e]]=[t,0];for(e=0,i=o.down.length;e<i;e++)n[o.down[e]]=[0,t];for(e=0,i=o.up.length;e<i;e++)n[o.up[e]]=[0,-1*t]},_setZoomDelta:function(t){var e,i,n=this._zoomKeys={},o=this.keyCodes;for(e=0,i=o.zoomIn.length;e<i;e++)n[o.zoomIn[e]]=t;for(e=0,i=o.zoomOut.length;e<i;e++)n[o.zoomOut[e]]=-t},_addHooks:function(){o.DomEvent.on(e,"keydown",this._onKeyDown,this)},_removeHooks:function(){o.DomEvent.off(e,"keydown",this._onKeyDown,this)},_onKeyDown:function(t){if(!(t.altKey||t.ctrlKey||t.metaKey)){var e,i=t.keyCode,n=this._map;if(i in this._panKeys){if(n._panAnim&&n._panAnim._inProgress)return;e=this._panKeys[i],t.shiftKey&&(e=o.point(e).multiplyBy(3)),n.panBy(e),n.options.maxBounds&&n.panInsideBounds(n.options.maxBounds)}else if(i in this._zoomKeys)n.setZoom(n.getZoom()+(t.shiftKey?3:1)*this._zoomKeys[i]);else{if(27!==i)return;n.closePopup()}o.DomEvent.stop(t)}}}),o.Map.addInitHook("addHandler","keyboard",o.Map.Keyboard),o.Handler.MarkerDrag=o.Handler.extend({initialize:function(t){this._marker=t},addHooks:function(){var t=this._marker._icon;this._draggable||(this._draggable=new o.Draggable(t,t,(!0))),this._draggable.on({dragstart:this._onDragStart,drag:this._onDrag,dragend:this._onDragEnd},this).enable(),o.DomUtil.addClass(t,"leaflet-marker-draggable")},removeHooks:function(){this._draggable.off({dragstart:this._onDragStart,drag:this._onDrag,dragend:this._onDragEnd},this).disable(),this._marker._icon&&o.DomUtil.removeClass(this._marker._icon,"leaflet-marker-draggable")},moved:function(){return this._draggable&&this._draggable._moved},_onDragStart:function(){this._oldLatLng=this._marker.getLatLng(),this._marker.closePopup().fire("movestart").fire("dragstart")},_onDrag:function(t){var e=this._marker,i=e._shadow,n=o.DomUtil.getPosition(e._icon),s=e._map.layerPointToLatLng(n);i&&o.DomUtil.setPosition(i,n),e._latlng=s,t.latlng=s,t.oldLatLng=this._oldLatLng,e.fire("move",t).fire("drag",t)},_onDragEnd:function(t){delete this._oldLatLng,this._marker.fire("moveend").fire("dragend",t)}}),o.Control=o.Class.extend({options:{position:"topright"},initialize:function(t){o.setOptions(this,t)},getPosition:function(){return this.options.position},setPosition:function(t){var e=this._map;return e&&e.removeControl(this),this.options.position=t,e&&e.addControl(this),this},getContainer:function(){return this._container},addTo:function(t){this.remove(),this._map=t;var e=this._container=this.onAdd(t),i=this.getPosition(),n=t._controlCorners[i];return o.DomUtil.addClass(e,"leaflet-control"),i.indexOf("bottom")!==-1?n.insertBefore(e,n.firstChild):n.appendChild(e),this},remove:function(){return this._map?(o.DomUtil.remove(this._container),this.onRemove&&this.onRemove(this._map),this._map=null,this):this},_refocusOnMap:function(t){this._map&&t&&t.screenX>0&&t.screenY>0&&this._map.getContainer().focus()}}),o.control=function(t){return new o.Control(t)},o.Map.include({addControl:function(t){return t.addTo(this),this},removeControl:function(t){return t.remove(),this},_initControlPos:function(){function t(t,s){var r=i+t+" "+i+s;e[t+s]=o.DomUtil.create("div",r,n)}var e=this._controlCorners={},i="leaflet-",n=this._controlContainer=o.DomUtil.create("div",i+"control-container",this._container);t("top","left"),t("top","right"),t("bottom","left"),t("bottom","right")},_clearControlPos:function(){o.DomUtil.remove(this._controlContainer)}}),o.Control.Zoom=o.Control.extend({options:{position:"topleft",zoomInText:"+",zoomInTitle:"Zoom in",zoomOutText:"-",zoomOutTitle:"Zoom out"},onAdd:function(t){var e="leaflet-control-zoom",i=o.DomUtil.create("div",e+" leaflet-bar"),n=this.options;return this._zoomInButton=this._createButton(n.zoomInText,n.zoomInTitle,e+"-in",i,this._zoomIn),this._zoomOutButton=this._createButton(n.zoomOutText,n.zoomOutTitle,e+"-out",i,this._zoomOut),this._updateDisabled(),t.on("zoomend zoomlevelschange",this._updateDisabled,this),i},onRemove:function(t){t.off("zoomend zoomlevelschange",this._updateDisabled,this)},disable:function(){return this._disabled=!0,this._updateDisabled(),this},enable:function(){return this._disabled=!1,this._updateDisabled(),this},_zoomIn:function(t){!this._disabled&&this._map._zoom<this._map.getMaxZoom()&&this._map.zoomIn(this._map.options.zoomDelta*(t.shiftKey?3:1))},_zoomOut:function(t){!this._disabled&&this._map._zoom>this._map.getMinZoom()&&this._map.zoomOut(this._map.options.zoomDelta*(t.shiftKey?3:1))},_createButton:function(t,e,i,n,s){var r=o.DomUtil.create("a",i,n);return r.innerHTML=t,r.href="#",r.title=e,o.DomEvent.on(r,"mousedown dblclick",o.DomEvent.stopPropagation).on(r,"click",o.DomEvent.stop).on(r,"click",s,this).on(r,"click",this._refocusOnMap,this),r},_updateDisabled:function(){var t=this._map,e="leaflet-disabled";o.DomUtil.removeClass(this._zoomInButton,e),o.DomUtil.removeClass(this._zoomOutButton,e),(this._disabled||t._zoom===t.getMinZoom())&&o.DomUtil.addClass(this._zoomOutButton,e),(this._disabled||t._zoom===t.getMaxZoom())&&o.DomUtil.addClass(this._zoomInButton,e)}}),o.Map.mergeOptions({zoomControl:!0}),o.Map.addInitHook(function(){this.options.zoomControl&&(this.zoomControl=new o.Control.Zoom,this.addControl(this.zoomControl))}),o.control.zoom=function(t){return new o.Control.Zoom(t)},o.Control.Attribution=o.Control.extend({options:{position:"bottomright",prefix:'<a href="http://leafletjs.com" title="A JS library for interactive maps">Leaflet</a>'},initialize:function(t){o.setOptions(this,t),this._attributions={}},onAdd:function(t){t.attributionControl=this,this._container=o.DomUtil.create("div","leaflet-control-attribution"),o.DomEvent&&o.DomEvent.disableClickPropagation(this._container);for(var e in t._layers)t._layers[e].getAttribution&&this.addAttribution(t._layers[e].getAttribution());return this._update(),this._container},setPrefix:function(t){return this.options.prefix=t,this._update(),this},addAttribution:function(t){return t?(this._attributions[t]||(this._attributions[t]=0),this._attributions[t]++,this._update(),this):this},removeAttribution:function(t){return t?(this._attributions[t]&&(this._attributions[t]--,this._update()),this):this},_update:function(){if(this._map){
 var t=[];for(var e in this._attributions)this._attributions[e]&&t.push(e);var i=[];this.options.prefix&&i.push(this.options.prefix),t.length&&i.push(t.join(", ")),this._container.innerHTML=i.join(" | ")}}}),o.Map.mergeOptions({attributionControl:!0}),o.Map.addInitHook(function(){this.options.attributionControl&&(new o.Control.Attribution).addTo(this)}),o.control.attribution=function(t){return new o.Control.Attribution(t)},o.Control.Scale=o.Control.extend({options:{position:"bottomleft",maxWidth:100,metric:!0,imperial:!0},onAdd:function(t){var e="leaflet-control-scale",i=o.DomUtil.create("div",e),n=this.options;return this._addScales(n,e+"-line",i),t.on(n.updateWhenIdle?"moveend":"move",this._update,this),t.whenReady(this._update,this),i},onRemove:function(t){t.off(this.options.updateWhenIdle?"moveend":"move",this._update,this)},_addScales:function(t,e,i){t.metric&&(this._mScale=o.DomUtil.create("div",e,i)),t.imperial&&(this._iScale=o.DomUtil.create("div",e,i))},_update:function(){var t=this._map,e=t.getSize().y/2,i=t.distance(t.containerPointToLatLng([0,e]),t.containerPointToLatLng([this.options.maxWidth,e]));this._updateScales(i)},_updateScales:function(t){this.options.metric&&t&&this._updateMetric(t),this.options.imperial&&t&&this._updateImperial(t)},_updateMetric:function(t){var e=this._getRoundNum(t),i=e<1e3?e+" m":e/1e3+" km";this._updateScale(this._mScale,i,e/t)},_updateImperial:function(t){var e,i,n,o=3.2808399*t;o>5280?(e=o/5280,i=this._getRoundNum(e),this._updateScale(this._iScale,i+" mi",i/e)):(n=this._getRoundNum(o),this._updateScale(this._iScale,n+" ft",n/o))},_updateScale:function(t,e,i){t.style.width=Math.round(this.options.maxWidth*i)+"px",t.innerHTML=e},_getRoundNum:function(t){var e=Math.pow(10,(Math.floor(t)+"").length-1),i=t/e;return i=i>=10?10:i>=5?5:i>=3?3:i>=2?2:1,e*i}}),o.control.scale=function(t){return new o.Control.Scale(t)},o.Control.Layers=o.Control.extend({options:{collapsed:!0,position:"topright",autoZIndex:!0,hideSingleBase:!1},initialize:function(t,e,i){o.setOptions(this,i),this._layers=[],this._lastZIndex=0,this._handlingClick=!1;for(var n in t)this._addLayer(t[n],n);for(n in e)this._addLayer(e[n],n,!0)},onAdd:function(t){return this._initLayout(),this._update(),this._map=t,t.on("zoomend",this._checkDisabledLayers,this),this._container},onRemove:function(){this._map.off("zoomend",this._checkDisabledLayers,this);for(var t=0;t<this._layers.length;t++)this._layers[t].layer.off("add remove",this._onLayerChange,this)},addBaseLayer:function(t,e){return this._addLayer(t,e),this._map?this._update():this},addOverlay:function(t,e){return this._addLayer(t,e,!0),this._map?this._update():this},removeLayer:function(t){t.off("add remove",this._onLayerChange,this);var e=this._getLayer(o.stamp(t));return e&&this._layers.splice(this._layers.indexOf(e),1),this._map?this._update():this},expand:function(){o.DomUtil.addClass(this._container,"leaflet-control-layers-expanded"),this._form.style.height=null;var t=this._map.getSize().y-(this._container.offsetTop+50);return t<this._form.clientHeight?(o.DomUtil.addClass(this._form,"leaflet-control-layers-scrollbar"),this._form.style.height=t+"px"):o.DomUtil.removeClass(this._form,"leaflet-control-layers-scrollbar"),this._checkDisabledLayers(),this},collapse:function(){return o.DomUtil.removeClass(this._container,"leaflet-control-layers-expanded"),this},_initLayout:function(){var t="leaflet-control-layers",e=this._container=o.DomUtil.create("div",t);e.setAttribute("aria-haspopup",!0),o.DomEvent.disableClickPropagation(e),o.Browser.touch||o.DomEvent.disableScrollPropagation(e);var i=this._form=o.DomUtil.create("form",t+"-list");if(this.options.collapsed){o.Browser.android||o.DomEvent.on(e,{mouseenter:this.expand,mouseleave:this.collapse},this);var n=this._layersLink=o.DomUtil.create("a",t+"-toggle",e);n.href="#",n.title="Layers",o.Browser.touch?o.DomEvent.on(n,"click",o.DomEvent.stop).on(n,"click",this.expand,this):o.DomEvent.on(n,"focus",this.expand,this),o.DomEvent.on(i,"click",function(){setTimeout(o.bind(this._onInputClick,this),0)},this),this._map.on("click",this.collapse,this)}else this.expand();this._baseLayersList=o.DomUtil.create("div",t+"-base",i),this._separator=o.DomUtil.create("div",t+"-separator",i),this._overlaysList=o.DomUtil.create("div",t+"-overlays",i),e.appendChild(i)},_getLayer:function(t){for(var e=0;e<this._layers.length;e++)if(this._layers[e]&&o.stamp(this._layers[e].layer)===t)return this._layers[e]},_addLayer:function(t,e,i){t.on("add remove",this._onLayerChange,this),this._layers.push({layer:t,name:e,overlay:i}),this.options.autoZIndex&&t.setZIndex&&(this._lastZIndex++,t.setZIndex(this._lastZIndex))},_update:function(){if(!this._container)return this;o.DomUtil.empty(this._baseLayersList),o.DomUtil.empty(this._overlaysList);var t,e,i,n,s=0;for(i=0;i<this._layers.length;i++)n=this._layers[i],this._addItem(n),e=e||n.overlay,t=t||!n.overlay,s+=n.overlay?0:1;return this.options.hideSingleBase&&(t=t&&s>1,this._baseLayersList.style.display=t?"":"none"),this._separator.style.display=e&&t?"":"none",this},_onLayerChange:function(t){this._handlingClick||this._update();var e=this._getLayer(o.stamp(t.target)),i=e.overlay?"add"===t.type?"overlayadd":"overlayremove":"add"===t.type?"baselayerchange":null;i&&this._map.fire(i,e)},_createRadioElement:function(t,i){var n='<input type="radio" class="leaflet-control-layers-selector" name="'+t+'"'+(i?' checked="checked"':"")+"/>",o=e.createElement("div");return o.innerHTML=n,o.firstChild},_addItem:function(t){var i,n=e.createElement("label"),s=this._map.hasLayer(t.layer);t.overlay?(i=e.createElement("input"),i.type="checkbox",i.className="leaflet-control-layers-selector",i.defaultChecked=s):i=this._createRadioElement("leaflet-base-layers",s),i.layerId=o.stamp(t.layer),o.DomEvent.on(i,"click",this._onInputClick,this);var r=e.createElement("span");r.innerHTML=" "+t.name;var a=e.createElement("div");n.appendChild(a),a.appendChild(i),a.appendChild(r);var h=t.overlay?this._overlaysList:this._baseLayersList;return h.appendChild(n),this._checkDisabledLayers(),n},_onInputClick:function(){var t,e,i,n=this._form.getElementsByTagName("input"),o=[],s=[];this._handlingClick=!0;for(var r=n.length-1;r>=0;r--)t=n[r],e=this._getLayer(t.layerId).layer,i=this._map.hasLayer(e),t.checked&&!i?o.push(e):!t.checked&&i&&s.push(e);for(r=0;r<s.length;r++)this._map.removeLayer(s[r]);for(r=0;r<o.length;r++)this._map.addLayer(o[r]);this._handlingClick=!1,this._refocusOnMap()},_checkDisabledLayers:function(){for(var t,e,n=this._form.getElementsByTagName("input"),o=this._map.getZoom(),s=n.length-1;s>=0;s--)t=n[s],e=this._getLayer(t.layerId).layer,t.disabled=e.options.minZoom!==i&&o<e.options.minZoom||e.options.maxZoom!==i&&o>e.options.maxZoom},_expand:function(){return this.expand()},_collapse:function(){return this.collapse()}}),o.control.layers=function(t,e,i){return new o.Control.Layers(t,e,i)},o.PosAnimation=o.Evented.extend({run:function(t,e,i,n){this.stop(),this._el=t,this._inProgress=!0,this._duration=i||.25,this._easeOutPower=1/Math.max(n||.5,.2),this._startPos=o.DomUtil.getPosition(t),this._offset=e.subtract(this._startPos),this._startTime=+new Date,this.fire("start"),this._animate()},stop:function(){this._inProgress&&(this._step(!0),this._complete())},_animate:function(){this._animId=o.Util.requestAnimFrame(this._animate,this),this._step()},_step:function(t){var e=+new Date-this._startTime,i=1e3*this._duration;e<i?this._runFrame(this._easeOut(e/i),t):(this._runFrame(1),this._complete())},_runFrame:function(t,e){var i=this._startPos.add(this._offset.multiplyBy(t));e&&i._round(),o.DomUtil.setPosition(this._el,i),this.fire("step")},_complete:function(){o.Util.cancelAnimFrame(this._animId),this._inProgress=!1,this.fire("end")},_easeOut:function(t){return 1-Math.pow(1-t,this._easeOutPower)}}),o.Map.include({setView:function(t,e,n){if(e=e===i?this._zoom:this._limitZoom(e),t=this._limitCenter(o.latLng(t),e,this.options.maxBounds),n=n||{},this._stop(),this._loaded&&!n.reset&&n!==!0){n.animate!==i&&(n.zoom=o.extend({animate:n.animate},n.zoom),n.pan=o.extend({animate:n.animate,duration:n.duration},n.pan));var s=this._zoom!==e?this._tryAnimatedZoom&&this._tryAnimatedZoom(t,e,n.zoom):this._tryAnimatedPan(t,n.pan);if(s)return clearTimeout(this._sizeTimer),this}return this._resetView(t,e),this},panBy:function(t,e){if(t=o.point(t).round(),e=e||{},!t.x&&!t.y)return this.fire("moveend");if(e.animate!==!0&&!this.getSize().contains(t))return this._resetView(this.unproject(this.project(this.getCenter()).add(t)),this.getZoom()),this;if(this._panAnim||(this._panAnim=new o.PosAnimation,this._panAnim.on({step:this._onPanTransitionStep,end:this._onPanTransitionEnd},this)),e.noMoveStart||this.fire("movestart"),e.animate!==!1){o.DomUtil.addClass(this._mapPane,"leaflet-pan-anim");var i=this._getMapPanePos().subtract(t).round();this._panAnim.run(this._mapPane,i,e.duration||.25,e.easeLinearity)}else this._rawPanBy(t),this.fire("move").fire("moveend");return this},_onPanTransitionStep:function(){this.fire("move")},_onPanTransitionEnd:function(){o.DomUtil.removeClass(this._mapPane,"leaflet-pan-anim"),this.fire("moveend")},_tryAnimatedPan:function(t,e){var i=this._getCenterOffset(t)._floor();return!((e&&e.animate)!==!0&&!this.getSize().contains(i))&&(this.panBy(i,e),!0)}}),o.Map.mergeOptions({zoomAnimation:!0,zoomAnimationThreshold:4});var h=o.DomUtil.TRANSITION&&o.Browser.any3d&&!o.Browser.mobileOpera;h&&o.Map.addInitHook(function(){this._zoomAnimated=this.options.zoomAnimation,this._zoomAnimated&&(this._createAnimProxy(),o.DomEvent.on(this._proxy,o.DomUtil.TRANSITION_END,this._catchTransitionEnd,this))}),o.Map.include(h?{_createAnimProxy:function(){var t=this._proxy=o.DomUtil.create("div","leaflet-proxy leaflet-zoom-animated");this._panes.mapPane.appendChild(t),this.on("zoomanim",function(e){var i=o.DomUtil.TRANSFORM,n=t.style[i];o.DomUtil.setTransform(t,this.project(e.center,e.zoom),this.getZoomScale(e.zoom,1)),n===t.style[i]&&this._animatingZoom&&this._onZoomTransitionEnd()},this),this.on("load moveend",function(){var e=this.getCenter(),i=this.getZoom();o.DomUtil.setTransform(t,this.project(e,i),this.getZoomScale(i,1))},this)},_catchTransitionEnd:function(t){this._animatingZoom&&t.propertyName.indexOf("transform")>=0&&this._onZoomTransitionEnd()},_nothingToAnimate:function(){return!this._container.getElementsByClassName("leaflet-zoom-animated").length},_tryAnimatedZoom:function(t,e,i){if(this._animatingZoom)return!0;if(i=i||{},!this._zoomAnimated||i.animate===!1||this._nothingToAnimate()||Math.abs(e-this._zoom)>this.options.zoomAnimationThreshold)return!1;var n=this.getZoomScale(e),s=this._getCenterOffset(t)._divideBy(1-1/n);return!(i.animate!==!0&&!this.getSize().contains(s))&&(o.Util.requestAnimFrame(function(){this._moveStart(!0)._animateZoom(t,e,!0)},this),!0)},_animateZoom:function(t,e,i,n){i&&(this._animatingZoom=!0,this._animateToCenter=t,this._animateToZoom=e,o.DomUtil.addClass(this._mapPane,"leaflet-zoom-anim")),this.fire("zoomanim",{center:t,zoom:e,noUpdate:n}),setTimeout(o.bind(this._onZoomTransitionEnd,this),250)},_onZoomTransitionEnd:function(){this._animatingZoom&&(o.DomUtil.removeClass(this._mapPane,"leaflet-zoom-anim"),this._animatingZoom=!1,this._move(this._animateToCenter,this._animateToZoom),o.Util.requestAnimFrame(function(){this._moveEnd(!0)},this))}}:{}),o.Map.include({flyTo:function(t,e,n){function s(t){var e=t?-1:1,i=t?v:g,n=v*v-g*g+e*L*L*y*y,o=2*i*L*y,s=n/o,r=Math.sqrt(s*s+1)-s,a=r<1e-9?-18:Math.log(r);return a}function r(t){return(Math.exp(t)-Math.exp(-t))/2}function a(t){return(Math.exp(t)+Math.exp(-t))/2}function h(t){return r(t)/a(t)}function l(t){return g*(a(x)/a(x+P*t))}function u(t){return g*(a(x)*h(x+P*t)-r(x))/L}function c(t){return 1-Math.pow(1-t,1.5)}function d(){var i=(Date.now()-b)/T,n=c(i)*w;i<=1?(this._flyToFrame=o.Util.requestAnimFrame(d,this),this._move(this.unproject(_.add(m.subtract(_).multiplyBy(u(n)/y)),f),this.getScaleZoom(g/l(n),f),{flyTo:!0})):this._move(t,e)._moveEnd(!0)}if(n=n||{},n.animate===!1||!o.Browser.any3d)return this.setView(t,e,n);this._stop();var _=this.project(this.getCenter()),m=this.project(t),p=this.getSize(),f=this._zoom;t=o.latLng(t),e=e===i?f:e;var g=Math.max(p.x,p.y),v=g*this.getZoomScale(f,e),y=m.distanceTo(_)||1,P=1.42,L=P*P,x=s(0),b=Date.now(),w=(s(1)-x)/P,T=n.duration?1e3*n.duration:1e3*w*.8;return this._moveStart(!0),d.call(this),this},flyToBounds:function(t,e){var i=this._getBoundsCenterZoom(t,e);return this.flyTo(i.center,i.zoom,e)}}),o.Map.include({_defaultLocateOptions:{timeout:1e4,watch:!1},locate:function(t){if(t=this._locateOptions=o.extend({},this._defaultLocateOptions,t),!("geolocation"in navigator))return this._handleGeolocationError({code:0,message:"Geolocation not supported."}),this;var e=o.bind(this._handleGeolocationResponse,this),i=o.bind(this._handleGeolocationError,this);return t.watch?this._locationWatchId=navigator.geolocation.watchPosition(e,i,t):navigator.geolocation.getCurrentPosition(e,i,t),this},stopLocate:function(){return navigator.geolocation&&navigator.geolocation.clearWatch&&navigator.geolocation.clearWatch(this._locationWatchId),this._locateOptions&&(this._locateOptions.setView=!1),this},_handleGeolocationError:function(t){var e=t.code,i=t.message||(1===e?"permission denied":2===e?"position unavailable":"timeout");this._locateOptions.setView&&!this._loaded&&this.fitWorld(),this.fire("locationerror",{code:e,message:"Geolocation error: "+i+"."})},_handleGeolocationResponse:function(t){var e=t.coords.latitude,i=t.coords.longitude,n=new o.LatLng(e,i),s=n.toBounds(t.coords.accuracy),r=this._locateOptions;if(r.setView){var a=this.getBoundsZoom(s);this.setView(n,r.maxZoom?Math.min(a,r.maxZoom):a)}var h={latlng:n,bounds:s,timestamp:t.timestamp};for(var l in t.coords)"number"==typeof t.coords[l]&&(h[l]=t.coords[l]);this.fire("locationfound",h)}})}(window,document);
 /*
  Leaflet.markercluster, Provides Beautiful Animated Marker Clustering functionality for Leaflet, a JS library for interactive maps.
  https://github.com/Leaflet/Leaflet.markercluster
  (c) 2012-2013, Dave Leaver, smartrak
 */
 (function (window, document, undefined) {/*
  * L.MarkerClusterGroup extends L.FeatureGroup by clustering the markers contained within
  */
 
 L.MarkerClusterGroup = L.FeatureGroup.extend({
 
     options: {
         maxClusterRadius: 80, //A cluster will cover at most this many pixels from its center
         iconCreateFunction: null,
 
         spiderfyOnMaxZoom: true,
         showCoverageOnHover: true,
         zoomToBoundsOnClick: true,
         singleMarkerMode: false,
 
         disableClusteringAtZoom: null,
 
         // Setting this to false prevents the removal of any clusters outside of the viewpoint, which
         // is the default behaviour for performance reasons.
         removeOutsideVisibleBounds: true,
 
         // Set to false to disable all animations (zoom and spiderfy).
         // If false, option animateAddingMarkers below has no effect.
         // If L.DomUtil.TRANSITION is falsy, this option has no effect.
         animate: true,
 
         //Whether to animate adding markers after adding the MarkerClusterGroup to the map
         // If you are adding individual markers set to true, if adding bulk markers leave false for massive performance gains.
         animateAddingMarkers: false,
 
         //Increase to increase the distance away that spiderfied markers appear from the center
         spiderfyDistanceMultiplier: 1,
 
         // Make it possible to specify a polyline options on a spider leg
         spiderLegPolylineOptions: { weight: 1.5, color: '#222', opacity: 0.5 },
 
         // When bulk adding layers, adds markers in chunks. Means addLayers may not add all the layers in the call, others will be loaded during setTimeouts
         chunkedLoading: false,
         chunkInterval: 200, // process markers for a maximum of ~ n milliseconds (then trigger the chunkProgress callback)
         chunkDelay: 50, // at the end of each interval, give n milliseconds back to system/browser
         chunkProgress: null, // progress callback: function(processed, total, elapsed) (e.g. for a progress indicator)
 
         //Options to pass to the L.Polygon constructor
         polygonOptions: {}
     },
 
     initialize: function (options) {
         L.Util.setOptions(this, options);
         if (!this.options.iconCreateFunction) {
             this.options.iconCreateFunction = this._defaultIconCreateFunction;
         }
 
         this._featureGroup = L.featureGroup();
         this._featureGroup.addEventParent(this);
 
         this._nonPointGroup = L.featureGroup();
         this._nonPointGroup.addEventParent(this);
 
         this._inZoomAnimation = 0;
         this._needsClustering = [];
         this._needsRemoving = []; //Markers removed while we aren't on the map need to be kept track of
         //The bounds of the currently shown area (from _getExpandedVisibleBounds) Updated on zoom/move
         this._currentShownBounds = null;
 
         this._queue = [];
 
         // Hook the appropriate animation methods.
         var animate = L.DomUtil.TRANSITION && this.options.animate;
         L.extend(this, animate ? this._withAnimation : this._noAnimation);
         // Remember which MarkerCluster class to instantiate (animated or not).
         this._markerCluster = animate ? L.MarkerCluster : L.MarkerClusterNonAnimated;
     },
 
     addLayer: function (layer) {
 
         if (layer instanceof L.LayerGroup) {
             return this.addLayers([layer]);
         }
 
         //Don't cluster non point data
         if (!layer.getLatLng) {
             this._nonPointGroup.addLayer(layer);
             return this;
         }
 
         if (!this._map) {
             this._needsClustering.push(layer);
             return this;
         }
 
         if (this.hasLayer(layer)) {
             return this;
         }
 
 
         //If we have already clustered we'll need to add this one to a cluster
 
         if (this._unspiderfy) {
             this._unspiderfy();
         }
 
         this._addLayer(layer, this._maxZoom);
 
         // Refresh bounds and weighted positions.
         this._topClusterLevel._recalculateBounds();
 
         //Work out what is visible
         var visibleLayer = layer,
             currentZoom = this._map.getZoom();
         if (layer.__parent) {
             while (visibleLayer.__parent._zoom >= currentZoom) {
                 visibleLayer = visibleLayer.__parent;
             }
         }
 
         if (this._currentShownBounds.contains(visibleLayer.getLatLng())) {
             if (this.options.animateAddingMarkers) {
                 this._animationAddLayer(layer, visibleLayer);
             } else {
                 this._animationAddLayerNonAnimated(layer, visibleLayer);
             }
         }
         return this;
     },
 
     removeLayer: function (layer) {
 
         if (layer instanceof L.LayerGroup) {
             return this.removeLayers([layer]);
         }
 
         //Non point layers
         if (!layer.getLatLng) {
             this._nonPointGroup.removeLayer(layer);
             return this;
         }
 
         if (!this._map) {
             if (!this._arraySplice(this._needsClustering, layer) && this.hasLayer(layer)) {
                 this._needsRemoving.push(layer);
             }
             return this;
         }
 
         if (!layer.__parent) {
             return this;
         }
 
         if (this._unspiderfy) {
             this._unspiderfy();
             this._unspiderfyLayer(layer);
         }
 
         //Remove the marker from clusters
         this._removeLayer(layer, true);
 
         // Refresh bounds and weighted positions.
         this._topClusterLevel._recalculateBounds();
 
         layer.off('move', this._childMarkerMoved, this);
 
         if (this._featureGroup.hasLayer(layer)) {
             this._featureGroup.removeLayer(layer);
             if (layer.clusterShow) {
                 layer.clusterShow();
             }
         }
 
         return this;
     },
 
     //Takes an array of markers and adds them in bulk
     addLayers: function (layersArray) {
         if (!L.Util.isArray(layersArray)) {
             return this.addLayer(layersArray);
         }
 
         var fg = this._featureGroup,
             npg = this._nonPointGroup,
             chunked = this.options.chunkedLoading,
             chunkInterval = this.options.chunkInterval,
             chunkProgress = this.options.chunkProgress,
             l = layersArray.length,
             offset = 0,
             originalArray = true,
             m;
 
         if (this._map) {
             var started = (new Date()).getTime();
             var process = L.bind(function () {
                 var start = (new Date()).getTime();
                 for (; offset < l; offset++) {
                     if (chunked && offset % 200 === 0) {
                         // every couple hundred markers, instrument the time elapsed since processing started:
                         var elapsed = (new Date()).getTime() - start;
                         if (elapsed > chunkInterval) {
                             break; // been working too hard, time to take a break :-)
                         }
                     }
 
                     m = layersArray[offset];
 
                     // Group of layers, append children to layersArray and skip.
                     // Side effects:
                     // - Total increases, so chunkProgress ratio jumps backward.
                     // - Groups are not included in this group, only their non-group child layers (hasLayer).
                     // Changing array length while looping does not affect performance in current browsers:
                     // http://jsperf.com/for-loop-changing-length/6
                     if (m instanceof L.LayerGroup) {
                         if (originalArray) {
                             layersArray = layersArray.slice();
                             originalArray = false;
                         }
                         this._extractNonGroupLayers(m, layersArray);
                         l = layersArray.length;
                         continue;
                     }
 
                     //Not point data, can't be clustered
                     if (!m.getLatLng) {
                         npg.addLayer(m);
                         continue;
                     }
 
                     if (this.hasLayer(m)) {
                         continue;
                     }
 
                     this._addLayer(m, this._maxZoom);
 
                     //If we just made a cluster of size 2 then we need to remove the other marker from the map (if it is) or we never will
                     if (m.__parent) {
                         if (m.__parent.getChildCount() === 2) {
                             var markers = m.__parent.getAllChildMarkers(),
                                 otherMarker = markers[0] === m ? markers[1] : markers[0];
                             fg.removeLayer(otherMarker);
                         }
                     }
                 }
 
                 if (chunkProgress) {
                     // report progress and time elapsed:
                     chunkProgress(offset, l, (new Date()).getTime() - started);
                 }
 
                 // Completed processing all markers.
                 if (offset === l) {
 
                     // Refresh bounds and weighted positions.
                     this._topClusterLevel._recalculateBounds();
 
                     //Update the icons of all those visible clusters that were affected
                     this._featureGroup.eachLayer(function (c) {
                         if (c instanceof L.MarkerCluster && c._iconNeedsUpdate) {
                             c._updateIcon();
                         }
                     });
 
                     this._topClusterLevel._recursivelyAddChildrenToMap(null, this._zoom, this._currentShownBounds);
                 } else {
                     setTimeout(process, this.options.chunkDelay);
                 }
             }, this);
 
             process();
         } else {
             var needsClustering = this._needsClustering;
 
             for (; offset < l; offset++) {
                 m = layersArray[offset];
 
                 // Group of layers, append children to layersArray and skip.
                 if (m instanceof L.LayerGroup) {
                     if (originalArray) {
                         layersArray = layersArray.slice();
                         originalArray = false;
                     }
                     this._extractNonGroupLayers(m, layersArray);
                     l = layersArray.length;
                     continue;
                 }
 
                 //Not point data, can't be clustered
                 if (!m.getLatLng) {
                     npg.addLayer(m);
                     continue;
                 }
 
                 if (this.hasLayer(m)) {
                     continue;
                 }
 
                 needsClustering.push(m);
             }
         }
         return this;
     },
 
     //Takes an array of markers and removes them in bulk
     removeLayers: function (layersArray) {
         var i, m,
             l = layersArray.length,
             fg = this._featureGroup,
             npg = this._nonPointGroup,
             originalArray = true;
 
         if (!this._map) {
             for (i = 0; i < l; i++) {
                 m = layersArray[i];
 
                 // Group of layers, append children to layersArray and skip.
                 if (m instanceof L.LayerGroup) {
                     if (originalArray) {
                         layersArray = layersArray.slice();
                         originalArray = false;
                     }
                     this._extractNonGroupLayers(m, layersArray);
                     l = layersArray.length;
                     continue;
                 }
 
                 this._arraySplice(this._needsClustering, m);
                 npg.removeLayer(m);
                 if (this.hasLayer(m)) {
                     this._needsRemoving.push(m);
                 }
             }
             return this;
         }
 
         if (this._unspiderfy) {
             this._unspiderfy();
 
             // Work on a copy of the array, so that next loop is not affected.
             var layersArray2 = layersArray.slice(),
                 l2 = l;
             for (i = 0; i < l2; i++) {
                 m = layersArray2[i];
 
                 // Group of layers, append children to layersArray and skip.
                 if (m instanceof L.LayerGroup) {
                     this._extractNonGroupLayers(m, layersArray2);
                     l2 = layersArray2.length;
                     continue;
                 }
 
                 this._unspiderfyLayer(m);
             }
         }
 
         for (i = 0; i < l; i++) {
             m = layersArray[i];
 
             // Group of layers, append children to layersArray and skip.
             if (m instanceof L.LayerGroup) {
                 if (originalArray) {
                     layersArray = layersArray.slice();
                     originalArray = false;
                 }
                 this._extractNonGroupLayers(m, layersArray);
                 l = layersArray.length;
                 continue;
             }
 
             if (!m.__parent) {
                 npg.removeLayer(m);
                 continue;
             }
 
             this._removeLayer(m, true, true);
 
             if (fg.hasLayer(m)) {
                 fg.removeLayer(m);
                 if (m.clusterShow) {
                     m.clusterShow();
                 }
             }
         }
 
         // Refresh bounds and weighted positions.
         this._topClusterLevel._recalculateBounds();
 
         //Fix up the clusters and markers on the map
         this._topClusterLevel._recursivelyAddChildrenToMap(null, this._zoom, this._currentShownBounds);
 
         fg.eachLayer(function (c) {
             if (c instanceof L.MarkerCluster) {
                 c._updateIcon();
             }
         });
 
         return this;
     },
 
     //Removes all layers from the MarkerClusterGroup
     clearLayers: function () {
         //Need our own special implementation as the LayerGroup one doesn't work for us
 
         //If we aren't on the map (yet), blow away the markers we know of
         if (!this._map) {
             this._needsClustering = [];
             delete this._gridClusters;
             delete this._gridUnclustered;
         }
 
         if (this._noanimationUnspiderfy) {
             this._noanimationUnspiderfy();
         }
 
         //Remove all the visible layers
         this._featureGroup.clearLayers();
         this._nonPointGroup.clearLayers();
 
         this.eachLayer(function (marker) {
             marker.off('move', this._childMarkerMoved, this);
             delete marker.__parent;
         });
 
         if (this._map) {
             //Reset _topClusterLevel and the DistanceGrids
             this._generateInitialClusters();
         }
 
         return this;
     },
 
     //Override FeatureGroup.getBounds as it doesn't work
     getBounds: function () {
         var bounds = new L.LatLngBounds();
 
         if (this._topClusterLevel) {
             bounds.extend(this._topClusterLevel._bounds);
         }
 
         for (var i = this._needsClustering.length - 1; i >= 0; i--) {
             bounds.extend(this._needsClustering[i].getLatLng());
         }
 
         bounds.extend(this._nonPointGroup.getBounds());
 
         return bounds;
     },
 
     //Overrides LayerGroup.eachLayer
     eachLayer: function (method, context) {
         var markers = this._needsClustering.slice(),
             needsRemoving = this._needsRemoving,
             i;
 
         if (this._topClusterLevel) {
             this._topClusterLevel.getAllChildMarkers(markers);
         }
 
         for (i = markers.length - 1; i >= 0; i--) {
             if (needsRemoving.indexOf(markers[i]) === -1) {
                 method.call(context, markers[i]);
             }
         }
 
         this._nonPointGroup.eachLayer(method, context);
     },
 
     //Overrides LayerGroup.getLayers
     getLayers: function () {
         var layers = [];
         this.eachLayer(function (l) {
             layers.push(l);
         });
         return layers;
     },
 
     //Overrides LayerGroup.getLayer, WARNING: Really bad performance
     getLayer: function (id) {
         var result = null;
         
         id = parseInt(id, 10);
 
         this.eachLayer(function (l) {
             if (L.stamp(l) === id) {
                 result = l;
             }
         });
 
         return result;
     },
 
     //Returns true if the given layer is in this MarkerClusterGroup
     hasLayer: function (layer) {
         if (!layer) {
             return false;
         }
 
         var i, anArray = this._needsClustering;
 
         for (i = anArray.length - 1; i >= 0; i--) {
             if (anArray[i] === layer) {
                 return true;
             }
         }
 
         anArray = this._needsRemoving;
         for (i = anArray.length - 1; i >= 0; i--) {
             if (anArray[i] === layer) {
                 return false;
             }
         }
 
         return !!(layer.__parent && layer.__parent._group === this) || this._nonPointGroup.hasLayer(layer);
     },
 
     //Zoom down to show the given layer (spiderfying if necessary) then calls the callback
     zoomToShowLayer: function (layer, callback) {
         
         if (typeof callback !== 'function') {
             callback = function () {};
         }
 
         var showMarker = function () {
             if ((layer._icon || layer.__parent._icon) && !this._inZoomAnimation) {
                 this._map.off('moveend', showMarker, this);
                 this.off('animationend', showMarker, this);
 
                 if (layer._icon) {
                     callback();
                 } else if (layer.__parent._icon) {
                     this.once('spiderfied', callback, this);
                     layer.__parent.spiderfy();
                 }
             }
         };
 
         if (layer._icon && this._map.getBounds().contains(layer.getLatLng())) {
             //Layer is visible ond on screen, immediate return
             callback();
         } else if (layer.__parent._zoom < this._map.getZoom()) {
             //Layer should be visible at this zoom level. It must not be on screen so just pan over to it
             this._map.on('moveend', showMarker, this);
             this._map.panTo(layer.getLatLng());
         } else {
             var moveStart = function () {
                 this._map.off('movestart', moveStart, this);
                 moveStart = null;
             };
 
             this._map.on('movestart', moveStart, this);
             this._map.on('moveend', showMarker, this);
             this.on('animationend', showMarker, this);
             layer.__parent.zoomToBounds();
 
             if (moveStart) {
                 //Never started moving, must already be there, probably need clustering however
                 showMarker.call(this);
             }
         }
     },
 
     //Overrides FeatureGroup.onAdd
     onAdd: function (map) {
         this._map = map;
         var i, l, layer;
 
         if (!isFinite(this._map.getMaxZoom())) {
             throw "Map has no maxZoom specified";
         }
 
         this._featureGroup.addTo(map);
         this._nonPointGroup.addTo(map);
 
         if (!this._gridClusters) {
             this._generateInitialClusters();
         }
 
         this._maxLat = map.options.crs.projection.MAX_LATITUDE;
 
         for (i = 0, l = this._needsRemoving.length; i < l; i++) {
             layer = this._needsRemoving[i];
             this._removeLayer(layer, true);
         }
         this._needsRemoving = [];
 
         //Remember the current zoom level and bounds
         this._zoom = this._map.getZoom();
         this._currentShownBounds = this._getExpandedVisibleBounds();
 
         this._map.on('zoomend', this._zoomEnd, this);
         this._map.on('moveend', this._moveEnd, this);
 
         if (this._spiderfierOnAdd) { //TODO FIXME: Not sure how to have spiderfier add something on here nicely
             this._spiderfierOnAdd();
         }
 
         this._bindEvents();
 
         //Actually add our markers to the map:
         l = this._needsClustering;
         this._needsClustering = [];
         this.addLayers(l);
     },
 
     //Overrides FeatureGroup.onRemove
     onRemove: function (map) {
         map.off('zoomend', this._zoomEnd, this);
         map.off('moveend', this._moveEnd, this);
 
         this._unbindEvents();
 
         //In case we are in a cluster animation
         this._map._mapPane.className = this._map._mapPane.className.replace(' leaflet-cluster-anim', '');
 
         if (this._spiderfierOnRemove) { //TODO FIXME: Not sure how to have spiderfier add something on here nicely
             this._spiderfierOnRemove();
         }
 
         delete this._maxLat;
 
         //Clean up all the layers we added to the map
         this._hideCoverage();
         this._featureGroup.remove();
         this._nonPointGroup.remove();
 
         this._featureGroup.clearLayers();
 
         this._map = null;
     },
 
     getVisibleParent: function (marker) {
         var vMarker = marker;
         while (vMarker && !vMarker._icon) {
             vMarker = vMarker.__parent;
         }
         return vMarker || null;
     },
 
     //Remove the given object from the given array
     _arraySplice: function (anArray, obj) {
         for (var i = anArray.length - 1; i >= 0; i--) {
             if (anArray[i] === obj) {
                 anArray.splice(i, 1);
                 return true;
             }
         }
     },
 
     /**
      * Removes a marker from all _gridUnclustered zoom levels, starting at the supplied zoom.
      * @param marker to be removed from _gridUnclustered.
      * @param z integer bottom start zoom level (included)
      * @private
      */
     _removeFromGridUnclustered: function (marker, z) {
         var map             = this._map,
             gridUnclustered = this._gridUnclustered;
 
         for (; z >= 0; z--) {
             if (!gridUnclustered[z].removeObject(marker, map.project(marker.getLatLng(), z))) {
                 break;
             }
         }
     },
 
     _childMarkerMoved: function (e) {
         if (!this._ignoreMove) {
             e.target._latlng = e.oldLatLng;
             this.removeLayer(e.target);
 
             e.target._latlng = e.latlng;
             this.addLayer(e.target);
         }
     },
 
     //Internal function for removing a marker from everything.
     //dontUpdateMap: set to true if you will handle updating the map manually (for bulk functions)
     _removeLayer: function (marker, removeFromDistanceGrid, dontUpdateMap) {
         var gridClusters = this._gridClusters,
             gridUnclustered = this._gridUnclustered,
             fg = this._featureGroup,
             map = this._map;
 
         //Remove the marker from distance clusters it might be in
         if (removeFromDistanceGrid) {
             this._removeFromGridUnclustered(marker, this._maxZoom);
         }
 
         //Work our way up the clusters removing them as we go if required
         var cluster = marker.__parent,
             markers = cluster._markers,
             otherMarker;
 
         //Remove the marker from the immediate parents marker list
         this._arraySplice(markers, marker);
 
         while (cluster) {
             cluster._childCount--;
             cluster._boundsNeedUpdate = true;
 
             if (cluster._zoom < 0) {
                 //Top level, do nothing
                 break;
             } else if (removeFromDistanceGrid && cluster._childCount <= 1) { //Cluster no longer required
                 //We need to push the other marker up to the parent
                 otherMarker = cluster._markers[0] === marker ? cluster._markers[1] : cluster._markers[0];
 
                 //Update distance grid
                 gridClusters[cluster._zoom].removeObject(cluster, map.project(cluster._cLatLng, cluster._zoom));
                 gridUnclustered[cluster._zoom].addObject(otherMarker, map.project(otherMarker.getLatLng(), cluster._zoom));
 
                 //Move otherMarker up to parent
                 this._arraySplice(cluster.__parent._childClusters, cluster);
                 cluster.__parent._markers.push(otherMarker);
                 otherMarker.__parent = cluster.__parent;
 
                 if (cluster._icon) {
                     //Cluster is currently on the map, need to put the marker on the map instead
                     fg.removeLayer(cluster);
                     if (!dontUpdateMap) {
                         fg.addLayer(otherMarker);
                     }
                 }
             } else {
                 if (!dontUpdateMap || !cluster._icon) {
                     cluster._updateIcon();
                 }
             }
 
             cluster = cluster.__parent;
         }
 
         delete marker.__parent;
     },
 
     _isOrIsParent: function (el, oel) {
         while (oel) {
             if (el === oel) {
                 return true;
             }
             oel = oel.parentNode;
         }
         return false;
     },
 
     //Override L.Evented.fire
     fire: function (type, data, propagate) {
         if (data && data.layer instanceof L.MarkerCluster) {
             //Prevent multiple clustermouseover/off events if the icon is made up of stacked divs (Doesn't work in ie <= 8, no relatedTarget)
             if (data.originalEvent && this._isOrIsParent(data.layer._icon, data.originalEvent.relatedTarget)) {
                 return;
             }
             type = 'cluster' + type;
         }
 
         L.FeatureGroup.prototype.fire.call(this, type, data, propagate);
     },
 
     //Override L.Evented.listens
     listens: function (type, propagate) {
         return L.FeatureGroup.prototype.listens.call(this, type, propagate) || L.FeatureGroup.prototype.listens.call(this, 'cluster' + type, propagate);
     },
 
     //Default functionality
     _defaultIconCreateFunction: function (cluster) {
         var childCount = cluster.getChildCount();
 
         var c = ' marker-cluster-';
         if (childCount < 10) {
             c += 'small';
         } else if (childCount < 100) {
             c += 'medium';
         } else {
             c += 'large';
         }
 
         return new L.DivIcon({ html: '<div><span>' + childCount + '</span></div>', className: 'marker-cluster' + c, iconSize: new L.Point(40, 40) });
     },
 
     _bindEvents: function () {
         var map = this._map,
             spiderfyOnMaxZoom = this.options.spiderfyOnMaxZoom,
             showCoverageOnHover = this.options.showCoverageOnHover,
             zoomToBoundsOnClick = this.options.zoomToBoundsOnClick;
 
         //Zoom on cluster click or spiderfy if we are at the lowest level
         if (spiderfyOnMaxZoom || zoomToBoundsOnClick) {
             this.on('clusterclick', this._zoomOrSpiderfy, this);
         }
 
         //Show convex hull (boundary) polygon on mouse over
         if (showCoverageOnHover) {
             this.on('clustermouseover', this._showCoverage, this);
             this.on('clustermouseout', this._hideCoverage, this);
             map.on('zoomend', this._hideCoverage, this);
         }
     },
 
     _zoomOrSpiderfy: function (e) {
         var cluster = e.layer,
             bottomCluster = cluster;
 
         while (bottomCluster._childClusters.length === 1) {
             bottomCluster = bottomCluster._childClusters[0];
         }
 
         if (bottomCluster._zoom === this._maxZoom &&
             bottomCluster._childCount === cluster._childCount &&
             this.options.spiderfyOnMaxZoom) {
 
             // All child markers are contained in a single cluster from this._maxZoom to this cluster.
             cluster.spiderfy();
         } else if (this.options.zoomToBoundsOnClick) {
             cluster.zoomToBounds();
         }
 
         // Focus the map again for keyboard users.
         if (e.originalEvent && e.originalEvent.keyCode === 13) {
             this._map._container.focus();
         }
     },
 
     _showCoverage: function (e) {
         var map = this._map;
         if (this._inZoomAnimation) {
             return;
         }
         if (this._shownPolygon) {
             map.removeLayer(this._shownPolygon);
         }
         if (e.layer.getChildCount() > 2 && e.layer !== this._spiderfied) {
             this._shownPolygon = new L.Polygon(e.layer.getConvexHull(), this.options.polygonOptions);
             map.addLayer(this._shownPolygon);
         }
     },
 
     _hideCoverage: function () {
         if (this._shownPolygon) {
             this._map.removeLayer(this._shownPolygon);
             this._shownPolygon = null;
         }
     },
 
     _unbindEvents: function () {
         var spiderfyOnMaxZoom = this.options.spiderfyOnMaxZoom,
             showCoverageOnHover = this.options.showCoverageOnHover,
             zoomToBoundsOnClick = this.options.zoomToBoundsOnClick,
             map = this._map;
 
         if (spiderfyOnMaxZoom || zoomToBoundsOnClick) {
             this.off('clusterclick', this._zoomOrSpiderfy, this);
         }
         if (showCoverageOnHover) {
             this.off('clustermouseover', this._showCoverage, this);
             this.off('clustermouseout', this._hideCoverage, this);
             map.off('zoomend', this._hideCoverage, this);
         }
     },
 
     _zoomEnd: function () {
         if (!this._map) { //May have been removed from the map by a zoomEnd handler
             return;
         }
         this._mergeSplitClusters();
 
         this._zoom = Math.round(this._map._zoom);
         this._currentShownBounds = this._getExpandedVisibleBounds();
     },
 
     _moveEnd: function () {
         if (this._inZoomAnimation) {
             return;
         }
 
         var newBounds = this._getExpandedVisibleBounds();
 
         this._topClusterLevel._recursivelyRemoveChildrenFromMap(this._currentShownBounds, this._zoom, newBounds);
         this._topClusterLevel._recursivelyAddChildrenToMap(null, Math.round(this._map._zoom), newBounds);
 
         this._currentShownBounds = newBounds;
         return;
     },
 
     _generateInitialClusters: function () {
         var maxZoom = this._map.getMaxZoom(),
             radius = this.options.maxClusterRadius,
             radiusFn = radius;
     
         //If we just set maxClusterRadius to a single number, we need to create
         //a simple function to return that number. Otherwise, we just have to
         //use the function we've passed in.
         if (typeof radius !== "function") {
             radiusFn = function () { return radius; };
         }
 
         if (this.options.disableClusteringAtZoom) {
             maxZoom = this.options.disableClusteringAtZoom - 1;
         }
         this._maxZoom = maxZoom;
         this._gridClusters = {};
         this._gridUnclustered = {};
     
         //Set up DistanceGrids for each zoom
         for (var zoom = maxZoom; zoom >= 0; zoom--) {
             this._gridClusters[zoom] = new L.DistanceGrid(radiusFn(zoom));
             this._gridUnclustered[zoom] = new L.DistanceGrid(radiusFn(zoom));
         }
 
         // Instantiate the appropriate L.MarkerCluster class (animated or not).
         this._topClusterLevel = new this._markerCluster(this, -1);
     },
 
     //Zoom: Zoom to start adding at (Pass this._maxZoom to start at the bottom)
     _addLayer: function (layer, zoom) {
         var gridClusters = this._gridClusters,
             gridUnclustered = this._gridUnclustered,
             markerPoint, z;
 
         if (this.options.singleMarkerMode) {
             this._overrideMarkerIcon(layer);
         }
 
         layer.on('move', this._childMarkerMoved, this);
 
         //Find the lowest zoom level to slot this one in
         for (; zoom >= 0; zoom--) {
             markerPoint = this._map.project(layer.getLatLng(), zoom); // calculate pixel position
 
             //Try find a cluster close by
             var closest = gridClusters[zoom].getNearObject(markerPoint);
             if (closest) {
                 closest._addChild(layer);
                 layer.__parent = closest;
                 return;
             }
 
             //Try find a marker close by to form a new cluster with
             closest = gridUnclustered[zoom].getNearObject(markerPoint);
             if (closest) {
                 var parent = closest.__parent;
                 if (parent) {
                     this._removeLayer(closest, false);
                 }
 
                 //Create new cluster with these 2 in it
 
                 var newCluster = new this._markerCluster(this, zoom, closest, layer);
                 gridClusters[zoom].addObject(newCluster, this._map.project(newCluster._cLatLng, zoom));
                 closest.__parent = newCluster;
                 layer.__parent = newCluster;
 
                 //First create any new intermediate parent clusters that don't exist
                 var lastParent = newCluster;
                 for (z = zoom - 1; z > parent._zoom; z--) {
                     lastParent = new this._markerCluster(this, z, lastParent);
                     gridClusters[z].addObject(lastParent, this._map.project(closest.getLatLng(), z));
                 }
                 parent._addChild(lastParent);
 
                 //Remove closest from this zoom level and any above that it is in, replace with newCluster
                 this._removeFromGridUnclustered(closest, zoom);
 
                 return;
             }
 
             //Didn't manage to cluster in at this zoom, record us as a marker here and continue upwards
             gridUnclustered[zoom].addObject(layer, markerPoint);
         }
 
         //Didn't get in anything, add us to the top
         this._topClusterLevel._addChild(layer);
         layer.__parent = this._topClusterLevel;
         return;
     },
 
     //Enqueue code to fire after the marker expand/contract has happened
     _enqueue: function (fn) {
         this._queue.push(fn);
         if (!this._queueTimeout) {
             this._queueTimeout = setTimeout(L.bind(this._processQueue, this), 300);
         }
     },
     _processQueue: function () {
         for (var i = 0; i < this._queue.length; i++) {
             this._queue[i].call(this);
         }
         this._queue.length = 0;
         clearTimeout(this._queueTimeout);
         this._queueTimeout = null;
     },
 
     //Merge and split any existing clusters that are too big or small
     _mergeSplitClusters: function () {
         var mapZoom = Math.round(this._map._zoom);
 
         //In case we are starting to split before the animation finished
         this._processQueue();
 
         if (this._zoom < mapZoom && this._currentShownBounds.intersects(this._getExpandedVisibleBounds())) { //Zoom in, split
             this._animationStart();
             //Remove clusters now off screen
             this._topClusterLevel._recursivelyRemoveChildrenFromMap(this._currentShownBounds, this._zoom, this._getExpandedVisibleBounds());
 
             this._animationZoomIn(this._zoom, mapZoom);
 
         } else if (this._zoom > mapZoom) { //Zoom out, merge
             this._animationStart();
 
             this._animationZoomOut(this._zoom, mapZoom);
         } else {
             this._moveEnd();
         }
     },
 
     //Gets the maps visible bounds expanded in each direction by the size of the screen (so the user cannot see an area we do not cover in one pan)
     _getExpandedVisibleBounds: function () {
         if (!this.options.removeOutsideVisibleBounds) {
             return this._mapBoundsInfinite;
         } else if (L.Browser.mobile) {
             return this._checkBoundsMaxLat(this._map.getBounds());
         }
 
         return this._checkBoundsMaxLat(this._map.getBounds().pad(1)); // Padding expands the bounds by its own dimensions but scaled with the given factor.
     },
 
     /**
      * Expands the latitude to Infinity (or -Infinity) if the input bounds reach the map projection maximum defined latitude
      * (in the case of Web/Spherical Mercator, it is 85.0511287798 / see https://en.wikipedia.org/wiki/Web_Mercator#Formulas).
      * Otherwise, the removeOutsideVisibleBounds option will remove markers beyond that limit, whereas the same markers without
      * this option (or outside MCG) will have their position floored (ceiled) by the projection and rendered at that limit,
      * making the user think that MCG "eats" them and never displays them again.
      * @param bounds L.LatLngBounds
      * @returns {L.LatLngBounds}
      * @private
      */
     _checkBoundsMaxLat: function (bounds) {
         var maxLat = this._maxLat;
 
         if (maxLat !== undefined) {
             if (bounds.getNorth() >= maxLat) {
                 bounds._northEast.lat = Infinity;
             }
             if (bounds.getSouth() <= -maxLat) {
                 bounds._southWest.lat = -Infinity;
             }
         }
 
         return bounds;
     },
 
     //Shared animation code
     _animationAddLayerNonAnimated: function (layer, newCluster) {
         if (newCluster === layer) {
             this._featureGroup.addLayer(layer);
         } else if (newCluster._childCount === 2) {
             newCluster._addToMap();
 
             var markers = newCluster.getAllChildMarkers();
             this._featureGroup.removeLayer(markers[0]);
             this._featureGroup.removeLayer(markers[1]);
         } else {
             newCluster._updateIcon();
         }
     },
 
     /**
      * Extracts individual (i.e. non-group) layers from a Layer Group.
      * @param group to extract layers from.
      * @param output {Array} in which to store the extracted layers.
      * @returns {*|Array}
      * @private
      */
     _extractNonGroupLayers: function (group, output) {
         var layers = group.getLayers(),
             i = 0,
             layer;
 
         output = output || [];
 
         for (; i < layers.length; i++) {
             layer = layers[i];
 
             if (layer instanceof L.LayerGroup) {
                 this._extractNonGroupLayers(layer, output);
                 continue;
             }
 
             output.push(layer);
         }
 
         return output;
     },
 
     /**
      * Implements the singleMarkerMode option.
      * @param layer Marker to re-style using the Clusters iconCreateFunction.
      * @returns {L.Icon} The newly created icon.
      * @private
      */
     _overrideMarkerIcon: function (layer) {
         var icon = layer.options.icon = this.options.iconCreateFunction({
             getChildCount: function () {
                 return 1;
             },
             getAllChildMarkers: function () {
                 return [layer];
             }
         });
 
         return icon;
     }
 });
 
 // Constant bounds used in case option "removeOutsideVisibleBounds" is set to false.
 L.MarkerClusterGroup.include({
     _mapBoundsInfinite: new L.LatLngBounds(new L.LatLng(-Infinity, -Infinity), new L.LatLng(Infinity, Infinity))
 });
 
 L.MarkerClusterGroup.include({
     _noAnimation: {
         //Non Animated versions of everything
         _animationStart: function () {
             //Do nothing...
         },
         _animationZoomIn: function (previousZoomLevel, newZoomLevel) {
             this._topClusterLevel._recursivelyRemoveChildrenFromMap(this._currentShownBounds, previousZoomLevel);
             this._topClusterLevel._recursivelyAddChildrenToMap(null, newZoomLevel, this._getExpandedVisibleBounds());
 
             //We didn't actually animate, but we use this event to mean "clustering animations have finished"
             this.fire('animationend');
         },
         _animationZoomOut: function (previousZoomLevel, newZoomLevel) {
             this._topClusterLevel._recursivelyRemoveChildrenFromMap(this._currentShownBounds, previousZoomLevel);
             this._topClusterLevel._recursivelyAddChildrenToMap(null, newZoomLevel, this._getExpandedVisibleBounds());
 
             //We didn't actually animate, but we use this event to mean "clustering animations have finished"
             this.fire('animationend');
         },
         _animationAddLayer: function (layer, newCluster) {
             this._animationAddLayerNonAnimated(layer, newCluster);
         }
     },
 
     _withAnimation: {
         //Animated versions here
         _animationStart: function () {
             this._map._mapPane.className += ' leaflet-cluster-anim';
             this._inZoomAnimation++;
         },
 
         _animationZoomIn: function (previousZoomLevel, newZoomLevel) {
             var bounds = this._getExpandedVisibleBounds(),
                 fg     = this._featureGroup,
                 i;
 
             this._ignoreMove = true;
 
             //Add all children of current clusters to map and remove those clusters from map
             this._topClusterLevel._recursively(bounds, previousZoomLevel, 0, function (c) {
                 var startPos = c._latlng,
                     markers  = c._markers,
                     m;
 
                 if (!bounds.contains(startPos)) {
                     startPos = null;
                 }
 
                 if (c._isSingleParent() && previousZoomLevel + 1 === newZoomLevel) { //Immediately add the new child and remove us
                     fg.removeLayer(c);
                     c._recursivelyAddChildrenToMap(null, newZoomLevel, bounds);
                 } else {
                     //Fade out old cluster
                     c.clusterHide();
                     c._recursivelyAddChildrenToMap(startPos, newZoomLevel, bounds);
                 }
 
                 //Remove all markers that aren't visible any more
                 //TODO: Do we actually need to do this on the higher levels too?
                 for (i = markers.length - 1; i >= 0; i--) {
                     m = markers[i];
                     if (!bounds.contains(m._latlng)) {
                         fg.removeLayer(m);
                     }
                 }
 
             });
 
             this._forceLayout();
 
             //Update opacities
             this._topClusterLevel._recursivelyBecomeVisible(bounds, newZoomLevel);
             //TODO Maybe? Update markers in _recursivelyBecomeVisible
             fg.eachLayer(function (n) {
                 if (!(n instanceof L.MarkerCluster) && n._icon) {
                     n.clusterShow();
                 }
             });
 
             //update the positions of the just added clusters/markers
             this._topClusterLevel._recursively(bounds, previousZoomLevel, newZoomLevel, function (c) {
                 c._recursivelyRestoreChildPositions(newZoomLevel);
             });
 
             this._ignoreMove = false;
 
             //Remove the old clusters and close the zoom animation
             this._enqueue(function () {
                 //update the positions of the just added clusters/markers
                 this._topClusterLevel._recursively(bounds, previousZoomLevel, 0, function (c) {
                     fg.removeLayer(c);
                     c.clusterShow();
                 });
 
                 this._animationEnd();
             });
         },
 
         _animationZoomOut: function (previousZoomLevel, newZoomLevel) {
             this._animationZoomOutSingle(this._topClusterLevel, previousZoomLevel - 1, newZoomLevel);
 
             //Need to add markers for those that weren't on the map before but are now
             this._topClusterLevel._recursivelyAddChildrenToMap(null, newZoomLevel, this._getExpandedVisibleBounds());
             //Remove markers that were on the map before but won't be now
             this._topClusterLevel._recursivelyRemoveChildrenFromMap(this._currentShownBounds, previousZoomLevel, this._getExpandedVisibleBounds());
         },
 
         _animationAddLayer: function (layer, newCluster) {
             var me = this,
                 fg = this._featureGroup;
 
             fg.addLayer(layer);
             if (newCluster !== layer) {
                 if (newCluster._childCount > 2) { //Was already a cluster
 
                     newCluster._updateIcon();
                     this._forceLayout();
                     this._animationStart();
 
                     layer._setPos(this._map.latLngToLayerPoint(newCluster.getLatLng()));
                     layer.clusterHide();
 
                     this._enqueue(function () {
                         fg.removeLayer(layer);
                         layer.clusterShow();
 
                         me._animationEnd();
                     });
 
                 } else { //Just became a cluster
                     this._forceLayout();
 
                     me._animationStart();
                     me._animationZoomOutSingle(newCluster, this._map.getMaxZoom(), this._map.getZoom());
                 }
             }
         }
     },
 
     // Private methods for animated versions.
     _animationZoomOutSingle: function (cluster, previousZoomLevel, newZoomLevel) {
         var bounds = this._getExpandedVisibleBounds();
 
         //Animate all of the markers in the clusters to move to their cluster center point
         cluster._recursivelyAnimateChildrenInAndAddSelfToMap(bounds, previousZoomLevel + 1, newZoomLevel);
 
         var me = this;
 
         //Update the opacity (If we immediately set it they won't animate)
         this._forceLayout();
         cluster._recursivelyBecomeVisible(bounds, newZoomLevel);
 
         //TODO: Maybe use the transition timing stuff to make this more reliable
         //When the animations are done, tidy up
         this._enqueue(function () {
 
             //This cluster stopped being a cluster before the timeout fired
             if (cluster._childCount === 1) {
                 var m = cluster._markers[0];
                 //If we were in a cluster animation at the time then the opacity and position of our child could be wrong now, so fix it
                 this._ignoreMove = true;
                 m.setLatLng(m.getLatLng());
                 this._ignoreMove = false;
                 if (m.clusterShow) {
                     m.clusterShow();
                 }
             } else {
                 cluster._recursively(bounds, newZoomLevel, 0, function (c) {
                     c._recursivelyRemoveChildrenFromMap(bounds, previousZoomLevel + 1);
                 });
             }
             me._animationEnd();
         });
     },
 
     _animationEnd: function () {
         if (this._map) {
             this._map._mapPane.className = this._map._mapPane.className.replace(' leaflet-cluster-anim', '');
         }
         this._inZoomAnimation--;
         this.fire('animationend');
     },
 
     //Force a browser layout of stuff in the map
     // Should apply the current opacity and location to all elements so we can update them again for an animation
     _forceLayout: function () {
         //In my testing this works, infact offsetWidth of any element seems to work.
         //Could loop all this._layers and do this for each _icon if it stops working
 
         L.Util.falseFn(document.body.offsetWidth);
     }
 });
 
 L.markerClusterGroup = function (options) {
     return new L.MarkerClusterGroup(options);
 };
 
 
 L.MarkerCluster = L.Marker.extend({
     initialize: function (group, zoom, a, b) {
 
         L.Marker.prototype.initialize.call(this, a ? (a._cLatLng || a.getLatLng()) : new L.LatLng(0, 0), { icon: this });
 
 
         this._group = group;
         this._zoom = zoom;
 
         this._markers = [];
         this._childClusters = [];
         this._childCount = 0;
         this._iconNeedsUpdate = true;
         this._boundsNeedUpdate = true;
 
         this._bounds = new L.LatLngBounds();
 
         if (a) {
             this._addChild(a);
         }
         if (b) {
             this._addChild(b);
         }
     },
 
     //Recursively retrieve all child markers of this cluster
     getAllChildMarkers: function (storageArray) {
         storageArray = storageArray || [];
 
         for (var i = this._childClusters.length - 1; i >= 0; i--) {
             this._childClusters[i].getAllChildMarkers(storageArray);
         }
 
         for (var j = this._markers.length - 1; j >= 0; j--) {
             storageArray.push(this._markers[j]);
         }
 
         return storageArray;
     },
 
     //Returns the count of how many child markers we have
     getChildCount: function () {
         return this._childCount;
     },
 
     //Zoom to the minimum of showing all of the child markers, or the extents of this cluster
     zoomToBounds: function () {
         var childClusters = this._childClusters.slice(),
             map = this._group._map,
             boundsZoom = map.getBoundsZoom(this._bounds),
             zoom = this._zoom + 1,
             mapZoom = map.getZoom(),
             i;
 
         //calculate how far we need to zoom down to see all of the markers
         while (childClusters.length > 0 && boundsZoom > zoom) {
             zoom++;
             var newClusters = [];
             for (i = 0; i < childClusters.length; i++) {
                 newClusters = newClusters.concat(childClusters[i]._childClusters);
             }
             childClusters = newClusters;
         }
 
         if (boundsZoom > zoom) {
             this._group._map.setView(this._latlng, zoom);
         } else if (boundsZoom <= mapZoom) { //If fitBounds wouldn't zoom us down, zoom us down instead
             this._group._map.setView(this._latlng, mapZoom + 1);
         } else {
             this._group._map.fitBounds(this._bounds);
         }
     },
 
     getBounds: function () {
         var bounds = new L.LatLngBounds();
         bounds.extend(this._bounds);
         return bounds;
     },
 
     _updateIcon: function () {
         this._iconNeedsUpdate = true;
         if (this._icon) {
             this.setIcon(this);
         }
     },
 
     //Cludge for Icon, we pretend to be an icon for performance
     createIcon: function () {
         if (this._iconNeedsUpdate) {
             this._iconObj = this._group.options.iconCreateFunction(this);
             this._iconNeedsUpdate = false;
         }
         return this._iconObj.createIcon();
     },
     createShadow: function () {
         return this._iconObj.createShadow();
     },
 
 
     _addChild: function (new1, isNotificationFromChild) {
 
         this._iconNeedsUpdate = true;
 
         this._boundsNeedUpdate = true;
         this._setClusterCenter(new1);
 
         if (new1 instanceof L.MarkerCluster) {
             if (!isNotificationFromChild) {
                 this._childClusters.push(new1);
                 new1.__parent = this;
             }
             this._childCount += new1._childCount;
         } else {
             if (!isNotificationFromChild) {
                 this._markers.push(new1);
             }
             this._childCount++;
         }
 
         if (this.__parent) {
             this.__parent._addChild(new1, true);
         }
     },
 
     /**
      * Makes sure the cluster center is set. If not, uses the child center if it is a cluster, or the marker position.
      * @param child L.MarkerCluster|L.Marker that will be used as cluster center if not defined yet.
      * @private
      */
     _setClusterCenter: function (child) {
         if (!this._cLatLng) {
             // when clustering, take position of the first point as the cluster center
             this._cLatLng = child._cLatLng || child._latlng;
         }
     },
 
     /**
      * Assigns impossible bounding values so that the next extend entirely determines the new bounds.
      * This method avoids having to trash the previous L.LatLngBounds object and to create a new one, which is much slower for this class.
      * As long as the bounds are not extended, most other methods would probably fail, as they would with bounds initialized but not extended.
      * @private
      */
     _resetBounds: function () {
         var bounds = this._bounds;
 
         if (bounds._southWest) {
             bounds._southWest.lat = Infinity;
             bounds._southWest.lng = Infinity;
         }
         if (bounds._northEast) {
             bounds._northEast.lat = -Infinity;
             bounds._northEast.lng = -Infinity;
         }
     },
 
     _recalculateBounds: function () {
         var markers = this._markers,
             childClusters = this._childClusters,
             latSum = 0,
             lngSum = 0,
             totalCount = this._childCount,
             i, child, childLatLng, childCount;
 
         // Case where all markers are removed from the map and we are left with just an empty _topClusterLevel.
         if (totalCount === 0) {
             return;
         }
 
         // Reset rather than creating a new object, for performance.
         this._resetBounds();
 
         // Child markers.
         for (i = 0; i < markers.length; i++) {
             childLatLng = markers[i]._latlng;
 
             this._bounds.extend(childLatLng);
 
             latSum += childLatLng.lat;
             lngSum += childLatLng.lng;
         }
 
         // Child clusters.
         for (i = 0; i < childClusters.length; i++) {
             child = childClusters[i];
 
             // Re-compute child bounds and weighted position first if necessary.
             if (child._boundsNeedUpdate) {
                 child._recalculateBounds();
             }
 
             this._bounds.extend(child._bounds);
 
             childLatLng = child._wLatLng;
             childCount = child._childCount;
 
             latSum += childLatLng.lat * childCount;
             lngSum += childLatLng.lng * childCount;
         }
 
         this._latlng = this._wLatLng = new L.LatLng(latSum / totalCount, lngSum / totalCount);
 
         // Reset dirty flag.
         this._boundsNeedUpdate = false;
     },
 
     //Set our markers position as given and add it to the map
     _addToMap: function (startPos) {
         if (startPos) {
             this._backupLatlng = this._latlng;
             this.setLatLng(startPos);
         }
         this._group._featureGroup.addLayer(this);
     },
 
     _recursivelyAnimateChildrenIn: function (bounds, center, maxZoom) {
         this._recursively(bounds, 0, maxZoom - 1,
             function (c) {
                 var markers = c._markers,
                     i, m;
                 for (i = markers.length - 1; i >= 0; i--) {
                     m = markers[i];
 
                     //Only do it if the icon is still on the map
                     if (m._icon) {
                         m._setPos(center);
                         m.clusterHide();
                     }
                 }
             },
             function (c) {
                 var childClusters = c._childClusters,
                     j, cm;
                 for (j = childClusters.length - 1; j >= 0; j--) {
                     cm = childClusters[j];
                     if (cm._icon) {
                         cm._setPos(center);
                         cm.clusterHide();
                     }
                 }
             }
         );
     },
 
     _recursivelyAnimateChildrenInAndAddSelfToMap: function (bounds, previousZoomLevel, newZoomLevel) {
         this._recursively(bounds, newZoomLevel, 0,
             function (c) {
                 c._recursivelyAnimateChildrenIn(bounds, c._group._map.latLngToLayerPoint(c.getLatLng()).round(), previousZoomLevel);
 
                 //TODO: depthToAnimateIn affects _isSingleParent, if there is a multizoom we may/may not be.
                 //As a hack we only do a animation free zoom on a single level zoom, if someone does multiple levels then we always animate
                 if (c._isSingleParent() && previousZoomLevel - 1 === newZoomLevel) {
                     c.clusterShow();
                     c._recursivelyRemoveChildrenFromMap(bounds, previousZoomLevel); //Immediately remove our children as we are replacing them. TODO previousBounds not bounds
                 } else {
                     c.clusterHide();
                 }
 
                 c._addToMap();
             }
         );
     },
 
     _recursivelyBecomeVisible: function (bounds, zoomLevel) {
         this._recursively(bounds, 0, zoomLevel, null, function (c) {
             c.clusterShow();
         });
     },
 
     _recursivelyAddChildrenToMap: function (startPos, zoomLevel, bounds) {
         this._recursively(bounds, -1, zoomLevel,
             function (c) {
                 if (zoomLevel === c._zoom) {
                     return;
                 }
 
                 //Add our child markers at startPos (so they can be animated out)
                 for (var i = c._markers.length - 1; i >= 0; i--) {
                     var nm = c._markers[i];
 
                     if (!bounds.contains(nm._latlng)) {
                         continue;
                     }
 
                     if (startPos) {
                         nm._backupLatlng = nm.getLatLng();
 
                         nm.setLatLng(startPos);
                         if (nm.clusterHide) {
                             nm.clusterHide();
                         }
                     }
 
                     c._group._featureGroup.addLayer(nm);
                 }
             },
             function (c) {
                 c._addToMap(startPos);
             }
         );
     },
 
     _recursivelyRestoreChildPositions: function (zoomLevel) {
         //Fix positions of child markers
         for (var i = this._markers.length - 1; i >= 0; i--) {
             var nm = this._markers[i];
             if (nm._backupLatlng) {
                 nm.setLatLng(nm._backupLatlng);
                 delete nm._backupLatlng;
             }
         }
 
         if (zoomLevel - 1 === this._zoom) {
             //Reposition child clusters
             for (var j = this._childClusters.length - 1; j >= 0; j--) {
                 this._childClusters[j]._restorePosition();
             }
         } else {
             for (var k = this._childClusters.length - 1; k >= 0; k--) {
                 this._childClusters[k]._recursivelyRestoreChildPositions(zoomLevel);
             }
         }
     },
 
     _restorePosition: function () {
         if (this._backupLatlng) {
             this.setLatLng(this._backupLatlng);
             delete this._backupLatlng;
         }
     },
 
     //exceptBounds: If set, don't remove any markers/clusters in it
     _recursivelyRemoveChildrenFromMap: function (previousBounds, zoomLevel, exceptBounds) {
         var m, i;
         this._recursively(previousBounds, -1, zoomLevel - 1,
             function (c) {
                 //Remove markers at every level
                 for (i = c._markers.length - 1; i >= 0; i--) {
                     m = c._markers[i];
                     if (!exceptBounds || !exceptBounds.contains(m._latlng)) {
                         c._group._featureGroup.removeLayer(m);
                         if (m.clusterShow) {
                             m.clusterShow();
                         }
                     }
                 }
             },
             function (c) {
                 //Remove child clusters at just the bottom level
                 for (i = c._childClusters.length - 1; i >= 0; i--) {
                     m = c._childClusters[i];
                     if (!exceptBounds || !exceptBounds.contains(m._latlng)) {
                         c._group._featureGroup.removeLayer(m);
                         if (m.clusterShow) {
                             m.clusterShow();
                         }
                     }
                 }
             }
         );
     },
 
     //Run the given functions recursively to this and child clusters
     // boundsToApplyTo: a L.LatLngBounds representing the bounds of what clusters to recurse in to
     // zoomLevelToStart: zoom level to start running functions (inclusive)
     // zoomLevelToStop: zoom level to stop running functions (inclusive)
     // runAtEveryLevel: function that takes an L.MarkerCluster as an argument that should be applied on every level
     // runAtBottomLevel: function that takes an L.MarkerCluster as an argument that should be applied at only the bottom level
     _recursively: function (boundsToApplyTo, zoomLevelToStart, zoomLevelToStop, runAtEveryLevel, runAtBottomLevel) {
         var childClusters = this._childClusters,
             zoom = this._zoom,
             i, c;
 
         if (zoomLevelToStart > zoom) { //Still going down to required depth, just recurse to child clusters
             for (i = childClusters.length - 1; i >= 0; i--) {
                 c = childClusters[i];
                 if (boundsToApplyTo.intersects(c._bounds)) {
                     c._recursively(boundsToApplyTo, zoomLevelToStart, zoomLevelToStop, runAtEveryLevel, runAtBottomLevel);
                 }
             }
         } else { //In required depth
 
             if (runAtEveryLevel) {
                 runAtEveryLevel(this);
             }
             if (runAtBottomLevel && this._zoom === zoomLevelToStop) {
                 runAtBottomLevel(this);
             }
 
             //TODO: This loop is almost the same as above
             if (zoomLevelToStop > zoom) {
                 for (i = childClusters.length - 1; i >= 0; i--) {
                     c = childClusters[i];
                     if (boundsToApplyTo.intersects(c._bounds)) {
                         c._recursively(boundsToApplyTo, zoomLevelToStart, zoomLevelToStop, runAtEveryLevel, runAtBottomLevel);
                     }
                 }
             }
         }
     },
 
     //Returns true if we are the parent of only one cluster and that cluster is the same as us
     _isSingleParent: function () {
         //Don't need to check this._markers as the rest won't work if there are any
         return this._childClusters.length > 0 && this._childClusters[0]._childCount === this._childCount;
     }
 });
 
 
 
 /*
 * Extends L.Marker to include two extra methods: clusterHide and clusterShow.
 * 
 * They work as setOpacity(0) and setOpacity(1) respectively, but
 * they will remember the marker's opacity when hiding and showing it again.
 * 
 */
 
 
 L.Marker.include({
     
     clusterHide: function () {
         this.options.opacityWhenUnclustered = this.options.opacity || 1;
         return this.setOpacity(0);
     },
     
     clusterShow: function () {
         var ret = this.setOpacity(this.options.opacity || this.options.opacityWhenUnclustered);
         delete this.options.opacityWhenUnclustered;
         return ret;
     }
     
 });
 
 
 
 
 
 L.DistanceGrid = function (cellSize) {
     this._cellSize = cellSize;
     this._sqCellSize = cellSize * cellSize;
     this._grid = {};
     this._objectPoint = { };
 };
 
 L.DistanceGrid.prototype = {
 
     addObject: function (obj, point) {
         var x = this._getCoord(point.x),
             y = this._getCoord(point.y),
             grid = this._grid,
             row = grid[y] = grid[y] || {},
             cell = row[x] = row[x] || [],
             stamp = L.Util.stamp(obj);
 
         this._objectPoint[stamp] = point;
 
         cell.push(obj);
     },
 
     updateObject: function (obj, point) {
         this.removeObject(obj);
         this.addObject(obj, point);
     },
 
     //Returns true if the object was found
     removeObject: function (obj, point) {
         var x = this._getCoord(point.x),
             y = this._getCoord(point.y),
             grid = this._grid,
             row = grid[y] = grid[y] || {},
             cell = row[x] = row[x] || [],
             i, len;
 
         delete this._objectPoint[L.Util.stamp(obj)];
 
         for (i = 0, len = cell.length; i < len; i++) {
             if (cell[i] === obj) {
 
                 cell.splice(i, 1);
 
                 if (len === 1) {
                     delete row[x];
                 }
 
                 return true;
             }
         }
 
     },
 
     eachObject: function (fn, context) {
         var i, j, k, len, row, cell, removed,
             grid = this._grid;
 
         for (i in grid) {
             row = grid[i];
 
             for (j in row) {
                 cell = row[j];
 
                 for (k = 0, len = cell.length; k < len; k++) {
                     removed = fn.call(context, cell[k]);
                     if (removed) {
                         k--;
                         len--;
                     }
                 }
             }
         }
     },
 
     getNearObject: function (point) {
         var x = this._getCoord(point.x),
             y = this._getCoord(point.y),
             i, j, k, row, cell, len, obj, dist,
             objectPoint = this._objectPoint,
             closestDistSq = this._sqCellSize,
             closest = null;
 
         for (i = y - 1; i <= y + 1; i++) {
             row = this._grid[i];
             if (row) {
 
                 for (j = x - 1; j <= x + 1; j++) {
                     cell = row[j];
                     if (cell) {
 
                         for (k = 0, len = cell.length; k < len; k++) {
                             obj = cell[k];
                             dist = this._sqDist(objectPoint[L.Util.stamp(obj)], point);
                             if (dist < closestDistSq) {
                                 closestDistSq = dist;
                                 closest = obj;
                             }
                         }
                     }
                 }
             }
         }
         return closest;
     },
 
     _getCoord: function (x) {
         return Math.floor(x / this._cellSize);
     },
 
     _sqDist: function (p, p2) {
         var dx = p2.x - p.x,
             dy = p2.y - p.y;
         return dx * dx + dy * dy;
     }
 };
 
 
 /* Copyright (c) 2012 the authors listed at the following URL, and/or
 the authors of referenced articles or incorporated external code:
 http://en.literateprograms.org/Quickhull_(Javascript)?action=history&offset=20120410175256
 
 Permission is hereby granted, free of charge, to any person obtaining
 a copy of this software and associated documentation files (the
 "Software"), to deal in the Software without restriction, including
 without limitation the rights to use, copy, modify, merge, publish,
 distribute, sublicense, and/or sell copies of the Software, and to
 permit persons to whom the Software is furnished to do so, subject to
 the following conditions:
 
 The above copyright notice and this permission notice shall be
 included in all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 
 Retrieved from: http://en.literateprograms.org/Quickhull_(Javascript)?oldid=18434
 */
 
 (function () {
     L.QuickHull = {
 
         /*
          * @param {Object} cpt a point to be measured from the baseline
          * @param {Array} bl the baseline, as represented by a two-element
          *   array of latlng objects.
          * @returns {Number} an approximate distance measure
          */
         getDistant: function (cpt, bl) {
             var vY = bl[1].lat - bl[0].lat,
                 vX = bl[0].lng - bl[1].lng;
             return (vX * (cpt.lat - bl[0].lat) + vY * (cpt.lng - bl[0].lng));
         },
 
         /*
          * @param {Array} baseLine a two-element array of latlng objects
          *   representing the baseline to project from
          * @param {Array} latLngs an array of latlng objects
          * @returns {Object} the maximum point and all new points to stay
          *   in consideration for the hull.
          */
         findMostDistantPointFromBaseLine: function (baseLine, latLngs) {
             var maxD = 0,
                 maxPt = null,
                 newPoints = [],
                 i, pt, d;
 
             for (i = latLngs.length - 1; i >= 0; i--) {
                 pt = latLngs[i];
                 d = this.getDistant(pt, baseLine);
 
                 if (d > 0) {
                     newPoints.push(pt);
                 } else {
                     continue;
                 }
 
                 if (d > maxD) {
                     maxD = d;
                     maxPt = pt;
                 }
             }
 
             return { maxPoint: maxPt, newPoints: newPoints };
         },
 
 
         /*
          * Given a baseline, compute the convex hull of latLngs as an array
          * of latLngs.
          *
          * @param {Array} latLngs
          * @returns {Array}
          */
         buildConvexHull: function (baseLine, latLngs) {
             var convexHullBaseLines = [],
                 t = this.findMostDistantPointFromBaseLine(baseLine, latLngs);
 
             if (t.maxPoint) { // if there is still a point "outside" the base line
                 convexHullBaseLines =
                     convexHullBaseLines.concat(
                         this.buildConvexHull([baseLine[0], t.maxPoint], t.newPoints)
                     );
                 convexHullBaseLines =
                     convexHullBaseLines.concat(
                         this.buildConvexHull([t.maxPoint, baseLine[1]], t.newPoints)
                     );
                 return convexHullBaseLines;
             } else {  // if there is no more point "outside" the base line, the current base line is part of the convex hull
                 return [baseLine[0]];
             }
         },
 
         /*
          * Given an array of latlngs, compute a convex hull as an array
          * of latlngs
          *
          * @param {Array} latLngs
          * @returns {Array}
          */
         getConvexHull: function (latLngs) {
             // find first baseline
             var maxLat = false, minLat = false,
                 maxLng = false, minLng = false,
                 maxLatPt = null, minLatPt = null,
                 maxLngPt = null, minLngPt = null,
                 maxPt = null, minPt = null,
                 i;
 
             for (i = latLngs.length - 1; i >= 0; i--) {
                 var pt = latLngs[i];
                 if (maxLat === false || pt.lat > maxLat) {
                     maxLatPt = pt;
                     maxLat = pt.lat;
                 }
                 if (minLat === false || pt.lat < minLat) {
                     minLatPt = pt;
                     minLat = pt.lat;
                 }
                 if (maxLng === false || pt.lng > maxLng) {
                     maxLngPt = pt;
                     maxLng = pt.lng;
                 }
                 if (minLng === false || pt.lng < minLng) {
                     minLngPt = pt;
                     minLng = pt.lng;
                 }
             }
             
             if (minLat !== maxLat) {
                 minPt = minLatPt;
                 maxPt = maxLatPt;
             } else {
                 minPt = minLngPt;
                 maxPt = maxLngPt;
             }
 
             var ch = [].concat(this.buildConvexHull([minPt, maxPt], latLngs),
                                 this.buildConvexHull([maxPt, minPt], latLngs));
             return ch;
         }
     };
 }());
 
 L.MarkerCluster.include({
     getConvexHull: function () {
         var childMarkers = this.getAllChildMarkers(),
             points = [],
             p, i;
 
         for (i = childMarkers.length - 1; i >= 0; i--) {
             p = childMarkers[i].getLatLng();
             points.push(p);
         }
 
         return L.QuickHull.getConvexHull(points);
     }
 });
 
 
 //This code is 100% based on https://github.com/jawj/OverlappingMarkerSpiderfier-Leaflet
 //Huge thanks to jawj for implementing it first to make my job easy :-)
 
 L.MarkerCluster.include({
 
     _2PI: Math.PI * 2,
     _circleFootSeparation: 25, //related to circumference of circle
     _circleStartAngle: Math.PI / 6,
 
     _spiralFootSeparation:  28, //related to size of spiral (experiment!)
     _spiralLengthStart: 11,
     _spiralLengthFactor: 5,
 
     _circleSpiralSwitchover: 9, //show spiral instead of circle from this marker count upwards.
                                 // 0 -> always spiral; Infinity -> always circle
 
     spiderfy: function () {
         if (this._group._spiderfied === this || this._group._inZoomAnimation) {
             return;
         }
 
         var childMarkers = this.getAllChildMarkers(),
             group = this._group,
             map = group._map,
             center = map.latLngToLayerPoint(this._latlng),
             positions;
 
         this._group._unspiderfy();
         this._group._spiderfied = this;
 
         //TODO Maybe: childMarkers order by distance to center
 
         if (childMarkers.length >= this._circleSpiralSwitchover) {
             positions = this._generatePointsSpiral(childMarkers.length, center);
         } else {
             center.y += 10; // Otherwise circles look wrong => hack for standard blue icon, renders differently for other icons.
             positions = this._generatePointsCircle(childMarkers.length, center);
         }
 
         this._animationSpiderfy(childMarkers, positions);
     },
 
     unspiderfy: function (zoomDetails) {
         /// <param Name="zoomDetails">Argument from zoomanim if being called in a zoom animation or null otherwise</param>
         if (this._group._inZoomAnimation) {
             return;
         }
         this._animationUnspiderfy(zoomDetails);
 
         this._group._spiderfied = null;
     },
 
     _generatePointsCircle: function (count, centerPt) {
         var circumference = this._group.options.spiderfyDistanceMultiplier * this._circleFootSeparation * (2 + count),
             legLength = circumference / this._2PI,  //radius from circumference
             angleStep = this._2PI / count,
             res = [],
             i, angle;
 
         res.length = count;
 
         for (i = count - 1; i >= 0; i--) {
             angle = this._circleStartAngle + i * angleStep;
             res[i] = new L.Point(centerPt.x + legLength * Math.cos(angle), centerPt.y + legLength * Math.sin(angle))._round();
         }
 
         return res;
     },
 
     _generatePointsSpiral: function (count, centerPt) {
         var spiderfyDistanceMultiplier = this._group.options.spiderfyDistanceMultiplier,
             legLength = spiderfyDistanceMultiplier * this._spiralLengthStart,
             separation = spiderfyDistanceMultiplier * this._spiralFootSeparation,
             lengthFactor = spiderfyDistanceMultiplier * this._spiralLengthFactor * this._2PI,
             angle = 0,
             res = [],
             i;
 
         res.length = count;
 
         // Higher index, closer position to cluster center.
         for (i = count - 1; i >= 0; i--) {
             angle += separation / legLength + i * 0.0005;
             res[i] = new L.Point(centerPt.x + legLength * Math.cos(angle), centerPt.y + legLength * Math.sin(angle))._round();
             legLength += lengthFactor / angle;
         }
         return res;
     },
 
     _noanimationUnspiderfy: function () {
         var group = this._group,
             map = group._map,
             fg = group._featureGroup,
             childMarkers = this.getAllChildMarkers(),
             m, i;
 
         group._ignoreMove = true;
 
         this.setOpacity(1);
         for (i = childMarkers.length - 1; i >= 0; i--) {
             m = childMarkers[i];
 
             fg.removeLayer(m);
 
             if (m._preSpiderfyLatlng) {
                 m.setLatLng(m._preSpiderfyLatlng);
                 delete m._preSpiderfyLatlng;
             }
             if (m.setZIndexOffset) {
                 m.setZIndexOffset(0);
             }
 
             if (m._spiderLeg) {
                 map.removeLayer(m._spiderLeg);
                 delete m._spiderLeg;
             }
         }
 
         group.fire('unspiderfied', {
             cluster: this,
             markers: childMarkers
         });
         group._ignoreMove = false;
         group._spiderfied = null;
     }
 });
 
 //Non Animated versions of everything
 L.MarkerClusterNonAnimated = L.MarkerCluster.extend({
     _animationSpiderfy: function (childMarkers, positions) {
         var group = this._group,
             map = group._map,
             fg = group._featureGroup,
             legOptions = this._group.options.spiderLegPolylineOptions,
             i, m, leg, newPos;
 
         group._ignoreMove = true;
 
         // Traverse in ascending order to make sure that inner circleMarkers are on top of further legs. Normal markers are re-ordered by newPosition.
         // The reverse order trick no longer improves performance on modern browsers.
         for (i = 0; i < childMarkers.length; i++) {
             newPos = map.layerPointToLatLng(positions[i]);
             m = childMarkers[i];
 
             // Add the leg before the marker, so that in case the latter is a circleMarker, the leg is behind it.
             leg = new L.Polyline([this._latlng, newPos], legOptions);
             map.addLayer(leg);
             m._spiderLeg = leg;
 
             // Now add the marker.
             m._preSpiderfyLatlng = m._latlng;
             m.setLatLng(newPos);
             if (m.setZIndexOffset) {
                 m.setZIndexOffset(1000000); //Make these appear on top of EVERYTHING
             }
 
             fg.addLayer(m);
         }
         this.setOpacity(0.3);
 
         group._ignoreMove = false;
         group.fire('spiderfied', {
             cluster: this,
             markers: childMarkers
         });
     },
 
     _animationUnspiderfy: function () {
         this._noanimationUnspiderfy();
     }
 });
 
 //Animated versions here
 L.MarkerCluster.include({
 
     _animationSpiderfy: function (childMarkers, positions) {
         var me = this,
             group = this._group,
             map = group._map,
             fg = group._featureGroup,
             thisLayerLatLng = this._latlng,
             thisLayerPos = map.latLngToLayerPoint(thisLayerLatLng),
             svg = L.Path.SVG,
             legOptions = L.extend({}, this._group.options.spiderLegPolylineOptions), // Copy the options so that we can modify them for animation.
             finalLegOpacity = legOptions.opacity,
             i, m, leg, legPath, legLength, newPos;
 
         if (finalLegOpacity === undefined) {
             finalLegOpacity = L.MarkerClusterGroup.prototype.options.spiderLegPolylineOptions.opacity;
         }
 
         if (svg) {
             // If the initial opacity of the spider leg is not 0 then it appears before the animation starts.
             legOptions.opacity = 0;
 
             // Add the class for CSS transitions.
             legOptions.className = (legOptions.className || '') + ' leaflet-cluster-spider-leg';
         } else {
             // Make sure we have a defined opacity.
             legOptions.opacity = finalLegOpacity;
         }
 
         group._ignoreMove = true;
 
         // Add markers and spider legs to map, hidden at our center point.
         // Traverse in ascending order to make sure that inner circleMarkers are on top of further legs. Normal markers are re-ordered by newPosition.
         // The reverse order trick no longer improves performance on modern browsers.
         for (i = 0; i < childMarkers.length; i++) {
             m = childMarkers[i];
 
             newPos = map.layerPointToLatLng(positions[i]);
 
             // Add the leg before the marker, so that in case the latter is a circleMarker, the leg is behind it.
             leg = new L.Polyline([thisLayerLatLng, newPos], legOptions);
             map.addLayer(leg);
             m._spiderLeg = leg;
 
             // Explanations: https://jakearchibald.com/2013/animated-line-drawing-svg/
             // In our case the transition property is declared in the CSS file.
             if (svg) {
                 legPath = leg._path;
                 legLength = legPath.getTotalLength() + 0.1; // Need a small extra length to avoid remaining dot in Firefox.
                 legPath.style.strokeDasharray = legLength; // Just 1 length is enough, it will be duplicated.
                 legPath.style.strokeDashoffset = legLength;
             }
 
             // If it is a marker, add it now and we'll animate it out
             if (m.setZIndexOffset) {
                 m.setZIndexOffset(1000000); // Make normal markers appear on top of EVERYTHING
             }
             if (m.clusterHide) {
                 m.clusterHide();
             }
             
             // Vectors just get immediately added
             fg.addLayer(m);
 
             if (m._setPos) {
                 m._setPos(thisLayerPos);
             }
         }
 
         group._forceLayout();
         group._animationStart();
 
         // Reveal markers and spider legs.
         for (i = childMarkers.length - 1; i >= 0; i--) {
             newPos = map.layerPointToLatLng(positions[i]);
             m = childMarkers[i];
 
             //Move marker to new position
             m._preSpiderfyLatlng = m._latlng;
             m.setLatLng(newPos);
             
             if (m.clusterShow) {
                 m.clusterShow();
             }
 
             // Animate leg (animation is actually delegated to CSS transition).
             if (svg) {
                 leg = m._spiderLeg;
                 legPath = leg._path;
                 legPath.style.strokeDashoffset = 0;
                 //legPath.style.strokeOpacity = finalLegOpacity;
                 leg.setStyle({opacity: finalLegOpacity});
             }
         }
         this.setOpacity(0.3);
 
         group._ignoreMove = false;
 
         setTimeout(function () {
             group._animationEnd();
             group.fire('spiderfied', {
                 cluster: me,
                 markers: childMarkers
             });
         }, 200);
     },
 
     _animationUnspiderfy: function (zoomDetails) {
         var me = this,
             group = this._group,
             map = group._map,
             fg = group._featureGroup,
             thisLayerPos = zoomDetails ? map._latLngToNewLayerPoint(this._latlng, zoomDetails.zoom, zoomDetails.center) : map.latLngToLayerPoint(this._latlng),
             childMarkers = this.getAllChildMarkers(),
             svg = L.Path.SVG,
             m, i, leg, legPath, legLength, nonAnimatable;
 
         group._ignoreMove = true;
         group._animationStart();
 
         //Make us visible and bring the child markers back in
         this.setOpacity(1);
         for (i = childMarkers.length - 1; i >= 0; i--) {
             m = childMarkers[i];
 
             //Marker was added to us after we were spiderfied
             if (!m._preSpiderfyLatlng) {
                 continue;
             }
 
             //Fix up the location to the real one
             m.setLatLng(m._preSpiderfyLatlng);
             delete m._preSpiderfyLatlng;
 
             //Hack override the location to be our center
             nonAnimatable = true;
             if (m._setPos) {
                 m._setPos(thisLayerPos);
                 nonAnimatable = false;
             }
             if (m.clusterHide) {
                 m.clusterHide();
                 nonAnimatable = false;
             }
             if (nonAnimatable) {
                 fg.removeLayer(m);
             }
 
             // Animate the spider leg back in (animation is actually delegated to CSS transition).
             if (svg) {
                 leg = m._spiderLeg;
                 legPath = leg._path;
                 legLength = legPath.getTotalLength() + 0.1;
                 legPath.style.strokeDashoffset = legLength;
                 leg.setStyle({opacity: 0});
             }
         }
 
         group._ignoreMove = false;
 
         setTimeout(function () {
             //If we have only <= one child left then that marker will be shown on the map so don't remove it!
             var stillThereChildCount = 0;
             for (i = childMarkers.length - 1; i >= 0; i--) {
                 m = childMarkers[i];
                 if (m._spiderLeg) {
                     stillThereChildCount++;
                 }
             }
 
 
             for (i = childMarkers.length - 1; i >= 0; i--) {
                 m = childMarkers[i];
 
                 if (!m._spiderLeg) { //Has already been unspiderfied
                     continue;
                 }
 
                 if (m.clusterShow) {
                     m.clusterShow();
                 }
                 if (m.setZIndexOffset) {
                     m.setZIndexOffset(0);
                 }
 
                 if (stillThereChildCount > 1) {
                     fg.removeLayer(m);
                 }
 
                 map.removeLayer(m._spiderLeg);
                 delete m._spiderLeg;
             }
             group._animationEnd();
             group.fire('unspiderfied', {
                 cluster: me,
                 markers: childMarkers
             });
         }, 200);
     }
 });
 
 
 L.MarkerClusterGroup.include({
     //The MarkerCluster currently spiderfied (if any)
     _spiderfied: null,
 
     unspiderfy: function () {
         this._unspiderfy.apply(this, arguments);
     },
 
     _spiderfierOnAdd: function () {
         this._map.on('click', this._unspiderfyWrapper, this);
 
         if (this._map.options.zoomAnimation) {
             this._map.on('zoomstart', this._unspiderfyZoomStart, this);
         }
         //Browsers without zoomAnimation or a big zoom don't fire zoomstart
         this._map.on('zoomend', this._noanimationUnspiderfy, this);
 
         if (!L.Browser.touch) {
             this._map.getRenderer(this);
             //Needs to happen in the pageload, not after, or animations don't work in webkit
             //  http://stackoverflow.com/questions/8455200/svg-animate-with-dynamically-added-elements
             //Disable on touch browsers as the animation messes up on a touch zoom and isn't very noticable
         }
     },
 
     _spiderfierOnRemove: function () {
         this._map.off('click', this._unspiderfyWrapper, this);
         this._map.off('zoomstart', this._unspiderfyZoomStart, this);
         this._map.off('zoomanim', this._unspiderfyZoomAnim, this);
         this._map.off('zoomend', this._noanimationUnspiderfy, this);
 
         //Ensure that markers are back where they should be
         // Use no animation to avoid a sticky leaflet-cluster-anim class on mapPane
         this._noanimationUnspiderfy();
     },
 
     //On zoom start we add a zoomanim handler so that we are guaranteed to be last (after markers are animated)
     //This means we can define the animation they do rather than Markers doing an animation to their actual location
     _unspiderfyZoomStart: function () {
         if (!this._map) { //May have been removed from the map by a zoomEnd handler
             return;
         }
 
         this._map.on('zoomanim', this._unspiderfyZoomAnim, this);
     },
 
     _unspiderfyZoomAnim: function (zoomDetails) {
         //Wait until the first zoomanim after the user has finished touch-zooming before running the animation
         if (L.DomUtil.hasClass(this._map._mapPane, 'leaflet-touching')) {
             return;
         }
 
         this._map.off('zoomanim', this._unspiderfyZoomAnim, this);
         this._unspiderfy(zoomDetails);
     },
 
     _unspiderfyWrapper: function () {
         /// <summary>_unspiderfy but passes no arguments</summary>
         this._unspiderfy();
     },
 
     _unspiderfy: function (zoomDetails) {
         if (this._spiderfied) {
             this._spiderfied.unspiderfy(zoomDetails);
         }
     },
 
     _noanimationUnspiderfy: function () {
         if (this._spiderfied) {
             this._spiderfied._noanimationUnspiderfy();
         }
     },
 
     //If the given layer is currently being spiderfied then we unspiderfy it so it isn't on the map anymore etc
     _unspiderfyLayer: function (layer) {
         if (layer._spiderLeg) {
             this._featureGroup.removeLayer(layer);
 
             if (layer.clusterShow) {
                 layer.clusterShow();
             }
                 //Position will be fixed up immediately in _animationUnspiderfy
             if (layer.setZIndexOffset) {
                 layer.setZIndexOffset(0);
             }
 
             this._map.removeLayer(layer._spiderLeg);
             delete layer._spiderLeg;
         }
     }
 });
 
 
 /**
  * Adds 1 public method to MCG and 1 to L.Marker to facilitate changing
  * markers' icon options and refreshing their icon and their parent clusters
  * accordingly (case where their iconCreateFunction uses data of childMarkers
  * to make up the cluster icon).
  */
 
 
 L.MarkerClusterGroup.include({
     /**
      * Updates the icon of all clusters which are parents of the given marker(s).
      * In singleMarkerMode, also updates the given marker(s) icon.
      * @param layers L.MarkerClusterGroup|L.LayerGroup|Array(L.Marker)|Map(L.Marker)|
      * L.MarkerCluster|L.Marker (optional) list of markers (or single marker) whose parent
      * clusters need to be updated. If not provided, retrieves all child markers of this.
      * @returns {L.MarkerClusterGroup}
      */
     refreshClusters: function (layers) {
         if (!layers) {
             layers = this._topClusterLevel.getAllChildMarkers();
         } else if (layers instanceof L.MarkerClusterGroup) {
             layers = layers._topClusterLevel.getAllChildMarkers();
         } else if (layers instanceof L.LayerGroup) {
             layers = layers._layers;
         } else if (layers instanceof L.MarkerCluster) {
             layers = layers.getAllChildMarkers();
         } else if (layers instanceof L.Marker) {
             layers = [layers];
         } // else: must be an Array(L.Marker)|Map(L.Marker)
         this._flagParentsIconsNeedUpdate(layers);
         this._refreshClustersIcons();
 
         // In case of singleMarkerMode, also re-draw the markers.
         if (this.options.singleMarkerMode) {
             this._refreshSingleMarkerModeMarkers(layers);
         }
 
         return this;
     },
 
     /**
      * Simply flags all parent clusters of the given markers as having a "dirty" icon.
      * @param layers Array(L.Marker)|Map(L.Marker) list of markers.
      * @private
      */
     _flagParentsIconsNeedUpdate: function (layers) {
         var id, parent;
 
         // Assumes layers is an Array or an Object whose prototype is non-enumerable.
         for (id in layers) {
             // Flag parent clusters' icon as "dirty", all the way up.
             // Dumb process that flags multiple times upper parents, but still
             // much more efficient than trying to be smart and make short lists,
             // at least in the case of a hierarchy following a power law:
             // http://jsperf.com/flag-nodes-in-power-hierarchy/2
             parent = layers[id].__parent;
             while (parent) {
                 parent._iconNeedsUpdate = true;
                 parent = parent.__parent;
             }
         }
     },
 
     /**
      * Refreshes the icon of all "dirty" visible clusters.
      * Non-visible "dirty" clusters will be updated when they are added to the map.
      * @private
      */
     _refreshClustersIcons: function () {
         this._featureGroup.eachLayer(function (c) {
             if (c instanceof L.MarkerCluster && c._iconNeedsUpdate) {
                 c._updateIcon();
             }
         });
     },
 
     /**
      * Re-draws the icon of the supplied markers.
      * To be used in singleMarkerMode only.
      * @param layers Array(L.Marker)|Map(L.Marker) list of markers.
      * @private
      */
     _refreshSingleMarkerModeMarkers: function (layers) {
         var id, layer;
 
         for (id in layers) {
             layer = layers[id];
 
             // Make sure we do not override markers that do not belong to THIS group.
             if (this.hasLayer(layer)) {
                 // Need to re-create the icon first, then re-draw the marker.
                 layer.setIcon(this._overrideMarkerIcon(layer));
             }
         }
     }
 });
 
 L.Marker.include({
     /**
      * Updates the given options in the marker's icon and refreshes the marker.
      * @param options map object of icon options.
      * @param directlyRefreshClusters boolean (optional) true to trigger
      * MCG.refreshClustersOf() right away with this single marker.
      * @returns {L.Marker}
      */
     refreshIconOptions: function (options, directlyRefreshClusters) {
         var icon = this.options.icon;
 
         L.setOptions(icon, options);
 
         this.setIcon(icon);
 
         // Shortcut to refresh the associated MCG clusters right away.
         // To be used when refreshing a single marker.
         // Otherwise, better use MCG.refreshClusters() once at the end with
         // the list of modified markers.
         if (directlyRefreshClusters && this.__parent) {
             this.__parent._group.refreshClusters(this);
         }
 
         return this;
     }
 });
 
 
 }(window, document));
 /**
  * Leaflet.MarkerCluster.Freezable 0.1.1+0285b6c
  * Sub-plugin for Leaflet.markercluster plugin; adds the ability to freeze clusters at a specified zoom.
  * (c) 2015-2016 Boris Seang
  * License MIT
  */
 (function (root, factory) {
     if (typeof define === "function" && define.amd) {
         define(["leaflet"], factory);
     } else if (typeof module === "object" && module.exports) {
         factory(require("leaflet"));
     } else {
         factory(root.L);
     }
 }(this, function (L, undefined) {
 
 L.MarkerClusterGroup.include({
 
     _originalOnAdd: L.MarkerClusterGroup.prototype.onAdd,
 
     onAdd: function (map) {
         var frozenZoom = this._zoom;
 
         this._originalOnAdd(map);
 
         if (this._frozen) {
 
             // Restore the specified frozenZoom if necessary.
             if (frozenZoom >= 0 && frozenZoom !== this._zoom) {
                 // Undo clusters and markers addition to this._featureGroup.
                 this._featureGroup.clearLayers();
 
                 this._zoom = frozenZoom;
 
                 this.addLayers([]);
             }
 
             // Replace the callbacks on zoomend and moveend events.
             map.off('zoomend', this._zoomEnd, this);
             map.off('moveend', this._moveEnd, this);
             map.on('zoomend moveend', this._viewChangeEndNotClustering, this);
         }
     },
 
     _originalOnRemove: L.MarkerClusterGroup.prototype.onRemove,
 
     onRemove: function (map) {
         map.off('zoomend moveend', this._viewChangeEndNotClustering, this);
         this._originalOnRemove(map);
     },
 
     disableClustering: function () {
         return this.freezeAtZoom(this._maxZoom + 1);
     },
 
     disableClusteringKeepSpiderfy: function () {
         return this.freezeAtZoom(this._maxZoom);
     },
 
     enableClustering: function () {
         return this.unfreeze();
     },
 
     unfreeze: function () {
         return this.freezeAtZoom(false);
     },
 
     freezeAtZoom: function (frozenZoom) {
         this._processQueue();
 
         var map = this._map;
 
         // If frozenZoom is not specified, true or NaN, freeze at current zoom.
         // Note: NaN is the only value which is not eaqual to itself.
         if (frozenZoom === undefined || frozenZoom === true || (frozenZoom !== frozenZoom)) {
             // Set to -1 if not on map, as the sign to freeze as soon as it gets added to a map.
             frozenZoom = map ? Math.round(map.getZoom()) : -1;
         } else if (frozenZoom === 'max') {
             // If frozenZoom is "max", freeze at MCG maxZoom + 1 (eliminates all clusters).
             frozenZoom = this._maxZoom + 1;
         } else if (frozenZoom === 'maxKeepSpiderfy') {
             // If "maxKeepSpiderfy", freeze at MCG maxZoom (eliminates all clusters but bottom-most ones).
             frozenZoom = this._maxZoom;
         }
 
         var requestFreezing = typeof frozenZoom === 'number';
 
         if (this._frozen) { // Already frozen.
             if (!requestFreezing) { // Unfreeze.
                 this._unfreeze();
                 return this;
             }
             // Just change the frozen zoom: go straight to artificial zoom.
         } else if (requestFreezing) {
             // Start freezing
             this._initiateFreeze();
         } else { // Not frozen and not requesting freezing => nothing to do.
             return this;
         }
 
         this._artificialZoomSafe(this._zoom, frozenZoom);
         return this;
     },
 
     _initiateFreeze: function () {
         var map = this._map;
 
         // Start freezing
         this._frozen = true;
 
         if (map) {
             // Change behaviour on zoomEnd and moveEnd.
             map.off('zoomend', this._zoomEnd, this);
             map.off('moveend', this._moveEnd, this);
 
             map.on('zoomend moveend', this._viewChangeEndNotClustering, this);
         }
     },
 
     _unfreeze: function () {
         var map = this._map;
 
         this._frozen = false;
 
         if (map) {
             // Restore original behaviour on zoomEnd.
             map.off('zoomend moveend', this._viewChangeEndNotClustering, this);
 
             map.on('zoomend', this._zoomEnd, this);
             map.on('moveend', this._moveEnd, this);
 
             // Animate.
             this._executeAfterUnspiderfy(function () {
                 this._zoomEnd(); // Will set this._zoom at the end.
             }, this);
         }
     },
 
     _executeAfterUnspiderfy: function (callback, context) {
         // Take care of spiderfied markers!
         // The cluster might be removed, whereas markers are on fake positions.
         if (this._unspiderfy && this._spiderfied) {
             this.once('animationend', function () {
                 callback.call(context);
             });
             this._unspiderfy();
             return;
         }
 
         callback.call(context);
     },
 
     _artificialZoomSafe: function (previousZoom, targetZoom) {
         this._zoom = targetZoom;
 
         if (!this._map || previousZoom === targetZoom) {
             return;
         }
 
         this._executeAfterUnspiderfy(function () {
             this._artificialZoom(previousZoom, targetZoom);
         }, this);
     },
 
     _artificialZoom: function (previousZoom, targetZoom) {
         if (previousZoom < targetZoom) {
             // Make as if we had instantly zoomed in from previousZoom to targetZoom.
             this._animationStart();
             this._topClusterLevel._recursivelyRemoveChildrenFromMap(
                 this._currentShownBounds, previousZoom, this._getExpandedVisibleBounds()
             );
             this._animationZoomIn(previousZoom, targetZoom);
 
         } else if (previousZoom > targetZoom) {
             // Make as if we had instantly zoomed out from previousZoom to targetZoom.
             this._animationStart();
             this._animationZoomOut(previousZoom, targetZoom);
         }
     },
 
     _viewChangeEndNotClustering: function () {
         var fg = this._featureGroup,
             newBounds = this._getExpandedVisibleBounds(),
             targetZoom = this._zoom;
 
         // Remove markers and bottom clusters outside newBounds, unless they come
         // from a spiderfied cluster.
         fg.eachLayer(function (layer) {
             if (!newBounds.contains(layer._latlng) && layer.__parent && layer.__parent._zoom < targetZoom) {
                 fg.removeLayer(layer);
             }
         });
 
         // Add markers and bottom clusters in newBounds.
         this._topClusterLevel._recursively(newBounds, -1, targetZoom,
             function (c) { // Add markers from each cluster of lower zoom than targetZoom
                 if (c._zoom === targetZoom) { // except targetZoom
                     return;
                 }
 
                 var markers = c._markers,
                     i = 0,
                     marker;
 
                 for (; i < markers.length; i++) {
                     marker = c._markers[i];
 
                     if (!newBounds.contains(marker._latlng)) {
                         continue;
                     }
 
                     fg.addLayer(marker);
                 }
             },
             function (c) { // Add clusters from targetZoom.
                 c._addToMap();
             }
         );
     },
 
     _originalZoomOrSpiderfy: L.MarkerClusterGroup.prototype._zoomOrSpiderfy,
 
     _zoomOrSpiderfy: function (e) {
         if (this._frozen && this.options.spiderfyOnMaxZoom) {
             e.layer.spiderfy();
             if (e.originalEvent && e.originalEvent.keyCode === 13) {
                 map._container.focus();
             }
         } else {
             this._originalZoomOrSpiderfy(e);
         }
     }
 
 });
 
 
 
 }));
 
 //# sourceMappingURL=leaflet.markercluster.freezable-src.map
 /*
  * Inspired by Tom Mac Wright article :
  * http://mapbox.com/osmdev/2012/11/20/getting-serious-about-svg/
  */
 
 (function () {
 
 var __onAdd = L.Polyline.prototype.onAdd,
     __onRemove = L.Polyline.prototype.onRemove,
     __updatePath = L.Polyline.prototype._updatePath,
     __bringToFront = L.Polyline.prototype.bringToFront;
 
 
 var PolylineTextPath = {
 
     onAdd: function (map) {
         __onAdd.call(this, map);
         this._textRedraw();
     },
 
     onRemove: function (map) {
         map = map || this._map;
         if (map && this._textNode)
             map._renderer._container.removeChild(this._textNode);
         __onRemove.call(this, map);
     },
 
     bringToFront: function () {
         __bringToFront.call(this);
         this._textRedraw();
     },
 
     _updatePath: function () {
         __updatePath.call(this);
         this._textRedraw();
     },
 
     _textRedraw: function () {
         var text = this._text,
             options = this._textOptions;
         if (text) {
             this.setText(null).setText(text, options);
         }
     },
 
     setText: function (text, options) {
         this._text = text;
         this._textOptions = options;
 
         /* If not in SVG mode or Polyline not added to map yet return */
         /* setText will be called by onAdd, using value stored in this._text */
         if (!L.Browser.svg || typeof this._map === 'undefined') {
           return this;
         }
 
         var defaults = {
             repeat: false,
             fillColor: 'black',
             attributes: {},
             below: false,
         };
         options = L.Util.extend(defaults, options);
 
         /* If empty text, hide */
         if (!text) {
             if (this._textNode && this._textNode.parentNode) {
                 this._map._renderer._container.removeChild(this._textNode);
                 
                 /* delete the node, so it will not be removed a 2nd time if the layer is later removed from the map */
                 delete this._textNode;
             }
             return this;
         }
 
         text = text.replace(/ /g, '\u00A0');  // Non breakable spaces
         var id = 'pathdef-' + L.Util.stamp(this);
         var svg = this._map._renderer._container;
         this._path.setAttribute('id', id);
 
         if (options.repeat) {
             /* Compute single pattern length */
             var pattern = L.SVG.create('text');
             for (var attr in options.attributes)
                 pattern.setAttribute(attr, options.attributes[attr]);
             pattern.appendChild(document.createTextNode(text));
             svg.appendChild(pattern);
             var alength = pattern.getComputedTextLength();
             svg.removeChild(pattern);
 
             /* Create string as long as path */
             text = new Array(Math.ceil(this._path.getTotalLength() / alength)).join(text);
         }
 
         /* Put it along the path using textPath */
         var textNode = L.SVG.create('text'),
             textPath = L.SVG.create('textPath');
 
         var dy = options.offset || this._path.getAttribute('stroke-width');
 
         textPath.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", '#'+id);
         textNode.setAttribute('dy', dy);
         for (var attr in options.attributes)
             textNode.setAttribute(attr, options.attributes[attr]);
         textPath.appendChild(document.createTextNode(text));
         textNode.appendChild(textPath);
         this._textNode = textNode;
 
         if (options.below) {
             svg.insertBefore(textNode, svg.firstChild);
         }
         else {
             svg.appendChild(textNode);
         }
 
         /* Center text according to the path's bounding box */
         if (options.center) {
            /* var textWidth = textNode.getBBox().width;
             var pathWidth = this._path.getBoundingClientRect().width;
             // Set the position for the left side of the textNode 
             textNode.setAttribute('dx', ((pathWidth / 2) - (textWidth / 2)));
             */
             var textLength = textNode.getComputedTextLength();
             var pathLength = this._path.getTotalLength();
             /* Set the position for the left side of the textNode */
             textNode.setAttribute('dx', ((pathLength / 2) - (textLength / 2)));
             
             
         }
 
         /* Initialize mouse events for the additional nodes */
         if (this.options.clickable) {
             if (L.Browser.svg || !L.Browser.vml) {
                 textPath.setAttribute('class', 'leaflet-clickable');
             }
 
             L.DomEvent.on(textNode, 'click', this._onMouseClick, this);
 
             var events = ['dblclick', 'mousedown', 'mouseover',
                           'mouseout', 'mousemove', 'contextmenu'];
             for (var i = 0; i < events.length; i++) {
                 L.DomEvent.on(textNode, events[i], this._fireMouseEvent, this);
             }
         }
 
         return this;
     }
 };
 
 L.Polyline.include(PolylineTextPath);
 
 L.LayerGroup.include({
     setText: function(text, options) {
         for (var layer in this._layers) {
             if (typeof this._layers[layer].setText === 'function') {
                 this._layers[layer].setText(text, options);
             }
         }
         return this;
     }
 });
 
 })();
 
 
 
 
 L.drawVersion="0.4.2";L.Draw={};L.drawLocal={draw:{toolbar:{actions:{title:"Cancel drawing",text:"Cancel"},finish:{title:"Finish drawing",text:"Finish"},undo:{title:"Delete last point drawn",text:"Delete last point"},buttons:{polyline:"Draw a polyline",polygon:"Draw a polygon",rectangle:"Draw a rectangle",circle:"Draw a circle",marker:"Draw a marker",circlemarker:"Draw a circlemarker"}},handlers:{circle:{tooltip:{start:"Click and drag to draw circle."},radius:"Radius"},circlemarker:{tooltip:{start:"Click map to place circle marker."}},marker:{tooltip:{start:"Click map to place marker."}},polygon:{tooltip:{start:"Click to start drawing shape.",cont:"Click to continue drawing shape.",end:"Click first point to close this shape."}},polyline:{error:"<strong>Error:</strong> shape edges cannot cross!",tooltip:{start:"Click to start drawing line.",cont:"Click to continue drawing line.",end:"Click last point to finish line."}},rectangle:{tooltip:{start:"Click and drag to draw rectangle."}},simpleshape:{tooltip:{end:"Release mouse to finish drawing."}}}},edit:{toolbar:{actions:{save:{title:"Save changes",text:"Save"},cancel:{title:"Cancel editing, discards all changes",text:"Cancel"},clearAll:{title:"Clear all layers",text:"Clear All"}},buttons:{edit:"Edit layers",editDisabled:"No layers to edit",remove:"Delete layers",removeDisabled:"No layers to delete"}},handlers:{edit:{tooltip:{text:"Drag handles or markers to edit features.",subtext:"Click cancel to undo changes."}},remove:{tooltip:{text:"Click on a feature to remove."}}}}};L.Draw.Event={};L.Draw.Event.CREATED="draw:created";L.Draw.Event.EDITED="draw:edited";L.Draw.Event.DELETED="draw:deleted";L.Draw.Event.DRAWSTART="draw:drawstart";L.Draw.Event.DRAWSTOP="draw:drawstop";L.Draw.Event.DRAWVERTEX="draw:drawvertex";L.Draw.Event.EDITSTART="draw:editstart";L.Draw.Event.EDITMOVE="draw:editmove";L.Draw.Event.EDITRESIZE="draw:editresize";L.Draw.Event.EDITVERTEX="draw:editvertex";L.Draw.Event.EDITSTOP="draw:editstop";L.Draw.Event.DELETESTART="draw:deletestart";L.Draw.Event.DELETESTOP="draw:deletestop";L.Draw.Event.TOOLBAROPENED="draw:toolbaropened";L.Draw.Event.TOOLBARCLOSED="draw:toolbarclosed";L.Draw.Event.MARKERCONTEXT="draw:markercontext";L.Edit=L.Edit||{};L.Edit.SimpleShape=L.Handler.extend({options:{moveIcon:new L.DivIcon({iconSize:new L.Point(8,8),className:"leaflet-div-icon leaflet-editing-icon leaflet-edit-move"}),resizeIcon:new L.DivIcon({iconSize:new L.Point(8,8),className:"leaflet-div-icon leaflet-editing-icon leaflet-edit-resize"}),touchMoveIcon:new L.DivIcon({iconSize:new L.Point(20,20),className:"leaflet-div-icon leaflet-editing-icon leaflet-edit-move leaflet-touch-icon"}),touchResizeIcon:new L.DivIcon({iconSize:new L.Point(20,20),className:"leaflet-div-icon leaflet-editing-icon leaflet-edit-resize leaflet-touch-icon"}),},initialize:function(shape,options){if(L.Browser.touch){this.options.moveIcon=this.options.touchMoveIcon;this.options.resizeIcon=this.options.touchResizeIcon;}this._shape=shape;L.Util.setOptions(this,options);},addHooks:function(){var shape=this._shape;if(this._shape._map){this._map=this._shape._map;shape.setStyle(shape.options.editing);if(shape._map){this._map=shape._map;if(!this._markerGroup){this._initMarkers();}this._map.addLayer(this._markerGroup);}}},removeHooks:function(){var shape=this._shape;shape.setStyle(shape.options.original);if(shape._map){this._unbindMarker(this._moveMarker);for(var i=0,l=this._resizeMarkers.length;i<l;i++){this._unbindMarker(this._resizeMarkers[i]);}this._resizeMarkers=null;this._map.removeLayer(this._markerGroup);delete this._markerGroup;}this._map=null;},updateMarkers:function(){this._markerGroup.clearLayers();this._initMarkers();},_initMarkers:function(){if(!this._markerGroup){this._markerGroup=new L.LayerGroup();}this._createMoveMarker();this._createResizeMarker();},_createMoveMarker:function(){},_createResizeMarker:function(){},_createMarker:function(latlng,icon){var marker=new L.Marker.Touch(latlng,{draggable:true,icon:icon,zIndexOffset:10});this._bindMarker(marker);this._markerGroup.addLayer(marker);return marker;},_bindMarker:function(marker){marker.on("dragstart",this._onMarkerDragStart,this).on("drag",this._onMarkerDrag,this).on("dragend",this._onMarkerDragEnd,this).on("touchstart",this._onTouchStart,this).on("touchmove",this._onTouchMove,this).on("MSPointerMove",this._onTouchMove,this).on("touchend",this._onTouchEnd,this).on("MSPointerUp",this._onTouchEnd,this);},_unbindMarker:function(marker){marker.off("dragstart",this._onMarkerDragStart,this).off("drag",this._onMarkerDrag,this).off("dragend",this._onMarkerDragEnd,this).off("touchstart",this._onTouchStart,this).off("touchmove",this._onTouchMove,this).off("MSPointerMove",this._onTouchMove,this).off("touchend",this._onTouchEnd,this).off("MSPointerUp",this._onTouchEnd,this);},_onMarkerDragStart:function(e){var marker=e.target;marker.setOpacity(0);this._shape.fire("editstart");},_fireEdit:function(){this._shape.edited=true;this._shape.fire("edit");},_onMarkerDrag:function(e){var marker=e.target,latlng=marker.getLatLng();if(marker===this._moveMarker){this._move(latlng);}else{this._resize(latlng);}this._shape.redraw();this._shape.fire("editdrag");},_onMarkerDragEnd:function(e){var marker=e.target;marker.setOpacity(1);this._fireEdit();},_onTouchStart:function(e){L.Edit.SimpleShape.prototype._onMarkerDragStart.call(this,e);if(typeof(this._getCorners)==="function"){var corners=this._getCorners(),marker=e.target,currentCornerIndex=marker._cornerIndex;marker.setOpacity(0);this._oppositeCorner=corners[(currentCornerIndex+2)%4];this._toggleCornerMarkers(0,currentCornerIndex);}this._shape.fire("editstart");},_onTouchMove:function(e){var layerPoint=this._map.mouseEventToLayerPoint(e.originalEvent.touches[0]),latlng=this._map.layerPointToLatLng(layerPoint),marker=e.target;if(marker===this._moveMarker){this._move(latlng);}else{this._resize(latlng);}this._shape.redraw();return false;},_onTouchEnd:function(e){var marker=e.target;marker.setOpacity(1);this.updateMarkers();this._fireEdit();},_move:function(){},_resize:function(){}});L.Edit=L.Edit||{};L.Edit.Poly=L.Handler.extend({initialize:function(poly){this.latlngs=[poly._latlngs];if(poly._holes){this.latlngs=this.latlngs.concat(poly._holes);}this._poly=poly;this._poly.on("revert-edited",this._updateLatLngs,this);},_defaultShape:function(){if(!L.Polyline._flat){return this._poly._latlngs;}return L.Polyline._flat(this._poly._latlngs)?this._poly._latlngs:this._poly._latlngs[0];},_eachVertexHandler:function(callback){for(var i=0;i<this._verticesHandlers.length;i++){callback(this._verticesHandlers[i]);}},addHooks:function(){this._initHandlers();this._eachVertexHandler(function(handler){handler.addHooks();});},removeHooks:function(){this._eachVertexHandler(function(handler){handler.removeHooks();});},updateMarkers:function(){this._eachVertexHandler(function(handler){handler.updateMarkers();});},_initHandlers:function(){this._verticesHandlers=[];for(var i=0;i<this.latlngs.length;i++){this._verticesHandlers.push(new L.Edit.PolyVerticesEdit(this._poly,this.latlngs[i],this._poly.options.poly));}},_updateLatLngs:function(e){this.latlngs=[e.layer._latlngs];if(e.layer._holes){this.latlngs=this.latlngs.concat(e.layer._holes);}}});L.Edit.PolyVerticesEdit=L.Handler.extend({options:{icon:new L.DivIcon({iconSize:new L.Point(8,8),className:"leaflet-div-icon leaflet-editing-icon"}),touchIcon:new L.DivIcon({iconSize:new L.Point(20,20),className:"leaflet-div-icon leaflet-editing-icon leaflet-touch-icon"}),drawError:{color:"#b00b00",timeout:1000}},initialize:function(poly,latlngs,options){if(L.Browser.touch){this.options.icon=this.options.touchIcon;}this._poly=poly;if(options&&options.drawError){options.drawError=L.Util.extend({},this.options.drawError,options.drawError);}this._latlngs=latlngs;L.setOptions(this,options);},_defaultShape:function(){if(!L.Polyline._flat){return this._latlngs;}return L.Polyline._flat(this._latlngs)?this._latlngs:this._latlngs[0];},addHooks:function(){var poly=this._poly;var path=poly._path;if(!(poly instanceof L.Polygon)){poly.options.fill=false;if(poly.options.editing){poly.options.editing.fill=false;}}if(path){if(poly.options.editing.className){if(poly.options.original.className){poly.options.original.className.split(" ").forEach(function(className){L.DomUtil.removeClass(path,className);});}poly.options.editing.className.split(" ").forEach(function(className){L.DomUtil.addClass(path,className);});}}poly.setStyle(poly.options.editing);if(this._poly._map){this._map=this._poly._map;if(!this._markerGroup){this._initMarkers();}this._poly._map.addLayer(this._markerGroup);}},removeHooks:function(){var poly=this._poly;var path=poly._path;if(path){if(poly.options.editing.className){poly.options.editing.className.split(" ").forEach(function(className){L.DomUtil.removeClass(path,className);});if(poly.options.original.className){poly.options.original.className.split(" ").forEach(function(className){L.DomUtil.addClass(path,className);});}}}poly.setStyle(poly.options.original);if(poly._map){poly._map.removeLayer(this._markerGroup);delete this._markerGroup;delete this._markers;}},updateMarkers:function(){this._markerGroup.clearLayers();this._initMarkers();},_initMarkers:function(){if(!this._markerGroup){this._markerGroup=new L.LayerGroup();}this._markers=[];var latlngs=this._defaultShape(),i,j,len,marker;for(i=0,len=latlngs.length;i<len;i++){marker=this._createMarker(latlngs[i],i);marker.on("click",this._onMarkerClick,this);marker.on("contextmenu",this._onContextMenu,this);this._markers.push(marker);}var markerLeft,markerRight;for(i=0,j=len-1;i<len;j=i++){if(i===0&&!(L.Polygon&&(this._poly instanceof L.Polygon))){continue;}markerLeft=this._markers[j];markerRight=this._markers[i];this._createMiddleMarker(markerLeft,markerRight);this._updatePrevNext(markerLeft,markerRight);}},_createMarker:function(latlng,index){var marker=new L.Marker.Touch(latlng,{draggable:true,icon:this.options.icon,});marker._origLatLng=latlng;marker._index=index;marker.on("dragstart",this._onMarkerDragStart,this).on("drag",this._onMarkerDrag,this).on("dragend",this._fireEdit,this).on("touchmove",this._onTouchMove,this).on("touchend",this._fireEdit,this).on("MSPointerMove",this._onTouchMove,this).on("MSPointerUp",this._fireEdit,this);this._markerGroup.addLayer(marker);return marker;},_onMarkerDragStart:function(){this._poly.fire("editstart");},_spliceLatLngs:function(){var latlngs=this._defaultShape();var removed=[].splice.apply(latlngs,arguments);this._poly._convertLatLngs(latlngs,true);this._poly.redraw();return removed;},_removeMarker:function(marker){var i=marker._index;this._markerGroup.removeLayer(marker);this._markers.splice(i,1);this._spliceLatLngs(i,1);this._updateIndexes(i,-1);marker.off("dragstart",this._onMarkerDragStart,this).off("drag",this._onMarkerDrag,this).off("dragend",this._fireEdit,this).off("touchmove",this._onMarkerDrag,this).off("touchend",this._fireEdit,this).off("click",this._onMarkerClick,this).off("MSPointerMove",this._onTouchMove,this).off("MSPointerUp",this._fireEdit,this);},_fireEdit:function(){this._poly.edited=true;this._poly.fire("edit");this._poly._map.fire(L.Draw.Event.EDITVERTEX,{layers:this._markerGroup,poly:this._poly});},_onMarkerDrag:function(e){var marker=e.target;var poly=this._poly;L.extend(marker._origLatLng,marker._latlng);if(marker._middleLeft){marker._middleLeft.setLatLng(this._getMiddleLatLng(marker._prev,marker));}if(marker._middleRight){marker._middleRight.setLatLng(this._getMiddleLatLng(marker,marker._next));}if(poly.options.poly){var tooltip=poly._map._editTooltip;if(!poly.options.poly.allowIntersection&&poly.intersects()){var originalColor=poly.options.color;poly.setStyle({color:this.options.drawError.color});if(L.version.indexOf("0.7")!==0){marker.dragging._draggable._onUp(e);}this._onMarkerClick(e);if(tooltip){tooltip.updateContent({text:L.drawLocal.draw.handlers.polyline.error});}setTimeout(function(){poly.setStyle({color:originalColor});if(tooltip){tooltip.updateContent({text:L.drawLocal.edit.handlers.edit.tooltip.text,subtext:L.drawLocal.edit.handlers.edit.tooltip.subtext});}},1000);}}this._poly._bounds._southWest=L.latLng(Infinity,Infinity);this._poly._bounds._northEast=L.latLng(-Infinity,-Infinity);var latlngs=this._poly.getLatLngs();this._poly._convertLatLngs(latlngs,true);this._poly.redraw();this._poly.fire("editdrag");},_onMarkerClick:function(e){var minPoints=L.Polygon&&(this._poly instanceof L.Polygon)?4:3,marker=e.target;if(this._defaultShape().length<minPoints){return;}this._removeMarker(marker);this._updatePrevNext(marker._prev,marker._next);if(marker._middleLeft){this._markerGroup.removeLayer(marker._middleLeft);}if(marker._middleRight){this._markerGroup.removeLayer(marker._middleRight);}if(marker._prev&&marker._next){this._createMiddleMarker(marker._prev,marker._next);}else{if(!marker._prev){marker._next._middleLeft=null;}else{if(!marker._next){marker._prev._middleRight=null;}}}this._fireEdit();},_onContextMenu:function(e){var marker=e.target;var poly=this._poly;this._poly._map.fire(L.Draw.Event.MARKERCONTEXT,{marker:marker,layers:this._markerGroup,poly:this._poly});L.DomEvent.stopPropagation;},_onTouchMove:function(e){var layerPoint=this._map.mouseEventToLayerPoint(e.originalEvent.touches[0]),latlng=this._map.layerPointToLatLng(layerPoint),marker=e.target;L.extend(marker._origLatLng,latlng);if(marker._middleLeft){marker._middleLeft.setLatLng(this._getMiddleLatLng(marker._prev,marker));}if(marker._middleRight){marker._middleRight.setLatLng(this._getMiddleLatLng(marker,marker._next));}this._poly.redraw();this.updateMarkers();},_updateIndexes:function(index,delta){this._markerGroup.eachLayer(function(marker){if(marker._index>index){marker._index+=delta;}});},_createMiddleMarker:function(marker1,marker2){var latlng=this._getMiddleLatLng(marker1,marker2),marker=this._createMarker(latlng),onClick,onDragStart,onDragEnd;marker.setOpacity(0.6);marker1._middleRight=marker2._middleLeft=marker;onDragStart=function(){marker.off("touchmove",onDragStart,this);var i=marker2._index;marker._index=i;marker.off("click",onClick,this).on("click",this._onMarkerClick,this);latlng.lat=marker.getLatLng().lat;latlng.lng=marker.getLatLng().lng;this._spliceLatLngs(i,0,latlng);this._markers.splice(i,0,marker);marker.setOpacity(1);this._updateIndexes(i,1);marker2._index++;this._updatePrevNext(marker1,marker);this._updatePrevNext(marker,marker2);this._poly.fire("editstart");};onDragEnd=function(){marker.off("dragstart",onDragStart,this);marker.off("dragend",onDragEnd,this);marker.off("touchmove",onDragStart,this);this._createMiddleMarker(marker1,marker);this._createMiddleMarker(marker,marker2);};onClick=function(){onDragStart.call(this);onDragEnd.call(this);this._fireEdit();};marker.on("click",onClick,this).on("dragstart",onDragStart,this).on("dragend",onDragEnd,this).on("touchmove",onDragStart,this);this._markerGroup.addLayer(marker);},_updatePrevNext:function(marker1,marker2){if(marker1){marker1._next=marker2;}if(marker2){marker2._prev=marker1;}},_getMiddleLatLng:function(marker1,marker2){var map=this._poly._map,p1=map.project(marker1.getLatLng()),p2=map.project(marker2.getLatLng());return map.unproject(p1._add(p2)._divideBy(2));}});L.Polyline.addInitHook(function(){if(this.editing){return;}if(L.Edit.Poly){this.editing=new L.Edit.Poly(this);if(this.options.editable){this.editing.enable();}}this.on("add",function(){if(this.editing&&this.editing.enabled()){this.editing.addHooks();}});this.on("remove",function(){if(this.editing&&this.editing.enabled()){this.editing.removeHooks();}});});L.Edit=L.Edit||{};L.Edit.Marker=L.Handler.extend({initialize:function(marker,options){this._marker=marker;L.setOptions(this,options);},addHooks:function(){var marker=this._marker;marker.dragging.enable();marker.on("dragend",this._onDragEnd,marker);this._toggleMarkerHighlight();},removeHooks:function(){var marker=this._marker;marker.dragging.disable();marker.off("dragend",this._onDragEnd,marker);this._toggleMarkerHighlight();},_onDragEnd:function(e){var layer=e.target;layer.edited=true;this._map.fire(L.Draw.Event.EDITMOVE,{layer:layer});},_toggleMarkerHighlight:function(){var icon=this._marker._icon;if(!icon){return;}icon.style.display="none";if(L.DomUtil.hasClass(icon,"leaflet-edit-marker-selected")){L.DomUtil.removeClass(icon,"leaflet-edit-marker-selected");this._offsetMarker(icon,-4);}else{L.DomUtil.addClass(icon,"leaflet-edit-marker-selected");this._offsetMarker(icon,4);}icon.style.display="";},_offsetMarker:function(icon,offset){var iconMarginTop=parseInt(icon.style.marginTop,10)-offset,iconMarginLeft=parseInt(icon.style.marginLeft,10)-offset;icon.style.marginTop=iconMarginTop+"px";icon.style.marginLeft=iconMarginLeft+"px";}});L.Marker.addInitHook(function(){if(L.Edit.Marker){this.editing=new L.Edit.Marker(this);if(this.options.editable){this.editing.enable();}}});L.Edit=L.Edit||{};L.Edit.CircleMarker=L.Edit.SimpleShape.extend({_createMoveMarker:function(){var center=this._shape.getLatLng();this._moveMarker=this._createMarker(center,this.options.moveIcon);},_createResizeMarker:function(){this._resizeMarkers=[];},_move:function(latlng){if(this._resizeMarkers.length){var resizemarkerPoint=this._getResizeMarkerPoint(latlng);this._resizeMarkers[0].setLatLng(resizemarkerPoint);}this._shape.setLatLng(latlng);this._map.fire(L.Draw.Event.EDITMOVE,{layer:this._shape});},});L.CircleMarker.addInitHook(function(){if(L.Edit.CircleMarker){this.editing=new L.Edit.CircleMarker(this);if(this.options.editable){this.editing.enable();}}this.on("add",function(){if(this.editing&&this.editing.enabled()){this.editing.addHooks();}});this.on("remove",function(){if(this.editing&&this.editing.enabled()){this.editing.removeHooks();}});});L.Edit=L.Edit||{};L.Edit.Circle=L.Edit.CircleMarker.extend({_createResizeMarker:function(){var center=this._shape.getLatLng(),resizemarkerPoint=this._getResizeMarkerPoint(center);this._resizeMarkers=[];this._resizeMarkers.push(this._createMarker(resizemarkerPoint,this.options.resizeIcon));},_getResizeMarkerPoint:function(latlng){var delta=this._shape._radius*Math.cos(Math.PI/4),point=this._map.project(latlng);return this._map.unproject([point.x+delta,point.y-delta]);},_resize:function(latlng){var moveLatLng=this._moveMarker.getLatLng();if(L.GeometryUtil.isVersion07x()){radius=moveLatLng.distanceTo(latlng);}else{radius=this._map.distance(moveLatLng,latlng);}this._shape.setRadius(radius);if(this._map.editTooltip){this._map._editTooltip.updateContent({text:L.drawLocal.edit.handlers.edit.tooltip.subtext+"<br />"+L.drawLocal.edit.handlers.edit.tooltip.text,subtext:L.drawLocal.draw.handlers.circle.radius+": "+L.GeometryUtil.readableDistance(radius,true,this.options.feet,this.options.nautic)});}this._shape.setRadius(radius);this._map.fire(L.Draw.Event.EDITRESIZE,{layer:this._shape});}});L.Circle.addInitHook(function(){if(L.Edit.Circle){this.editing=new L.Edit.Circle(this);if(this.options.editable){this.editing.enable();}}this.on("add",function(){if(this.editing&&this.editing.enabled()){this.editing.addHooks();}});this.on("remove",function(){if(this.editing&&this.editing.enabled()){this.editing.removeHooks();}});});L.Edit=L.Edit||{};L.Edit.Rectangle=L.Edit.SimpleShape.extend({_createMoveMarker:function(){var bounds=this._shape.getBounds(),center=bounds.getCenter();this._moveMarker=this._createMarker(center,this.options.moveIcon);},_createResizeMarker:function(){var corners=this._getCorners();this._resizeMarkers=[];for(var i=0,l=corners.length;i<l;i++){this._resizeMarkers.push(this._createMarker(corners[i],this.options.resizeIcon));this._resizeMarkers[i]._cornerIndex=i;}},_onMarkerDragStart:function(e){L.Edit.SimpleShape.prototype._onMarkerDragStart.call(this,e);var corners=this._getCorners(),marker=e.target,currentCornerIndex=marker._cornerIndex;this._oppositeCorner=corners[(currentCornerIndex+2)%4];this._toggleCornerMarkers(0,currentCornerIndex);},_onMarkerDragEnd:function(e){var marker=e.target,bounds,center;if(marker===this._moveMarker){bounds=this._shape.getBounds();center=bounds.getCenter();marker.setLatLng(center);}this._toggleCornerMarkers(1);this._repositionCornerMarkers();L.Edit.SimpleShape.prototype._onMarkerDragEnd.call(this,e);},_move:function(newCenter){var latlngs=this._shape._defaultShape?this._shape._defaultShape():this._shape.getLatLngs(),bounds=this._shape.getBounds(),center=bounds.getCenter(),offset,newLatLngs=[];for(var i=0,l=latlngs.length;i<l;i++){offset=[latlngs[i].lat-center.lat,latlngs[i].lng-center.lng];newLatLngs.push([newCenter.lat+offset[0],newCenter.lng+offset[1]]);}this._shape.setLatLngs(newLatLngs);this._repositionCornerMarkers();this._map.fire(L.Draw.Event.EDITMOVE,{layer:this._shape});},_resize:function(latlng){var bounds;this._shape.setBounds(L.latLngBounds(latlng,this._oppositeCorner));bounds=this._shape.getBounds();this._moveMarker.setLatLng(bounds.getCenter());this._map.fire(L.Draw.Event.EDITRESIZE,{layer:this._shape});},_getCorners:function(){var bounds=this._shape.getBounds(),nw=bounds.getNorthWest(),ne=bounds.getNorthEast(),se=bounds.getSouthEast(),sw=bounds.getSouthWest();return[nw,ne,se,sw];},_toggleCornerMarkers:function(opacity){for(var i=0,l=this._resizeMarkers.length;i<l;i++){this._resizeMarkers[i].setOpacity(opacity);}},_repositionCornerMarkers:function(){var corners=this._getCorners();for(var i=0,l=this._resizeMarkers.length;i<l;i++){this._resizeMarkers[i].setLatLng(corners[i]);}}});L.Rectangle.addInitHook(function(){if(L.Edit.Rectangle){this.editing=new L.Edit.Rectangle(this);if(this.options.editable){this.editing.enable();}}});L.Draw=L.Draw||{};L.Draw.Feature=L.Handler.extend({initialize:function(map,options){this._map=map;this._container=map._container;this._overlayPane=map._panes.overlayPane;this._popupPane=map._panes.popupPane;if(options&&options.shapeOptions){options.shapeOptions=L.Util.extend({},this.options.shapeOptions,options.shapeOptions);}L.setOptions(this,options);var version=L.version.split(".");if(parseInt(version[0],10)===1&&parseInt(version[1],10)>=2){L.Draw.Feature.include(L.Evented.prototype);}else{L.Draw.Feature.include(L.Mixin.Events);}},enable:function(){if(this._enabled){return;}L.Handler.prototype.enable.call(this);this.fire("enabled",{handler:this.type});this._map.fire(L.Draw.Event.DRAWSTART,{layerType:this.type});},disable:function(){if(!this._enabled){return;}L.Handler.prototype.disable.call(this);this._map.fire(L.Draw.Event.DRAWSTOP,{layerType:this.type});this.fire("disabled",{handler:this.type});},addHooks:function(){var map=this._map;if(map){L.DomUtil.disableTextSelection();map.getContainer().focus();this._tooltip=new L.Draw.Tooltip(this._map);L.DomEvent.on(this._container,"keyup",this._cancelDrawing,this);}},removeHooks:function(){if(this._map){L.DomUtil.enableTextSelection();this._tooltip.dispose();this._tooltip=null;L.DomEvent.off(this._container,"keyup",this._cancelDrawing,this);}},setOptions:function(options){L.setOptions(this,options);},_fireCreatedEvent:function(layer){this._map.fire(L.Draw.Event.CREATED,{layer:layer,layerType:this.type});},_cancelDrawing:function(e){if(e.keyCode===27){this._map.fire("draw:canceled",{layerType:this.type});this.disable();}}});L.SimpleShape={};L.Draw.SimpleShape=L.Draw.Feature.extend({options:{repeatMode:false},initialize:function(map,options){this._endLabelText=L.drawLocal.draw.handlers.simpleshape.tooltip.end;L.Draw.Feature.prototype.initialize.call(this,map,options);},addHooks:function(){L.Draw.Feature.prototype.addHooks.call(this);if(this._map){this._mapDraggable=this._map.dragging.enabled();if(this._mapDraggable){this._map.dragging.disable();}this._container.style.cursor="crosshair";this._tooltip.updateContent({text:this._initialLabelText});this._map.on("mousedown",this._onMouseDown,this).on("mousemove",this._onMouseMove,this).on("touchstart",this._onMouseDown,this).on("touchmove",this._onMouseMove,this);document.addEventListener("touchstart",L.DomEvent.preventDefault,{passive:false});}},removeHooks:function(){L.Draw.Feature.prototype.removeHooks.call(this);if(this._map){if(this._mapDraggable){this._map.dragging.enable();}this._container.style.cursor="";this._map.off("mousedown",this._onMouseDown,this).off("mousemove",this._onMouseMove,this).off("touchstart",this._onMouseDown,this).off("touchmove",this._onMouseMove,this);L.DomEvent.off(document,"mouseup",this._onMouseUp,this);L.DomEvent.off(document,"touchend",this._onMouseUp,this);document.removeEventListener("touchstart",L.DomEvent.preventDefault);if(this._shape){this._map.removeLayer(this._shape);delete this._shape;}}this._isDrawing=false;},_getTooltipText:function(){return{text:this._endLabelText};},_onMouseDown:function(e){this._isDrawing=true;this._startLatLng=e.latlng;L.DomEvent.on(document,"mouseup",this._onMouseUp,this).on(document,"touchend",this._onMouseUp,this).preventDefault(e.originalEvent);},_onMouseMove:function(e){var latlng=e.latlng;this._tooltip.updatePosition(latlng);if(this._isDrawing){this._tooltip.updateContent(this._getTooltipText());this._drawShape(latlng);}},_onMouseUp:function(){if(this._shape){this._fireCreatedEvent();}this.disable();if(this.options.repeatMode){this.enable();}}});L.Draw.Marker=L.Draw.Feature.extend({statics:{TYPE:"marker"},options:{icon:new L.Icon.Default(),repeatMode:false,zIndexOffset:2000},initialize:function(map,options){this.type=L.Draw.Marker.TYPE;this._initialLabelText=L.drawLocal.draw.handlers.marker.tooltip.start;L.Draw.Feature.prototype.initialize.call(this,map,options);},addHooks:function(){L.Draw.Feature.prototype.addHooks.call(this);if(this._map){this._tooltip.updateContent({text:this._initialLabelText});if(!this._mouseMarker){this._mouseMarker=L.marker(this._map.getCenter(),{icon:L.divIcon({className:"leaflet-mouse-marker",iconAnchor:[20,20],iconSize:[40,40]}),opacity:0,zIndexOffset:this.options.zIndexOffset});}this._mouseMarker.on("click",this._onClick,this).addTo(this._map);this._map.on("mousemove",this._onMouseMove,this);this._map.on("click",this._onTouch,this);}},removeHooks:function(){L.Draw.Feature.prototype.removeHooks.call(this);if(this._map){this._map.off("click",this._onClick,this).off("click",this._onTouch,this);if(this._marker){this._marker.off("click",this._onClick,this);this._map.removeLayer(this._marker);delete this._marker;}this._mouseMarker.off("click",this._onClick,this);this._map.removeLayer(this._mouseMarker);delete this._mouseMarker;this._map.off("mousemove",this._onMouseMove,this);}},_onMouseMove:function(e){var latlng=e.latlng;this._tooltip.updatePosition(latlng);this._mouseMarker.setLatLng(latlng);if(!this._marker){this._marker=this._createMarker(latlng);this._marker.on("click",this._onClick,this);this._map.on("click",this._onClick,this).addLayer(this._marker);}else{latlng=this._mouseMarker.getLatLng();this._marker.setLatLng(latlng);}},_createMarker:function(latlng){return new L.Marker(latlng,{icon:this.options.icon,zIndexOffset:this.options.zIndexOffset});},_onClick:function(){this._fireCreatedEvent();this.disable();if(this.options.repeatMode){this.enable();}},_onTouch:function(e){this._onMouseMove(e);this._onClick();},_fireCreatedEvent:function(){var marker=new L.Marker.Touch(this._marker.getLatLng(),{icon:this.options.icon});L.Draw.Feature.prototype._fireCreatedEvent.call(this,marker);}});L.Draw.CircleMarker=L.Draw.Marker.extend({statics:{TYPE:"circlemarker"},options:{stroke:true,color:"#3388ff",weight:4,opacity:0.5,fill:true,fillColor:null,fillOpacity:0.2,clickable:true,zIndexOffset:2000},initialize:function(map,options){this.type=L.Draw.CircleMarker.TYPE;this._initialLabelText=L.drawLocal.draw.handlers.circlemarker.tooltip.start;L.Draw.Feature.prototype.initialize.call(this,map,options);},_fireCreatedEvent:function(){var circleMarker=new L.CircleMarker(this._marker.getLatLng(),this.options);L.Draw.Feature.prototype._fireCreatedEvent.call(this,circleMarker);},_createMarker:function(latlng){return new L.CircleMarker(latlng,this.options);}});L.Draw.Polyline=L.Draw.Feature.extend({statics:{TYPE:"polyline"},Poly:L.Polyline,options:{allowIntersection:true,repeatMode:false,drawError:{color:"#b00b00",timeout:2500},icon:new L.DivIcon({iconSize:new L.Point(8,8),className:"leaflet-div-icon leaflet-editing-icon"}),touchIcon:new L.DivIcon({iconSize:new L.Point(20,20),className:"leaflet-div-icon leaflet-editing-icon leaflet-touch-icon"}),guidelineDistance:20,maxGuideLineLength:4000,shapeOptions:{stroke:true,color:"#3388ff",weight:4,opacity:0.5,fill:false,clickable:true},metric:true,feet:true,nautic:false,showLength:true,zIndexOffset:2000,factor:1,maxPoints:0},initialize:function(map,options){if(L.Browser.touch){this.options.icon=this.options.touchIcon;}this.options.drawError.message=L.drawLocal.draw.handlers.polyline.error;if(options&&options.drawError){options.drawError=L.Util.extend({},this.options.drawError,options.drawError);}this.type=L.Draw.Polyline.TYPE;L.Draw.Feature.prototype.initialize.call(this,map,options);},addHooks:function(){L.Draw.Feature.prototype.addHooks.call(this);if(this._map){this._markers=[];this._markerGroup=new L.LayerGroup();this._map.addLayer(this._markerGroup);this._poly=new L.Polyline([],this.options.shapeOptions);this._tooltip.updateContent(this._getTooltipText());if(!this._mouseMarker){this._mouseMarker=L.marker(this._map.getCenter(),{icon:L.divIcon({className:"leaflet-mouse-marker",iconAnchor:[20,20],iconSize:[40,40]}),opacity:0,zIndexOffset:this.options.zIndexOffset});}this._mouseMarker.on("mouseout",this._onMouseOut,this).on("mousemove",this._onMouseMove,this).on("mousedown",this._onMouseDown,this).on("mouseup",this._onMouseUp,this).addTo(this._map);this._map.on("mouseup",this._onMouseUp,this).on("mousemove",this._onMouseMove,this).on("zoomlevelschange",this._onZoomEnd,this).on("touchstart",this._onTouch,this).on("zoomend",this._onZoomEnd,this);}},removeHooks:function(){L.Draw.Feature.prototype.removeHooks.call(this);this._clearHideErrorTimeout();this._cleanUpShape();this._map.removeLayer(this._markerGroup);delete this._markerGroup;delete this._markers;this._map.removeLayer(this._poly);delete this._poly;this._mouseMarker.off("mousedown",this._onMouseDown,this).off("mouseout",this._onMouseOut,this).off("mouseup",this._onMouseUp,this).off("mousemove",this._onMouseMove,this);this._map.removeLayer(this._mouseMarker);delete this._mouseMarker;this._clearGuides();this._map.off("mouseup",this._onMouseUp,this).off("mousemove",this._onMouseMove,this).off("zoomlevelschange",this._onZoomEnd,this).off("zoomend",this._onZoomEnd,this).off("touchstart",this._onTouch,this).off("click",this._onTouch,this);},deleteLastVertex:function(){if(this._markers.length<=1){return;}var lastMarker=this._markers.pop(),poly=this._poly,latlngs=poly.getLatLngs(),latlng=latlngs.splice(-1,1)[0];this._poly.setLatLngs(latlngs);this._markerGroup.removeLayer(lastMarker);if(poly.getLatLngs().length<2){this._map.removeLayer(poly);}this._vertexChanged(latlng,false);},addVertex:function(latlng){var markersLength=this._markers.length;if(markersLength>=2&&!this.options.allowIntersection&&this._poly.newLatLngIntersects(latlng)){this._showErrorTooltip();return;}else{if(this._errorShown){this._hideErrorTooltip();}}this._markers.push(this._createMarker(latlng));this._poly.addLatLng(latlng);if(this._poly.getLatLngs().length===2){this._map.addLayer(this._poly);}this._vertexChanged(latlng,true);},completeShape:function(){if(this._markers.length<=1){return;}this._fireCreatedEvent();this.disable();if(this.options.repeatMode){this.enable();}},_finishShape:function(){var latlngs=this._poly._defaultShape?this._poly._defaultShape():this._poly.getLatLngs();var intersects=this._poly.newLatLngIntersects(latlngs[latlngs.length-1]);if((!this.options.allowIntersection&&intersects)||!this._shapeIsValid()){this._showErrorTooltip();return;}this._fireCreatedEvent();this.disable();if(this.options.repeatMode){this.enable();}},_shapeIsValid:function(){return true;},_onZoomEnd:function(){if(this._markers!==null){this._updateGuide();}},_onMouseMove:function(e){var newPos=this._map.mouseEventToLayerPoint(e.originalEvent);var latlng=this._map.layerPointToLatLng(newPos);this._currentLatLng=latlng;this._updateTooltip(latlng);this._updateGuide(newPos);this._mouseMarker.setLatLng(latlng);L.DomEvent.preventDefault(e.originalEvent);},_vertexChanged:function(latlng,added){this._map.fire(L.Draw.Event.DRAWVERTEX,{layers:this._markerGroup});this._updateFinishHandler();this._updateRunningMeasure(latlng,added);this._clearGuides();this._updateTooltip();},_onMouseDown:function(e){if(!this._clickHandled&&!this._touchHandled&&!this._disableMarkers){this._onMouseMove(e);this._clickHandled=true;this._disableNewMarkers();var originalEvent=e.originalEvent;var clientX=originalEvent.clientX;var clientY=originalEvent.clientY;this._startPoint.call(this,clientX,clientY);}},_startPoint:function(clientX,clientY){this._mouseDownOrigin=L.point(clientX,clientY);},_onMouseUp:function(e){var originalEvent=e.originalEvent;var clientX=originalEvent.clientX;var clientY=originalEvent.clientY;this._endPoint.call(this,clientX,clientY,e);this._clickHandled=null;},_endPoint:function(clientX,clientY,e){if(this._mouseDownOrigin){var dragCheckDistance=L.point(clientX,clientY).distanceTo(this._mouseDownOrigin);var lastPtDistance=this._calculateFinishDistance(e.latlng);if(this.options.maxPoints>1&&this.options.maxPoints==this._markers.length+1){this.addVertex(e.latlng);this._finishShape();}else{if(lastPtDistance<10&&L.Browser.touch){this._finishShape();}else{if(Math.abs(dragCheckDistance)<9*(window.devicePixelRatio||1)){this.addVertex(e.latlng);}}}this._enableNewMarkers();}this._mouseDownOrigin=null;},_onTouch:function(e){var originalEvent=e.originalEvent;var clientX;var clientY;if(originalEvent.touches&&originalEvent.touches[0]&&!this._clickHandled&&!this._touchHandled&&!this._disableMarkers){clientX=originalEvent.touches[0].clientX;clientY=originalEvent.touches[0].clientY;this._disableNewMarkers();this._touchHandled=true;this._startPoint.call(this,clientX,clientY);this._endPoint.call(this,clientX,clientY,e);this._touchHandled=null;}this._clickHandled=null;},_onMouseOut:function(){if(this._tooltip){this._tooltip._onMouseOut.call(this._tooltip);}},_calculateFinishDistance:function(potentialLatLng){var lastPtDistance;if(this._markers.length>0){var finishMarker;if(this.type===L.Draw.Polyline.TYPE){finishMarker=this._markers[this._markers.length-1];}else{if(this.type===L.Draw.Polygon.TYPE){finishMarker=this._markers[0];}else{return Infinity;}}var lastMarkerPoint=this._map.latLngToContainerPoint(finishMarker.getLatLng()),potentialMarker=new L.Marker(potentialLatLng,{icon:this.options.icon,zIndexOffset:this.options.zIndexOffset*2});var potentialMarkerPint=this._map.latLngToContainerPoint(potentialMarker.getLatLng());lastPtDistance=lastMarkerPoint.distanceTo(potentialMarkerPint);}else{lastPtDistance=Infinity;}return lastPtDistance;},_updateFinishHandler:function(){var markerCount=this._markers.length;if(markerCount>1){this._markers[markerCount-1].on("click",this._finishShape,this);}if(markerCount>2){this._markers[markerCount-2].off("click",this._finishShape,this);}},_createMarker:function(latlng){var marker=new L.Marker(latlng,{icon:this.options.icon,zIndexOffset:this.options.zIndexOffset*2});this._markerGroup.addLayer(marker);return marker;},_updateGuide:function(newPos){var markerCount=this._markers?this._markers.length:0;if(markerCount>0){newPos=newPos||this._map.latLngToLayerPoint(this._currentLatLng);this._clearGuides();this._drawGuide(this._map.latLngToLayerPoint(this._markers[markerCount-1].getLatLng()),newPos);}},_updateTooltip:function(latLng){var text=this._getTooltipText();if(latLng){this._tooltip.updatePosition(latLng);}if(!this._errorShown){this._tooltip.updateContent(text);}},_drawGuide:function(pointA,pointB){var length=Math.floor(Math.sqrt(Math.pow((pointB.x-pointA.x),2)+Math.pow((pointB.y-pointA.y),2))),guidelineDistance=this.options.guidelineDistance,maxGuideLineLength=this.options.maxGuideLineLength,i=length>maxGuideLineLength?length-maxGuideLineLength:guidelineDistance,fraction,dashPoint,dash;if(!this._guidesContainer){this._guidesContainer=L.DomUtil.create("div","leaflet-draw-guides",this._overlayPane);}for(;i<length;i+=this.options.guidelineDistance){fraction=i/length;dashPoint={x:Math.floor((pointA.x*(1-fraction))+(fraction*pointB.x)),y:Math.floor((pointA.y*(1-fraction))+(fraction*pointB.y))};dash=L.DomUtil.create("div","leaflet-draw-guide-dash",this._guidesContainer);dash.style.backgroundColor=!this._errorShown?this.options.shapeOptions.color:this.options.drawError.color;L.DomUtil.setPosition(dash,dashPoint);}},_updateGuideColor:function(color){if(this._guidesContainer){for(var i=0,l=this._guidesContainer.childNodes.length;i<l;i++){this._guidesContainer.childNodes[i].style.backgroundColor=color;}}},_clearGuides:function(){if(this._guidesContainer){while(this._guidesContainer.firstChild){this._guidesContainer.removeChild(this._guidesContainer.firstChild);}}},_getTooltipText:function(){var showLength=this.options.showLength,labelText,distanceStr;if(this._markers.length===0){labelText={text:L.drawLocal.draw.handlers.polyline.tooltip.start};}else{distanceStr=showLength?this._getMeasurementString():"";if(this._markers.length===1){labelText={text:L.drawLocal.draw.handlers.polyline.tooltip.cont,subtext:distanceStr};}else{labelText={text:L.drawLocal.draw.handlers.polyline.tooltip.end,subtext:distanceStr};}}return labelText;},_updateRunningMeasure:function(latlng,added){var markersLength=this._markers.length,previousMarkerIndex,distance;if(this._markers.length===1){this._measurementRunningTotal=0;}else{previousMarkerIndex=markersLength-(added?2:1);if(L.GeometryUtil.isVersion07x()){distance=latlng.distanceTo(this._markers[previousMarkerIndex].getLatLng())*(this.options.factor||1);}else{distance=this._map.distance(latlng,this._markers[previousMarkerIndex].getLatLng())*(this.options.factor||1);}this._measurementRunningTotal+=distance*(added?1:-1);}},_getMeasurementString:function(){var currentLatLng=this._currentLatLng,previousLatLng=this._markers[this._markers.length-1].getLatLng(),distance;if(L.GeometryUtil.isVersion07x()){distance=previousLatLng&&currentLatLng&&currentLatLng.distanceTo?this._measurementRunningTotal+currentLatLng.distanceTo(previousLatLng)*(this.options.factor||1):this._measurementRunningTotal||0;}else{distance=previousLatLng&&currentLatLng?this._measurementRunningTotal+this._map.distance(currentLatLng,previousLatLng)*(this.options.factor||1):this._measurementRunningTotal||0;}return L.GeometryUtil.readableDistance(distance,this.options.metric,this.options.feet,this.options.nautic,this.options.precision);},_showErrorTooltip:function(){this._errorShown=true;this._tooltip.showAsError().updateContent({text:this.options.drawError.message});this._updateGuideColor(this.options.drawError.color);this._poly.setStyle({color:this.options.drawError.color});this._clearHideErrorTimeout();this._hideErrorTimeout=setTimeout(L.Util.bind(this._hideErrorTooltip,this),this.options.drawError.timeout);},_hideErrorTooltip:function(){this._errorShown=false;this._clearHideErrorTimeout();this._tooltip.removeError().updateContent(this._getTooltipText());this._updateGuideColor(this.options.shapeOptions.color);this._poly.setStyle({color:this.options.shapeOptions.color});},_clearHideErrorTimeout:function(){if(this._hideErrorTimeout){clearTimeout(this._hideErrorTimeout);this._hideErrorTimeout=null;}},_disableNewMarkers:function(){this._disableMarkers=true;},_enableNewMarkers:function(){setTimeout(function(){this._disableMarkers=false;}.bind(this),50);},_cleanUpShape:function(){if(this._markers.length>1){this._markers[this._markers.length-1].off("click",this._finishShape,this);}},_fireCreatedEvent:function(){var poly=new this.Poly(this._poly.getLatLngs(),this.options.shapeOptions);L.Draw.Feature.prototype._fireCreatedEvent.call(this,poly);}});L.Draw.Polygon=L.Draw.Polyline.extend({statics:{TYPE:"polygon"},Poly:L.Polygon,options:{showArea:false,showLength:false,shapeOptions:{stroke:true,color:"#3388ff",weight:4,opacity:0.5,fill:true,fillColor:null,fillOpacity:0.2,clickable:true},metric:true,feet:true,nautic:false,precision:{}},initialize:function(map,options){L.Draw.Polyline.prototype.initialize.call(this,map,options);this.type=L.Draw.Polygon.TYPE;},_updateFinishHandler:function(){var markerCount=this._markers.length;if(markerCount===1){this._markers[0].on("click",this._finishShape,this);}if(markerCount>2){this._markers[markerCount-1].on("dblclick",this._finishShape,this);if(markerCount>3){this._markers[markerCount-2].off("dblclick",this._finishShape,this);}}},_getTooltipText:function(){var text,subtext;if(this._markers.length===0){text=L.drawLocal.draw.handlers.polygon.tooltip.start;}else{if(this._markers.length<3){text=L.drawLocal.draw.handlers.polygon.tooltip.cont;subtext=this._getMeasurementString();}else{text=L.drawLocal.draw.handlers.polygon.tooltip.end;subtext=this._getMeasurementString();}}return{text:text,subtext:subtext};},_getMeasurementString:function(){var area=this._area,measurementString="";if(!area&&!this.options.showLength){return null;}if(this.options.showLength){measurementString=L.Draw.Polyline.prototype._getMeasurementString.call(this);}if(area){measurementString+="<br>"+L.GeometryUtil.readableArea(area,this.options.metric,this.options.precision);}return measurementString;},_shapeIsValid:function(){return this._markers.length>=3;},_vertexChanged:function(latlng,added){var latLngs;if(!this.options.allowIntersection&&this.options.showArea){latLngs=this._poly.getLatLngs();this._area=L.GeometryUtil.geodesicArea(latLngs);}L.Draw.Polyline.prototype._vertexChanged.call(this,latlng,added);},_cleanUpShape:function(){var markerCount=this._markers.length;if(markerCount>0){this._markers[0].off("click",this._finishShape,this);if(markerCount>2){this._markers[markerCount-1].off("dblclick",this._finishShape,this);}}}});L.Draw.Rectangle=L.Draw.SimpleShape.extend({statics:{TYPE:"rectangle"},options:{shapeOptions:{stroke:true,color:"#3388ff",weight:4,opacity:0.5,fill:true,fillColor:null,fillOpacity:0.2,showArea:true,clickable:true},metric:true},initialize:function(map,options){this.type=L.Draw.Rectangle.TYPE;this._initialLabelText=L.drawLocal.draw.handlers.rectangle.tooltip.start;L.Draw.SimpleShape.prototype.initialize.call(this,map,options);},disable:function(){if(!this._enabled){return;}this._isCurrentlyTwoClickDrawing=false;L.Draw.SimpleShape.prototype.disable.call(this);},_onMouseUp:function(e){if(!this._shape&&!this._isCurrentlyTwoClickDrawing){this._isCurrentlyTwoClickDrawing=true;return;}if(this._isCurrentlyTwoClickDrawing&&!_hasAncestor(e.target,"leaflet-pane")){return;}L.Draw.SimpleShape.prototype._onMouseUp.call(this);},_drawShape:function(latlng){if(!this._shape){this._shape=new L.Rectangle(new L.LatLngBounds(this._startLatLng,latlng),this.options.shapeOptions);this._map.addLayer(this._shape);}else{this._shape.setBounds(new L.LatLngBounds(this._startLatLng,latlng));}},_fireCreatedEvent:function(){var rectangle=new L.Rectangle(this._shape.getBounds(),this.options.shapeOptions);L.Draw.SimpleShape.prototype._fireCreatedEvent.call(this,rectangle);},_getTooltipText:function(){var tooltipText=L.Draw.SimpleShape.prototype._getTooltipText.call(this),shape=this._shape,showArea=this.options.showArea,latLngs,area,subtext;if(shape){latLngs=this._shape._defaultShape?this._shape._defaultShape():this._shape.getLatLngs();area=L.GeometryUtil.geodesicArea(latLngs);subtext=showArea?L.GeometryUtil.readableArea(area,this.options.metric):"";}return{text:tooltipText.text,subtext:subtext};}});function _hasAncestor(el,cls){while((el=el.parentElement)&&!el.classList.contains(cls)){}return el;}L.Draw.Circle=L.Draw.SimpleShape.extend({statics:{TYPE:"circle"},options:{shapeOptions:{stroke:true,color:"#3388ff",weight:4,opacity:0.5,fill:true,fillColor:null,fillOpacity:0.2,clickable:true},showRadius:true,metric:true,feet:true,nautic:false},initialize:function(map,options){this.type=L.Draw.Circle.TYPE;this._initialLabelText=L.drawLocal.draw.handlers.circle.tooltip.start;L.Draw.SimpleShape.prototype.initialize.call(this,map,options);},_drawShape:function(latlng){if(!this._shape){this._shape=new L.Circle(this._startLatLng,this._startLatLng.distanceTo(latlng),this.options.shapeOptions);this._map.addLayer(this._shape);}else{this._shape.setRadius(this._startLatLng.distanceTo(latlng));}},_fireCreatedEvent:function(){var circle=new L.Circle(this._startLatLng,this._shape.getRadius(),this.options.shapeOptions);L.Draw.SimpleShape.prototype._fireCreatedEvent.call(this,circle);},_onMouseMove:function(e){var latlng=e.latlng,showRadius=this.options.showRadius,useMetric=this.options.metric,radius;this._tooltip.updatePosition(latlng);if(this._isDrawing){this._drawShape(latlng);radius=this._shape.getRadius().toFixed(1);var subtext="";if(showRadius){subtext=L.drawLocal.draw.handlers.circle.radius+": "+L.GeometryUtil.readableDistance(radius,useMetric,this.options.feet,this.options.nautic);}this._tooltip.updateContent({text:this._endLabelText,subtext:subtext});}}});L.Map.mergeOptions({touchExtend:true});L.Map.TouchExtend=L.Handler.extend({initialize:function(map){this._map=map;this._container=map._container;this._pane=map._panes.overlayPane;},addHooks:function(){L.DomEvent.on(this._container,"touchstart",this._onTouchStart,this);L.DomEvent.on(this._container,"touchend",this._onTouchEnd,this);L.DomEvent.on(this._container,"touchmove",this._onTouchMove,this);if(this._detectIE()){L.DomEvent.on(this._container,"MSPointerDown",this._onTouchStart,this);L.DomEvent.on(this._container,"MSPointerUp",this._onTouchEnd,this);L.DomEvent.on(this._container,"MSPointerMove",this._onTouchMove,this);L.DomEvent.on(this._container,"MSPointerCancel",this._onTouchCancel,this);}else{L.DomEvent.on(this._container,"touchcancel",this._onTouchCancel,this);L.DomEvent.on(this._container,"touchleave",this._onTouchLeave,this);}},removeHooks:function(){L.DomEvent.off(this._container,"touchstart",this._onTouchStart);L.DomEvent.off(this._container,"touchend",this._onTouchEnd);L.DomEvent.off(this._container,"touchmove",this._onTouchMove);if(this._detectIE()){L.DomEvent.off(this._container,"MSPointerDowm",this._onTouchStart);L.DomEvent.off(this._container,"MSPointerUp",this._onTouchEnd);L.DomEvent.off(this._container,"MSPointerMove",this._onTouchMove);L.DomEvent.off(this._container,"MSPointerCancel",this._onTouchCancel);}else{L.DomEvent.off(this._container,"touchcancel",this._onTouchCancel);L.DomEvent.off(this._container,"touchleave",this._onTouchLeave);}},_touchEvent:function(e,type){var touchEvent={};if(typeof e.touches!=="undefined"){if(!e.touches.length){return;}touchEvent=e.touches[0];}else{if(e.pointerType==="touch"){touchEvent=e;if(!this._filterClick(e)){return;}}else{return;}}var containerPoint=this._map.mouseEventToContainerPoint(touchEvent),layerPoint=this._map.mouseEventToLayerPoint(touchEvent),latlng=this._map.layerPointToLatLng(layerPoint);this._map.fire(type,{latlng:latlng,layerPoint:layerPoint,containerPoint:containerPoint,pageX:touchEvent.pageX,pageY:touchEvent.pageY,originalEvent:e});},_filterClick:function(e){var timeStamp=(e.timeStamp||e.originalEvent.timeStamp),elapsed=L.DomEvent._lastClick&&(timeStamp-L.DomEvent._lastClick);if((elapsed&&elapsed>100&&elapsed<500)||(e.target._simulatedClick&&!e._simulated)){L.DomEvent.stop(e);return false;}L.DomEvent._lastClick=timeStamp;return true;},_onTouchStart:function(e){if(!this._map._loaded){return;}var type="touchstart";this._touchEvent(e,type);},_onTouchEnd:function(e){if(!this._map._loaded){return;}var type="touchend";this._touchEvent(e,type);},_onTouchCancel:function(e){if(!this._map._loaded){return;}var type="touchcancel";if(this._detectIE()){type="pointercancel";}this._touchEvent(e,type);},_onTouchLeave:function(e){if(!this._map._loaded){return;}var type="touchleave";this._touchEvent(e,type);},_onTouchMove:function(e){if(!this._map._loaded){return;}var type="touchmove";this._touchEvent(e,type);},_detectIE:function(){var ua=window.navigator.userAgent;var msie=ua.indexOf("MSIE ");if(msie>0){return parseInt(ua.substring(msie+5,ua.indexOf(".",msie)),10);}var trident=ua.indexOf("Trident/");if(trident>0){var rv=ua.indexOf("rv:");return parseInt(ua.substring(rv+3,ua.indexOf(".",rv)),10);}var edge=ua.indexOf("Edge/");if(edge>0){return parseInt(ua.substring(edge+5,ua.indexOf(".",edge)),10);}return false;}});L.Map.addInitHook("addHandler","touchExtend",L.Map.TouchExtend);L.Marker.Touch=L.Marker.extend({_initInteraction:function(){if(!this.addInteractiveTarget){return this._initInteractionLegacy();}return L.Marker.prototype._initInteraction.apply(this);},_initInteractionLegacy:function(){if(!this.options.clickable){return;}var icon=this._icon,events=["dblclick","mousedown","mouseover","mouseout","contextmenu","touchstart","touchend","touchmove"];if(this._detectIE){events.concat(["MSPointerDown","MSPointerUp","MSPointerMove","MSPointerCancel"]);}else{events.concat(["touchcancel"]);}L.DomUtil.addClass(icon,"leaflet-clickable");L.DomEvent.on(icon,"click",this._onMouseClick,this);L.DomEvent.on(icon,"keypress",this._onKeyPress,this);for(var i=0;i<events.length;i++){L.DomEvent.on(icon,events[i],this._fireMouseEvent,this);}if(L.Handler.MarkerDrag){this.dragging=new L.Handler.MarkerDrag(this);if(this.options.draggable){this.dragging.enable();}}},_detectIE:function(){var ua=window.navigator.userAgent;var msie=ua.indexOf("MSIE ");if(msie>0){return parseInt(ua.substring(msie+5,ua.indexOf(".",msie)),10);}var trident=ua.indexOf("Trident/");if(trident>0){var rv=ua.indexOf("rv:");return parseInt(ua.substring(rv+3,ua.indexOf(".",rv)),10);}var edge=ua.indexOf("Edge/");if(edge>0){return parseInt(ua.substring(edge+5,ua.indexOf(".",edge)),10);}return false;}});L.LatLngUtil={cloneLatLngs:function(latlngs){var clone=[];for(var i=0,l=latlngs.length;i<l;i++){if(Array.isArray(latlngs[i])){clone.push(L.LatLngUtil.cloneLatLngs(latlngs[i]));}else{clone.push(this.cloneLatLng(latlngs[i]));}}return clone;},cloneLatLng:function(latlng){return L.latLng(latlng.lat,latlng.lng);}};var L_GeometryUtilMode="NORMAL";(function(){var defaultPrecision={km:4,ha:2,m:0,mi:4,ac:2,yd:0,ft:0,nm:2};L.GeometryUtil=L.extend(L.GeometryUtil||{},{geodesicArea:function(latLngs){var pointsCount=latLngs.length,area=0,d2r=Math.PI/180,p1,p2;if(pointsCount>2){for(var i=0;i<pointsCount;i++){p1=latLngs[i];p2=latLngs[(i+1)%pointsCount];area+=((p2.lng-p1.lng)*d2r)*(2+Math.sin(p1.lat*d2r)+Math.sin(p2.lat*d2r));}area=area*6378137*6378137/2;}return Math.abs(area);},formattedNumber:function(n,precision){var formatted=parseFloat(n).toFixed(precision),format=L.drawLocal.format&&L.drawLocal.format.numeric,delimiters=format&&format.delimiters,thousands=delimiters&&delimiters.thousands,decimal=delimiters&&delimiters.decimal;if(thousands||decimal){var splitValue=formatted.split(".");formatted=thousands?splitValue[0].replace(/(\d)(?=(\d{3})+(?!\d))/g,"$1"+thousands):splitValue[0];decimal=decimal||".";if(splitValue.length>1){formatted=formatted+decimal+splitValue[1];}}return formatted;},readableArea:function(area,isMetric,precision){var areaStr,units,precision=L.Util.extend({},defaultPrecision,precision);if(isMetric){units=["ha","m"];type=typeof isMetric;if(type==="string"){units=[isMetric];}else{if(type!=="boolean"){units=isMetric;}}if(L_GeometryUtilMode==="KM_M_MI"){if(area>=10000&&units.indexOf("km")!==-1){areaStr=L.GeometryUtil.formattedNumber(area*0.000001,precision.km)+" km<sup>2</sup>";}else{areaStr=L.GeometryUtil.formattedNumber(area,precision.m)+" m<sup>2</sup>";}}else{if(area>=1000000&&units.indexOf("km")!==-1){areaStr=L.GeometryUtil.formattedNumber(area*0.000001,precision.km)+" km<sup>2</sup>";}else{if(area>=10000&&units.indexOf("ha")!==-1){areaStr=L.GeometryUtil.formattedNumber(area*0.0001,precision.ha)+" ha";}else{areaStr=L.GeometryUtil.formattedNumber(area,precision.m)+" m<sup>2</sup>";}}}}else{area/=0.836127;if(L_GeometryUtilMode==="KM_M_MI"){areaStr=L.GeometryUtil.formattedNumber(area/3097600,precision.mi)+" mi<sup>2</sup>";}else{if(area>=3097600){areaStr=L.GeometryUtil.formattedNumber(area/3097600,precision.mi)+" mi<sup>2</sup>";}else{if(area>=4840){areaStr=L.GeometryUtil.formattedNumber(area/4840,precision.ac)+" acres";}else{areaStr=L.GeometryUtil.formattedNumber(area,precision.yd)+" yd<sup>2</sup>";}}}}return areaStr;},readableDistance:function(distance,isMetric,isFeet,isNauticalMile,precision){var distanceStr,units,precision=L.Util.extend({},defaultPrecision,precision);if(isMetric){units=typeof isMetric=="string"?isMetric:"metric";}else{if(isFeet){units="feet";}else{if(isNauticalMile){units="nauticalMile";}else{units="yards";}}}switch(units){case"metric":if(distance>1000){distanceStr=L.GeometryUtil.formattedNumber(distance/1000,precision.km)+" km";}else{distanceStr=L.GeometryUtil.formattedNumber(distance,precision.m)+" m";}break;case"feet":distance*=1.09361*3;distanceStr=L.GeometryUtil.formattedNumber(distance,precision.ft)+" ft";break;case"nauticalMile":distance*=0.53996;distanceStr=L.GeometryUtil.formattedNumber(distance/1000,precision.nm)+" nm";break;case"yards":default:distance*=1.09361;if(L_GeometryUtilMode==="KM_M_MI"){distanceStr=L.GeometryUtil.formattedNumber(distance/1760,precision.mi)+" miles";}else{if(distance>1760){distanceStr=L.GeometryUtil.formattedNumber(distance/1760,precision.mi)+" miles";}else{distanceStr=L.GeometryUtil.formattedNumber(distance,precision.yd)+" yd";}}break;}return distanceStr;},isVersion07x:function(){var version=L.version.split(".");return parseInt(version[0],10)===0&&parseInt(version[1],10)===7;},});})();L.Util.extend(L.LineUtil,{segmentsIntersect:function(p,p1,p2,p3){return this._checkCounterclockwise(p,p2,p3)!==this._checkCounterclockwise(p1,p2,p3)&&this._checkCounterclockwise(p,p1,p2)!==this._checkCounterclockwise(p,p1,p3);},_checkCounterclockwise:function(p,p1,p2){return(p2.y-p.y)*(p1.x-p.x)>(p1.y-p.y)*(p2.x-p.x);}});L.Polyline.include({intersects:function(){var points=this._getProjectedPoints(),len=points?points.length:0,i,p,p1;if(this._tooFewPointsForIntersection()){return false;}for(i=len-1;i>=3;i--){p=points[i-1];p1=points[i];if(this._lineSegmentsIntersectsRange(p,p1,i-2)){return true;}}return false;},newLatLngIntersects:function(latlng,skipFirst){if(!this._map){return false;}return this.newPointIntersects(this._map.latLngToLayerPoint(latlng),skipFirst);},newPointIntersects:function(newPoint,skipFirst){var points=this._getProjectedPoints(),len=points?points.length:0,lastPoint=points?points[len-1]:null,maxIndex=len-2;if(this._tooFewPointsForIntersection(1)){return false;}return this._lineSegmentsIntersectsRange(lastPoint,newPoint,maxIndex,skipFirst?1:0);},_tooFewPointsForIntersection:function(extraPoints){var points=this._getProjectedPoints(),len=points?points.length:0;len+=extraPoints||0;return !points||len<=3;},_lineSegmentsIntersectsRange:function(p,p1,maxIndex,minIndex){var points=this._getProjectedPoints(),p2,p3;minIndex=minIndex||0;for(var j=maxIndex;j>minIndex;j--){p2=points[j-1];p3=points[j];if(L.LineUtil.segmentsIntersect(p,p1,p2,p3)){return true;}}return false;},_getProjectedPoints:function(){if(!this._defaultShape){return this._originalPoints;}var points=[],_shape=this._defaultShape();for(var i=0;i<_shape.length;i++){points.push(this._map.latLngToLayerPoint(_shape[i]));}return points;}});L.Polygon.include({intersects:function(){var polylineIntersects,points=this._getProjectedPoints(),len,firstPoint,lastPoint,maxIndex;if(this._tooFewPointsForIntersection()){return false;}polylineIntersects=L.Polyline.prototype.intersects.call(this);if(polylineIntersects){return true;}len=points.length;firstPoint=points[0];lastPoint=points[len-1];maxIndex=len-2;return this._lineSegmentsIntersectsRange(lastPoint,firstPoint,maxIndex,1);}});L.Control.Draw=L.Control.extend({options:{position:"topleft",draw:{},edit:false},initialize:function(options){if(L.version<"0.7"){throw new Error("Leaflet.draw 0.2.3+ requires Leaflet 0.7.0+. Download latest from https://github.com/Leaflet/Leaflet/");}L.Control.prototype.initialize.call(this,options);var toolbar;this._toolbars={};if(L.DrawToolbar&&this.options.draw){toolbar=new L.DrawToolbar(this.options.draw);this._toolbars[L.DrawToolbar.TYPE]=toolbar;this._toolbars[L.DrawToolbar.TYPE].on("enable",this._toolbarEnabled,this);}if(L.EditToolbar&&this.options.edit){toolbar=new L.EditToolbar(this.options.edit);this._toolbars[L.EditToolbar.TYPE]=toolbar;this._toolbars[L.EditToolbar.TYPE].on("enable",this._toolbarEnabled,this);}L.toolbar=this;},onAdd:function(map){var container=L.DomUtil.create("div","leaflet-draw"),addedTopClass=false,topClassName="leaflet-draw-toolbar-top",toolbarContainer;for(var toolbarId in this._toolbars){if(this._toolbars.hasOwnProperty(toolbarId)){toolbarContainer=this._toolbars[toolbarId].addToolbar(map);if(toolbarContainer){if(!addedTopClass){if(!L.DomUtil.hasClass(toolbarContainer,topClassName)){L.DomUtil.addClass(toolbarContainer.childNodes[0],topClassName);}addedTopClass=true;}container.appendChild(toolbarContainer);}}}return container;},onRemove:function(){for(var toolbarId in this._toolbars){if(this._toolbars.hasOwnProperty(toolbarId)){this._toolbars[toolbarId].removeToolbar();}}},setDrawingOptions:function(options){for(var toolbarId in this._toolbars){if(this._toolbars[toolbarId] instanceof L.DrawToolbar){this._toolbars[toolbarId].setOptions(options);}}},_toolbarEnabled:function(e){var enabledToolbar=e.target;for(var toolbarId in this._toolbars){if(this._toolbars[toolbarId]!==enabledToolbar){this._toolbars[toolbarId].disable();}}}});L.Map.mergeOptions({drawControlTooltips:true,drawControl:false});L.Map.addInitHook(function(){if(this.options.drawControl){this.drawControl=new L.Control.Draw();this.addControl(this.drawControl);}});L.Draw=L.Draw||{};L.Draw.Tooltip=L.Class.extend({initialize:function(map){this._map=map;this._popupPane=map._panes.popupPane;this._visible=false;this._container=map.options.drawControlTooltips?L.DomUtil.create("div","leaflet-draw-tooltip",this._popupPane):null;this._singleLineLabel=false;this._map.on("mouseout",this._onMouseOut,this);},dispose:function(){this._map.off("mouseout",this._onMouseOut,this);if(this._container){this._popupPane.removeChild(this._container);this._container=null;}},updateContent:function(labelText){if(!this._container){return this;}labelText.subtext=labelText.subtext||"";if(labelText.subtext.length===0&&!this._singleLineLabel){L.DomUtil.addClass(this._container,"leaflet-draw-tooltip-single");this._singleLineLabel=true;}else{if(labelText.subtext.length>0&&this._singleLineLabel){L.DomUtil.removeClass(this._container,"leaflet-draw-tooltip-single");this._singleLineLabel=false;}}this._container.innerHTML=(labelText.subtext.length>0?'<span class="leaflet-draw-tooltip-subtext">'+labelText.subtext+"</span><br />":"")+"<span>"+labelText.text+"</span>";if(!labelText.text&&!labelText.subtext){this._visible=false;this._container.style.visibility="hidden";}else{this._visible=true;this._container.style.visibility="inherit";}return this;},updatePosition:function(latlng){var pos=this._map.latLngToLayerPoint(latlng),tooltipContainer=this._container;if(this._container){if(this._visible){tooltipContainer.style.visibility="inherit";}L.DomUtil.setPosition(tooltipContainer,pos);}return this;},showAsError:function(){if(this._container){L.DomUtil.addClass(this._container,"leaflet-error-draw-tooltip");}return this;},removeError:function(){if(this._container){L.DomUtil.removeClass(this._container,"leaflet-error-draw-tooltip");}return this;},_onMouseOut:function(){if(this._container){this._container.style.visibility="hidden";}}});L.Toolbar=L.Class.extend({initialize:function(options){L.setOptions(this,options);this._modes={};this._actionButtons=[];this._activeMode=null;var version=L.version.split(".");if(parseInt(version[0],10)===1&&parseInt(version[1],10)>=2){L.Toolbar.include(L.Evented.prototype);}else{L.Toolbar.include(L.Mixin.Events);}},enabled:function(){return this._activeMode!==null;},disable:function(){if(!this.enabled()){return;}this._activeMode.handler.disable();},addToolbar:function(map){var container=L.DomUtil.create("div","leaflet-draw-section"),buttonIndex=0,buttonClassPrefix=this._toolbarClass||"",modeHandlers=this.getModeHandlers(map),i;this._toolbarContainer=L.DomUtil.create("div","leaflet-draw-toolbar leaflet-bar");this._map=map;for(i=0;i<modeHandlers.length;i++){if(modeHandlers[i].enabled){this._initModeHandler(modeHandlers[i].handler,this._toolbarContainer,buttonIndex++,buttonClassPrefix,modeHandlers[i].title);}}if(!buttonIndex){return;}this._lastButtonIndex=--buttonIndex;this._actionsContainer=L.DomUtil.create("ul","leaflet-draw-actions");container.appendChild(this._toolbarContainer);container.appendChild(this._actionsContainer);return container;},removeToolbar:function(){for(var handlerId in this._modes){if(this._modes.hasOwnProperty(handlerId)){this._disposeButton(this._modes[handlerId].button,this._modes[handlerId].handler.enable,this._modes[handlerId].handler);this._modes[handlerId].handler.disable();this._modes[handlerId].handler.off("enabled",this._handlerActivated,this).off("disabled",this._handlerDeactivated,this);}}this._modes={};for(var i=0,l=this._actionButtons.length;i<l;i++){this._disposeButton(this._actionButtons[i].button,this._actionButtons[i].callback,this);}this._actionButtons=[];this._actionsContainer=null;},_initModeHandler:function(handler,container,buttonIndex,classNamePredix,buttonTitle){var type=handler.type;this._modes[type]={};this._modes[type].handler=handler;this._modes[type].button=this._createButton({type:type,title:buttonTitle,className:classNamePredix+"-"+type,container:container,callback:this._modes[type].handler.enable,context:this._modes[type].handler});this._modes[type].buttonIndex=buttonIndex;this._modes[type].handler.on("enabled",this._handlerActivated,this).on("disabled",this._handlerDeactivated,this);},_detectIOS:function(){var iOS=(/iPad|iPhone|iPod/.test(navigator.userAgent)&&!window.MSStream);return iOS;},_createButton:function(options){var link=L.DomUtil.create("a",options.className||"",options.container);var sr=L.DomUtil.create("span","sr-only",options.container);link.href="#";link.appendChild(sr);if(options.title){link.title=options.title;sr.innerHTML=options.title;}if(options.text){link.innerHTML=options.text;sr.innerHTML=options.text;}var buttonEvent=this._detectIOS()?"touchstart":"click";L.DomEvent.on(link,"click",L.DomEvent.stopPropagation).on(link,"mousedown",L.DomEvent.stopPropagation).on(link,"dblclick",L.DomEvent.stopPropagation).on(link,"touchstart",L.DomEvent.stopPropagation).on(link,"click",L.DomEvent.preventDefault).on(link,buttonEvent,options.callback,options.context);return link;},_disposeButton:function(button,callback){var buttonEvent=this._detectIOS()?"touchstart":"click";L.DomEvent.off(button,"click",L.DomEvent.stopPropagation).off(button,"mousedown",L.DomEvent.stopPropagation).off(button,"dblclick",L.DomEvent.stopPropagation).off(button,"touchstart",L.DomEvent.stopPropagation).off(button,"click",L.DomEvent.preventDefault).off(button,buttonEvent,callback);},_handlerActivated:function(e){this.disable();this._activeMode=this._modes[e.handler];L.DomUtil.addClass(this._activeMode.button,"leaflet-draw-toolbar-button-enabled");this._showActionsToolbar();this.fire("enable");},_handlerDeactivated:function(){this._hideActionsToolbar();L.DomUtil.removeClass(this._activeMode.button,"leaflet-draw-toolbar-button-enabled");this._activeMode=null;this.fire("disable");},_createActions:function(handler){var container=this._actionsContainer,buttons=this.getActions(handler),l=buttons.length,li,di,dl,button;for(di=0,dl=this._actionButtons.length;di<dl;di++){this._disposeButton(this._actionButtons[di].button,this._actionButtons[di].callback);}this._actionButtons=[];while(container.firstChild){container.removeChild(container.firstChild);}for(var i=0;i<l;i++){if("enabled" in buttons[i]&&!buttons[i].enabled){continue;}li=L.DomUtil.create("li","",container);button=this._createButton({title:buttons[i].title,text:buttons[i].text,container:li,callback:buttons[i].callback,context:buttons[i].context});this._actionButtons.push({button:button,callback:buttons[i].callback});}},_showActionsToolbar:function(){var buttonIndex=this._activeMode.buttonIndex,lastButtonIndex=this._lastButtonIndex,toolbarPosition=this._activeMode.button.offsetTop-1;this._createActions(this._activeMode.handler);this._actionsContainer.style.top=toolbarPosition+"px";if(buttonIndex===0){L.DomUtil.addClass(this._toolbarContainer,"leaflet-draw-toolbar-notop");L.DomUtil.addClass(this._actionsContainer,"leaflet-draw-actions-top");}if(buttonIndex===lastButtonIndex){L.DomUtil.addClass(this._toolbarContainer,"leaflet-draw-toolbar-nobottom");L.DomUtil.addClass(this._actionsContainer,"leaflet-draw-actions-bottom");}this._actionsContainer.style.display="block";this._map.fire(L.Draw.Event.TOOLBAROPENED);},_hideActionsToolbar:function(){this._actionsContainer.style.display="none";L.DomUtil.removeClass(this._toolbarContainer,"leaflet-draw-toolbar-notop");L.DomUtil.removeClass(this._toolbarContainer,"leaflet-draw-toolbar-nobottom");L.DomUtil.removeClass(this._actionsContainer,"leaflet-draw-actions-top");L.DomUtil.removeClass(this._actionsContainer,"leaflet-draw-actions-bottom");this._map.fire(L.Draw.Event.TOOLBARCLOSED);}});L.DrawToolbar=L.Toolbar.extend({statics:{TYPE:"draw"},options:{polyline:{},polygon:{},rectangle:{},circle:{},marker:{},circlemarker:{}},initialize:function(options){for(var type in this.options){if(this.options.hasOwnProperty(type)){if(options[type]){options[type]=L.extend({},this.options[type],options[type]);}}}this._toolbarClass="leaflet-draw-draw";L.Toolbar.prototype.initialize.call(this,options);},getModeHandlers:function(map){return[{enabled:this.options.polyline,handler:new L.Draw.Polyline(map,this.options.polyline),title:L.drawLocal.draw.toolbar.buttons.polyline},{enabled:this.options.polygon,handler:new L.Draw.Polygon(map,this.options.polygon),title:L.drawLocal.draw.toolbar.buttons.polygon},{enabled:this.options.rectangle,handler:new L.Draw.Rectangle(map,this.options.rectangle),title:L.drawLocal.draw.toolbar.buttons.rectangle},{enabled:this.options.circle,handler:new L.Draw.Circle(map,this.options.circle),title:L.drawLocal.draw.toolbar.buttons.circle},{enabled:this.options.marker,handler:new L.Draw.Marker(map,this.options.marker),title:L.drawLocal.draw.toolbar.buttons.marker},{enabled:this.options.circlemarker,handler:new L.Draw.CircleMarker(map,this.options.circlemarker),title:L.drawLocal.draw.toolbar.buttons.circlemarker}];},getActions:function(handler){return[{enabled:handler.completeShape,title:L.drawLocal.draw.toolbar.finish.title,text:L.drawLocal.draw.toolbar.finish.text,callback:handler.completeShape,context:handler},{enabled:handler.deleteLastVertex,title:L.drawLocal.draw.toolbar.undo.title,text:L.drawLocal.draw.toolbar.undo.text,callback:handler.deleteLastVertex,context:handler},{title:L.drawLocal.draw.toolbar.actions.title,text:L.drawLocal.draw.toolbar.actions.text,callback:this.disable,context:this}];},setOptions:function(options){L.setOptions(this,options);for(var type in this._modes){if(this._modes.hasOwnProperty(type)&&options.hasOwnProperty(type)){this._modes[type].handler.setOptions(options[type]);}}}});L.EditToolbar=L.Toolbar.extend({statics:{TYPE:"edit"},options:{edit:{selectedPathOptions:{dashArray:"10, 10",fill:true,fillColor:"#fe57a1",fillOpacity:0.1,maintainColor:false}},remove:{},poly:null,featureGroup:null},initialize:function(options){if(options.edit){if(typeof options.edit.selectedPathOptions==="undefined"){options.edit.selectedPathOptions=this.options.edit.selectedPathOptions;}options.edit.selectedPathOptions=L.extend({},this.options.edit.selectedPathOptions,options.edit.selectedPathOptions);}if(options.remove){options.remove=L.extend({},this.options.remove,options.remove);}if(options.poly){options.poly=L.extend({},this.options.poly,options.poly);}this._toolbarClass="leaflet-draw-edit";L.Toolbar.prototype.initialize.call(this,options);this._selectedFeatureCount=0;},getModeHandlers:function(map){var featureGroup=this.options.featureGroup;return[{enabled:this.options.edit,handler:new L.EditToolbar.Edit(map,{featureGroup:featureGroup,selectedPathOptions:this.options.edit.selectedPathOptions,poly:this.options.poly}),title:L.drawLocal.edit.toolbar.buttons.edit},{enabled:this.options.remove,handler:new L.EditToolbar.Delete(map,{featureGroup:featureGroup}),title:L.drawLocal.edit.toolbar.buttons.remove}];},getActions:function(handler){var actions=[{title:L.drawLocal.edit.toolbar.actions.save.title,text:L.drawLocal.edit.toolbar.actions.save.text,callback:this._save,context:this},{title:L.drawLocal.edit.toolbar.actions.cancel.title,text:L.drawLocal.edit.toolbar.actions.cancel.text,callback:this.disable,context:this}];if(handler.removeAllLayers){actions.push({title:L.drawLocal.edit.toolbar.actions.clearAll.title,text:L.drawLocal.edit.toolbar.actions.clearAll.text,callback:this._clearAllLayers,context:this});}return actions;},addToolbar:function(map){var container=L.Toolbar.prototype.addToolbar.call(this,map);this._checkDisabled();this.options.featureGroup.on("layeradd layerremove",this._checkDisabled,this);return container;},removeToolbar:function(){this.options.featureGroup.off("layeradd layerremove",this._checkDisabled,this);L.Toolbar.prototype.removeToolbar.call(this);},disable:function(){if(!this.enabled()){return;}this._activeMode.handler.revertLayers();L.Toolbar.prototype.disable.call(this);},_save:function(){this._activeMode.handler.save();if(this._activeMode){this._activeMode.handler.disable();}},_clearAllLayers:function(){this._activeMode.handler.removeAllLayers();if(this._activeMode){this._activeMode.handler.disable();}},_checkDisabled:function(){var featureGroup=this.options.featureGroup,hasLayers=featureGroup.getLayers().length!==0,button;if(this.options.edit){button=this._modes[L.EditToolbar.Edit.TYPE].button;if(hasLayers){L.DomUtil.removeClass(button,"leaflet-disabled");}else{L.DomUtil.addClass(button,"leaflet-disabled");}button.setAttribute("title",hasLayers?L.drawLocal.edit.toolbar.buttons.edit:L.drawLocal.edit.toolbar.buttons.editDisabled);}if(this.options.remove){button=this._modes[L.EditToolbar.Delete.TYPE].button;if(hasLayers){L.DomUtil.removeClass(button,"leaflet-disabled");}else{L.DomUtil.addClass(button,"leaflet-disabled");}button.setAttribute("title",hasLayers?L.drawLocal.edit.toolbar.buttons.remove:L.drawLocal.edit.toolbar.buttons.removeDisabled);}}});L.EditToolbar.Edit=L.Handler.extend({statics:{TYPE:"edit"},initialize:function(map,options){L.Handler.prototype.initialize.call(this,map);L.setOptions(this,options);this._featureGroup=options.featureGroup;if(!(this._featureGroup instanceof L.FeatureGroup)){throw new Error("options.featureGroup must be a L.FeatureGroup");}this._uneditedLayerProps={};this.type=L.EditToolbar.Edit.TYPE;var version=L.version.split(".");if(parseInt(version[0],10)===1&&parseInt(version[1],10)>=2){L.EditToolbar.Edit.include(L.Evented.prototype);}else{L.EditToolbar.Edit.include(L.Mixin.Events);}},enable:function(){if(this._enabled||!this._hasAvailableLayers()){return;}this.fire("enabled",{handler:this.type});this._map.fire(L.Draw.Event.EDITSTART,{handler:this.type});L.Handler.prototype.enable.call(this);this._featureGroup.on("layeradd",this._enableLayerEdit,this).on("layerremove",this._disableLayerEdit,this);},disable:function(){if(!this._enabled){return;}this._featureGroup.off("layeradd",this._enableLayerEdit,this).off("layerremove",this._disableLayerEdit,this);L.Handler.prototype.disable.call(this);this._map.fire(L.Draw.Event.EDITSTOP,{handler:this.type});this.fire("disabled",{handler:this.type});},addHooks:function(){var map=this._map;if(map){map.getContainer().focus();this._featureGroup.eachLayer(this._enableLayerEdit,this);this._tooltip=new L.Draw.Tooltip(this._map);this._tooltip.updateContent({text:L.drawLocal.edit.handlers.edit.tooltip.text,subtext:L.drawLocal.edit.handlers.edit.tooltip.subtext});map._editTooltip=this._tooltip;this._updateTooltip();this._map.on("mousemove",this._onMouseMove,this).on("touchmove",this._onMouseMove,this).on("MSPointerMove",this._onMouseMove,this).on(L.Draw.Event.EDITVERTEX,this._updateTooltip,this);}},removeHooks:function(){if(this._map){this._featureGroup.eachLayer(this._disableLayerEdit,this);this._uneditedLayerProps={};this._tooltip.dispose();this._tooltip=null;this._map.off("mousemove",this._onMouseMove,this).off("touchmove",this._onMouseMove,this).off("MSPointerMove",this._onMouseMove,this).off(L.Draw.Event.EDITVERTEX,this._updateTooltip,this);}},revertLayers:function(){this._featureGroup.eachLayer(function(layer){this._revertLayer(layer);},this);},save:function(){var editedLayers=new L.LayerGroup();this._featureGroup.eachLayer(function(layer){if(layer.edited){editedLayers.addLayer(layer);layer.edited=false;}});this._map.fire(L.Draw.Event.EDITED,{layers:editedLayers});},_backupLayer:function(layer){var id=L.Util.stamp(layer);if(!this._uneditedLayerProps[id]){if(layer instanceof L.Polyline||layer instanceof L.Polygon||layer instanceof L.Rectangle){this._uneditedLayerProps[id]={latlngs:L.LatLngUtil.cloneLatLngs(layer.getLatLngs())};}else{if(layer instanceof L.Circle){this._uneditedLayerProps[id]={latlng:L.LatLngUtil.cloneLatLng(layer.getLatLng()),radius:layer.getRadius()};}else{if(layer instanceof L.Marker||layer instanceof L.CircleMarker){this._uneditedLayerProps[id]={latlng:L.LatLngUtil.cloneLatLng(layer.getLatLng())};}}}}},_getTooltipText:function(){return({text:L.drawLocal.edit.handlers.edit.tooltip.text,subtext:L.drawLocal.edit.handlers.edit.tooltip.subtext});},_updateTooltip:function(){this._tooltip.updateContent(this._getTooltipText());},_revertLayer:function(layer){var id=L.Util.stamp(layer);layer.edited=false;if(this._uneditedLayerProps.hasOwnProperty(id)){if(layer instanceof L.Polyline||layer instanceof L.Polygon||layer instanceof L.Rectangle){layer.setLatLngs(this._uneditedLayerProps[id].latlngs);}else{if(layer instanceof L.Circle){layer.setLatLng(this._uneditedLayerProps[id].latlng);layer.setRadius(this._uneditedLayerProps[id].radius);}else{if(layer instanceof L.Marker||layer instanceof L.CircleMarker){layer.setLatLng(this._uneditedLayerProps[id].latlng);}}}layer.fire("revert-edited",{layer:layer});}},_enableLayerEdit:function(e){var layer=e.layer||e.target||e,pathOptions,poly;this._backupLayer(layer);if(this.options.poly){poly=L.Util.extend({},this.options.poly);layer.options.poly=poly;}if(this.options.selectedPathOptions){pathOptions=L.Util.extend({},this.options.selectedPathOptions);if(pathOptions.maintainColor){pathOptions.color=layer.options.color;pathOptions.fillColor=layer.options.fillColor;}layer.options.original=L.extend({},layer.options);layer.options.editing=pathOptions;}if(layer instanceof L.Marker){if(layer.editing){layer.editing.enable();}layer.dragging.enable();layer.on("dragend",this._onMarkerDragEnd).on("touchmove",this._onTouchMove,this).on("MSPointerMove",this._onTouchMove,this).on("touchend",this._onMarkerDragEnd,this).on("MSPointerUp",this._onMarkerDragEnd,this);}else{layer.editing.enable();}},_disableLayerEdit:function(e){var layer=e.layer||e.target||e;layer.edited=false;if(layer.editing){layer.editing.disable();}delete layer.options.editing;delete layer.options.original;if(this._selectedPathOptions){if(layer instanceof L.Marker){this._toggleMarkerHighlight(layer);}else{layer.setStyle(layer.options.previousOptions);delete layer.options.previousOptions;}}if(layer instanceof L.Marker){layer.dragging.disable();layer.off("dragend",this._onMarkerDragEnd,this).off("touchmove",this._onTouchMove,this).off("MSPointerMove",this._onTouchMove,this).off("touchend",this._onMarkerDragEnd,this).off("MSPointerUp",this._onMarkerDragEnd,this);}else{layer.editing.disable();}},_onMouseMove:function(e){this._tooltip.updatePosition(e.latlng);},_onMarkerDragEnd:function(e){var layer=e.target;layer.edited=true;this._map.fire(L.Draw.Event.EDITMOVE,{layer:layer});},_onTouchMove:function(e){var touchEvent=e.originalEvent.changedTouches[0],layerPoint=this._map.mouseEventToLayerPoint(touchEvent),latlng=this._map.layerPointToLatLng(layerPoint);e.target.setLatLng(latlng);},_hasAvailableLayers:function(){return this._featureGroup.getLayers().length!==0;}});L.EditToolbar.Delete=L.Handler.extend({statics:{TYPE:"remove"},initialize:function(map,options){L.Handler.prototype.initialize.call(this,map);L.Util.setOptions(this,options);this._deletableLayers=this.options.featureGroup;if(!(this._deletableLayers instanceof L.FeatureGroup)){throw new Error("options.featureGroup must be a L.FeatureGroup");}this.type=L.EditToolbar.Delete.TYPE;var version=L.version.split(".");if(parseInt(version[0],10)===1&&parseInt(version[1],10)>=2){L.EditToolbar.Delete.include(L.Evented.prototype);}else{L.EditToolbar.Delete.include(L.Mixin.Events);}},enable:function(){if(this._enabled||!this._hasAvailableLayers()){return;}this.fire("enabled",{handler:this.type});this._map.fire(L.Draw.Event.DELETESTART,{handler:this.type});L.Handler.prototype.enable.call(this);this._deletableLayers.on("layeradd",this._enableLayerDelete,this).on("layerremove",this._disableLayerDelete,this);},disable:function(){if(!this._enabled){return;}this._deletableLayers.off("layeradd",this._enableLayerDelete,this).off("layerremove",this._disableLayerDelete,this);L.Handler.prototype.disable.call(this);this._map.fire(L.Draw.Event.DELETESTOP,{handler:this.type});this.fire("disabled",{handler:this.type});},addHooks:function(){var map=this._map;if(map){map.getContainer().focus();this._deletableLayers.eachLayer(this._enableLayerDelete,this);this._deletedLayers=new L.LayerGroup();this._tooltip=new L.Draw.Tooltip(this._map);this._tooltip.updateContent({text:L.drawLocal.edit.handlers.remove.tooltip.text});this._map.on("mousemove",this._onMouseMove,this);}},removeHooks:function(){if(this._map){this._deletableLayers.eachLayer(this._disableLayerDelete,this);this._deletedLayers=null;this._tooltip.dispose();this._tooltip=null;this._map.off("mousemove",this._onMouseMove,this);}},revertLayers:function(){this._deletedLayers.eachLayer(function(layer){this._deletableLayers.addLayer(layer);layer.fire("revert-deleted",{layer:layer});},this);},save:function(){this._map.fire(L.Draw.Event.DELETED,{layers:this._deletedLayers});},removeAllLayers:function(){this._deletableLayers.eachLayer(function(layer){this._removeLayer({layer:layer});},this);this.save();},_enableLayerDelete:function(e){var layer=e.layer||e.target||e;layer.on("click",this._removeLayer,this);},_disableLayerDelete:function(e){var layer=e.layer||e.target||e;layer.off("click",this._removeLayer,this);this._deletedLayers.removeLayer(layer);},_removeLayer:function(e){var layer=e.layer||e.target||e;this._deletableLayers.removeLayer(layer);this._deletedLayers.addLayer(layer);layer.fire("deleted");},_onMouseMove:function(e){this._tooltip.updatePosition(e.latlng);},_hasAvailableLayers:function(){return this._deletableLayers.getLayers().length!==0;}});
 
 
 function componentToHex(c) {
     var hex = c.toString(16);
     return hex.length == 1 ? "0" + hex : hex;
 }
 
 function rgbToHex(r, g, b) {
     return "#" + componentToHex(r) + componentToHex(g) + componentToHex(b);
 }
 
 //alert( rgbToHex(0, 51, 255) );
 
 
 L.KML = L.FeatureGroup.extend({
     options: {
         async: true,
         popup: true,
         displayName: false,
         displayName_suffix: '_display_name',
         name_on_props: false,
         name_prop: 'kml_name',
         descr_on_props: false,
         descr_prop: 'kml_description',
         onEachFeature: null
     }, _this: null,
     initialize: function(kml, options) {
         L.Util.setOptions(this, options);
         if (options === undefined)
             options = this.options;
 
         this._kml = kml;
         this._layers = {};
         //console.log(" options=" + options.name_on_props);
         //console.log(" options=" + options.name_on_props);
         if (kml) {
             if (kml instanceof File) {
                 this.readKML(kml, this.options);
             }
             else if (kml instanceof String) {
                 this.addKML(kml, this.options, this.options.async);
             }
             else {
                 this._addKML(kml, options);
             }
         }
     },
     loadXML: function(url, cb, options, async) {
         if (async === undefined)
             async = this.options.async;
         if (options === undefined)
             options = this.options;
 
         var req = new window.XMLHttpRequest();
 
         // Check for IE8 and IE9 Fix Cors for those browsers
         if (req.withCredentials === undefined && typeof window.XDomainRequest !== 'undefined') {
             var xdr = new window.XDomainRequest();
             xdr.open('GET', url, async);
             xdr.onprogress = function() {
             };
             xdr.ontimeout = function() {
             };
             xdr.onerror = function() {
             };
             xdr.onload = function() {
                 if (xdr.responseText) {
                     var xml = new window.ActiveXObject('Microsoft.XMLDOM');
                     xml.loadXML(xdr.responseText);
                     cb(xml, options);
                 }
             };
             setTimeout(function() {
                 xdr.send();
             }, 0);
         } else {
             req.open('GET', url, async);
             req.setRequestHeader('Accept', 'application/vnd.google-earth.kml+xml');
             try {
                 req.overrideMimeType('text/xml'); // unsupported by IE
             } catch (e) {
             }
             req.onreadystatechange = function() {
                 if (req.readyState !== 4)
                     return;
                 if (req.status === 200)
                     cb(req.responseXML, options);
             };
             req.send(null);
         }
     },
     addKML: function(url, options, async) {
         //var _this = this;
         _this = this;
         //console.log(" options 3=" + options.name_on_props);
         var cb = function(kml) {
             _this._addKML(kml, options);
         };
         this.loadXML(url, cb, options, async);
     },
     readKML: function(kml, options) {
         _this = this;
         var reader = new FileReader();
         reader.readAsText(kml);
         reader.onload = function(evt) {
             var text = evt.target.result;
             var parser = new DOMParser();
             var xml = parser.parseFromString(text,"text/xml");
             _this._addKML(xml, options);
         };
     },
     _addKML: function(xml, options) {
         //console.log(" options 2=" + options.name_on_props);
         _this = this;
         var layers = L.KML.parseKML(xml, options);
         if (!layers || !layers.length)
             return;
         for (var i = 0; i < layers.length; i++) {
             this.fire('addlayer', {
                 layer: layers[i]
             });
             this.addLayer(layers[i]);
         }
         this.latLngs = L.KML.getLatLngs(xml);
         this.fire('loaded');
     },
     latLngs: []
 });
 
 L.Util.extend(L.KML, {
     parseKML: function(xml) {
 
         var style = this.parseStyles(xml);
         this.parseStyleMap(xml, style);
         var el = xml.getElementsByTagName('Folder');
         var layers = [], l;
         for (var i = 0; i < el.length; i++) {
             if (!this._check_folder(el[i])) {
                 continue;
             }
             l = this.parseFolder(el[i], style);
             if (l) {
                 layers.push(l);
             }
         }
         el = xml.getElementsByTagName('Placemark');
         for (var j = 0; j < el.length; j++) {
             //console.log(" calling placemark");
             if (!this._check_folder(el[j])) {
                 continue;
             }
             l = this.parsePlacemark(el[j], xml, style);
             if (l) {
                 layers.push(l);
             }
         }
         el = xml.getElementsByTagName('GroundOverlay');
         for (var k = 0; k < el.length; k++) {
             l = this.parseGroundOverlay(el[k]);
             if (l) {
                 layers.push(l);
             }
         }
         return layers;
     },
     // Return false if e's first parent Folder is not [folder]
     // - returns true if no parent Folders
     _check_folder: function(e, folder) {
         e = e.parentNode;
         while (e && e.tagName !== 'Folder')
         {
             e = e.parentNode;
         }
         return !e || e === folder;
     },
     parseStyles: function(xml) {
         var styles = {};
         var sl = xml.getElementsByTagName('Style');
         for (var i = 0, len = sl.length; i < len; i++) {
             var style = this.parseStyle(sl[i]);
             if (style) {
                 var styleName = '#' + style.id;
                 styles[styleName] = style;
             }
         }
         return styles;
     },
     parseStyle: function(xml) {
         var style = {}, poptions = {}, ioptions = {}, el, id;
 
         var attributes = {color: true, width: true, Icon: true, href: true, hotSpot: true};
 
         function _parse(xml) {
             var options = {};
             for (var i = 0; i < xml.childNodes.length; i++) {
                 var e = xml.childNodes[i];
                 var key = e.tagName;
                 if (!attributes[key]) {
                     continue;
                 }
                 if (key === 'hotSpot')
                 {
                     for (var j = 0; j < e.attributes.length; j++) {
                         options[e.attributes[j].name] = e.attributes[j].nodeValue;
                     }
                 } else {
                     var value = e.childNodes[0].nodeValue;
                     if (key === 'color') {
                         options.opacity = parseInt(value.substring(0, 2), 16) / 255.0;
                         options.color = '#' + value.substring(6, 8) + value.substring(4, 6) + value.substring(2, 4);
                     } else if (key === 'width') {
                         options.weight = value;
                     } else if (key === 'Icon') {
                         ioptions = _parse(e);
                         if (ioptions.href) {
                             options.href = ioptions.href;
                         }
                     } else if (key === 'href') {
                         options.href = value;
                     }
                 }
             }
             return options;
         }
 
         el = xml.getElementsByTagName('LineStyle');
         if (el && el[0]) {
             style = _parse(el[0]);
         }
         el = xml.getElementsByTagName('PolyStyle');
         if (el && el[0]) {
             poptions = _parse(el[0]);
         }
         if (poptions.color) {
             style.fillColor = poptions.color;
         }
         if (poptions.opacity) {
             style.fillOpacity = poptions.opacity;
         }
         el = xml.getElementsByTagName('IconStyle');
         if (el && el[0]) {
             ioptions = _parse(el[0]);
         }
         if (ioptions.href) {
             style.icon = new L.KMLIcon({
                 iconUrl: ioptions.href,
                 shadowUrl: null,
                 anchorRef: {x: ioptions.x, y: ioptions.y},
                 anchorType: {x: ioptions.xunits, y: ioptions.yunits}
             });
         }
 
         id = xml.getAttribute('id');
         if (id && style) {
             style.id = id;
         }
 
         return style;
     },
     parseStyleMap: function(xml, existingStyles) {
         var sl = xml.getElementsByTagName('StyleMap');
 
         for (var i = 0; i < sl.length; i++) {
             var e = sl[i], el;
             var smKey, smStyleUrl;
 
             el = e.getElementsByTagName('key');
             if (el && el[0]) {
                 smKey = el[0].textContent;
             }
             el = e.getElementsByTagName('styleUrl');
             if (el && el[0]) {
                 smStyleUrl = el[0].textContent;
             }
 
             if (smKey === 'normal')
             {
                 existingStyles['#' + e.getAttribute('id')] = existingStyles[smStyleUrl];
             }
         }
 
         return;
     },
     parseFolder: function(xml, style) {
         var el, layers = [], l;
         el = xml.getElementsByTagName('Folder');
         for (var i = 0; i < el.length; i++) {
             if (!this._check_folder(el[i], xml)) {
                 continue;
             }
             l = this.parseFolder(el[i], style);
             if (l) {
                 layers.push(l);
             }
         }
         el = xml.getElementsByTagName('Placemark');
         for (var j = 0; j < el.length; j++) {
             //                   console.log(" parseFolder --placemark")
             if (!this._check_folder(el[j], xml)) {
                 continue;
             }
             l = this.parsePlacemark(el[j], xml, style);
             if (l) {
                 layers.push(l);
             }
         }
         el = xml.getElementsByTagName('GroundOverlay');
         for (var k = 0; k < el.length; k++) {
             if (!this._check_folder(el[k], xml)) {
                 continue;
             }
             l = this.parseGroundOverlay(el[k]);
             if (l) {
                 layers.push(l);
             }
         }
         if (!layers.length) {
             return;
         }
         if (layers.length === 1) {
             return layers[0];
         }
         return new L.FeatureGroup(layers);
     },
     parsePlacemark: function(place, xml, style, options) {
         var h, i, j, k, el, il, opts = options || {};
         //console.log(" parse placemark xml=" + JSON.stringify(place));
         el = place.getElementsByTagName('styleUrl');
         for (i = 0; i < el.length; i++) {
         //console.log(" placemark i="+i);
             var url = el[i].childNodes[0].nodeValue;
             for (var a in style[url]) {
                 //console.log(" overriding styles A a=" + a + " url=" + url);
                 opts[a] = style[url][a];
             }
         }
 
         il = place.getElementsByTagName('Style')[0];
         if (il) {
             var inlineStyle = this.parseStyle(place);
             if (inlineStyle) {
                 for (k in inlineStyle) {
                     //console.log(" overriding styles B a=" + k);
                     opts[k] = inlineStyle[k];
                 }
             }
         }
 
         var multi = ['MultiGeometry', 'MultiTrack', 'gx:MultiTrack'];
         var tmm = place.getElementsByTagName('ExtendedData');
         var tmm2 = place.getElementsByTagName('SimpleData');
         var temp_color;
         for (var ii = 0; ii < tmm2.length; ++ii) {
             var tmm_name = tmm2[ii].getAttribute('name');
             //console.log("name=" + tmm_name + " simpledata=" + tmm2[ii].childNodes[0].nodeValue);
             //name="COLOR"
             if (tmm_name.toUpperCase() === "COLOR") {
                 temp_color = tmm2[ii].childNodes[0].nodeValue;
             }
         }
         //console.log("tmm=" + tmm + " temp_color=" + temp_color);
         // opts.color="#ff0000";
         // opts.fillColor="#00ff00";
         if (temp_color) {
 
             var c_arr = temp_color.split(" ");
             var c_hex = rgbToHex(parseInt(c_arr[0]), parseInt(c_arr[1]), parseInt(c_arr[2]));
             //console.log(" setting opts c_arr[1]=" + c_arr[1] + "  chex=" + c_hex);
             opts.color = c_hex;
             opts.fillColor = c_hex;
         }
         for (h in multi) {
             el = place.getElementsByTagName(multi[h]);
             for (i = 0; i < el.length; i++) {
                 return this.parsePlacemark(el[i], xml, style, opts);
             }
         }
 
         var layers = [];
         //console.log(" starting polygons");
         var parse = ['LineString', 'Polygon', 'Point', 'Track', 'gx:Track'];
         for (j in parse) {
             var tag = parse[j];
             el = place.getElementsByTagName(tag);
             for (i = 0; i < el.length; i++) {
                 var l = this['parse' + tag.replace(/gx:/, '')](el[i], xml, opts);
                 if (l) {
                     layers.push(l);
                 }
             }
         }
 
         if (!layers.length) {
             return;
         }
         var layer = layers[0];
         if (layers.length > 1) {
             layer = new L.FeatureGroup(layers);
         }
 
         this.parseData(place, layer);
 
         return layer;
     },
     parseData: function(xml, layer) {
         var name,
                 descr = '',
                 props = {},
                 eld, eldn, el, i, j, prop
                 ;
         //console.log(" parse data xml=" + JSON.stringify(xml));
         el = xml.getElementsByTagName('ExtendedData');
         //console.log(" el ="+el.length);                
         for (i = 0; i < el.length; i++) {
             for (j = 0; j < el[i].childNodes.length; j++) {
                 eld = el[i].childNodes[j];
         //console.log(" tagName="+eld.tagName);
                 if (eld.tagName === 'Data') {
                     prop = eld.getAttribute('name');
                     props[prop] = null;
 
                     eldn = eld.getElementsByTagName('value');
                     if (eldn.length)
                         props[prop] = eldn[0].firstChild.nodeValue;
 
                     if (_this.options.displayName) {
                         eldn = eld.getElementsByTagName('displayName');
                         if (eldn.length)
                             props[prop + _this.options.displayName_suffix] = eldn[0].firstChild.nodeValue;
                     }
                 }
             }
         }
 
         el = xml.getElementsByTagName('name');
 //console.log(" el name="+el);                
         if (el.length && el[0].childNodes.length) {
             name = el[0].childNodes[0].nodeValue;
         }
 
         el = xml.getElementsByTagName('description');
         for (i = 0; i < el.length; i++) {
             for (j = 0; j < el[i].childNodes.length; j++) {
                 descr = descr + el[i].childNodes[j].nodeValue;
             }
         }
 
         layer.name = name;
         if (_this.options.name_on_props)
             props[_this.options.name_prop] = name;
 
         layer.description = descr;
         if (_this.options.descr_on_props)
             props[_this.options.descr_prop] = descr;
 
         layer.feature = layer.toGeoJSON();
         layer.feature.properties = props;
 
         if (_this.options.popup && (name || descr))
             layer.bindPopup('<h2>' + name + '</h2>' + descr);
 
         if (typeof (_this.options.onEachFeature) === 'function')
             _this.options.onEachFeature(layer.feature, layer);
 
         return layer;
     },
     parseCoords: function(xml) {
         var el = xml.getElementsByTagName('coordinates');
         return this._read_coords(el[0]);
     },
     parseLineString: function(line, xml, options) {
         var coords = this.parseCoords(line);
         if (!coords.length) {
             return;
         }
         return new L.Polyline(coords, options);
     },
     parseTrack: function(line, xml, options) {
         var el = xml.getElementsByTagName('gx:coord');
         if (el.length === 0) {
             el = xml.getElementsByTagName('coord');
         }
         var coords = [];
         for (var j = 0; j < el.length; j++) {
             coords = coords.concat(this._read_gxcoords(el[j]));
         }
         if (!coords.length) {
             return;
         }
         return new L.Polyline(coords, options);
     },
     parsePoint: function(line, xml, options) {
         var el = line.getElementsByTagName('coordinates');
         if (!el.length) {
             return;
         }
         var ll = el[0].childNodes[0].nodeValue.split(',');
         return new L.KMLMarker(new L.LatLng(ll[1], ll[0]), options);
     },
     parsePolygon: function(line, xml, options) {
         //console.log(" polygon options= " + JSON.stringify(options));
         var el, polys = [], inner = [], i, coords;
         el = line.getElementsByTagName('outerBoundaryIs');
         for (i = 0; i < el.length; i++) {
             coords = this.parseCoords(el[i]);
             if (coords) {
                 polys.push(coords);
             }
         }
         el = line.getElementsByTagName('innerBoundaryIs');
         for (i = 0; i < el.length; i++) {
             coords = this.parseCoords(el[i]);
             if (coords) {
                 inner.push(coords);
             }
         }
         if (!polys.length) {
             return;
         }
         if (options.fillColor) {
             options.fill = true;
         }
         if (polys.length === 1) {
             return new L.Polygon(polys.concat(inner), options);
         }
         return new L.MultiPolygon(polys, options);
     },
     getLatLngs: function(xml) {
         var el = xml.getElementsByTagName('coordinates');
         var coords = [];
         for (var j = 0; j < el.length; j++) {
             // text might span many childNodes
             coords = coords.concat(this._read_coords(el[j]));
         }
         return coords;
     },
     _read_coords: function(el) {
         var text = '', coords = [], i;
         for (i = 0; i < el.childNodes.length; i++) {
             text = text + el.childNodes[i].nodeValue;
         }
         text = text.split(/[\s\n]+/);
         for (i = 0; i < text.length; i++) {
             var ll = text[i].split(',');
             if (ll.length < 2) {
                 continue;
             }
             coords.push(new L.LatLng(ll[1], ll[0]));
         }
         return coords;
     },
     _read_gxcoords: function(el) {
         var text = '', coords = [];
         text = el.firstChild.nodeValue.split(' ');
         coords.push(new L.LatLng(text[1], text[0]));
         return coords;
     },
     parseGroundOverlay: function(xml) {
         var latlonbox = xml.getElementsByTagName('LatLonBox')[0];
         var bounds = new L.LatLngBounds(
                 [
                     latlonbox.getElementsByTagName('south')[0].childNodes[0].nodeValue,
                     latlonbox.getElementsByTagName('west')[0].childNodes[0].nodeValue
                 ],
                 [
                     latlonbox.getElementsByTagName('north')[0].childNodes[0].nodeValue,
                     latlonbox.getElementsByTagName('east')[0].childNodes[0].nodeValue
                 ]
                 );
         var attributes = {Icon: true, href: true, color: true};
         function _parse(xml) {
             var options = {}, ioptions = {};
             for (var i = 0; i < xml.childNodes.length; i++) {
                 var e = xml.childNodes[i];
                 var key = e.tagName;
                 if (!attributes[key]) {
                     continue;
                 }
                 var value = e.childNodes[0].nodeValue;
                 if (key === 'Icon') {
                     ioptions = _parse(e);
                     if (ioptions.href) {
                         options.href = ioptions.href;
                     }
                 } else if (key === 'href') {
                     options.href = value;
                 } else if (key === 'color') {
                     options.opacity = parseInt(value.substring(0, 2), 16) / 255.0;
                     options.color = '#' + value.substring(6, 8) + value.substring(4, 6) + value.substring(2, 4);
                 }
             }
             return options;
         }
         var options = {};
         options = _parse(xml);
         if (latlonbox.getElementsByTagName('rotation')[0] !== undefined) {
             var rotation = latlonbox.getElementsByTagName('rotation')[0].childNodes[0].nodeValue;
             options.rotation = parseFloat(rotation);
         }
         return new L.RotatedImageOverlay(options.href, bounds, {opacity: options.opacity, angle: options.rotation});
     }
 
 });
 
 L.KMLIcon = L.Icon.extend({
     _setIconStyles: function(img, name) {
         L.Icon.prototype._setIconStyles.apply(this, [img, name]);
         var options = this.options;
         this.options.popupAnchor = [0, (-0.83 * img.height)];
         if (options.anchorType.x === 'fraction')
             img.style.marginLeft = (-options.anchorRef.x * img.width) + 'px';
         if (options.anchorType.y === 'fraction')
             img.style.marginTop = ((-(1 - options.anchorRef.y) * img.height) + 1) + 'px';
         if (options.anchorType.x === 'pixels')
             img.style.marginLeft = (-options.anchorRef.x) + 'px';
         if (options.anchorType.y === 'pixels')
             img.style.marginTop = (options.anchorRef.y - img.height + 1) + 'px';
     }
 });
 
 
 L.KMLMarker = L.Marker.extend({
     options: {
         icon: new L.KMLIcon.Default()
     }
 });
 
 // Inspired by https://github.com/bbecquet/Leaflet.PolylineDecorator/tree/master/src
 L.RotatedImageOverlay = L.ImageOverlay.extend({
     options: {
         angle: 0
     },
     _reset: function() {
         L.ImageOverlay.prototype._reset.call(this);
         this._rotate();
     },
     _animateZoom: function(e) {
         L.ImageOverlay.prototype._animateZoom.call(this, e);
         this._rotate();
     },
     _rotate: function() {
         if (L.DomUtil.TRANSFORM) {
             // use the CSS transform rule if available
             this._image.style[L.DomUtil.TRANSFORM] += ' rotate(' + this.options.angle + 'deg)';
         } else if (L.Browser.ie) {
             // fallback for IE6, IE7, IE8
             var rad = this.options.angle * (Math.PI / 180),
                     costheta = Math.cos(rad),
                     sintheta = Math.sin(rad);
             this._image.style.filter += ' progid:DXImageTransform.Microsoft.Matrix(sizingMethod=\'auto expand\', M11=' +
                     costheta + ', M12=' + (-sintheta) + ', M21=' + sintheta + ', M22=' + costheta + ')';
         }
     },
     getBounds: function() {
         return this._bounds;
     }
 });
 
 var bub;
 
 (function(window, document, undefined) {
 
     XYZ = {};
     window.XYZ = XYZ;
     XYZ.version = 1.4;
     XYZ._maps = {};
     XYZ._standalone = false;
     XYZ._resource_path = "../../../espresso/static";
     XYZ._nitro_home;
     XYZ.setStandAlone = function(standalone, nitro_home) {
         XYZ._standalone = standalone;
         if (standalone) {
             XYZ._resource_path = ".";
         }
         XYZ._nitro_home = nitro_home;
     };
 
     if(typeof L_GeometryUtilMode !=='undefined'){L_GeometryUtilMode="KM_M_MI";} //default view of areas
 
     XYZ.Map = function() {
         var o = {};
 
         var _tile_type = XYZ.TILE.MAP;
         var _mode = XYZ.MODE.CLUSTER;
         var _attr = XYZ.ATTR.EDGE_TEXT | XYZ.ATTR.EDGE_AGGR_TEXT;
         var _context_path;
         typeof CONTEXT_PATH !== 'undefined' ? _context_path = CONTEXT_PATH : _context_path = "";
 
         var _category, _clusterData, _clusterOptions={};
         var _splitClusters;
         var _frozen = {};
 
         var _icon_map = {"node_marker": new L.Icon({
                 iconUrl: XYZ._resource_path + '/nitro/css/images/xyz/product/location.png',
                 iconAnchor: L.point(10, 10),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: XYZ._resource_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             })
         };
 
         //include XYZ.IconMap to get standard icon library 
         if (!XYZ._icon_map) {
             //console.log(" init icon library icon_path="+XYZ._resource_path);
             XYZ._initIconLibrary(XYZ._resource_path);
         }
         _icon_map = XYZ.icon_map;
 
         var _map_url = ' http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
         //var _map_url = 'http://netgeo.vh.eng.vzwcorp.com/arcgis/rest/services/basemap_webmer/World_Street_Map/MapServer/tile/{z}/{y}/{x}';
         var _grid_url;
         //var _grid_url = _context_path + '/uui/espresso/static/nitro/css/images/xyz/grid/grid_{z}.png';
         // var _grid_url = _context_path + XYZ._resource_path+'/nitro/css/images/xyz/grid/grid_{z}.png';
         if (XYZ._nitro_home) {
             _grid_url = XYZ._nitro_home + '/nitro/css/images/xyz/grid/grid_{z}.png';
         } else {
             _grid_url = _context_path + '/uui/espresso/static/nitro/css/images/xyz/grid/grid_{z}.png';
         }
         var _zoom_lvl = 4;
         var _tile_layer;//set in initialize
         var _tile_options = {maxZoom: 20, minZoom: 2, opacity: .2, attribution: "Powered by Nitro {x,y,z}"/*,unloadInvisibleTiles:true*/};
         var _current_map_url = _map_url;
         var _viewport_id;
         var _map;
 
         var _grid_opacity = .2;
         var _edges = {};
         var _nodes = {};
 
         //var _drag_group = new L.layerGroup();
         var _drag_group = new L.featureGroup();
         var _cluster_group;
         var _edge_group = new L.featureGroup();
         var _overlay_group = new L.featureGroup();
         var _draw_group = new L.featureGroup();
 
         var _positions = {};//for generated positions
         var _log = function(s) {/*console.log(s);*/
         };
         var _line_map = {};//used for aggregation
         var _aggr_line_map = {};//used for line aggregation
         var _line_attr = {weight: 5, opacity: .6, color: "#ff0000", fillColor: "#ff0000"};
         var _friendly_map = {};
 
         var _text_attr = {
             "font-weight": "bolder",
             stroke: "#000000",
             fill: "#000000",
             "font-size": "14",
             "stroke-width": "0px"
         };
 
         var _vis_options = {
             autoResize: false,
             locale: 'en',
             clickToUse: false,
             layout: {improvedLayout: true},
             physics: {enabled: true}, //,stabilization:{enabled:true,iterations: 1000,updateInterval: 25}},
             interaction: {hover: false} // defined in the interaction module.
         };
 
         //////////////////////////////////////   functions ////////////////////////////
         //var _instance={};
         //XYZ._map.push(o);
 
 
         //var _add=function(name,value){
         //   _instance[name]=value;
         //};
 
         if (o._logging) {
             _log = function(s) {
                 console.log(s);
             };
         }
         
         o.getClusterGroup = function(name) {
             return _cluster_group[name || 'default'];
         }
         
         o.addClusterGroup = function(name, clusterRad, spiderfy) {
             if (_cluster_group[name]) return;
             if (_clusterOptions.pieChart) {
                 _cluster_group[name] = L.markerClusterGroup({
                     maxClusterRadius: 60,
                     iconCreateFunction: _createPieChart
                 });
             }
             else _cluster_group[name] = L.markerClusterGroup({
                 maxClusterRadius: clusterRad || _clusterOptions.maxRad || 80,
                 disableClusteringAtZoom: _clusterOptions.disableZoom || undefined,
                 spiderfyOnMaxZoom: spiderfy || (_clusterOptions.disableZoom ? false : true)
             });
             _map.addLayer(_cluster_group[name]);
             //_cluster_group[name].on('animationend', _handleAnimateEnd);
         }
         o.deleteClusterGroup = function(name) {
             if (!_cluster_group[name] || !_map.hasLayer(_cluster_group[name])) return;
             _cluster_group[name].clearLayers();
             _map.removeLayer(_cluster_group[name]);
             delete _cluster_group[name];
         }
         
         var _freeze = function(name) {
             if (_frozen[name]) return;
             _cluster_group[name].disableClustering();
             _frozen[name] = true;
         }
         var _unfreeze = function(name) {
             if (!_frozen[name]) return;
             _cluster_group[name].enableClustering();
             delete _frozen[name];
         }
         o.freezeClusterGroup = function(name) {
             _freeze(name);
         }
         o.unfreezeClusterGroup = function(name) {
             _unfreeze(name);
         }
 
         o.updateSize = function() {
             setTimeout(function() {
                 _map.invalidateSize();
             }, 50);
         };
 
         o.zoomControl = function(activate, options) {
 
             if (activate) {
                 if (!options) {
                     options = {position: 'topleft'};
                 }
                 new L.Control.Zoom(options).addTo(_map);
             } else {
 //todo --turn off.
             }
         };
         
         _updateClusters = function() {
             if (_map.getZoom() != _zoom_lvl) {
                 if (_map.getZoom() >= _splitClusters && _zoom_lvl < _splitClusters) {
                     _cluster_group['default'].eachLayer(function(l) {
                         if (!l.clusterName) return;
                         _cluster_group['default'].removeLayer(l);
                         _cluster_group[l.clusterName].addLayer(l);
                     });
                 }
                 else if (_map.getZoom() < _splitClusters && _zoom_lvl >= _splitClusters) {
                     for (i in _cluster_group) {
                         _unfreeze(i);
                         if (i === 'default') continue;
                         _cluster_group[i].eachLayer(function(l) {
                             _cluster_group[i].removeLayer(l);
                             _cluster_group['default'].addLayer(l);
                         });
                     }
                 }
             }
             else {
                 if (_map.getZoom() >= _splitClusters) {
                     _cluster_group['default'].eachLayer(function(l) {
                         if (!l.clusterName) return;
                         _cluster_group['default'].removeLayer(l);
                         _cluster_group[l.clusterName].addLayer(l);
                     });
                 }
                 else if (_map.getZoom() < _splitClusters) {
                     for (i in _cluster_group) {
                         _cluster_group[i].eachLayer(function(l) {
                             _cluster_group[i].removeLayer(l);
                             _cluster_group['default'].addLayer(l);
                         });
                     }
                 }
             }
             _zoom_lvl = _map.getZoom();
         };
 
         o.initialize = function(viewport_id, options) {         
             _viewport_id = viewport_id;
             if (options) {
                 if (options.url) {
                     _map_url = options.url;
                 }
 
                 if (options.mode) {                  
                     _mode = options.mode;
                 }
             }
             
             if (options && options.tileOptions) _tile_layer = new L.TileLayer(_map_url + (options.stamp || ""), options.tileOptions);
             else _tile_layer = new L.TileLayer(_map_url, _tile_options);
             
             if (options && options.resourcePath) {
                 XYZ._resource_path = options.resourcePath;
                 XYZ._initIconLibrary(XYZ._resource_path);
             }
 
             if (_tile_type & XYZ.TILE.MAP) {
                 _tile_layer.setOpacity(1.0);
             } else {
                 _tile_layer.setOpacity(_grid_opacity);
             }
 
 
 
             _map = new L.Map(viewport_id, {
                 layers: [_tile_layer],
                 /*todo*/    center: new L.LatLng(40, -85),
                 zoom: _zoom_lvl,
                 zoomControl: false
             });
 
             if (options) {
                 if (options["zoomPos"]) {
                     L.control.zoom({
                         position: options["zoomPos"]
                     }).addTo(_map);
                 }
                 if (options["legend"]) {
                     var legend = L.control({position: options["legendPos"] || 'bottomleft'});
                     legend.onAdd = function(map) {
                         var div = L.DomUtil.create('div', 'legend');
                         div.setAttribute('style', 'background:white; border-radius: 6px;');
                         div.innerHTML += options["legend"];
                         return div;
                     };
                     legend.addTo(_map);
                 }
                 if (options["drawControl"]) {
                     _map.addLayer(_draw_group);
                     var drawOptions = {
                         position: options["drawControlPos"] || 'topleft',
                         draw: {
                             polyline: options["drawPolyline"] || false,
                             polygon: {
                                 showArea: true,
                                 metric: false,
                                 allowIntersection: false, // Restricts shapes to simple polygons
                                 drawError: {
                                     color: '#e10000', // Color the shape will turn when intersects
                                     message: "Can't draw a polygon with intersecting lines." // Message that will show when intersect
                                 },
                                 guideLayers: options["polygonGuide"] ,
                                 snapDistance:options["polygonSnapDistance"]
                             },
                             circle: false,
                             rectangle: {
                                 showArea: true,
                                 metric: false,
                                 shapeOptions: {
                                     clickable: false
                                 }
                             },
                             marker: false,
                             circlemarker: false
                         },
                         edit: {
                             featureGroup: _draw_group,
                             remove: true
                         }
                     };
                     var drawControl = new L.Control.Draw(drawOptions);
                     drawControl.addTo(_map);
                     _map.on('draw:created', function(e) {
                         //console.log(e.layer);
                         _draw_group.addLayer(e.layer);
                     });
                     _map.on('draw:edited', function(e) {
                         //console.log(e);
                     });
                     _map.on('draw:deleted', function(e) {
                         /*setTimeout(function() {
                          for (i in e.layers._layers) {
                          if (e.layers._layers[i] instanceof L.Layer)
                          _draw_group.addLayer(e.layers._layers[i]);
                          }
                          }, 5000);*/
                     });
                 }
                 _clusterOptions = options["clusterOptions"];
                 if (_clusterOptions && _clusterOptions['splitClusters']) {
                     _splitClusters = _clusterOptions['splitClusters'];
                     _map.on('zoomend', _updateClusters);
                 }
                 if (options["clusterPie"]) {
                     _category = options["category"];
                     _clusterData = options["clusterData"];
                     _cluster_group = {'default':L.markerClusterGroup({
                         maxClusterRadius: 60,
                         iconCreateFunction: _createPieChart
                     })};
                 }
                 else {/*
                     _cluster_group = {'default':L.markerClusterGroup({
                         maxClusterRadius: _clusterOptions.maxRad ? 160 : 80,
                         disableClusteringAtZoom: _clusterOptions.disableZoom || undefined,
                         spiderfyOnMaxZoom: _clusterOptions.disableZoom ? false : true
                     })};
                     */
                 }
             }
             o._map = _map;//temporary for testing
 
             _map.attributionControl.setPrefix('');
 
             _map.on('mouseup', function() {
 
                 if (_mode & XYZ.MODE.DRAG) {
                     //update lines
                     for (var i in _nodes) {
                         var n = _nodes[i];
                         n.y = n.marker.getLatLng().lat;
                         n.x = n.marker.getLatLng().lng;
                     }
 
                     for (var e in _edges) {
                         //console.log(" updating edges");
                         _updateEdge(_edges[e]);
                     }
                 }
             });
 
 
             if (_mode & XYZ.MODE.DRAG || _mode & XYZ.MODE.STATIC) {
                 _map.addLayer(_drag_group);
             } else {
                 if(_cluster_group){_cluster_group['default'].on("animationend", _handleAnimateEnd);}
                 for (i in _cluster_group) _map.addLayer(_cluster_group[i]);
             }
 
             _map.addLayer(_edge_group);
             _map.addLayer(_overlay_group);
            
             return o;
         };
 
 
         o.autoLayoutNetwork = function(bounds) {
             var container = $("#vis_map");
             if (container.length < 1) {
                 container = $("<div id='vis_map' style='display:none;position:absolute:z-index:-5000;'></div>");
                 $("#" + _viewport_id).append(container);
             }
 
             container = $("#vis_map")[0];
 
             var ns = [];
             var es = [];
 
             for (var i in _nodes) {
                 var n = _nodes[i];
                 ns.push({id: n.id, label: "f"});
             }
 
             for (var i in _edges) {
                 var e = _edges[i];
                 es.push({from: e.n1.id, to: e.n2.id});
             }
 
             var data = {
                 nodes: new vis.DataSet(ns),
                 edges: new vis.DataSet(es)
             };
 
             var gennet = new vis.Network(container, data, _vis_options);
 
             _positions = gennet.getPositions();
             var minx = 1000000;
             var miny = 1000000;
             var maxx = -1000000;
             var maxy = -1000000;
             for (var i in _positions) {
                 var x = _positions[i].x;
                 var y = _positions[i].y;
                 if (x < minx)
                     minx = x;
                 if (x > maxx)
                     maxx = x;
                 if (y < miny)
                     miny = y;
                 if (y > maxy)
                     maxy = y;
             }
 
             //console.log(" bounds="+minx+","+miny+"  to "+maxx+","+maxy);
             //console.log(" new bounds="+bounds.minx+","+bounds.miny+" to "+bounds.maxx+","+bounds.maxy);
             //apply to bounds
             if (bounds) {
                 var dx = maxx - minx;
                 var dy = maxy - miny;
                 var bdx = bounds.maxx - bounds.minx;
                 var bdy = bounds.maxy - bounds.miny;
 
                 var scalex = bdx / dx;
                 var scaley = bdy / dy;
                 //console.log(" scalex="+scalex+" scaley="+scaley);   
                 for (var i in _positions) {
                     var x = _positions[i].x;
                     var y = _positions[i].y;
                     _positions[i].x = bounds.minx + (x - minx) * scalex;
                     _positions[i].y = bounds.miny + (y - miny) * scaley;
                     //console.log("i="+i+" x="+_positions[i].x+" y="+_positions[i].y);
                 }
             }
 
             for (var i in _nodes) {
                 var n = _nodes[i];
                 //console.log("setting n:"+n.id+" x="+_positions[i].x+","+_positions[i].y);         
                 n.x = _positions[i].x;
                 n.y = _positions[i].y;
                 n.marker.setLatLng(L.latLng(n.y, n.x));
             }
 
             for (var e in _edges) {
                 _updateEdge(_edges[e], true);
             }
 
         };
 
 
         o.setEdgeAttr = function(attr) {
             _attr = attr;
         };
 
         var _handleAnimateEnd = function() {
             //console.log(" zoom ended");
             if (_mode & XYZ.MODE.CLUSTER) {
                 setTimeout(_handleZoomChange, 250);
             }
         };
 
         o.setNodeLatLng = function(id, lat, lng) {
             var n = _nodes[id];
             if (n) {
                 n.y = lat;
                 n.x = lng;
                 n.marker.setLatLng(L.latLng(n.y, n.x));
             }
         };
 
         var _getParent = function(n) {
             return _cluster_group[n.marker.clusterName].getVisibleParent(n.marker);
         };
 
         o.setZoom = function(lvl) {
             _map.setZoom(lvl);
             return o;
         };
 
         o.setLatLongZoom = function(lat, long, zoom) {
             _map.setView(L.latLng(lat, long), zoom);
             return o;
         };
 
         o.center = function() {
             //var cll=_cluster_group._topClusterLevel._latlng;
             // var z=_cluster_group._topClusterLevel._group._zoom;
             //var m=null;//_cluster_group._topClusterLevel._childClusters[0].__parent;
 
             // console.log(" center bounds="+_drag_group.getBounds().toString());
 
             if (_mode & XYZ.MODE.CLUSTER) {
                 //suspend zoom animation update
                 _cluster_group['default'].off("animationend", _handleAnimateEnd);
 
                 _map.setZoom(2);
                 var cnt = 40;
                 var n = null;
                 for (var i in _nodes) {
                     n = _nodes[i];
                     break;
                 }
                 var cnt = 0;
                 var m = n.marker;
                 var top = m;
                 m = m.__parent;
                 //console.log(" m="+m._markers.length);
                 while (m._zoom > -1 && cnt < 40) {
                     ++cnt;
                     top = m;
                     m = m.__parent;
                     //console.log("incrementing parent len="+m._markers.length+" zoom="+m._zoom);
                 }
                 //console.log("z="+z);
                 //o.setLatLongZoom(cll.lat,cll.lng,z);
                 if (top && top.zoomToBounds) {
 //need to work here --on consecutive centerings --keeps zooming
                     // console.log(" top"+top._zoom);
                     top.zoomToBounds();
                 } else {
                     _map.fitBounds(_cluster_group['default'].getBounds());
                 }
                 //z=_map._zoom;
                 //cll=top._latlng;
                 //o.setLatLongZoom(cll.lat,cll.lng,z);
                 //o.top.unspiderfy();
                 //
                 //
                 //reinstate animate end
                 _cluster_group['default'].on("animationend", _handleAnimateEnd);
                 if (_map._zoom >= 20)
                     _map.setZoom(19);
             } else {
                 _map.fitBounds(_drag_group.getBounds());
             }
         };
 
         o.setTileLayer = function(tile) {
             _tile_type = tile;
             if (_tile_type & XYZ.TILE.MAP) {
                 _tile_layer.setOpacity(1.0);
                 _tile_layer.setUrl(_map_url);
             } else {
                 _tile_layer.setOpacity(_grid_opacity);
                 _tile_layer.setUrl(_grid_url);
             }
         };
         
         o.setMapUrl = function(url) {
             _map_url = url;
             _tile_layer.setUrl(_map_url);
         }
 
         o.getMode = function() {
             return _mode;
         };
 
         o.setMode = function(mode) {
 
 //need rules here so modes are compatible
 //or seperate functions for different modes
 
             //if(typeof mode ==='undefined') { mode=_mode;}
             _mode = mode;
 
             if (_mode & XYZ.MODE.DRAG) {
                 for (var i in _aggr_line_map) {
                     _log(" removing aggr line id=" + i + " obj=" + _aggr_line_map[i] + "  id=" + _aggr_line_map[i]._leaflet_id);
                     _edge_group.removeLayer(_aggr_line_map[i]);
                 }
 
                 for (i in _cluster_group) _map.removeLayer(_cluster_group[i]);
                 _map.addLayer(_drag_group);
                 _drag_group.eachLayer(function(layer) {
                     if (layer.dragging && layer.node) {
                         layer.dragging.enable();
                     }
                 });
 
                 for (var i in _edges) {
                     _edges[i].cluster_marker1 = null;
                     _edges[i].cluster_marker2 = null;
                     _showEdge(_edges[i]);
                     _updateEdge(_edges[i]);
                 }
             } else if (_mode & XYZ.MODE.STATIC) {
                 for (var i in _aggr_line_map) {
                     _log(" removing aggr line id=" + i + " obj=" + _aggr_line_map[i] + "  id=" + _aggr_line_map[i]._leaflet_id);
                     _edge_group.removeLayer(_aggr_line_map[i]);
                 }
 
                 for (i in _cluster_group) _map.removeLayer(_cluster_group[i]);
                 _map.addLayer(_drag_group);
                 _drag_group.eachLayer(function(layer) {
                     if (layer.dragging && layer.node) {
                         layer.dragging.disable();
                     }
                 });
 
                 for (var i in _edges) {
                     _edges[i].cluster_marker1 = null;
                     _edges[i].cluster_marker2 = null;
                     _showEdge(_edges[i]);
                     _updateEdge(_edges[i]);
                 }
 
             } else { //cluster
 
                 _map.removeLayer(_drag_group);
                 for (i in _cluster_group) _cluster_group[i].clearLayers();
                 delete _cluster_group;
                 if (_clusterOptions && _clusterOptions.pieChart) {
                     _cluster_group = {'default':L.markerClusterGroup({
                         maxClusterRadius: 60,
                         iconCreateFunction: _createPieChart
                     })};
                 }
                 else {
                     _cluster_group = {'default':L.markerClusterGroup({
                         maxClusterRadius: (_clusterOptions && _clusterOptions.maxRad) ? 160 : 80,
                         disableClusteringAtZoom: (_clusterOptions && _clusterOptions.disableZoom) || undefined,
                         spiderfyOnMaxZoom: (_clusterOptions && _clusterOptions.disableZoom) ? false : true
                     })};
                 }
                 for (i in _cluster_group) _map.addLayer(_cluster_group[i]);
                 _line_map = {};
                 _aggr_line_map = {};
 
                 for (var i in _edges) {
                     _edges[i].cluster_marker1 = null;
                     _edges[i].cluster_marker2 = null;
 
                 }
 
                 for (i in _nodes) {
                     _nodes[i].marker.dragging.disable();
                     _nodes[i].marker.__parent = null;
                     _nodes[i]._zoom = null;
                     if (_nodes[i].marker.clusterName) _cluster_group[_nodes[i].marker.clusterName].addLayer(_nodes[i].marker);
                     else _cluster_group['default'].addLayer(_nodes[i].marker);
                 }
 
                 _cluster_group['default'].on("animationend", _handleAnimateEnd);
 
                 _handleZoomChange();
 
             }
 
             return o;
         };
 
 
 
         o.addIcon = function(name, marker_icon) {
             XYZ._icon_map[name] = marker_icon;
             return o;
         };
 
         o.getNodes = function() {
             return _nodes;
         };
 
         o.removeNodes = function(nodes) {
             for (i in nodes) {
                 var n=nodes[i];
                 if (!(n instanceof XYZ.Node)) {
                     n = _nodes["" + n];
                 }
 
                 _drag_group.removeLayer(n.marker);
                 if (_mode & XYZ.MODE.CLUSTER) {
                     if (_cluster_group['default'].hasLayer(n.marker)) _cluster_group['default'].removeLayer(n.marker);
                     if (n.marker.clusterName && _cluster_group[n.marker.clusterName].hasLayer(n.marker)) _cluster_group[n.marker.clusterName].removeLayer(n.marker);
                 }
             }
             o.update();
 //need code for fixing edges --if there node(s) are gone should they be removed too?        
         };
 
         o.removeNode = function(n) {
             if (!(n instanceof XYZ.Node)) {
                 n = _nodes["" + n];
             }
 
             _drag_group.removeLayer(n.marker);
             if (_mode & XYZ.MODE.CLUSTER) {
                 if (_cluster_group['default'].hasLayer(n.marker)) _cluster_group['default'].removeLayer(n.marker);
                 if (n.marker.clusterName && _cluster_group[n.marker.clusterName].hasLayer(n.marker)) _cluster_group[n.marker.clusterName].removeLayer(n.marker);
             }
             o.update();
 //need code for fixing edges --if there node(s) are gone should they be removed too?        
         };
 
         o.addNode = function(n) {
             if (!(n instanceof XYZ.Node)) {
                 n = _nodes["" + n];
             }
             if (_clusterData) {
                 var feature = {
                     type: "Feature",
                     properties: {}
                 };
                 if (n.info)
                     feature.properties[_category] = n.info.category || "4";
                 else
                     feature.properties[_category] = "4";
                 n.marker.feature = feature;
                 _clusterData["features"].push(feature);
                 d3.json(JSON.stringify(_clusterData));
             }
             _drag_group.addLayer(n.marker);
             if (_mode & XYZ.MODE.CLUSTER) {
                 if (n.marker.clusterName) _cluster_group[n.marker.clusterName].addLayer(n.marker);
                 else _cluster_group['default'].addLayer(n.marker);
             }
             _handleMarkers(n.marker);
             _nodes[n.id] = n;
             return o;
         };
 
         o.addNodes = function(nodes) {
             for (var i in nodes) {
                 var nj = nodes[i];
                 var n = XYZ.node(nj.id, nj.x, nj.y, nj.options);
                 o.addNode(n);
                 //_drag_group.addLayer(n.marker);
                 //_cluster_group.addLayer(n.marker);
                 //_handleMarkers(n.marker);
                 //_nodes[n.id] = n;
             }
             if (_splitClusters) _updateClusters();
             o.update();
             return o;
         };
         
         
         o.removeEdges = function(edges) {
             for (var i in edges){
                 var e=edges[i]; 
                 _edge_group.removeLayer(e.polyline);
                 e.in_layer = false;
                 delete _edges[e.id];
             } 
             o.update();
             return o;
         };
         
 
         o.removeEdge = function(e) {
             _edge_group.removeLayer(e.polyline);
             e.in_layer = false;
             delete _edges[e.id];
             o.update();
             return o;
         };
 
         o.hasNode = function(id) {
             return _nodes[id];
         };
 
         o.hasEdge = function(id) {
             return _edges[id];
         };
 
         //////////////////////   drawing toolbar /////////////////
 
         o.initSelectionBar = function(callback) {
             var draw_group = new L.FeatureGroup();
             _map.addLayer(draw_group);
             var drawControl = new L.Control.Draw({edit: {featureGroup: draw_group}}).addTo(_map);
             _map.on('draw:created', function(e) {
                 // draw_group.addLayer(e.layer);
                 // console.log("lat longs="+e.layer.getLatLngs());
                 callback(e);
             });
             _map.removeLayer(drawControl);
         };
 
 
 
 
         //new generic add function
 
         o.add = function(o) {
             if (o instanceof XYZ.Polygon) {
                 _overlay_group.addLayer(o.poly);
             } else if (o instanceof XYZ.Polyline) {
                 _overlay_group.addLayer(o.poly);
             } else if (o instanceof XYZ.Circle) {
                 _overlay_group.addLayer(o.circle);
             }
 
             return o;
         };
 
 
         var _handleMarkers = function(m) {
             if (_mode & XYZ.MODE.DRAG) {
                 if (m.dragging) {
                     m.dragging.enable();
                 }
             } else {
                 if (m.dragging) {
                     m.dragging.disable();
                 }
                 else {
                     //n.marker._initInteraction();
                     //this is needed in the case of marker cluster --which is not setting this 
                     //-- see L.marker._initInteraction();
                     m.dragging = new L.Handler.MarkerDrag(m);
                     m.dragging.disable();
                 }
             }
         };
 
         var _createPieChart = function(cluster) {
             var children = cluster.getAllChildMarkers(),
                     n = children.length, //Get number of markers in cluster
                     strokeWidth = 1, //Set clusterpie stroke width
                     r = _clusterOptions.maxRad - 2 * strokeWidth - (n < 10 ? 12 : n < 100 ? 8 : n < 1000 ? 4 : 0), //Calculate clusterpie radius...
                     iconDim = (r + strokeWidth) * 2, //...and divIcon dimensions (leaflet really want to know the size)
                     data = d3.nest() //Build a dataset for the pie chart
                     .key(function(d) {
                         return d.feature.properties[_category];
                     })
                     .entries(children, d3.map),
                     //bake some svg markup
                     html = _createClusterIcon({data: data,
                         valueFunc: function(d) {
                             return d.values.length;
                         },
                         strokeWidth: 1,
                         outerRadius: r,
                         innerRadius: r - 10,
                         pieClass: 'cluster-pie',
                         pieLabel: n,
                         pieLabelClass: 'marker-cluster-pie-label',
                         pathClassFunc: function(d) {
                             return "category-" + d.data.key;
                         },
                         pathTitleFunc: function(d) {
                             return d.data.values.length;
                         }
                     }),
             //Create a new divIcon and assign the svg markup to the html property
             myIcon = new L.DivIcon({
                 html: html,
                 className: 'marker-cluster',
                 iconSize: new L.Point(iconDim, iconDim)
             });
             return myIcon;
         };
 
         var _createClusterIcon = function(options) {
             /*data and valueFunc are required*/
             if (!options.data || !options.valueFunc) {
                 return '';
             }
             
             var data = options.data,
                     valueFunc = options.valueFunc,
                     r = options.outerRadius ? options.outerRadius : 28, //Default outer radius = 28px
                     rInner = options.innerRadius ? options.innerRadius : r - 10, //Default inner radius = r-10
                     strokeWidth = options.strokeWidth ? options.strokeWidth : 1, //Default stroke is 1
                     pathClassFunc = options.pathClassFunc ? options.pathClassFunc : function() {
                         return '';
                     }, //Class for each path
                     pathTitleFunc = options.pathTitleFunc ? options.pathTitleFunc : function() {
                         return '';
                     }, //Title for each path
                     pieClass = options.pieClass ? options.pieClass : 'marker-cluster-pie', //Class for the whole pie
                     pieLabel = options.pieLabel ? options.pieLabel : d3.sum(data, valueFunc), //Label for the whole pie
                     pieLabelClass = options.pieLabelClass ? options.pieLabelClass : 'marker-cluster-pie-label', //Class for the pie label
 
                     origo = (r + strokeWidth), //Center coordinate
                     w = origo * 2, //width and height of the svg element
                     h = w,
                     donut = d3.layout.pie(),
                     arc = d3.svg.arc().innerRadius(rInner).outerRadius(r);
 
             //Create an svg element
             var svg = document.createElementNS(d3.ns.prefix.svg, 'svg');
             //Create the pie chart
             var vis = d3.select(svg)
                     .data([data])
                     .attr('class', pieClass)
                     .attr('width', w)
                     .attr('height', h);
 
             var arcs = vis.selectAll('g.arc')
                     .data(donut.value(valueFunc))
                     .enter().append('svg:g')
                     .attr('class', 'arc')
                     .attr('transform', 'translate(' + origo + ',' + origo + ')');
 
             arcs.append('svg:path')
                     .attr('class', pathClassFunc)
                     .attr('stroke-width', strokeWidth)
                     .attr('d', arc)
                     .append('svg:title')
                     .text(pathTitleFunc);
 
             vis.append('text')
                     .attr('x', origo)
                     .attr('y', origo)
                     .attr('class', pieLabelClass)
                     .attr('text-anchor', 'middle')
                     //.attr('dominant-baseline', 'central')
                     /*IE doesn't seem to support dominant-baseline, but setting dy to .3em does the trick*/
                     .attr('dy', '.3em')
                     .text(pieLabel);
             //Return the svg-markup rather than the actual element
             return _serializeXmlNode(svg);
         };
 
         var _serializeXmlNode = function(xmlNode) {
             if (typeof window.XMLSerializer !== "undefined") {
                 return (new window.XMLSerializer()).serializeToString(xmlNode);
             } else if (typeof xmlNode.xml !== "undefined") {
                 return xmlNode.xml;
             }
             return "";
         };
 
         o.addEdge = function(e) {
             e.init(o, _friendly_map);
             _edge_group.addLayer(e.polyline);
             e.in_layer = true;
             _edges[e.id] = e;
             _updateEdgeLite(e);
             return o;
         };
 
         o.addEdges = function(edges) {
             for (var i in edges) {
                 var ej = edges[i];
                 //console.log(" n1="+ej.n1+" obj="+_nodes[ej.n1].x);
                 var e = XYZ.edge(ej.id, _nodes[ej.n1], _nodes[ej.n2], ej.options);
                 o.addEdge(e);
             }
             o.update();
             return o;
         };
 
         o.getPoly = function(leafletId) {
             return _draw_group.getLayer(leafletId);
         };
 
         o.drawPolyFromLatlngs = function(latlngs, leafletId, options) {
             var poly;
             if (leafletId) {
 //is this correct?                
                 if (poly = _draw_group.getLayer(leafletId)) {
                     _map.fitBounds(poly.getBounds());
                     return leafletId;
                 }
             }
             poly = new L.Polygon(latlngs);
             _draw_group.addLayer(poly);
             _map.fitBounds(poly.getBounds());
             return poly._leaflet_id;
         };
 
         o.removePoly = function(id) {
             _draw_group.removeLayer(id);
         };
 
         o.reset = function(keepDrawn) {
             _edges = {};
             _nodes = {};
             _line_map = {};
             _aggr_line_map = {};
             if (_clusterData)
                 _clusterData["features"] = [];
             _drag_group.clearLayers();
             if (_mode & XYZ.MODE.CLUSTER) {
                 _cluster_group['default'].off("animationend", _handleAnimateEnd);
                 for (var i in _cluster_group) {
                     _cluster_group[i].clearLayers();
                     _map.removeLayer(_cluster_group[i]);
                     delete _cluster_group[i];
                 }
                 _cluster_group = {};
                 if (_clusterOptions && _clusterOptions.pieChart) {
                     _cluster_group = {'default':L.markerClusterGroup({
                         maxClusterRadius: 60,
                         iconCreateFunction: _createPieChart
                     })};
                 }
                 else {
                     _cluster_group = {'default':L.markerClusterGroup({
                         maxClusterRadius: _clusterOptions && _clusterOptions.maxRad ? 160 : 80,
                         disableClusteringAtZoom: _clusterOptions && _clusterOptions.disableZoom || undefined,
                         spiderfyOnMaxZoom: _clusterOptions && _clusterOptions.disableZoom ? false : true
                     })};
                 };
                 _frozen = {};
                 for (var i in _cluster_group) {_map.addLayer(_cluster_group[i]);}
                 if(_clusterOptions){_cluster_group['default'].on("animationend", _handleAnimateEnd);}
             }
             _edge_group.clearLayers();
             if (!keepDrawn) {_draw_group.clearLayers();}
         };
 
         _getParentAtZoomLevel = function(node, zoomlevel) {
             var m = node.marker.__parent;
             if (node.marker.clusterName && _frozen[node.marker.clusterName]) return node.marker;
             var max_loop = 0;
 
             //_log(" nid=" + node.id + " begin search... marker id=" + m._leaflet_id + " zoom=" + zoomlevel);
             while (m && !m._icon && m._zoom > zoomlevel && max_loop < 40) {
                 var ml = m.getLatLng().toString();
                 m = m.__parent;
                 _log("  inside while finding _icon=" + m._icon + " id=" + m._leaflet_id + " lat long=" + ml + " z=" + m._zoom);
                 ++max_loop;
             }
 
             if (m && m._zoom === zoomlevel) {
                 return m;
             }
             return null;
         };
 
         o.update = function() {
             //console.log(" updating map --mode="+_mode+" attr="+_attr);
 
             for (var i in _edges) {
                 _updateEdge(_edges[i], true);
                 _showEdge(_edges[i]);
             }
 
             if (_mode & XYZ.MODE.CLUSTER) {
                 _handleZoomChange();
             }
         };
 
         ///////////////////// built in handlers
 
 
         var _handleZoomChange = function() {
             //console.log("----- zoom level=" + _map.getZoom() + "----");
 
             //TODO  cache current parent to improve getParentAtZoomLevel traversing.
 
             //clear the last groupings
             for (var i in _aggr_line_map) {
                 _log(" removing aggr line id=" + i + " obj=" + _aggr_line_map[i] + "  id=" + _aggr_line_map[i]._leaflet_id);
                 _edge_group.removeLayer(_aggr_line_map[i]);
 
             }
             _aggr_line_map = {};
             _line_map = {};
             var update_list = {};
 
             _log(" ----------------------------");
 
             for (var i in _edges) {
                 var e = _edges[i];
                 var n1 = e.n1;
                 var n2 = e.n2;
                 var p1 = _getParentAtZoomLevel(n1, _map.getZoom());
                 var p2 = _getParentAtZoomLevel(n2, _map.getZoom());
                 //console.log(" p1="+p1+" p2="+p2);
                 _log("----" + _edges.length + "  testing edge n1=" + n1.id + "  n2=" + n2.id);
 
                 if (p1) {
                     if (e.lat1 !== p1._latlng.lat || e.lng1 !== p1._latlng.lng) {
                         e.lat1 = p1._latlng.lat;
                         e.lng1 = p1._latlng.lng;
                         update_list[e.id] = e;
                     }
                     _log(" p1 parent found  nid=" + n1.id + " p1 lat=" + e.lat1 + " lng=" + e.lng1);
                     e.cluster_marker1 = p1;
 
                 } else {
                     if (e.lat1 !== n1.marker.getLatLng().lat || e.lng1 !== n1.marker.getLatLng().lng) {
                         e.lat1 = n1.marker.getLatLng().lat;
                         e.lng1 = n1.marker.getLatLng().lng;
                         update_list[e.id] = e;
                     }
                     e.cluster_marker1 = null;
                 }
 
                 if (p2) {
                     if (e.lat2 !== p2._latlng.lat || e.lng2 !== p2._latlng.lng) {
                         e.lat2 = p2._latlng.lat;
                         e.lng2 = p2._latlng.lng;
                         update_list[e.id] = e;
                     }
                     e.cluster_marker2 = p2;
 
                     _log(" p2  parent found  nid=" + n2.id + " p2 lat=" + e.lat2 + " lng=" + e.lng2);
                 }
                 else {
                     if (e.lat2 !== n2.marker.getLatLng().lat || e.lng2 !== n2.marker.getLatLng().lng) {
                         e.lat2 = n2.marker.getLatLng().lat;
                         e.lng2 = n2.marker.getLatLng().lng;
                         update_list[e.id] = e;
                     }
                     e.cluster_marker2 = null;
                 }
 
                 var n1 = e.cluster_marker1 !== null ? e.cluster_marker1 : e.n1.marker;
                 var n2 = e.cluster_marker2 !== null ? e.cluster_marker2 : e.n2.marker;
                 var id = 0;
                 if (n1._leaflet_id < n2._leaflet_id) {
                     id = n1._leaflet_id + "-" + n2._leaflet_id;
                 } else {
                     id = n2._leaflet_id + "-" + n1._leaflet_id;
                 }
 
                 if (_line_map[id]) {
                     _line_map[id].push(e);
                     if (_line_map[id].length > 1) {
                         update_list[e.id] = null;//remove all further groupings
                     }
                 }
                 else {
                     _line_map[id] = [e];
                 }
             }
 
             for (var i in update_list) {
                 var e = update_list[i];
                 if (e !== null) {
                     _updateEdge(e);
                 }
             }
 
             for (var i in _line_map) {
                 var m = _line_map[i];
                 if (m && m.length > 1) {
                     //console.log("i=" + i + " more than one edge num=" + m.length);
                     for (var j in m) {
                         _hideEdge(m[j]);
                     }
 
                     var pline = L.polyline(m[0].polyline.getLatLngs(), m[0].line_attr);
                     if (_attr & XYZ.ATTR.EDGE_AGGR_TEXT) {
                         //console.log(" doing line aggr");                     
                         pline.setText("" + m.length, {center: true, attributes: m[0].text_attr});
                     }
 //popup details is not in xyz.css
 //added attribute for doing EDGE aggregation of popup text
                     if (_attr & XYZ.ATTR.EDGE_AGGR_POPUP) {
                         var popup = "<div class='popup-details' style='background:white;'><div style='max-height:400px; min-width:400px; overflow-y:scroll;'>";
                         for (j in m) {
                             if (m[j].popup)
                             {
                                 popup += m[j].popup.html;
                             }
 
                             if (j < m.length - 1)
                                 popup += "<div style='height:0; border-bottom:2px dashed #555; width:100%; margin:5px 0 10px;'></div>";
                         }
                         popup += "</div></div>";
                         pline.bindPopup(popup);
                     }
 
                     _aggr_line_map[i] = pline;
                     _log(" adding aggr id=" + i + "  id=" + pline._leaflet_id);
                     _edge_group.addLayer(pline);
 
                 }
             }
 
 
             return o;
         };
 
         var _hideEdge = function(e) {
             _edge_group.removeLayer(e.polyline);
             // console.log(" removing edge id=" + this.id);
             e.in_layer = false;
         };
 
         var _showEdge = function(e) {
             if (!e.in_layer) {
                 _edge_group.addLayer(e.polyline);
                 _log(" adding edge id=" + e.id);
                 e.in_layer = true;
                 if (!e.text_init) {
                     e.text_init = true;
 //only do this once visible--its the major source of slowdown
                     if (_attr & XYZ.ATTR.EDGE_TEXT) {
                         //console.log(" doing edge text attr="+_attr);
                         e.polyline.setText(e.text, {center: true, attributes: e.text_attr});
                     }
                 }
             }
         };
 
         var _updateEdge = function(e, override) {
             //this address text on the line --line must flow from left to right to keep string upright         
             if (e.cluster_marker1 !== null && e.cluster_marker1 === e.cluster_marker2) {
                 //console.log(" updating edge hide edge");               
                 _hideEdge(e);
             } else {
                 _showEdge(e);
             }
 //under review --here for efficiency should this be done all time --will markers location ever change
             if ((_mode & XYZ.MODE.DRAG) || override) {
                 e.lat1 = e.n1.marker.getLatLng().lat;
                 e.lng1 = e.n1.marker.getLatLng().lng;
                 e.lat2 = e.n2.marker.getLatLng().lat;
                 e.lng2 = e.n2.marker.getLatLng().lng;
                 //console.log(" updating polyline lat longs");
             }
 
             var x1 = e.lng1;
             var x2 = e.lng2;
             //console.log("edge  x1=" + x1 + " x2=" + x2);
             if (e.polyline !== null) {
                 if (x1 > x2) {
                     e.polyline.setLatLngs([L.latLng(e.lat2, e.lng2), L.latLng(e.lat1, e.lng1)]);
                 } else {
                     e.polyline.setLatLngs([L.latLng(e.lat1, e.lng1), L.latLng(e.lat2, e.lng2)]);
                 }
             }
 
             return e;
         };
 
         var _updateEdgeLite = function(e) {
             e.tag_for_update = false;
 
             if (e.cluster_marker1 !== null && e.cluster_marker1 === e.cluster_marker2) {
                 _hideEdge(e);
             } else {
                 _showEdge(e);
             }
 
             return e;
         };
 
 
         _friendly_map._updateEdgeLite = _updateEdgeLite;
 
         return o;
     }; /// end Map
 ////////////////////////////////////////////////
     //polygon
 
     XYZ.polygon = function(id, points, options) {
         var e = new XYZ.Polygon(id, points, options);
         return e;
     };
 
     XYZ.Polygon = function(id, points/*[{lat:44,lng:-122}]*/, options) {
 
         this.id = id;
         this.points = points;
         this.options = options;
         this.poly = L.polyline(points, options);
     };
 
     XYZ.Polygon.prototype = {
         test: function(point, vs) {
         }
     };
 
     ////////////////////////////////////////////////
     //polyline
 
     XYZ.polyline = function(id, points/*[{lat:44,lng:-122}]*/, options) {
         var e = new XYZ.Polyline(id, points, options);
         return e;
     };
 
     XYZ.Polyline = function(id, points, options) {
 
         this.id = id;
         this.points = points;
         this.options = options;
         this.poly = L.polyline(points, options);
     };
 
     XYZ.Polyline.prototype = {
         test: function(point, vs) {
         }
     };
 
     ////////////////////////////////////////////////
     //circle
 
     XYZ.circle = function(id, points, options) {
         var e = new XYZ.Circle(id, points, options);
         return e;
     };
 
     XYZ.Circle = function(id, point/*{lat:44,lng:-122}*/, radius/*km*/, options) {
 
         this.id = id;
         this.points = point;
         this.radius = radius;
         this.options = options;
         this.circle = L.circle(point, radius, options);
     };
 
     XYZ.Circle.prototype = {
         test: function(point, vs) {
         }
     };
 
     ///////////////////////////
     ////////////  UTILS
     ///////////////////////////////////
 
 
     XYZ.Util = {
         inside: function(point, vs) {
             // ray-casting algorithm based on
             // http://www.ecse.rpi.edu/Homepages/wrf/Research/Short_Notes/pnpoly.html
             // array of coordinates of each vertex of the polygon
             //var polygon = [ [ 1, 1 ], [ 1, 2 ], [ 2, 2 ], [ 2, 1 ] ];
             //inside([ 1.5, 1.5 ], polygon); // true
 
             var x = point[0], y = point[1];
 
             var inside = false;
             for (var i = 0, j = vs.length - 1; i < vs.length; j = i++) {
                 var xi = vs[i][0], yi = vs[i][1];
                 var xj = vs[j][0], yj = vs[j][1];
 
                 var intersect = ((yi > y) != (yj > y))
                         && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
                 if (intersect)
                     inside = !inside;
             }
 
             return inside;
         },
         getDegreesFromDegMinSec: function(val) {
 
             var deg_arr = val.split("-");
             var deg = val;
             if (deg_arr.length > 2) {
                 // min seconds convert to dec
                 deg = parseInt(deg_arr[0]);
                 var m = 0;
                 if (deg_arr.length > 3) {
                     deg = parseInt(deg_arr[1]);
                     m = deg_arr[2] / 60 + deg_arr[3] / 3600;
                     //console.log("2="+deg_arr[2]+" 3="+deg_arr[3]+" m="+m+" deg="+deg);
                     deg = -deg - m;
                 }
                 else {
                     m = deg_arr[1] / 60 + deg_arr[2] / 3600;
                     deg += m;
                 }
             }
             //console.log(" before val="+val+" after="+deg);
             return deg;
         },
         getDistanceBetween: function(lat1, lng1, lat2, lng2) {
 
             //Haversine
             //formula:	a = sin²(Δφ/2) + cos φ1 ⋅ cos φ2 ⋅ sin²(Δλ/2)
             //c = 2 ⋅ atan2( √a, √(1−a) )
             //d = R ⋅ c
             //where	φ is latitude, λ is longitude, R is earth’s radius (mean radius = 6,371km);
             //note that angles need to be in radians to pass to trig functions!
             //JavaScript:	
 
             var R = 6371e3; // metres
             var phi1 = lat1.toRadians();
             var phi2 = lat2.toRadians();
             var delta_phi = (lat2 - lat1).toRadians();
             var delta_lambda = (lng2 - lng1).toRadians();
 
             var a = Math.sin(delta_phi / 2) * Math.sin(delta_phi / 2) +
                     Math.cos(phi1) * Math.cos(phi2) *
                     Math.sin(delta_lambda / 2) * Math.sin(delta_lambda / 2);
             var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
 
             var d = R * c;
             return d;
         },
         getDistanceBetweenLatLong: function(lat1, lng1, lat2, lng2) {
             var loc1 = L.latLng(lat1, lng1);
             var loc2 = L.latLng(lat2, lng2);
             var d = loc1.distanceTo(loc2);
             return d;
         },
         getLatLongJson: function(latlngs) {
             var coors = [];
             for (ind in latlngs) {
                 coors.push({lat: latlngs[ind].lat, lng: latlngs[ind].lng});
             }
             return coors;
         }
 
 
     };
 
 
 
 
     /////////////////////////////////////
     // node
     /////////////////////////////////////
 
     XYZ.Node = function(id, x, y, options) {
 
         this.id = id;
         this.x = x;
         this.y = y;
         this.marker_icon = options.icon;
         var _map;
 
         if (!options.icon) {
             this.marker_icon = XYZ._icon_map["node_marker"];
         }
 
         this.marker = L.marker([this.y, this.x], {icon: XYZ._icon_map[options.icon], draggable: true});
 
         //this.marker._node=this;
         this.edge = null;
         this.marker.node = this;
         this.tooltip = options.tooltip;
         this.popup = options.popup;
 
         if (this.tooltip) {
             if (!this.tooltip.options) {
                 this.tooltip.options = {permanent: false, direction: "bottom", className: "nitro-tooltip", opacity: 1.0};
             }
 
             //defaults
             if (!this.tooltip.options.direction) {
                 this.tooltip.options["direction"] = "bottom";
             }
 
             if (this.tooltip.options.permanent) {
                 this.tooltip.options.className = "nitro-label";
             }
 
             this.marker.bindTooltip(this.tooltip.text, this.tooltip.options);
         }
 
         if (this.popup) {
             this.marker.bindPopup(this.popup.html, this.popup.options);
         }
         
         if (options.markerOptions) {
             for (i in options.markerOptions) this.marker[i] = options.markerOptions[i];
         }
 
         this.attributes = {};
     };
 
     XYZ.Node.prototype = {
         data: function(name, value) {
             if (value) {
                 this.attributes[name] = value;
             }
             return this.attributes[name];
         },
         setTooltip: function(str, options) {
             this.marker.bindTooltip(str, options);
         },
         on: function(e, fnc) {
             this.marker.on(e, function() {
                 fnc(this.node);
             });
             return this;
         },
         setPosition: function(x, y) {
             this.x = x;
             this.y = y;
             if (this.edge !== null) {
                 this.edge.updateNode(p);
             }
             return this;
         },
         setMarker: function(marker) {
             this.marker = marker;
             return this;
         },
         setIcon: function(name) {
             this.marker_icon = XYZ._icon_map[name];
             if (this.marker !== null) {
                 //console.log(" mi="+this.marker_icon);
                 this.marker.setIcon(this.marker_icon);
             }
         }
     };
 
 
     //////////////////////////////////////////////////////////////
     // edge
     //////////////////////////////////////////////////////////////
 
 
     XYZ.Edge = function(id, n1, n2, options) {
         this.id = id;
         this.n1 = n1;
         this.n2 = n2;
         this._options = options;
         this._map;
         this._friendly_map;
 
 //move this to map        
         /*
          if (!(n1 instanceof XYZ.Node)) {
          console.log(" not a node n1="+n1);
          this.n1 = _nodes["" + n1];
          }
          
          if (!(n2 instanceof XYZ.Node)) {
          this.n2 = _nodes["" + n2];
          }
          */
 
         /*this.lat1 = this.n1.marker.getLatLng().lat;
          this.lng1 = this.n1.marker.getLatLng().lng;
          this.lat2 = this.n2.marker.getLatLng().lat;
          this.lng2 = this.n2.marker.getLatLng().lng;
          this.cluster_marker1 = null;
          this.cluster_marker2 = null;
          
          //edge states
          this.in_layer = false;
          this.text_init = false;
          
          this.text = options ? options.text : null;
          //NEED SOLUTION HERE!!!
          //need to add options for line and text attributes otherwise use global
          this.line_attr = XYZ.Map._line_attr;
          this.text_attr = XYZ.Map._text_attr;
          
          if (this.options) {
          if (this.options.text_attr) {
          this.text_attr = this.options.text_attr;
          }
          if (this.options.line_attr) {
          this.line_attr = this.options.line_attr;
          }
          }
          
          var x1 = this.lng1;
          var x2 = this.lng2;
          //_log(" x1=" + x1 + " x2=" + x2);
          if (this.polyline !== null) {
          if (x1 > x2) {
          this.polyline = L.polyline([L.latLng(this.lat2, this.lng2), L.latLng(this.lat1, this.lng1)], this.line_attr);
          } else {
          this.polyline = L.polyline([L.latLng(this.lat1, this.lng1), L.latLng(this.lat2, this.lng2)], this.line_attr);
          }
          }
          
          
          this.tooltip = options.tooltip;
          
          if (this.tooltip) {
          if (!this.tooltip.options) {
          this.tooltip.options = {sticky: true, permanent: false, direction: "bottom", className: "nitro-tooltip", opacity: 1.0};
          }
          
          //override
          this.tooltip.options.permanent = false;
          if (!this.tooltip.options.className) {
          this.tooltip.options.className = "nitro-label";
          }
          
          this.polyline.bindTooltip(this.tooltip.text, this.tooltip.options);
          }
          
          this.popup = options.popup;
          
          if (this.popup) {
          this.polyline.bindPopup(this.popup.html, this.popup.options);
          }
          */
     };
 
 
 
     XYZ.Edge.prototype = {
         init: function(map, friendly_map) {
             this._map = map;
             this._friendly_map = friendly_map;
 
 
             if (!(this.n1 instanceof XYZ.Node)) {
                 //console.log(" not a node n1=" + this.n1);
                 this.n1 = map.getNodes()["" + this.n1];
             }
 
             if (!(this.n2 instanceof XYZ.Node)) {
                 this.n2 = map.getNodes()["" + this.n2];
             }
 
             this.lat1 = this.n1.marker.getLatLng().lat;
             this.lng1 = this.n1.marker.getLatLng().lng;
             this.lat2 = this.n2.marker.getLatLng().lat;
             this.lng2 = this.n2.marker.getLatLng().lng;
             this.cluster_marker1 = null;
             this.cluster_marker2 = null;
 
             //edge states
             this.in_layer = false;
             this.text_init = false;
 
             this.text = this._options ? this._options.text : null;
 //NEED SOLUTION HERE!!!
 //need to add options for line and text attributes otherwise use global
             this.line_attr = XYZ.Map._line_attr;
             this.text_attr = XYZ.Map._text_attr;
 
             if (this._options) {
                 if (this._options.text_attr) {
                     this.text_attr = this._options.text_attr;
                 }
                 if (this._options.line_attr) {
                     this.line_attr = this._options.line_attr;
                 }
             }
             var x1 = this.lng1;
             var x2 = this.lng2;
             //_log(" x1=" + x1 + " x2=" + x2);
             if (this.polyline !== null) {
                 if (x1 > x2) {
                     this.polyline = L.polyline([L.latLng(this.lat2, this.lng2), L.latLng(this.lat1, this.lng1)], this.line_attr);
                 } else {
                     this.polyline = L.polyline([L.latLng(this.lat1, this.lng1), L.latLng(this.lat2, this.lng2)], this.line_attr);
                 }
             }
 
 
             this.tooltip = this._options.tooltip;
 
             if (this.tooltip) {
                 if (!this.tooltip.options) {
                     this.tooltip.options = {sticky: true, permanent: false, direction: "bottom", className: "nitro-tooltip", opacity: 1.0};
                 }
 
                 //override
                 this.tooltip.options.permanent = false;
                 if (!this.tooltip.options.className) {
                     this.tooltip.options.className = "nitro-label";
                 }
 
                 this.polyline.bindTooltip(this.tooltip.text, this.tooltip.options);
             }
 
             this.popup = this._options.popup;
 
             if (this.popup) {
                 this.polyline.bindPopup(this.popup.html, this.popup.options);
             }
 
             this._friendly_map._updateEdgeLite(this);
         },
         setText: function(text) {
             this.text = text;
             this.polyline.setText(this.text, {center: true, attributes: this.text_attr});
             return this;
         },
         setAttr: function(options) {
             this.polyline.setStyle(options);
             return this;
         },
         setNodes: function(n1, n2) {
             this.n1 = n1;
             this.n2 = n2;
             this.lat1 = n1.marker.getLatLng().lat;
             this.lng1 = n1.marker.getLatLng().lng;
             this.lat2 = n2.marker.getLatLng().lat;
             this.lng2 = n2.marker.getLatLng().lng;
             return this;
         }
     };
 
 
 
 
 
 
 
 ////////////////////////////////////////////////
 
     XYZ.map = function() {
         return new XYZ.Map();
     };
 
     XYZ.node = function(id, x, y, options) {
         return new XYZ.Node(id, x, y, options);
     };
 
     XYZ.edge = function(id, n1, n2, options) {
 
         var e = new XYZ.Edge(id, n1, n2, options);
         //XYZ._updateEdgeLite(e);
         // _updateEdgeLite(e);
         return e;
     };
 
 ///////////////////////////////////////////////////////////////////////////////////////////////////////
 
 
 
 
 
     XYZ.TILE = {};
     XYZ.TILE.MAP = 1;
     XYZ.TILE.GRID = 2;
 
     XYZ.ATTR = {};
     XYZ.ATTR.EDGE_TEXT = 1;
     XYZ.ATTR.EDGE_AGGR_TEXT = 2;
     XYZ.ATTR.EDGE_AGGR_POPUP = 4;
 
 
     XYZ.MODE = {};
     XYZ.MODE.DRAG = 1;
     XYZ.MODE.CLUSTER = 2;
     XYZ.MODE.STATIC = 4;
 
 
 
     XYZ._logging = false;
 
     XYZ._initIconLibrary = function(icon_path) {
         
         XYZ._icon_map = {
             "hub_green": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/hub_32_Green.png',
                 iconAnchor: L.point(10, 10),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }),
             "hub_blue": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/hub_32_Cyan.png',
                 iconAnchor: L.point(10, 10),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }),
             "hub_orange": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/hub_32_Orange.png',
                 iconAnchor: L.point(10, 10),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }),
             "hub_red": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/hub_32_Red.png',
                 iconAnchor: L.point(10, 10),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }),
             "node_marker": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/location.png',
                 iconAnchor: L.point(10, 10),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }), "cell_tower": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/cellphone_tower_24.png',
                 iconAnchor: L.point(12, 12),
                 shadowAnchor: L.point(13, 32),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }), "building": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/building_icon.png',
                 iconAnchor: L.point(12, 12),
                 shadowAnchor: L.point(5, 32),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }), "building_green": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/building_icon_green.png',
                 iconAnchor: L.point(12, 12),
                 shadowAnchor: L.point(5, 32),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }), "cell_tower_red": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/cellphone_tower_24_red.png',
                 iconAnchor: L.point(12, 12),
                 shadowAnchor: L.point(13, 32),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }), "cell_tower_green": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/cellphone_tower_24_green.png',
                 iconAnchor: L.point(12, 12),
                 shadowAnchor: L.point(13, 32),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }), "building_red": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/building_icon_red.png',
                 iconAnchor: L.point(12, 12),
                 shadowAnchor: L.point(5, 32),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }), "warehouse": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/warehouse_32x32.gif',
                 iconAnchor: L.point(15, 13),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             })
             , "verizon_store": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/verizon_store32x32.gif',
                 iconAnchor: L.point(15, 15),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             })
             , "retail_store": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/retail_store32x32.gif',
                 iconAnchor: L.point(15, 15),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             })
             , "data_hub": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/datahub_32x32.gif',
                 iconAnchor: L.point(15, 15),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }),
             "node_hub": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/nodes_32_cyan.png',
                 iconAnchor: L.point(10, 10),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }),
             "node_hub_green": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/nodes_32_green.png',
                 iconAnchor: L.point(10, 10),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }),
             "node_hub_red": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/nodes_32_red.png',
                 iconAnchor: L.point(10, 10),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             })
             , "router": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/router_32_cyan.png',
                 iconAnchor: L.point(15, 15),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             })
             , "switch": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/switchblue_32.png',
                 iconAnchor: L.point(15, 15),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             })
             , "fiber_shuffle": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/fiber_shuffle_32_cyan.png',
                 iconAnchor: L.point(15, 15),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             })
             , "generic_equipment": new L.Icon({
                 iconUrl: icon_path + '/uiam/css/images/topo/generic_equip.png',
                 iconAnchor: L.point(15, 15),
                 shadowAnchor: L.point(5, 25),
                 iconSize: [20, 20],
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }),
             "generic_vzt_equipment": new L.Icon({		
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/equip.png',
                 iconAnchor: L.point(15, 15),
                 shadowAnchor: L.point(5, 25),
                 iconSize: [20, 20],
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }),
             "hub_green_24": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/hub_24_Green.png',
                 iconAnchor: L.point(10, 10),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }),
             "hub_blue_24": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/hub_24_Cyan.png',
                 iconAnchor: L.point(10, 10),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }),
             "hub_orange_24": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/hub_24_Orange.png',
                 iconAnchor: L.point(10, 10),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }),
             "hub_red_24": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/hub_24_Red.png',
                 iconAnchor: L.point(10, 10),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }),
             "node_marker_24": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/location.png',
                 iconAnchor: L.point(10, 10),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }), "cell_tower_24": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/cellphone_tower_24.png',
                 iconAnchor: L.point(12, 12),
                 shadowAnchor: L.point(13, 32),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }), "building_24": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/building_icon.png',
                 iconAnchor: L.point(12, 12),
                 shadowAnchor: L.point(5, 32),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }), "cell_tower_red_24": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/cellphone_tower_24_red.png',
                 iconAnchor: L.point(12, 12),
                 shadowAnchor: L.point(13, 32),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }), "cell_tower_green_24": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/cellphone_tower_24_green.png',
                 iconAnchor: L.point(12, 12),
                 shadowAnchor: L.point(13, 32),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }), "building_red_24": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/building_icon_red.png',
                 iconAnchor: L.point(12, 12),
                 shadowAnchor: L.point(5, 32),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }), "warehouse_24": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/warehouse_24x24.gif',
                 iconAnchor: L.point(15, 13),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             })
             , "verizon_store_24": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/verizon_store24x24.gif',
                 iconAnchor: L.point(15, 15),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             })
             , "retail_store_24": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/retail_store24x24.gif',
                 iconAnchor: L.point(15, 15),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             })
             , "data_hub_24": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/datahub_24x24.gif',
                 iconAnchor: L.point(15, 15),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }),
             "node_hub_24": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/nodes_24_cyan.png',
                 iconAnchor: L.point(10, 10),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }),
             "node_hub_green_24": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/nodes_24_green.png',
                 iconAnchor: L.point(10, 10),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }),
             "node_hub_red_24": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/nodes_24_red.png',
                 iconAnchor: L.point(10, 10),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             })
             , "router_24": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/router_24_cyan.png',
                 iconAnchor: L.point(15, 15),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             })
             , "switch_24": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/switchblue_24.png',
                 iconAnchor: L.point(15, 15),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             })
             , "fiber_shuffle_24": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/fiber_shuffle_24_cyan.png',
                 iconAnchor: L.point(15, 15),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             })
             , "generic_equipment_24": new L.Icon({
                 iconUrl: icon_path + '/uiam/css/images/topo/generic_equip.png',
                 iconAnchor: L.point(15, 15),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/marker-shadow.png'
             }),
             "home": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/glass-house.png',
                 iconAnchor: L.point(15,15),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/glass-ellipse.png'
             }),
             "glass_tower": new L.Icon({
                 iconUrl: icon_path + '/nitro/css/images/xyz/product/big-glass-tower.png',
                 iconAnchor: L.point(15,15),
                 shadowAnchor: L.point(5, 25),
                 shadowUrl: icon_path + '/nitro/css/images/xyz/product/glass-ellipse.png'
             })
         };
     };
 
 }(window, document));
 
 
 
 
 //TODO
 /*
  * review text left-to right and edge updating in general to make efficient choices
  * its possible markers may move --but only do text flow once per change or init
  * 
  *
  * VIS alg --done
  * save/retrieve
  * menu for sample 50%
  * privatize
  * prototype map
  * flash screen for loading
  * data loading ?? 
  * multiple map instances?
  * macro for plugin in window any size
  * change prefix--done
  * confluence
  * geo location
  * multiple lines 
  * selections
  * selctino boces
  * highlites
  * trace routing -based on what?
  * 
  * do we need to reinit on a mode changes --tooltips are still messing up
  * x y is backwards on nodes --and probably lines
  * 
  * 
  * ISSUES
  * removing nodes from cluster --breaking cluster/network --do we need to rebuild cluster--if so when --might remove several
  * need mode with no drag and no cluster
  * had to add back feature group to drag_group in order for center() to work --only feature has getBounds()
  * need way to debug without exposing members
  */
 
 
 /*
  * other tile urls
  *  //_map_url=' http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
  //_map_url='http://netgeo.vh.eng.vzwcorp.com/arcgis/rest/services/basemap_webmer/World_Topo_Map/MapServer/tile/{z}/{y}/{x}';
  //_map_url='http://netgeo.vh.eng.vzwcorp.com/arcgis/rest/services/basemap_webmer/NatGeo_World_Map/MapServer/tile/{z}/{y}/{x}';
  //_map_url='http://netgeo.vh.eng.vzwcorp.com/arcgis/rest/services/basemap_webmer/World_Imagery/MapServer/tile/{z}/{y}/{x}';
  _map_url = ' http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
  _grid_url = CONTEXT_PATH + '/uui/espresso/static/nitro/css/images/xyz/grid/grid_{z}.png';
  * 
  * 
  */
 
 
 
 /*
  *  exprimenting with multiple tooltips
  * 
  * 
  * 
  * 
  * 
  * 
  * 
  *      if(n.tooltip){
  n.marker.bindTooltip(n.tooltip.text,n.tooltip.options);
  n.tooltip_obj=n.marker.getTooltip();
  }
  
  console.log(" the tool tip="+n.tooltip_obj);
  
  if(n.label){
  n.marker.bindTooltip(n.label.text, n.label.options);  
  n.label_obj=n.marker.getTooltip();
  }
  * 
  * 
  *  //this.label=options.label;
  //this.label_obj=null;
  * 
  * 
  *   if(this.label){
  if(this.label.options){
  if(!this.label.options.direction){
  this.label.options["direction"]="bottom";
  }
  }else{
  this.label.options={permanent:true,direction:"bottom",className:"nitro-label",opacity:1.0};
  }
  
  //this.marker.bindTooltip(this.label.text, this.label.options);  
  //this.marker.label_obj=this.marker.getTooltip();
  
  
  *     if(n.tooltip){
  n.marker.bindTooltip(n.tooltip.text,n.tooltip.options);
  n.tooltip_obj=n.marker.getTooltip();
  }
  
  console.log(" the tool tip="+n.tooltip_obj);
  
  if(n.label){
  n.marker.bindTooltip(n.label.text, n.label.options);  
  n.label_obj=n.marker.getTooltip();
  * 
  this.marker.on('mouseover', function(e) {
  console.log(" setting tooltip text to "+this._node.tooltip.text);
  
  //this.setTooltipContent(this._node.tooltip.text);
  this.unbindTooltip();
  //this.bindTooltip(this._node.tooltip_obj);
  var n=this._node;
  this.bindTooltip(n.tooltip.text,n.tooltip.options).addTo(_map);
  console.log(" s tool tip="+this._node.tooltip_obj+" text="+n.tooltip.text);
  //this.update();   
  });
  this.marker.on('mouseout', function(e) {             
  console.log(" setting tooltip text to "+this._node.label.text);
  console.log(" label tool tip="+this._node.label_obj);
  //this.setTooltipContent(this._node.label.text);
  this.unbindTooltip();
  //this.bindTooltip(this._node.label_obj);
  var n=this._node;
  this.bindTooltip(n.label.text, n.label.options);
  });
  */
 
 
 
 
 //Leaflet-SVGIcon
 //SVG icon for any marker class
 //Ilya Atkin
 //ilya.atkin@unh.edu
 
 L.DivIcon.SVGIcon = L.DivIcon.extend({
     options: {
         "circleText": "",
         "className": "svg-icon",
         "circleAnchor": null, //defaults to [iconSize.x/2, iconSize.x/2]
         "circleColor": null, //defaults to color
         "circleOpacity": null, // defaults to opacity
         "circleFillColor": "rgb(255,255,255)",
         "circleFillOpacity": null, //default to opacity 
         "circleRatio": 0.5,
         "circleWeight": null, //defaults to weight
         "color": "rgb(0,102,255)",
         "fillColor": null, // defaults to color
         "fillOpacity": 0.4,
         "fontColor": "rgb(0, 0, 0)",
         "fontOpacity": "1",
         "fontSize": null, // defaults to iconSize.x/4
         "iconAnchor": null, //defaults to [iconSize.x/2, iconSize.y] (point tip)
         "iconSize": L.point(32,48),
         "opacity": 1,
         "popupAnchor": null,
         "weight": 2
     },
     initialize: function(options) {
         options = L.Util.setOptions(this, options)
         
         //iconSize needs to be converted to a Point object if it is not passed as one
         options.iconSize = L.point(options.iconSize)
 
         //in addition to setting option dependant defaults, Point-based options are converted to Point objects
         if (!options.circleAnchor) {
             options.circleAnchor = L.point(Number(options.iconSize.x)/2, Number(options.iconSize.x)/2)
         }
         else {
             options.circleAnchor = L.point(options.circleAnchor)
         }
         if (!options.circleColor) {
             options.circleColor = options.color
         }
         if (!options.circleFillOpacity) {
             options.circleFillOpacity = options.opacity
         }
         if (!options.circleOpacity) {
             options.circleOpacity = options.opacity
         }
         if (!options.circleWeight) {
             options.circleWeight = options.weight
         }
         if (!options.fillColor) { 
             options.fillColor = options.color
         }
         if (!options.fontSize) {
             options.fontSize = Number(options.iconSize.x/4) 
         }
         if (!options.iconAnchor) {
             options.iconAnchor = L.point(Number(options.iconSize.x)/2, Number(options.iconSize.y))
         }
         else {
             options.iconAnchor = L.point(options.iconAnchor)
         }
         if (!options.popupAnchor) {
             options.popupAnchor = L.point(0, (-0.75)*(options.iconSize.y))
         }
         else {
             options.popupAnchor = L.point(options.popupAnchor)
         }
 
         var path = this._createPath()
         var circle = this._createCircle()
 
         options.html = this._createSVG()
     },
     _createCircle: function() {
         var cx = Number(this.options.circleAnchor.x)
         var cy = Number(this.options.circleAnchor.y)
         var radius = this.options.iconSize.x/2 * Number(this.options.circleRatio)
         var fill = this.options.circleFillColor
         var fillOpacity = this.options.circleFillOpacity
         var stroke = this.options.circleColor
         var strokeOpacity = this.options.circleOpacity
         var strokeWidth = this.options.circleWeight
         var className = this.options.className + "-circle"        
        
         var circle = '<circle class="' + className + '" cx="' + cx + '" cy="' + cy + '" r="' + radius +
             '" fill="' + fill + '" fill-opacity="'+ fillOpacity + 
             '" stroke="' + stroke + '" stroke-opacity=' + strokeOpacity + '" stroke-width="' + strokeWidth + '"/>'
         
         return circle
     },
     _createPathDescription: function() {
         var height = Number(this.options.iconSize.y)
         var width = Number(this.options.iconSize.x)
         var weight = Number(this.options.weight)
         var margin = weight / 2
 
         var startPoint = "M " + margin + " " + (width/2) + " "
         var leftLine = "L " + (width/2) + " " + (height - weight) + " "
         var rightLine = "L " + (width - margin) + " " + (width/2) + " "
         var arc = "A " + (width/4) + " " + (width/4) + " 0 0 0 " + margin + " " + (width/2) + " Z"
 
         var d = startPoint + leftLine + rightLine + arc
 
         return d
     },
     _createPath: function() {
         var pathDescription = this._createPathDescription()
         var strokeWidth = this.options.weight
         var stroke = this.options.color
         var strokeOpacity = this.options.Opacity
         var fill = this.options.fillColor
         var fillOpacity = this.options.fillOpacity
         var className = this.options.className + "-path"
 
         var path = '<path class="' + className + '" d="' + pathDescription +
             '" stroke-width="' + strokeWidth + '" stroke="' + stroke + '" stroke-opacity="' + strokeOpacity +
             '" fill="' + fill + '" fill-opacity="' + fillOpacity + '"/>'
 
         return path
     },
     _createSVG: function() {
         var path = this._createPath()
         var circle = this._createCircle()
         var text = this._createText()
         var className = this.options.className + "-svg"
 
         var style = "width:" + this.options.iconSize.x + "; height:" + this.options.iconSize.y + ";"
 
         var svg = '<svg xmlns="http://www.w3.org/2000/svg" version="1.1" class="' + className + '" style="' + style + '">' + path + circle + text + '</svg>'
 
         return svg
     },
     _createText: function() {
         var fontSize = this.options.fontSize + "px"
         var lineHeight = Number(this.options.fontSize)
 
         var x = Number(this.options.iconSize.x) / 2
         var y = x + (lineHeight * 0.35) //35% was found experimentally 
         var circleText = this.options.circleText
         var textColor = this.options.fontColor.replace("rgb(", "rgba(").replace(")", "," + this.options.fontOpacity + ")")
 
         var text = '<text text-anchor="middle" x="' + x + '" y="' + y + '" style="font-size: ' + fontSize + '" fill="' + textColor + '">' + circleText + '</text>'
 
         return text
     }
 })
 
 L.divIcon.svgIcon = function(options) {
     return new L.DivIcon.SVGIcon(options)
 }
 
 L.Marker.SVGMarker = L.Marker.extend({
     options: {
         "iconFactory": L.divIcon.svgIcon,
         "iconOptions": {}
     },
     initialize: function(latlng, options) {
         options = L.Util.setOptions(this, options)
         options.icon = options.iconFactory(options.iconOptions)
         this._latlng = latlng
     },
     onAdd: function(map) {
         L.Marker.prototype.onAdd.call(this, map)
     },
     setStyle: function(style) {
         if (this._icon) {
             var svg = this._icon.children[0]
             var iconBody = this._icon.children[0].children[0]
             var iconCircle = this._icon.children[0].children[1]
 
             if (style.color && !style.iconOptions) {
                 var stroke = style.color.replace("rgb","rgba").replace(")", ","+this.options.icon.options.opacity+")")
                 var fill = style.color.replace("rgb","rgba").replace(")", ","+this.options.icon.options.fillOpacity+")")
                 iconBody.setAttribute("stroke", stroke)
                 iconBody.setAttribute("fill", fill)
                 iconCircle.setAttribute("stroke", stroke)
 
                 this.options.icon.fillColor = fill
                 this.options.icon.color = stroke
                 this.options.icon.circleColor = stroke
             }
             if (style.opacity) {
                 this.setOpacity(style.opacity)
             }
             if (style.iconOptions) {
                 if (style.color) { style.iconOptions.color = style.color }
                 iconOptions = L.Util.setOptions(this.options.icon, style.iconOptions)
                 this.setIcon(L.divIcon.svgIcon(iconOptions))
             }
         }
     }
 })
 
 L.marker.svgMarker = function(latlng, options) {
     return new L.Marker.SVGMarker(latlng, options)
 }
 
 
 /*
  * 
  *Leaflet-SVGIcon
 L.DivIcon.SVGIcon is a simple and customizable SVG marker icon with no external library or file dependencies. By default, 1 emoji, 2 characters of text or about 3 numerals can fit inside the icon's inner circle.
 
 Also included is L.Marker.SVGMarker, a small Marker wrapper class for SVGIcons with a setStyle implementation that handles marker opacity changes, monochromatic color changes and changes to specific icon options.
 
 There are also 2 example subclasses provided. One is rhombus shaped and includes an example SVGMarker subclass specific to this icon. The other is shaped like the Washington Monument.
 
 Requirements
 Leaflet 0.7+ (earlier versions may work, but are untested)
 Browser support for SVG
 Demo
 The following example is centered on the Washington Monument and allows for the manipulation of all icon options. The default options are shown as placeholder text. The icon can also be changed to either of the example subclasses.
 
 Example
 
 Usage
 Include the source file
 <script src="svg-icon.js"></script>
 Use an SVGMarker
 var marker = new L.Marker.SVGMarker(latlng)
 Use an SVGMarker with customized icon options
 var marker = new L.Marker.SVGMarker(latlng, { iconOptions: { color: "rgb(0,0,100)" }})
 Use any place Icons are accepted
 var marker = new L.Marker(latlng, { icon: new L.DivIcon.SVGIcon() })
 Properties
 L.DivIcon.SVGIcon
 Unspecified Icon options are ignored
 
 Option	Type	Default	Description
 circleText	String	""	Text to include in the center of the icon
 className	String	"svg-icon"	Class prefix to use for icon elements
 circleAnchor	Point	[iconSize.x/2, iconSize.x/2]	Point of origin for the icon's inner circle
 circleColor	String	same as "color"	Color of the icon's inner circle border
 circleOpacity	Number	same as "opacity"	Opacity of the icon's inner circle border
 circleFillColor	String	"rgb(255,255,255)"	Color of the icon's inner circle interior
 circleFillOpacity	Number	same as "opacity"	Opacity of the icon's inner circle interior
 circleRatio	Number	0.5	Ratio of the width of the icon's inner circle to the width of the marker. Set to 0 to disable circle
 circleWeight	Number	same as "weight"	Width of the icon's inner circle border
 color	String	"rgb(0,102,255)"	Color of the icon's border
 fillColor	String	same as "color"	Color of the icon's interior
 fillOpacity	Number	0.4	Opacity of the icon's interior
 fontColor	String	"rgb(0,0,0)"	Color of the icon's center text
 fontOpacity	Number	1	Opacity of the icon's center text
 fontSize	Number	iconSize.x/4	Font size in pixels of the icon's center text
 iconAnchor	Point	[iconSize.x/2, iconSize.y]	The point to align over the marker's geographic location
 iconSize	Point	[32,48]	The size of the icon
 opacity	Number	1	Opacity of the icon's border
 popupAnchor	Point	[0,(-0.75*iconSize.y)]	Point of origin for bound popups relative to the iconAnchor
 L.Marker.SVGMarker
 All standard L.Marker options are supported excluding icon. To customize the icon, pass a dictionary of icon options using the iconOptions SVGMarker option. There is an example in the Usage section.
 
 Option	Type	Default	Description
 iconFactory	method	L.divIcon.svgIcon	The factory method to use when creating the SVGIcon. Only useful for SVGIcon subclasses
 iconOptions	Dictionary	{}	A dictionary of icon options to pass
 Methods
 L.DivIcon.SVGIcon
 This class does not include any methods that are intended to be user accessible as part of normal use. The following are the internal methods used to generate the icon. All methods with the exception of _createPathDescription are customizable using icon options only. Due to the computations inherent in creating a scalable path description, _createPathDescription must be overridden in order to change the overall icon shape.
 
 _createCircle()
 Creates the icon's inner circle. This method is 100% customizable using icon options exclusively, and should not need to be overridden in most cases.
 
 _createPath()
 Creates the main body of the icon. All aspects of the icon body with the exception of the shape itself may be customized used icon options.
 
 _createPathDescription()
 Creates the drawing instructions for the icon's shape. This method must be overridden in order to change the icon's shape. See the Advanced Customization section for more information.
 
 _createSVG()
 Creates the final SVG element. This method should not need to be overridden. Note that if adding HTML elements, they need to be placed outside the main element.
 
 _createText()
 Creates the SVG text element. More text can be fit without overriding this method by increasing the size of the icon and specifying a font size.
 
 L.Marker.SVGMarker
 setStyle(style)
 This method supports three style values:
 
 opacity: Equivalent to using setOpacity i.e. the opacity of the entire marker icon changes.
 color: Monochromatically sets the icon border color, interior color and inner circle border color
 iconOptions: A dictionary of specific icon options to change. These may be any SVGIcon option.
 If "color" and "iconOptions" are specified, "iconOptions.color" is set to "color".
 
 Advanced Customization
 Modifying the icon's shape
 The body of the icon is drawn using an SVG path. The shape may be changed by replacing the _createPathDescription method of L.DivIcon.SVGIcon to return a different path description i.e. the path drawing instructions. Please see the Mozilla Developer Network's SVG Path Tutorial for more information on SVG paths.
 
 This repository includes an example L.DivIcon.SVGIcon.RhombusIcon subclass and accompanying convenience L.Marker.SVGMarker.RhombusMarker subclass.
 
 Disabling the icon's inner circle or text
 By default, the icon has a semi-transparent body with an opaque white circle in order to increase visibility and allow for a small amount of easily legible text. If you don't need the circle, the simplest way to exclude it is to set "circleRatio" to 0 which will result in a circle with a radius of zero.
 
 If you will be creating a large number of icons or writing a subclass that doesn't need either the circle or displayed text, generating the circle and text elements can be disabled entirely by either overridding _createCircle/_createText to return an empty string or overriding _createSVG to exclude calling the creation methods for the unneeded elements.
  * 
  * */
  
 /** @license
  *
  *  Copyright (C) 2012 K. Arthur Endsley (kaendsle@mtu.edu)
  *  Michigan Tech Research Institute (MTRI)
  *  3600 Green Court, Suite 100, Ann Arbor, MI, 48105
  *
  *  This program is free software: you can redistribute it and/or modify
  *  it under the terms of the GNU General Public License as published by
  *  the Free Software Foundation, either version 3 of the License, or
  *  (at your option) any later version.
  *
  *  This program is distributed in the hope that it will be useful,
  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *  GNU General Public License for more details.
  *
  *  You should have received a copy of the GNU General Public License
  *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *
  */
 
 (function (root, factory) {
 
     if (typeof define === "function" && define.amd) {
         // AMD (+ global for extensions)
         define(function () {
             return factory();
         });
     } else if (typeof module !== 'undefined' && typeof exports === "object") {
         // CommonJS
         module.exports = factory();
     } else {
         // Browser
         root.Wkt = factory();
     }
 }(this, function () {
 
 
     var beginsWith, endsWith, root, Wkt;
 
     // Establish the root object, window in the browser, or exports on the server
     root = this;
 
     /**
      * @desc The Wkt namespace.
      * @property    {String}    delimiter   - The default delimiter for separating components of atomic geometry (coordinates)
      * @namespace
      * @global
      */
     Wkt = function (obj) {
         if (obj instanceof Wkt) return obj;
         if (!(this instanceof Wkt)) return new Wkt(obj);
         this._wrapped = obj;
     };
 
 
 
     /**
      * Returns true if the substring is found at the beginning of the string.
      * @param   str {String}    The String to search
      * @param   sub {String}    The substring of interest
      * @return      {Boolean}
      * @private
      */
     beginsWith = function (str, sub) {
         return str.substring(0, sub.length) === sub;
     };
 
     /**
      * Returns true if the substring is found at the end of the string.
      * @param   str {String}    The String to search
      * @param   sub {String}    The substring of interest
      * @return      {Boolean}
      * @private
      */
     endsWith = function (str, sub) {
         return str.substring(str.length - sub.length) === sub;
     };
 
     /**
      * The default delimiter for separating components of atomic geometry (coordinates)
      * @ignore
      */
     Wkt.delimiter = ' ';
 
     /**
      * Determines whether or not the passed Object is an Array.
      * @param   obj {Object}    The Object in question
      * @return      {Boolean}
      * @member Wkt.isArray
      * @method
      */
     Wkt.isArray = function (obj) {
         return !!(obj && obj.constructor === Array);
     };
 
     /**
      * Removes given character String(s) from a String.
      * @param   str {String}    The String to search
      * @param   sub {String}    The String character(s) to trim
      * @return      {String}    The trimmed string
      * @member Wkt.trim
      * @method
      */
     Wkt.trim = function (str, sub) {
         sub = sub || ' '; // Defaults to trimming spaces
         // Trim beginning spaces
         while (beginsWith(str, sub)) {
             str = str.substring(1);
         }
         // Trim ending spaces
         while (endsWith(str, sub)) {
             str = str.substring(0, str.length - 1);
         }
         return str;
     };
 
     /**
      * An object for reading WKT strings and writing geographic features
      * @constructor this.Wkt.Wkt
      * @param   initializer {String}    An optional WKT string for immediate read
      * @property            {Array}     components      - Holder for atomic geometry objects (internal representation of geometric components)
      * @property            {String}    delimiter       - The default delimiter for separating components of atomic geometry (coordinates)
      * @property            {Object}    regExes         - Some regular expressions copied from OpenLayers.Format.WKT.js
      * @property            {String}    type            - The Well-Known Text name (e.g. 'point') of the geometry
      * @property            {Boolean}   wrapVerticies   - True to wrap vertices in MULTIPOINT geometries; If true: MULTIPOINT((30 10),(10 30),(40 40)); If false: MULTIPOINT(30 10,10 30,40 40)
      * @return              {this.Wkt.Wkt}
      * @memberof Wkt
      */
     Wkt.Wkt = function (initializer) {
 
         /**
          * The default delimiter between X and Y coordinates.
          * @ignore
          */
         this.delimiter = Wkt.delimiter || ' ';
 
         /**
          * Configuration parameter for controlling how Wicket seralizes
          * MULTIPOINT strings. Examples; both are valid WKT:
          * If true: MULTIPOINT((30 10),(10 30),(40 40))
          * If false: MULTIPOINT(30 10,10 30,40 40)
          * @ignore
          */
         this.wrapVertices = true;
 
         /**
          * Some regular expressions copied from OpenLayers.Format.WKT.js
          * @ignore
          */
         this.regExes = {
             'typeStr': /^\s*(\w+)\s*\(\s*(.*)\s*\)\s*$/,
             'spaces': /\s+|\+/, // Matches the '+' or the empty space
             'numeric': /-*\d+(\.*\d+)?/,
             'comma': /\s*,\s*/,
             'parenComma': /\)\s*,\s*\(/,
             'coord': /-*\d+\.*\d+ -*\d+\.*\d+/, // e.g. "24 -14"
             'doubleParenComma': /\)\s*\)\s*,\s*\(\s*\(/,
             'trimParens': /^\s*\(?(.*?)\)?\s*$/,
             'ogcTypes': /^(multi)?(point|line|polygon|box)?(string)?$/i, // Captures e.g. "Multi","Line","String"
             'crudeJson': /^{.*"(type|coordinates|geometries|features)":.*}$/ // Attempts to recognize JSON strings
         };
 
         /**
          * The internal representation of geometry--the "components" of geometry.
          * @ignore
          */
         this.components = undefined;
 
         // An initial WKT string may be provided
         if (initializer && typeof initializer === 'string') {
             this.read(initializer);
         } else if (initializer && typeof initializer !== undefined) {
             this.fromObject(initializer);
         }
 
     };
 
 
 
     /**
      * Returns true if the internal geometry is a collection of geometries.
      * @return  {Boolean}   Returns true when it is a collection
      * @memberof this.Wkt.Wkt
      * @method
      */
     Wkt.Wkt.prototype.isCollection = function () {
         switch (this.type.slice(0, 5)) {
             case 'multi':
                 // Trivial; any multi-geometry is a collection
                 return true;
             case 'polyg':
                 // Polygons with holes are "collections" of rings
                 return true;
             default:
                 // Any other geometry is not a collection
                 return false;
         }
     };
 
     /**
      * Compares two x,y coordinates for equality.
      * @param   a   {Object}    An object with x and y properties
      * @param   b   {Object}    An object with x and y properties
      * @return      {Boolean}
      * @memberof this.Wkt.Wkt
      * @method
      */
     Wkt.Wkt.prototype.sameCoords = function (a, b) {
         return (a.x === b.x && a.y === b.y);
     };
 
     /**
      * Sets internal geometry (components) from framework geometry (e.g.
      * Google Polygon objects or google.maps.Polygon).
      * @param   obj {Object}    The framework-dependent geometry representation
      * @return      {this.Wkt.Wkt}   The object itself
      * @memberof this.Wkt.Wkt
      * @method
      */
     Wkt.Wkt.prototype.fromObject = function (obj) {
         var result;
 
         if (obj.hasOwnProperty('type') && obj.hasOwnProperty('coordinates')) {
             result = this.fromJson(obj);
         } else {
             result = this.deconstruct.call(this, obj);
         }
 
         this.components = result.components;
         this.isRectangle = result.isRectangle || false;
         this.type = result.type;
         return this;
     };
 
     /**
      * Creates external geometry objects based on a plug-in framework's
      * construction methods and available geometry classes.
      * @param   config  {Object}    An optional framework-dependent properties specification
      * @return          {Object}    The framework-dependent geometry representation
      * @memberof this.Wkt.Wkt
      * @method
      */
     Wkt.Wkt.prototype.toObject = function (config) {
         var obj = this.construct[this.type].call(this, config);
         // Don't assign the "properties" property to an Array
         if (typeof obj === 'object' && !Wkt.isArray(obj)) {
             obj.properties = this.properties;
         }
         return obj;
     };
 
     /**
      * Returns the WKT string representation; the same as the write() method.
      * @memberof this.Wkt.Wkt
      * @method
      */
     Wkt.Wkt.prototype.toString = function (config) {
         return this.write();
     };
 
     /**
      * Parses a JSON representation as an Object.
      * @param	obj	{Object}	An Object with the GeoJSON schema
      * @return	{this.Wkt.Wkt}	The object itself
      * @memberof this.Wkt.Wkt
      * @method
      */
     Wkt.Wkt.prototype.fromJson = function (obj) {
         var i, j, k, coords, iring, oring;
 
         this.type = obj.type.toLowerCase();
         this.components = [];
         if (obj.hasOwnProperty('geometry')) { //Feature
             this.fromJson(obj.geometry);
             this.properties = obj.properties;
             return this;
         }
         coords = obj.coordinates;
 
         if (!Wkt.isArray(coords[0])) { // Point
             this.components.push({
                 x: coords[0],
                 y: coords[1]
             });
 
         } else {
 
             for (i in coords) {
                 if (coords.hasOwnProperty(i)) {
 
                     if (!Wkt.isArray(coords[i][0])) { // LineString
 
                         if (this.type === 'multipoint') { // MultiPoint
                             this.components.push([{
                                 x: coords[i][0],
                                 y: coords[i][1]
                             }]);
 
                         } else {
                             this.components.push({
                                 x: coords[i][0],
                                 y: coords[i][1]
                             });
 
                         }
 
                     } else {
 
                         oring = [];
                         for (j in coords[i]) {
                             if (coords[i].hasOwnProperty(j)) {
 
                                 if (!Wkt.isArray(coords[i][j][0])) {
                                     oring.push({
                                         x: coords[i][j][0],
                                         y: coords[i][j][1]
                                     });
 
                                 } else {
 
                                     iring = [];
                                     for (k in coords[i][j]) {
                                         if (coords[i][j].hasOwnProperty(k)) {
 
                                             iring.push({
                                                 x: coords[i][j][k][0],
                                                 y: coords[i][j][k][1]
                                             });
 
                                         }
                                     }
 
                                     oring.push(iring);
 
                                 }
 
                             }
                         }
 
                         this.components.push(oring);
                     }
                 }
             }
 
         }
 
         return this;
     };
 
     /**
      * Creates a JSON representation, with the GeoJSON schema, of the geometry.
      * @return    {Object}    The corresponding GeoJSON representation
      * @memberof this.Wkt.Wkt
      * @method
      */
     Wkt.Wkt.prototype.toJson = function () {
         var cs, json, i, j, k, ring, rings;
 
         cs = this.components;
         json = {
             coordinates: [],
             type: (function () {
                 var i, type, s;
 
                 type = this.regExes.ogcTypes.exec(this.type).slice(1);
                 s = [];
 
                 for (i in type) {
                     if (type.hasOwnProperty(i)) {
                         if (type[i] !== undefined) {
                             s.push(type[i].toLowerCase().slice(0, 1).toUpperCase() + type[i].toLowerCase().slice(1));
                         }
                     }
                 }
 
                 return s;
             }.call(this)).join('')
         }
 
         // Wkt BOX type gets a special bbox property in GeoJSON
         if (this.type.toLowerCase() === 'box') {
             json.type = 'Polygon';
             json.bbox = [];
 
             for (i in cs) {
                 if (cs.hasOwnProperty(i)) {
                     json.bbox = json.bbox.concat([cs[i].x, cs[i].y]);
                 }
             }
 
             json.coordinates = [
                 [
                     [cs[0].x, cs[0].y],
                     [cs[0].x, cs[1].y],
                     [cs[1].x, cs[1].y],
                     [cs[1].x, cs[0].y],
                     [cs[0].x, cs[0].y]
                 ]
             ];
 
             return json;
         }
 
         // For the coordinates of most simple features
         for (i in cs) {
             if (cs.hasOwnProperty(i)) {
 
                 // For those nested structures
                 if (Wkt.isArray(cs[i])) {
                     rings = [];
 
                     for (j in cs[i]) {
                         if (cs[i].hasOwnProperty(j)) {
 
                             if (Wkt.isArray(cs[i][j])) { // MULTIPOLYGONS
                                 ring = [];
 
                                 for (k in cs[i][j]) {
                                     if (cs[i][j].hasOwnProperty(k)) {
                                         ring.push([cs[i][j][k].x, cs[i][j][k].y]);
                                     }
                                 }
 
                                 rings.push(ring);
 
                             } else { // POLYGONS and MULTILINESTRINGS
 
                                 if (cs[i].length > 1) {
                                     rings.push([cs[i][j].x, cs[i][j].y]);
 
                                 } else { // MULTIPOINTS
                                     rings = rings.concat([cs[i][j].x, cs[i][j].y]);
                                 }
                             }
                         }
                     }
 
                     json.coordinates.push(rings);
 
                 } else {
                     if (cs.length > 1) { // For LINESTRING type
                         json.coordinates.push([cs[i].x, cs[i].y]);
 
                     } else { // For POINT type
                         json.coordinates = json.coordinates.concat([cs[i].x, cs[i].y]);
                     }
                 }
 
             }
         }
 
         return json;
     };
 
     /**
      * Absorbs the geometry of another this.Wkt.Wkt instance, merging it with its own,
      * creating a collection (MULTI-geometry) based on their types, which must agree.
      * For example, creates a MULTIPOLYGON from a POLYGON type merged with another
      * POLYGON type, or adds a POLYGON instance to a MULTIPOLYGON instance.
      * @param   wkt {String}    A Wkt.Wkt object
      * @return	{this.Wkt.Wkt}	The object itself
      * @memberof this.Wkt.Wkt
      * @method
      */
     Wkt.Wkt.prototype.merge = function (wkt) {
         var prefix = this.type.slice(0, 5);
 
         if (this.type !== wkt.type) {
             if (this.type.slice(5, this.type.length) !== wkt.type) {
                 throw TypeError('The input geometry types must agree or the calling this.Wkt.Wkt instance must be a multigeometry of the other');
             }
         }
 
         switch (prefix) {
 
             case 'point':
                 this.components = [this.components.concat(wkt.components)];
                 break;
 
             case 'multi':
                 this.components = this.components.concat((wkt.type.slice(0, 5) === 'multi') ? wkt.components : [wkt.components]);
                 break;
 
             default:
                 this.components = [
                     this.components,
                     wkt.components
                 ];
                 break;
 
         }
 
         if (prefix !== 'multi') {
             this.type = 'multi' + this.type;
         }
         return this;
     };
 
     /**
      * Reads a WKT string, validating and incorporating it.
      * @param   str {String}    A WKT or GeoJSON string
      * @return	{this.Wkt.Wkt}	The object itself
      * @memberof this.Wkt.Wkt
      * @method
      */
     Wkt.Wkt.prototype.read = function (str) {
         var matches;
         matches = this.regExes.typeStr.exec(str);
         if (matches) {
             this.type = matches[1].toLowerCase();
             this.base = matches[2];
             if (this.ingest[this.type]) {
                 this.components = this.ingest[this.type].apply(this, [this.base]);
             }
 
         } else {
             if (this.regExes.crudeJson.test(str)) {
                 if (typeof JSON === 'object' && typeof JSON.parse === 'function') {
                     this.fromJson(JSON.parse(str));
 
                 } else {
                     console.log('JSON.parse() is not available; cannot parse GeoJSON strings');
                     throw {
                         name: 'JSONError',
                         message: 'JSON.parse() is not available; cannot parse GeoJSON strings'
                     };
                 }
 
             } else {
                 console.log('Invalid WKT string provided to read()');
                 throw {
                     name: 'WKTError',
                     message: 'Invalid WKT string provided to read()'
                 };
             }
         }
 
         return this;
     }; // eo readWkt
 
     /**
      * Writes a WKT string.
      * @param   components  {Array}     An Array of internal geometry objects
      * @return              {String}    The corresponding WKT representation
      * @memberof this.Wkt.Wkt
      * @method
      */
     Wkt.Wkt.prototype.write = function (components) {
         var i, pieces, data;
 
         components = components || this.components;
 
         pieces = [];
 
         pieces.push(this.type.toUpperCase() + '(');
 
         for (i = 0; i < components.length; i += 1) {
             if (this.isCollection() && i > 0) {
                 pieces.push(',');
             }
 
             // There should be an extract function for the named type
             if (!this.extract[this.type]) {
                 return null;
             }
 
             data = this.extract[this.type].apply(this, [components[i]]);
             if (this.isCollection() && this.type !== 'multipoint') {
                 pieces.push('(' + data + ')');
 
             } else {
                 pieces.push(data);
 
                 // If not at the end of the components, add a comma
                 if (i !== (components.length - 1) && this.type !== 'multipoint') {
                     pieces.push(',');
                 }
 
             }
         }
 
         pieces.push(')');
 
         return pieces.join('');
     };
 
     /**
      * This object contains functions as property names that extract WKT
      * strings from the internal representation.
      * @memberof this.Wkt.Wkt
      * @namespace this.Wkt.Wkt.extract
      * @instance
      */
     Wkt.Wkt.prototype.extract = {
         /**
          * Return a WKT string representing atomic (point) geometry
          * @param   point   {Object}    An object with x and y properties
          * @return          {String}    The WKT representation
          * @memberof this.Wkt.Wkt.extract
          * @instance
          */
         point: function (point) {
             return String(point.x) + this.delimiter + String(point.y);
         },
 
         /**
          * Return a WKT string representing multiple atoms (points)
          * @param   multipoint  {Array}     Multiple x-and-y objects
          * @return              {String}    The WKT representation
          * @memberof this.Wkt.Wkt.extract
          * @instance
          */
         multipoint: function (multipoint) {
             var i, parts = [],
                 s;
 
             for (i = 0; i < multipoint.length; i += 1) {
                 s = this.extract.point.apply(this, [multipoint[i]]);
 
                 if (this.wrapVertices) {
                     s = '(' + s + ')';
                 }
 
                 parts.push(s);
             }
 
             return parts.join(',');
         },
 
         /**
          * Return a WKT string representing a chain (linestring) of atoms
          * @param   linestring  {Array}     Multiple x-and-y objects
          * @return              {String}    The WKT representation
          * @memberof this.Wkt.Wkt.extract
          * @instance
          */
         linestring: function (linestring) {
             // Extraction of linestrings is the same as for points
             return this.extract.point.apply(this, [linestring]);
         },
 
         /**
          * Return a WKT string representing multiple chains (multilinestring) of atoms
          * @param   multilinestring {Array}     Multiple of multiple x-and-y objects
          * @return                  {String}    The WKT representation
          * @memberof this.Wkt.Wkt.extract
          * @instance
          */
         multilinestring: function (multilinestring) {
             var i, parts = [];
 
             if (multilinestring.length) {
                 for (i = 0; i < multilinestring.length; i += 1) {
                     parts.push(this.extract.linestring.apply(this, [multilinestring[i]]));
                 }
             } else {
                 parts.push(this.extract.point.apply(this, [multilinestring]));
             }
 
             return parts.join(',');
         },
 
         /**
          * Return a WKT string representing multiple atoms in closed series (polygon)
          * @param   polygon {Array}     Collection of ordered x-and-y objects
          * @return          {String}    The WKT representation
          * @memberof this.Wkt.Wkt.extract
          * @instance
          */
         polygon: function (polygon) {
             // Extraction of polygons is the same as for multilinestrings
             return this.extract.multilinestring.apply(this, [polygon]);
         },
 
         /**
          * Return a WKT string representing multiple closed series (multipolygons) of multiple atoms
          * @param   multipolygon    {Array}     Collection of ordered x-and-y objects
          * @return                  {String}    The WKT representation
          * @memberof this.Wkt.Wkt.extract
          * @instance
          */
         multipolygon: function (multipolygon) {
             var i, parts = [];
             for (i = 0; i < multipolygon.length; i += 1) {
                 parts.push('(' + this.extract.polygon.apply(this, [multipolygon[i]]) + ')');
             }
             return parts.join(',');
         },
 
         /**
          * Return a WKT string representing a 2DBox
          * @param   multipolygon    {Array}     Collection of ordered x-and-y objects
          * @return                  {String}    The WKT representation
          * @memberof this.Wkt.Wkt.extract
          * @instance
          */
         box: function (box) {
             return this.extract.linestring.apply(this, [box]);
         },
 
         geometrycollection: function (str) {
             console.log('The geometrycollection WKT type is not yet supported.');
         }
     };
 
     /**
      * This object contains functions as property names that ingest WKT
      * strings into the internal representation.
      * @memberof this.Wkt.Wkt
      * @namespace this.Wkt.Wkt.ingest
      * @instance
      */
     Wkt.Wkt.prototype.ingest = {
 
         /**
          * Return point feature given a point WKT fragment.
          * @param   str {String}    A WKT fragment representing the point
          * @memberof this.Wkt.Wkt.ingest
          * @instance
          */
         point: function (str) {
             var coords = Wkt.trim(str).split(this.regExes.spaces);
             // In case a parenthetical group of coordinates is passed...
             return [{ // ...Search for numeric substrings
                 x: parseFloat(this.regExes.numeric.exec(coords[0])[0]),
                 y: parseFloat(this.regExes.numeric.exec(coords[1])[0])
             }];
         },
 
         /**
          * Return a multipoint feature given a multipoint WKT fragment.
          * @param   str {String}    A WKT fragment representing the multipoint
          * @memberof this.Wkt.Wkt.ingest
          * @instance
          */
         multipoint: function (str) {
             var i, components, points;
             components = [];
             points = Wkt.trim(str).split(this.regExes.comma);
             for (i = 0; i < points.length; i += 1) {
                 components.push(this.ingest.point.apply(this, [points[i]]));
             }
             return components;
         },
 
         /**
          * Return a linestring feature given a linestring WKT fragment.
          * @param   str {String}    A WKT fragment representing the linestring
          * @memberof this.Wkt.Wkt.ingest
          * @instance
          */
         linestring: function (str) {
             var i, multipoints, components;
 
             // In our x-and-y representation of components, parsing
             //  multipoints is the same as parsing linestrings
             multipoints = this.ingest.multipoint.apply(this, [str]);
 
             // However, the points need to be joined
             components = [];
             for (i = 0; i < multipoints.length; i += 1) {
                 components = components.concat(multipoints[i]);
             }
             return components;
         },
 
         /**
          * Return a multilinestring feature given a multilinestring WKT fragment.
          * @param   str {String}    A WKT fragment representing the multilinestring
          * @memberof this.Wkt.Wkt.ingest
          * @instance
          */
         multilinestring: function (str) {
             var i, components, line, lines;
             components = [];
 
             lines = Wkt.trim(str).split(this.regExes.doubleParenComma);
             if (lines.length === 1) { // If that didn't work...
                 lines = Wkt.trim(str).split(this.regExes.parenComma);
             }
 
             for (i = 0; i < lines.length; i += 1) {
                 line = lines[i].replace(this.regExes.trimParens, '$1');
                 components.push(this.ingest.linestring.apply(this, [line]));
             }
 
             return components;
         },
 
         /**
          * Return a polygon feature given a polygon WKT fragment.
          * @param   str {String}    A WKT fragment representing the polygon
          * @memberof this.Wkt.Wkt.ingest
          * @instance
          */
         polygon: function (str) {
             var i, j, components, subcomponents, ring, rings;
             rings = Wkt.trim(str).split(this.regExes.parenComma);
             components = []; // Holds one or more rings
             for (i = 0; i < rings.length; i += 1) {
                 ring = rings[i].replace(this.regExes.trimParens, '$1').split(this.regExes.comma);
                 subcomponents = []; // Holds the outer ring and any inner rings (holes)
                 for (j = 0; j < ring.length; j += 1) {
                     // Split on the empty space or '+' character (between coordinates)
                     var split = ring[j].split(this.regExes.spaces);
                     if (split.length > 2) {
                         //remove the elements which are blanks
                         split = split.filter(function (n) {
                             return n != ""
                         });
                     }
                     if (split.length === 2) {
                         var x_cord = split[0];
                         var y_cord = split[1];
 
                         //now push
                         subcomponents.push({
                             x: parseFloat(x_cord),
                             y: parseFloat(y_cord)
                         });
                     }
                 }
                 components.push(subcomponents);
             }
             return components;
         },
 
         /**
          * Return box vertices (which would become the Rectangle bounds) given a Box WKT fragment.
          * @param   str {String}    A WKT fragment representing the box
          * @memberof this.Wkt.Wkt.ingest
          * @instance
          */
         box: function (str) {
             var i, multipoints, components;
 
             // In our x-and-y representation of components, parsing
             //  multipoints is the same as parsing linestrings
             multipoints = this.ingest.multipoint.apply(this, [str]);
 
             // However, the points need to be joined
             components = [];
             for (i = 0; i < multipoints.length; i += 1) {
                 components = components.concat(multipoints[i]);
             }
 
             return components;
         },
 
         /**
          * Return a multipolygon feature given a multipolygon WKT fragment.
          * @param   str {String}    A WKT fragment representing the multipolygon
          * @memberof this.Wkt.Wkt.ingest
          * @instance
          */
         multipolygon: function (str) {
             var i, components, polygon, polygons;
             components = [];
             polygons = Wkt.trim(str).split(this.regExes.doubleParenComma);
             for (i = 0; i < polygons.length; i += 1) {
                 polygon = polygons[i].replace(this.regExes.trimParens, '$1');
                 components.push(this.ingest.polygon.apply(this, [polygon]));
             }
             return components;
         },
 
         /**
          * Return an array of features given a geometrycollection WKT fragment.
          * @param   str {String}    A WKT fragment representing the geometry collection
          * @memberof this.Wkt.Wkt.ingest
          * @instance
          */
         geometrycollection: function (str) {
             console.log('The geometrycollection WKT type is not yet supported.');
         }
 
     }; // eo ingest
 
     return Wkt;
 }));
 
 /** @license
  *
  *  Copyright (C) 2012 K. Arthur Endsley (kaendsle@mtu.edu)
  *  Michigan Tech Research Institute (MTRI)
  *  3600 Green Court, Suite 100, Ann Arbor, MI, 48105
  *
  *  This program is free software: you can redistribute it and/or modify
  *  it under the terms of the GNU General Public License as published by
  *  the Free Software Foundation, either version 3 of the License, or
  *  (at your option) any later version.
  *
  *  This program is distributed in the hope that it will be useful,
  *  but WITHOUT ANY WARRANTY; without even the implied warranty of
  *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  *  GNU General Public License for more details.
  *
  *  You should have received a copy of the GNU General Public License
  *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *
  */
 
 /**
  * @augments Wkt.Wkt
  * A framework-dependent flag, set for each Wkt.Wkt() instance, that indicates
  * whether or not a closed polygon geometry should be interpreted as a rectangle.
  */
 Wkt.Wkt.prototype.isRectangle = false;
 
 /**
  * @augments Wkt.Wkt
  * Truncates an Array of coordinates by the closing coordinate when it is
  * equal to the first coordinate given--this is only to be used for closed
  * geometries in order to provide merely an "implied" closure to Leaflet.
  * @param   coords  {Array}     An Array of x,y coordinates (objects)
  * @return          {Array}
  */
 Wkt.Wkt.prototype.trunc = function (coords) {
     var i, verts = [];
 
     for (i = 0; i < coords.length; i += 1) {
         if (Wkt.isArray(coords[i])) {
             verts.push(this.trunc(coords[i]));
 
         } else {
 
             // Add the first coord, but skip the last if it is identical
             if (i === 0 || !this.sameCoords(coords[0], coords[i])) {
                 verts.push(coords[i]);
             }
         }
     }
 
     return verts;
 };
 
 /**
  * @augments Wkt.Wkt
  * An object of framework-dependent construction methods used to generate
  * objects belonging to the various geometry classes of the framework.
  */
 Wkt.Wkt.prototype.construct = {
     /**
      * Creates the framework's equivalent point geometry object.
      * @param   config      {Object}    An optional properties hash the object should use
      * @param   component   {Object}    An optional component to build from
      * @return              {L.marker}
      */
     point: function (config, component) {
         var coord = component || this.components;
         if (coord instanceof Array) {
             coord = coord[0];
         }
 
         return L.marker(this.coordsToLatLng(coord), config);
     },
 
     /**
      * Creates the framework's equivalent multipoint geometry object.
      * @param   config  {Object}    An optional properties hash the object should use
      * @return          {L.featureGroup}
      */
     multipoint: function (config) {
         var i,
             layers = [],
             coords = this.components;
 
         for (i = 0; i < coords.length; i += 1) {
             layers.push(this.construct.point.call(this, config, coords[i]));
         }
 
         return L.featureGroup(layers, config);
     },
 
     /**
      * Creates the framework's equivalent linestring geometry object.
      * @param   config      {Object}    An optional properties hash the object should use
      * @param   component   {Object}    An optional component to build from
      * @return              {L.polyline}
      */
     linestring: function (config, component) {
         var coords = component || this.components,
             latlngs = this.coordsToLatLngs(coords);
 
         return L.polyline(latlngs, config);
     },
 
     /**
      * Creates the framework's equivalent multilinestring geometry object.
      * @param   config  {Object}    An optional properties hash the object should use
      * @return          {L.multiPolyline}
      */
     multilinestring: function (config) {
         var coords = this.components,
             latlngs = this.coordsToLatLngs(coords, 1);
 
         return L.multiPolyline(latlngs, config);
     },
 
     /**
      * Creates the framework's equivalent polygon geometry object.
      * @param   config      {Object}    An optional properties hash the object should use
      * @return              {L.multiPolygon}
      */
     polygon: function (config) {
         // Truncate the coordinates to remove the closing coordinate
         var coords = this.trunc(this.components),
             latlngs = this.coordsToLatLngs(coords, 1);
         return L.polygon(latlngs, config);
     },
 
     /**
      * Creates the framework's equivalent multipolygon geometry object.
      * @param   config  {Object}    An optional properties hash the object should use
      * @return          {L.multiPolygon}
      */
     multipolygon: function (config) {
         // Truncate the coordinates to remove the closing coordinate
         var coords = this.trunc(this.components),
             latlngs = this.coordsToLatLngs(coords, 2);
 
         return L.multiPolygon(latlngs, config);
     },
 
     /**
      * Creates the framework's equivalent collection of geometry objects.
      * @param   config  {Object}    An optional properties hash the object should use
      * @return          {L.featureGroup}
      */
     geometrycollection: function (config) {
         var comps, i, layers;
 
         comps = this.trunc(this.components);
         layers = [];
         for (i = 0; i < this.components.length; i += 1) {
             layers.push(this.construct[comps[i].type].call(this, comps[i]));
         }
 
         return L.featureGroup(layers, config);
 
     }
 };
 
 L.Util.extend(Wkt.Wkt.prototype, {
     coordsToLatLngs: L.GeoJSON.coordsToLatLngs,
     // TODO Why doesn't the coordsToLatLng function in L.GeoJSON already suffice?
     coordsToLatLng: function (coords, reverse) {
         var lat = reverse ? coords.x : coords.y,
             lng = reverse ? coords.y : coords.x;
 
         return L.latLng(lat, lng, true);
     }
 });
 
 /**
  * @augments Wkt.Wkt
  * A framework-dependent deconstruction method used to generate internal
  * geometric representations from instances of framework geometry. This method
  * uses object detection to attempt to classify members of framework geometry
  * classes into the standard WKT types.
  * @param   obj {Object}    An instance of one of the framework's geometry classes
  * @return      {Object}    A hash of the 'type' and 'components' thus derived
  */
 Wkt.Wkt.prototype.deconstruct = function (obj) {
     var attr, coordsFromLatLngs, features, i, verts, rings, tmp;
 
     /**
      * Accepts an Array (arr) of LatLngs from which it extracts each one as a
      *  vertex; calls itself recursively to deal with nested Arrays.
      */
     coordsFromLatLngs = function (arr) {
         var i, coords;
 
         coords = [];
         for (i = 0; i < arr.length; i += 1) {
             if (Wkt.isArray(arr[i])) {
                 coords.push(coordsFromLatLngs(arr[i]));
 
             } else {
                 coords.push({
                     x: arr[i].lng,
                     y: arr[i].lat
                 });
             }
         }
 
         return coords;
     };
 
     // L.Marker ////////////////////////////////////////////////////////////////
     if (obj.constructor === L.Marker || obj.constructor === L.marker) {
         return {
             type: 'point',
             components: [{
                 x: obj.getLatLng().lng,
                 y: obj.getLatLng().lat
             }]
         };
     }
 
     // L.Rectangle /////////////////////////////////////////////////////////////
     if (obj.constructor === L.Rectangle || obj.constructor === L.rectangle) {
         tmp = obj.getBounds(); // L.LatLngBounds instance
         return {
             type: 'polygon',
             isRectangle: true,
             components: [
                 [
                     { // NW corner
                         x: tmp.getSouthWest().lng,
                         y: tmp.getNorthEast().lat
                     },
                     { // NE corner
                         x: tmp.getNorthEast().lng,
                         y: tmp.getNorthEast().lat
                     },
                     { // SE corner
                         x: tmp.getNorthEast().lng,
                         y: tmp.getSouthWest().lat
                     },
                     { // SW corner
                         x: tmp.getSouthWest().lng,
                         y: tmp.getSouthWest().lat
                     },
                     { // NW corner (again, for closure)
                         x: tmp.getSouthWest().lng,
                         y: tmp.getNorthEast().lat
                     }
                 ]
             ]
         };
 
     }
 
     // L.Polyline //////////////////////////////////////////////////////////////
     if (obj.constructor === L.Polyline || obj.constructor === L.polyline) {
         verts = [];
         tmp = obj.getLatLngs();
 
         if (!tmp[0].equals(tmp[tmp.length - 1])) {
 
             for (i = 0; i < tmp.length; i += 1) {
                 verts.push({
                     x: tmp[i].lng,
                     y: tmp[i].lat
                 });
             }
 
             return {
                 type: 'linestring',
                 components: verts
             };
 
         }
     }
 
     // L.Polygon ///////////////////////////////////////////////////////////////
 
     if (obj.constructor === L.Polygon || obj.constructor === L.polygon) {
         rings = [];
         verts = [];
         tmp = obj.getLatLngs();
 
         // First, we deal with the boundary points
         for (i = 0; i < obj._latlngs.length; i += 1) {
             verts.push({ // Add the first coordinate again for closure
                 x: tmp[i].lng,
                 y: tmp[i].lat
             });
         }
 
         verts.push({ // Add the first coordinate again for closure
             x: tmp[0].lng,
             y: tmp[0].lat
         });
 
         rings.push(verts);
 
         // Now, any holes
         if (obj._holes && obj._holes.length > 0) {
             // Reworked to support holes properly
             verts = coordsFromLatLngs(obj._holes);
             for (i=0; i < verts.length;i++) {
                 verts[i].push(verts[i][0]); // Copy the beginning coords again for closure
                 rings.push(verts[i]);
             }
         }
 
         return {
             type: 'polygon',
             components: rings
         };
 
     }
 
     // L.MultiPolyline /////////////////////////////////////////////////////////
     // L.MultiPolygon //////////////////////////////////////////////////////////
     // L.LayerGroup ////////////////////////////////////////////////////////////
     // L.FeatureGroup //////////////////////////////////////////////////////////
     if (obj.constructor === L.MultiPolyline || obj.constructor === L.MultiPolygon
             || obj.constructor === L.LayerGroup || obj.constructor === L.FeatureGroup) {
 
         features = [];
         tmp = obj._layers;
 
         for (attr in tmp) {
             if (tmp.hasOwnProperty(attr)) {
                 if (tmp[attr].getLatLngs || tmp[attr].getLatLng) {
                     // Recursively deconstruct each layer
                     features.push(this.deconstruct(tmp[attr]));
                 }
             }
         }
 
         return {
 
             type: (function () {
                 switch (obj.constructor) {
                 case L.MultiPolyline:
                     return 'multilinestring';
                 case L.MultiPolygon:
                     return 'multipolygon';
                 case L.FeatureGroup:
                     return (function () {
                         var i, mpgon, mpline, mpoint;
 
                         // Assume that all layers are of one type (any one type)
                         mpgon = true;
                         mpline = true;
                         mpoint = true;
 
                         for (i in obj._layers) {
                             if (obj._layers.hasOwnProperty(i)) {
                                 if (obj._layers[i].constructor !== L.Marker) {
                                     mpoint = false;
                                 }
                                 if (obj._layers[i].constructor !== L.Polyline) {
                                     mpline = false;
                                 }
                                 if (obj._layers[i].constructor !== L.Polygon) {
                                     mpgon = false;
                                 }
                             }
                         }
 
                         if (mpoint) {
                             return 'multipoint';
                         }
                         if (mpline) {
                             return 'multilinestring';
                         }
                         if (mpgon) {
                             return 'multipolygon';
                         }
                         return 'geometrycollection';
 
                     }());
                 default:
                     return 'geometrycollection';
                 }
             }()),
 
             components: (function () {
                 // Pluck the components from each Wkt
                 var i, comps;
 
                 comps = [];
                 for (i = 0; i < features.length; i += 1) {
                     if (features[i].components) {
                         comps.push(features[i].components);
                     }
                 }
 
                 return comps;
             }())
 
         };
 
     }
 
     // L.Circle ////////////////////////////////////////////////////////////////
     if (obj.constructor === L.Rectangle || obj.constructor === L.rectangle) {
         console.log('Deconstruction of L.Circle objects is not yet supported');
 
     } else {
         console.log('The passed object does not have any recognizable properties.');
     }
 
 };
 