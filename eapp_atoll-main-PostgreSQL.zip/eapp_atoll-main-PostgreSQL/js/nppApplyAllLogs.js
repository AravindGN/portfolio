
var projectDataSource = new kendo.data.DataSource({
	data: [],
});

function getSummaryColumns() {
	return [
		{
			"title": "Site Record ID",
			"field": "siteRecordId",
			width: 30,
			attributes: { style: "white-space: normal; overflow : visible" },
			headerAttributes: { style: "white-space: normal; overflow : visible" }
		},
		{
			"title": "Process",
			"field": "processName",
			width: 50,
			attributes: { style: "white-space: normal; overflow : visible" },
			headerAttributes: { style: "white-space: normal; overflow : visible" }
		},
		{
			"title": "Log Identifier",
			"field": "logIdentifier",
			width: 50,
			attributes: { style: "white-space: normal; overflow : visible" },
			headerAttributes: { style: "white-space: normal; overflow : visible" }
		},
		{
			"title": " Message Type",
			"field": "messageType",
			width: 40,
			attributes: { style: "white-space: normal; overflow : visible" },
			headerAttributes: { style: "white-space: normal; overflow : visible" }
		},
		{
			"title": "Message",
			"field": "message",
			width: 150,
			attributes: { style: "white-space: normal; overflow : visible" },
			headerAttributes: { style: "white-space: normal; overflow : visible" }
		},
		{
			"title": "Date",
			"field": "modifiedDate",
			width: 40,
			headerAttributes: { style: "white-space: normal; overflow : visible" }
		}
	]
}

function getNppApplyAllLogs(params) {
	$('#loading').show();
	$.ajax({
		type: 'POST',
		url: fetchNppApplyAllLogsUrl,
		dataType: 'json',
		contentType: 'application/json; charset=UTF-8',
		cache: false,
		data: JSON.stringify(params),
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function(data) {
			if(data.length > 0){
				data.forEach(element => {
					if(element['messageType'] == "1"){
						element['messageType'] = "Info";
					}else if(element['messageType'] == "2"){
						element['messageType'] = "Error";
					}else if (element['messageType'] == "3"){
						element['messageType'] = "Warning";
					}	
				});
			}
			var returnedData = data;
			if (returnedData.length < 1) {
				$('#loading').hide()
				console.log('info', 'No data found');
				grid.setDataSource(
					new kendo.data.DataSource({
						pageSize: 10,
						data: [],
					}));
				return;
			}
			$('#loading').hide();
			$('#responseGrid')
				.getKendoGrid()
				.setDataSource(
					new kendo.data.DataSource({
						pageSize: 25,
						data: data
					})
				);
		},
		error: function(request, status, err) {
			$('#loading').hide();
			console.log('Error', 'Something went wrong while fetching Npp Apply All Logs ' + err);
		}
	});

}

function logsTable(id, dataSource, columns) {
	$(id).kendoGrid({
		dataSource: dataSource,
		columns: columns,
		sortable: true,
		filterable: {
			extra: false,
			operators: {
				string: {
					startswith: "Starts with",
					eq: "Is equal to",
					neq: "Is not equal to"
				}
			}
		},
		pageable: {
			pageSize: 25,
			input: true,
			numeric: false,
			pageSizes: [25, 50, 75, 100, 150, 200, "All"]

		},
		change: function() {

		},
		dataBound: function(e) {

		},
		noRecords: {
			template: "<div style='font-size:12px;color:red'>No data available</div>"
		},

	});
	grid = $(id).data("kendoGrid");

}

function openNppApplyLogs(params) {

	if ($("#nppapply_apply_btn").attr("disabled")) return;
	if (document.getElementById("ApplyAll_Logs_div")) {
		$("#alertMask").show();
		$("#ApplyAll_Logs_div").show();
	} else {
		var divElement = document.createElement('div');
		divElement.id = "alertMask";
		divElement.className = "alert-mask";
		document.body.appendChild(divElement);

		var ApplyAll_Logs_div = document.createElement('div');
		ApplyAll_Logs_div.id = "ApplyAll_Logs_div";
		ApplyAll_Logs_div.style.cssText = "position:fixed;z-index:1003;top:4%;Width:100%;";
		document.body.appendChild(ApplyAll_Logs_div);

		var container = document.createElement('div');
		container.style.cssText = "padding:0px;min-height:0px;width: 95%;min-width: 1200px;";
		container.id = "container-whitepage";
		container.className = "container whitepage";
		document.getElementById("ApplyAll_Logs_div").appendChild(container);

		var rowHeader = document.createElement('div');
		rowHeader.id = "rowHeader";
		rowHeader.className = "row header-cls";
		rowHeader.style.cssText = "margin:0px;";
		document.getElementById("container-whitepage").appendChild(rowHeader);
		document.getElementById("rowHeader").innerHTML = '<span id="ApplyAll_Logs_div_title">NPP Apply All Logs</span><span><button id="ApplyAll_Logs_div_close" class="btn btn-danger btn-circle floating-right-cls" onclick="closeNppApplyLogs()" type="button"><i class="glyphicon glyphicon-remove"></i></button></span>';

		var formGroup = document.createElement('div');
		formGroup.id = "formGroup";
		formGroup.className = "form-group";
		formGroup.style.cssText = "margin-bottom: 0;";
		document.getElementById("container-whitepage").appendChild(formGroup);
		document.getElementById("formGroup").innerHTML = '<div style="font-size: 12px;" id="responseGrid"></div>';

	}
	logsTable("#responseGrid", projectDataSource, getSummaryColumns());
	getNppApplyAllLogs(params);
}

function closeNppApplyLogs() {
	$('#alertMask').hide();
	$('#ApplyAll_Logs_div').hide();
	$("#ApplyAll_Logs_div").attr('src', "");
}
