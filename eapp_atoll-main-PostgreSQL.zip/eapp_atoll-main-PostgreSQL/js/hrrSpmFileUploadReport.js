var gridDataSource = new kendo.data.DataSource({
    data: [],
    pageSize: 10
});

var popupGridDataSource = new kendo.data.DataSource({
    data: [],
    pageSize: 10
});

var popupCandidatesGridDataSource = new kendo.data.DataSource({
    data: [],
    pageSize: 5
});

var popupProjectStatusLogGridDataSource = new kendo.data.DataSource({
    data: [],
    pageSize: 5
});

var popupHRRAnalyticsGridDataSource = new kendo.data.DataSource({
    data: [],
    pageSize: 5
});

var popupCandidateLogGridDataSource = new kendo.data.DataSource({
    data: [],
    pageSize: 5
});

var pieChartDatasource = new kendo.data.DataSource({
    data: []
});

var candCreationFailureCount=0
var candCreationFailureColor="blue";
var transmitterCoverageFailureCount=0;
var transmitterCoverageFailureColor="yellow";
var siteAnalyticsFailureCount=0;
var siteAnalyticsFailureColor="violet";
var spmImageGenerationFailureCount=0;
var spmImageGenerationFailureColor="#7c7c7c";
var successCount = 0;
var successColor = "green";
var failureCount = 0;
var failureColor = "red";
var inprogressCount = 0;
var inprogressColor = "blue";
var holdCount = 0;
var holdColor = "yellow";
var currentProjectId = "";
var currentFuzeSiteId = "";


var hrrFileUploadColumns = [
	{
        "title": "FuzeSite Id",
        "field": "fuzeSiteId",
		width: 35,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
	{
        "title": "Document Path",
        "field": "documentPath",
		width: 30,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        },
        template: function (dataItem) {
            return '<a href="' + dataItem.documentPath + '" target="_blank"> Download </a>';
        }
    },
    {
        "title": "Document Type",
        "field": "documentType",
		width: 30,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    }
];

var hrrProjectStatusLogsColumns = [
    {
        "title": "STATUS",
        "field": "status",
		width: 30,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
    {
        "title": "ERROR MSG",
        "field": "errorMsg",
		width: 30,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
    {
        "title": "START DATE",
        "field": "startDate",
		width: 30,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
    {
        "title": "END DATE",
        "field": "endDate",
		width: 30,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
    {
        "title": "COMMENTS",
        "field": "comments",
		width: 30,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    }
]

var hrrCandEntryColumns = [
	{
        "title": "FUZE SITE ID",
        "field": "candFuzeSiteId",
		width: 30,
		attributes: { 
        	style:"font-size: larger;"
            
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
     },
    {
        "title": "SITE RECORD ID",
        "field": "candSiteRecordId",
		width: 30,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
    {
        "title": "SPM REPORT STATUS",
        "field": "spmReportStatus",
		width: 30,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
    {
        "title": "DATE",
        "field": "modifiedDate",
		width: 30,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },

    {
        "title": "ANALYTICS RE-TRIGGERED",
        "field": "isSiteAnalyticsTriggered",
		width: 75,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
    {
        "title": "IS DELETED",
        "field": "isDeleted",
		width: 75,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
    
    
];

var hrrCandLogColumns = [
	{
        "title": "SITE ID",
        "field": "fuzeSiteId",
		width: 30,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
	{
        "title": "STATUS",
        "field": "status",
		width: 30,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
    {
        "title": "COMMENTS",
        "field": "comments",
		width: 50,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
    {
        "title": "ERROR MSG",
        "field": "errorMsg",
		width: 30,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
    {
        "title": "START DATE",
        "field": "startDate",
		width: 30,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
    {
        "title": "END DATE",
        "field": "endDate",
		width: 30,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    }
    // {
    //     "title": "INBOUND REQUEST",
    //     "field": "inboundRequest",
	// 	width: 50,
	// 	attributes: { 
    //     	style:"font-size: larger;"
    //     },
    //     headerAttributes: {
    //         style: "font-weight: bold; font-size: larger;"
    //     }
    // },
    // {
    //     "title": "OUTBOUND RESPONSE",
    //     "field": "outboundResponse",
	// 	width: 50,
	// 	attributes: { 
    //     	style:"font-size: larger;"
    //     },
    //     headerAttributes: {
    //         style: "font-weight: bold; font-size: larger;"
    //     }
    // }
];

var hrrTaskStatusColumns = [
	{
        title: "SPM Project Id",
        field:"spmProjectId",
        width: 35,
        attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        },
        template: function (dataItem) {
            return '<button class="spmProjectId" projectId="'+dataItem.spmProjectId+'" type="button" style="margin-top:4px;"> '+dataItem.spmProjectId+'</button>';
        }
    },
    {
        title: "Fuze Site Id",
        field:"fuzeSiteId",
        width: 35,
        attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
    {
        "title": "Created Date",
        "field": "createdDate",
		width: 50,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
    {
        "title": "Documents",
        "field": "Documents",
		width: 35,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        },
        template: function (dataItem) {
            return '<button class="documents" projectId="'+dataItem.spmProjectId+'" type="button"> Documents</button>';
        }
    },
    {
        "title": "Status",
        "field": "status",
		width: 80,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
    {
        "title": "Error Msg",
        "field": "errorMsg",
		width: 100,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    }
];


var atollEqpBunColumns = [
	{
        title: "Parent Solution Id",
        field:"parentSolutionId",
        width: 25,
        attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
        
    },
    {
        "title": "Error Msg",
        "field": "errorMsg",
		width: 60,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
    {
        "title": "Status",
        "field": "status",
		width: 30,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    }, {
        "title": "Created Date",
        "field": "startDate",
		width: 30,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },{
        "title": "Request",
        "field": "request",
		width: 60,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
	{
        "title": "Response",
        "field": "response",
		width: 60,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
    {
        "title": "Error Msg",
        "field": "errorMsg",
		width: 60,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    }
];

var hrrAnalyticsColumns = [
	{
        "title": "SPM Project Id",
        "field": "spmProjectId",
		width: 35,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
	{
        "title": "Market",
        "field": "market",
		width: 30,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
    {
        "title": "Log Time",
        "field": "logTime",
		width: 30,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
    {
        "title": "Log Message",
        "field": "logMessage",
		width: 150,
		attributes: { 
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    }
];

var dataAnalyticsColumns = [
        {
        "title": "Site Info Id",
        "field": "fuzeSiteId",
		width: 35,
		attributes: {
        	style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
    {
        "title": "SPM Project Id",
        "field": "spmProjectId",
    	width: 30,
    	attributes: {
        style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
    {
        "title": "Site Status",
        "field": "status",
    	width: 30,
    	attributes: {
        style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
    {
        "title": "Mapping",
        "field": "mappingStatus",
    	width: 70,
    	attributes: {
        style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        }
    },
    {
        "title": "Source",
        "field": "source",
    	width: 35,
    	attributes: {
        style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        },
    },
    {
        "title": "Site Record ID",
        "field": "siteRecordId",
    	width: 35,
    	attributes: {
        style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        },
    },
    {
        "title": "Created Date",
        "field": "createdDate",
    	width: 35,
    	attributes: {
        style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        },
     },
    {
        "title": "Data Validation",
        "field": "Data Validation",
    	width: 35,
    	attributes: {
        style:"font-size: larger;"
        },
        headerAttributes: {
            style: "font-weight: bold; font-size: larger;"
        },
    template: function (dataItem) {
            return '<button class="runAnalytics" fuzeSiteId="'+dataItem.fuzeSiteId+'" type="button">Run</button>';
        }
    }
];

$(document).ready(function () {

    try {
        var env = window.location.href.includes('canvasple') ? '-PLE' : '';
        window.initClickstream({
            "system_name": "Network Planning Platform",
            "app_name": "ATOLL" + env,
            "screen_name": "ATOLL Dashboards",
            "showLogs" : "true"
        });
    } catch(e) {
        return false;
    }

    $("pre").width(480);
    $('#atoll-select').on('change', function() {
    	$('#loading').show();
    	var gridColumns;
        var tableName=$('#atoll-select').val();
        var view;
        var dataload=false;
        if(tableName=='atoll_eqp_bundling_transaction'){
        	$('.hrrStatusCiteria').hide();
            $('.atollEQBCiteria').show();
            $('.hrrAnalyticsCiteria').hide();
            $('.dataAnalyticsCiteria').hide();
        	gridColumns=atollEqpBunColumns;
        	view="getAtollEquipmentBundlingTransactionList";
        	$('.candidateGrid').children().appendTo('.grid');
        }else if(tableName=='hrr_status'){
        	$('.hrrStatusCiteria').show();
            $('.atollEQBCiteria').hide();
            $('.hrrAnalyticsCiteria').hide();
            $('.dataAnalyticsCiteria').hide();
        	gridColumns=hrrTaskStatusColumns;
        	view="getHRRTaskStatus";
        	$('.candidateGrid').children().appendTo('.grid');
        }else if(tableName=='hrr_analytics'){
        	$('.hrrAnalyticsCiteria').show();
            $('.atollEQBCiteria').hide();
            $('.hrrStatusCiteria').hide();
            $('.dataAnalyticsCiteria').hide();
        	gridColumns=hrrAnalyticsColumns;
            dataload=true;
        	view="getHRRAnalytics";
        	$('.candidateGrid').children().appendTo('.grid');
        }else if(tableName=='data_analytics'){
            $('.dataAnalyticsCiteria').show();
            $('.atollEQBCiteria').hide();
            $('.hrrStatusCiteria').hide();
            $('.hrrAnalyticsCiteria').hide();
            $('#individualData').hide();
            gridColumns=dataAnalyticsColumns;
            view="getDataAnalytics";
            $('.grid').children().appendTo('.candidateGrid');
            $('#fixLog').prop('disabled',true);
            $('#fix').prop('disabled',true);
        }

        $('#reportGrid').data().kendoGrid.destroy();
        $('#statusPieChart').data().kendoChart.destroy();
        resetCriteria();
        setDateToDefault();
        createPieChart();

        $(".tabs-list li a").click(function(e){
             e.preventDefault();
          });

          $(".tabs-list li").click(function(){
             var tabid = $(this).find("a").attr("href");
             $(".tabs-list li,.tabs div.tab").removeClass("active");   // removing active class from tab

             $(".tab").hide();   // hiding open tab
             $(tabid).show();    // show tab
             $(this).addClass("active"); //  adding active class to clicked tab
             if(tabid=='#individualRecord'){
             $('.individualRecordCriteria').show();
             $('.atollEQBCiteria').hide();
             $('.hrrStatusCiteria').hide();
             $('.hrrAnalyticsCiteria').hide();
             $('.dataAnalyticsCiteria').show();
             $('.grid').hide();
             }

             if(tabid=='#candidateLog'){
             $('#siteId').val('');
             //$('#jsonBox').text('');
             $('#individualData').hide();
             $('.individualRecordCriteria').show();
             $('.atollEQBCiteria').hide();
             $('.hrrStatusCiteria').hide();
             $('.hrrAnalyticsCiteria').hide();
             $('.dataAnalyticsCiteria').show();
             $('.grid').show();
             }
          });

        loadReportData(gridColumns,view,addEmptyFilterCriteria(), dataload);
    });

    $("#reportGridExportBtn").click(function (e) {
        e.preventDefault();
        var dataChk = $("#reportGrid").data("kendoGrid").dataSource.data();
        var fileName = 'HRR_SPM_REPORT_'+new Date().toJSON().slice(0, 10)+'.csv' ;
        if (dataChk==undefined || dataChk==null  || dataChk.length== 0) {
        	$('#errorMessageSpan').text('');
            $('#errorMessageSpan').text("No records found to export");
            $("#myModal").modal("show");
            $('#myModal').attr('style', 'width: fit-content; vertical-align: middle; height: 100%; margin: 0px auto; display: block !important;');
            return;
        }
        var columns  =[];
        $('#reportGrid').find('thead .k-link:visible').each(function( index ) {
            columns.push($( this ).text());
          });
        exportDataAsCSV('reportGrid',fileName,columns);
    });


    $('.hrrStatusCiteria').show();
    $('.atollEQBCiteria').hide();
    $('.hrrAnalyticsCiteria').hide();
    $('.dataAnalyticsCiteria').hide();
    appendStatusOptions();
    appendHrrStatusOptions();
    $(document).on("click",".documents",function(e) {
        e.preventDefault();
        loadPopData($(this).attr("projectId"));
    });
    $(document).on("click",".runAnalytics",function(e) {
        e.preventDefault();
        loadpopIndividualRecord($(this).attr("fuzeSiteId"));
        });
    $(document).on("click",".spmProjectId",function(e) {
        e.preventDefault();
        loadProjectPopData($(this).attr("projectId"));
        currentProjectId = $(this).attr("projectId");
    });
    $(document).on("click","#closeAddIcon",function(e) {
        e.preventDefault();
        closePopupDialog();
    });
    $(document).on("click","#closeButton",function(e) {
        e.preventDefault();
        closePopupBox();
        });
    $(document).on("click","#searchReportData",function(e) {
        e.preventDefault();
        searchReportData();
    });
    $('#startDate').daterangepicker({
        "singleDatePicker": true,
        "showDropdowns": true,
        "timePicker": false,
        "autoUpdateInput": false,
        "startDate":  moment().subtract('days', 29),
        "maxDate": moment(),
        "locale": {
            "format": "DD-MMM-YYYY",
            "cancelLabel": 'Clear'
        }
    });
    $('#endDate').daterangepicker({
        "singleDatePicker": true,
        "showDropdowns": true,
        "timePicker": false,
        "autoUpdateInput": false,
        "startDate":  moment(),
        "maxDate": moment(),
        "locale": {
            "format": "DD-MMM-YYYY",
            "cancelLabel": 'Clear'
        }
    });
    setDateToDefault();
    $('.daterangepicker_input').on('apply.daterangepicker', function (ev, picker) {
        $(this).val(picker.startDate.format('DD-MMM-YYYY'));
    });

    $('.daterangepicker_input').on('cancel.daterangepicker', function (ev, picker) {
        $(this).val('');
    });
    loadReportData(hrrTaskStatusColumns,"getHRRTaskStatus",addEmptyFilterCriteria(), false);
    createPieChart();
});

function loadReportData(columns, view, filterCriteria, dataLoad){
	var reqObj={};
	reqObj.view=view;
	if(view=="getHRRAnalytics"){
        reqObj.projectId=filterCriteria.projectId;
    }else if(view!="getDataAnalytics"){
        reqObj.filterCriteria=filterCriteria;
    } 
	 $('#reportGrid').empty();
	 successCount=0;
     failureCount=0;
     holdCount=0;
	 inprogressCount=0;
	 candCreationFailureCount=0
	 transmitterCoverageFailureCount=0;
	 siteAnalyticsFailureCount=0;
	 spmImageGenerationFailureCount=0;

	var goalsGrid = $("#reportGrid").kendoGrid({
        dataSource: gridDataSource,
        sortable: true,
        sort: function(e) {
            console.log("sorting is clicked!");
        },
        pageable: {
            pageSizes: true,
            change:function(e){
                console.log("grid pager clicke" +
                		"d!");
           }
        },
        excel:{
            fileName:'HRR_SPM_REPORT_'+new Date().toJSON().slice(0, 10)+'.csv',
            allPages:true,
            filterable:true
        },
        columnMenu: true,
        reorderable: false,
        resizable: false,
        scrollable: {
            virtual: true
        },
        height:"250px" ,
        columns: columns,
        editable: "inline"
    }).data("kendoGrid");

	var toolbar = $("<span class='.k-header.k-grid-toolbar'> </span>")
	$(toolbar).appendTo($("#reportGrid .k-grid-pager"));
	var excelEle = "<a id='reportGridExportBtn' role='button' style='margin-top:4px;' class = 'k-button k-button-icontext k-grid-excel' href='#' ><span class='k-icon k-i-file-excel'>::before</span>Export To Excel</a>";
    toolbar.append(excelEle);
    $('#reportGrid').find(".k-button.k-button-icontext.k-grid-excel").addClass("tableExcel").attr("title","Downloads Records as CSV file");

    if(dataLoad){
        gridDataSource.data([]);
        if(view=="getHRRAnalytics"){
            $('.chartWrapper').hide();
            $('.timestamp').hide();
            $('.searchReq').show();
        }
        $('#loading').hide();
    }else{
        $.ajax({
            url:  CONTEXT_PATH+"/uui/eapp/atoll_pg/atollTransactionTableData",
            type: "POST",
            dataType: "json",
            data:JSON.stringify(reqObj),
            contentType: "application/json",
            success: function (response) {
                if (response != null && response.length > 0) {
                    gridDataSource.data(response);
                    if(view=="getHRRTaskStatus"){
                        for (let task of response) {
                            if (task && task.status && (task.status == "SUCCESS" || task.status == "success")) {
                                successCount++;
                            } else if (task && task.status && (task.status == "CAND_CREATION_FAILURE")) {
                                candCreationFailureCount++;
                            } else if (task && task.status && task.status == "TRANSMITTER_COVERAGE_FAILURE") {
                                transmitterCoverageFailureCount++;
                            } else if (task && task.status && task.status == "SITE_ANALYTICS_FAILURE") {
                                siteAnalyticsFailureCount++;
                            } else if (task && task.status && task.status == "SPM_IMAGE_GENRATION_FAILURE") {
                                spmImageGenerationFailureCount++;
                            }
                        }
                        $('.chartWrapper').show();
                        $('.timestamp').show();
                        $('.searchReq').show();
                        updateHrrPieChart();
                    }else if(view=="getAtollEquipmentBundlingTransactionList"){
                        for (let task of response) {
                            if (task && task.status && (task.status == "SUCCESS" || task.status == "success")) {
                                successCount++;
                            } else if (task && task.status && (task.status == "FAILURE" || task.status == "failure" || task.status == "error")) {
                                failureCount++;
                            } else if (task && task.status && task.status == "HOLD") {
                                holdCount++;
                            } else if (task && task.status && task.status == "INPROGRESS") {
                                inprogressCount++;
                            }
                        }
                        $('.chartWrapper').show();
                        $('.timestamp').show();
                        $('.searchReq').show();
                        updatePieChart();
                    }else if(view=="getHRRAnalytics"){
                        $('.chartWrapper').hide();
                        $('.timestamp').hide();
                        $('.searchReq').show();
                    }else if(view=="getDataAnalytics"){
                        for (let task of response) {
                            if (task && task.status && (task.status == "SUCCESS" || task.status == "success")) {
                                successCount++;
                            } else if (task && task.status && (task.status == "FAILURE" || task.status == "failure" || task.status == "error")) {
                                failureCount++;
                            }
                        }
                         $('.chartWrapper').hide();
                         $('.timestamp').hide();
                         $('.searchReq').hide();
                    }
                } else{
                    gridDataSource.data([]);
                    pieChartDatasource.data([]);
                    if(view=="getHRRAnalytics"){
                        $('.chartWrapper').hide();
                        $('.timestamp').hide();
                        $('.searchReq').show();
                    }else if(view=="getDataAnalytics"){
                        $('.chartWrapper').hide();
                        $('.timestamp').hide();
                        $('.searchReq').hide();
                    }else{
                        $('.chartWrapper').show();
                        $('.timestamp').show();
                        $('.searchReq').show();
                    }
                }
                $('#loading').hide();
            },
            error: function (data) {
                $('#loading').hide();
                if(view=="getHRRAnalytics"){
                    $('.chartWrapper').hide();
                    $('.timestamp').hide();
                    $('.searchReq').show();
                }else if(view=="getDataAnalytics"){
                    $('.chartWrapper').hide();
                    $('.timestamp').hide();
                    $('.searchReq').hide();
                }else{
                    $('.chartWrapper').show();
                    $('.timestamp').show();
                    $('.searchReq').show();
                }
                updatePieChart();
                gridDataSource.data([]);
                console.log("Error occurred while fetching the data from the API.");
            }
        });
    }
	
}

function exportDataAsCSV(gridId, fileName, allowedColumns) {
    $('#loading').show();
    var csv        = '';
    var anchorLink = null;
    var data       = null;
    fileName       = fileName || 'HRR_SPM_REPORT_'+new Date().toJSON().slice(0, 10)+'.csv';
    var grid       = $("#" + gridId).data("kendoGrid");
    // Gets the data source from the grid.
    var dataSource = $("#"+gridId).data("kendoGrid").dataSource;
    // Gets the filter from the dataSource
    var filters    = dataSource.filter();
    // Gets the full set of data from the data source
    var allData     = dataSource.data();
    // Applies the filter to the data
    var query        = new kendo.data.Query(allData);
    var finalData = query.filter(filters).data;
    
    data =finalData;

    //collect header row
    for (var i = 0; i < grid.columns.length; i++) {
        var field = grid.columns[i].field;
        var title = grid.columns[i].title || field;

        //validate column value 
        if (!field) continue;
        if (allowedColumns.indexOf(title) >-1){
             title = title.replace(/"/g, '""');
             csv += '"' + title + '"';
             if (i < grid.columns.length - 1) {
                 csv += ',';
             }
         }
    }
    csv += '\n';

    //collect and add each row of data
   if(data!=null && data!=undefined && data.length>0){
 	  for(var j=0;j<data.length; j++) {
 		  let row =data[j];
 		  let rowDataInCsv ="";
 		  for (var i = 0; i < grid.columns.length; i++) {
 			  var fieldName = grid.columns[i].field;
 			  var title = grid.columns[i].title || fieldName;
 			  
 			  //validate column
 			  if (!fieldName) continue;
 			  if (allowedColumns.indexOf(title) >-1){
 				      var value = '';
 					  if(fieldName=='dueDate'){
 						  value = kendo.toString(row[fieldName], "dd-MMM-yyyy") || '';
 					  }else{
 						  value =row[fieldName] || '';
 					  }
 				  value = value.toString().replace(/"/g, '""').replace(/#/g, "");
 				  //csv += '"' + value + '"';
 				  rowDataInCsv +='"' + value + '"';
 				  if(i <grid.columns.length-1) {
 					  //csv += ',';
 					  rowDataInCsv+=',';
 				  }
 			  }
 		  }
 		   var temp = rowDataInCsv;
 		   if(temp.toString().replace(/"/g, '').replace(/,/g,"").length>0){
 			   csv  +=rowDataInCsv
 			   csv += '\n';
 		   }else{
 			   console.log(row);
 		   }
 	  }
   } 
 csv = 'data:text/csv;charset=utf-8,' + csv;
 anchorLink = document.createElement('a');
 anchorLink.setAttribute('href', encodeURI(csv));
 anchorLink.setAttribute('download', fileName);
 anchorLink.click();
 $('#loading').hide();

}

function popupDialogOpen() {
	$('#popupDialog').show();
  }
function popupBoxOpen() {
	$('#popupBox').show();
  }
function closePopupDialog() {
	popupGridDataSource = new kendo.data.DataSource({
	    data: [],
	    pageSize: 10
	});

	popupCandidatesGridDataSource = new kendo.data.DataSource({
	    data: [],
	    pageSize: 5
	});

    popupProjectStatusLogGridDataSource = new kendo.data.DataSource({
	    data: [],
	    pageSize: 5
	});

    popupHRRAnalyticsGridDataSource = new kendo.data.DataSource({
        data: [],
        pageSize: 5
    });

    popupCandidateLogGridDataSource = new kendo.data.DataSource({
	    data: [],
	    pageSize: 5
	});

    
    currentFuzeSiteId = "";
    currentProjectId = "";

	if($('#filesContainer').data().kendoGrid)
		$('#filesContainer').data().kendoGrid.destroy();
	$('#filesContainer').empty();
	$('#filesContainer').hide();
	$('.k-grid-pager').remove();
    $('k-grid k-widget k-display-block k-editable').remove();
	if($('#reloCandidateStatusContainer').data().kendoGrid)
		$('#reloCandidateStatusContainer').data().kendoGrid.destroy();
	$('#reloCandidateStatusContainer').empty();
    if($('#projectStatusContainer').data().kendoGrid)
         $('#projectStatusContainer').data().kendoGrid.destroy();
    $('#projectStatusContainer').empty();
    if($('#HRRAnalyticsContainer').data().kendoGrid)
      $('#HRRAnalyticsContainer').data().kendoGrid.destroy();
    $('#HRRAnalyticsContainer').empty();2
	$('#candidatesContainer').hide();
	$('#popupDialog').hide();
}
function closePopupCandidateLogDialog(){
    popupCandidateLogGridDataSource = new kendo.data.DataSource({
	    data: [],
	    pageSize: 5
	});

    currentFuzeSiteId = "";
    if($('#filesContainer').data().kendoGrid)
    $('#filesContainer').data().kendoGrid.destroy();
    $('#filesContainer').empty();
    $('#filesContainer').hide();

    $('.k-grid-pager').remove();
    $('k-grid k-widget k-display-block k-editable').remove();
	if($('#candidatesDetailedLogContainer').data().kendoGrid)
		$('#candidatesDetailedLogContainer').data().kendoGrid.destroy();
	$('#candidatesDetailedLogContainer').empty();
    $('#candidatesDetailedLogContainer').hide();
    $('#candidatesContainer').hide();
	$('#popupCandidateLogDialog').hide();
}
function closePopupBox() {
	$('#popupBox').hide();
}

function loadPopData(projectId){
	$('#popupDialog').show();
	$('#filesContainer').show();
	$('#candidatesContainer').hide();
	$('#individualRecordContainer').hide();
	if($('#filesContainer').data().kendoGrid){
		$('#filesContainer').data().kendoGrid.destroy();
		$('#filesContainer').empty();
	}
	var filesGrid = $("#filesContainer").kendoGrid({
       dataSource: popupGridDataSource,
       sortable: true,
       sort: function(e) {
           console.log("sorting is clicked!");
       },
       pageable: {
           pageSizes: true,
           change:function(e){
               console.log("grid pager clicked!");
          }
       },
       columnMenu: true,
       reorderable: false,
       resizable: true,
       columns: hrrFileUploadColumns,
       editable: "inline"
   }).data("kendoGrid");

	var toolbar = $("<span class='.k-header.k-grid-toolbar'> </span>")
	$(toolbar).appendTo($("#reportGrid .k-grid-pager"));
	
	var reqObj={};
	reqObj.view="getSPMFiles";
	reqObj.projectId=projectId;
	$.ajax({
	   url:  CONTEXT_PATH+"/uui/eapp/atoll_pg/atollTransactionTableData",
       type: "POST",
       dataType: "json",
       data:JSON.stringify(reqObj),
       contentType: "application/json",
       success: function (response) {
           if (response != null && response.length > 0) {
               
        	   popupGridDataSource.data(response);
               $("#filesContainer").data("kendoGrid").dataSource.filter([]);
           } 
           $('#loading').hide();
       },
       error: function (data) {
           $('#loading').hide();
           popupGridDataSource.data([]);
           console.log("Error occurred while fetching the data from the API.");
       }
   });
}
function loadpopIndividualRecord(fuzeSiteId){
$('#popupBox').show();
$('#filesContainer').hide();
$('#candidatesContainer').hide();
$('#individualRecordContainer').show();
var reqObj={};
	reqObj.view="getIndividualRecord";
	reqObj.fuzeSiteId=fuzeSiteId;
	$.ajax({
	   url:  CONTEXT_PATH+"/uui/eapp/atoll_pg/atollTransactionTableData",
       type: "POST",
       dataType: "json",
       data:JSON.stringify(reqObj),
       contentType: "application/json",
       success: function (response) {
           if (response != null && response.length > 0) {

              var keyValueData=[];
              var result = $.parseJSON(response);
              $.each(result, function(k, v) {
                   var action=v==="No"?"Fix":"";
                   keyValueData.push({key:k,value:v,action:action});
              });
              $("#individualRecordContainer").kendoGrid({
                dataSource: {
                data:keyValueData,
                },

                sortable: true,
                sort: function(e) {
                     console.log("sorting is clicked!");
                },
                 columnMenu: true,
                 reorderable: false,
                 resizable: true,
                 columns: [
                 {field:"key",title:"Key"},
                 {field:"value",title:"Value"},
                 {
                 "title": "Action",
                 "field": "action",

                 template: function (dataItem) {
                             if(dataItem.action==="Fix"){
                             return '<button disabled class="fixSite" type="button">Fix</button>';
                             }else{return '';}
                 }
                 }
                 ],
                 editable: "inline"
              });
              }
       },
       error: function (data) {
           $('#loading').hide();
           console.log("Error occurred while fetching the data from the API.");
       }
   });
}
function loadProjectPopData(projectId){
	$('#popupDialog').show();
	$('#filesContainer').hide();
	$('#individualRecordContainer').hide();
    $("#candidatesLogContainer").hide();
	$('#candidatesContainer').show();
   
    
    var projectStatusLogsGrid = $("#projectStatusContainer").kendoGrid({
        dataSource: popupProjectStatusLogGridDataSource,
        sort: function(e) {
            console.log("sorting is clicked!");
        },
        pageable: {
            pageSizes: true,
            change:function(e){
                console.log("grid pager clicked!");
           }
        },
        columnMenu: true,
        reorderable: false,
        resizable: true,
        columns: hrrProjectStatusLogsColumns,
        editable: "inline"
        
    }).data("kendoGrid");
   var toolbar = $("<span class='.k-header.k-grid-toolbar'> </span>")
	$(toolbar).appendTo($("#reportGrid .k-grid-pager"));

    var reqObj={};
	reqObj.view="getHRRProjectStatusLogs";
	reqObj.projectId=projectId;
	$.ajax({
	   url:  CONTEXT_PATH+"/uui/eapp/atoll_pg/atollTransactionTableData",
       type: "POST",
       dataType: "json",
       data:JSON.stringify(reqObj),
       contentType: "application/json",
       success: function (response) {
           if (response != null && response.length > 0) {
            popupProjectStatusLogGridDataSource.data(response);
           } 
           $('#loading').hide();
       },
       error: function (data) {
           $('#loading').hide();
           popupProjectStatusLogGridDataSource.data([]);
           console.log("Error occurred while fetching the data from the API.");
       }
   });

	var candidatesGrid = $("#reloCandidateStatusContainer").kendoGrid({
       dataSource: popupCandidatesGridDataSource,
       sortable: true,
       sort: function(e) {
           console.log("sorting is clicked!");
       },
       pageable: {
           pageSizes: true,
           change:function(e){
               console.log("grid pager clicked!");
          }
       },
       columnMenu: true,
       reorderable: false,
       resizable: true,
       columns: hrrCandEntryColumns,
      detailTemplate:'<div class = "taskStatusHeaders"  ><b>Candidate Detailed Logs</b></div> <span  class="container whitepage" id="candidatesDetailedLogContainer" ></span> ',
      
      detailInit: loadCandidateDetailedLogs,
       editable: "inline"
   }).data("kendoGrid");

	var toolbar = $("<span class='.k-header.k-grid-toolbar'> </span>")
	$(toolbar).appendTo($("#reportGrid .k-grid-pager"));
	
	var reqObj={};
	reqObj.view="getReloCandidateStatus";
	reqObj.projectId=projectId;
	$.ajax({
	   url:  CONTEXT_PATH+"/uui/eapp/atoll_pg/atollTransactionTableData",
       type: "POST",
       dataType: "json",
       data:JSON.stringify(reqObj),
       contentType: "application/json",
       success: function (response) {
           if (response != null && response.length > 0) {
        	   popupCandidatesGridDataSource.data(response);
           } 
           $('#loading').hide();
       },
       error: function (data) {
           $('#loading').hide();
           popupCandidatesGridDataSource.data([]);
           console.log("Error occurred while fetching the data from the API.");
       }
   });

       var HRRAnalyticsGrid = $("#HRRAnalyticsContainer").kendoGrid({
        dataSource: popupHRRAnalyticsGridDataSource,
        sortable: true,
        sort: function(e) {
            console.log("sorting is clicked!");
        },
        pageable: {
            pageSizes: true,
            change:function(e){
                console.log("grid pager clicked!");
           }
        },
        columnMenu: true,
        reorderable: false,
        resizable: true,
        columns: hrrAnalyticsColumns,
        editable: "inline"
    }).data("kendoGrid");
 
     var toolbar = $("<span class='.k-header.k-grid-toolbar'> </span>")
     $(toolbar).appendTo($("#reportGrid .k-grid-pager"));
     
     var reqObj={};
     reqObj.view="getHRRAnalytics";
     reqObj.projectId=projectId;
     $.ajax({
        url:  CONTEXT_PATH+"/uui/eapp/atoll_pg/atollTransactionTableData",
        type: "POST",
        dataType: "json",
        data:JSON.stringify(reqObj),
        contentType: "application/json",
        success: function (response) {
            if (response != null && response.length > 0) {
                popupHRRAnalyticsGridDataSource.data(response);
            } 
            $('#loading').hide();
        },
        error: function (data) {
            $('#loading').hide();
            popupHRRAnalyticsGridDataSource.data([]);
            console.log("Error occurred while fetching the data from the API.");
        }
    });

}   
function loadCandidateDetailedLogs(e){
   $('#candidatesContainer').show();
	$('#filesContainer').hide();
	$('#individualRecordContainer').hide();
       e.detailRow.find("#candidatesDetailedLogContainer").appendTo(e.detailCell).kendoGrid({
        dataSource: popupCandidateLogGridDataSource,
        sortable: true,
        sort: function(e) {
            console.log("sorting is clicked!");
        },
        pageable: {
            pageSizes: true,
            change:function(e){
                console.log("grid pager clicked!");
           }
        },
        columnMenu: true,
        reorderable: false,
        resizable: true,
        columns: hrrCandLogColumns,
        editable: "inline"
    }).data("kendoGrid");

     var toolbar = $("<span class='.k-header.k-grid-toolbar'> </span>")
     $(toolbar).appendTo($("#reportGrid .k-grid-pager"));
     
     var reqObj={};
     reqObj.view="getHRRCandidateDetailedLogs";
     reqObj.projectId=currentProjectId;
     reqObj.fuzeSiteId=e.data.candFuzeSiteId.toString();
     
     $.ajax({
        url:  CONTEXT_PATH+"/uui/eapp/atoll_pg/atollTransactionTableData",
        type: "POST",
        dataType: "json",
        data:JSON.stringify(reqObj),
        contentType: "application/json",
        success: function (response) {
            if (response != null && response.length > 0) {
                popupCandidateLogGridDataSource.data(response);
            } 
            $('#loading').hide();
        },
        error: function (data) {
            $('#loading').hide();
            popupCandidateLogGridDataSource.data([]);
            console.log("Error occurred while fetching the data from the API.");
        }
    });
}

function createPieChart() {
	var tableName=$('#atoll-select').val();
	var width=600;
    if(tableName=='atoll_eqp_bundling_transaction'){
    	width=400;
    }
    $('#statusPieChart').empty();
    $("#statusPieChart").kendoChart({
        chartArea: {
            width: width,
            background: ""
        },
        legend: {
            visible: true,
            position: "right",
            labels: {
                visible: true,
                background: "transparent",
                template: "#= text # (#= value #)",
                font: "15px sans-serif"
            }
        },
        seriesDefaults: {
            labels: {
                visible: false,
                background: "transparent",
                template: "#= category #: \n #= value #%"
            }
        },
        series: [
            {
                type: "pie",
                field: "value",
                categoryField: "category",
                startAngle: 150,
                explodeField: "explode",
                highlight: {
                    border: {
                      opacity: 1,
                      width: 2,
                      color: "black"
                    }
                }
            }
        ],
        dataSource: pieChartDatasource,
        seriesClick: function (e) {
            $(e.sender.dataSource.data()).each(function (i, item) {
                if (item.category == e.dataItem.category && item.color == e.dataItem.color) {
                    if (item.explode) {
                        item.explode = false;
                    } else {
                        item.explode = true;
                    }
                } else {
                    item.explode = false;
                }
            });
            createPieChart();
        }
    });
}

function updatePieChart() {
    var pieChartData = [
        {
            category: "SUCCESS",
            value: successCount,
            color: successColor,
            explode: true
        },
        {
            category: "FAILURE",
            value: failureCount,
            color: failureColor
        },
        {
            category: "HOLD",
            value: holdCount,
            color: holdColor
        },
        {
            category: "INPROGRESS",
            value: inprogressCount,
            color: inprogressColor
        }
    ];

    pieChartDatasource.data(pieChartData);
}

function updateHrrPieChart() {
    var pieChartData = [
        {
            category: "SUCCESS",
            value: successCount,
            color: successColor,
            explode: true
        },
        {
            category: "CAND_CREATION_FAILURE",
            value: candCreationFailureCount,
            color: candCreationFailureColor
        },
        {
            category: "TRANSMITTER_COVERAGE_FAILURE",
            value: transmitterCoverageFailureCount,
            color: transmitterCoverageFailureColor
        },
        {
            category: "SITE_ANALYTICS_FAILURE",
            value: siteAnalyticsFailureCount,
            color: siteAnalyticsFailureColor
        },
        {
            category: "SPM_IMAGE_GENRATION_FAILURE",
            value: spmImageGenerationFailureCount,
            color: spmImageGenerationFailureColor
        }
    ];

    pieChartDatasource.data(pieChartData);
}

function appendStatusOptions(){
	let statusOptions = "";
	statusOptions += '<option value ="SUCCESS"> SUCCESS </option>';
	statusOptions += '<option value ="FAILURE"> FAILURE </option>';
	statusOptions += '<option value ="HOLD"> HOLD </option>';
	statusOptions += '<option value ="INPROGRESS"> INPROGRESS </option>';
    
    $("#atollStatus").html(statusOptions);

    $('#atollStatus').multiselect({
        includeSelectAllOption: true,
        enableFiltering: false,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 200,
        menuMinHeight: 200,
        noneText: 'None selected',
        placeholder: 'Status'
    });
    $('#atollStatus').multiselect('refresh');
}
function appendHrrStatusOptions(){
	let statusOptions = "";
	statusOptions += '<option value ="SUCCESS"> SUCCESS </option>';
	statusOptions += '<option value ="CAND_CREATION_FAILURE"> CAND_CREATION_FAILURE </option>';
	statusOptions += '<option value ="TRANSMITTER_COVERAGE_FAILURE"> TRANSMITTER_COVERAGE_FAILURE </option>';
	statusOptions += '<option value ="SITE_ANALYTICS_FAILURE"> SITE_ANALYTICS_FAILURE </option>';
	statusOptions += '<option value ="SPM_IMAGE_GENRATION_FAILURE"> SPM_IMAGE_GENRATION_FAILURE </option>';
    
    $("#hrrStatus").html(statusOptions);

    $('#hrrStatus').multiselect({
        includeSelectAllOption: true,
        enableFiltering: false,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 200,
        menuMinHeight: 200,
        noneText: 'None selected',
        placeholder: 'Status'
    });
    $('#hrrStatus').multiselect('refresh');
}

function resetCriteria(){
	$('#parentId').val('');
	$('#projectId').val('');
    $('#hrrAnalyticsProjectId').val('');
	$('.statusDropDown').val([]);
    $('.statusDropDown').multiselect('refresh');
    setDateToDefault();
}

function runIndividualRecord(fuzeSiteId){
	$('#individualData').show();
	var reqObj={};
    	reqObj.view="getIndividualRecord";
    	reqObj.fuzeSiteId=fuzeSiteId;
    	$.ajax({
    	   url:  CONTEXT_PATH+"/uui/eapp/atoll_pg/atollTransactionTableData",
           type: "POST",
           dataType: "json",
           data:JSON.stringify(reqObj),
           contentType: "application/json",
           success: function (response) {
               if (response != null && response.length > 0) {
                  var keyValueData=[];
                  var result = $.parseJSON(response);
                  $.each(result, function(k, v) {
                         var action=v==="No"?"Fix":"";
                         keyValueData.push({key:k,value:v,action:action});
                  });
                  $("#individualData").kendoGrid({
                     dataSource: {
                     data:keyValueData,
                  },
                  sortable: true,
                  sort: function(e) {
                       console.log("sorting is clicked!");
                  },
                  columnMenu: true,
                  reorderable: false,
                  resizable: true,
                  columns: [
                           {field:"key",title:"Key"},
                           {field:"value",title:"Value"},
                           {
                           "title": "Action",
                            "field": "action",
                            template: function (dataItem) {
                                     if(dataItem.action==="Fix"){
                                        return '<button class="fixSite" type="button">Fix</button>';
                                     }else{return '';}
                            }
                            }
                            ],
                  editable: "inline"
                  });
                  }
           },
           error: function (data) {
               $('#loading').hide();
               console.log("Error occurred while fetching the data from the API.");
           }
       });
}

function searchReportData(){
	$('#loading').show();
	var gridColumns;
    var tableName=$('#atoll-select').val();
    var view;
    var filterCriteria={};
    if(tableName=='atoll_eqp_bundling_transaction'){
    	filterCriteria.parentIds=processIds('parentId');
    	filterCriteria.status=processStatus('atollStatus');
    	filterCriteria.projectIds=[];
    	filterCriteria.applicationIds=[];
    	gridColumns=atollEqpBunColumns;
    	view="getAtollEquipmentBundlingTransactionList";
    }else if(tableName=='hrr_status'){
    	filterCriteria.parentIds=[];
    	filterCriteria.projectIds=processIds('projectId');
    	filterCriteria.applicationIds=processIds('applicationId');
    	filterCriteria.status=processStatus('hrrStatus');
    	gridColumns=hrrTaskStatusColumns;
    	view="getHRRTaskStatus";
    }else if(tableName=='hrr_analytics'){
        $('.hrrAnalyticsCiteria').show();
        $('.atollEQBCiteria').hide();
        $('.hrrStatusCiteria').hide();
        $('.dataAnalyticsCiteria').hide();
        filterCriteria.projectId=$('#hrrAnalyticsProjectId').val();
        gridColumns=hrrAnalyticsColumns;
        view="getHRRAnalytics";
    }else if(tableName=='data_analytics'){
        $('.dataAnalyticsCiteria').show();
        $('.atollEQBCiteria').hide();
        $('.hrrStatusCiteria').hide();
        $('.hrrAnalyticsCiteria').hide();
        gridColumns=dataAnalyticsColumns;
        view="getDataAnalytics";
    }
    if(tableName=='atoll_eqp_bundling_transaction' ||tableName=='hrr_status'){
        if (document.querySelector('#startDate') && document.querySelector('#startDate').value) {
            filterCriteria.startDate = document.querySelector('#startDate').value;
        }
        if (document.querySelector('#endDate') && document.querySelector('#endDate').value) {
            filterCriteria.endDate = document.querySelector('#endDate').value;
        }
    }
    $('#reportGrid').data().kendoGrid.destroy();
	loadReportData(gridColumns,view,filterCriteria, false);
}

function processIds(id){
	var val=$('#'+id).val();
	var temp = new Array();
	if(val && val!=null && val.trim()!='')
		temp = val.split(",");
	return temp;
}
function processStatus(id){
	 if (document.querySelector('#'+id) && document.querySelector('#'+id).value) {
	        var status = $('#'+id).val().toString();
	        var temp = new Array();
	    	temp = status.split(",");
	    	return temp;
	 }else{
		 return new Array();
	 }
}
function addEmptyFilterCriteria(){
	 var filterCriteria={};
	 filterCriteria.projectIds=[];
	 filterCriteria.applicationIds=[];
	 filterCriteria.status=[];
	 filterCriteria.parentIds=[];
	 filterCriteria.status=[];
     filterCriteria.projectId=0;
	 if (document.querySelector('#startDate') && document.querySelector('#startDate').value) {
		 filterCriteria.startDate = document.querySelector('#startDate').value;
	 }
	 if (document.querySelector('#endDate') && document.querySelector('#endDate').value) {
	     filterCriteria.endDate = document.querySelector('#endDate').value;
	 }
	 return filterCriteria;
}
function setDateToDefault(){
	var d = new Date();
	 d.setDate(d.getDate() - 29);
	 var e =new Date();
   document.querySelector('#startDate').value = d.toShortFormat();
   document.querySelector('#endDate').value = e.toShortFormat();
}
Date.prototype.toShortFormat = function() {

    const monthNames = ["Jan", "Feb", "Mar", "Apr",
                        "May", "Jun", "Jul", "Aug",
                        "Sep", "Oct", "Nov", "Dec"];
    
    const day = this.getDate();
    
    const monthIndex = this.getMonth();
    const monthName = monthNames[monthIndex];
    
    const year = this.getFullYear();
    
    return `${day}-${monthName}-${year}`;  
}