$(document).ready(function () {
	fetchTaskDetails(); 
});

function getURLParameter(name) {
	let parameters = new URLSearchParams(window.location.search);
	return parameters.get(name);
}

function fetchTaskDetails(){
	$.ajax({
	      type: 'GET',
	      async: false,
	      url: fetchUteTaskBySiteRecordIdUrl+getURLParameter("siteRecordId"),
	      dataType: "json",
	      contentType: 'application/json; charset=UTF-8',
		  cache: false,
	      headers: {
	          'Accept': 'application/json',
	          'Content-Type': 'application/json'
	      },
	      
	      success: function (data) {
	       $("#taskData tbody").empty();
           if((data && data.length>0)){
             $.each(data, function(i,row){
            	 externalTaskId = data[i].externalTaskId;
           	  $("#taskData tbody").append("<tr>" +
           	  		"<td>"+row['siteRecordId']+"</td>" +
           	  		 "<td>"+row['projectId']+"</td>" +
           	  		 "<td>"+row['siteName']+"</td>" +
           	  		 "<td>"+row['txId']+"</td>" +
           	  		 "<td>"+row['band']+"</td>" +
           	  		 "<td>"+row['powerLimit']+"</td>" +
           	  		 "<td>"+row['psdValue']+"</td>" +
           	  		 "<td>"+row['nonPsdValue']+"</td>" +
           	  		 "<td>"+row['marketName']+"</td>" +
           	  		 "<td>"+row['txRecordId']+"</td>" +
           	  		 "</tr>");
           	});
           }
	      }
	       
	 });
}

function taskCompleted(){
	$.ajax({
		type: 'GET',
		async: false,	
		url: fccPowerCheckUTETaskCompleteUrl+externalTaskId,
		dataType: 'json',
		contentType: 'application/json; charset=UTF-8',
		cache: false,
		//data: JSON.stringify(sectorCarrirEndPayload),
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function (data) {
			
			successAlert('Success', 'Task Completed Successfully');

		},			
		error: function (data) {
			
			errorAlert('error', 'Task Completed Failed');
		}
		});

}

function taskRejected(){
	$.ajax({
		type: 'GET',
		async: false,	
		url: fccPowerCheckUTETaskRejectUrl+externalTaskId,
		dataType: 'json',
		contentType: 'application/json; charset=UTF-8',
		cache: false,
		headers: {
			'Accept': 'application/json, text/plain, */*',
			'Content-Type': 'application/json'
		},
		success: function (data) {
			
			successAlert('Success', 'Task Rejected Successfully');

		},
	
		error: function (data) {
			errorAlert('error', 'Task RejectedFailed');
		}
		});

}

