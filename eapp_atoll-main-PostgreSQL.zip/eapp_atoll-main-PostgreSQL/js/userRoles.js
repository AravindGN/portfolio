$(document).ready(function(){

	var dirtyRows = [];

	function prepareGetData(jsonObj){
		$('#userName').html(vzId);
		$('#ftlLoginTable tbody').empty()
		var mrktHtml = '';
		$('#invaliduser').hide();
		$('#containerroles').show();
		var userRoles = jsonObj.atollUserRoles;
		var urLen = userRoles.length;
		for(var i=0; i< urLen; i++){
			var userRole = userRoles[i];

			var readChk = userRole.read ?'checked':''; 
			var readWrtChk = userRole.readWrite ?'checked':''; 
			mrktHtml += '<tr id="vzidRow'+ (i + 1) +'">'
			+'<td class="text-center"></td>'
			+'<td id="vzidMarket'+ (i + 1) +'">'+ userRole.market +'</td>'
			+'<td class="text-center"><input class="readcheck" vz-data="read" id="vzidRead'+ (i + 1) +'" type="checkbox" '+ readChk +' data-readchkid="'+ (i+1) +'" /></td>'
			+'<td class="text-center"><input class="writecheck" vz-data="readWrite" id="vzidReadWrite'+ (i + 1) +'" type="checkbox" '+ readWrtChk +'  data-writechkid="'+ (i+1) +'" /></td>'
			+'</tr>'
		}
		$('#ftlLoginTable tbody').append(mrktHtml);
	}

	$('body').on('change', 'input[type="checkbox"]',  function() {
		var checkborow = $(this).data('readchkid');
		if($.type(checkborow) == 'undefined') {
			checkborow = $(this).data('writechkid');
			if($('#vzidReadWrite'+checkborow).is(":checked")) {
				$('#vzidRead'+checkborow).removeAttr("checked");
			}
		}else {
			if($('#vzidRead'+checkborow).is(":checked")) {
				$('#vzidReadWrite'+checkborow).removeAttr("checked");
			}
		}
		dirtyRows.push(checkborow);
	});

	function prepareUpdatedata(){
		var jsonObj = []
		var obj = {
				"atollUserRoles": [],
				"firstName": null,
				"lastName": null,
				"message": null,
				"result": "Success",
				"vzid": vzId
		}
		var changedObj
		var marketName = '';
		var path = '';
		var vzRead = false;
		var vzReadWrite = false;
		var rowsLen = $('#ftlLoginTable tbody tr').length;
		debugger;
		for(var i=0; i<dirtyRows.length; i++){
			path = $('#ftlLoginTable tbody tr:nth-child('+ (dirtyRows[i])+')');
			marketName = path.find('#vzidMarket' + dirtyRows[i]).text();
			vzRead = path.find('#vzidRead' + dirtyRows[i]).is(':checked');
			vzReadWrite = path.find('#vzidReadWrite' + dirtyRows[i]).is(':checked');

			//if(vzRead || vzReadWrite) {
				objRole = {}
				objRole.market = marketName;
				objRole.read = vzRead;
				objRole.readWrite = vzReadWrite;
				obj.atollUserRoles.push(objRole);
			//}
		}
		return obj;
	}

	$('#userLoginupdate').on('click', function(){
		if(dirtyRows.length == 0) {
			$("#NoRolesSelected").fadeIn(1000, function() {
				setTimeout(function() {
					$("#NoRolesSelected").fadeOut(1000);
				}, 5000);
			});
		} else {
			var jdata = prepareUpdatedata();
			var strObjsAry = JSON.stringify(jdata);
			dirtyRows = [];
			$.ajax({
				type:'POST',
				url: updateRolesURL,
				contentType:'application/json',
				data:strObjsAry,
				success: function(data){
					if(data.result == "failure"){
						 $(window).scrollTop(0);
						$("#updateRolesFailedAlert").fadeIn(500, function () {
							setTimeout(function () {
								$("#updateRolesFailedAlert").fadeOut(500);
							}, 5000);
						});
					} else {
						getRolesOnLoad();
						 $(window).scrollTop(0);
						$("#updateSuccessAlert").fadeIn(1000, function() {
							setTimeout(function() {
								$("#updateSuccessAlert").fadeOut(1000);
							}, 5000);
						});
					}
				},
				error: function(){
					$("#updateRolesFailedAlert").fadeIn(500, function () {
						setTimeout(function () {
							$("#updateRolesFailedAlert").fadeOut(500);
						}, 5000);
					});
				}

			})
		}

	});


	function getRolesOnLoad(){
		var obj = {
				"atollUserRoles": [
					{
						"market": "",
						"read": true,
						"readWrite": true
					}
					],
					"firstName": null,
					"lastName": null,
					"message": "",
					"result": "",
					"vzid": vzId
		}

		$.ajax({
			type:'POST',
			url: getRolesURL,
			contentType:'application/json',
			data:JSON.stringify(obj),
			success: function(data){
				if(data.result == "failure"){
					if(data.message == 'INVALID USER') {
						$('#invaliduser').show();
						$('#containerroles').hide();
					} else {
						$("#getRolesFailedAlert").fadeIn(500, function () {
							setTimeout(function () {
								$("#getRolesFailedAlert").fadeOut(500);
							}, 5000);
						});
					}
				} else {
					$('#containerroles').show();
					prepareGetData(data);
				}

			},
			error: function(){
				$("#getRolesFailedAlert").fadeIn(500, function () {
					setTimeout(function () {
						$("#getRolesFailedAlert").fadeOut(500);
					}, 5000);
				});
			}
		})
	}
	getRolesOnLoad();

});