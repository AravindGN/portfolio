var isParamPresentInUrl = false;
var schemaSiteVersionDataMap = {};
var sitesHistoryData = [];
var atollSiteHistoryData = {};
var currentHistoryTabSelected = "Sites";
var historyRequestStatusData = [];
var totalPages=1000;
var sitePages=0;
var transmittersPages=0;
var ltePages=0;
var gnrPages=0;
var repeatersPages=0; 
var  featureFlag=Object.keys(featureToggleMap).includes("NTSCD-19298") && featureToggleMap['NTSCD-19298'];

const gridTabs = ["Sites","Transmitters","Cells LTE","Cells NR","Repeaters","History Request Status"]

const blankData = {
    "cellsLte" : [ ],
    "cellsNr" : [ ],
    "transmitters" : [ ],
    "sites" : [ ],
    "repeaters" : [ ]
}

const downloadHistoryRequestDataTemplate = (requestItem) => {
    let siteName = JSON.parse(requestItem.REQUEST_PAYLOAD).siteName;
    return requestItem.COMPLETED_DATE_TIME && requestItem.REQUEST_STATUS=="COMPLETED"?
        "<span class='fa fa-download' style='cursor:pointer' onClick='downloadExcelReportById("+requestItem.REQUEST_ID+",\""+siteName+"\")'></span>": "";
}

const downloadExcelReportById = (requestId, siteName) => {
    $.ajax({
        url: getAtollSchemaData.split("/",4).join("/")+"/atollSiteHistory/downloadHistoryReportByRequestId/"+requestId,
        async: false,
        dataType: 'json',
        type: "POST",
        contentType: 'application/json',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        success: function (data) {
            const blob = base64toBlob(data[0].RESPONSE_DATA);
            const link = document.createElement("a");
            link.href = window.URL.createObjectURL(blob);
            link.download = getAtollSiteHistoryReportName(siteName);
            link.click();
            showSuccess("Excel report downloaded");
        },
        error: function(){
            atollSiteHistoryData = blankData;
            $("#asyncRequestStatusLabel").click();
            showError("Error while fetching history data request status");
        }
    })
}

const fetchSiteVersionsListForInitialLoad = (selectedSiteVersions) => {
    $.ajax({
        async: false,
        url: fetchSiteVersionFromRfdsUrl,
        dataType: 'json',
        data: JSON.stringify([localStorage.getItem("fuzeSiteId").replace(/"/g,"")]),
        type: "POST",
        contentType: 'application/json; charset=UTF-8',
        headers: {
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json'
        },
        success: function (data) {
            if(data && data.length && data[0] && data[0].siteRecords){
                let siteVersions = Object.values(data[0].siteRecords);
                $("#commonSiteManagmentSchemaSearchVersionList").multiselect("destroy");
                siteVersions.forEach(versionRecord => {
                    let versionName = versionRecord.substring(0, versionRecord.indexOf("(")).trim();
                    if(selectedSiteVersions.includes(versionName)) $("#commonSiteManagmentSchemaSearchVersionList").append("<option selected>"+versionRecord+"</option>");
                    else $("#commonSiteManagmentSchemaSearchVersionList").append("<option>"+versionRecord+"</option>");
                })
                $("#commonSiteManagmentSchemaSearchVersionList").multiselect({
                    includeSelectAllOption: true,
                    enableFiltering: true,
                    enableCaseInsensitiveFiltering: true,
                    buttonClass: 'btn btn-default whitebg btn-sm',
                    numberDisplayed: 1,
                }); 
                onCommonSearchClick('commonSiteManagmentSchemaSearch');
            }
        },
        error: function (data) {
            showError('Warning', 'Failed to load site version data!');
        }
    })
}

const fetchSiteNameAndSiteVersions = (siteName, atollSchema, siteVersions) => {
    $.ajax({
        url: CONTEXT_PATH + "/uui/eapp/atoll_pg/siteAutocomplete"+ '?query=' + siteName + '&atollSchema=' + atollSchema,
        dataType: 'json',
        type: "GET",
        async: false,
        success: function(data) {
        	$('#commonSiteManagmentSchemaSearchSiteName').val(data.data[0].VZ_SITE_NAME);
            fetchSiteVersionsListForInitialLoad(siteVersions);
        },
        error: function(error) {
            showError("failed to load sitename autocomplete")
        }
    });
}

const checkAndPopulateSiteNameAndVersion = (schemaName, siteName, siteVersions) => {
    fetchSiteNameAndSiteVersions(siteName, schemaName, siteVersions);
}

const checkAndPopulateAutoFields = () => {
    if(window.location.href.includes("?")){
        let schemaName = localStorage.getItem("atollSchema").replace(/"/g,"");
        let siteName = localStorage.getItem("fuzeSiteId").replace(/"/g,"");
        let siteVersions = localStorage.getItem("siteVersion");
        try{
            siteVersions = JSON.parse(siteVersions);
        }
        catch(err){};
        $("#commonSiteManagmentSchemaSearchSchemalist").val(schemaName).multiselect("refresh");
        checkAndPopulateSiteNameAndVersion(schemaName, siteName, siteVersions);
    }
}

const getHistoryDataPayload = () => {
    return ({
        siteRecordIds: $("#commonSiteManagmentSchemaSearchVersionList").val()?.map(version => version.split("(")[1].replace(")","").trim()),
        market: $("#commonSiteManagmentSchemaSearchSchemalist").val(),
        startDate: $("#atollHistoryStartDate").val(),
        endDate: $("#atollHistoryEndDate").val(),
        siteName: $('#commonSiteManagmentSchemaSearchSiteName').val(),
        fuzeSiteId : (localStorage.getItem("fuzeSiteId")==null || localStorage.getItem("fuzeSiteId")=="undefined")?0:localStorage.getItem("fuzeSiteId").replace(/"/g,""),
        isAllSelected: localStorage.getItem("fetchedSiteVersionsLength") == $("#commonSiteManagmentSchemaSearchVersionList").val()?.map(version => version.split("(")[1].replace(")","").trim()).length,
        pageNum: (localStorage.getItem("currentPage")==null || localStorage.getItem("currentPage")=="undefined") ?0:localStorage.getItem("currentPage"), //.replace(/"/g,""),
        pageSize:(localStorage.getItem("currentPageSize")==null || localStorage.getItem("currentPageSize")=="undefined") ?50:localStorage.getItem("currentPageSize"), //.replace(/"/g,""),        
        userId: VZID
    });
}

const formatDateDefault = (givenDate) => {
    var newDate = new Date(givenDate || new Date());

    var sMonth = lpad(newDate.getMonth() + 1,2);
    var sDay = lpad(newDate.getDate(),2);
    var sYear = lpad(newDate.getFullYear(),4);
    return sYear+"-"+sMonth+"-"+sDay;
}

const validateAndUpdateHistoryDate = (ele) => {
	let startDate = $("#atollHistoryStartDate").val();
	let endDate = $("#atollHistoryEndDate").val();
    if(startDate>endDate){
        showError("Start date should be less than end date");
    }
	if(startDate && parseInt(startDate.split("-")[0])>9999){
		$("#atollHistoryStartDate").val("");
        showError("Invalid date");
	}
	if(endDate && parseInt(endDate.split("-")[0])>9999){
		$("#atollHistoryEndDate").val("");
        showError("Invalid date");
	}
    setTimeout(() => hideProgress(), 8000);
}

const base64toBlob = (base64, type) => {
    const binary = window.atob(base64);
    const len = binary.length;
    const bytes = new Uint8Array(len);
    for(let i=0;i<len;i++) bytes[i] = binary.charCodeAt(i);
    return new Blob([bytes]);
}

const showSuccess = (message) => {
    hideProgress();
    $("#messageBannerPlaceHolder").css("visibility", "visible");
    $("#messageBannerPlaceHolder").css("background-color", "green");
    $("#messageBannerTextLabel").html(message);
    $("#messageBannerTextLabel").css("color", "white");
    setTimeout(() => hideProgress(), 5000);
}

const showError = (message) => {
    hideProgress();
    $("#messageBannerPlaceHolder").css("visibility", "visible");
    $("#messageBannerPlaceHolder").css("background-color", "orange");
    $("#messageBannerTextLabel").html(message);
    $("#messageBannerTextLabel").css("color", "white");
}

const showProgress = (message) => {
    $("#messageBannerPlaceHolder").css("visibility", "visible");
    $("#messageBannerPlaceHolder").css("background-color", "grey");
    $("#messageBannerTextLabel").html(message);
    $("#messageBannerTextLabel").css("color", "white");
    $("#progressGif").css("display", "inline");
}

const hideProgress = () => {
    $("#messageBannerPlaceHolder").css("visibility", "hidden");
    $("#messageBannerPlaceHolder").css("background-color", "white");
    $("#messageBannerTextLabel").html("");
    $("#messageBannerTextLabel").css("color", "black");
    $("#progressGif").css("display", "none");
}

const lpad = (value, places) => {
    if(!value) value = "";
    else value = new String(value);
    while(value.length<places) value = "0"+value;
    return value;
}

const getAtollSiteHistoryReportName = (siteName) => {
    if(!siteName) siteName = $("#commonSiteManagmentSchemaSearchSiteName").val();
    let date = new Date();
    return "AtollSiteHistory_" 
        + siteName.replaceAll(/^\W/g,'')
        + "_"
        + lpad(date.getMonth(),2)
        + lpad(date.getDay(),2)
        + lpad(date.getFullYear(),4)
        + "_"
        + lpad(date.getHours(),2)
        + lpad(date.getMinutes(),2)
        + lpad(date.getSeconds(),2)
        + ".xlsx";
}

const exportHistoryGridDataToExcel = () => {
    let atollSiteHistoryRequestPayload = getHistoryDataPayload();
    if(!atollSiteHistoryRequestPayloadValid(atollSiteHistoryRequestPayload)){
        return showError("Please select the values from above dropdown");
    }
    showProgress("Submitting request for excel report . . . ");
    $.ajax({
        url: getAtollSchemaData.split("/",4).join("/")+"/atollSiteHistory/submitSiteHistoryExcelRequest",
        data: JSON.stringify(atollSiteHistoryRequestPayload),
        type: "POST",
        contentType: 'application/json',
        success: function (data) {
            showSuccess("Excel report request submitted. Check status in \"History Request Status Tab\"");
        },
        error: function(error){
            showError("Error while submitting excel report request: "+error);
        }
    })
}

const atollSiteHistoryRequestPayloadValid = (atollSiteHistoryRequestPayload) => {
    return atollSiteHistoryRequestPayload.siteRecordIds && atollSiteHistoryRequestPayload.market;
}

const fetchAtollSiteHistoryData = () => {
    let atollSiteHistoryRequestPayload = getHistoryDataPayload();
    if(!atollSiteHistoryRequestPayloadValid(atollSiteHistoryRequestPayload)){
        return showError("Please select the values from above dropdown");
    }
    showProgress("Fetching history data . . . ");
    if(featureFlag){
        switch(currentHistoryTabSelected){
            case "Sites": 
                return fetchSiteHistoryDataAjaxCall(atollSiteHistoryRequestPayload);
            case "Transmitters": 
                return fetchTransmitterHistoryDataAjaxCall(atollSiteHistoryRequestPayload);
            case "Cells LTE": 
                return fetchCellsLTEHistoryDataAjaxCall(atollSiteHistoryRequestPayload);    
            case "Cells NR": 
                return fetchCellsNrHistoryDataAjaxCall(atollSiteHistoryRequestPayload);
            case "Repeaters":
                return fetchRepeaterHistoryDataAjaxCall(atollSiteHistoryRequestPayload);
            case "History Request Status": return refreshStatusGrid();
        }
    } 
    else
    {
        setTimeout(() => fetchAtollSiteHistoryDataAjaxCall(atollSiteHistoryRequestPayload), 1);
    }
};

const fetchSiteHistoryDataAjaxCall = (atollSiteHistoryRequestPayload) => {
    showProgress("Fetching Site history data . . . ");
    $.ajax({
        url: getAtollSchemaData.split("/",4).join("/")+"/atollSiteHistory/fetchSiteHistoryRecords",
        async: false,
        dataType: 'json',
        data: JSON.stringify(atollSiteHistoryRequestPayload),
        type: "POST",
        contentType: 'application/json',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        success: function (data) {
            atollSiteHistoryData.sites = data.sites;
            sitePages = data.noOfPages[0].sitePages;           
            updateDataGrid(currentHistoryTabSelected);
            showSuccess("Site history data fetched");
        },
        error: function(){
            atollSiteHistoryData = blankData;
            updateDataGrid(currentHistoryTabSelected);
            showError("Error while fetching history data");
        }
    })
}
const fetchTransmitterHistoryDataAjaxCall = (atollSiteHistoryRequestPayload) => {
    showProgress("Fetching Transmitter history data . . . ");
    $.ajax({
        url: getAtollSchemaData.split("/",4).join("/")+"/atollSiteHistory/fetchTransmitterHistoryRecords",
        async: false,
        dataType: 'json',
        data: JSON.stringify(atollSiteHistoryRequestPayload),
        type: "POST",
        contentType: 'application/json',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        success: function (data) {
            atollSiteHistoryData.transmitters = data.transmitters;
            transmittersPages = data.noOfPages[0].transmitterPages;
            updateDataGrid(currentHistoryTabSelected);
            showSuccess("Transmitter History data fetched");
        },
        error: function(){
            atollSiteHistoryData = blankData;
            updateDataGrid(currentHistoryTabSelected);
            showError("Error while fetching history data");
        }
    })
}
const fetchCellsLTEHistoryDataAjaxCall = (atollSiteHistoryRequestPayload) => {
    $.ajax({
        url: getAtollSchemaData.split("/",4).join("/")+"/atollSiteHistory/fetchCellLTEHistoryRecords",
        async: false,
        dataType: 'json',
        data: JSON.stringify(atollSiteHistoryRequestPayload),
        type: "POST",
        contentType: 'application/json',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        success: function (data) {
            atollSiteHistoryData.cellsLte = data.cellsLte;
            ltePages = data.noOfPages[0].ltePages;
            updateDataGrid(currentHistoryTabSelected);
            showSuccess("Cell history data fetched");
        },
        error: function(){
            atollSiteHistoryData = blankData;
            updateDataGrid(currentHistoryTabSelected);
            showError("Error while fetching history data");
        }
    })
}
const fetchCellsNrHistoryDataAjaxCall = (atollSiteHistoryRequestPayload) => {
    $.ajax({
        url: getAtollSchemaData.split("/",4).join("/")+"/atollSiteHistory/fetchCellNRHistoryRecords",
        async: false,
        dataType: 'json',
        data: JSON.stringify(atollSiteHistoryRequestPayload),
        type: "POST",
        contentType: 'application/json',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        success: function (data) {
            atollSiteHistoryData.cellsNr = data.cellsNr;
            gnrPages = data.noOfPages[0].gnrPages;
            updateDataGrid(currentHistoryTabSelected);
            showSuccess("Cell history data fetched");
        },
        error: function(){
            atollSiteHistoryData = blankData;
            updateDataGrid(currentHistoryTabSelected);
            showError("Error while fetching history data");
        }
    })
}
const fetchRepeaterHistoryDataAjaxCall = (atollSiteHistoryRequestPayload) => {
    $.ajax({
        url: getAtollSchemaData.split("/",4).join("/")+"/atollSiteHistory/fetchRepeaterHistoryRecords",
        async: false,
        dataType: 'json',
        data: JSON.stringify(atollSiteHistoryRequestPayload),
        type: "POST",
        contentType: 'application/json',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        success: function (data) {
            atollSiteHistoryData.repeaters = data.repeaters;
            repeatersPages = data.noOfPages[0].repeatersPages;
            updateDataGrid(currentHistoryTabSelected);
            showSuccess("Repeater history data fetched");
        },
        error: function(){
            atollSiteHistoryData = blankData;
            updateDataGrid(currentHistoryTabSelected);
            showError("Error while fetching history data");
        }
    })
}
const fetchAtollSiteHistoryDataAjaxCall = (atollSiteHistoryRequestPayload) => {
    $.ajax({
        url: getAtollSchemaData.split("/",4).join("/")+"/atollSiteHistory/fetchAtollSiteHistoryData",
        async: false,
        dataType: 'json',
        data: JSON.stringify(atollSiteHistoryRequestPayload),
        type: "POST",
        contentType: 'application/json',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        success: function (data) {
            atollSiteHistoryData = data;
            updateDataGrid(currentHistoryTabSelected);
            showSuccess("History data fetched");
        },
        error: function(){
            atollSiteHistoryData = blankData;
            updateDataGrid(currentHistoryTabSelected);
            showError("Error while fetching history data");
        }
    })
}

const initSelectFields = () => {
    commonSchemaSearch('commonSiteManagmentSchemaSearch');
    $("#atollHistoryStartDate").on("change", (e) => validateAndUpdateHistoryDate(e.target));
	$("#atollHistoryEndDate").on("change", (e) => validateAndUpdateHistoryDate(e.target));    
	$("#atollHistoryStartDate").val(formatDateDefault(getDateMinusDays(14)));
	$("#atollHistoryEndDate").val(formatDateDefault());
    $("#searchBtn").css("min-height", "35px");
    $("#resetBtn").css("min-height", "35px");
}

const getDateMinusDays = (numberOfDays) => {
    return new Date()-(24*60*60*1000 * numberOfDays);
}

const clearAtollSiteHistoryDropdowns = () => {
    $("#commonSiteManagmentSchemaSearchSchemalist").val("None Selected").multiselect("refresh");
    $("#commonSiteManagmentSchemaSearchSiteName").val([]);
    $("#commonSiteManagmentSchemaSearchVersionList").multiselect("deselectAll", false).multiselect("refresh");
    $("#atollHistoryStartDate").val(formatDateDefault(getDateMinusDays(14)));
	$("#atollHistoryEndDate").val(formatDateDefault());
}

const fetchRequestStatusLogsOnLoad = () => {
	    fetchRequestStatusLogs(event);
};

const fetchRequestStatusLogs = (event) => {
    $.ajax({
        url: getAtollSchemaData.split("/",4).join("/")+"/atollSiteHistory/fetchRequestStatusData",
        async: false,
        dataType: 'json',
        type: "POST",
        contentType: 'application/json',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        success: function (data) {
            historyRequestStatusData = data.sort((req1, req2) => req1.REQUEST_ID>req2.REQUEST_ID?-1:1);
            $("#asyncRequestStatusLabel").click();
            refreshStatusGrid();
            showSuccess("History Data Request Status fetched");
        },
        error: function(){
            atollSiteHistoryData = blankData;
            $("#asyncRequestStatusLabel").click();
            refreshStatusGrid();
            showError("Error while fetching history data request status");
        }
    })
}

const refreshStatusGrid = () => {
    $("#siteHistoryGrid").html("");
    $("#siteHistoryGrid").kendoGrid({
        dataSource: {
            data: historyRequestStatusData,
            pageSize: 50
        },
        columns: historyRequestStatusColumns,
        sortable: true,
		filterable: true,
		groupable: false,
		reorderable: true,
        columnMenu: true,
        resizable: true,
        pageable: {
            input: true,
            numeric: false,
            refresh: true,
            pageSizes: [10, 20, 50, 100, "All"]

        },
        columnMenu: true,
        editable: false,
        noRecords: "There is no data to show"
    });
}

const refreshGrid = (data, columns) => {
    $("#siteHistoryGrid").html("");
    $("#siteHistoryGrid").kendoGrid({
        dataSource: {
            data: data,
            pageSize: 50
        },
        columns: columns,
        columnMenu: true,
        sortable: true,
		filterable: true,
		groupable: false,
		reorderable: true,
        resizable: true,
        pageable: {
            input: true,
            numeric: false,
            refresh: true,
            pageSizes: [10, 20, 50, 100, "All"]
        },
        editable: true,
        noRecords: "There is no data to show"
    });
}

const resetLocalvalues=()=>{
    console.log("Entered in reset log values");
    localStorage.setItem("currentPage",1);
    localStorage.setItem("currentPageSize",50);
    localStorage.setItem("isAllSelected",false);    
}

const refreshGridByPagination = (data, columns, pages) => {
    let isAllSelected = localStorage.getItem("isAllSelected");
    $("#siteHistoryGrid").html("");
    $("#siteHistoryGrid").kendoGrid({
        dataSource:{
        schema: {
            data: function () {
                return data;
            },
            total: function () {
                return pages*50;
            }
        },
        page:parseInt(localStorage.getItem("currentPage")),
        pageSize: 50,
        serverPaging: true
        },        
        columns: columns,
        columnMenu: true,
        sortable: true,
		filterable: true,
		groupable: false,
		reorderable: true,
        resizable: true,
        pageable: {
            input: true,
            numeric: true,
            refresh: false,
            change:function(e){
                localStorage.setItem("currentPage",this.page());
                localStorage.setItem("currentPageSize",this.pageSize());
                console.log("Pegable change...................");          
                fetchAtollSiteHistoryData();
            },
            pageSizes: [10, 20, 50, 100, "All"]            
        },
        editable: true,
        noRecords: "There is no data to show"
    });
}

const updateDataGrid = (selectedGridName) => {
    currentHistoryTabSelected = selectedGridName;
    var isAllVersionsSelected=getHistoryDataPayload().isAllSelected;
    console.log("isAllVersionsSelected==>",isAllVersionsSelected);    
    if(isAllVersionsSelected){
        switch(selectedGridName){
            case "Sites": {        
                return refreshGridByPagination(atollSiteHistoryData.sites, sitesHistoryGridColumns,sitePages)
            }
            case "Transmitters":{
                return refreshGridByPagination(atollSiteHistoryData.transmitters, transmittersHistoryGridColumns,transmittersPages);
            } 
            case "Cells LTE": {
                return refreshGridByPagination(atollSiteHistoryData.cellsLte, cellsHistoryGridColumns,ltePages);
            }
            case "Cells NR": {
                return refreshGridByPagination(atollSiteHistoryData.cellsNr, cellsHistoryGridColumns,gnrPages);
			}
            case "Repeaters": {
                return refreshGridByPagination(atollSiteHistoryData.repeaters, repeatersHistoryGridColumns,repeatersPages);
            }
            case "History Request Status": return refreshStatusGrid();
        }

    }
    else{
    switch(selectedGridName){
        case "Sites": return refreshGrid(atollSiteHistoryData.sites, sitesHistoryGridColumns)
        case "Transmitters": return refreshGrid(atollSiteHistoryData.transmitters, transmittersHistoryGridColumns)
        case "Cells LTE": return refreshGrid(atollSiteHistoryData.cellsLte, cellsHistoryGridColumns)
        case "Cells NR": return refreshGrid(atollSiteHistoryData.cellsNr, cellsHistoryGridColumns)
        case "Repeaters": return refreshGrid(atollSiteHistoryData.repeaters, repeatersHistoryGridColumns)
        case "History Request Status": return refreshStatusGrid();
        }
    }
    
}

const handleSwitchTabs = (event) => {
    if(!event.target.innerText) return;
    $(".tab-item").each((_, tabItem) => $(tabItem).attr("class", "tab-item"));
    event.target.className = "tab-item tab-item-selected";
    if(featureFlag){
        currentHistoryTabSelected= event.target.innerText;
        fetchAtollSiteHistoryData();
    }
    else{
        updateDataGrid(event.target.innerText);
    }
}

const initSwitchTabs = () => {
    $("#siteHistoryGrid").kendoGrid({
        dataSource: {
            data: [],
            pageSize: 50,            
        },
        columns: sitesHistoryGridColumns,
        columnMenu: true,
        resizable: true,
        sortable: true,
		filterable: true,
		groupable: false,
		reorderable: true,
        pageable: {
            input: true,
            numeric: false,
            pageSizes: [10, 20, 50, 100, "All"]
        },
        editable: false,
        noRecords: "There is no data to show"
    });
    $(".tab-item").click((event) => handleSwitchTabs(event));
        updateDataGrid(currentHistoryTabSelected);
}

// Initialize atollSiteHistoryData with empty arrays to prevent errors when switching tabs
atollSiteHistoryData = blankData;

$(document).ready(() => {

    try {
        var env = window.location.href.includes('canvasple') ? '-PLE' : '';
		window.initClickstream({
			"system_name": "Network Planning Platform",
			"app_name": "ATOLL" + env,
			"screen_name": "Atoll Site History",

			"showLogs": "true"
		});
	} catch (e) {
		return false;
	}

    resetLocalvalues();
    initSelectFields();
    initSwitchTabs();
    checkAndPopulateAutoFields();
})