
var versionData = []
var atollSchema = ["albuquerque","atlanta","austin","bismarck","bocaraton","boise","carolinas","centralillinois","chicago","cincinnati","cleveland","dallas","denver","desmoines","detroit","dublin","eugene","fargo","hawaii","houston","indianapolis","jacksonville","kansas","lasvegas","losangeles","louisville","milwaukee","minneapolis","montana","nashville","newenglandeast","newenglandwest","newjersey","neworleans","nymetro","nyupstate","orlando","philadelphia","phoenix","pittsburgh","portland","rockford","sacramento","saltlake","sandiego","sanfrancisco","sdakota","seattle","southcentral","spokane","stlouis","tampa","virginia","washington"]
var initialFlag = true;
var Market;
var versionDisplayColumns = [];
var siteAutoAjax;
var kendoGridManager = {
		stringFilterOperator:
		{
		contains: "Contains",
		startswith: "Starts with",
		eq: "Equal to",
		endswith: "Ends with",
		}
		}

$(document).ready(function(e){

    try {
        var env = window.location.href.includes('canvasple') ? '-PLE' : '';
		window.initClickstream({
			"system_name": "Network Planning Platform",
			"app_name": "ATOLL" + env,
			"screen_name": "RFE Report",

			"showLogs": "true"
		});
	} catch (e) {
		return false;
	}

    roles.push("BETA_USER");
       getUserSchema();
    buildVersionGrids(); 
    reloadData();
    $.widget("custom.catautocomplete", $.ui.autocomplete, {
        _create: function() {
            this._super();
            this.widget().menu( "option", "items", "> :not(.ui-autocomplete-category)" );
        },
        _renderMenu: function(ul, items) {
            var self = this;
            var current = "";
            $.each(items, function(index, item) {
                if (item.category != current) {
                    ul.append("<li class='ui-autocomplete-category'>"+item.category+"</li>");
                    current = item.category;
                }
                self._renderItemData(ul,item);
            });
        },
    });
    buildCatauto($('#siteName'));
    //buildCatautoSiteVersion($('#siteVersion'));
	$('#atollSchemaDropdown').on('change',function(e){
		$('#siteName').val('')
		$('#siteVersion').val('')
    	reloadData();
    });
	
	$('#siteName').on('change',function(e){
		buildCatautoSiteVersion($('#siteVersion'));
    });
    $('#searchBtn').click(function(e){
    	
    	reloadData();

    });
  

    if(receivedSchema && receivedSchema != ""){
        // call from map page and need to populate data
        $('#atollSchemaDropdown').val(receivedSchema).multiselect("refresh");
        $('#siteName').val(receivedSiteName);
        siteNameGlobal = receivedSiteName;
        $('#searchBtn').attr("disabled", false);
        $("#searchBtn").trigger( "click" );
    }
     $('#loading').hide();
});


function reloadData(){
	
	
	var grid = $("#versionGrid").data("kendoGrid");
	    grid.dataSource.read({
	     "market" :$('#atollSchemaDropdown').val(),
	         "siteName":$('#siteName').val(),
	         "siteVersion":$('#siteVersion').val()
	        });
	    grid.dataSource.page(1);
	}

function buildVersionGrids() {
    if($('#versionGrid').data().kendoGrid){
        $('#versionGrid').data().kendoGrid.destroy();
        $('#versionGrid').empty();
    }
  
    
    var dataSource = new kendo.data.DataSource({
        type: "data",
        transport: {
            read: {
                url: CONTEXT_PATH + '/uui/eapp/atoll_pg/rfe',
                dataType: "json",
                type: "POST"
            },
            parameterMap: function (data, type) {
                $('<div class="k-loading-mask" id="versionLoadSpin" style="width: 100%; height: 100%; top: 0px; left: 0px;"><span class="k-loading-text">Loading...</span><div class="k-loading-image"></div><div class="k-loading-color"></div></div>').appendTo('#versionGrid .k-grid-content');
                
                data["market"]= $('#atollSchemaDropdown').val();
                data["siteVersion"]=$('#siteVersion').val();
                data["siteName"]=$('#siteName').val();
                
                if (data.filter && data.filter.filters.length>0){
                	
                	for(var i=0 ;i<data.filter.filters.length;i++){
                		let filter=data.filter.filters[i];
                		
                		if(filter.field=='SITE_NAME' ){
                			data["siteName"]=filter.value;
                			data["siteNameOpr"]=filter.operator;
                		}
                		/*if(filter.field=='SITE_VERSION' ){
                			data["siteVersion"]=filter.value;
                			data["siteVersionOpr"]=filter.operator;
                		}*/
                		
                	}
                }
                
                
                return data;
          }
        },
        schema: {
            data: function (response) {
                siteVersion = response && response.data[0] && response.data[0].NAME? response.data[0].NAME : "";
                return response.data; // twitter's response is { "statuses": [ /* results  ] }
            },
            total: function (data) {
                // $('#loading').hide();
                return data.totalCount;
            }
        },
        pageSize: 50,
        serverPaging: true,
        serverFiltering: true,
        serverSorting: true
    });
    var exportFlag = false;
        $("#versionGrid").kendoGrid({
    		toolbar: [
                "excel"
            ],
            excel: {
                fileName: "RFE Report Export.csv",
                allPages: true
            },
            excelExport: function(e) {
            	 if (!exportFlag) {
                     e.sender.hideColumn('SITE_VERSION'); // index of the column you want to exclude
                     e.preventDefault();
                     exportFlag = true;
                     setTimeout(function () {
                         e.sender.saveAsExcel();
                     });
                 } else {
                     e.sender.showColumn('SITE_VERSION');
                     exportFlag = false;
                     $(".k-loading-mask").hide();
                 }
            },
        autoBind: false,
        height: 500,
        sortable: true,
		scrollable: true,
		//scrollable : scrollable.Virtual(true))
        pageable: {
            pageSizes: [10, 25, 50, 100, 150, 200, 500],
            input: false,
            numeric: false,
            messages :{}
        },
        columns: versionDisplayColumns,
        dataSource: dataSource,
        dataBound: versionDataBound,
		
        //change: versionGridChange,
        columns: [
            {
                "title": "Site Name",
                "field": "SITE_NAME",
				width: 200,
                filterable: {
                	operators: {
                        string:kendoGridManager.stringFilterOperator
                    }
                }
                
            },
			{
                "title": "Site Number",
                "field": "SITE_NUMBER",
				width: 75,
                filterable: false
            },
            {
                "title": "Site Version",
                "field": "SITE_VERSION",
				width: 75,
				filterable: {
                	operators: {
                        string:kendoGridManager.stringFilterOperator
                    }
                }
            },
			{
                "title": "Siterra Site ID",
                "field": "Siterra_Site_ID",
				width: 75,
                filterable: false
            },
			{
                "title": "Switch Name",
                "field": "SWITCH_NAME",
				width: 150,
                filterable: false
            },
			{
                "title": "Switch Number",
                "field": "SWITCH_NUMBER",
				width: 75,
                filterable: false
            },
			{
                "title": "Street Address",
                "field": "STREET_ADDRESS",
				width: 150,
                filterable: false
            },
			{
                "title": "City",
                "field": "CITY",
				width: 75,
				filterable: false
            },
			{
                "title": "State",
                "field": "STATE",
				width: 75,
				filterable: false
            },
			{
                "title": "Zip Code",
                "field": "ZIP_CODE",
				width: 75,
				filterable: false
            },
			{
                "title": "Country",
                "field": "COUNTY",
				width: 95,
				filterable: false
            },
			{
                "title": "Sector",
                "field": "SECTOR",
				width: 75,
				filterable: false
            },
			{
                "title": "Support Structure Ht (ft)",
                "field": "SUPPORT_STRUCTURE_HT_FT",
				width: 105,
				filterable: false
            },
			{
                "title": "Surveyed Elevation AMSL (ft)",
                "field": "SURVEYED_ELEVATION_AMSL_FT",
				width: 125,
				filterable: false
            },
			{
                "title": "Tower Owner",
                "field": "TOWER_OWNER",
				width: 75,
				filterable: false
            },
			{
                "title": "MSA/RSA",
                "field": "MSA_OR_RSA",
				width: 95,
				filterable: false
            },
			{
                "title": "MTA",
                "field": "MTA",
				width: 75,
				filterable: false
            },
			{
                "title": "BTA",
                "field": "BTA",
				width: 95,
				filterable: false
            },
			{
                "title": "Support Type",
                "field": "SUPPORT_TYPE",
				width: 75,
				filterable: false
            },
			{
                "title": "E-911 Latitude Degrees (NAD83)",
                "field": "E_911_LATITUDE_DEGREES_NAD83",
				width: 125,
				filterable: false
            },
			{
                "title": "E-911 Longitude Degrees (NAD83)",
                "field": "E_911_LONGITUDE_DEGREES_NAD83",
				width: 125,
				filterable: false
            },
			{
                "title": "Transmission Antenna Ports",
                "field": "TRANSMISSION_ANTENNA_PORTS",
				width: 115,
				filterable: false
            },
			{
                "title": "Reception Antenna Ports",
                "field": "RECEPTION_ANTENNA_PORTS",
				width: 105,
				filterable: false
            },
            {
                "title": "Antenna Model",
                "field": "ANTENNA_MODEL",
				width: 75,
				filterable: false
            },
			{
                "title": "Antenna Manufacturer",
                "field": "ANTENNA_MANUFACTURER",
				width: 105,
				filterable: false
            },
			{
                "title": "Antenna Name",
                "field": "ANTENNA_NAME",
				width: 75,
				filterable: false
            },
			{
                "title": "Antenna Height (in)",
                "field": "ANTENNA_HEIGHT_IN",
				width: 75,
				filterable: false
            },
			{
                "title": "Antenna Width (in)",
                "field": "ANTENNA_WIDTH_IN",
				width: 75,
				filterable: false
            },
			{
                "title": "Antenna Depth (in)",
                "field": "ANTENNA_DEPTH_IN",
				width: 75,
				filterable: false
            },
			{
                "title": "Antenna Centerline (ft)",
                "field": "ANTENNA_CENTERLINE_FT",
				width: 75,
				filterable: false
            },
			{
                "title": "Antenna H-BW (deg)",
                "field": "ANTENNA_H_BW_DEG",
				width: 75,
				filterable: false
            },
			{
                "title": "Antenna V-BW (deg)",
                "field": "ANTENNA_V_BW_DEG",
				width: 75,
				filterable: false
            },
			{
                "title": "Antenna Max Gain (dBd)",
                "field": "ANTENNA_MAX_GAIN_DBD",
				width: 105,
				filterable: false
            },
			{
                "title": "Antenna Pattern Electrical Tilt (deg)",
                "field": "ANTENNA_PATTERN_ELECTRICAL_TILT_DEG",
				width: 125,
				filterable: false
            },
			{
                "title": "Antenna Polarization",
                "field": "ANTENNA_POLARIZATION",
				width: 105,
				filterable: false
            },
			{
                "title": "Antenna Type",
                "field": "ANTENNA_TYPE",
				width: 75,
				filterable: false
            },
			{
                "title": "Mechanical Tilt (deg)",
                "field": "TILT",
				width: 75,
				filterable: false
            },
			{
                "title": "Azimuth (deg)",
                "field": "AZIMUTH_DEG",
				width: 75,
				filterable: false
            },
			{
                "title": "Technology",
                "field": "TECHNOLOGY",
				width: 75,
				filterable: false
            },
			{
                "title": "Trans-Cell Type",
                "field": "TRANS_CELL_TYPE",
				width: 105,
				filterable: false
            },
			{
                "title": "Band Class",
                "field": "BAND_CLASS",
				width: 75,
				filterable: false
            },
			{
                "title": "LTE Max Power (dBm)",
                "field": "LTE_MAX_POWER_DBM",
				width: 95,
				filterable: false
            },
			{
                "title": "CDMA Max Power (dBm)",
                "field": "CDMA_POWER",
				width: 95,
				filterable: false
            },
			{
                "title": "Transmission Losses (dB)",
                "field": "TRANSMISSION_LOSSES_DB",
				width: 75,
				filterable: false
            },
			{
                "title": "Center Channel",
                "field": "CHANNEL",
				width: 75,
				filterable: false
            },
			{
                "title": "Regulatory Power",
                "field": "REGULATORY_POWER",
				width: 75,
				filterable: false
            },
			{
                "title": "GeoPlan Structure Type",
                "field": "GEOPLAN_STRUCTURE_TYPE",
				width: 105,
				filterable: false
            },
			{
                "title": "eNodeB ID",
                "field": "ENODEB_ID",
				width: 75,
				filterable: false
            },
        ],
        filterable: {
            // mode: "row",
            operators: {},
            extra: false
        },
        filter: function (e) {
        },
        
        columnMenu: {
            columns: true
        },
	
        reorderable: true,
        resizable: true
    });
    $('#versionGrid').find(".k-grid-content").css("height", "300px");
    $('#versionGrid').find(".k-grid-content-locked").css("height", "300px");
    $("a.k-button.k-button-icontext.k-grid-excel").html('<span class="k-icon k-i-file-excel"></span> Export To CSV ');
}


var preUid, preTxUid, preCellUid;
function versionDataBound(e){
    $("#versionGrid").data('kendoGrid').select('tr:eq(0)');
    var grid = $("#versionGrid").data("kendoGrid");
    $("#versionLoadSpin").remove();
   
    var grid = e.sender;
    $("#versionGrid").find('tbody').find("[role='row']").find('td').on("click", function(e){
    	var grid = $("#versionGrid").data("kendoGrid");
        var row = $(e.target).closest("tr");
		
    });
}

function buildCatautoSiteVersion(element){
    $(element).catautocomplete({
        minLength: 0,
        delay: 600,
        source: function(request, response) {
            $(element).addClass("ui-autocomplete-loading");
            var term = request.term;
            var suggestions = [];
            runSiteVersionAutocomplete(term).then(function(results) {
                if(!results || !results.data || results.data.length == 0){
                    suggestions.push({ label: "Not Found.", value: "Not found.", category: "Site Results" });
                    siteNameGlobal = term;
                    // fuzeSiteIdGlobal = term;
                }else{
                    var obj =  _.map(results.data, function convertResult(result) {
                        return {
                            // label: result.NAME,
                            label: result.VZ_SITE_VERSION,
                            value: result.VZ_SITE_VERSION,
                            siteName: result.VZ_SITE_NAME,
                            fuzeSiteId: result.VZ_SITE_VERSION,
                            category: "Site Version Results",
                        };
                    });
                    suggestions = obj
                }
                response(_.flatten(_.filter(suggestions, Boolean)));
                $(element).removeClass("ui-autocomplete-loading");
            });
        },
        select: function(event, ui) {
            $(element).removeClass("ui-autocomplete-loading");
        }
    });
}


function displayViewManagement(view){
    var url = CONTEXT_PATH + "/uui/eapp/atoll_pg/viewFilterPopup?page=" + view;
    var height = window.innerHeight - 60;
    height = height > 520? 520 : height;
    $('#viewManagerPageIframe').css("height", height);
    $('#viewManagerPageIframe').attr('page', view);
    $('#viewManagerPageIframe').attr('src', url);
    $('#viewManagerPage').show();
    $('#alertMask').show();
}
function backToOriginPage(){
    $('#viewManagerPage').hide();
    $('#solutionSearchPage').show();
    $('#alertMask').hide();
    // update view dropdown value
    if($('#viewManagerPageIframe').attr('page') == "version"){
        getCustomTemplates("ATOLL.CARRIER.VERSION.", "fromPopup", "version");
    }else if($('#viewManagerPageIframe').attr('page') == "version"){
        getCustomTemplates("ATOLL.CARRIER.TX.", "fromPopup", "tx");
    }else{
        getCustomTemplates("ATOLL.CARRIER.CELL.", "fromPopup", "cell");
    }
}


function buildCatauto(element){
    $(element).catautocomplete({
        minLength: 2,
        delay: 600,
        source: function(request, response) {
            $(element).addClass("ui-autocomplete-loading");
            var term = request.term;
            var suggestions = [];
            runSiteAutocomplete(term).then(function(results) {
                if(!results || !results.data || results.data.length == 0){
                    suggestions.push({ label: "Not Found.", value: "Not found.", category: "Site Results" });
                    siteNameGlobal = term;
                    // fuzeSiteIdGlobal = term;
                }else{
                    var obj =  _.map(results.data, function convertResult(result) {
                        return {
                            // label: result.NAME,
                            label: "(" + result.VZ_SITE_INFO_ID + ") " + result.VZ_SITE_NAME,
                            value: result.VZ_SITE_NAME,
                            siteName: result.VZ_SITE_NAME,
                            fuzeSiteId: result.VZ_SITE_INFO_ID,
                            category: "Site Results",
                        };
                    });
                    suggestions = obj
                }
                response(_.flatten(_.filter(suggestions, Boolean)));
                $(element).removeClass("ui-autocomplete-loading");
            });
        },
        select: function(event, ui) {
            $(element).removeClass("ui-autocomplete-loading");
           // validate();
          //  siteNameGlobal = ui.item.siteName;
            // fuzeSiteIdGlobal = ui.item.fuzeSiteId;
        }
    });
}

function runSiteVersionAutocomplete(term, response) {
    if(siteAutoAjax){
        siteAutoAjax.abort();
        siteAutoAjax = null;
    }
    term = term.toUpperCase();
    siteAutoAjax =  $.get(CONTEXT_PATH + "/uui/eapp/atoll_pg/siteVersionAutocomplete", { query: term, atollSchema: $('#atollSchemaDropdown').val(),  siteName:$('#siteName').val() }).success().error(
        function handleError(error) {
            // console.error("Something went wrong with the site search", error);
            return [];
        }
    );
    return siteAutoAjax;
}

function runSiteAutocomplete(term, response) {
    if(siteAutoAjax){
        siteAutoAjax.abort();
        siteAutoAjax = null;
    }
    term = term.toUpperCase();
    siteAutoAjax =  $.get(CONTEXT_PATH + "/uui/eapp/atoll_pg/siteAutocomplete", { query: term, atollSchema: $('#atollSchemaDropdown').val() }).success().error(
        function handleError(error) {
            // console.error("Something went wrong with the site search", error);
            return [];
        }
    );
    return siteAutoAjax;
}

function getUserSchema(){
	if(roles.indexOf("BETA_USER") >= 0){
        $.each(atollSchema, function(i, v){
            $('#atollSchemaDropdown').append("<option>" + v.toUpperCase() + "</option>");
        });
        $('#atollSchemaDropdown').multiselect({
            includeSelectAllOption: true,
            enableFiltering:true,
            enableCaseInsensitiveFiltering: true,
            buttonClass: 'btn btn-default whitebg btn-sm',
            numberDisplayed: 1
        });
    }else{
        $.ajax({
            url: '/uuigui/uui/eapp/atoll_pg/getUserSchemas',
            type: 'GET',
            contentType: 'application/json',
            success: function (data) {
                data = data && data.data? data.data : [];
                $.each(data, function(i, v){
                    $('#atollSchemaDropdown').append("<option>" + v.SCHEMA + "</option>");
                });
                $('#atollSchemaDropdown').multiselect({
                    includeSelectAllOption: true,
                    enableFiltering:true,
                    enableCaseInsensitiveFiltering: true,
                    buttonClass: 'btn btn-default whitebg btn-sm',
                    numberDisplayed: 1
                });
            }
        });
    }
}
