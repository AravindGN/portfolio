var siteVersionDataProvider;
var projectnumber;
var siteId;
var unityData;
var versionValue;
var fuzesiteid;
var versionName;
/*Document Ready*/
$(document).ready(function() {
	getURLParams();
	getUnitySummaryData();
});
$(document).click(function(e) {
});

var parameters;
function getURLParameter(name) {
	parameters = new URLSearchParams(window.location.search);
	projectnumber = parameters.get('projectnumber');
	siteId = parameters.get('siteid');
	fuzesiteid = parameters.get('fuzesiteid');
	return parameters.get(name);
}

function getURLParams() {
	document.getElementById('siteName').innerHTML = getURLParameter('sitename');
	document.getElementById('siteId').innerHTML = getURLParameter('siteid');
	document.getElementById('projectName').innerHTML = getURLParameter('projectName');
	document.getElementById('projectnumber').innerHTML = getURLParameter('projectnumber');
	//document.getElementById('fuzesiteid').innerHTML = getURLParameter('fuzesiteid');
	loadAtollVersion();
}

$("#projectnumber").on('click', function() {
	if (fuzeProjectNumberUrl != null && fuzeProjectNumberUrl != undefined && fuzeProjectNumberUrl != "") {
		if (projectnumber != null && projectnumber != "") {
			document.getElementById("projectnumber").href = fuzeProjectNumberUrl + "?projectId=" + projectnumber;
		}
	}
});

var allVersions = [];

var loadAtollVersion = function() {
	$.ajax({
		url: fetchAtollVersionsUrl + "?fuzeSiteId=" + fuzesiteid,
		type: "POST",
		dataType: 'json',
		contentType: 'application/json; charset=UTF-8',
		cache: false,
		data: JSON.stringify({ fuzeSiteId: fuzesiteid }),
		success: function(data) {
			if (data.respData !== null && data.respData.length >= 0) {	
				$.each(data.respData, function(index, value) {
					var splitVal = data.respData[index].split('(');
					allVersions.push(splitVal[0]);
					$(versionDropdown).append("<option style='display:inline-block;' id='" + value + "' value='" + value + "' class='version-option'>" + value + "</option>");
				});
			}
		},
		error: function(request, status, err) {
			console.log(err, 'Something went wrong while fetching atoll version');
			showMessageBanner('error', 'Something went wrong while fetching atoll version');
		}
	});
}

var versionFlag = 0;

function validateVersion(versionName){
	versionFlag = 0;
	for( var i = 0;i < allVersions.length ; i++){
		if(allVersions[i] == versionName){
			versionFlag =1;
		}
	}
	console.log(versionFlag);
}

function getUnitySummaryData() {
	$('#loading').show();
	$.ajax({
		url: fetchiBwaveUnityDataUrl,
		type: "POST",
		dataType: 'json',
		contentType: 'application/json; charset=UTF-8',
		cache: false,
		data: JSON.stringify({ projectId: projectnumber }),
		success: function(data) {
			$('#loading').hide();
			var unity_data = [];
			unity_data.push(["Bands", "Sectors"]);
			unityData = data.unityData;
			$.each(data.unityData, function(index, val) {
				var isFound = false;
				$.each(unity_data, function(i, dVal) {
					if (dVal[0] === val.fband) {
						isFound = true;
						dVal[1] = dVal[1] + 1;
					}
				});
				if (!isFound) {
					var obj = [];
					obj.push(val.fband);
					obj.push(1);
					unity_data.push(obj);
				}
			});
			if (unity_data.length > 0) {
				var unity_output = '<table class="table table-striped table-bordered summary-table">';
				unity_output += '<tr><th colspan="3">Unity Design Summary</th></tr>';
				for (var row = 0; row < unity_data.length; row++) {
					unity_output += '<tr>';
					for (var cell = 0; cell < unity_data[row].length; cell++) {
						if (row == 0) {
							unity_output += '<th>' + unity_data[row][cell] + '</th>';
						} else {
							unity_output += '<td>' + unity_data[row][cell] + '</td>';
						}
					}
					unity_output += '</tr>';
				}
				unity_output += '</table>';
				document.getElementById('unit_summary').innerHTML = unity_output;
			}
		},
		error: function(request, status, err) {
			$('#loading').hide();
			console.log(err, 'Something went wrong while fetching iBwave unity data!');
			showMessageBanner('error', 'Something went wrong while fetching iBwave unity data!');
		}
	});
}

function getAtollSummaryData(version) {
   	    var atoll_output_table = '<table class="table table-striped table-bordered summary-table">';
			atoll_output_table += '<tr><th colspan="3">Atoll Design Summary</th></tr>';
			atoll_output_table += '<tr><th>Bands</th><th>Sectors</th></tr>';
			atoll_output_table += '<tr><td colspan="3">No data available</td></tr>';
			atoll_output_table += '</table>';
	if(version === 'None Selected'){
			document.getElementById('atoll_summary').innerHTML = atoll_output_table;
		return;
	}
	versionValue = version;
	$('#loading').show();
	$.ajax({
		url: getAtollBandDataUrl,
		type: "POST",
		dataType: 'json',
		contentType: 'application/json; charset=UTF-8',
		cache: false,
		data: JSON.stringify({
			fuzeSiteId: siteId,
			projectId: projectnumber,
			version: version.split("(")[0]

		}),
		success: function(data) {
			$('#loading').hide();
			if(data.atollData && data.atollData.length <= 0) {
			        document.getElementById('atoll_summary').innerHTML = atoll_output_table;
				    return ;
			}
			var atoll_data = [];
			atoll_data.push(["Bands", "Sectors"]);
			$.each(data.atollData, function(index, val) {
				var isFound = false;
				$.each(atoll_data, function(i, dVal) {
					if (dVal[0] === val.fband) {
						isFound = true;
						dVal[1] = dVal[1] + 1;
					}
				});
				if (!isFound) {
					var obj = [];
					obj.push(val.fband);
					obj.push(1);
					atoll_data.push(obj);
				}
			});
			if (atoll_data.length > 0) {
				var atoll_output = '<table class="table table-striped table-bordered summary-table">';
				atoll_output += '<tr><th colspan="3">Atoll Design Summary</th></tr>';
				for (var row = 0; row < atoll_data.length; row++) {
					atoll_output += '<tr>';
					for (var cell = 0; cell < atoll_data[row].length; cell++) {
						if (row == 0) {
							atoll_output += '<th>' + atoll_data[row][cell] + '</th>';
						} else {
							atoll_output += '<td>' + atoll_data[row][cell] + '</td>';
						}
					}
					atoll_output += '</tr>';
				}
				atoll_output += '</table>';
				document.getElementById('atoll_summary').innerHTML = atoll_output;
			}
		},
		error: function(request, status, err) {
			$('#loading').hide();
			console.log(err, 'Something went wrong while fetching iBwave atoll data!');
			showMessageBanner('error', 'Something went wrong while fetching iBwave atoll data!');
		}
	});
}

function showMessageBanner(level, message) {
	$('#messageBanner').show();
	$('#messageBanner').text(message);
	if (level.toLowerCase() == "info") {
		$('#messageBanner').css("background-color", "yellow");
	}
	else if (level.toLowerCase() == "warn") {
		$('#messageBanner').css("background-color", "grey");
	}
	else if (level.toLowerCase() == "error") {
		$('#messageBanner').css("background-color", "pink");
	}
	setTimeout(function() {
		$('#messageBanner').hide();
	}, 3000);
}
function newVersionPopUp() {
	document.getElementById('newVersionName').value = '';
	$('#newVersionDialog').show();
}

function updateAtollToNewRevision() {
	console.log(document.getElementById('newVersionName').value);

}
function closenewVersionDialog() {
	$('#newVersionDialog').hide();
	document.getElementById('newVersionName').value = '';
}


function successDialog() {
	$('#loading').show();
	 versionName = document.getElementById('newVersionName').value;
	validateVersion(versionName);
	if(versionFlag == 1){
		$('#loading').hide();
		return errorAlert('Error', 'Version alreay exists!');
		
	}
 	else {
		var unityDataArray = [];
		if(unityData && unityData.length >= 0) {
		 for (i = 0; i < unityData.length; i++) {
			var unityDataPayload = {
				"provider" : unityData[i].provider,
				"band" : unityData[i].band,
				"technology" : unityData[i].technology,
				"sectorId" : unityData[i].sectorID,
				"sectorNumber" : unityData[i].sectorNumber,
				"block" : unityData[i].block,
				"fband" : unityData[i].fband
			}
			unityDataArray.push(unityDataPayload);
		 }	
		}
		let payload = {
			"unityData" : unityDataArray,
			"fuzesiteid" : getURLParameter('fuzesiteid'),
			"spmProjectId" : getURLParameter('projectnumber'),
			"parentSolutionId" : getURLParameter('parentSolutionId'),
			"latitude" : getURLParameter('latitude'),
			"longitude" : getURLParameter('longitude'),
			"locationName" : getURLParameter('sitename'),
			"newSiteVersion" : versionName,
			"sourceSiteVersion":versionValue !== null && versionValue !== undefined ? versionValue.split("(")[0] : ""
		};
		if (versionName.length > 0 && versionName.trim().length > 0) {
			$.ajax({
						type : "POST",
						url : updateiBwaveUnityDetailsUrl,
						// url: fetchSiteRevisionIdsUrl,
						data : JSON.stringify(payload),
						contentType : 'application/json; charset=UTF-8',
						cache : false,
						cors : true,
						success : function(data) {
							$('#loading').hide();
							if (data.result == 'SUCCESS') {
								successAlert('Success',
										'Atoll Update Completed,Transmitters created on Site '
												+ getURLParameter('sitename'));
								$('#newVersionDialog').hide();
							} else {
								errorAlert('Error', data.error);
							}
						},
						error : function(response) {
							$('#loading').hide();
							errorAlert('Error',
									'Error occured in Creating New Version');
						}
					});
		} else {
			$('#loading').hide();
			errorAlert("Error", "Enter Valid Site Version");
		}
	}
	
}

function closesuccessDialog() {
	$('#successDialog').hide();
	document.getElementById('newVersionName').value = '';
}

$('#backButton').click(function(e) {
	var url = CONTEXT_PATH + '/uui/eapp/atoll_pg/iBwaveManagement?fuzeSiteId=' + siteId + '&tmp=' + Date.parse(new Date());
	if (siteId == '')
		url = CONTEXT_PATH + '/uui/eapp/atoll_pg/iBwaveManagement?fuzeSiteId=0&tmp=' + Date.parse(new Date());
	window.location.href = url;
});

function updateVersionPopUp() {
	console.log(versionValue);
	if (versionValue == 'None Selected' || versionValue == null) {
		errorAlert('Error', 'Please Select Version')
	}
	else {
		console.log(versionValue);
		$('#updateVersionDialog').show();
		versionConfirmation();
	}
}

function versionConfirmation() {
	var context = "All current Atoll data on siteName " + '<b>'+ getURLParameter('sitename') +'</b>'+ " and version " + '<b>'+ versionValue.split("(")[0] +'</b>'+ " will be lost.Do you wish to continue?";
	document.getElementById('updateVersionConfirmation').innerHTML = context;
}

function successDialogForUpdateVersion() {
	$('#loading').show();
	console.log(unityData);
	var unityDataArray = [];
	for (i = 0; i < unityData.length; i++) {
		var unityDataPayload = {
			"provider": unityData[i].provider,
			"band": unityData[i].band,
			"technology": unityData[i].technology,
			"sectorId": unityData[i].sectorID,
			"sectorNumber": unityData[i].sectorNumber,
			"block": unityData[i].block,
			"fband": unityData[i].fband
		}
		unityDataArray.push(unityDataPayload);
	}
	let payload = {
		"unityData": unityDataArray,
		"fuzesiteid": getURLParameter('fuzesiteid'),
		"spmProjectId": getURLParameter('projectnumber'),
		"parentSolutionId": getURLParameter('parentSolutionId'),
		"latitude": getURLParameter('latitude'),
		"longitude": getURLParameter('longitude'),
		"locationName": getURLParameter('sitename'),
		"sourceSiteVersion": versionValue.split("(")[0],
		"newSiteVersion" : versionValue.split("(")[0]
	};
	console.log(payload);
	$.ajax({
		type: "POST",
		url: updateiBwaveSiteDetailsUrl,
		data: JSON.stringify(payload),
		contentType: 'application/json; charset=UTF-8',
		cache: false,
		cors: true,
		success: function (data) {
			$('#loading').hide();
			if (data.result == 'SUCCESS') {
				successAlert('Success', 'Atoll Update Completed,Transmitters created on Site ' + getURLParameter('sitename'));
				$('#updateVersionDialog').hide();
			}
			else {
				errorAlert('Error', 'Error occured in updating Version');
			}
		},
		error: function (response) {
			$('#loading').hide();
			errorAlert('Error', 'Error occured in updating Version');

		}
	});
}
function closeUpdateVersionDialog() {
	$('#updateVersionDialog').hide();
}
