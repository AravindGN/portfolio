var selectedTransmitterInfoPanel;
var selectedCellInfoPanel;
var transTable;
var cellTable;
var siteTable;
var defaultPageSize = 8;


$(document).ready( function() {
	
	addPagination();
	loadDataIntoTransmitterGrid();
	loadDataIntoCellInfoGrid();
	loadDataIntoSiteInfoGrid();

	$(window).on('hashchange',  function (event) {
		updatePageInputbox();
		transTable.loadData(getData());
		cellTable.loadData(getData());
		siteTable.loadData(getData());
	});

	$('.pagination input').bind("enterKey",function(e){
		//console.log(this);
		gotoEnteredPage(this.name);
	});

	$('.pagination input').keyup(function(e){
		 if(e.keyCode == 13)
		 {
			 $(this).trigger("enterKey");
		 }
	 });

})

var transmitters = JSON.parse(localStorage.getItem("selectedTransmitters"));
var maxpage = Math.ceil(transmitters.length / defaultPageSize);

function getData(){
	var page  = parseInt(window.location.hash.replace('#', '')) || 1,
		limit = defaultPageSize,
		row   = (page - 1) * limit,
		count = page * limit,
		part  = [];

	for(;row < count;row++) {
		part.push(transmitters[row]);
	}
	return part;
};

function addPagination(){
	var str = "";
	str += "<label>of " + maxpage + "</label>";
	$("#pagination-top").append(str);
	$("#pagination-bottom").append(str);
}

function gotoEnteredPage(inputboxName){
	var enteredPage;
	var isChangePage = true;
	if (inputboxName.indexOf("top") != -1){ // top input box in control
		enteredPage = $("#pagination-top input").val();
		if (enteredPage > maxpage){ // entered page out of range
			enteredPage = $("#pagination-bottom input").val();
			$("#pagination-top input").val(enteredPage);
			isChangePage = false;
		}
		else{ // valid page
			$("#pagination-bottom input").val(enteredPage);
		}
	}
	else{
		enteredPage = $("#pagination-bottom input").val();
		if (enteredPage > maxpage){ // entered page out of range
			enteredPage = $("#pagination-top input").val();
			$("#pagination-bottom input").val(enteredPage);
			isChangePage = false;
		}
		else{ // valid page
			$("#pagination-top input").val(enteredPage);
		}
	}

	if (isChangePage){
		window.location.hash = "#"+enteredPage;
	}	
}


function updatePageInputbox(){
	var curPage = parseInt(window.location.hash.replace('#', ''));
	if ($("#pagination-top input").val() != curPage){
		if (curPage <= maxpage){
			$("#pagination-top input").val(curPage);
			$("#pagination-bottom input").val(curPage);
		}
		else{
			window.location.hash = "#" + $("#pagination-top input").val();
		}
	}
}	

function loadDataIntoTransmitterGrid(){
	var colHeaders = ["TX Id", "Azimuth", "Electrical Tilt", "Centerline", "Antenna Model", "Mechanical DT", "Max Power",
					  "Rx Ports", "Tx Ports", "Sector", "Radio Model"];
	var columns = [
		{data: 'transmitter_name', editor: false},
		{data: 'azimuth'},
		{data: 'electrical_tilt'},
		{data: 'antenna_centerline', editor: false},
		{data: 'antenna_model', editor: false},
		{data: 'mechanical_tilt'},
		{data: 'max_power'},
		{data: 'number_of_rx_antenna_ports'},
		{data: 'number_of_tx_antenna_ports'},
		{data: 'sector', editor: false},
		{data: 'radio_model', editor: false}
	];
	transTable = new Handsontable($("#selectedTransmitterInfoPanel")[0],{
		data: getData(),
		rowHeaders: true, 
		colHeaders: colHeaders,
		columns: columns,
		dropdownMenu: true,
		filters: true,
		width: '100%',
		stretchH: 'all',
		licenseKey:"non-commercial-and-evaluation",
		cells(row, col) {
			const cellProperties = {};
			if (row % 2 != 0) {
			  cellProperties.renderer = oddRowRenderer; 
			}
			return cellProperties;
		}
	})

}

function oddRowRenderer(instance, td, row, col, prop, value, cellProperties) {
	Handsontable.renderers.TextRenderer.apply(this, arguments);
	td.style.background = '#e8e8e8';
}


function loadDataIntoCellInfoGrid(){
	var colHeaders = ["TX Id", "Cell Id", "Band", "Band Class", "Band Info", "Band Width", "Channel Number", "Enodeb Id"];
	var columns = [
		{data: 'transmitter_name', editor: false},
		{data: 'cell_id', editor: false},
		{data: 'band', editor: false},
		{data: 'band_class', editor: false},
		{data: 'band_info', editor: false},
		{data: 'channel_bw', editor: false},
		{data: 'channel_number', editor: false},
		{data: 'enodeb_eutrancellfdd', editor: false}
	];
	cellTable = new Handsontable($("#selectedCellInfoPanel")[0],{
		data: getData(),
		rowHeaders: true, 
		colHeaders: colHeaders,
		columns: columns,
		dropdownMenu: true,
		filters: true,
		width: '100%',
		stretchH: 'all',
		licenseKey:"non-commercial-and-evaluation",
		cells(row, col) {
			const cellProperties = {};
			if (row % 2 != 0) {
			  cellProperties.renderer = oddRowRenderer; 
			}
			return cellProperties;
		}
	})
}



function loadDataIntoSiteInfoGrid(){ 
	var colHeaders = ["TX Id", "Fuze Site Id", "Site Name","Site Version", "City","Market", "Local Market", "Territory", "Site Record Id", "Technology"];
	var columns = [
		{data: 'transmitter_name', editor: false},
		{data: 'fuze_site_id', editor: false},
		{data: 'site_record_name', editor: false},
		{data: 'site_version', editor: false},
		{data: 'city', editor: false},
		{data: 'network_market', editor: false},
		{data: 'network_local_market', editor: false},
		{data: 'network_territory', editor: false},
		{data: 'site_record_id', editor: false},
		{data: 'technology', editor: false}
	];
	siteTable = new Handsontable($("#selectedSiteInfoPanel")[0],{
		data: getData(),
		rowHeaders: true, 
		colHeaders: colHeaders,
		columns: columns,
		dropdownMenu: true,
		filters: true,
		width: '100%',
		stretchH: 'all',
		licenseKey:"non-commercial-and-evaluation",
		cells(row, col) {
			const cellProperties = {};
			if (row % 2 != 0) {
			  cellProperties.renderer = oddRowRenderer; 
			}
			return cellProperties;
		}
	})
}


function saveChanges(){
	localStorage.setItem("selectedTransmitters", JSON.stringify(transmitters));
}

function lastPage(){
	window.location.hash = "#" + maxpage;
}

function firstPage(){
	window.location.hash = "#1";
}

function nextPage(){
	var curPage = parseInt(window.location.hash.replace("#", ""));
	if (curPage < maxpage){
		window.location.hash = "#"+(curPage+1);
	}	
}

function prevPage(){
	var curPage = parseInt(window.location.hash.replace("#", ""));
	if (curPage >1){
		window.location.hash = "#"+(curPage-1);
	}	
}