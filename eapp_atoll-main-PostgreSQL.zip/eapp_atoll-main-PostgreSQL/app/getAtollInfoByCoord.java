import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import com.google.gson.*;
import java.util.*;
import org.json.*;
import java.util.ArrayList;
import com.google.gson.internal.LinkedTreeMap;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.stream.Collectors;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

importCommands("com.verizon.webkit.espresso");

System.out.println("Running getAtollInfoByCoord.java");
DataSourceCriteria criteria = new DataSourceCriteria();
HashMap json = new HashMap();

DataSourceResultSet rs = null;
Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();

HashMap json = gson.fromJson(data.get("json"), HashMap.class);
String selectedGeoJson = json.get("selectedGeo").toString();
String selectedBand = json.get("selectedBand").toString();
String selectedSiteType = json.get("selectedSiteType").toString();
String selectedVersion = json.get("selectedVersion").toString();

System.out.println("selectedGeoJson:::"+selectedGeoJson);
System.out.println("selectedBand:::"+selectedBand);
System.out.println("selectedVersion:::"+selectedVersion);

String [] selectedBandArr = null;
if (selectedBand != null && !selectedBand.equals("") && selectedBand!=null){
	selectedBandArr = selectedBand.split(",");
}else{
	selectedBandArr = new String[0];
}
System.out.println("selectedBandArr:::"+selectedBandArr);
String [] selectedSiteTypeArr = null;
if (selectedSiteType != null && !selectedSiteType.equals("") && selectedSiteType!=null){
	selectedSiteTypeArr = selectedSiteType.split(",");
}else{
	selectedSiteTypeArr = new String[0];
}
System.out.println("selectedSiteTypeArr1:::"+selectedSiteTypeArr);
String [] selectedVersionArr = null;
if (selectedVersion != null && !selectedVersion.equals("") && selectedVersion!=null){
	selectedVersionArr = selectedVersion.split(",");
}else{
	selectedVersionArr = new String[0];
}
System.out.println("selectedVersionArr:::"+selectedVersionArr);
List <String> selectedBandList = new ArrayList<String>();
List <String> selectedSiteTypeList = new ArrayList<String>();
List <String> selectedVersionList = new ArrayList<String>();

for (int i=0; i<selectedBandArr.length; i++){
	selectedBandList.add(selectedBandArr[i]);
}
for (int i=0; i<selectedSiteTypeArr.length; i++){
	selectedSiteTypeList.add(selectedSiteTypeArr[i]);
}
for (int i=0; i<selectedVersionArr.length; i++){
	selectedVersionList.add(selectedVersionArr[i]);
}


criteria.put("selectedGeoJson", selectedGeoJson);
System.out.println("selectedBandList:::"+selectedBandList);
System.out.println("selectedSiteTypeList:::"+selectedSiteTypeList);
System.out.println("selectedVersionList:::"+selectedVersionList);
System.out.println("selectedBandArr.length: "+selectedBandArr.length);
String isBand = "N";
String isSite = "N";
String isVersion = "N";
	
try {
	if(selectedBandArr.length > 0) {
		criteria.put("selectedBandList", selectedBandList);
		isBand = "Y";
	} else {
		criteria.put("selectedBandList", new ArrayList<String>());
	}

	if(selectedSiteTypeArr.length > 0) {
		criteria.put("selectedSiteTypeList", selectedSiteTypeList);
		isSite = "Y";
	} else {
		criteria.put("selectedSiteTypeList", new ArrayList<String>());
	}
	
	if(selectedVersionArr.length > 0) {
		criteria.put("selectedVersionList", selectedVersionList);
		isVersion = "Y";
	} else {
		criteria.put("selectedVersionList", new ArrayList<String>());
	}
	if (isBand.equals("Y") && isSite.equals("Y") && isVersion.equals("Y")) {
		rs = DataCloud.performDynamic("atoll_pg/ds/getAtollInfoByCoordBoth", criteria);
	} else {
		rs = DataCloud.performDynamic("atoll_pg/ds/getAtollInfoByCoord", criteria);
	}
    String out = gson.toJson(rs.getRows());
    Response.ResponseBuilder builder;
    builder = Response.ok(out);
    builder.type(MediaType.APPLICATION_JSON);
    System.out.println("AtollInfo:::"+builder);
    return builder.build();
}catch (Exception e) {
	 System.out.println("getAtollInfoByCoord :"+e);
	 e.printStackTrace();
	 logger.log(Level.SEVERE, "ERROR fetching count", e);
	 return new WebApplicationException(500);
}
