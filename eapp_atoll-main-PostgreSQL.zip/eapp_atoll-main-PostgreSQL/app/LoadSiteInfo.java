import com.google.gson.Gson;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import com.google.gson.*;
importCommands("com.verizon.webkit.espresso");
Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
HashMap json = gson.fromJson(data.get("json"), HashMap.class);
Double parentSolutionId = json.get("PARENT_SOLUTION_ID");
Double spmProjectId = json.get("SPM_PROJECT_ID");
DataSourceResultSet rs;
//Long tempId = Long.parseLong(json.get("PARENT_SOLUTION_ID"));
String anyString = "%";
System.out.println(parentSolutionId + "," + spmProjectId);
DataSourceCriteria criteria = new DataSourceCriteria();

criteria.put("PARENT_SOLUTION_ID", parentSolutionId);
criteria.put("SPM_PROJECT_ID", spmProjectId);
criteria.put("ANY_STRING", anyString);
rs = DataCloud.performDynamic("atoll_pg/ds/loadSiteInfo", criteria);

/*
if (parentSolutionId != -1.0 && spmProjectId != -1.0){
    criteria.put("PARENT_SOLUTION_ID", parentSolutionId);
    criteria.put("SPM_PROJECT_ID", spmProjectId);
    rs = DataCloud.performDynamic("atoll_pg/ds/loadSiteInfo", criteria);
}
else if (parentSolutionId != -1.0){
    criteria.put("PARENT_SOLUTION_ID", parentSolutionId);
    rs = DataCloud.performDynamic("atoll_pg/ds/loadSiteInfoByParentSolId", criteria);
}else{
    criteria.put("SPM_PROJECT_ID", spmProjectId);
    rs = DataCloud.performDynamic("atoll_pg/ds/loadSiteInfoBySPMPid", criteria);
}
*/
String out = gson.toJson(rs.getRows());
String result = "{";
result += "\"data\":" + out + "}";
Response.ResponseBuilder builder;
builder = Response.ok(result);
builder.type(MediaType.APPLICATION_JSON);
return builder.build();