import com.google.gson.Gson;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import com.google.gson.*;
importCommands("com.verizon.webkit.espresso");



Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
HashMap json = gson.fromJson(data.get("json"), HashMap.class);
String txId = json.get("txId");
String schema = json.get("schema");

DataSourceCriteria criteria = new DataSourceCriteria();
criteria.put("TX_ID", txId);
criteria.put("SCHEMA", schema);
criteria.put("VZID", user.getVzId());

String rs = "SUCCESS";
try {
	DataSourceResultSet rs = DataCloud.performDynamic("atoll_pg/ds/deleteTx", criteria);
} catch(Exception e) {
	rs = e.getMessage().toString();
}
Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
return gson.toJson(rs);