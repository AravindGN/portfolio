
importCommands("com.verizon.webkit.espresso");
import com.verizon.webkit.util.UPIProperties;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.verizon.webkit.rest.apps.UserSettings;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.verizon.webkit.datacloud.Clob;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import java.util.logging.Level;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;

//String url = UPIProperties.getProperty("small_cell.getUserDetails");

Gson gson = new GsonBuilder().setPrettyPrinting().create();
String vzid = user.getVzId();
String name = data.get("name")!= null && !data.get("name").equals("undefined")? data.get("name"):"";
String userId = data.get("userId")!= null && !data.get("userId").equals("undefined")? data.get("userId"):vzid;
DataSourceCriteria criteria = new DataSourceCriteria();
DataSourceResultSet result = null;
try {
    criteria.put("name",name);
    criteria.put("vzid",userId);
    result = DataCloud.performDynamic("atoll_pg/ds/getCustomTemplates", criteria);
 } catch (Exception e) {
     logger.log(Level.SEVERE,"ERROR",e);
 }
// Render home page
return gson.toJson(result.getRows());
