import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import com.verizon.webkit.util.ExcelExportUtil;
import com.google.gson.*;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.logging.Level;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;


importCommands("com.verizon.webkit.espresso");
Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();

String firstName = "%"+data.get("firstName")+"%";
String lastName = "%"+data.get("lastName")+"%";
DataSourceResultSet rs = null;
try{
	DataSourceCriteria criteria = new DataSourceCriteria();
    criteria.put("firstName", firstName);
    criteria.put("lastName", lastName);
	rs = DataCloud.performDynamic("atoll_pg/ds/searchContract",criteria);
	return gson.toJson(rs.getRows());
}catch(Exception e){
	
}