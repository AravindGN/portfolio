import com.google.gson.Gson;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import com.google.gson.*;
importCommands("com.verizon.webkit.espresso");



Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
HashMap json = gson.fromJson(data.get("json"), HashMap.class);
String siteName = json.get("siteName");
String oldVersion = json.get("oldVersion");
//String fuzeSiteId = json.get("fuzeSiteId");
String lantitude = json.get("lantitude");
String longitude = json.get("longitude");
String siteRecordId = json.get("siteRecordId");
String newVersion = json.get("newVersion");
String schema = json.get("schema");

DataSourceCriteria criteria = new DataSourceCriteria();
criteria.put("SITE_RECORD_ID", siteRecordId);
criteria.put("NEW_VERSION", newVersion);
criteria.put("SCHEMA", schema);

String rs = "SUCCESS";
try {
	DataSourceResultSet rs = DataCloud.performDynamic("atoll_pg/ds/cloneSite", criteria);
} catch(Exception e) {
	rs = e.getMessage().toString();
}
Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
return gson.toJson(rs);