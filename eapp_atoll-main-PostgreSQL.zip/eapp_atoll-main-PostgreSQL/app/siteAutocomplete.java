import com.google.gson.Gson;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import com.google.gson.*;
import java.util.regex.Pattern;
importCommands("com.verizon.webkit.espresso");

Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
String atollSchema = data.get("atollSchema");
String out = "";
String reg = "[0-9]+";
int fuzeSiteId = 0;
String query =null;
if(atollSchema != null && !atollSchema.isEmpty()) {
	DataSourceCriteria criteria = new DataSourceCriteria();
	try {
		
		logger.info("QUERY***********"+data.get("query"));
		
		if(Pattern.matches(reg, data.get("query"))) {
			fuzeSiteId =Integer.parseInt(data.get("query"));
			criteria.put("FUZE_SITE_ID",fuzeSiteId );
		}else {
			 query = "%" + data.get("query") + "%";
			criteria.put("SITE_NAME", query);
		   
		}
		criteria.put("SCHEMA", atollSchema);
		
		DataSourceResultSet rs = DataCloud.performDynamic("atoll_pg/ds/siteAutocomplete", criteria);
		
		out = gson.toJson(rs.getRows());
	} catch(NumberFormatException e) {
		out = e.getMessage().toString();
		logger.info("NumberFormatException***********"+e.getMessage().toString());
		// is not a number move on
	}catch(Exception e) {
		out = e.getMessage().toString();
		logger.info("Exception***********"+e.getMessage().toString());
		
	}
	
}
String result = "{";
result += "\"data\":" + out + "}";
Response.ResponseBuilder builder;
builder = Response.ok(result);
builder.type(MediaType.APPLICATION_JSON);
return builder.build();
