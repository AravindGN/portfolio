import com.verizon.webkit.util.UPIProperties;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.WebApplicationException;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultColumnTypeEnum;
import com.verizon.webkit.datacloud.DataSourceResultFilter;
import com.verizon.webkit.datacloud.DataSourceResultMetaData;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import java.util.logging.Level;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

importCommands("com.verizon.webkit.espresso");

logger.info("******** Reset ATOLL USER PWD ********");



//alter user ABCD account unlock;
//alter user ABCD identified by ABCD123#A;

String cmd = data.get("cmd");
String newpwd = data.get("newpwd");
String vzid = user.getVzId();
//HashMap json = new HashMap();
//json.put("vzId",vzid);
data.put("VZID", vzid);


DataSourceResultSet result = null;
DataSourceCriteria criteria = new DataSourceCriteria();
criteria.put("VZID", vzid);
criteria.put("NPWD", newpwd);

    if("resetpwd".equals(cmd)){
        if(vzid!=null && vzid.length()>3 && newpwd!=null && newpwd.length()>7){
            
            
            
            String DB_URL = "jdbc:oracle:thin:@txslatollsd2v.nss.vzwnet.com:1521:atolprd";
    		String USER = "forsk_admin";
    		String PASS = "!Ug420#r";
    		
    		String q1="alter user "+vzid+" account unlock";
    		String q2="alter user "+vzid+" identified by "+newpwd;
    		
    		Connection conn=null;
    		Statement stmt=null;
    		  try {
    			  conn = DriverManager.getConnection(DB_URL, USER, PASS);
    			  stmt = conn.createStatement();
    			  int num =	  stmt.executeUpdate(q1);
    			  logger.info("atoll account unlock done for "+vzid);
    			  data.put("msg","Unlock done");
    			  num =	  stmt.executeUpdate(q2);
    			  logger.info("atoll Pwd reset done for "+vzid);
    			  data.put("msg","Unlock done, Reset password done.");
    		  }catch (Exception e) {
    		         e.printStackTrace();
    		  }finally {
    			  if(conn!=null)
    				try {
    					conn.close();
    				} catch (Exception e) {
    					// TODO Auto-generated catch block
    					e.printStackTrace();
    				}
    		  }
            
            
            
            
            
            
            
        }else{
            data.put("msg","New password is not valid (minimum 8 char)");
        }
    	
    }




renderTemplate("atoll_pg/ftl/setpwd.html", data);