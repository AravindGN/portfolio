importCommands("com.verizon.webkit.espresso");
import com.verizon.webkit.util.UPIProperties;
importFile("planning_common/app/featureToggle.java");
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.verizon.webkit.rest.apps.UserSettings;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.verizon.webkit.datacloud.Clob;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import java.util.logging.Level;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import javax.ws.rs.WebApplicationException;
//importFile("small_cell/app/user/retrieve_user_details.java");
importFile("inbuilding2_pg/app/user/retrieve_user_details.java");
importFile("planning_common/app/getClickStreamEnvDetails.java");

	Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
	String vzid = user.getVzId();
	String emailId=user.getEmailId();
	//logger.log(Level.INFO, "emailId "+emailId);
	String baseUrl = UPIProperties.getProperty("rfds_pg.baseUrl");
	// String baseUrl = UPIProperties.getProperty("rfds_pg.baseUrl","http://localhost:10803/plan-rfds");
	data.put("roles", gson.toJson(user.getRoles())); 
	data.put("VZID", vzid);
	data.put("emailId", emailId);
	logger.log(Level.INFO, "chen baseUrl site"+baseUrl);
	//data.put("baseUrl",gson.toJson(baseUrl));
	data.put("baseUrl",baseUrl);
	ArrayList roles = new ArrayList();
	roles.add(user.getRoles());

	ArrayList sendRoles = new ArrayList();
	if(roles.contains("PLANNING_RF_ENG")){
		sendRoles.add("PLANNING_RF_ENG");
	}
	if(roles.contains("PLANNING_TRAFFIC_ENG")){
		sendRoles.add("PLANNING_TRAFFIC_ENG");
	}

try {
	ObjectMapper mapper = new ObjectMapper();
    mapper.configure(org.codehaus.jackson.map.SerializationConfig.Feature.FAIL_ON_EMPTY_BEANS, false);
    data.put("featureToggleMap", mapper.writeValueAsString(getFeatureToggleMap()));
    ArrayList territoryList = new ArrayList();
    ArrayList areaList = new ArrayList();
    ArrayList regionList = new ArrayList();
    ArrayList marketList = new ArrayList();
    ArrayList countyList = new ArrayList();
    ArrayList enodebList = new ArrayList();
    DataSourceResultSet resultMarket = null;
    DataSourceResultSet result = null;
    DataSourceCriteria criteria = new DataSourceCriteria();
    criteria.put("USER_ID", vzid);
	
    boolean tFlag = false, aflag = false, rflag = false, mflag = false;
	
}
catch (Exception e) {
	logger.log(Level.SEVERE, "ERROR fetching by wildcard", e);
	return new WebApplicationException(500);
}
data.put("fetchSiteVersionsUrl", UPIProperties.getProperty("atoll_pg.fetchSiteVersionsUrl"));
data.put("fetchDispLocUrl", UPIProperties.getProperty("atoll_pg.fetchDispLocUrl"));
data.put("updateToAtollUrl", UPIProperties.getProperty("atoll_pg.updateToAtollUrl"));
data.put("fetchSiteDetailsUrl", UPIProperties.getProperty("atoll_pg.fetchSiteDetailsUrl"));
data.put("fetchDropDownsDataUrl", UPIProperties.getProperty("atoll_pg.fetchDropDownsDataUrl"));
data.put("clickStreamUrl", clickStreamUrl);
renderTemplate("atoll_pg/ftl/e911Dispatchable.html", data);

