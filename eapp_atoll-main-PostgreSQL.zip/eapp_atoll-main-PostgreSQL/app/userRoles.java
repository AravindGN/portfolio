import java.util.HashMap;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.verizon.webkit.util.UPIProperties;

importCommands("com.verizon.webkit.espresso");


                    

Gson gson = new GsonBuilder().setPrettyPrinting().create();

String updateRoles = UPIProperties.getProperty("atoll_pg.updateRoles","https://nppatolluat-east1.ebiz.verizon.com/npp-atoll-services/user/updateRoles");
String getRoles =  UPIProperties.getProperty("atoll_pg.getRoles","https://nppatolluat-east1.ebiz.verizon.com/npp-atoll-services/user/getRoles");

logger.info(" updateRoles = "+ updateRoles);
logger.info(" getRoles = "+ getRoles);

data.put("getRoles", getRoles);
data.put("updateRoles", updateRoles);

data.put("vzId", user.getVzId());
data.put("firstname", user.getFirstName());
data.put("lastname", user.getLastName());
data.put("roles", gson.toJson(user.getRoles())); 
renderTemplate("atoll_pg/ftl/userRoles.html", data);