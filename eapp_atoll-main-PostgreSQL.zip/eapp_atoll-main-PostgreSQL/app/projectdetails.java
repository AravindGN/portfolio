import com.verizon.webkit.util.UPIProperties;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.verizon.webkit.rest.apps.UserSettings;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import java.util.HashMap;

importCommands("com.verizon.webkit.espresso");
importFile("planning_common/app/featureToggle.java");
importFile("inbuilding2_pg/app/user/retrieve_user_details.java");
importFile("planning_common/app/getClickStreamEnvDetails.java");

Gson gson = new GsonBuilder().setPrettyPrinting().create();

ObjectMapper mapper = new ObjectMapper();
mapper.configure(org.codehaus.jackson.map.SerializationConfig.Feature.FAIL_ON_EMPTY_BEANS, false);

HashMap data = new HashMap();

HashMap featureMap = getFeatureToggleMap();

data.put("roles", gson.toJson(user.getRoles()));
String vzid = user.getVzId();
data.put("userid", vzid);


data.put("contextpath", request.getContextPath());

data.put("clickStreamUrl", clickStreamUrl);

String getPromotionUrl = UPIProperties.getProperty("atoll_pg.getPromotionUrl");
String versionPromotionUrl = UPIProperties.getProperty("atoll_pg.versionPromotionUrl");

data.put("getPromotionUrl",getPromotionUrl);
data.put("versionPromotionUrl", versionPromotionUrl);
 

String fuzeSiteId = request.getParameter("fuzeSiteId");
String projectNumber = request.getParameter("projectNumber");

if(fuzeSiteId != null) {
    data.put("fuzeSiteId", fuzeSiteId);
} else {
    data.put("fuzeSiteId", "");
}

if (projectNumber != null) {
    data.put("projectNumber", projectNumber);
} else {
    data.put("projectNumber", "");
}




if(featureMap != null && featureMap.get("F91285") != null && featureMap.get("F91285")) {
    data.put("featureToggleMap", mapper.writeValueAsString(getFeatureToggleMap()));
    data.put("getAtollSchemaData", UPIProperties.getProperty("atoll_pg.getAtollSchemaData"));
}

String path = "atoll_pg/ftl/projectdetails.html";

renderTemplate(path, data);
