import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import com.google.gson.*;
import java.util.*;
import org.json.*;
import java.util.ArrayList;
import com.google.gson.internal.LinkedTreeMap;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.stream.Collectors;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

importCommands("com.verizon.webkit.espresso");

System.out.println("Running transmitterSearch.java");
DataSourceCriteria criteria = new DataSourceCriteria();
HashMap json = new HashMap();

DataSourceResultSet rs = null;
Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();

String postData = data.get("json");
JsonElement jelem = gson.fromJson(postData, JsonElement.class);
JsonObject jobj = jelem.getAsJsonObject();
String tx_id= jobj.get("tx_id").toString();
String tilt= jobj.get("tilt").toString();
String azimut= jobj.get("azimut").toString();

System.out.println("tx_ids DATA:::"+tx_id+"--"+tilt+"--"+azimut);

criteria.put("tx_id", tx_id);
criteria.put("tilt", tilt);
criteria.put("azimut", azimut);
// int recordsFiltered = 0;
try {
    rs = DataCloud.performDynamic("atoll_pg/ds/transmitterSearchPod", criteria);
    String out = gson.toJson(rs.getRows());
    Response.ResponseBuilder builder;
    builder = Response.ok(out);
    builder.type(MediaType.APPLICATION_JSON);
    return builder.build();
}catch (Exception e) {
	 System.out.println("locationSearchPagination :"+e);
	 e.printStackTrace();
	 logger.log(Level.SEVERE, "ERROR fetching count", e);
	 return new WebApplicationException(500);
}
