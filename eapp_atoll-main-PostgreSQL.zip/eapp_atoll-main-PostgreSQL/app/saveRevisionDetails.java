import com.verizon.webkit.util.UPIProperties;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Date;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultColumnTypeEnum;
import com.verizon.webkit.datacloud.DataSourceResultFilter;
import com.verizon.webkit.datacloud.DataSourceResultMetaData;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import com.google.gson.*;
import javax.ws.rs.WebApplicationException;
import java.net.URL;
import java.net.URI;
import javax.net.ssl.HttpsURLConnection;
import java.nio.charset.Charset;
import javax.xml.bind.DatatypeConverter;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;


importCommands("com.verizon.webkit.espresso");

Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
HashMap json = gson.fromJson(data.get("json"), HashMap.class);
logger.info(" json="+json.toString());

String vzid = user.getVzId();
Double parentSolutionId = json.get("PARENT_SOLUTION_ID");
String baseRevisionID = json.get("BASE_REVISION");
String market = json.get("MARKET");

String revisionName = json.get("RevisionName") != null ? json.get("RevisionName") : "";
DataSourceCriteria criteria = new DataSourceCriteria();
criteria.put("REVISION_NAME", revisionName);
criteria.put("BASE_REVISION", baseRevisionID);
criteria.put("PARENT_SOLU_ID", parentSolutionId);
criteria.put("CREATEDBY", vzid);
criteria.put("MARKET", market);

if(json.get("coverage_type") != null && json.get("Threshold") != null) {

	criteria.put("coverage_type",json.get("coverage_type"));
	criteria.put("Threshold",json.get("Threshold"));
}
String revisionId = "";
try {
	DataSourceResultSet rs ;
	if(json.get("coverage_type") != null && json.get("Threshold") != null) {
		 rs = DataCloud.performDynamic("atoll_pg/ds/SaveRevisionWithCoverageType", criteria);
	}else{
		 rs = DataCloud.performDynamic("atoll_pg/ds/SaveRevision", criteria);
	}
	String out = gson.toJson(rs.getRows());

	for (DataSourceResult row: rs.getRows()) {
	    		revisionId = row.get("REVISION_ID").toString();
	            System.out.println(revisionId);
	}
	System.out.println("Data Inserted Successfully");
} catch(Exception e) {
	revisionId = e.getMessage().toString();
}

return gson.toJson(revisionId);


