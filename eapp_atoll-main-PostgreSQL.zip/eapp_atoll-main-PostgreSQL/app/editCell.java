import com.google.gson.Gson;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import com.google.gson.*;
importCommands("com.verizon.webkit.espresso");

Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
HashMap json = gson.fromJson(data.get("json"), HashMap.class);

DataSourceCriteria criteria = new DataSourceCriteria();
for(String key : json.keySet()) { 	  
	  String k = key;
	  String[] arr = k.split("@");
	  
	  String name = arr[0];
	  String type = arr.length > 1? arr[1] : "";
	  String value = json.get(key);

	 if ( !key.equals("SCHEMA")) {
	  if (type == "DOUBLE" ) {		 
		 Double valueD = Double.parseDouble(value);
		 criteria.put(name, valueD);
	  }
	  else if(type == "SINGLE" ) {		 
			 Integer valueS = Integer.parseInt(value);
			 criteria.put(name, valueS);
		  }
	  else if(type == "LONG INTEGER" ) {		
			 Long valueI = Long.parseLong(value);			
			 criteria.put(name, valueI);
		  }
	  else if(type == "SHORT INTEGER" ) {		
			 Integer valueSi= Integer.parseLong(value);			
			 criteria.put(name, valueSi);
		  }
	  else if(type == "TEXT" ) {		 
			 criteria.put(name, value);
		  }
	  else if(type == "BOOLEAN" ) {	
		     if(value.equals("TRUE")) {
		    	 criteria.put(name, true); 
		     }
		     else {
		    	 criteria.put(name, false); 
		     }			
		  }
	  else {
	  criteria.put(name, value);
	  }
	 }
	 else {
	 criteria.put("SCHEMA", value);
	 }
}

//logger.info("Criteria: "+ criteria);

String rs = "SUCCESS";
/*
 * try { DataSourceResultSet rs = DataCloud.performDynamic("atoll_pg/ds/editCell",
 * criteria); } catch(Exception e) { rs = e.getMessage().toString(); }
 */
 
Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
return gson.toJson(rs);