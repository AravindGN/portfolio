import com.verizon.webkit.util.UPIProperties;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URI;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import javax.net.ssl.HttpsURLConnection;
import java.nio.charset.Charset;
import javax.xml.bind.DatatypeConverter;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import com.verizon.webkit.util.ExcelExportUtil;
import com.google.gson.*;
import java.io.ByteArrayInputStream;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
importCommands("com.verizon.webkit.espresso");
DataSourceResultSet filterCountRs = null;
DataSourceResultSet paginationRs = null;
DataSourceCriteria criteria = new DataSourceCriteria();
DataSourceCriteria criteria1 = new DataSourceCriteria();
DataSourceCriteria coverageCriteria = new DataSourceCriteria();
DataSourceCriteria coverageReqIDCriteria = new DataSourceCriteria();
Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
String vzid = user.getVzId();
//String draw = data.get("draw");
// System.out.println("data: " + data);
//ArrayList json = gson.fromJson(data.get("obj"), ArrayList.class);

HashMap json = gson.fromJson(data.get("json"), HashMap.class);
String fz_workspaceName = json.get("fz_workspaceName");
String revisionId = json.get("REVISION_ID");
String baseRevisionID = json.get("BASE_REVISION");
String projectNumber = json.get("project_number");
String parentSolutionId = json.get("PARENT_SOLUTION_ID");
String selectedGeo = json.get("selectedGeo");
String selectedBand = json.get("selectedBand") != null ? json.get("selectedBand") : "";
String selectedSiteType = json.get("selectedSiteType") != null ? json.get("selectedSiteType") : "";
String selectedVersion = json.get("selectedVersion") != null ? json.get("selectedVersion") : "";
ArrayList fz_TransData = json.get("transmitterdata");

System.out.println("parentSolutionId: " + parentSolutionId);
System.out.println("revisionId: " + revisionId);
System.out.println("fz_workspaceName: " + fz_workspaceName);
System.out.println("selectedBand: " + selectedBand);
System.out.println("selectedSiteType: " + selectedSiteType);
System.out.println("selectedVersion: " + selectedVersion);

criteria.put("WS_NAME", fz_workspaceName);
criteria.put("PARENT_SOLU_ID", parentSolutionId);
criteria.put("REVISION_ID", revisionId);
criteria.put("PROJECT_NUMBER", projectNumber);
criteria.put("PARENT_SOLU_ID", parentSolutionId);
criteria.put("SELECTEDGEOM_FZ", selectedGeo);
criteria.put("SELECTED_BAND", selectedBand);
criteria.put("SELECTED_SITETYPE", selectedSiteType);
criteria.put("SELECTED_VER", selectedVersion);
criteria.put("CREATEDBY", vzid);

System.out.println("fetching row count");
DataSourceResultSet rowCount = DataCloud.performDynamic("atoll_pg/ds/getCountFZTransmittersWorkspace", criteria);
String count = "";
for (DataSourceResult row: rowCount.getRows()) {
	 count = row.get("COUNT(*)").toString();;
}
int FZrowCount =Integer.parseInt(count);  

System.out.println("rowCount1 "+ FZrowCount);

System.out.println("Before saving to DB");
DataSourceResultSet rs;
if(FZrowCount == 0){
System.out.println("insert to DB");
 rs = DataCloud.performDynamic("atoll_pg/ds/SaveFZWorkspace", criteria);
}else{
System.out.println("update to DB");
 rs = DataCloud.performDynamic("atoll_pg/ds/UpdateFZWorkspace", criteria);
}
System.out.println("afterDB"+rs.getRows());
String out = gson.toJson(rs.getRows());
System.out.println(out);
String fz_ws_id = "";

for (DataSourceResult row: rs.getRows()) {
	fz_ws_id = row.get("fz_workspace_id").toString();
             System.out.println("fz_ws_id: "+fz_ws_id);
}
// System.out.println(fz_ws_id);
double revID = Double.parseDouble(fz_ws_id);
int tempfz_ws_id = Integer.parseInt(fz_ws_id);

System.out.println("fz_TransData");
JsonArray jsonArray2 = new Gson().toJsonTree(fz_TransData).getAsJsonArray();
ArrayList<String> resultList = new ArrayList<String>();
// System.out.println(jsonArray2);

// System.out.println("jsonArray2 "+jsonArray2);
try{
    criteria1.put("FZ_WS_ID",fz_ws_id);
    for (JsonElement array_element : jsonArray2) {
        // System.out.println("jsonArray2 inside ");
        if (array_element.isJsonObject()) {
            //  System.out.println("jsonArray2 inside1 ");
            JsonObject array_object = array_element.getAsJsonObject();
            // System.out.println("INSIDE ITERATION"); 
            String transTXID = array_object.get("ATOLL_TRANSMITTER_TX_ID").getAsString();
            String transData = array_object.get("TRANSMITTER_DATA").getAsString();
            
            // System.out.println("transData " + transData);
           
            criteria1.put("TRANSTX_ID",transTXID);
            criteria1.put("TRANS_DATA",transData); 
            DataSourceResultSet rs1;
            if(FZrowCount == 0){
                System.out.println("insert transmitter to DB");
                rs1 = DataCloud.performDynamic("atoll_pg/ds/SaveFZTransmitters", criteria1);
            }else{
                System.out.println("update transmitter to DB");
                rs1 = DataCloud.performDynamic("atoll_pg/ds/UpdateFZTransmitters", criteria1);
            }
            String out = gson.toJson(rs1.getRows());
            // System.out.println(out);    
            String transmitterId = "";    
            for(DataSourceResult row : rs1.getRows()){
                transmitterId = row.get("FZ_TRANS_MAPPING_ID").toString();
                resultList.add(transmitterId);                  
            } 
            
        }
    }
} catch(Exception ee){
    System.out.println("EXCCC "+ee);
}


// System.out.println(resultList);
String nResponse = null;
try{
	String result = gson.toJson(resultList);
    Response.ResponseBuilder builder;
    builder = Response.ok(result);
    builder.type(MediaType.APPLICATION_JSON);
	return builder.build();
}catch(Exception e){
    System.out.println(e.getMessage());
}