import com.verizon.webkit.util.UPIProperties;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.verizon.webkit.rest.apps.UserSettings;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import java.util.HashMap;

importCommands("com.verizon.webkit.espresso");
 
importFile("inbuilding2_pg/app/user/retrieve_user_details.java");

Gson gson = new GsonBuilder().setPrettyPrinting().create();
 
data.put("roles", gson.toJson(user.getRoles())); 
String vzid = user.getVzId();
data.put("userid", vzid);
String url=UPIProperties.getProperty("atoll_pg.postMessageUrl");logger.info("Url "+url);
data.put("postMessageUrl",url);
String viewAllMessageUrl=UPIProperties.getProperty("atoll_pg.viewAllMessageUrl");
String deleteMessageUrl=UPIProperties.getProperty("atoll_pg.deleteMessageUrl");

data.put("viewAllMessageUrl",viewAllMessageUrl);
data.put("deleteMessageUrl",deleteMessageUrl);

String path = "atoll_pg/ftl/appNotification.html";
 
renderTemplate(path, data);
