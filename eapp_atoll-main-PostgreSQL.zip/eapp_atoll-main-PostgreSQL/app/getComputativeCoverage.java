import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import com.google.gson.*;
import java.util.*;
import org.json.*;
import java.util.ArrayList;
import com.google.gson.internal.LinkedTreeMap;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.stream.Collectors;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

importCommands("com.verizon.webkit.espresso");

DataSourceCriteria criteria = new DataSourceCriteria();
HashMap json = new HashMap();

DataSourceResultSet rs = null;
Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();

HashMap json = gson.fromJson(data.get("json"), HashMap.class);
String originalGeom = json.get("originalGeom").toString();
String drawnGeom = json.get("drawnGeom").toString();


criteria.put("originalGeom", originalGeom);
criteria.put("drawnGeom", drawnGeom);
	
try {
	rs = DataCloud.performDynamic("atoll_pg/ds/getComputativeCoverage", criteria);

    String out = gson.toJson(rs.getRows());
    Response.ResponseBuilder builder;
    builder = Response.ok(out);
    builder.type(MediaType.APPLICATION_JSON);
    System.out.println("AtollInfo:::"+builder);
    return builder.build();
}catch (Exception e) {
	 System.out.println("getAtollInfoByCoord :"+e);
	 e.printStackTrace();
	 logger.log(Level.SEVERE, "ERROR fetching count", e);
	 return new WebApplicationException(500);
}
