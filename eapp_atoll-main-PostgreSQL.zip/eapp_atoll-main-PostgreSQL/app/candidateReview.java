importCommands("com.verizon.webkit.espresso");
import com.verizon.webkit.util.UPIProperties;
import java.util.logging.Level;

	String vzid = user.getVzId();
	data.put("VZID", vzid);
	data.put("firstname", user.getFirstName());
    data.put("lastname", user.getLastName());
	data.put("spm_project_id",UPIProperties.getProperty("atoll_pg.spm_project_id"));
	data.put("parent_solution_id",UPIProperties.getProperty("atoll_pg.parent_solution_id"));

renderTemplate("atoll_pg/ftl/candidateSelection.html", data);