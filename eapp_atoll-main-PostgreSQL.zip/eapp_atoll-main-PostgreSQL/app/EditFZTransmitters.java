import com.verizon.webkit.util.UPIProperties;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URI;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import javax.net.ssl.HttpsURLConnection;
import java.nio.charset.Charset;
import javax.xml.bind.DatatypeConverter;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import com.verizon.webkit.util.ExcelExportUtil;
import com.google.gson.*;
import java.io.ByteArrayInputStream;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
importCommands("com.verizon.webkit.espresso");
DataSourceResultSet filterCountRs = null;
DataSourceResultSet paginationRs = null;
DataSourceCriteria criteria = new DataSourceCriteria();
DataSourceCriteria criteria1 = new DataSourceCriteria();
DataSourceCriteria coverageCriteria = new DataSourceCriteria();
DataSourceCriteria coverageReqIDCriteria = new DataSourceCriteria();
Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
String vzid = user.getVzId();
//String draw = data.get("draw");
System.out.println("data: " + data);
//ArrayList json = gson.fromJson(data.get("obj"), ArrayList.class);

HashMap json = gson.fromJson(data.get("json"), HashMap.class);
String fz_workspaceID = json.get("fz_workspaceID");
//String fz_transmitterIDs = json.get("fz_transmitterIDs");

ArrayList fz_TransData = json.get("transmitterdata");

System.out.println("fz_TransData");
JsonArray jsonArray2 = new Gson().toJsonTree(fz_TransData).getAsJsonArray();
ArrayList<String> resultList = new ArrayList<String>();
System.out.println(jsonArray2);

System.out.println("jsonArray2 "+jsonArray2);
try{
    criteria1.put("FZ_WS_ID",fz_workspaceID);
    for (JsonElement array_element : jsonArray2) {
        System.out.println("jsonArray2 inside ");
        if (array_element.isJsonObject()) {
             System.out.println("jsonArray2 inside1 ");
            JsonObject array_object = array_element.getAsJsonObject();
            System.out.println("INSIDE ITERATION"); 
            String transTXID = array_object.get("ATOLL_TRANSMITTER_TX_ID").getAsString();
            String transData = array_object.get("TRANSMITTER_DATA").getAsString();
            
            System.out.println("transData " + transData);
           
            criteria1.put("TRANSTX_ID",transTXID);
            criteria1.put("TRANS_DATA",transData);
            DataSourceResultSet rs = DataCloud.performDynamic("atoll_pg/ds/EditFZTransmitters", criteria1);
            String out = gson.toJson(rs.getRows());
            System.out.println(out);    
            String transmitterId = "";    
            for(DataSourceResult row : rs.getRows()){
                transmitterId = row.get("FZ_TRANS_MAPPING_ID").toString();
                resultList.add(transmitterId);                  
            } 
            
        }
    }
} catch(Exception ee){
    System.out.println("EXCCC "+ee);
}


System.out.println(resultList);
String nResponse = null;
try{
	String result = gson.toJson(resultList);
    Response.ResponseBuilder builder;
    builder = Response.ok(result);
    builder.type(MediaType.APPLICATION_JSON);
	return builder.build();
}catch(Exception e){
    System.out.println(e.getMessage());
}