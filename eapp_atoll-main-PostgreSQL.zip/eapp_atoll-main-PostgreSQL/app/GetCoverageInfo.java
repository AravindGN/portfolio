import com.google.gson.Gson;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import com.google.gson.*;
importCommands("com.verizon.webkit.espresso");
Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
HashMap json = gson.fromJson(data.get("json"), HashMap.class);
Double parentSolutionId = json.get("PARENT_SOLUTION_ID");
String transRevIds = json.get("TRANSREV_ID");
String transTXIds = json.get("TRANSTX_ID");
//System.out.println(transRevIds);

DataSourceCriteria criteria = new DataSourceCriteria();
DataSourceCriteria criteriaGeo = new DataSourceCriteria();

String [] transRevId = null;
String [] transTXId = null;
if (transRevIds != null && !transRevIds.equals("") && transTXIds!=null){
	transRevId = transRevIds.split(",");
    transTXId = transTXIds.split(",");
	//logger.info("********budgetPoolId: " + budgetPoolId[0]);
}else{
	transRevId = new String[0];
     transTXId = new String[0];
}
//System.out.println(transRevId);
List <Int> transIdList = new ArrayList<Int>();
List <Int> transTXIdList = new ArrayList<Int>();

for (int i=0; i<transRevId.length; i++){
	transIdList.add(transRevId[i]);
}
for (int i=0; i<transTXId.length; i++){
	transTXIdList.add(transTXId[i]);
}
//System.out.println("transIdList "+transIdList);
//System.out.println("transTXIdList "+transTXIdList);
criteria.put("TRANS_IDS", transIdList);
String out = "";
String out1 = "";
try{
    DataSourceResultSet rs = DataCloud.performDynamic("atoll_pg/ds/getCoverageRequestID", criteria);
     //System.out.println("RAout  "+out);
    out = gson.toJson(rs.getRows());
    System.out.println("out  "+out);
}
catch(Exception e){
    System.out.println("exception  "+e);
}

String result = out;
Response.ResponseBuilder builder;
builder = Response.ok(result);
builder.type(MediaType.APPLICATION_JSON);
return builder.build();