import com.google.gson.Gson;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import com.google.gson.*;
importCommands("com.verizon.webkit.espresso");

Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
HashMap json = gson.fromJson(data.get("json"), HashMap.class);
String atollSchema = json.get("atollSchema");
String band = json.get("band");
// String atollSchema = "denver";
// String band = "B66";

DataSourceCriteria criteria = new DataSourceCriteria();
criteria.put("SCHEMA", atollSchema);
criteria.put("FBAND", band);
DataSourceResultSet rs = DataCloud.performDynamic("atoll_pg/ds/getStationTemplatesByBand", criteria);

String out = gson.toJson(rs.getRows());
String result = "{";
result += "\"data\":" + out + "}";
Response.ResponseBuilder builder;
builder = Response.ok(result);
builder.type(MediaType.APPLICATION_JSON);
return builder.build();
