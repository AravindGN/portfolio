import com.verizon.webkit.util.UPIProperties;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URI;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

import javax.net.ssl.HttpsURLConnection;
import java.nio.charset.Charset;
import javax.xml.bind.DatatypeConverter;

import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import com.verizon.webkit.util.ExcelExportUtil;
import com.google.gson.*;
import java.io.ByteArrayInputStream;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
importCommands("com.verizon.webkit.espresso");

Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
HashMap json = gson.fromJson(data.get("json"), HashMap.class);
String reqDataJson = json.get("reqData");

System.out.println("CoverageRequestThreshold reqData: "+reqData);
String url = UPIProperties.getProperty("atoll_pg.coverage_reqthreshold","http://10.194.198.57:10533/atoll/coverage_reqthreshold");
//String url = "http://10.194.198.57:10533/atoll/coverage_reqthreshold";
System.out.println("url:      " + url);
Client client = Client.create();
WebResource resource = client.resource(url);
WebResource.Builder builder = resource.header("Accept","application/json");
builder = builder.header("Content-Type","application/json");
ClientResponse cResponse = null;

String nResponse = null;
try{
    cResponse=builder.post(ClientResponse.class, reqDataJson);
	nResponse = cResponse.getEntity(String.class);
    logger.info("nResponse: " + nResponse);
    System.out.println("CoverageRequestThreshold Response: "+nResponse);
	return nResponse;
}catch(Exception e){
	System.out.println("CoverageRequestThreshold Exception: "+e);
    logger.info(e.getMessage());    
}
