import com.google.gson.Gson;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import com.google.gson.*;
importCommands("com.verizon.webkit.espresso");

Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
HashMap json = gson.fromJson(data.get("json"), HashMap.class);
String atollSchema = json.get("atollSchema");
logger.info("atollSchema11111: " + atollSchema);
// String atollSchema = "austin";

DataSourceCriteria criteria = new DataSourceCriteria();
criteria.put("SCHEMA", atollSchema);
DataSourceResultSet rs = DataCloud.performDynamic("atoll_pg/ds/getAllBandClass", criteria);

String out = gson.toJson(rs.getRows());
String result = "{";
result += "\"data\":" + out + "}";
Response.ResponseBuilder builder;
builder = Response.ok(result);
builder.type(MediaType.APPLICATION_JSON);
return builder.build();
