import com.verizon.webkit.util.UPIProperties;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultColumnTypeEnum;
import com.verizon.webkit.datacloud.DataSourceResultFilter;
import com.verizon.webkit.datacloud.DataSourceResultMetaData;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import com.google.gson.*;
import javax.ws.rs.WebApplicationException;
import java.net.URL;
import java.net.URI;
import javax.net.ssl.HttpsURLConnection;
import java.nio.charset.Charset;
import javax.xml.bind.DatatypeConverter;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;


importCommands("com.verizon.webkit.espresso");
Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
HashMap json = gson.fromJson(data.get("json"), HashMap.class);


String url = UPIProperties.getProperty("atoll_pg.coverage_sitetxrequest","http://10.194.83.101:10533/atoll/coverage_sitetxrequest");

logger.info(" url="+url);
String auth = UPIProperties.getProperty("planning_pg.micro_service_username", "IVAPP") + ":" + UPIProperties.getProperty("planning_pg.micro_service_password", "ivapp"); 
String encodedAuthHeader = ("Basic " + DatatypeConverter.printBase64Binary(auth.getBytes(Charset.forName("US-ASCII") ) ) );

Client client = Client.create();
WebResource resource = client.resource(url);
WebResource.Builder builder = resource.header("Accept","application/json");
builder = builder.header("Content-Type","application/json");
builder.header("Authorization",encodedAuthHeader);
ClientResponse cResponse = null;

String nResponse = null;
try{
    logger.info("input: " + gson.toJson(json));
	//cResponse = builder.get(ClientResponse.class);
    cResponse=builder.post(ClientResponse.class, gson.toJson(json));
	nResponse = cResponse.getEntity(String.class);
	return nResponse;
}catch(Exception e){
    logger.info("error: " + e.getMessage());
}