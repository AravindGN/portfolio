import com.verizon.webkit.util.UPIProperties;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.verizon.webkit.rest.apps.UserSettings;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import java.util.HashMap;

importCommands("com.verizon.webkit.espresso");
importFile("planning_common/app/featureToggle.java");
importFile("inbuilding2_pg/app/user/retrieve_user_details.java");
importFile("planning_common/app/getClickStreamEnvDetails.java");

Gson gson = new GsonBuilder().setPrettyPrinting().create();
HashMap featureMap = getFeatureToggleMap(); 
ObjectMapper mapper = new ObjectMapper();
mapper.configure(org.codehaus.jackson.map.SerializationConfig.Feature.FAIL_ON_EMPTY_BEANS, false);
data.put("roles", gson.toJson(user.getRoles())); 
String vzid = user.getVzId();
data.put("userid", vzid);
data.put("clickStreamUrl", clickStreamUrl);
String path = "";
if(featureMap != null && featureMap.get("F91285") != null && featureMap.get("F91285")) {
	data.put("featureToggleMap", mapper.writeValueAsString(getFeatureToggleMap()));
	data.put("getAtollSchemaData",UPIProperties.getProperty("atoll_pg.getAtollSchemaData","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/getAtollSchema"));
	data.put("getSiteVersionsURL",UPIProperties.getProperty("atoll_pg.getSiteVersionsURL","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/getSiteVersions"));
	data.put("getSiteManagementInfoUrl", UPIProperties.getProperty("atoll_pg.getSiteManagementInfoUrl","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/siteManagement/getSiteManagementInfo"));
    data.put("saveSiteManagementInfoUrl", UPIProperties.getProperty("atoll_pg.saveSiteManagementInfoUrl","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/siteManagement/saveSiteDataBySiteManagement"));
    data.put("fetchChoiceListUrl", UPIProperties.getProperty("atoll_pg.fetchChoiceListUrl","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/atollUtility/fetchChoiceList"));
	data.put("applyAllForSiteManagement", UPIProperties.getProperty("atoll_pg.applyAllForSiteManagement","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/vzapplyAll/applyAllForSiteManagement"));
	data.put("createNewSiteVersionUrl", UPIProperties.getProperty("atoll_pg.createNewSiteVersionUrl","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/siteManagement/createNewSite"));
	data.put("carrierAddUrl", UPIProperties.getProperty("atoll_pg.carrierAddUrl","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/siteManagement/carrierAdd"));
	data.put("cellAddUrl", UPIProperties.getProperty("atoll_pg.cellAddUrl","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/siteManagement/cellAdd"));
	data.put("sectorAddUrl", UPIProperties.getProperty("atoll_pg.sectorAddUrl","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/siteManagement/sectorAdd"));
    path = "atoll_pg/ftl/atollSiteManagement.html";
    
} else {
    path = "atoll_pg/ftl/versionSearchPage.html";
}
renderTemplate(path, data);
