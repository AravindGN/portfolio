import com.google.gson.Gson;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import com.google.gson.*;
importCommands("com.verizon.webkit.espresso");

Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
HashMap json = gson.fromJson(data.get("json"), HashMap.class);

DataSourceCriteria criteria = new DataSourceCriteria();

for(String key : json.keySet()) { 	  
	  String k = key;
	  String[] arr = k.split("@");
	  
	  String name = arr[0];
	  String type = arr.length > 1? arr[1] : "";
	  String value = json.get(key);

	 if ( !key.equals("SCHEMA")) {
		 if ("DOUBLE".equalsIgnoreCase(type) || "SINGLE".equalsIgnoreCase(type)  || "LONG INTEGER".equalsIgnoreCase(type) || "SHORT INTEGER".equalsIgnoreCase(type)) {
				if(!value.isEmpty()) {					
					criteria.put(name, value);
				} else {
					criteria.put(name, null);
				}
		  }		 		  
		  else if("BOOLEAN".equalsIgnoreCase(type) ) {	
		     if(value.equals("TRUE")) {
		    	 criteria.put(name, true); 
		     }
		     else {
		    	 criteria.put(name, false); 
		     }			
		  }
		  else {
			  criteria.put(name, value);
		  }
	 }
	 else {
		 criteria.put("SCHEMA", value);
	 }
}
criteria.put("VZID", user.getVzId());

String rs = "SUCCESS";

if(!criteria.get("TX_ID").isEmpty()) {

	try{ 
		DataSourceResultSet
		rs=DataCloud.performDynamic("atoll_pg/ds/editTx",criteria); 
	} catch(Exception e) { 
		rs=e.getMessage().toString(); 
	}
} else {
	rs = "Invalid TX ID";
}

return gson.toJson(rs);