import com.verizon.webkit.util.UPIProperties;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URI;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import javax.net.ssl.HttpsURLConnection;
import java.nio.charset.Charset;
import javax.xml.bind.DatatypeConverter;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import com.verizon.webkit.util.ExcelExportUtil;
import com.google.gson.*;
import java.io.ByteArrayInputStream;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
importCommands("com.verizon.webkit.espresso");
DataSourceCriteria criteria = new DataSourceCriteria();
Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
String vzid = user.getVzId();
//String draw = data.get("draw");
System.out.println("data: " + data);
HashMap json = gson.fromJson(data.get("json"), HashMap.class);
String selectedRevisionID = json.get("selectedRevisionID").toString();
String userID = json.get("user_id").toString();

System.out.println("getFilterZoneWorkspace by Revision :"+selectedRevisionID);

String filterZoneWSRS = "";
criteria.put("REVISION_ID", selectedRevisionID);
criteria.put("created_by", userID);

try {
            DataSourceResultSet rs = DataCloud.performDynamic("atoll_pg/ds/getFZWorkspace", criteria);
            filterZoneWSRS = gson.toJson(rs.getRows());
            System.out.println(filterZoneWSRS);  
}catch (Exception e) {
	 System.out.println("getFilterZoneWorkspace by Revision Exception :"+e);
	 e.printStackTrace();
	 logger.log(Level.SEVERE, "ERROR fetching count", e);
	 return new WebApplicationException(500);
}

String nResponse = null;
try{
	String result = "{";
	result += "\"FZWorkspaceInfo\":" + filterZoneWSRS + "}";
	
    Response.ResponseBuilder builder;
    builder = Response.ok(result);
    builder.type(MediaType.APPLICATION_JSON);
    System.out.println("filterZoneWSRS:::"+builder);
	return builder.build();
}catch(Exception e){
    System.out.println(e.getMessage());
}