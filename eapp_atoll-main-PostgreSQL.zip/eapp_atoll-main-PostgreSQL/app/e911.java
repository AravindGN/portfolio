import com.verizon.webkit.util.UPIProperties;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.verizon.webkit.rest.apps.UserSettings;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import com.google.gson.Gson;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import com.google.gson.*;
importCommands("com.verizon.webkit.espresso");


DataSourceResultSet countRs = null;
DataSourceResultSet rs =null;
DataSourceCriteria criteria = new DataSourceCriteria();
Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
Integer totalCount;
int filterCount;
String out = "[]";
String search = null;
int start_row = -1;
int end_row = -1;
String length = null;





String schema = data.get("market") != null && !data.get("market").toString().equalsIgnoreCase("") ? data.get("market") : null;
String siteVersion = data.get("siteVersion") != null && !data.get("siteVersion").toString().equalsIgnoreCase("") ? data.get("siteVersion") : null;
String siteName = data.get("siteName") != null && !data.get("siteName").toString().equalsIgnoreCase("") ? data.get("siteName") : null;
String fuzeSiteId =data.get("fuzeSiteId") != null && !data.get("fuzeSiteId").equalsIgnoreCase("") ? data.get("fuzeSiteId") : null;

//String siteVersionOpr = data.get("siteVersionOpr") != null && !data.get("siteVersionOpr").toString().equalsIgnoreCase("") ? data.get("siteVersionOpr") : null;
String siteNameOpr = data.get("siteNameOpr") != null && !data.get("siteNameOpr").toString().equalsIgnoreCase("") ? data.get("siteNameOpr") : null;

String pageSize = data.get("pageSize");
String page = data.get("page");

logger.info("schema: " + schema);
logger.info("siteVersion: " + siteVersion);
logger.info("siteName: " + siteName);
logger.info("fuzeSiteId: " + fuzeSiteId);

if(null != siteNameOpr) {
	if(siteNameOpr.equalsIgnoreCase("contains"))
		siteName="%"+siteName+"%";
	else if(siteNameOpr.equalsIgnoreCase("startswith"))
		siteName=siteName+"%";
	else if(siteNameOpr.equalsIgnoreCase("endswith"))
		siteName="%"+siteName;
}

/*if(null != siteVersionOpr) {
	if(siteVersionOpr.equalsIgnoreCase("contains"))
		siteVersion="%"+siteVersion+"%";
	else if(siteVersionOpr.equalsIgnoreCase("startswith"))
		siteVersion=siteVersion+"%";
	else if(siteVersionOpr.equalsIgnoreCase("endswith"))
		siteVersion="%"+siteVersion;
}*/

if(null != schema){
	 criteria.put("SCHEMA", schema);
}else{
    criteria.put("SCHEMA", "isnull");
}
if(null !=siteVersion &&!siteVersion.equalsIgnoreCase("[]")){
	String sites=siteVersion.replace("[","").replace("]","");
	String siteVersions=sites.replace("\"","");
	logger.info("siteVersions: " + siteVersions);
	String[] replacedVersions = siteVersions.split(",");
	List<String> arrayList = Arrays.asList(replacedVersions);
	criteria.put("SITE_VERSION", arrayList);
	criteria.put("VERSION_CHECK", "1");
}else{
    criteria.put("VERSION_CHECK", "isnull");
}
if(null != siteName && null == fuzeSiteId){
	criteria.put("SITE_NAME", siteName);
}else{
    criteria.put("SITE_NAME", "isnull");
}
if(null != fuzeSiteId){
	criteria.put("FUZE_SITE_ID", fuzeSiteId);
}else{
    criteria.put("FUZE_SITE_ID", "isnull");
}

logger.info("*****************page number*************************"+data.get("page"));
if (data.get("page") != null){
	start_row = Integer.parseInt(data.get("page"))-1;
	//start_row++;
}
logger.info("******************page size**************************"+data.get("pageSize"));
if (data.get("pageSize") != null) {
	length = data.get("pageSize");
}

if(length != null){
    end_row =  Integer.parseInt(length);
}


if (start_row != null && start_row >=0) {
    criteria.put("start_row", start_row);
}
if (end_row != null && end_row >=0) {
    criteria.put("end_row", end_row);
}
String out = "";
try {
	
	DataSourceResultSet rs = DataCloud.performDynamic("atoll_pg/ds/e911Report", criteria);
	
	out = gson.toJson(rs.getRows());
	countRs = DataCloud.performDynamic("atoll_pg/ds/e911ReportCount", criteria);
    
    if (countRs.getRows() == null || countRs.getRows().isEmpty()) {
        // empty result
        
    } else {
    	//logger.info(countRs);
        for (DataSourceResult row: countRs.getRows()) {
        	//logger.info(row.get("TOTALCOUNT"));
            totalCount = row.get("TOTALCOUNT").intValue();
        }
    }


 
	 
} catch(Exception e) {
	out = e.getMessage().toString();
}

String result = "{";
result += "\"data\":" + out + ",\"totalCount\":"+totalCount+"}";
Response.ResponseBuilder builder;
builder = Response.ok(result);
builder.type(MediaType.APPLICATION_JSON);
return builder.build();
