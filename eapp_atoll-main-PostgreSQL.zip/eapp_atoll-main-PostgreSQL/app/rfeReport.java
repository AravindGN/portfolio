import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
importCommands("com.verizon.webkit.espresso");
importFile("planning_common/app/getClickStreamEnvDetails.java");

                    


Gson gson = new GsonBuilder().setPrettyPrinting().create();
data.put("roles", gson.toJson(user.getRoles())); 
data.put("clickStreamUrl", clickStreamUrl);
renderTemplate("atoll_pg/ftl/rfeReport.html", data);