import com.google.gson.Gson;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import com.google.gson.*;
importCommands("com.verizon.webkit.espresso");

Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();

HashMap json = gson.fromJson(data.get("json"), HashMap.class);

String schema = json.get("market");
String siteRecordId = json.get("site_record_id");
String txId = json.get("tx_id");

// Needs to be comvert the list of strings to , separated string
List carriersList = json.get("carriers");
StringBuilder csvBuilder = new StringBuilder();
StringBuilder fieldBuilder = new StringBuilder();
boolean separator = false;
for(AbstractMap  tmp : carriersList){
	if(separator) {
		csvBuilder.append(",");
		fieldBuilder.append(",");
	}
	csvBuilder.append(tmp.get("template"));
	fieldBuilder.append(tmp.get("label"));
	separator= true;
}
String carriers = csvBuilder.toString();
String carrier_labels = fieldBuilder.toString();
String band = json.get("band");
// logger.info("schema: " + schema + ", siteRecordId: " + siteRecordId + ", txId: " + txId + ", carriers: " + carriers + ", carrier_labels: " + carrier_labels + ", band: " + band);
DataSourceCriteria criteria = new DataSourceCriteria();
criteria.put("VZID", user.getVzId());
criteria.put("SITE_RECORD_ID", siteRecordId);
criteria.put("SCHEMA", schema);
criteria.put("CARRIERS", carriers);
criteria.put("CARRIER_LABELS", carrier_labels);
criteria.put("TX_ID", txId);
criteria.put("BAND", band);

String rs = "SUCCESS";
 try {
 	DataSourceResultSet rs = DataCloud.performDynamic("atoll_pg/ds/addCell", criteria);
 } catch(Exception e) {
 	rs = e.getMessage().toString();
 }

return gson.toJson(rs);