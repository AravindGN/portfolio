import com.google.gson.Gson;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import com.google.gson.*;
import com.verizon.webkit.util.UPIProperties;
import java.util.logging.Level;

importCommands("com.verizon.webkit.espresso");

String vzid = user.getVzId();
data.put("VZID", vzid);
data.put("firstname", user.getFirstName());
data.put("lastname", user.getLastName());
data.put("fetchUteTaskBySiteRecordIdUrl", UPIProperties.getProperty("atoll_pg.fetchUteTaskBySiteRecordIdUrl"));
data.put("fccPowerCheckUTETaskCompleteUrl", UPIProperties.getProperty("atoll_pg.fccPowerCheckUTETaskCompleteUrl"));
data.put("fccPowerCheckUTETaskRejectUrl", UPIProperties.getProperty("atoll_pg.fccPowerCheckUTETaskRejectUrl"));
renderTemplate("atoll_pg/ftl/fccPowerCheckUteTaskDetails.html", data);
