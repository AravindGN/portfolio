import com.google.gson.Gson;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import com.google.gson.*;
importCommands("com.verizon.webkit.espresso");

Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
String atollSchema = data.get("atollSchema");
String siteName = data.get("siteName");
String out = "";
if(atollSchema != null && !atollSchema.isEmpty()) {
	DataSourceCriteria criteria = new DataSourceCriteria();
	
	String query = "%" + data.get("query") + "%";
	
	criteria.put("SCHEMA", atollSchema);
	criteria.put("VZ_SITE_VERSION", query);
	criteria.put("SITE_NAME", siteName);
	DataSourceResultSet rs = DataCloud.performDynamic("atoll_pg/ds/siteVersionAutocomplete", criteria);
	
	out = gson.toJson(rs.getRows());
}
String result = "{";
result += "\"data\":" + out + "}";
Response.ResponseBuilder builder;
builder = Response.ok(result);
builder.type(MediaType.APPLICATION_JSON);
return builder.build();