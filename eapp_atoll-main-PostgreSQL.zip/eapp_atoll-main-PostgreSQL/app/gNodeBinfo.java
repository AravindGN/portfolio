importCommands("com.verizon.webkit.espresso");
import com.verizon.webkit.util.UPIProperties;
importFile("planning_common/app/featureToggle.java");
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.verizon.webkit.rest.apps.UserSettings;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.verizon.webkit.datacloud.Clob;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import java.util.logging.Level;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import javax.ws.rs.WebApplicationException;
//importFile("small_cell/app/user/retrieve_user_details.java");
importFile("inbuilding2_pg/app/user/retrieve_user_details.java");
importFile("planning_common/app/getClickStreamEnvDetails.java");

	Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
	String vzid = user.getVzId();
	String emailId=user.getEmailId();
	//logger.log(Level.INFO, "emailId "+emailId);
	String baseUrl = UPIProperties.getProperty("rfds_pg.baseUrl");
	//String baseUrl = UPIProperties.getProperty("rfds_pg.baseUrl","http://localhost:10803/plan-rfds");
	data.put("roles", gson.toJson(user.getRoles())); 
	data.put("VZID", vzid);
	data.put("emailId", emailId);
	logger.log(Level.INFO, "chen baseUrl site"+baseUrl);
	//data.put("baseUrl",gson.toJson(baseUrl));
	data.put("baseUrl",baseUrl);
	ArrayList roles = new ArrayList();
	roles.add(user.getRoles());

	ArrayList sendRoles = new ArrayList();
	if(roles.contains("PLANNING_RF_ENG")){
		sendRoles.add("PLANNING_RF_ENG");
	}
	if(roles.contains("PLANNING_TRAFFIC_ENG")){
		sendRoles.add("PLANNING_TRAFFIC_ENG");
	}

try {
	ObjectMapper mapper = new ObjectMapper();
    mapper.configure(org.codehaus.jackson.map.SerializationConfig.Feature.FAIL_ON_EMPTY_BEANS, false);
    data.put("featureToggleMap", mapper.writeValueAsString(getFeatureToggleMap()));
    ArrayList territoryList = new ArrayList();
    ArrayList areaList = new ArrayList();
    ArrayList regionList = new ArrayList();
    ArrayList marketList = new ArrayList();
    ArrayList countyList = new ArrayList();
    ArrayList enodebList = new ArrayList();
    DataSourceResultSet resultMarket = null;
    DataSourceResultSet result = null;
    DataSourceCriteria criteria = new DataSourceCriteria();
    criteria.put("USER_ID", vzid);
	
    boolean tFlag = false, aflag = false, rflag = false, mflag = false;
	
}
catch (Exception e) {
	logger.log(Level.SEVERE, "ERROR fetching by wildcard", e);
	return new WebApplicationException(500);
}
String fetchEnbReservedRangesPlanUrl = UPIProperties.getProperty("atoll_pg.fetchEnbReservedRangesPlanUrl","https://npprandev2-east1.ebiz.verizon.com/plan-equipment/enbgnbAssignment/fetchEnbReservedRanges?marketName=");
String updateEnbReservedRangesPlanUrl = UPIProperties.getProperty("atoll_pg.updateEnbReservedRangesPlanUrl","https://npprandev2-east1.ebiz.verizon.com/plan-equipment/enbgnbAssignment/updateEnbReservedRanges");
String fetchGnbCapacityPlanURL = UPIProperties.getProperty("atoll_pg.fetchGnbCapacityPlanURL","https://npprandev2-east1.ebiz.verizon.com/plan-equipment/enbgnbAssignment/fetchGnbCapacity?regionName=");
String updateGnbCapacityPlanURL = UPIProperties.getProperty("atoll_pg.updateGnbCapacityPlanURL","https://npprandev2-east1.ebiz.verizon.com/plan-equipment/enbgnbAssignment/updateGnbCapacity");
data.put("enbgnbAssignmentUrl", UPIProperties.getProperty("atoll_pg.enbgnbAssignmentUrl","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/fetchGnbData"));
data.put("enbgnbValidationUrl", UPIProperties.getProperty("atoll_pg.enbgnbValidationUrl","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/validateGNBs"));
data.put("fetchVendorsUrl", UPIProperties.getProperty("atoll_pg.fetchVendorsUrl","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/atollUtility/fetchVendors"));
data.put("fetchGnbDUNumberUrl", UPIProperties.getProperty("atoll_pg.fetchGnbDUNumberUrl","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/fetchGnbDUNumberDetails"));
data.put("fetchPhysicalGNBDetailsUrl",  UPIProperties.getProperty("atoll_pg.fetchPhysicalGNBDetailsUrl","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/fetchPhysicalGNBDetails"));
data.put("enbgnbvalidateENBsUrl",  UPIProperties.getProperty("atoll_pg.enbgnbvalidateENBsUrl","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/validateENBs"));
data.put("getSectorCarrierAssignmentsURL",  UPIProperties.getProperty("atoll_pg.getSectorCarrierAssignmentsURL","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/getSectorCarrierAssignments"));
data.put("getENBAssignmentsUrl",  UPIProperties.getProperty("atoll_pg.getENBAssignmentsUrl","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/getENBAssignments"));
data.put("getVirtualandPhysicalGNBSecAssignmentsUrl",  UPIProperties.getProperty("atoll_pg.getVirtualandPhysicalGNBSecAssignmentsUrl","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/getVirtualandPhysicalGNBSecAssignments"));
data.put("getAtollSchemaData",  UPIProperties.getProperty("atoll_pg.getAtollSchemaData","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/getAtollSchema"));
data.put("getGNBENBAtollInfoURL",  UPIProperties.getProperty("atoll_pg.getGNBENBAtollInfoURL","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/getGNBENBAtollInfo"));
data.put("getSiteVersionsURL",  UPIProperties.getProperty("atoll_pg.getSiteVersionsURL","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/getSiteVersions"));
data.put("pushGnbEnbDataToAtollURL", UPIProperties.getProperty("atoll_pg.pushGnbEnbDataToAtollURL","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/pushGnbEnbDataToAtoll"));
data.put("getAtollSchemaMarketsURL", UPIProperties.getProperty("atoll_pg.getAtollSchemaMarketsURL","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/atollUtility/getAtollSchemaMarkets?atollSchema="));
data.put("getAORPreferencesURL", UPIProperties.getProperty("atoll_pg.getAORPreferencesURL","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/getAORPreferences?vzId="));
data.put("fetchGnbCapacityURL", UPIProperties.getProperty("atoll_pg.fetchGnbCapacityURL","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/fetchGnbCapacity?regionName="));
data.put("updateGnbCapacityURL", UPIProperties.getProperty("atoll_pg.updateGnbCapacityURL","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/updateGnbCapacity"));
data.put("getUserRoleURL", UPIProperties.getProperty("atoll_pg.getUserRoleURL","https://uteidentitydit1.ebiz.verizon.com/user/uiroles/"));
data.put("fetchPciRsiReservationUrl", UPIProperties.getProperty("atoll_pg.fetchPciRsiReservationUrl","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/fetchPciRsiReservation"));
data.put("updatePciRsiReservationTableUrl", UPIProperties.getProperty("atoll_pg.updatePciRsiReservationTableUrl","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/updatePciRsiReservationTable"));
data.put("fetchEnbReservedRangesUrl", UPIProperties.getProperty("atoll_pg.fetchEnbReservedRangesUrl","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/fetchEnbReservedRanges?marketName="));
data.put("updateEnbReservedRangesUrl", UPIProperties.getProperty("atoll_pg.updateEnbReservedRangesUrl","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/updateEnbReservedRanges"));
data.put("fetchEnbReservedRangesPlanUrl", fetchEnbReservedRangesPlanUrl);
data.put("updateEnbReservedRangesPlanUrl", updateEnbReservedRangesPlanUrl);
data.put("fetchRfModulesAndLinksUrl" , UPIProperties.getProperty("atoll_pg.fetchRfModulesAndLinksUrl","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/atollUtility/fetchRfModulesAndLinks"));
data.put("fetchSchemaAndFuzeSiteIdBySiteRecordIdURL", UPIProperties.getProperty("atoll_pg.fetchSchemaAndFuzeSiteIdBySiteRecordIdURL","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/atollUtility/fetchSchemaAndFuzeSiteIdBySiteRecordId?siteRecordId="));
data.put("fetchSchemaAndFuzeSiteIdByProjectNumberURL", UPIProperties.getProperty("atoll_pg.fetchSchemaAndFuzeSiteIdByProjectNumberURL","https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/atollUtility/fetchSchemaAndFuzeSiteIdByProjectNumber?projectNumber="));
data.put("fetchSiteVersionFromRfdsUrl", UPIProperties.getProperty("atoll_pg.fetchSiteVersionFromRfdsUrl","https://npprandev2-east1.ebiz.verizon.com/plan-rfds/siteversion/fetchSiteVersion"));
data.put("fetchGnbCapacityPlanURL",fetchGnbCapacityPlanURL);
data.put("updateGnbCapacityPlanURL", updateGnbCapacityPlanURL);
data.put("getSchemaFromFuseSiteId", UPIProperties.getProperty("atoll_pg.getSchemaFromFuseSiteId"));
data.put("getSchemaFromProjectNumber", UPIProperties.getProperty("atoll_pg.getSchemaFromProjectNumber"));
data.put("deleteMiddleDigitsURL", UPIProperties.getProperty("atoll_pg.deleteMiddleDigitsURL"));
data.put("addMiddleDigitsURL", UPIProperties.getProperty("atoll_pg.addMiddleDigitsURL"));
data.put("getMiddleDigitByVendorURL", UPIProperties.getProperty("atoll_pg.getMiddleDigitByVendorURL"));
data.put("getVendFRMiddleDigit",UPIProperties.getProperty("atoll_pg.getVendFRMiddleDigit"));
data.put("getVendFRFirstDuDigit", UPIProperties.getProperty("atoll_pg.getVendFRFirstDuDigit", "https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/getVendFRFirstDuDigit"));
data.put("getInAppNotifications",UPIProperties.getProperty("atoll_pg.getInAppNotifications","https://nppranuat-east1.ebiz.verizon.com/npp-inapp-notification-service/notification"));
data.put("clickStreamUrl","https://canvas.verizon.com/canvas_open_source/clickstream.js");
data.put("getPhysicalVendorListUrl", UPIProperties.getProperty("atoll_pg.getPhysicalVendorListUrl"));
data.put("getDuVendorListUrl", UPIProperties.getProperty("atoll_pg.getDuVendorListUrl", "https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/getVendorListForDU"));
data.put("getFirstDuDigitByVendorURL", UPIProperties.getProperty("atoll_pg.getFirstDuDigitByVendorURL", "https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/getFirstDuDigit"));
data.put("addFirstDuDigitsURL", UPIProperties.getProperty("atoll_pg.addFirstDuDigitsURL", "https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/gNB/addFirstDuDigits"));
data.put("deleteFirstDuDigitsURL", UPIProperties.getProperty("atoll_pg.deleteFirstDuDigitsURL", "https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/gNB/deleteFirstDuDigits"));
data.put("getFRByVendorAndFirstDuDigitURL", UPIProperties.getProperty("atoll_pg.getFRByVendorAndFirstDuDigitURL", "https://nppatolldev2-east1.ebiz.verizon.com/npp-atoll-services/enbgnbAssignment/getFRByVendorAndFirstDuDigit"));
renderTemplate("atoll_pg/ftl/gNodeBinfo.html", data);