import com.verizon.webkit.util.UPIProperties;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URI;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import javax.net.ssl.HttpsURLConnection;
import java.nio.charset.Charset;
import javax.xml.bind.DatatypeConverter;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import com.verizon.webkit.util.ExcelExportUtil;
import com.google.gson.*;
import java.io.ByteArrayInputStream;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
importCommands("com.verizon.webkit.espresso");
DataSourceResultSet filterCountRs = null;
DataSourceResultSet paginationRs = null;
DataSourceCriteria criteria = new DataSourceCriteria();
DataSourceCriteria criteria1 = new DataSourceCriteria();
DataSourceCriteria coverageCriteria = new DataSourceCriteria();
DataSourceCriteria coverageReqIDCriteria = new DataSourceCriteria();
Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
String vzid = user.getVzId();
//String draw = data.get("draw");
System.out.println("data: " + data);
//ArrayList json = gson.fromJson(data.get("obj"), ArrayList.class);

HashMap json = gson.fromJson(data.get("json"), HashMap.class);
String revisionId = json.get("REVISION_ID");
String baseRevisionID = json.get("BASE_REVISION");

//String revisionName = json.get("RevisionName") != null ? json.get("RevisionName") : "";
//String parentSolutionId = data.get("parentSolutionId") != null ? data.get("parentSolutionId") : "";
//System.out.println("parentSolutionId: " + parentSolutionId);
//System.out.println("revisionName: " + revisionName);

//criteria.put("REVISION_NAME", revisionName);
//criteria.put("PARENT_SOLU_ID", parentSolutionId);
//criteria.put("CREATEDBY", vzid);

//DataSourceResultSet rs = DataCloud.performDynamic("atoll_pg/ds/SaveRevision", criteria);
//String out = gson.toJson(rs.getRows());
//System.out.println(out);
//String revisionId = "";

/*for (DataSourceResult row: rs.getRows()) {
    		revisionId = row.get("REVISION_ID").toString();
            System.out.println(revisionId);
}
System.out.println(revisionId);
double revID = Double.parseDouble(revisionId);
int tempRevID = (int) revID;
String reviID = (tempRevID - 1).toString();*/
ArrayList transData = json.get("transmitterdata");

System.out.println("transData");
JsonArray jsonArray2 = new Gson().toJsonTree(transData).getAsJsonArray();
ArrayList<String> resultList = new ArrayList<String>();
System.out.println(jsonArray2);

System.out.println("jsonArray2 "+jsonArray2);
try{
    criteria1.put("REVISIONID",revisionId);
    for (JsonElement array_element : jsonArray2) {
        System.out.println("jsonArray2 inside ");
        if (array_element.isJsonObject()) {
             System.out.println("jsonArray2 inside1 ");
            JsonObject array_object = array_element.getAsJsonObject();
            System.out.println("INSIDE ITERATION"); 
            String transUUIID = array_object.get("ATOLL_TRANSMITTER_UUIID").getAsString();
            String transTXID = array_object.get("ATOLL_TRANSMITTER_TX_ID").getAsString();
            String siteName = array_object.get("SITE_NAME")!= null ? array_object.get("SITE_NAME").getAsString() : null;
            String azimuth = array_object.get("AZIMUTH")!= null ? array_object.get("AZIMUTH").getAsString() : null;
            String sector = array_object.get("SECTORID")!= null ? array_object.get("SECTORID").getAsString() : null;         
            String height = array_object.get("HEIGHT")!= null ? array_object.get("HEIGHT").getAsString() : null;
            double temp = Double.parseDouble(height);
	        int heightVal = (int) temp;
	        System.out.println("height inside");
            String siteLat = array_object.get("SITE_LATITUDE")!= null ? array_object.get("SITE_LATITUDE").getAsString() : null;
            String siteLon = array_object.get("SITE_LONGITUDE")!= null ? array_object.get("SITE_LONGITUDE").getAsString() : null;
            String xtRXLosses = array_object.get("XT_RXLOSSES")!= null ? array_object.get("XT_RXLOSSES").getAsString() : null;
            String xtTXLosses = array_object.get("XT_TXLOSSES")!= null ? array_object.get("XT_TXLOSSES").getAsString() : null;
            String feederLength = array_object.get("FEEDER_LENGTH")!= null ? array_object.get("FEEDER_LENGTH").getAsString() : null;
            String vzMountFace = array_object.get("VZ_MOUNT_FACE")!= null ? array_object.get("VZ_MOUNT_FACE").getAsString() : null;
            String xtAntennaName = array_object.get("XT_ANTENNA_NAME")!= null ? array_object.get("XT_ANTENNA_NAME").getAsString() : null;
            String feederEquipment = array_object.get("FEEDER_EQUIPMENT")!= null ? array_object.get("FEEDER_EQUIPMENT").getAsString() : null;
            String rrhModel = array_object.get("XDT_VZ_RRH_MODEL")!= null ? array_object.get("XDT_VZ_RRH_MODEL").getAsString() : null;
            System.out.println("rrhModel inside");
            System.out.println(array_object.get("XT_MECHANICAL_DT"));
            Double mechanicalTiltVal = array_object.get("XT_MECHANICAL_DT")!= null ?  Double.parseDouble(array_object.get("XT_MECHANICAL_DT").getAsString())  : null;
            System.out.println(mechanicalTiltVal);
            //System.out.println("mechanicalTiltVal " + mechanicalTilt);
            //double mechanicalTiltVal = Double.parseDouble(mechanicalTiltVal)
	        //int mechanicalTiltVal = (int) tempMechanicalTilt;
            String centerLine = array_object.get("XT_VZ_CENTERLINE")!= null ? array_object.get("XT_VZ_CENTERLINE").getAsString() : null;
            String mountPosition = array_object.get("VZ_MOUNT_POSITION")!= null ? array_object.get("VZ_MOUNT_POSITION").getAsString() : null;
            Double rcAntennasVal = array_object.get("XT_NO_RX_ANTENNAS")!= null ?  Double.parseDouble(array_object.get("XT_NO_RX_ANTENNAS").getAsString()): null;
            System.out.println("rcAntennasVal inside");
            //System.out.println("rxAntennas " + rxAntennas);
            //double rcAntennasVal= Double.parseDouble(rxAntennas)
	        // int rcAntennasVal = (int) temprxAntennas;
            // System.out.println("rcAntennasVal");
            Double txAntennasVal = array_object.get("XT_NO_TX_ANTENNAS")!= null ? Double.parseDouble(array_object.get("XT_NO_TX_ANTENNAS").getAsString()) : null;
            System.out.println("txAntennasVal inside");
            //double txAntennasVal= Double.parseDouble(txAntennas);
	        //int txAntennasVal = (int) temptxAntennas;
            Double electicalTiltVal = array_object.get("AN_ELECTRICAL_TILT")!= null ? Double.parseDouble(array_object.get("AN_ELECTRICAL_TILT").getAsString()) : null;
            System.out.println("electicalTiltVal inside");
            //double electicalTiltVal= Double.parseDouble(electicalTilt);
	        //int electicalTiltVal = (int) tempelecticalTilt;
            Double tempmaxPowerVal = array_object.get("CONFIGURED_MAX_POWER")!= null ? Double.parseDouble(array_object.get("CONFIGURED_MAX_POWER").getAsString()) : null;
            System.out.println("tempmaxPowerVal inside");
            //double tempmaxPowerVal= Double.parseDouble(maxPower);
	        //int tempmaxPowerVal = (int) tempmaxPower;
            String rxLoss = array_object.get("XT_VZ_MISC_RXLOSS_COM")!= null ? array_object.get("XT_VZ_MISC_RXLOSS_COM").getAsString() : null;
            System.out.println("XT_VZ_MISC_RXLOSS_COM inside");
            String txLoss = array_object.get("XT_VZ_MISC_TXLOSS_COM")!= null ? array_object.get("XT_VZ_MISC_TXLOSS_COM").getAsString() : null;
            System.out.println("XT_VZ_MISC_TXLOSS_COM inside");
            String powerField = array_object.get("REGULATORY_POWER_FIELD")!= null ? array_object.get("REGULATORY_POWER_FIELD").getAsString() : null;
            System.out.println("REGULATORY_POWER_FIELD inside");
            String cellID = array_object.get("XC_CELL_ID")!= null ? array_object.get("XC_CELL_ID").getAsString() : null;
            System.out.println("XC_CELL_ID inside");
            String xcCarrier = array_object.get("XC_CARRIER")!= null ? array_object.get("XC_CARRIER").getAsString() : null; 
            System.out.println("XC_CARRIER inside");
            String transData = array_object.get("TRANSMITTER_DATA")!= null ?array_object.get("TRANSMITTER_DATA").getAsString(): null;         
            String status = array_object.get("STATUS").getAsString();
            String coverageType = array_object.get("COVERAGE_TYPE")!= null ?array_object.get("COVERAGE_TYPE").getAsString(): null;   
            System.out.println("geom value is " +json.get("GEOM"));
            String geomData = array_object.get("GEOM") != null ? array_object.get("GEOM").getAsString() : null;
            //String geomData= array_object.get("GEOM").getAsString();
            //String geomJson = geomData == ""?null:geomData;
            System.out.println("geom " + geoData);
            String reqID = array_object.get("COVERAGE_REQ_ID").getAsString();
            System.out.println("status " + array_object.get("COVERAGE_REQ_ID").getAsString());
            double temp = Double.parseDouble(reqID);
	        int covgRequestID = (int) temp;
	        System.out.println("covgReq " + covgRequestID);
	        //int covgReqID;
            
          
            //System.out.println("Test " + covgRequestID);
            //int covgReqID
            System.out.println(transUUIID);
            criteria1.put("TRANSUUI_ID",transUUIID);
            criteria1.put("TRANSTX_ID",transTXID);
            criteria1.put("TRANS_DATA",transData);
            criteria1.put("SITE_NAME",siteName);
            criteria1.put("SECTORID",sector);
            criteria1.put("AZIMUTH",azimuth);
            criteria1.put("SITE_LONGITUDE",siteLon);
            criteria1.put("SITE_LATITUDE",siteLat);
            criteria1.put("heightVal",heightVal);
            criteria1.put("XT_RXLOSSES",xtRXLosses);
            criteria1.put("XT_TXLOSSES",xtTXLosses);
            criteria1.put("FEEDER_LENGTH",feederLength);
            criteria1.put("VZ_MOUNT_FACE",vzMountFace);
            criteria1.put("XT_ANTENNA_NAME",xtAntennaName);
            criteria1.put("FEEDER_EQUIPMENT",feederEquipment);
            criteria1.put("XDT_VZ_RRH_MODEL",rrhModel);
            criteria1.put("XT_MECHANICAL_DT",mechanicalTiltVal);
            criteria1.put("XT_VZ_CENTERLINE",centerLine);
            criteria1.put("VZ_MOUNT_POSITION",mountPosition);
            criteria1.put("XT_NO_RX_ANTENNAS",rcAntennasVal);
            criteria1.put("XT_NO_TX_ANTENNAS",txAntennasVal);
            criteria1.put("AN_ELECTRICAL_TILT",electicalTiltVal);
            criteria1.put("CONFIGURED_MAX_POWER",tempmaxPowerVal);
            criteria1.put("XT_VZ_MISC_RXLOSS_COM",rxLoss);
            criteria1.put("XT_VZ_MISC_TXLOSS_COM",txLoss);
            criteria1.put("REGULATORY_POWER_FIELD",powerField);
            criteria1.put("XC_CELL_ID",cellID);
            criteria1.put("XC_CARRIER",xcCarrier);           
            DataSourceResultSet rs = DataCloud.performDynamic("atoll_pg/ds/SaveTransmitters", criteria1);
            String out = gson.toJson(rs.getRows());
            System.out.println(out);    
            String transmitterId = "";    
            for(DataSourceResult row : rs.getRows()){
                transmitterId = row.get("TRANS_MAPPING_ID").toString();
                resultList.add(transmitterId);                  
            } 
            System.out.println("CoverageType "+coverageType);
            if(Objects.equals(coverageType, new String("Exist"))) {
            	int covReqID = 0;
            	System.out.println("coverage already exists condition"); 
            	coverageReqIDCriteria.put("TRANS_IDS",transTXID);
            	System.out.println("TRANS_IDS " +transTXID);                
                coverageReqIDCriteria.put("BASE_REV_ID",baseRevisionID);
                System.out.println("REV_ID " +reviID);
                DataSourceResultSet rs = DataCloud.performDynamic("atoll_pg/ds/getUnchangedCovReqID", coverageReqIDCriteria);
                
                for(DataSourceResult row : rs.getRows()){
                	covReqID = row.get("COVERAGE_REQUEST_ID").intValue();
                }    
                System.out.println("coverage condition ended "+covReqID);
                coverageCriteria.put("COV_REQ_ID",covReqID);
                System.out.println("coverage Area"+ geomData);
                coverageCriteria.put("GEOM",geomData);  
            } 
            if(Objects.equals(coverageType, new String("Passed"))) {
            	System.out.println("Passed Entered");
            	coverageCriteria.put("COV_REQ_ID",covgRequestID);
            	 coverageCriteria.put("GEOM", geomData);  
            	//coverageReqID = 
            }
            if(Objects.equals(coverageType, new String("Failed"))) {
            	System.out.println("Failed Entered");
            	coverageCriteria.put("COV_REQ_ID", 0);
            	coverageCriteria.put("GEOM",null);  
            	//coverageReqID = 0;
            }
            //ST_GeomFromText(ST_GeomFromGeoJSON(:GEOM:))
            
            
            coverageCriteria.put("TRANS_ID",transmitterId);
            coverageCriteria.put("STATUS",status);
                     
            DataSourceResultSet rs11 = DataCloud.performDynamic("atoll_pg/ds/SaveCoverage", coverageCriteria);
            //String out = gson.toJson(rs.getRows());
            System.out.println("covReqID IF "); 
            
            /*if(null != txIDCovReqIDMap.get(transTXID)){
                int covReqID = txIDCovReqIDMap.get(transTXID);
                System.out.println("covReqID "+covReqID);    
                if(covReqID !=0){
                    coverageCriteria.put("COV_REQ_ID",covReqID);
                    coverageCriteria.put("TRANS_ID",transmitterId);
                    DataSourceResultSet rs11 = DataCloud.performDynamic("atoll_pg/ds/SaveCoverage", coverageCriteria);
                    //String out = gson.toJson(rs.getRows());
                    System.out.println("covReqID IF ");  
                } 
            } else{
                int covReqID = 0;
                coverageReqIDCriteria.put("TRANS_IDS",transTXID);
                double revID = Double.parseDouble(revisionId) - 1;
                coverageReqIDCriteria.put("REV_ID",revID);
                DataSourceResultSet rs = DataCloud.performDynamic("atoll_pg/ds/getUnchangedCovReqID", coverageReqIDCriteria);
                
                for(DataSourceResult row : rs.getRows()){
                    covReqID = row.get("COVERAGE_REQUEST_ID").intValue();
                }   
                 System.out.println("covReqID else "+covReqID);  
                 
                coverageCriteria.put("COV_REQ_ID",covReqID);
                coverageCriteria.put("TRANS_ID",transmitterId);
                DataSourceResultSet rs3 = DataCloud.performDynamic("atoll_pg/ds/SaveCoverage", coverageCriteria);
                String out = gson.toJson(rs3.getRows());
                System.out.println("covReqID Elseqq "+out);  
            }*/
        }
    }
} catch(Exception ee){
    System.out.println("EXCCC "+ee);
}


System.out.println(resultList);
String nResponse = null;
try{
	String result = gson.toJson(resultList);
    Response.ResponseBuilder builder;
    builder = Response.ok(result);
    builder.type(MediaType.APPLICATION_JSON);
	return builder.build();
}catch(Exception e){
    System.out.println(e.getMessage());
}