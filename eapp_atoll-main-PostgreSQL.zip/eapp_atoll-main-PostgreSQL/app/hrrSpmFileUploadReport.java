importCommands("com.verizon.webkit.espresso");
import com.verizon.webkit.util.UPIProperties;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
importFile("planning_common/app/getClickStreamEnvDetails.java");

Gson gson = new GsonBuilder().setPrettyPrinting().create();
data.put("nppAtollServicesURL", UPIProperties.getProperty("atoll_pg.nppAtollServicesURL"));
data.put("clickStreamUrl", clickStreamUrl);
renderTemplate("atoll_pg/ftl/hrrSpmFileUploadReport.html", data);