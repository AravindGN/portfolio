import com.verizon.webkit.util.UPIProperties;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultColumnTypeEnum;
import com.verizon.webkit.datacloud.DataSourceResultFilter;
import com.verizon.webkit.datacloud.DataSourceResultMetaData;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import javax.ws.rs.WebApplicationException;
import java.net.URL;
import java.net.URI;
import javax.net.ssl.HttpsURLConnection;
import java.nio.charset.Charset;
import javax.xml.bind.DatatypeConverter;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import com.google.gson.*;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;


importCommands("com.verizon.webkit.espresso");
Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
Map postData = data.get("post_data");
LinkedList take =  postData.get("take") != null ? postData.get("take") : new LinkedList();
LinkedList skip = postData.get("skip") != null ? postData.get("skip") : new LinkedList();
LinkedList initialFlagList = postData.get("initialFlag") != null ? postData.get("initialFlag") : new LinkedList();
String initialFlag = initialFlagList.size() > 0 && initialFlagList.get(0) != null? initialFlagList.get(0) : "";
LinkedList atollSchemaList = postData.get("atollSchema") != null ? postData.get("atollSchema") : new LinkedList();
String atollSchema = atollSchemaList.size() > 0 && atollSchemaList.get(0) != null? atollSchemaList.get(0) : "";
LinkedList siteNameList = postData.get("siteName") != null ? postData.get("siteName") : new LinkedList();
LinkedList txIdList = postData.get("txId") != null ? postData.get("txId") : new LinkedList();

String siteName = siteNameList.size() > 0 && siteNameList.get(0) != null? siteNameList.get(0) : "";
String txId = txIdList.size() > 0 && txIdList.get(0) != null? txIdList.get(0) : "";
LinkedList fuzeSiteIdList = postData.get("fuzeSiteId") != null ? postData.get("fuzeSiteId") : new LinkedList();
String fuzeSiteId = fuzeSiteIdList.size() > 0 && fuzeSiteIdList.get(0) != null? fuzeSiteIdList.get(0) : "";

HashMap json = new HashMap();
if(!txId.equals("")){
    json.put("tx_id",tx_id);
}
json.put("site",siteName);

// DataSourceCriteria criteria = new DataSourceCriteria();
// criteria.put("SCHEMA", atollSchema);
// criteria.put("NAME", siteName);
// DataSourceResultSet rs = DataCloud.performDynamic("atoll_pg/ds/getTxDataForMap", criteria);

// String out = gson.toJson(rs.getRows());
// String result = "{";
// result += "\"data\":" + out + "}";
// Response.ResponseBuilder builder;
// builder = Response.ok(result);
// builder.type(MediaType.APPLICATION_JSON);
// return builder.build();

String url = UPIProperties.getProperty("atoll_pg.coverage_sitetxrequest","http://10.194.83.101:10533/atoll/coverage_sitetxrequest");

logger.info(" url="+url);
String auth = UPIProperties.getProperty("planning_pg.micro_service_username", "IVAPP") + ":" + UPIProperties.getProperty("planning_pg.micro_service_password", "ivapp"); 
String encodedAuthHeader = ("Basic " + DatatypeConverter.printBase64Binary(auth.getBytes(Charset.forName("US-ASCII") ) ) );

Client client = Client.create();
WebResource resource = client.resource(url);
WebResource.Builder builder = resource.header("Accept","application/json");
builder = builder.header("Content-Type","application/json");
builder.header("Authorization",encodedAuthHeader);
ClientResponse cResponse = null;

String nResponse = null;
try{
    logger.info("input: " + gson.toJson(json));
	//cResponse = builder.get(ClientResponse.class);
    cResponse=builder.post(ClientResponse.class, gson.toJson(json));
	nResponse = cResponse.getEntity(String.class);
    logger.info("nResponse: " + nResponse);
	return nResponse;
}catch(Exception e){
    logger.info(e.getMessage());
}