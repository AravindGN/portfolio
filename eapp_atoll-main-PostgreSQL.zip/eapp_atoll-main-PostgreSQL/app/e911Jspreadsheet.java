import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import com.google.gson.*;
import com.verizon.webkit.util.UPIProperties;
import java.util.logging.Level;
importCommands("com.verizon.webkit.espresso");
importFile("planning_common/app/featureToggle.java");
importFile("planning_common/app/getClickStreamEnvDetails.java");








ObjectMapper mapper = new ObjectMapper();
data.put("featureToggleMap", mapper.writeValueAsString(getFeatureToggleMap()));

Gson gson = new GsonBuilder().setPrettyPrinting().create();
data.put("roles", gson.toJson(user.getRoles()));
data.put("fetchTransmittersBySiteNameAndVersionURL", UPIProperties.getProperty("atoll_pg.fetchTransmittersBySiteNameAndVersionURL"));
data.put("updateTransmitterAntennaDtoURL", UPIProperties.getProperty("atoll_pg.updateTransmitterAntennaDtoURL"));
data.put("fetchRfModulesAndLinksUrl", UPIProperties.getProperty("atoll_pg.fetchRfModulesAndLinksUrl"));
data.put("getAtollSchemaData", UPIProperties.getProperty("atoll_pg.getAtollSchemaData"));
data.put("fetchRfModulesAndLinksUrl", UPIProperties.getProperty("atoll_pg.fetchRfModulesAndLinksUrl"));
data.put("fetchSchemaAndFuzeSiteIdBySiteRecordIdURL", UPIProperties.getProperty("atoll_pg.fetchSchemaAndFuzeSiteIdBySiteRecordIdURL"));
data.put("fetchSchemaAndFuzeSiteIdByProjectNumberURL", UPIProperties.getProperty("atoll_pg.fetchSchemaAndFuzeSiteIdByProjectNumberURL"));
data.put("fetchSiteVersionFromRfdsUrl", UPIProperties.getProperty("atoll_pg.fetchSiteVersionFromRfdsUrl"));
data.put("getSiteVersionsURL", UPIProperties.getProperty("atoll_pg.getSiteVersionsURL"));
data.put("clickStreamUrl", clickStreamUrl);
renderTemplate("atoll_pg/ftl/e911Jspreadsheet.html", data);
