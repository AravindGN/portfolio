import com.google.gson.Gson;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import com.google.gson.*;
importCommands("com.verizon.webkit.espresso");


Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
Map postData = data.get("post_data");
LinkedList take =  postData.get("take") != null ? postData.get("take") : new LinkedList();
LinkedList skip = postData.get("skip") != null ? postData.get("skip") : new LinkedList();
LinkedList initialFlagList = postData.get("initialFlag") != null ? postData.get("initialFlag") : new LinkedList();
String initialFlag = initialFlagList.size() > 0 && initialFlagList.get(0) != null? initialFlagList.get(0) : "";
LinkedList atollSchemaList = postData.get("atollSchema") != null ? postData.get("atollSchema") : new LinkedList();
String atollSchema = atollSchemaList.size() > 0 && atollSchemaList.get(0) != null? atollSchemaList.get(0) : "";
LinkedList siteNameList = postData.get("siteName") != null ? postData.get("siteName") : new LinkedList();

String siteName = siteNameList.size() > 0 && siteNameList.get(0) != null? siteNameList.get(0) : "";
LinkedList fuzeSiteIdList = postData.get("fuzeSiteId") != null ? postData.get("fuzeSiteId") : new LinkedList();
String fuzeSiteId = fuzeSiteIdList.size() > 0 && fuzeSiteIdList.get(0) != null? fuzeSiteIdList.get(0) : "";

if(initialFlag.equals("frominitialdontreturndata")){
    String result = "{\"draw\":" + draw  + ",\"recordsFiltered\":0,\"data\":[]}";
    Response.ResponseBuilder builder;
    builder = Response.ok(result);
    builder.type(MediaType.APPLICATION_JSON);
    return builder.build();
}
DataSourceCriteria criteria = new DataSourceCriteria();

criteria.put("SCHEMA", atollSchema);
criteria.put("FUZE_SITE_ID", fuzeSiteId);
criteria.put("SITE_NAME", siteName);
DataSourceResultSet rs = DataCloud.performDynamic("atoll_pg/ds/txSearch", criteria);
Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();

String out = gson.toJson(rs.getRows());
String result = "{";
result += "\"data\":" + out + "}";
Response.ResponseBuilder builder;
builder = Response.ok(result);
builder.type(MediaType.APPLICATION_JSON);
return builder.build();
// return gson.toJson(rs);