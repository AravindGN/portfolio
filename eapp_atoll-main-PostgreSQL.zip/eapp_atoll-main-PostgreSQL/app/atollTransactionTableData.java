import com.verizon.webkit.util.UPIProperties;
import com.verizon.webkit.datacloud.DataCloud;
import com.verizon.webkit.datacloud.DataSourceCriteria;
import com.verizon.webkit.datacloud.DataSourceResult;
import com.verizon.webkit.datacloud.DataSourceResultSet;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
importCommands("com.verizon.webkit.espresso");

Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
String defaultIP="https://nppatoll-east1.vpc.verizon.com/npp-atoll-services/atollTransaction/";
String response = null;


HashMap json = gson.fromJson(data.get("json"), HashMap.class);
logger.info("view------------>"+json.get("view"));
logger.info("filterCriteria------------>"+json.get("filterCriteria"));
logger.info("projectId------------>"+json.get("projectId"));
switch(json.get("view")) {
  case "getHRRTaskStatus": 
    String getHRRTaskStatusURL = UPIProperties.getProperty("atoll_pg.getHRRTaskStatusURL", defaultIP + "getHRRTaskStatus");
    logger.info("url------------>"+getHRRTaskStatusURL);
    Client client = Client.create();
    WebResource resource = client.resource(getHRRTaskStatusURL);
    WebResource.Builder builder = resource.header("Content-Type","application/json");

    try {
      cResponse = builder.post(ClientResponse.class, gson.toJson(json.get("filterCriteria")));
      response = cResponse.getEntity(String.class);  
    } catch (Exception e){
      logger.log(Level.SEVERE, "In atollTransactionTable.java - ERROR while fetching Hrr task status data.", e);
      return new WebApplicationException(500);
    }
    break;
  case "getAtollEquipmentBundlingTransactionList": 
	    String getAtollEquipmentBundlingTransactionURL = UPIProperties.getProperty("atoll_pg.getAtollEquipmentBundlingTransactionURL", defaultIP + "getAtollEquipmentBundlingTransactionList");
	    logger.info("url------------>"+getAtollEquipmentBundlingTransactionURL);
	    Client client = Client.create();
	    WebResource resource = client.resource(getAtollEquipmentBundlingTransactionURL);
	    WebResource.Builder builder = resource.header("Content-Type","application/json");

	    try {
	      cResponse = builder.post(ClientResponse.class, gson.toJson(json.get("filterCriteria")));
	      response = cResponse.getEntity(String.class);  
	    } catch (Exception e){
	      logger.log(Level.SEVERE, "In atollTransactionTable.java - ERROR while fetching Atoll Bundling Transaction data.", e);
	      return new WebApplicationException(500);
	    }
	    break;
  case "getSPMFiles": 
	    String getSpmFilesURL = UPIProperties.getProperty("atoll_pg.getSpmFilesURL", defaultIP + "getSPMFilesByProjectId");
	    getSpmFilesURL=getSpmFilesURL+"?projectId="+json.get("projectId");
	    logger.info("url------------>"+getAtollEquipmentBundlingTransactionURL);
	    Client client = Client.create();
	    WebResource resource = client.resource(getSpmFilesURL);
	    WebResource.Builder builder = resource.header("Content-Type","application/json");

	    try {
	      cResponse = builder.get(ClientResponse.class);
	      response = cResponse.getEntity(String.class);  
	    } catch (Exception e){
	      logger.log(Level.SEVERE, "In atollTransactionTable.java - ERROR while fetching getSpmFilesURL data.", e);
	      return new WebApplicationException(500);
	    }
	    break;

  case "getHRRCandidateEntry": 
	    String getHRRCandidateEntryURL = UPIProperties.getProperty("atoll_pg.getHRRCandidateEntryURL", defaultIP + "getHRRCandidateEntryByProjectId");
	    getHRRCandidateEntryURL=getHRRCandidateEntryURL+"?projectId="+json.get("projectId");
	    logger.info("url getHRRCandidateEntry------------>"+getAtollEquipmentBundlingTransactionURL);
	    Client client = Client.create();
	    WebResource resource = client.resource(getHRRCandidateEntryURL);
	    WebResource.Builder builder = resource.header("Content-Type","application/json");

	    try {
	      cResponse = builder.get(ClientResponse.class);
	      response = cResponse.getEntity(String.class);  
	    } catch (Exception e){
	      logger.log(Level.SEVERE, "In atollTransactionTable.java - ERROR while fetching getHRRCandidateEntry data.", e);
	      return new WebApplicationException(500);
	    }
	    break;
case "getReloCandidateStatus"	:
		String getReloCandidateStatusURL = UPIProperties.getProperty("atoll_pg.getReloCandidateStatusURL", defaultIP + "getReloCandidateStatusByProjectId");
	    getReloCandidateStatusURL=getReloCandidateStatusURL+"?projectId="+json.get("projectId");
	    logger.info("url getHRRCandidateEntry------------>"+getReloCandidateStatusURL);
	    Client client = Client.create();
	    WebResource resource = client.resource(getReloCandidateStatusURL);
	    WebResource.Builder builder = resource.header("Content-Type","application/json");

	    try {
	      cResponse = builder.get(ClientResponse.class);
	      response = cResponse.getEntity(String.class);  
	    } catch (Exception e){
	      logger.log(Level.SEVERE, "In atollTransactionTable.java - ERROR while fetching getReloCandidateStatusURL data.", e);
	      return new WebApplicationException(500);
	    }
	    break;
  case "getHRRCandidateLogs": 
	    String getHRRCandidateLogsURL = UPIProperties.getProperty("atoll_pg.getHRRCandidateLogsURL", defaultIP + "getHRRCandidateLogsByProjectId");
	    getHRRCandidateLogsURL=getHRRCandidateLogsURL+"?projectId="+json.get("projectId");
	    logger.info("url  getHRRCandidateLogs------------>"+getAtollEquipmentBundlingTransactionURL);
	    Client client = Client.create();
	    WebResource resource = client.resource(getHRRCandidateLogsURL);
	    WebResource.Builder builder = resource.header("Content-Type","application/json");

	    try {
	      cResponse = builder.get(ClientResponse.class);
	      response = cResponse.getEntity(String.class);  
	    } catch (Exception e){
	      logger.log(Level.SEVERE, "In atollTransactionTable.java - ERROR while fetching getHRRCandidateLogs data.", e);
	      return new WebApplicationException(500);
	    }
	    break;
 case "getHRRCandidateDetailedLogs": 
	    String getHRRCandidateDetailedLogsURL = UPIProperties.getProperty("atoll_pg.getHRRCandidateDetailedLogsURL", defaultIP + "getHRRCandidateDetailedLogs");
	    getHRRCandidateDetailedLogsURL = getHRRCandidateDetailedLogsURL+"?projectId="+json.get("projectId")+"&fuzeSiteId="+json.get("fuzeSiteId");
	    logger.info("url  getHRRCandidateDetailedLogs------------>"+getHRRCandidateDetailedLogsURL);
		Client client = Client.create();
	    WebResource resource = client.resource(getHRRCandidateDetailedLogsURL);
	    WebResource.Builder builder = resource.header("Content-Type","application/json");

	    try {
	      cResponse = builder.get(ClientResponse.class);
	      response = cResponse.getEntity(String.class);  
	    } catch (Exception e){
	      logger.log(Level.SEVERE, "In atollTransactionTable.java - ERROR while fetching getHRRCandidateDetailedLogs data.", e);
	      return new WebApplicationException(500);
	    }
	    break;
case"getHRRProjectStatusLogs":
	    String getHRRProjectStatusLogsURL = UPIProperties.getProperty("atoll_pg.getHRRProjectStatusLogsURL", defaultIP + "getHRRTaskStatusByProjectId");
    	getHRRProjectStatusLogsURL=getHRRProjectStatusLogsURL+"?projectId="+json.get("projectId");
		logger.info("url------------>"+getHRRProjectStatusLogsURL);
		Client client = Client.create();
    	WebResource resource = client.resource(getHRRProjectStatusLogsURL);
	    WebResource.Builder builder = resource.header("Content-Type","application/json");

	    try {
	      cResponse = builder.get(ClientResponse.class);
	      response = cResponse.getEntity(String.class);  
	    } catch (Exception e){
	      logger.log(Level.SEVERE, "In atollTransactionTable.java - ERROR while fetching getHRRProjectStatusLogsURL data.", e);
	      return new WebApplicationException(500);
	    }
	    break;
 case "getHRRAnalytics": 
	    String getHRRAnalyticsURL = UPIProperties.getProperty("atoll_pg.getHRRAnalyticsURL", defaultIP + "getHRRAnalyticsByProjectId");
	    getHRRAnalyticsURL=getHRRAnalyticsURL+"?projectId="+json.get("projectId");
	    logger.info("url getHRRAnalytics------------>"+getHRRAnalyticsURL);
	    Client client = Client.create();
	    WebResource resource = client.resource(getHRRAnalyticsURL);
	    WebResource.Builder builder = resource.header("Content-Type","application/json");

	    try {
	      cResponse = builder.get(ClientResponse.class);
	      response = cResponse.getEntity(String.class);  
	    } catch (Exception e){
	      logger.log(Level.SEVERE, "In atollTransactionTable.java - ERROR while fetching getHRRAnalyticsLogs data.", e);
	      return new WebApplicationException(500);
	    }
	    break;
 case "getDataAnalytics":
		String getDataAnalyticsURL = UPIProperties.getProperty("atoll_pg.getDataAnalyticsURL", defaultIP + "getDataAnalyticsCandidateLogs");
		logger.info("url getDataAnalytics------------>"+getDataAnalyticsURL);
		Client client = Client.create();
		WebResource resource = client.resource(getDataAnalyticsURL);
		WebResource.Builder builder = resource.header("Content-Type","application/json");

		try {
		cResponse = builder.get(ClientResponse.class);
		response = cResponse.getEntity(String.class);
		} catch (Exception e){
		logger.log(Level.SEVERE, "In atollTransactionTable.java - ERROR while fetching getDataAnalytics data.", e);
		return new WebApplicationException(500);
		}
		break;
 case "getIndividualRecord":
		String getIndividualRecordURL = UPIProperties.getProperty("atoll_pg.getIndividualRecordURL", defaultIP + "getIndividualCandidateLog");
		getIndividualRecordURL=getIndividualRecordURL+"?siteInfoID="+json.get("fuzeSiteId");
		logger.info("url getIndividualRecord------------>"+getIndividualRecordURL);
		Client client = Client.create();
		WebResource resource = client.resource(getIndividualRecordURL);
		WebResource.Builder builder = resource.header("Content-Type","application/json");

		try {
		cResponse = builder.get(ClientResponse.class);
		response = cResponse.getEntity(String.class);
		} catch (Exception e){
		logger.log(Level.SEVERE, "In atollTransactionTable.java - ERROR while fetching getIndividualRecordURL data.", e);
		return new WebApplicationException(500);
		}
		break;		
  default:
    logger.info("default view/not implemented");
}

return response;